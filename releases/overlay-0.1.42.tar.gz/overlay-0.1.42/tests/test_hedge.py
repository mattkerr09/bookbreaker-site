"""Hedging a bet you already have (overlay_engine/hedge.py), the AVO bar's top gap: the arithmetic, the refusals, and
the wording the house rules require."""
import re

import pytest

from overlay_engine import hedge
from overlay_engine.ledger import Ledger, LedgerError
from overlay_engine.odds import OddsError


def test_the_same_result_hedge_leaves_the_same_result_whichever_side_wins():
    r = hedge.plan(50, 2.5, "-120")
    same = next(x for x in r["rows"] if x["name"] == "Same result")
    assert same["hedge_stake"] == pytest.approx(68.18)
    assert same["if_held_wins"] == pytest.approx(same["if_other_wins"], abs=0.01)
    assert same["if_held_wins"] == pytest.approx(6.82, abs=0.01)


def test_the_stake_back_hedge_returns_the_stake_if_the_other_side_wins():
    r = hedge.plan(50, 2.5, "-120")
    back = next(x for x in r["rows"] if x["name"] == "Stake back")
    assert back["hedge_stake"] == pytest.approx(60.0)
    assert back["if_other_wins"] == pytest.approx(0.0, abs=0.01)
    assert back["if_held_wins"] == pytest.approx(15.0)


def test_no_hedge_is_always_shown_beside_the_hedges():
    rows = hedge.plan(50, 2.5, "-120")["rows"]
    none = rows[0]
    assert none["name"] == "No hedge" and none["if_held_wins"] == 75.0 and none["if_other_wins"] == -50.0


def test_a_hedge_that_cannot_cover_says_so_rather_than_promising_a_profit():
    r = hedge.plan(50, 1.5, "-400")              # a short bet against a much shorter other side
    assert "costs more than your bet can cover" in r["headline"]


def test_it_never_promises():
    text = " ".join([hedge.plan(50, 2.5, "-120")["headline"], *hedge.plan(50, 2.5, "-120")["notes"]])
    assert not re.search(r"guarantee|risk.free|either way|free bet|can.t lose|\block\b", text, re.I)
    assert "accepted and stand" in text and "places nothing" in text


def test_a_bad_price_is_refused_in_plain_words():
    with pytest.raises(OddsError, match="other side's price"):
        hedge.plan(50, 2.5, "banana")


def test_a_saved_open_bet_is_hedged_and_a_settled_one_refused(tmp_path):
    with Ledger(tmp_path / "t.db") as db:
        bet = db.import_bet(event_id="e1", sport="nba", market_type="h2h", outcome="home", book="dk",
                            decimal_odds=2.5, stake=50.0, placed_at=1.0)
        r = hedge.for_bet(db, bet, "-120")
        assert r["bet_id"] == bet and r["rows"][2]["hedge_stake"] == pytest.approx(68.18)
        db.settle_result(bet, result="won", profit=75.0)
        with pytest.raises(LedgerError, match="already settled"):
            hedge.for_bet(db, bet, "-120")
        with pytest.raises(LedgerError, match="no bet 999"):
            hedge.for_bet(db, 999, "-120")


def test_the_window_may_run_hedge_and_the_build_asks_the_built_engine():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    rust = (root / "ui" / "src-tauri" / "src" / "main.rs").read_text()
    verbs = re.findall(r'"([a-z-]+)"', re.search(r'const ALLOWED: \[&str; \d+\] = \[([^\]]+)\]', rust).group(1))
    assert "hedge" in verbs
    build = (root / "scripts" / "build_app.sh").read_text()
    assert re.search(r"^\s+hedge\)\s+probe=\(hedge --stake 50 --held \+150 --other -120\)", build, re.M)
    js = (root / "ui" / "src" / "app.js").read_text()
    body = js[js.index("function showHedge"):js.index("function settleWords")]
    assert not re.search(r"[-+*/]\s*\d|toFixed|Math\.", body), "the window does no arithmetic on a hedge"
