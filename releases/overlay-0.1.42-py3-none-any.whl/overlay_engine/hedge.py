"""Hedge a bet you already have: what to bet on the other side, and what each result then pays.

The AVO bar's top gap (ops/qa/bookbreaker/AVO_BAR.md, 2026-10-30): a bet is open, its price has moved, and the
bettor wants to know what a bet on the other side would do. Two hedges are worked out from the bet's own stake and
price and the other side's price as typed:

  same result   the hedge stake that leaves the same result whichever side wins
  stake back    the smallest hedge stake that returns the original stake if the other side wins

and, beside them, what holding the bet alone pays. Results assume both bets are accepted and stand, and that the two
sides are the only outcomes (a push or a void returns each stake). It places nothing, reads nothing, and the window
does no arithmetic: every figure and sentence is worked out here.
"""
from __future__ import annotations

from .ledger import Ledger, LedgerError
from .odds import OddsError, decimal_to_american, parse_odds


def _money(x: float) -> str:
    return f"{'-' if x < 0 else ''}${abs(x):,.2f}"


def _signed(x: float) -> str:
    return f"{'+' if x >= 0 else '-'}${abs(x):,.2f}"


def _amer(decimal: float) -> str:
    a = round(decimal_to_american(decimal))
    return f"{'+' if a > 0 else '-'}{abs(a)}"


def plan(stake: float, held_decimal: float, other_price) -> dict:
    """The two hedges for a bet of `stake` at `held_decimal`, against `other_price` (American or decimal)."""
    try:
        other = parse_odds(other_price)
    except OddsError as exc:
        raise OddsError(f"{exc} Type the other side's price, like -120 or +105.") from None
    if not stake > 0:
        raise OddsError("The bet's stake must be more than zero.")
    held_win = stake * (held_decimal - 1.0)

    def row(name, h, why):
        h = round(h, 2)
        if_held = round(held_win - h, 2)
        if_other = round(h * (other - 1.0) - stake, 2)
        return {"name": name, "hedge_stake": h, "hedge_text": _money(h), "if_held_wins": if_held,
                "if_other_wins": if_other, "if_held_text": _signed(if_held), "if_other_text": _signed(if_other),
                "why": why}

    same = row("Same result", stake * held_decimal / other,
               "The hedge stake that leaves the same result whichever side wins.")
    back = row("Stake back", stake / (other - 1.0),
               "The smallest hedge that returns your original stake if the other side wins.")
    rows = [row("No hedge", 0.0, "Keep the bet as it is."), back, same]
    locked = same["if_held_wins"]
    if locked >= 0:
        headline = (f"Bet {same['hedge_text']} on the other side at {_amer(other)} and either result is "
                    f"{same['if_held_text']}, if both bets are accepted and stand.")
    else:
        headline = (f"At {_amer(other)} the other side costs more than your bet can cover: a same-result hedge of "
                    f"{same['hedge_text']} leaves {same['if_held_text']} on either result. Holding, or the stake-back "
                    "hedge, may suit you better.")
    return {"stake": round(stake, 2), "held_price": _amer(held_decimal), "other_price": _amer(other),
            "headline": headline, "rows": rows,
            "notes": ["Both bets must be accepted at these prices and both must stand.",
                      "A push or a void returns each stake.",
                      "Bookbreaker places nothing; the price you can get may differ from the one typed."]}


def for_bet(db: Ledger, bet_id: int, other_price) -> dict:
    """The hedges for open bet `bet_id` in this Mac's ledger."""
    bet = db.get_bet(bet_id)
    if bet is None:
        raise LedgerError(f"There is no bet {bet_id}.")
    if bet.get("profit") is not None:
        raise LedgerError(f"Bet {bet_id} is already settled, so there is nothing to hedge.")
    out = plan(float(bet["stake"]), float(bet["decimal_odds"]), other_price)
    out["bet_id"] = bet_id
    out["selection"] = bet.get("selection") or bet.get("outcome")
    out["game"] = bet.get("game") or ""
    return out
