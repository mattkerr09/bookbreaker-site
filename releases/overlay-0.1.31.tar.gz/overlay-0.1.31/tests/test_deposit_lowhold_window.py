"""The deposit plan page and the Low hold page in the window.

Static, like the Odds screen's tests: none of it needs a GUI. What these pin is what a
screenshot cannot show:

  * the shell lets the window run `deposit` and nothing else new, the build asks the
    built engine about it, and Low hold needs no verb at all (it is `board`'s read-only flag);
  * Which books to fund reuses the state Promos keeps, keeps locked and expected amounts
    in two lists with two totals in the engine's own words, and says which books were
    passed over and why, with each book's limit note;
  * Low hold's one engine call reads files only: it fetches nothing, needs no key and
    spends no credit, and nothing in the window runs it at launch or on a timer;
  * the window computes nothing on either page, draws engine text as text, and reads
    only fields the engine really sends.
"""

import contextlib
import datetime as dt
import io
import json
import os
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()
RUST = (UI / "src-tauri" / "src" / "main.rs").read_text()
BUILD = (ROOT / "scripts" / "build_app.sh").read_text()
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way", "free bet", "free money")


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def _panel(name: str) -> str:
    start = HTML.index(f'id="panel-{name}"')
    return HTML[start:HTML.index("</section>", start)]


DEPOSIT_PANEL, LOWHOLD_PANEL = _panel("deposit"), _panel("lowhold")
DEPOSIT_JS = JS[JS.index("const HAVE = "):JS.index("/* ------------------------------------------------------------ convert my own promo")]
LOWHOLD_JS = JS[JS.index("const LOWHOLD = {"):JS.index("// Local and free: whether a key is set")]


def _no_arithmetic(block: str):
    for banned in ("Math.", ".toFixed(", ".reduce(", "parseFloat", "Number(", "parseInt"):
        assert banned not in block, banned
    leaves = re.findall(r"\$\{([^`{}]*)\}", block)
    assert len(leaves) > 20, "the extractor has drifted"
    for expr in leaves:
        bare = re.sub(r"\"[^\"]*\"|'[^']*'", "''", expr)
        assert not re.search(r"[\w)\]]\s*[*/%]\s*[\w(]|[\w)\]]\s+[+-]\s+[\w(]", bare), f"arithmetic on an engine figure: {expr}"


def _raw_text(block: str, var_fields: dict):
    """Engine text interpolated without esc(): any `${var.field}` for a field that carries words."""
    raw = []
    for var, fields in var_fields.items():
        raw += re.findall(rf"\$\{{({var}\.(?:{'|'.join(fields)}))\}}", block)
    return raw


# ================================================================ the shell and the build

def test_the_shell_lets_the_window_run_deposit_and_nothing_else_new():
    allowed = re.search(r'const ALLOWED: \[&str; (\d+)\] = \[([^\]]+)\]', RUST)
    verbs = re.findall(r'"([a-z-]+)"', allowed.group(2))
    assert int(allowed.group(1)) == len(verbs) == 17 and "deposit" in verbs
    assert "lowhold" not in verbs, "Low hold is board's read-only flag, not a new verb"
    assert "lab" not in verbs and "edges" not in verbs


def test_the_shells_own_test_runs_deposit_past_the_allow_list_and_the_build_asks_the_built_engine():
    assert 'for verb in ["players", "goal", "ask", "promo", "deposit", "track"]' in RUST
    assert re.search(r"^\s+deposit\)\s+probe=\(deposit MI 1000\)", BUILD, re.M)


# ================================================================ where the pages live

def test_which_books_to_fund_is_a_page_of_promos_and_low_hold_a_page_of_arbitrage():
    promos = re.search(r'<nav class="subnav" data-section="promos" hidden>(.*?)</nav>', HTML, re.S).group(1)
    assert re.findall(r'data-panel="([a-z]+)">([^<]+)<', promos) == [
        ("welcome", "Welcome offers"), ("convert", "Convert my own promo"), ("deposit", "Which books to fund")]
    arbs = re.search(r'<nav class="subnav" data-section="arbs" hidden>(.*?)</nav>', HTML, re.S).group(1)
    assert re.findall(r'data-panel="([a-z]+)">([^<]+)<', arbs) == [("board", "Arbitrage"), ("lowhold", "Low hold")]
    assert re.search(r'<section class="panel" id="panel-deposit" data-section="promos">', HTML)
    assert re.search(r'<section class="panel" id="panel-lowhold" data-section="arbs">', HTML)
    assert len(re.findall(r'<button class="nav[^"]*" data-section=', HTML)) <= 6, "the rail is unchanged"
    assert re.search(r'<button class="nav" data-section="arbs" data-panel="board"', HTML), "the rail still opens the board"


def test_each_page_has_its_one_button_first_and_the_controls_the_script_reads():
    assert re.findall(r'data-run="([a-z-]+)"', DEPOSIT_PANEL) == ["deposit"]
    assert re.findall(r'data-run="([a-z-]+)"', LOWHOLD_PANEL) == ["lowhold"]
    for ident in ("d-bank", "d-have", "out-deposit"):
        assert f'id="{ident}"' in DEPOSIT_PANEL
    for ident in ("lh-book", "lh-amount", "out-lowhold"):
        assert f'id="{ident}"' in LOWHOLD_PANEL


def test_each_page_says_what_it_does_not_do():
    low = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", LOWHOLD_PANEL))
    assert "Nothing on this page fetches anything or spends a credit" in low
    dep = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", DEPOSIT_PANEL))
    assert "It opens no account and places no bet" in dep


# ================================================================ the state is Promos' state

def test_the_plan_reads_the_one_state_picker_and_has_no_list_of_its_own():
    assert 'id="d-state"' not in DEPOSIT_PANEL, "one state picker, in the top bar; the plan has no second one"
    changed = _braced(JS, "function stateChanged()")
    assert JS.count('store.set("bb.state"') == 1
    assert 'primed.delete("deposit");' in changed, "a plan for the state just left is worked out again when opened"


def test_with_no_state_or_no_bankroll_the_engine_is_not_asked():
    guard = JS[JS.index('if (kind === "deposit" && !val("w-state"))'):JS.index("// The Odds screen and Low hold keep showing")]
    assert "PICK_STATE_DEPOSIT" in guard and 'val("d-bank")' in guard and "return;" in guard
    assert "Pick your state" in JS[JS.index("const PICK_STATE_DEPOSIT"):][:200]


# ================================================================ the plan's engine call

def test_the_deposit_call_is_the_verb_the_state_the_bankroll_and_stated_options():
    builder = re.search(r"^\s*deposit: \(\) => \[(.*?)\],?$", JS, re.M | re.S).group(1)
    assert builder.startswith('"deposit", val("w-state"), val("d-bank"),')
    assert '`--bonus-odds=${val("w-odds")}`' in builder and '`--hold=${val("w-hold")}`' in builder, (
        "the same assumptions Welcome offers prices with, so the two pages agree")
    assert '`--have=${HAVE.join(",")}`' in builder and "HAVE.length" in builder
    assert '"--"' not in builder, "the shell appends --json last, so nothing may follow a bare --"
    assert "--json" not in builder
    for word in ("--live", "--feed", "fetch"):
        assert word not in builder


def test_the_plan_is_worked_out_when_first_opened_and_never_by_itself():
    assert re.search(r"^\s*deposit: \(\) =>", JS, re.M)
    assert re.findall(r'^run\("([a-z]+)"\);', JS, re.M) == ["keystatus", "oddsestimate"]
    assert JS.count('run("deposit")') == 1, ("the book chips are a press; a new state in the top bar marks the plan "
                                             "to be worked out again when the page is opened")
    for timer in ("setInterval", "setTimeout"):
        for m in re.finditer(timer + r"\(", JS):
            assert "deposit" not in JS[m.start():m.start() + 300].lower()


def test_the_books_you_have_are_kept_on_this_mac_by_engine_key_and_asked_again():
    assert re.search(r'filter\(\(k\) => /\^\[a-z0-9_\]\+\$/\.test\(String\(k\)\)\)', DEPOSIT_JS), "only plain keys come back out of storage"
    press = _braced(DEPOSIT_JS, 'document.getElementById("d-have").addEventListener("click"')
    assert 'store.set("bb.have", HAVE);' in press and 'run("deposit");' in press
    chips = _braced(DEPOSIT_JS, "function drawHave(")
    assert 'data-have="${esc(key)}"' in chips
    assert "[...out.fund, ...out.left, ...out.no_offer].forEach((i) => seen.set(i.book, i.name));" in chips, (
        "the books listed are the engine's, never a list typed into the window")


# ================================================================ locked and expected are kept apart

def test_locked_and_expected_are_two_lists_with_two_totals_in_the_engines_words():
    group = _braced(DEPOSIT_JS, "function depositGroup(")
    assert 'out.fund.filter((i) => i.kind === kind)' in group and "out.labels[kind]" in group
    assert "label.title" in group and "label.note" in group
    totals = _braced(DEPOSIT_JS, "function depositTotals(")
    for field in ("out.totals_text.deposit", "out.totals_text.locked", "out.totals_text.expected"):
        assert field in totals
    for field in ("t.deposit", "t.locked", "t.expected"):
        assert field in totals
    show = _braced(DEPOSIT_JS, "function showDeposit(")
    assert 'depositGroup(out, "locked")' in show and 'depositGroup(out, "expected")' in show
    assert show.index('depositGroup(out, "locked")') < show.index('depositGroup(out, "expected")'), "locked first"
    # The window never writes the titles, the notes, the totals' sentences or a value line itself.
    for words in ("Locked offers", "Expected offers", "Locked across", "Expected across", "if both bets are accepted",
                  "on average"):
        assert words not in DEPOSIT_JS, words
    assert "out.locked_means" in show and "i.value_text" in _braced(DEPOSIT_JS, "function depositItem(")


def test_a_kind_with_no_funded_book_has_no_tile_and_the_two_kinds_are_never_one_colour_or_one_figure():
    totals = _braced(DEPOSIT_JS, "function depositTotals(")
    assert 'out.fund.some((i) => i.kind === kind)' in totals
    assert 'tile("locked", t.locked, out.totals_text.locked)' in totals
    assert 'tile("expected", t.expected, out.totals_text.expected)' in totals
    assert not re.search(r"t\.locked\s*[+\-*/]|[+\-*/]\s*t\.expected|t\.expected\s*[+\-*/]|[+\-*/]\s*t\.locked", totals)
    assert re.search(r"\.dp-tot\.locked b\{color:var\(--profit\)\}", CSS)
    assert re.search(r"\.dp-tot\.expected b\{color:var\(--accent-2\)\}", CSS)
    assert re.search(r"\.dp-val\.up\{color:var\(--profit\)\}", CSS) and re.search(r"\.dp-val\.ev\{color:var\(--accent-2\)\}", CSS)


def test_a_book_passed_over_says_what_it_needs_and_why_and_every_book_carries_its_limit_note():
    item = _braced(DEPOSIT_JS, "function depositItem(")
    for field in ("i.limit_note", "i.left_text", "i.staged_note", "i.ends_note", "i.breakdown", "i.value_text", "i.offer"):
        assert field in item, field
    show = _braced(DEPOSIT_JS, "function showDeposit(")
    assert "out.left.map((i) => depositItem(i, false))" in show, "passed over whole, with what it needs"
    assert "i.reason" in show and "out.no_offer.map" in show
    assert "out.assumptions.map" in show and "out.freshness" in show
    assert "Passed over: the bankroll runs out" in show


def test_with_no_online_book_the_page_says_why_in_the_engines_words():
    show = _braced(DEPOSIT_JS, "function showDeposit(")
    assert "if (!out.online)" in show and "esc(out.message)" in show and "out.state_name" in show
    assert "box.hidden = true" in _braced(DEPOSIT_JS, "function drawHave(")


# ================================================================ it draws; it does not compute

def test_no_arithmetic_on_an_engine_figure_on_either_page():
    _no_arithmetic(DEPOSIT_JS)
    _no_arithmetic(LOWHOLD_JS)
    assert LOWHOLD_JS.count("* 1000") == 0 and DEPOSIT_JS.count("* 1000") == 0


def test_the_engines_words_are_drawn_as_text_not_markup():
    deposit_fields = ("name", "offer", "value_text", "breakdown", "staged_note", "left_text", "ends_note", "limit_note",
                      "reason", "message", "locked_means", "state_name", "freshness", "source", "read", "title", "note")
    assert _raw_text(DEPOSIT_JS, {"i": deposit_fields, "out": deposit_fields, "label": deposit_fields, "a": ("x",)}) == []
    low_fields = ("hold_text", "game", "league_label", "market_label", "cost_text", "cost_line", "line", "label",
                  "book_name", "message", "note", "warning", "age_text", "amount_text", "cost_means", "max_hold_text",
                  "name", "key")
    assert _raw_text(LOWHOLD_JS, {"r": low_fields, "l": low_fields, "s": low_fields, "b": low_fields,
                                  "one": low_fields}) == []
    for sink in ("document.write", "outerHTML", "insertAdjacentHTML", "eval(", "new Function"):
        assert sink not in DEPOSIT_JS + LOWHOLD_JS


def test_neither_page_gives_the_window_a_way_to_the_network():
    for sink in ("fetch(", "XMLHttpRequest", "WebSocket", "sendBeacon", "EventSource", "navigator."):
        assert sink not in DEPOSIT_JS + LOWHOLD_JS, sink
    assert not re.search(r'href="https?:', DEPOSIT_PANEL + LOWHOLD_PANEL)


def test_neither_page_promises_more_than_it_is():
    for text in (DEPOSIT_JS, LOWHOLD_JS, DEPOSIT_PANEL, LOWHOLD_PANEL):
        low = text.lower()
        for word in BANNED:
            assert word not in low, word


# ================================================================ Low hold's one call

def test_low_holds_one_engine_call_reads_files_only():
    builder = re.search(r"^\s*lowhold: \(\) => \[(.*?)\],?$", JS, re.M | re.S).group(1)
    assert builder.startswith('"board", "--feed", "oddsapi", "--lowhold",')
    assert '`--credit-book=${val("lh-book")}`' in builder and '`--amount=${val("lh-amount")}`' in builder
    for flag in ("--estimate", "--sport", "--region", "--market", "--live", "--bankroll", "--props", "--screen", "--min-margin"):
        assert flag not in builder, flag
    assert "oddsFlags" not in builder, "the choices that decide what a refresh reads are not part of this call"
    assert JS.count('"--lowhold"') == 1, "one argv carries the flag"
    assert JS.count('"--feed"') == 4, "the refresh, its cost line, the screen and Low hold: no fifth way to the feed"


def test_the_credit_book_picker_and_the_amount_ask_only_for_files_to_be_read_again():
    change = _braced(LOWHOLD_JS[LOWHOLD_JS.index('getElementById("lh-book").addEventListener("change"'):], "=>")
    assert 'run("lowhold")' in change and 'store.set("bb.credit", LOWHOLD.credit)' in change
    for call in ("invoke(", "fetch(", "await"):
        assert call not in change
    # The picker lists the books the answer says were priced, and nothing typed into the window.
    books = _braced(LOWHOLD_JS, "function lowholdBooks(")
    assert "out.books" in books and "b.key" in books and "b.name" in books
    assert "LOWHOLD.credit = \"\"" in books, "a credit book the latest read no longer prices is dropped"


def test_a_remembered_credit_book_is_applied_by_asking_the_files_again_and_cannot_loop():
    draw = _braced(LOWHOLD_JS, "function drawLowhold(")
    assert 's.credit_book !== val("lh-book")' in draw and 'AGAIN.add("lowhold")' in draw
    # The comparison is against the picker, not the stored choice: with nothing read there are no options, the
    # picker says "", the engine echoes "", and the two agree, so there is no second ask.
    assert "LOWHOLD.credit" not in draw[draw.index("AGAIN"):draw.index("AGAIN") + 60]


def test_it_is_worked_out_again_when_opened_and_never_at_launch_or_on_a_timer():
    show = _braced(JS, "function show(")
    assert 'if (panel === "lowhold") run("lowhold");' in show
    assert JS.count('run("lowhold")') == 2, "opening the page, and the credit book picker"
    assert re.findall(r'^run\("([a-z]+)"\);', JS, re.M) == ["keystatus", "oddsestimate"]
    for timer in ("setInterval", "setTimeout", "requestAnimationFrame"):
        for m in re.finditer(timer + r"\(", JS):
            assert "lowhold" not in JS[m.start():m.start() + 400].lower(), timer
    assert "visibilitychange" not in JS and '"focus"' not in JS


def test_a_refresh_does_not_need_to_fill_it_and_clearing_the_key_clears_it():
    assert "lowhold" not in _braced(JS, "function showOddsboard(").lower()
    clear = _braced(JS, "function showKeyclear(")
    assert "LOWHOLD.data = null;" in clear and "drawLowhold();" in clear and 'run("lowhold")' not in clear
    draw = _braced(LOWHOLD_JS, "function drawLowhold(")
    assert 'if (!s) { box.innerHTML = ""; lowholdBooks(null); return; }' in draw


def test_the_list_keeps_what_it_has_while_it_is_worked_out_again():
    assert '!(kind === "lowhold" && LOWHOLD.data)' in JS[JS.index("// The Odds screen and Low hold keep showing"):][:300]


# ================================================================ what Low hold draws

def test_a_row_draws_the_hold_both_sides_the_books_and_the_cost_from_the_engine():
    row = _braced(LOWHOLD_JS, "function lowholdRow(")
    for field in ("r.hold_text", "r.game", "r.league_label", "r.market_label", "r.legs", "r.cost_text", "r.cost_line",
                  "r.one_book", "r.is_arb"):
        assert field in row, field
    leg = _braced(LOWHOLD_JS, "function lowholdLeg(")
    for field in ("l.label", "l.american", "l.book_name", "l.stake", "l.credit", "l.also_at"):
        assert field in leg, field
    assert "amer(l.american)" in leg and "money(l.stake)" in leg


def test_an_arbitrage_is_marked_and_a_cost_is_never_drawn_as_a_gain():
    row = _braced(LOWHOLD_JS, "function lowholdRow(")
    assert '${r.is_arb ? "kept" : "cost"}' in row and '<em class="tag arb">Arbitrage</em>' in row
    assert '<b class="${r.is_arb ? "up" : ""}">${esc(r.cost_text)}</b>' in row, "only an arbitrage is green"
    assert re.search(r"\.lh-row\.arb \.lh-hold b\{color:var\(--profit\)\}", CSS)
    assert not re.search(r"\.lh-cost b\{[^}]*var\(--profit\)", CSS), "an ordinary cost is not green"


def test_the_credit_leg_is_marked_and_the_page_says_which_amount_it_means():
    leg = _braced(LOWHOLD_JS, "function lowholdLeg(")
    assert 'l.credit ? " credit" : ""' in leg and "(credit book)" in leg
    draw = _braced(LOWHOLD_JS, "function drawLowhold(")
    assert "esc(s.amount_text)" in draw and "clockTime(s.read_at)" in draw and "s.age_text" in draw
    assert "s.warning" in draw and "esc(s.cost_means)" in draw and "esc(s.note)" in draw
    assert "LAST READ" in draw
    assert re.search(r"\.lh-leg\.credit\{", CSS)


def test_an_empty_list_says_why_and_leads_to_arbitrage():
    draw = _braced(LOWHOLD_JS, "function drawLowhold(")
    assert "esc(s.message)" in draw and 'data-panel="board">Open Arbitrage' in draw and "if (!s.has_odds)" in draw
    assert "Nothing cheap enough right now" in draw


# ================================================================ dispatch and styling

def test_each_renderer_is_dispatched_and_exists():
    dispatch = re.search(r"\(\{([^}]*)\}\)\[kind\]", JS, re.S).group(1)
    for kind, fn in (("lowhold", "showLowhold"), ("deposit", "showDeposit")):
        assert re.search(rf"\b{kind}: {fn}\b", dispatch)
        assert re.search(rf"^function {fn}\(", JS, re.M)


def test_every_class_the_two_pages_use_has_a_rule_and_is_drawn():
    used = {"dp-item", "dp-left", "dp-n", "dp-body", "dp-val", "dp-limit", "dp-put", "dp-group", "dp-list", "dp-tot",
            "dp-totals", "dp-lead", "dp-passed", "dp-none", "dp-nolist", "havebox", "is-on",
            "lh-row", "lh-hold", "lh-game", "lh-legs", "lh-leg", "lh-cost", "lh-list", "credit", "arb"}
    for cls in used:
        assert re.search(rf"\.{re.escape(cls)}\b[^{{}}]*\{{", CSS), f".{cls} has no rule in app.css"
    drawn = DEPOSIT_JS + LOWHOLD_JS + DEPOSIT_PANEL
    for cls in used - {"dp-left", "dp-passed", "dp-none", "dp-lead", "is-on", "credit", "arb"}:
        assert re.search(rf'class="[^"]*\b{re.escape(cls)}\b|dp-\$\{{kind\}}', drawn), f".{cls} is styled and never drawn"
    for cls in ("dp-left", "dp-passed", "dp-none", "dp-lead", "is-on", "credit", "arb"):
        assert cls in drawn, cls


# ================================================================ the window reads only what the engine sends

@pytest.fixture(scope="module")
def plans():
    from overlay_engine import deposit

    today = dt.date(2026, 10, 12)
    return [deposit.plan("MI", 1000, today=today), deposit.plan("MI", 100_000, today=today),
            deposit.plan("NJ", 300, today=today, have="dk"), deposit.plan("TX", 1000, today=today)]


def _keys(items):
    return set().union(*(set(i) for i in items)) if items else set()


def test_every_field_the_deposit_page_reads_is_one_the_engine_sends(plans):
    sent = {
        "out": _keys(plans),
        "i": _keys([i for p in plans for part in ("fund", "left", "no_offer") for i in p[part]]),
        "t": _keys([p["totals"] for p in plans]),
        "label": _keys([l for p in plans for l in p["labels"].values()]),
    }
    block = "".join(_braced(DEPOSIT_JS, f"function {fn}(") for fn in
                    ("depositItem", "depositGroup", "depositTotals", "drawHave", "showDeposit"))
    for var, keys in sent.items():
        read = set(re.findall(rf"(?<![\w.]){var}\.([a-z_]+)", block))
        read -= {"length", "join", "map", "filter", "some", "push", "set", "forEach", "totals_text"}
        assert read <= keys, f"{var}: read but never sent: {sorted(read - keys)}"
    assert {"fund", "left", "no_offer", "labels", "totals", "totals_text", "message", "locked_means", "assumptions",
            "freshness", "online", "state_name"} <= sent["out"]
    for plan in plans:
        assert set(plan["totals_text"]) <= {"deposit", "locked", "expected"}
    assert {"deposit", "locked", "expected"} == set(plans[1]["totals_text"])
    assert {"order", "deposit", "needs", "short_by", "left_text"} <= sent["i"] | {"x"}


@pytest.fixture(scope="module")
def lowhold_answers(tmp_path_factory):
    import test_lowhold_view as tl
    import test_oddsapi as to
    import test_parity_grid as tp
    from overlay_engine import cli, oddsapi

    was = os.environ.get("OVERLAY_HOME")
    os.environ["OVERLAY_HOME"] = str(tmp_path_factory.mktemp("home"))
    answers = []
    try:
        oddsapi.refresh(to.est("nfl", markets=["h2h"]), to.KEY, clock=to.Clock(),
                        fetcher=to.FakeApi({"americanfootball_nfl": tp.only(tl.world(), "h2h")}))

        def ask(*extra):
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                assert cli.main(["board", "--feed", "oddsapi", "--lowhold", "--json", *extra]) == 0
            return json.loads(out.getvalue())

        import time
        real = time.time
        time.time = lambda: to.NOW + 30
        try:
            answers = [ask(), ask("--credit-book", "dk", "--amount", "500")]
        finally:
            time.time = real
        # An arbitrage, and then nothing read at all.
        arb = dict(tl.ML)
        arb["fanduel"] = (2.10, 1.80)
        arb["betmgm"] = (1.80, 2.10)
        oddsapi.refresh(to.est("nfl", markets=["h2h"]), to.KEY, clock=to.Clock(to.NOW + 100),
                        fetcher=to.FakeApi({"americanfootball_nfl": tp.only(tl.world(arb), "h2h")}))
        time.time = lambda: to.NOW + 130
        try:
            answers.append(ask())
        finally:
            time.time = real
        os.environ["OVERLAY_HOME"] = str(tmp_path_factory.mktemp("empty"))
        answers.append(ask())
        yield [a["lowhold"] for a in answers]
    finally:
        if was is None:
            os.environ.pop("OVERLAY_HOME", None)
        else:
            os.environ["OVERLAY_HOME"] = was


def test_every_field_the_low_hold_page_reads_is_one_the_engine_sends(lowhold_answers):
    full = [a for a in lowhold_answers if a["has_odds"]]
    assert len(full) == 3 and not lowhold_answers[3]["has_odds"]
    rows = [r for a in full for r in a["rows"]]
    legs = [l for r in rows for l in r["legs"]]
    sent = {"s": _keys(lowhold_answers) | {"message"}, "r": _keys(rows), "l": _keys(legs),
            "one": _keys([r["one_book"] for r in rows if r["one_book"]]), "b": _keys([b for a in full for b in a["books"]]),
            # books_for rides beside the low-hold block in the CLI answer (oddsapi.books_for); tested in test_state_books.
            "out": _keys(lowhold_answers) | {"books_for"}}
    block = "".join(_braced(LOWHOLD_JS, f"function {fn}(") for fn in
                    ("lowholdBooks", "lowholdLeg", "lowholdRow", "showLowhold", "drawLowhold"))
    block = re.sub(r"\.(?:map|filter|find|some)\((\w+)", r".map(\1", block)
    for var, keys in sent.items():
        read = set(re.findall(rf"(?<![\w.]){var}\.([a-z_]+)", block))
        read -= {"length", "join", "map", "filter", "find", "some", "push", "lowhold"}
        assert read <= keys, f"{var}: read but never sent: {sorted(read - keys)}"
    assert {"hold_text", "game", "legs", "cost_text", "cost_line", "one_book", "is_arb", "league_label", "market_label",
            "starts"} <= sent["r"]
    assert {"label", "american", "book_name", "stake", "credit", "also_at"} <= sent["l"]
    assert {"credit_book", "has_odds", "read_at", "age_text", "amount_text", "warning", "cost_means", "note", "rows",
            "shown", "qualifying", "max_hold_text", "books", "message"} <= sent["s"]
    assert any(r["is_arb"] for r in rows) and any(not r["is_arb"] for r in rows), "both kinds of row were exercised"
    assert any(l["credit"] for l in legs) and any(not l["credit"] for l in legs)


def test_the_empty_answer_has_the_fields_the_page_reads(lowhold_answers):
    empty = lowhold_answers[3]
    assert empty["has_odds"] is False and empty["message"] and empty["rows"] == [] and empty["books"] == []
    assert empty["credit_book"] == ""
    draw = _braced(LOWHOLD_JS, "function drawLowhold(")
    assert "s.credit_book" in draw
