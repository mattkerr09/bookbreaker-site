"""Alternate lines: the cost of one game's ladder, said before anything is read (altlines.py)."""

import pytest

from overlay_engine import altlines, oddsapi
from overlay_engine.oddsapi import OddsApiError

GAME = "abc123def4567890"


def test_the_default_is_both_ladders_in_us_and_europe_for_four_credits():
    e = altlines.estimate("nfl", GAME)
    assert e.markets == ("alternate_spreads", "alternate_totals") and e.regions == ("us", "eu")
    assert e.credits == 4


@pytest.mark.parametrize("markets,regions,credits", [
    (["alternate_spreads"], ["us"], 1), (["alternate_totals"], ["us", "eu"], 2),
    (["alternate_spreads", "alternate_totals"], ["us", "us2", "eu"], 6)])
def test_the_cost_is_markets_times_regions_for_the_one_game(markets, regions, credits):
    assert altlines.estimate("nba", GAME, markets, regions).credits == credits


def test_the_sentence_says_the_number_the_rule_and_that_nothing_reads_before_the_press():
    s = altlines.estimate("nfl", GAME, ["alternate_totals"], ["us"]).sentence()
    assert "up to 1 credit " in s and "1 market x 1 region" in s and "Nothing is read until you press Read." in s
    assert "—" not in s and "free bet" not in s.lower()


def test_the_rule_is_the_event_odds_rule_held_verbatim_and_cited():
    d = altlines.estimate("nfl", GAME).as_dict()
    assert d["rule"] == oddsapi.PROPS_COST_RULE and "GET event odds" in d["rule_source"]
    assert "betting-markets.html" in d["source"] and "2026-10-13" in d["source"]


@pytest.mark.parametrize("bad", ["", "../../v4/sports", "abc 123", "a" * 65, "short", None])
def test_a_game_id_that_could_not_be_the_odds_apis_is_refused_before_any_url(bad):
    with pytest.raises(OddsApiError) as got:
        altlines.estimate("nfl", bad)
    assert got.value.reason == "bad_choice"


def test_an_unknown_league_market_or_region_is_refused_in_a_sentence():
    for args in (("xfl", GAME), ("nfl", GAME, ["alternate_moneyline"]), ("nfl", GAME, None, ["mars"])):
        with pytest.raises(OddsApiError) as got:
            altlines.estimate(*args)
        assert got.value.reason == "bad_choice" and str(got.value).endswith(".")


# ------------------------------------------------------------ reading one game

KEY = "0123456789abcdef0123456789abcdef"


class FakeApi:
    """Answers the event-odds path only, counts calls, and charges what it is told to."""

    def __init__(self, charge=4, remaining=400):
        self.calls, self.charge, self.remaining = [], charge, remaining

    def __call__(self, path, params):
        self.calls.append((path, dict(params)))
        self.remaining -= self.charge
        payload = {"id": GAME, "sport_key": "americanfootball_nfl", "bookmakers": [
            {"key": "draftkings", "title": "DraftKings", "markets": [
                {"key": "alternate_totals", "last_update": "2026-10-13T20:00:00Z", "outcomes": [
                    {"name": "Over", "price": 1.80, "point": 44.5}, {"name": "Under", "price": 2.05, "point": 44.5}]}]}]}
        return payload, {"x-requests-last": str(self.charge), "x-requests-remaining": str(self.remaining),
                         "x-requests-used": "100"}


class Clock:
    def __init__(self, t=1_800_000_000.0):
        self.t = t

    def __call__(self):
        return self.t


@pytest.fixture
def home(monkeypatch, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def test_one_press_is_one_request_for_that_game_with_the_markets_and_regions_picked(home):
    api = FakeApi()
    got = altlines.read(altlines.estimate("nfl", GAME), KEY, clock=Clock(), fetcher=api)
    [(path, params)] = api.calls
    assert path == f"/v4/sports/americanfootball_nfl/events/{GAME}/odds"
    assert params["markets"] == "alternate_spreads,alternate_totals" and params["regions"] == "us,eu"
    assert got.credits == 4 and got.remaining == 396 and not got.from_cache and not got.warning
    assert got.payload["bookmakers"][0]["key"] == "draftkings"


def test_a_second_press_inside_the_cache_window_spends_nothing(home):
    api, clock = FakeApi(), Clock()
    est = altlines.estimate("nfl", GAME)
    altlines.read(est, KEY, clock=clock, fetcher=api)
    again = altlines.read(est, KEY, clock=clock, fetcher=api)
    assert len(api.calls) == 1 and again.from_cache and again.credits is None


def test_too_few_credits_left_is_refused_before_any_request(home):
    api = FakeApi()
    with pytest.raises(OddsApiError) as got:
        altlines.read(altlines.estimate("nfl", GAME), KEY, clock=Clock(), fetcher=api, remaining=3)
    assert api.calls == [] and "needs up to 4 credits" in str(got.value) and "3 left" in str(got.value)


def test_a_charge_above_the_rule_is_said_plainly(home):
    got = altlines.read(altlines.estimate("nfl", GAME, ["alternate_totals"], ["us"]), KEY, clock=Clock(),
                        fetcher=FakeApi(charge=3))
    assert "charged 3 credits" in got.warning and "allows 1" in got.warning


def test_the_key_is_in_no_message_and_nothing_the_read_returns(home):
    def broken(path, params):
        raise RuntimeError(f"boom with {params['apiKey']}")
    with pytest.raises(OddsApiError) as got:
        altlines.read(altlines.estimate("nfl", GAME), KEY, clock=Clock(), fetcher=broken)
    assert KEY not in str(got.value)
    ok = altlines.read(altlines.estimate("nfl", GAME), KEY, clock=Clock(), fetcher=FakeApi())
    assert KEY not in repr(ok)


# ------------------------------------------------------------ the ladder

HOME, AWAY = "Kansas City Chiefs", "Buffalo Bills"


def _spreads(home_line_prices):
    """[(home line, home price, away price)]: each home line with the away team's opposite number."""
    out = []
    for line, hp, ap in home_line_prices:
        out += [{"name": HOME, "price": hp, "point": line}, {"name": AWAY, "price": ap, "point": -line}]
    return {"key": "alternate_spreads", "last_update": "2026-10-13T20:00:00Z", "outcomes": out}


def _totals(lines):
    out = []
    for line, o, u in lines:
        out += [{"name": "Over", "price": o, "point": line}, {"name": "Under", "price": u, "point": line}]
    return {"key": "alternate_totals", "last_update": "2026-10-13T20:00:00Z", "outcomes": out}


def game_payload():
    return {"id": GAME, "sport_key": "americanfootball_nfl", "commence_time": "2026-10-20T00:20:00Z",
            "home_team": HOME, "away_team": AWAY, "bookmakers": [
                {"key": "pinnacle", "title": "Pinnacle", "markets": [
                    _spreads([(-3.5, 1.95, 1.95), (3.5, 1.40, 3.10)]), _totals([(44.5, 1.80, 2.10), (47.5, 1.98, 1.92)])]},
                {"key": "draftkings", "title": "DraftKings", "markets": [
                    _spreads([(-3.5, 1.91, 1.91), (3.5, 1.36, 3.00)]), _totals([(44.5, 1.75, 2.05), (47.5, 2.10, 1.75)])]},
                {"key": "ballybet", "title": "Bally Bet", "markets": [
                    _totals([(47.5, 2.20, 1.70)])]},
            ]}


def ladder(state=None, **kw):
    est = altlines.estimate("nfl", GAME)
    got = altlines.Read(est, game_payload(), 1_800_000_000.0)
    return altlines.ladder(got, now=1_800_000_060.0, state=state, **kw)


def lines_of(view, market):
    return next(s for s in view["sections"] if s["market"] == market)["lines"]


def test_a_spread_line_pairs_with_the_other_teams_opposite_number_never_the_same_sign():
    for line in lines_of(ladder(), "spreads"):
        labels = sorted(r["label"] for r in line["rows"])
        assert len(labels) == 2
        (a, la), (b, lb) = [(r["outcome"].split("@")[0], float(r["outcome"].split("@")[1])) for r in line["rows"]]
        assert a != b and la == -lb, labels
    assert {l["line"] for l in lines_of(ladder(), "spreads")} == {-3.5, 3.5}


def test_a_total_line_is_over_and_under_at_one_number():
    for line in lines_of(ladder(), "totals"):
        assert [r["label"].split()[0] for r in line["rows"]] == ["Over", "Under"]
        assert len({r["line"] for r in line["rows"]}) == 1


def test_every_line_has_a_fair_price_from_books_that_priced_both_sides():
    for market in ("spreads", "totals"):
        for line in lines_of(ladder(), market):
            probs = [r["fair"]["prob"] for r in line["rows"]]
            assert all(p for p in probs) and abs(sum(probs) - 1.0) < 1e-3


def test_without_a_state_bally_can_be_best_and_in_michigan_it_never_is():
    over_47 = lambda v: next(r for l in lines_of(v, "totals") if l["line"] == 47.5 for r in l["rows"]
                             if r["label"].startswith("Over"))
    assert over_47(ladder())["best"]["books"] == ["ballybet"]
    mi = over_47(ladder(state="MI"))
    assert mi["best"]["books"] == ["dk"] and not mi["cells"]["ballybet"].get("best")
    assert not mi["cells"]["ballybet"].get("ev")
    cols = {c["key"]: c["bettable"] for c in ladder(state="MI")["books"]}
    assert cols["ballybet"] is False and cols["pinnacle"] is False and cols["dk"] is True


def test_a_reference_book_is_never_best_or_ev():
    for market in ("spreads", "totals"):
        for line in lines_of(ladder(), market):
            for r in line["rows"]:
                assert "pinnacle" not in (r["best"] or {}).get("books", [])
                assert not r["cells"].get("pinnacle", {}).get("ev")


def test_the_view_names_the_game_says_the_state_rule_and_never_claims_arbs():
    v = ladder()
    assert v["game"] == f"{AWAY} at {HOME}" and v["has_lines"]
    assert v["books_for"]["sentence"] == oddsapi.NO_STATE
    assert "Arbs and middles between alternate lines are not looked for yet." in v["note"]
    assert "—" not in v["note"]


def test_a_price_above_the_fair_line_at_a_bettable_book_is_marked_with_its_ev():
    over = next(r for l in lines_of(ladder(state="MI"), "totals") if l["line"] == 47.5 for r in l["rows"]
                if r["label"].startswith("Over"))
    ev = over["cells"]["dk"].get("ev")
    assert ev is not None and ev > 0
    assert abs(ev - (2.10 * over["fair"]["prob"] - 1)) < 0.02, "the board's EV, within its own adjustments"


# ------------------------------------------------------------ kept on this Mac

def test_a_read_is_kept_and_reopens_later_with_no_request(home):
    api = FakeApi()
    altlines.read(altlines.estimate("nfl", GAME), KEY, clock=Clock(), fetcher=api)
    back = altlines.load("nfl", GAME, now=1_800_000_000.0 + 3 * 86400)
    assert back is not None and back.from_cache and back.payload["bookmakers"][0]["key"] == "draftkings"
    assert len(api.calls) == 1
    files = list(altlines.folder().glob("*.json"))
    assert files and oct(files[0].stat().st_mode & 0o777) == "0o600"


def test_a_stored_read_past_thirty_days_is_not_shown(home):
    altlines.read(altlines.estimate("nfl", GAME), KEY, clock=Clock(), fetcher=FakeApi())
    assert altlines.load("nfl", GAME, now=1_800_000_000.0 + 31 * 86400) is None


def test_clearing_the_key_clears_the_kept_alternate_lines(home):
    altlines.read(altlines.estimate("nfl", GAME), KEY, clock=Clock(), fetcher=FakeApi())
    assert list(altlines.folder().glob("*.json"))
    oddsapi.Cache().clear()
    assert not altlines.folder().exists()


# ------------------------------------------------------------ the command the window runs

import json  # noqa: E402

from overlay_engine import cli, keystore  # noqa: E402


class GameApi(FakeApi):
    def __call__(self, path, params):
        self.calls.append((path, dict(params)))
        self.remaining -= self.charge
        return game_payload(), {"x-requests-last": str(self.charge), "x-requests-remaining": str(self.remaining)}


def test_the_cli_reads_once_says_the_cost_and_reopens_from_this_mac_for_nothing(home, monkeypatch, capsys):
    api = GameApi()
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: KEY)
    base = ["board", "--feed", "oddsapi", "--alt-league", "nfl", "--alt-event", GAME, "--state", "MI", "--json"]
    assert cli.main([*base, "--alt-lines"]) == 0
    first = json.loads(capsys.readouterr().out)
    assert first["estimate"]["credits"] == 4 and first["altlines"]["credits"] == 4
    assert first["altlines"]["has_lines"] and first["altlines"]["books_for"]["state"] == "MI"
    assert len(api.calls) == 1 and KEY not in json.dumps(first)
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: (_ for _ in ()).throw(AssertionError("key read")))
    assert cli.main([*base, "--alt-stored"]) == 0
    again = json.loads(capsys.readouterr().out)["altlines"]
    assert again["from_cache"] and again["sections"] == first["altlines"]["sections"] and len(api.calls) == 1


def test_the_cli_refuses_mixing_alternate_lines_with_other_reads(home, capsys):
    for extra in (["--futures"], ["--screen"], ["--alt-stored", "--estimate"], ["--sport", "nfl"]):
        code = cli.main(["board", "--feed", "oddsapi", "--alt-lines", "--alt-league", "nfl", "--alt-event", GAME,
                         *extra, "--json"])
        assert code != 0, extra
        capsys.readouterr()


# ------------------------------------------------------------ the window

import re  # noqa: E402
from pathlib import Path  # noqa: E402

JS = (Path(__file__).resolve().parent.parent / "ui" / "src" / "app.js").read_text()


def test_opening_a_game_only_prices_it_and_opens_what_is_kept_and_never_reads():
    est = re.search(r"^\s*altestimate: \(\) => \[(.*?)\],$", JS, re.M).group(1)
    assert '"--estimate"' in est and '"--alt-lines"' in est
    stored = re.search(r"^\s*altstored: \(\) => \[(.*?)\],$", JS, re.M).group(1)
    assert '"--alt-stored"' in stored and '"--alt-lines"' not in stored
    opener = JS[JS.index('const b = ev.target.closest && ev.target.closest("[data-alt]");'):]
    opener = opener[:opener.index("});")]
    assert 'run("altestimate")' in opener and 'run("altstored")' in opener and "altread" not in opener
    assert JS.count('data-run="altread"') == 1, "only the Read button reads"


def test_the_window_draws_the_engines_ev_text_and_computes_nothing():
    block = JS[JS.index("function altLadder("):JS.index("function drawScreen()")]
    for banned in ("Math.", ".toFixed(", "* 100", "parseFloat", "Number("):
        assert banned not in block, banned
    assert "c.ev_text" in block
