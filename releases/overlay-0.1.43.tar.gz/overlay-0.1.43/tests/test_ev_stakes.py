"""A suggested stake on every +EV play (kelly.ev_stake / stake_rows; the AVO bar's item 11): Kelly sized from the LOW
end of the fair chance, nothing when that end has no edge, and the words the house rules require."""
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import kelly

ROOT = Path(__file__).resolve().parents[1]


def test_the_stake_is_kelly_on_the_low_end_of_the_fair_chance():
    decimal, fair, ev_low = 2.2, 0.5, 0.03            # low end: (1 + 0.03) / 2.2
    r = kelly.ev_stake(decimal, fair, ev_low, 2000, 0.25)
    expect = kelly.size_bet(decimal, fair, 2000, fraction=0.25, prob_low=(1 + ev_low) / decimal).stake
    assert r["stake"] == pytest.approx(round(expect, 2))
    mid = kelly.size_bet(decimal, fair, 2000, fraction=0.25).stake
    assert r["stake"] < mid, "sized from the cautious end, not the middle"


def test_no_edge_at_the_low_end_means_no_stake():
    r = kelly.ev_stake(2.0, 0.52, -0.01, 2000)
    assert r["stake"] == 0 and r["text"].startswith("No stake suggested")


def test_the_words_never_promise():
    t = kelly.ev_stake(2.2, 0.5, 0.03, 2000)["text"]
    assert "any one bet can lose" in t and "low end of its fair chance" in t
    assert not re.search(r"guarantee|risk.free|either way|free bet|\bwin\b|sure thing", t, re.I)


def test_only_ev_rows_get_a_stake():
    rows = [{"kind": "arb", "legs": [{"decimal": 2.1, "fair_prob": 0.5, "ev_low": 0.02}]},
            {"kind": "ev", "legs": [{"decimal": 2.2, "fair_prob": 0.5, "ev_low": 0.03}]}]
    kelly.stake_rows(rows, 1000)
    assert "sizing" not in rows[0] and rows[1]["sizing"]["stake"] > 0


def test_the_board_sizes_ev_rows_only_when_a_bankroll_is_given():
    run = lambda *a: json.loads(subprocess.run([sys.executable, "-m", "overlay_engine.cli", "board", "--kind", "ev",
                                                *a, "--json"], cwd=ROOT / "backend", capture_output=True, text=True,
                                               check=True).stdout)
    with_bank = run("--kelly-bankroll", "2000")
    assert with_bank["rows"] and all("sizing" in r for r in with_bank["rows"])
    assert all(r["sizing"] is None for r in run()["rows"])


def test_the_window_draws_the_engines_sentence_and_does_no_arithmetic():
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    assert '${p.sizing ? `<p class="c-note">${esc(p.sizing.text)}</p>` : ""}' in js
    assert "function kellyFlags" in js and "...kellyFlags()" in js
    html = (ROOT / "ui" / "src" / "index.html").read_text()
    assert 'id="b-kbank"' in html and 'id="b-kfrac"' in html
