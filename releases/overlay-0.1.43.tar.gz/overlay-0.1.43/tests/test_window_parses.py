"""The window's own scripts parse. Every other window test reads app.js as text, so a stray brace passed the whole
gate on 2026-10-30 and only the live preview caught it ("Unexpected token '}'": the window drew nothing)."""
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
NODE = shutil.which("node")


@pytest.mark.skipif(NODE is None, reason="node is not installed")
@pytest.mark.parametrize("name", ["app.js", "whatsnew.js"])
def test_the_window_script_parses(name):
    run = subprocess.run([NODE, "--check", str(ROOT / "ui" / "src" / name)], capture_output=True, text=True)
    assert run.returncode == 0, run.stderr[-400:]
