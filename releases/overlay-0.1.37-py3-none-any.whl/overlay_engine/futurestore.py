"""The last read of each league's futures, kept on this Mac so the view can be reopened for free.

A futures read costs credits, and the prices in it are worth looking at long after the minute the
Odds API answer is reused for. So each read is written, as it was read, to
`~/.overlay/oddsapi/futures/<league>.json` (one file per league, the newest read replacing the
older one), and `futures.from_store` lays the grid out from it with no key, no request and no credit.

It is the same promise `oddshistory` makes for the main odds, kept apart from it on purpose: a
futures market has dozens of outcomes and no game to start, and the Odds screen and Low hold read
`oddshistory` as two-way markets of games.

**Each price keeps the time its book last confirmed it** (the feed's own `last_update`), so the age
shown when the view is reopened a day later is the true one: `now - seen_at`, never the age at the
time of the read.

**Kept 30 days, readable by its owner only, deleted with the key.** `key clear` removes the odds the
key fetched, and `oddsapi.Cache.clear` calls `clear` here, so these go with them.
"""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

from .ledger import home
from .models import Market, Outcome, Quote

KEEP_DAYS = 30
VERSION = 1


def folder() -> Path:
    """Where each league's newest futures read is kept."""
    return home() / "oddsapi" / "futures"


def _private(path: Path) -> None:
    try:
        os.chmod(path, 0o700 if path.is_dir() else 0o600)
    except OSError:
        pass


def record(where: Path, *, alias: str, key: str, fetched_at: float, regions, question: str,
           markets, names: dict) -> bool:
    """Write one league's read. Returns whether it was written.

    Never raises: a store that cannot be written costs the reopened view, and must not cost
    the person the read they just paid for. An older read never replaces a newer one, so a
    slow second window cannot put yesterday's prices back.
    """
    try:
        where = Path(where)
        where.mkdir(parents=True, exist_ok=True)
        _private(where.parent)
        _private(where)
        path = where / f"{alias}.json"
        try:
            kept = json.loads(path.read_text())
            if float(kept["fetched_at"]) > fetched_at:
                return False
        except (OSError, ValueError, KeyError, TypeError):
            pass
        used = {q.book for m in markets for q in m.quotes}
        body = {
            "v": VERSION, "alias": alias, "key": key, "fetched_at": fetched_at,
            "regions": list(regions), "question": question,
            "markets": [{"event": str(m.event_id),
                         "q": [[q.book, q.outcome.name, round(q.decimal, 4), q.seen_at] for q in m.quotes]}
                        for m in markets],
            "names": {b: names[b] for b in sorted(used) if b in names},
        }
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(body, separators=(",", ":")))
        _private(tmp)
        os.replace(tmp, path)
        _prune(where, fetched_at)
        return True
    except OSError:
        return False


def _prune(where: Path, now: float) -> None:
    for f in where.glob("*.json"):
        try:
            if now - float(json.loads(f.read_text())["fetched_at"]) > KEEP_DAYS * 86400:
                f.unlink()
        except (OSError, ValueError, KeyError, TypeError):
            pass


def load(where: Path) -> list:
    """Every kept read, one per league, in no particular order. Reads files only."""
    out = []
    try:
        files = sorted(Path(where).glob("*.json"))
    except OSError:
        return out
    for f in files:
        try:
            rec = json.loads(f.read_text())
            if rec.get("v") != VERSION or not isinstance(rec.get("markets"), list):
                continue
            float(rec["fetched_at"])
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            continue
        out.append(rec)
    return out


def to_markets(rec: dict) -> list:
    """The engine's own Market objects for one kept read."""
    out = []
    for m in rec["markets"]:
        quotes = [Quote(book=b, outcome=Outcome(name=n), decimal=float(d), seen_at=float(s),
                        fetched_at=float(rec["fetched_at"]))
                  for b, n, d, s in m["q"]]
        out.append(Market(event_id=m["event"], sport=rec["key"], market_type="outrights", quotes=quotes))
    return out


def clear(where: Path) -> int:
    n = 0
    try:
        for f in Path(where).glob("*.json"):
            f.unlink()
            n += 1
        shutil.rmtree(where, ignore_errors=True)
    except OSError:
        pass
    return n
