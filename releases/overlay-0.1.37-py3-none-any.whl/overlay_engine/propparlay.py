"""Player-prop parlays: every yardage and receptions leg a book posts, priced, then built into parlays.

How a leg is priced. Each book's main over/under on a player (say 236.5 passing yards) is taken with the margin
removed, and that is the centre: it already holds the matchup, the usage, the injury news and the weather, so nothing
here adds them twice. Around the centre goes the shape of how NFL starters actually land against a projection, from
every regular-season game 2019-2025 (data/prop_shapes.json): yards cannot go under zero and have a long right tail,
which a normal curve gets wrong, and it is in the far rungs of an alternate ladder ("150+") that the gap shows. The
fair chance of each rung is read off that shape, and every price a book licensed in the person's state posts on it is
set against the fair chance.

How parlays are built, from what the record and the 2019-2025 games showed:
  * one game per same-game parlay, and never the same leg on two tickets (sharing legs wiped the whole day 67% of
    the time in replayed weeks, against 30% with each ticket on its own game);
  * a QB stacked with his own wide receivers and tight ends (those legs land together 9% more often than apart);
  * 3 to 6 legs, each with the best price at a licensed book.

What it cannot see. A same-game parlay's price is set by the book's own model and no feed carries it, so for those
the builder says the fair price and the shortest price worth taking; the person compares it with the book's number.
A parlay across games at one book is priced exactly. Anytime-touchdown props are left out: books post only the yes
side, so a fair price cannot be taken from them.
"""
from __future__ import annotations

import bisect
import json
import os
import re
import time
import unicodedata
from dataclasses import dataclass, field
from functools import lru_cache
from itertools import combinations
from pathlib import Path

from .feed import FeedError
from .oddsapi import (ENGINE_KEY, PROPS_COST_RULE, PROPS_COST_RULE_SOURCE, REGIONS, Cache, OddsApiError, _pick,
                      _problem, bettable_in)
from .restfeed import read_quota

COST_RULE, COST_RULE_SOURCE = PROPS_COST_RULE, PROPS_COST_RULE_SOURCE
SOURCE = "https://the-odds-api.com/sports-odds-data/betting-markets.html (player props and _alternate, read 2026-10-12)"
LEAGUE_KEY = "americanfootball_nfl"

#: Odds API market key -> the stat it is about. A main market is a two-way over/under at one line; an alternate is
#: the "X+" ladder, an over at each rung.
MAIN = {"player_pass_yds": "passing_yards", "player_rush_yds": "rushing_yards",
        "player_reception_yds": "receiving_yards", "player_receptions": "receptions"}
ALTERNATE = {k + "_alternate": v for k, v in MAIN.items()}
MARKETS = {**MAIN, **ALTERNATE}
DEFAULT_MARKETS = tuple(MARKETS)
DEFAULT_REGIONS = ("us",)
STAT_LABEL = {"passing_yards": "passing yards", "rushing_yards": "rushing yards",
              "receiving_yards": "receiving yards", "receptions": "receptions"}
KEEP_DAYS = 2                      # props are for one game day; an older read is not offered as current
_EVENT_ID = re.compile(r"[A-Za-z0-9]{8,64}")

MIN_LEG_CHANCE = 0.55              # a leg below this is a longshot, not a parlay building block
MIN_TICKET_CHANCE = 0.12           # same-game tickets are kept to ones that land at least this often
LEGS = range(3, 7)


# ---------------------------------------------------------------- the shape

@dataclass(frozen=True)
class Shape:
    """Quantiles of (what a starter did) / (his projection). `above(x)` is the chance the ratio beats x."""

    q: tuple

    def above(self, x: float) -> float:
        q = self.q
        if x < q[0]:
            return 1.0
        if x >= q[-1]:
            return 0.0
        i = bisect.bisect_right(q, x) - 1
        span = q[i + 1] - q[i]
        frac = (x - q[i]) / span if span > 0 else 1.0
        return max(0.0, min(1.0, 1.0 - (i + frac) / 100.0))

    def at(self, p: float) -> float:
        """The ratio the starter beats with chance p."""
        t = min(100.0, max(0.0, (1.0 - p) * 100.0))
        i = int(t)
        if i >= 100:
            return self.q[100]
        return self.q[i] + (self.q[i + 1] - self.q[i]) * (t - i)


@lru_cache(maxsize=1)
def shapes() -> dict:
    data = json.loads((Path(__file__).parent / "data" / "prop_shapes.json").read_text())
    return {"shapes": {k: Shape(tuple(v["quantiles"])) for k, v in data["markets"].items()},
            "lift": float(data["lift"]["qb_own_pass_catcher"]["value"]), "source": data["source"]}


# ---------------------------------------------------------------- what reading costs, and the read

@dataclass(frozen=True)
class Estimate:
    event_ids: tuple
    markets: tuple
    regions: tuple

    @property
    def credits(self) -> int:
        # THE RULE: unique markets returned x regions, once per game; an upper bound said before anything is read.
        return len(self.event_ids) * len(self.markets) * len(self.regions)

    def sentence(self) -> str:
        n, g = self.credits, len(self.event_ids)
        return (f"Reading player props for {g} game{'s' if g != 1 else ''} costs up to {n} credits from your Odds API "
                f"allowance: {len(self.markets)} markets x {len(self.regions)} region{'s' if len(self.regions) != 1 else ''}"
                f" x {g} game{'s' if g != 1 else ''}. A market no book posts is not charged. Nothing is read until you "
                f"press Read.")

    def as_dict(self) -> dict:
        return {"event_ids": list(self.event_ids), "markets": list(self.markets), "regions": list(self.regions),
                "credits": self.credits, "sentence": self.sentence(), "rule": COST_RULE,
                "rule_source": COST_RULE_SOURCE, "source": SOURCE}


def estimate(event_ids, markets=None, regions=None) -> Estimate:
    ids = tuple(dict.fromkeys(str(e).strip() for e in (event_ids or []) if str(e).strip()))
    if not ids:
        raise OddsApiError("Pick at least one game.", reason="bad_choice")
    for e in ids:
        if not _EVENT_ID.fullmatch(e):
            raise OddsApiError("A game's id is missing or is not one the Odds API uses. Pick games from the list.",
                               reason="bad_choice")
    return Estimate(ids, _pick(markets, MARKETS, "player prop market", DEFAULT_MARKETS),
                    _pick(regions, REGIONS, "region", DEFAULT_REGIONS))


@dataclass
class Read:
    estimate: Estimate
    games: list = field(default_factory=list)     # one Odds API event-odds payload per game
    fetched_at: float = 0.0
    credits: int | None = None
    remaining: int | None = None
    warning: str = ""


def read(est: Estimate, key: str, *, clock=None, cache: Cache | None = None, fetcher=None,
         remaining: int | None = None) -> Read:
    """Ask the Odds API for each chosen game's props, once each. Raises OddsApiError with a sentence, never the key.
    A read that could cost more than the credits left is refused before any request."""
    from .oddsapi import odds_api_fetcher
    clock = clock or time.time
    cache = cache or Cache()
    if remaining is not None and remaining < est.credits:
        raise OddsApiError(f"Reading these games' player props needs up to {est.credits} credits and you have "
                           f"{remaining} left this month.", reason="credits")
    fetcher = fetcher or odds_api_fetcher()
    out = Read(est, fetched_at=clock())
    spent = 0
    for event in est.event_ids:
        tag = f"props/{LEAGUE_KEY}/{event}"
        entry = cache.get(tag, est.regions, est.markets, clock())
        if entry is not None:
            out.games.append(entry.payload[0])
            continue
        got_at = clock()
        try:
            payload, headers = fetcher(f"/v4/sports/{LEAGUE_KEY}/events/{event}/odds",
                                       {"apiKey": key, "regions": ",".join(est.regions),
                                        "markets": ",".join(est.markets), "oddsFormat": "decimal",
                                        "dateFormat": "iso"})
            if not isinstance(payload, dict) or not isinstance(payload.get("bookmakers", []), list):
                raise FeedError("expected one game with a list of bookmakers")
        except Exception as exc:                     # noqa: BLE001
            raise _problem(exc, "this game's player props") from None
        cache.put(tag, est.regions, est.markets, [payload], headers, got_at)
        quota = read_quota(headers)
        cache.remember(quota, got_at)
        spent += quota.last or 0
        out.remaining = quota.remaining
        out.games.append(payload)
    out.credits = spent
    if spent > est.credits:
        out.warning = (f"The Odds API charged {spent} credits for these props, and Bookbreaker's count allows "
                       f"{est.credits}. Check for a newer Bookbreaker before reading more.")
    save(out)
    return out


def folder() -> Path:
    from .ledger import home
    return home() / "oddsapi" / "props"


def save(got: Read, where: Path | None = None) -> bool:
    """Keep the read so the parlays reopen for nothing. Never raises."""
    try:
        where = Path(where or folder())
        where.mkdir(parents=True, exist_ok=True)
        for d in (where.parent, where):
            os.chmod(d, 0o700)
        path = where / "latest.json"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"event_ids": list(got.estimate.event_ids), "markets": list(got.estimate.markets),
                                   "regions": list(got.estimate.regions), "fetched_at": got.fetched_at,
                                   "games": got.games}))
        os.chmod(tmp, 0o600)
        tmp.replace(path)
        return True
    except (OSError, TypeError, ValueError):
        return False


def load(where: Path | None = None, now: float | None = None) -> Read | None:
    now = time.time() if now is None else now
    try:
        data = json.loads((Path(where or folder()) / "latest.json").read_text())
        if now - float(data["fetched_at"]) > KEEP_DAYS * 86400:
            return None
        est = Estimate(tuple(data["event_ids"]), tuple(data["markets"]), tuple(data["regions"]))
        return Read(est, list(data["games"]), float(data["fetched_at"]))
    except (OSError, ValueError, KeyError, TypeError):
        return None


# ---------------------------------------------------------------- pricing every leg

def _norm(name: str) -> str:
    s = unicodedata.normalize("NFKD", name or "").encode("ascii", "ignore").decode().lower()
    s = re.sub(r"[^a-z ]", "", s.replace("-", " ").replace(".", ""))
    return " ".join(w for w in s.split() if w not in ("jr", "sr", "ii", "iii", "iv", "v"))


@dataclass
class Leg:
    game: str
    event_id: str
    player: str
    stat: str
    point: float
    fair: float                    # chance it lands
    best: float                    # best decimal price at a licensed book
    books: list                    # who has the best price
    prices: dict                   # every licensed book's decimal price on it
    team: str = ""
    pos: str = ""
    red: list = field(default_factory=list)     # reasons to keep it off a ticket
    green: list = field(default_factory=list)   # reasons it lands more often than its peers

    @property
    def ev(self) -> float:
        return self.fair * self.best - 1.0

    @property
    def label(self) -> str:
        n = int(self.point + 0.5)
        return f"{self.player} {n}+ {STAT_LABEL[self.stat]}"

    def as_dict(self) -> dict:
        return {"game": self.game, "player": self.player, "stat": self.stat, "point": self.point, "label": self.label,
                "fair": round(self.fair, 4), "fair_american": american(1 / self.fair) if 0 < self.fair < 1 else None,
                "best": round(self.best, 3), "best_american": american(self.best), "books": self.books,
                "ev": round(self.ev, 4), "margin": round(1 - self.fair * self.best, 4),
                "team": self.team, "pos": self.pos, "red": self.red, "green": self.green,
                "prices": {b: american(d) for b, d in sorted(self.prices.items())}}


def american(decimal: float) -> int:
    return int(round((decimal - 1) * 100)) if decimal >= 2 else int(round(-100 / (decimal - 1)))


def _game_name(g: dict) -> str:
    return f"{g.get('away_team', '?')} @ {g.get('home_team', '?')}"


def legs(read_: Read, state: str | None = None, teams: dict | None = None, context: dict | None = None) -> list:
    """Every alternate and main over a licensed book posts, with its fair chance. `teams` maps a player's normalised
    name to (team, position) when nflverse data is on this Mac; without it no stack is credited."""
    sh = shapes()["shapes"]
    licensed = bettable_in(state)
    teams = teams or {}
    out = []
    for g in read_.games:
        mains, overs = {}, {}
        for bm in g.get("bookmakers", []):
            book = ENGINE_KEY.get(bm.get("key", ""), bm.get("key", ""))
            for m in bm.get("markets", []):
                stat = MARKETS.get(m.get("key", ""))
                if not stat:
                    continue
                pair = {}
                for o in m.get("outcomes", []):
                    who, pt, price = o.get("description"), o.get("point"), o.get("price")
                    if not who or pt is None or not price or price <= 1:
                        continue
                    side = str(o.get("name", "")).lower()
                    if side == "over":
                        overs.setdefault((who, stat, float(pt)), {})[book] = float(price)
                        if m["key"] in MAIN:
                            pair.setdefault((who, float(pt)), {})["o"] = float(price)
                    elif side == "under" and m["key"] in MAIN:
                        pair.setdefault((who, float(pt)), {})["u"] = float(price)
                for (who, pt), ou in pair.items():
                    if "o" in ou and "u" in ou:
                        po = (1 / ou["o"]) / (1 / ou["o"] + 1 / ou["u"])
                        mains.setdefault((who, stat), []).append(pt / max(1e-6, sh[stat].at(po)))
        for (who, stat, pt), prices in overs.items():
            scales = mains.get((who, stat))
            if not scales:
                continue                              # no two-way main line anywhere: no centre, no fair price
            scales.sort()
            c = scales[len(scales) // 2]
            fair = sh[stat].above(pt / c) if c > 0 else 0.0
            ours = {b: d for b, d in prices.items() if b in licensed}
            if not ours or not 0 < fair < 1:
                continue
            best = max(ours.values())
            team, pos = teams.get(_norm(who), ("", ""))
            leg = Leg(_game_name(g), g.get("id", ""), who, stat, pt, fair, best,
                      sorted(b for b, d in ours.items() if d == best), ours, team, pos)
            if context:
                leg.red, leg.green = flag(leg, context.get(_norm(who)))
            out.append(leg)
    out.sort(key=lambda x: -x.ev)
    return out


# ---------------------------------------------------------------- building parlays

def _joint(ls: list, lift: float) -> float:
    p = 1.0
    for x in ls:
        p *= x.fair
    qbs = {x.team for x in ls if x.stat == "passing_yards" and x.team}
    stacked = sum(1 for x in ls if x.team in qbs and x.stat in ("receiving_yards", "receptions") and x.pos in ("WR", "TE"))
    return min(1.0, p * lift ** stacked)


def same_game(leg_list: list, lift: float | None = None, book: str | None = None) -> list:
    """The best same-game parlay of 3 to 6 legs for each game: one rung per player and stat (the one with the smallest margin),
    legs that land at least MIN_LEG_CHANCE, ranked by value, stacks credited."""
    lift = shapes()["lift"] if lift is None else lift
    by_game = {}
    for x in leg_list:
        if x.fair < MIN_LEG_CHANCE or (book and book not in x.prices) or x.red:
            continue
        k = (x.player, x.stat)
        cur = by_game.setdefault(x.game, {}).get(k)
        if cur is None or x.ev > cur.ev:
            by_game[x.game][k] = x
    tickets = []
    for game, picks in by_game.items():
        pool = sorted(picks.values(), key=lambda x: -x.ev)[:10]
        best = None
        for n in LEGS:
            for combo in combinations(pool, n):
                if len({x.player for x in combo}) < n:
                    continue                            # one leg per player keeps a single bad day from taking two
                joint = _joint(list(combo), lift)
                if joint < MIN_TICKET_CHANCE:
                    continue
                paid = 1.0
                for x in combo:
                    paid *= (x.prices[book] if book else x.best)
                value = joint * paid - 1.0              # if the book paid the legs multiplied; an SGP pays less
                if best is None or value > best[0]:
                    best = (value, combo, joint, paid)
        if best:
            value, combo, joint, paid = best
            qbs = {x.team: x.player for x in combo if x.stat == "passing_yards" and x.team}
            pairs = [f"{qbs[x.team]} and {x.player}" for x in combo
                     if x.team in qbs and x.stat in ("receiving_yards", "receptions") and x.pos in ("WR", "TE")]
            tickets.append({"kind": "same game", "game": game, "legs": [x.as_dict() for x in combo],
                            "chance": round(joint, 4), "fair_american": american(1 / joint),
                            "take_at_or_longer": american(1 / joint),
                            "legs_multiplied_american": american(paid), "value_if_paid_multiplied": round(value, 4),
                            # what the ticket costs against its fair price if the book paid the legs multiplied; a
                            # same-game price is usually shorter, so the real cost is at least this
                            "cost_vs_fair": round(1 - joint * paid, 4),
                            "correlated": pairs,
                            "correlation_note": ("These legs move together. A same-game parlay prices that in its own "
                                                 "number, usually shorter than the legs multiplied; a regular parlay will "
                                                 "not take two legs from one game.") if pairs else "",
                            "keys": [(x.player, x.stat, x.point) for x in combo]})
    tickets.sort(key=lambda t: -t["value_if_paid_multiplied"])
    return tickets


def across_games(leg_list: list, book: str, legs_n: int = 3) -> dict | None:
    """A regular parlay at one book, one leg per game: priced exactly, as the legs multiplied."""
    best = {}
    for x in leg_list:
        if book in x.prices and x.fair >= MIN_LEG_CHANCE:
            ev = x.fair * x.prices[book] - 1
            if x.game not in best or ev > best[x.game][0]:
                best[x.game] = (ev, x)
    picks = [x for ev, x in sorted(best.values(), key=lambda t: -t[0]) if ev > 0][:legs_n]
    if len(picks) < 2:
        return None
    chance, paid = 1.0, 1.0
    for x in picks:
        chance *= x.fair
        paid *= x.prices[book]
    return {"kind": "across games", "book": book, "legs": [x.as_dict() for x in picks], "chance": round(chance, 4),
            "price_american": american(paid), "fair_american": american(1 / chance), "ev": round(chance * paid - 1, 4),
            "cost_vs_fair": round(1 - chance * paid, 4),
            "keys": [(x.player, x.stat, x.point) for x in picks]}


def day_plan(tickets: list, n: int = 5, stake: float = 50.0) -> dict:
    """Up to n same-game tickets on different games with no leg on two tickets; the steadiest gets the most."""
    chosen, used = [], set()
    for t in tickets:
        keys = {tuple(k) for k in t["keys"]}
        if t["game"] in {c["game"] for c in chosen} or keys & used:
            continue
        chosen.append(t)
        used |= keys
        if len(chosen) == n:
            break
    if not chosen:
        return {"tickets": [], "note": "No game had enough legs that land often enough to build a ticket."}
    anchor = max(chosen, key=lambda t: t["chance"])
    rest = [t for t in chosen if t is not anchor]
    a_share = 0.4 if rest else 1.0
    plan = [dict(anchor, stake=round(stake * a_share, 2), role="anchor")]
    plan += [dict(t, stake=round(stake * (1 - a_share) / len(rest), 2), role="") for t in rest]
    none = 1.0
    for t in plan:
        none *= 1 - t["chance"]
    return {"tickets": plan, "chance_at_least_one": round(1 - none, 4), "stake": stake,
            "note": ("Each ticket is a different game and no leg is on two tickets, so one bad leg costs one ticket. "
                     "A parlay charges the book's margin once for every leg, so it costs more than the same legs bet "
                     "singly unless the price beats the fair price shown. A same-game ticket only beats the fair "
                     "price at the price shown or longer. Below that it costs you money on average.")}


def build(read_: Read, state: str | None = None, book: str | None = None, tickets: int = 5, stake: float = 50.0,
          teams: dict | None = None, context: dict | None = None) -> dict:
    if context and not teams:
        teams = {k: (v["team"], v["pos"]) for k, v in context.items()}
    ls = legs(read_, state, teams, context)
    sg = same_game(ls, book=book)
    cross = across_games(ls, book) if book else None
    return texts({"state": state, "book": book, "fetched_at": read_.fetched_at, "legs": [x.as_dict() for x in ls[:40]],
            "value_legs": sum(1 for x in ls if x.ev > 0), "all_legs": len(ls), "same_game": sg,
            "kept_off": sum(1 for x in ls if x.red), "flagged": bool(context),
            "across_games": cross, "plan": day_plan(sg, tickets, stake), "stacked": bool(teams),
            "shape_source": shapes()["source"],
            "note": ("Fair chances are the books' own main lines with the margin removed, spread by how NFL starters "
                     "landed against their projection in every game 2019-2025. Prices are as read; check each one at "
                     "the book before you bet. A ticket lands only if every leg does.")})


def teams_from_nflverse() -> dict:
    """Player -> (team, position) from the newest season of nflverse data on this Mac, or {} when there is none."""
    try:
        from . import nflverse
        if not nflverse.have_data():
            return {}
        rows = nflverse.read_weekly()
    except Exception:                                # noqa: BLE001
        return {}
    out = {}
    for r in rows:                                   # oldest first, so the newest team wins
        out[_norm(r["name"])] = (r["team"], r["pos"])
    return out


def upcoming_games(key: str, *, clock=None, cache: Cache | None = None, fetcher=None, days: float = 7.0) -> list:
    """This week's NFL games, soonest first, from the Odds API's games list. That call is free: it does not count
    against the allowance (https://the-odds-api.com/liveapi/guides/v4/, GET events)."""
    from .oddsapi import odds_api_fetcher
    from .restfeed import parse_time
    clock = clock or time.time
    cache = cache or Cache()
    listed = cache.get(f"{LEAGUE_KEY}/events", (), (), clock())
    if listed is not None:
        games = listed.payload
    else:
        fetcher = fetcher or odds_api_fetcher()
        try:
            games, _ = fetcher(f"/v4/sports/{LEAGUE_KEY}/events", {"apiKey": key, "dateFormat": "iso"})
            if not isinstance(games, list):
                raise FeedError("expected a list of games")
        except Exception as exc:                     # noqa: BLE001
            raise _problem(exc, "this week's NFL games") from None
        cache.put(f"{LEAGUE_KEY}/events", (), (), games, {}, clock())
    now, out = clock(), []
    for g in games:
        try:
            start = parse_time(g["commence_time"])
        except (KeyError, TypeError, FeedError):
            continue
        if now < start < now + days * 86400:
            out.append({"id": str(g["id"]), "game": _game_name(g), "start": start})
    out.sort(key=lambda g: g["start"])
    return out


# ---------------------------------------------------------------- flags from the record and the injury report

#: What moved a leg's hit rate against peers set the same distance under their average, in every NFL starter's game
#: 2019-2026 (nflverse stats, injury reports and depth charts): listed Questionable -6 to -9 points; usage falling over
#: the last two games -3 to -7; a high-target teammate Out or Doubtful +4 to +5 on receptions and rushing; a line also
#: 20%+ under last season's average 70% against 50%. The books' main lines already move for news, so these are not
#: added to the fair price: a red flag keeps a leg off every ticket, a green one is shown.
STAT_USE = {"passing_yards": "attempts", "rushing_yards": "carries", "receiving_yards": "targets", "receptions": "targets"}
STAT_COL = {"passing_yards": "passing_yards", "rushing_yards": "rushing_yards", "receiving_yards": "receiving_yards",
            "receptions": "receptions"}


def flag(leg: Leg, info: dict | None) -> tuple:
    if not info:
        return [], []
    red, green = [], []
    if info.get("status") in ("Questionable", "Doubtful", "Out"):
        red.append(f"listed {info['status']} this week")
    use = STAT_USE[leg.stat]
    u_all, u_last = info["use"].get(use), info["use_last2"].get(use)
    if u_all and u_last is not None and u_last < 0.85 * u_all:
        red.append("his usage fell over the last two games")
    avg, last = info["avg"].get(STAT_COL[leg.stat]), info["last_season"].get(STAT_COL[leg.stat])
    if avg and leg.point > 0 and (avg - leg.point) / leg.point >= 0.2 and last and (last - leg.point) / leg.point >= 0.2:
        green.append("the line is 20%+ under his average this season and last")
    if info.get("mate_out") and leg.stat in ("receptions", "receiving_yards", "rushing_yards"):
        green.append(f"{info['mate_out']} is listed out, so his targets go elsewhere")
    return red, green


def context_from_nflverse() -> dict:
    """Each player's averages this season and last, usage over his last two games, his injury tag this week and any
    high-target teammate listed out, from the nflverse data on this Mac. {} when there is none."""
    try:
        from . import nflverse
        if not nflverse.have_data():
            return {}
        rows = nflverse.read_weekly()
        injuries = nflverse.read_injuries()
    except Exception:                                # noqa: BLE001
        return {}
    if not rows:
        return {}
    season = max(r["season"] for r in rows)
    by = {}
    for r in rows:
        if r["season"] in (season, season - 1):
            by.setdefault(_norm(r["name"]), []).append(r)
    week_now = max((i["week"] for i in injuries), default=0)
    status = {_norm(i["name"]): i["status"] for i in injuries if i["week"] == week_now}
    share = {}
    out = {}
    for name, rs in by.items():
        cur = [r for r in rs if r["season"] == season]
        prev = [r for r in rs if r["season"] == season - 1]
        if not cur:
            continue
        last2 = cur[-2:]
        def mean(xs, k):
            v = [x.get(k, 0.0) for x in xs]
            return sum(v) / len(v) if v else None
        info = {"team": cur[-1]["team"], "pos": cur[-1]["pos"], "status": status.get(name, ""),
                "avg": {k: mean(cur, k) for k in STAT_COL.values()},
                "last_season": {k: mean(prev, k) if len(prev) >= 6 else None for k in STAT_COL.values()},
                "use": {k: mean(cur, k) for k in ("attempts", "carries", "targets")},
                "use_last2": {k: mean(last2, k) for k in ("attempts", "carries", "targets")} if len(cur) >= 4 else {},
                "mate_out": ""}
        out[name] = info
        share.setdefault(info["team"], []).append((info["use"].get("targets") or 0.0, name))
    for team, players in share.items():
        hurt = [n for t, n in sorted(players, reverse=True)[:4] if out[n]["status"] in ("Out", "Doubtful")]
        if hurt:
            for t, n in players:
                if n not in hurt:
                    out[n]["mate_out"] = by[hurt[0]][-1]["name"]
    return out


# ---------------------------------------------------------------- words for the window (it does no arithmetic)

def _pct(x: float) -> str:
    return f"{x * 100:+.1f}%"


def texts(view: dict) -> dict:
    """The same view with every figure the window shows already written as text."""
    for x in view.get("legs", []):
        x["fair_text"] = f"{x['fair_american']:+d}" if x.get("fair_american") is not None else "no fair price"
        x["best_text"] = f"{x['best_american']:+d} at {', '.join(x['books'])}"
        x["value_text"] = _pct(x["ev"])
        x["chance_text"] = f"{x['fair'] * 100:.0f}%"
    for t in view.get("same_game", []):
        t["chance_text"] = f"{t['chance'] * 100:.0f}%"
        t["fair_text"] = f"{t['fair_american']:+d}"
        t["paid_text"] = f"{t['legs_multiplied_american']:+d}"
        t["cost_text"] = _pct(t["cost_vs_fair"])
        t["take_text"] = f"{t['take_at_or_longer']:+d}"
        for x in t["legs"]:
            x["chance_text"] = f"{x['fair'] * 100:.0f}%"
    c = view.get("across_games")
    if c:
        c["chance_text"] = f"{c['chance'] * 100:.0f}%"
        c["price_text"] = f"{c['price_american']:+d}"
        c["fair_text"] = f"{c['fair_american']:+d}"
        c["cost_text"] = _pct(c["cost_vs_fair"])
    plan = view.get("plan", {})
    for t in plan.get("tickets", []):
        t["stake_text"] = f"{t['stake']:.2f}"
        t["chance_text"] = f"{t['chance'] * 100:.0f}%"
    if plan.get("chance_at_least_one") is not None:
        plan["at_least_one_text"] = f"{plan['chance_at_least_one'] * 100:.0f}%"
    return view
