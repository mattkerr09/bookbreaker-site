"""The Recommended preset: a safe default for the board.

The biggest number on a board is most often the least trustworthy one: a player
prop on a thin market, a +1200 longshot a book priced carelessly, a price with
fifteen dollars behind it, a market so wide that two sharp books would disagree
by more than the edge. Recommended hides those plays until the person says they
want them, so the first thing a new bettor sees is the kind of play that mostly
holds up.

**It flags and never deletes.** The engine marks every row `recommended` or not,
with the reasons it was not, and sends all of them. The window then shows or
hides rows by that flag, so switching the preset off again re-draws what is
already on screen: it does not ask the engine for a second read, and a read of
live sportsbook odds spends the person's credits. A preset that needed a new
read to turn off would be a preset nobody could afford to look past.

**A number that is not known passes.** A sportsbook's price carries no amount
on offer, and a market priced by one book has no width to speak of. A rule that
cannot be applied is not a reason to hide a play (the same rule the books that
publish no size follow elsewhere), and a row is marked down only for a fact the
engine has.

The four rules are constants with tests, and the sentence that explains them is
the engine's, so the window never words a rule of its own.
"""

from __future__ import annotations

import math
from statistics import median

from .odds import decimal_to_american

NAME = "Recommended"

#: The market types that count as main: the three a bettor reads off a
#: scoreboard, as the feed names them (`moneyline` is what Kalshi and Polymarket
#: US pairs are). Everything else (props, alternate lines, a quarter or a half,
#: futures) is opt-in. An exact allow-list and not a guess from the name, so a
#: market type this version has never heard of, and `h2h_q1`, are not
#: recommended by default.
MAIN_MARKETS = ("h2h", "spreads", "totals", "moneyline")

#: The least that must be on offer at a price, in dollars, where the venue says.
MIN_ON_OFFER = 100.0

#: The longest price a leg may have, as an American price: +300 is 4.00 in
#: decimal. Past it a devigged "fair price" is the shakiest number on the board.
MAX_AMERICAN = 300

#: The widest a two-sided market may be, in cents of line: -110 / -110 is 20,
#: -120 / -120 is 40. See `width_cents`.
MAX_WIDTH_CENTS = 40

RULES = [
    "Main markets only: moneylines, spreads and totals.",
    f"No leg priced longer than +{MAX_AMERICAN}.",
    f"At least ${MIN_ON_OFFER:,.0f} on offer, where the venue says how much.",
    f"No market wider than {MAX_WIDTH_CENTS} cents, where the engine can tell.",
]

WHY = ("Recommended is on because the biggest number on a board is usually a prop, a longshot or a thin market "
       "that moved first, and those are the plays that most often turn out not to be there.")

#: The reason codes, and what each is called when the window counts them.
LABELS = {
    "market": "not a main market",
    "price": f"priced longer than +{MAX_AMERICAN}",
    "size": f"under ${MIN_ON_OFFER:,.0f} on offer",
    "width": f"in a market wider than {MAX_WIDTH_CENTS} cents",
}


def _american(decimal: float) -> float:
    return decimal_to_american(decimal)


def width_cents(decimal_a: float, decimal_b: float) -> float:
    """How wide a two-sided market is, in cents of line.

    The gap between the two sides across even money, the way a bettor says a
    "dime line": -110 / -110 is a 20-cent line, +105 / -125 is 20, -120 / +100
    is 20. Each price is placed on a line where even money is 0 (+105 sits at
    +5, -110 at -10) and the width is how far the two sit below it together.
    A market priced -110 / -110 and one priced -140 / +100 are the same width
    to the cent, which is why this is the number and not the hold: it is what a
    bettor sees by looking at the two prices.
    """
    def place(a: float) -> float:
        return a - 100.0 if a > 0 else 100.0 + a

    return -(place(_american(decimal_a)) + place(_american(decimal_b)))


def market_width(market) -> float | None:
    """The market's width in cents: the middle of what the books that quote both
    sides of it say. None when the engine cannot tell (not two sides, or no book
    quotes both)."""
    outcomes = market.outcomes()
    if len(outcomes) != 2:
        return None
    widths = []
    for book in market.complete_books():
        quotes = market.by_book(book)
        widths.append(width_cents(quotes[outcomes[0]].decimal, quotes[outcomes[1]].decimal))
    return round(median(widths), 1) if widths else None


def _signed(american: float) -> str:
    return f"+{american:.0f}" if american > 0 else f"{american:.0f}"


def misses(market_type: str, decimals: list, on_offer: list | None = None, width: float | None = None) -> list:
    """Every reason one play is not recommended; empty when it is.

    `decimals` are the prices of the play's legs. `on_offer` is the dollars
    resting at each leg's price, None for a leg whose venue does not say.
    """
    out = []
    if market_type not in MAIN_MARKETS:
        out.append({"code": "market", "text": "It is not a main market: Recommended keeps moneylines, spreads "
                                              "and totals."})
    # A price at or below 1.00 is not a price (a contract at 100 cents): it is not a longshot either.
    longest = max((_american(d) for d in decimals if d > 1.0), default=None)
    if longest is not None and longest > MAX_AMERICAN:
        out.append({"code": "price", "text": f"A leg is priced at {_signed(longest)}, longer than the "
                                             f"+{MAX_AMERICAN} Recommended allows."})
    known = [x for x in (on_offer or []) if x is not None]
    if known and min(known) < MIN_ON_OFFER:
        # Rounded down, so $99.99 is never printed as "$100 is under $100".
        out.append({"code": "size", "text": f"Only ${math.floor(min(known)):,} is on offer, under the "
                                            f"${MIN_ON_OFFER:,.0f} Recommended wants."})
    if width is not None and width > MAX_WIDTH_CENTS:
        out.append({"code": "width", "text": f"The market is {round(width, 1):g} cents wide, wider than the "
                                             f"{MAX_WIDTH_CENTS} Recommended allows."})
    return out


def summary(plays: list) -> dict:
    """What the preset did to a set of plays, in the engine's words.

    `plays` is each play's list of misses (empty when recommended). The window
    prints this and counts nothing of its own.
    """
    total = len(plays)
    hidden = sum(1 for m in plays if m)
    by = []
    for code, label in LABELS.items():
        n = sum(1 for m in plays if any(x["code"] == code for x in m))
        if n:
            by.append({"code": code, "label": label, "count": n})
    plays_word = f"{total} play{'s' if total != 1 else ''}"
    if not hidden:
        sentence = f"Recommended keeps all {plays_word}." if total else ""
        sentence_off = f"Recommended would keep all {plays_word}." if total else ""
    else:
        parts = "; ".join(f"{b['label']}: {b['count']}" for b in by)
        more = " A play can fall under more than one." if sum(b["count"] for b in by) > hidden else ""
        sentence = f"Recommended hides {hidden} of {plays_word} ({parts}).{more}"
        sentence_off = (f"Recommended would hide {hidden} of {plays_word} ({parts}).{more} "
                        "Those are marked, with the reason.")
    return {"name": NAME, "why": WHY, "rules": list(RULES), "total": total, "kept": total - hidden,
            "hidden": hidden, "hidden_by": by, "sentence": sentence, "sentence_off": sentence_off}
