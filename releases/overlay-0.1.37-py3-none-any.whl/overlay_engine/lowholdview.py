"""The low hold view: every two-way market on this Mac, cheapest to cover first.

`lowhold.py` prices one market you hand it. This is the same idea over the prices a
read of live sportsbook odds left on this Mac: each two-way market, covered with the
cheapest pair of books, cheapest first, with a "credit book" for the person who has
bonus money to play through at one book.

**It reads files and nothing else.** It is handed the reads that
`screen.history_reads` loaded from `~/.overlay/oddsapi/history`; it builds no fetcher,
never touches the Keychain and spends no credit, exactly as the odds screen does
(`board --feed oddsapi --screen`). A test rigs the fetcher and the key to raise.

**Cost first, and certain.** Each row says what putting the stated amount through
costs, then what the obvious way (both sides at one book) costs for the same amount.
A cost of $4.20 is $4.20 gone; a row never calls it a gain. A pair that costs less than
nothing is an arbitrage and is marked as one, with the condition every locked amount in
this app carries: it is kept only if both bets are accepted and stand.

**A credit book is where the bonus money is.** With one chosen, every row has a leg at
that book and the stated amount is what is bet there (that is what clears the
playthrough); the other leg is sized to match and sits at a different book. With none,
the amount is the total across both bets. The engine words which it is, so the window
prints the sentence and does no arithmetic.

**Only books you can bet at.** The same set the board uses (`oddsapi.BETTABLE`): a
reference book such as Pinnacle prices the market and is never a leg.
"""

from __future__ import annotations

from . import screen
from .lowhold import Pairing, Quote, _hold, best, single_book_baseline

#: Pairs costing more than this are not listed: a view of low holds that included a
#: 6% hold would be a list of ordinary bets.
MAX_HOLD = 0.03
#: Rows returned. The count that qualified is returned too.
LIMIT = 40
DEFAULT_AMOUNT = 1000.0
MAX_AMOUNT = 10_000_000.0

LOCKED_CONDITION = "if both bets are accepted and stand"

COST_MEANS = ("The cost is what the two prices' combined margin takes out of the money you put through. It is "
              "paid whichever side wins, so it is a price and not a risk. The second figure on each row is "
              "what the same amount costs with both bets at one book, so you can see whether splitting "
              "the bets across two books is cheaper.")
NOTE = ("Prices are as they were when read, and a book can change one at any moment: check both prices at the "
        "books before you bet, and if one bet is refused the other is a plain bet. Only sportsbooks you can bet "
        "at from the US are used. A cost here is the margin in the prices read, before any limit on your account.")
TOO_OLD = ("The last read of sportsbook odds on this Mac is more than six hours old, so no markets are listed: "
           "a list built on old prices looks exactly like one built on live ones. Press Live sportsbook odds on the "
           "Arbitrage page to read fresh prices.")


class LowHoldError(ValueError):
    """The question could not be answered as asked: a refusal, not a crash."""


def money(amount: float) -> str:
    """$1,234 for a whole amount, $1,234.56 for one with cents."""
    return f"${amount:,.0f}" if abs(amount - round(amount)) < 0.005 else f"${amount:,.2f}"


def pct(x: float) -> str:
    """A hold as a percentage to two places, never a negative zero."""
    v = round(x * 100.0, 2)
    return f"{(0.0 if v == 0 else v):.2f}%"


def _amount(value) -> float:
    try:
        amount = float(value)
    except (TypeError, ValueError):
        raise LowHoldError(f"{value!r} is not an amount. Type it like 1000.")
    if amount != amount or amount in (float("inf"), float("-inf")) or amount <= 0:
        raise LowHoldError("The amount has to be more than zero.")
    if amount > MAX_AMOUNT:
        raise LowHoldError(f"The amount is more than {money(MAX_AMOUNT)}. Type the amount you will actually put through.")
    return amount


def _two_way_sets(market, bettable):
    """Each two-sided set in a market: (line, [side keys], {key: [quotes]}).

    A market holds every line a book posts for a game, so a spread market has Chiefs
    -3.5 and Chiefs -2.5 side by side, and sides are grouped by the size of the line.
    A set is two-way only when its two outcomes really are opposite sides of one bet:
    over against under on one total, one team's line against the other's with the
    opposite sign, two names and no line on a moneyline. Anything else (a draw, a
    three-way price, two lines that only look alike) is left out rather than paired.
    """
    groups: dict = {}
    for q in market.quotes:
        if bettable is not None and q.book not in bettable:
            continue
        if q.decimal <= 1.0:
            continue
        line = q.outcome.line
        groups.setdefault(None if line is None else abs(line), {}).setdefault(q.outcome.key, []).append(q)
    for line, sides in groups.items():
        if len(sides) != 2:
            continue
        (ka, qa), (kb, qb) = list(sides.items())
        a, b = qa[0].outcome, qb[0].outcome
        if a.name.lower() == b.name.lower():
            continue
        if market.market_type == "totals":
            if {a.name.lower(), b.name.lower()} != {"over", "under"}:
                continue
        elif market.market_type == "spreads":
            if a.line is None or b.line is None or abs(a.line + b.line) > 1e-9:
                continue
        elif market.market_type == "h2h":
            if a.line is not None or b.line is not None:
                continue
        else:
            continue
        yield line, [ka, kb], sides


def _order_sides(keys: list, teams: tuple) -> list:
    """Over before Under; teams in the order the game's name gives them; any other
    pair keeps the order the feed gave it."""
    def rank(item):
        i, k = item
        name = screen.parse_key(k)[0]
        if name.lower() in ("over", "under"):
            return (0 if name.lower() == "over" else 1, i)
        return (2 + (teams.index(name) if name in teams else 0), i)
    return [k for _, k in sorted(enumerate(keys), key=rank)]


def _cheapest(sides: dict, keys: list, credit: str):
    """The cheapest cross-book pairing of these two sides, with a leg at `credit` when
    one is named, and the quotes it was chosen from. None when no such pairing exists."""
    quotes = []
    for k in keys:
        # One price per book per side: that book's own posted price.
        at: dict = {}
        for q in sides[k]:
            if q.book not in at or q.decimal > at[q.book].decimal:
                at[q.book] = q
        quotes += [Quote(b, k, q.decimal) for b, q in at.items()]
    found = [p for p in best(quotes, sides=keys, limit=len(quotes) ** 2 + 1)
             if len({q.book for q in p.picks}) == len(p.picks)
             and (not credit or credit in {q.book for q in p.picks})]
    if not found:
        return None
    found.sort(key=lambda p: (round(p.hold, 9), sum(screen.popular(q.book) for q in p.picks),
                              [q.book for q in p.picks]))
    return found[0], quotes


def _one_book(sides, keys, quotes, credit, amount, cost, names):
    """The obvious way, for the same amount: both sides at one book. With a credit book
    that book, and all of the amount is bet there; otherwise the cheapest single book."""
    base = None
    if credit:
        mine = [max((x for x in sides[k] if x.book == credit), key=lambda x: x.decimal, default=None) for k in keys]
        if all(mine):
            picks = [Quote(credit, k, x.decimal) for k, x in zip(keys, mine)]
            base = Pairing(picks, _hold(picks))
    else:
        base = single_book_baseline(quotes, keys)
    if base is None:
        return None
    base_cost = base.kept_back(amount)
    at = screen.book_name(base.picks[0].book, names)
    sentence = (f"At {at} alone, with both bets there, the same {money(amount)} costs about "
                f"{money(abs(base_cost))}.")
    if base_cost < cost:
        sentence += " That is less than this pair."
    return {"book": base.picks[0].book, "book_name": at, "hold": round(base.hold, 6), "hold_text": pct(base.hold),
            "cost": base_cost, "cost_text": money(abs(base_cost)), "line": sentence, "cheaper": base_cost < cost}


def _row(read, market, line, keys, sides, pairing, quotes, *, credit, amount, now, bettable):
    names = read.names
    mtype = market.market_type
    info = read.events.get(str(market.event_id), {})
    index = next((i for i, q in enumerate(pairing.picks) if q.book == credit), 0) if credit else 0
    total = pairing.total_for(index, amount) if credit else amount
    stakes = pairing.stakes(total)
    cost = pairing.kept_back(total)

    legs = []
    for q, st in zip(pairing.picks, stakes):
        orig = next(x for x in sides[q.side] if x.book == q.book)
        age = round(max(0.0, now - orig.seen_at), 1)
        also = sorted({x.book for x in sides[q.side]
                       if x.book != q.book and x.decimal == orig.decimal and (bettable is None or x.book in bettable)})
        legs.append({
            "side": q.side, "label": screen.side_label(q.side, mtype), "book": q.book,
            "book_name": screen.book_name(q.book, names), "american": screen.american(q.decimal),
            "decimal": round(q.decimal, 4), "stake": st["stake"], "returns": st["returns"],
            "age": age, "age_text": f"last confirmed {screen.ago(age)}",
            "credit": bool(credit) and q.book == credit,
            "also_at": [screen.book_name(b, names) for b in also]})

    where = f"at {screen.book_name(credit, names)}" if credit else "across both bets"
    if pairing.is_arb and cost < 0:
        cost_line = (f"Keeps about {money(-cost)} on {money(amount)} {where} {LOCKED_CONDITION}. "
                     "This is an arbitrage.")
    else:
        cost_line = f"Costs about {money(max(cost, 0.0))} to put {money(amount)} through {where}."
    return {
        "event_id": str(market.event_id), "game": info.get("label") or str(market.event_id),
        "league": read.alias, "league_label": read.label,
        "market": mtype, "market_label": screen.MARKET_LABELS.get(mtype, mtype), "line": line,
        "starts": market.starts_at, "legs": legs,
        "hold": round(pairing.hold, 6), "hold_text": pct(pairing.hold), "is_arb": bool(pairing.is_arb),
        "total": round(total, 2), "cost": cost, "cost_text": money(abs(cost)), "cost_line": cost_line,
        "one_book": _one_book(sides, keys, quotes, credit, amount, cost, names),
        "read_at": read.fetched_at,
    }


def view(reads: list, bettable, now: float, *, credit_book: str = "", amount=DEFAULT_AMOUNT,
         older: bool = False, max_hold: float = MAX_HOLD, limit: int = LIMIT,
         show_for: float = screen.SHOW_FOR) -> dict:
    """Two-way markets ranked by combined hold, from reads already on this Mac."""
    amount = _amount(amount)
    credit = str(credit_book or "").strip()
    if credit and bettable is not None and credit not in bettable:
        raise LowHoldError(f"{credit!r} is not a sportsbook this app reads prices for. Pick one from the list.")
    reads = [r for r in reads if now - r.fetched_at <= show_for]
    base = {"now": now, "credit_book": credit, "amount": amount, "max_hold": max_hold,
            "max_hold_text": pct(max_hold), "cost_means": COST_MEANS, "note": NOTE,
            "rows": [], "shown": 0, "qualifying": 0, "books": [], "under_way": 0, "warning": ""}
    if not reads:
        return {**base, "has_odds": False, "credit_name": "", "amount_text": "",
                "message": TOO_OLD if older else screen.NONE_YET}

    names_all: dict = {}
    rows, priced_books, under_way, sets_seen, credit_priced = [], set(), 0, 0, False
    for read in reads:
        names_all.update(read.names)
        for market in read.markets:
            if market.starts_at is not None and market.starts_at <= now:
                under_way += 1
                continue
            away, at, home = (read.events.get(str(market.event_id), {}).get("label") or "").partition(" at ")
            for line, keys, sides in _two_way_sets(market, bettable):
                sets_seen += 1
                keys = _order_sides(keys, (away, home) if at else ())
                for k in keys:
                    priced_books.update(q.book for q in sides[k])
                if credit and not any(q.book == credit for k in keys for q in sides[k]):
                    continue
                credit_priced = credit_priced or bool(credit)
                got = _cheapest(sides, keys, credit)
                if got is None:
                    continue
                pairing, quotes = got
                if pairing.hold > max_hold:
                    continue
                rows.append(_row(read, market, line, keys, sides, pairing, quotes, credit=credit,
                                 amount=amount, now=now, bettable=bettable))
    rows.sort(key=lambda r: (r["hold"], r["starts"] is None, r["starts"] or 0, r["game"], r["market"]))
    qualifying = len(rows)
    rows = rows[:limit]

    credit_name = screen.book_name(credit, names_all) if credit else ""
    books = sorted(({"key": b, "name": screen.book_name(b, names_all)} for b in priced_books),
                   key=lambda b: (screen.popular(b["key"]), b["name"].lower()))
    oldest = min(r.fetched_at for r in reads)
    age = round(max(0.0, now - oldest), 1)
    warning = ""
    if age > screen.OLD_AFTER:
        warning = (f"These prices were read {screen.ago(age)}. A sportsbook can change a price at any moment, so use "
                   "the list to look, and check both prices at the books before you bet.")
    if credit:
        amount_text = (f"{money(amount)} is what you bet at {credit_name}, your credit book. The other bet is "
                       f"sized to match and sits at a different book, and only the bet at {credit_name} counts "
                       "toward playing the credit through.")
    else:
        amount_text = f"{money(amount)} is the total across both bets."
    message = ""
    if not rows:
        if credit and not credit_priced:
            message = (f"{credit_name} prices none of the two-way markets in the prices read on this Mac, so "
                       "there is nothing to pair it with. Pick another credit book, or read the odds again.")
        elif sets_seen == 0:
            message = ("None of the games in the prices read on this Mac has a two-way market to cover. "
                       "Press Live sportsbook odds on the Arbitrage page to read the next ones.")
        else:
            with_book = f" with a bet at {credit_name}" if credit else ""
            message = (f"No two-way market in the prices read on this Mac can be covered for {pct(max_hold)} or less"
                       f"{with_book} right now. Reading again later, or reading more leagues, may find some.")
    return {**base, "has_odds": True, "credit_name": credit_name, "amount_text": amount_text, "books": books,
            "rows": rows, "shown": len(rows), "qualifying": qualifying, "under_way": under_way,
            "markets_considered": sets_seen, "read_at": max(r.fetched_at for r in reads), "oldest": oldest,
            "age": age, "age_text": screen.ago(age), "warning": warning, "message": message, "limit": limit}


def from_history(folder, bettable, now: float, *, credit_book: str = "", amount=DEFAULT_AMOUNT) -> dict:
    """The view from what refreshes left on this Mac. Reads files; no network, no key."""
    reads, older = screen.history_reads(folder, now)
    return view(reads, bettable, now, credit_book=credit_book, amount=amount, older=older)
