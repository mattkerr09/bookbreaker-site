"""The EV formula: the books you trust, weighted, as your own true price.

OddsJam lets a bettor say which sharp books set the "true price" a +EV bet is judged against, and how much each
counts. This is that, on the engine's own blend (`fair.fair_value`): the fair price of a market is the weighted blend
of the formula books that priced **both sides** of it, and a +EV bet is shown only when enough of the formula's weight
was actually there.

  * **Weights** are whole numbers from 0 to 10, one per book, keyed by the engine's own book key. A book counts for its
    weight over the formula's total ("2 and 1" is 66.7% and 33.3%). All zero is no formula: the engine's own tiered
    blend, exactly as before this existed.
  * **The threshold** (0 to 100%, 50 unless changed) is the share of the formula's weight that must have priced the
    market. The share present is the weight of the formula books that quoted both sides, over the total weight. 0 is
    "Any book" (one is still needed: with none there is no price) and 100 is "All books".
  * **The book you bet at is left out of its own price**, as everywhere else here. If it is one of the formula's books,
    its weight does not count as present for that bet.
  * **Only books The Odds API can send.** `BOOKS` is that list, with the region each is sent in. Circa and BookMaker are
    not in the feed (checked against the Odds API's bookmaker list), so they are not offered and the panel says so.
    Nothing is invented to fill the gap.
  * **No credit is spent.** The formula works on prices already read. A formula book in a region the person has not
    picked is simply absent, and `regions_note` says, in a sentence, what picking the region would cost. The engine
    never changes a region.

The setting is kept by the window on this Mac like the other board settings and arrives as one JSON token. It is
bounded and checked here: unknown books are dropped, weights are clamped, and text that cannot be read is no formula
with a one-line notice, never a crash.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, replace

from .fair import FairValue, fair_value
from .models import Book, BookTier

NAME = "EV formula"
MAX_WEIGHT = 10
DEFAULT_THRESHOLD = 50
STEP = 5                       # the slider's step, in percent
MAX_TEXT = 4000
MAX_SHOWN = 12                 # most extra book cards one setting may carry

#: Region keys in plain words, for the sentence about cost.
REGION_WORDS = {"us": "US", "us2": "more US", "eu": "Europe", "us_ex": "US exchanges"}


@dataclass(frozen=True)
class FormulaBook:
    key: str            # the engine's key for the book
    name: str
    regions: tuple      # the Odds API regions that send it (any one is enough)
    preset: bool = False
    note: str = ""


#: Every book a formula may use: the books The Odds API sends that this engine can tell apart. The preset cards come
#: first, in the order OddsJam shows them where the feed has them.
BOOKS: tuple = (
    FormulaBook("pinnacle", "Pinnacle", ("eu",), True, "The sharpest book in the feed, used for its prices only."),
    FormulaBook("betonlineag", "BetOnline", ("us", "eu"), True, "An offshore book, used for its prices only."),
    FormulaBook("betfair", "Betfair Exchange", ("eu",), False, "An exchange: its prices are fair odds, with commission."),
    FormulaBook("kalshi", "Kalshi", ("us_ex",), False, "A prediction market."),
    FormulaBook("polymarket", "Polymarket", ("us_ex",), False, "A prediction market."),
    FormulaBook("dk", "DraftKings", ("us",), False, "A US sportsbook."),
    FormulaBook("fd", "FanDuel", ("us",), False, "A US sportsbook."),
    FormulaBook("mgm", "BetMGM", ("us",), False, "A US sportsbook."),
)
BY_KEY = {b.key: b for b in BOOKS}

#: Books OddsJam's formula offers that The Odds API does not carry. Said in the panel, never faked.
NOT_IN_FEED = (
    {"name": "Circa", "why": "Circa is not in The Odds API, so Bookbreaker cannot read its prices and it is left out."},
    {"name": "BookMaker", "why": "BookMaker is not in The Odds API, so Bookbreaker cannot read its prices and it is left out."},
)

NOTICE_UNREADABLE = "Your saved formula could not be read, so no formula is set."
OFF_TEXT = "No formula is set, so Bookbreaker prices every bet with its own blend of books."
LOCK_TEXT = ("Recommended is on, and it prices bets with Bookbreaker's own blend of books, so your formula is paused. "
             "Turn Recommended off to use it.")
APPLY = "Press Live sportsbook odds to use it. Nothing is read until you do."
WHERE = ("The formula works on prices already read and spends no credits. It applies to +EV bets only: arbs and "
         "middles do not use a fair price.")
SHARE_WHY = ("A bet is shown only when the books that priced it add up to at least this much of your formula's "
             "weight. A market a formula book did not quote on both sides is counted as that book being absent.")


@dataclass(frozen=True)
class Formula:
    """A usable formula: positive weights only, and the threshold."""

    weights: tuple          # ((key, weight), ...) sorted by key; every weight is 1..MAX_WEIGHT
    threshold: int          # percent, 0..100

    @property
    def total(self) -> int:
        return sum(w for _, w in self.weights)

    def weight_of(self, key: str) -> int:
        return dict(self.weights).get(key, 0)

    def keys(self) -> tuple:
        return tuple(k for k, _ in self.weights)


@dataclass
class Setting:
    """What the window sent, checked. `formula` is None when there is nothing to apply."""

    weights: dict           # every known book -> 0..MAX_WEIGHT (zeros included), for the panel
    threshold: int
    shown: list             # extra book cards the person added
    notice: str = ""
    paused: bool = False    # Recommended is on, so the formula is held
    sent: bool = False      # the window sent a setting at all

    @property
    def formula(self) -> Formula | None:
        if self.paused:
            return None
        return self.built()

    def built(self) -> Formula | None:
        pos = tuple(sorted((k, w) for k, w in self.weights.items() if w > 0))
        return Formula(pos, self.threshold) if pos else None


def _number(v):
    """A finite real number, else None. A bool is not a weight."""
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        return None
    return v


def _clamp(v, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(round(v))))


def parse(text, paused: bool = False) -> Setting:
    """The window's setting, checked and bounded. Never raises.

    `text` is `{"weights": {book: 0..10}, "threshold": 0..100, "shown": [book]}` as JSON, or None for nothing sent.
    Unknown books are dropped, weights and the threshold are clamped, and anything that cannot be read at all is no
    formula with a one-line notice.
    """
    empty = Setting({b.key: 0 for b in BOOKS}, DEFAULT_THRESHOLD, [], paused=paused)
    if text is None:
        return empty
    empty.sent = True
    if not isinstance(text, str) or len(text) > MAX_TEXT:
        empty.notice = NOTICE_UNREADABLE
        return empty
    try:
        raw = json.loads(text)
    except (ValueError, RecursionError):
        empty.notice = NOTICE_UNREADABLE
        return empty
    if not isinstance(raw, dict) or not isinstance(raw.get("weights", {}), dict):
        empty.notice = NOTICE_UNREADABLE
        return empty
    dropped = 0
    weights = {b.key: 0 for b in BOOKS}
    for key, value in raw.get("weights", {}).items():
        if key not in BY_KEY:
            dropped += 1
            continue
        num = _number(value)
        if num is None:
            dropped += 1
            continue
        weights[key] = _clamp(num, 0, MAX_WEIGHT)
    threshold = DEFAULT_THRESHOLD
    if "threshold" in raw:
        num = _number(raw["threshold"])
        if num is None:
            dropped += 1
        else:
            threshold = _clamp(num, 0, 100)
    shown: list = []
    extra = raw.get("shown", [])
    if isinstance(extra, list):
        for key in extra[:MAX_SHOWN * 4]:
            if isinstance(key, str) and key in BY_KEY and key not in shown and len(shown) < MAX_SHOWN:
                shown.append(key)
            else:
                dropped += 1
    elif "shown" in raw:
        dropped += 1
    notice = ""
    if dropped:
        notice = (f"{dropped} part{'s' if dropped != 1 else ''} of your saved formula could not be used "
                  f"(a book Bookbreaker cannot read, or a value that was not a number) and "
                  f"{'was' if dropped == 1 else 'were'} left out.")
    return Setting(weights, threshold, shown, notice, paused, True)


# ------------------------------------------------------------ the arithmetic

@dataclass(frozen=True)
class Presence:
    """Which of the formula's books priced a market, and whether that is enough."""

    present: tuple          # formula books that quoted both sides, with a known price
    missing: tuple          # formula books that did not
    share: float            # weight present over total weight, 0..1
    threshold: float        # 0..1
    meets: bool
    left_out: str | None    # the book bet at, left out of its own price


def meets(share: float, threshold_pct: int) -> bool:
    """Whether a share reaches a threshold. A hair of tolerance so 2 of 3 reaches 66.7% and 1 of 3 reaches 33%."""
    return share + 1e-9 >= threshold_pct / 100.0


def blended(market, books: dict, formula: Formula, method_weights=None, left_out: str | None = None):
    """`(fair values by outcome, Presence)` for one market under a formula.

    The fair values are the engine's own blend (`fair.fair_value`, in log-odds) over the formula books only, weighted
    by the formula; every other book is given weight 0. A formula book the engine has no tier for (BetOnline) counts as
    a sharp one here, because the person said to trust it. The threshold is NOT applied: the caller reads `Presence`.
    """
    contributors = set(market.complete_books())
    use = {b: formula.weight_of(b) for b in contributors}
    if left_out is not None:
        use[left_out] = 0
    table = dict(books)
    for key in formula.keys():
        have = table.get(key)
        if have is None or have.tier is BookTier.UNKNOWN:
            info = BY_KEY.get(key)
            table[key] = Book(key=key, name=info.name if info else key, tier=BookTier.SHARP,
                              limits_winners=False)
    fairs = fair_value(market, table, method_weights, book_weights=use)
    if fairs:
        priced = set(next(iter(fairs.values())).contributors)
    else:
        priced = set()
    present = tuple(k for k in formula.keys() if k in priced)
    missing = tuple(k for k in formula.keys() if k not in priced)
    share = sum(formula.weight_of(k) for k in present) / formula.total
    return fairs, Presence(present, missing, share, formula.threshold / 100.0,
                           bool(fairs) and meets(share, formula.threshold), left_out)


def fair_values(market, books: dict, formula: Formula, method_weights=None, left_out: str | None = None) -> dict:
    """The fair values a +EV bet is judged against: `{}` when too little of the formula priced the market."""
    fairs, presence = blended(market, books, formula, method_weights, left_out)
    return fairs if presence.meets else {}


# ------------------------------------------------------------ words

def percent(x: float) -> str:
    """66.7%, 50%, 100%: one decimal only where it is needed."""
    text = f"{x * 100:.1f}"
    return (text[:-2] if text.endswith(".0") else text) + "%"


def threshold_text(pct: int) -> str:
    return "Any book" if pct <= 0 else "All books" if pct >= 100 else f"{pct}%"


def _names(keys) -> list:
    return [BY_KEY[k].name if k in BY_KEY else k for k in keys]


def _join(names: list) -> str:
    if len(names) <= 1:
        return "".join(names)
    return ", ".join(names[:-1]) + " and " + names[-1]


def requires(formula: Formula | None) -> str:
    """The "Requires:" line: which books must be present to reach the threshold.

    A book is required when the rest cannot reach the threshold without it. When the required books alone are not
    enough, the line says how much more is needed; when none is required, it says so in weight.
    """
    if formula is None:
        return ""
    total, pct = formula.total, formula.threshold
    if pct <= 0:
        return "Requires at least one of your formula's books."
    need = [k for k, w in formula.weights if not meets((total - w) / total, pct)]
    held = sum(formula.weight_of(k) for k in need)
    if need and meets(held / total, pct):
        return f"Requires {_join(_names(need))}."
    if need:
        return (f"Requires {_join(_names(need))}, and enough of the others to reach {threshold_text(pct)} "
                f"of the weight.")
    if pct >= 100:
        return "Requires every book in your formula."
    return f"Requires books that add up to at least {pct}% of the weight; no one book is needed on its own."


def _plural(n: int, one: str, many: str) -> str:
    return one if n == 1 else many


def regions_note(weights: dict, est) -> dict:
    """What a formula book in a region that is not picked means, and what picking it would cost.

    `est` is the `oddsapi.Estimate` of the choices in front of the person. Nothing is fetched and nothing is changed:
    this only says what the next refresh would cost if the person picked the region themselves.
    """
    out = {"missing": [], "text": "", "credits_now": None, "credits_with": None}
    if est is None:
        return out
    used = [BY_KEY[k] for k, w in weights.items() if w > 0 and k in BY_KEY]
    props_regions = tuple(est.props.regions) if est.props is not None else None

    def absent(info, regions) -> bool:
        return not set(info.regions) & set(regions)

    lost = [i for i in used if absent(i, est.regions) or (props_regions is not None and absent(i, props_regions))]
    if not lost:
        return out
    add_main = []
    add_props = []
    for info in lost:
        if absent(info, est.regions) and info.regions[0] not in add_main:
            add_main.append(info.regions[0])
        if props_regions is not None and absent(info, props_regions) and info.regions[0] not in add_props:
            add_props.append(info.regions[0])
    bigger = replace(est, regions=tuple(est.regions) + tuple(add_main))
    if est.props is not None:
        bigger = replace(bigger, props=replace(est.props, regions=props_regions + tuple(add_props)))
    regions = []
    for info in lost:
        if info.regions[0] not in regions:
            regions.append(info.regions[0])
    many, several = len(lost) != 1, len(regions) != 1
    now, then = est.total, bigger.total
    out["missing"] = [i.key for i in lost]
    out["credits_now"], out["credits_with"] = now, then
    out["text"] = (
        f"{_join([i.name for i in lost])} {'are' if many else 'is'} in your formula but "
        f"{'are' if many else 'is'} only sent in the {_join([f'{r} ({REGION_WORDS.get(r, r)})' for r in regions])} "
        f"region{'s' if several else ''}, which {'are' if several else 'is'} not picked, so "
        f"{'they are' if many else 'it is'} not read and count{'' if many else 's'} as absent. Picking "
        f"{'them' if several else 'it'} on the Odds source page would raise the next refresh from up to {now} "
        f"credit{'s' if now != 1 else ''} to up to {then}. Bookbreaker never changes your regions by itself.")
    return out


def _card(info: FormulaBook, weight: int, total: int, est) -> dict:
    share = weight / total if total else 0.0
    picked = est is None or bool(set(info.regions) & set(est.regions))
    return {
        "key": info.key, "name": info.name, "weight": weight, "minus": max(0, weight - 1),
        "plus": min(MAX_WEIGHT, weight + 1),
        "share": share, "share_text": percent(share) if weight else "0%",
        "preset": info.preset, "note": info.note,
        "regions": list(info.regions),
        "region_text": "Sent in the " + " or ".join(f"{r} ({REGION_WORDS.get(r, r)})" for r in info.regions) +
                       (" regions" if len(info.regions) > 1 else " region"),
        "picked": picked,
        "region_note": "" if picked else "Its region is not picked, so its prices are not read and it counts as absent.",
        "can_minus": weight > 0, "can_plus": weight < MAX_WEIGHT,
        "removable": (not info.preset) and weight == 0,
    }


def panel(setting: Setting, est=None) -> dict:
    """Everything the panel draws, in the engine's words. The window prints it and works out nothing."""
    total = sum(setting.weights.values())
    shown_keys = [b.key for b in BOOKS if b.preset or setting.weights.get(b.key, 0) > 0 or b.key in setting.shown]
    cards = [_card(BY_KEY[k], setting.weights.get(k, 0), total, est) for k in shown_keys]
    more = [{"key": b.key, "name": b.name} for b in BOOKS if b.key not in shown_keys]
    built = setting.built()
    note = regions_note({k: w for k, w in setting.weights.items()}, est)
    return {
        "name": NAME,
        "intro": ("Choose the books you trust to set the true price. Each +EV bet (one that pays more than its chance "
                  "of winning is worth) is then judged against a blend of just those books. A book with weight 2 "
                  "counts twice as much as one with weight 1, and a weight of 0 leaves it out."),
        "has_formula": built is not None,
        "states": {"off": "off", "paused": "paused", "on": "on"},
        "active": built is not None and not setting.paused,
        "paused": setting.paused and built is not None,
        "lock_text": LOCK_TEXT, "off_text": OFF_TEXT, "apply": APPLY, "where": WHERE,
        "notice": setting.notice,
        "books": cards, "more": more, "not_in_feed": [dict(x) for x in NOT_IN_FEED],
        "max_weight": MAX_WEIGHT,
        "total_text": (f"{total} point{'s' if total != 1 else ''} of weight in all" if total else "All weights are 0"),
        "threshold": {
            "label": "Only show bets when book weights reach this threshold",
            "value": setting.threshold, "text": threshold_text(setting.threshold),
            "min": 0, "max": 100, "step": STEP, "min_text": "Any book", "max_text": "All books",
            "why": SHARE_WHY,
        },
        "requires": requires(built),
        "regions": note,
    }


# ------------------------------------------------------------ on a read

def counts_text(setting: Setting, shown: int, without: int, left_out: int) -> str:
    """The formula's effect on one read, for the filter counts."""
    built = setting.built()
    if built is None:
        return ""
    if setting.paused:
        return "Held by Recommended: this read used Bookbreaker's own blend of books."
    text = (f"{shown} +EV bet{'s' if shown != 1 else ''} on this read. Without it there would be "
            f"{without}.")
    if left_out:
        text += (f" {left_out} +EV bet{'s' if left_out != 1 else ''} left out because too little of your formula's "
                 "weight priced them.")
    return text


def counts(setting: Setting, stats: dict) -> dict | None:
    """The block `filtercounts` carries for the formula; None when no formula was sent or set."""
    if setting is None or setting.built() is None:
        return None
    on = not setting.paused
    shown, without, left = (stats.get("formula_shown", 0), stats.get("formula_default", 0),
                            stats.get("formula_below", 0)) if on else (0, 0, 0)
    return {"active": on, "paused": setting.paused, "shown": shown, "without": without, "left_out": left,
            "text": counts_text(setting, shown, without, left)}


def board_block(setting: Setting, stats: dict, est=None) -> dict:
    """What a read says about the formula: whether it was used, why not, and what it left out."""
    built = setting.built()
    block = panel(setting, est)
    if built is None:
        sentence = ""
    elif setting.paused:
        sentence = "Your EV formula was not used on this read, because Recommended is on."
    else:
        sentence = (f"Priced with your EV formula. {requires(built)} "
                    + counts_text(setting, stats.get("formula_shown", 0), stats.get("formula_default", 0),
                                  stats.get("formula_below", 0)))
    block["sentence"] = sentence.strip()
    return block


# ------------------------------------------------------------ one play's detail

def detail_block(market, books: dict, formula: Formula, left_out: str | None, names_of) -> dict:
    """Which formula books priced this play and how much of the formula was there, for the row's detail."""
    fairs, pres = blended(market, books, formula, None, left_out)
    total = formula.total
    rows = []
    for key in sorted(formula.keys(), key=lambda k: (-formula.weight_of(k), names_of(k).lower())):
        rows.append({"book": key, "name": names_of(key), "weight": formula.weight_of(key),
                     "share": formula.weight_of(key) / total, "share_text": percent(formula.weight_of(key) / total),
                     "priced": key in pres.present, "left_out": key == left_out,
                     "status": ("priced this market" if key in pres.present else
                                "left out, you would bet here" if key == left_out else "did not price this market")})
    out_name = names_of(left_out) if left_out else ""
    said = (f"{percent(pres.share)} of your formula's weight priced this market"
            f" ({_join([names_of(k) for k in pres.present]) or 'no book'}). "
            f"{'That reaches' if pres.meets else 'That is under'} your threshold "
            f"({threshold_text(formula.threshold)}).")
    if left_out in formula.keys():
        said += f" {out_name}'s own price is left out, because you would bet there."
    absent = [names_of(k) for k in pres.missing if k != left_out]
    if absent:
        said += f" Not priced: {_join(absent)}."
    return {"active": True, "books": rows, "present_share": pres.share, "present_text": percent(pres.share),
            "threshold": formula.threshold, "threshold_text": threshold_text(formula.threshold),
            "meets": pres.meets, "sentence": said}


__all__ = ["BOOKS", "Formula", "Presence", "Setting", "parse", "blended", "fair_values", "panel", "requires",
           "regions_note", "board_block", "counts", "detail_block", "FairValue"]
