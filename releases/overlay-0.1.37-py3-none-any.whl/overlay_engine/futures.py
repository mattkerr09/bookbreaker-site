"""Futures: who wins the title, every book's price side by side, judged against a fair price.

OddsJam has a Futures tab per league: a grid with a row per team, a column per book, the best price
marked. This is that, on the same footing as player props: **opt in, the cost said before the press,
nothing read that was not picked, and the read stored so the view reopens for free.**

**The rule, and where it comes from.** A futures market is an `outrights` market on its own sport key
(`americanfootball_nfl_super_bowl_winner`), read on the same endpoint as the main odds. The Odds API
charges for it the way it charges for any market (https://the-odds-api.com/liveapi/guides/v4/, "GET odds",
"Usage Quota Costs", read 2026-10-13):

    The usage quota cost is 1 per region per market.
    cost = [number of markets specified] x [number of regions specified]

Futures are one market, `outrights`, so a futures key costs one credit per region and a read costs
(futures keys picked) x (regions). `estimate()` says that number before anything is fetched. It is an
upper bound: the same page says "Responses with empty data do not count towards the usage quota", so a
futures market with no prices costs nothing. What a read really cost is read back off `x-requests-last`.

**The free list.** `GET /v4/sports` "does not count against the usage quota" (same page, "GET sports", read
2026-10-13) and carries `active` and `has_outrights` for each sport key. Before spending anything a read
asks it which of the picked keys are listed right now and skips the rest, at no cost, so an out-of-season
title is never paid for. The keys a person can pick are a fixed, dated list (`FUTURES`, read 2026-10-13
from https://the-odds-api.com/sports-odds-data/sports-apis.html), not whatever the list says: the cost
must be known before the list is asked.

**What was not found.** The guide documents `outrights` as a valid market but gives no outrights example
response and no outrights-specific cost line. This code reads the general shape every market has
(`bookmakers` > `markets` > `outcomes` with `name` and `price`, `last_update` on the market) and treats
lay odds (`outrights_lay`, which exchanges send) as not a price you can back: it is ignored.

**The fair price.** A futures market has dozens of outcomes and a large hold, so each book's own complete
list is devigged with the engine's multi-way methods (`devig.devig_all`: multiplicative, power and Shin
handle any number of outcomes; additive raises rather than going negative on a long list, and the spread
keeps that failure) and blended by `fair.fair_value`, or by the person's EV formula
(`formula.blended`) when one is set, exactly as +EV bets are priced. The "list" is every name that at
least two books price; a book sets the fair price only if it prices the whole list, because a book that
leaves names out cannot be devigged (the missing names' chances are not in its prices). A name only one
book lists is shown and given no fair price.

**+EV is marked only where it could be bet.** `ev.find_edges` is the board's own test (robust, anchored
unless the formula says otherwise, at least `min_ev`), and a mark is kept only at a book in
`oddsapi.bettable_in(state)`: the US list, narrowed to books licensed in the person's state when one is picked.
Pinnacle, Europe and the exchanges price the market and are never marked.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from . import fair as fair_mod
from . import futurestore
from .ev import find_edges
from .feed import FeedError, stamp
from .models import Market, Outcome, Quote
from .odds import decimal_to_american, hold as hold_of
from .oddsapi import (BETTABLE, DEFAULT_REGIONS, LEAGUES, REGIONS, Cache, OddsApiError, _pick, _problem,
                      books_table, engine_book, odds_api_fetcher)
from .restfeed import MIN_DECIMAL, Quota, parse_time, read_quota
from .staleness import FillModel, LatencyModel, ago, price_age

#: The sentence the futures cost rests on, kept verbatim so a test can hold it. `outrights` is one market.
COST_RULE = ("The usage quota cost is 1 per region per market. "
             "cost = [number of markets specified] x [number of regions specified]")
COST_RULE_SOURCE = ("https://the-odds-api.com/liveapi/guides/v4/ (GET odds, Usage Quota Costs; outrights "
                    "is one market, and GET sports, the list of futures keys, is free), read 2026-10-13")

#: Futures markets older than this are not drawn: they move slowly, so a read from yesterday is still worth
#: opening (with its age on every price), but one from last month looks exactly like today's.
SHOW_FOR = 7 * 86400.0

#: A name whose fair chance is under this is a long shot.
LONG_SHOT = 0.05

TIES_UP = ("A future ties your money up until the season ends, often for months, so you cannot use it on "
           "anything else meanwhile. A small edge here is worth less than the same edge on a bet that settles tonight.")
LONG_SHOT_NOTE = ("A long shot's edge is the least certain. A small change in a team's true chance moves a long "
                  "shot's expected value far more than a favourite's, and the ways of taking the hold out of "
                  "prices disagree most on long shots.")
NONE_YET = ("No futures have been read on this Mac yet. Turn futures on, pick a league and press Read futures: "
            "it says how many credits that costs first.")
TOO_OLD = ("The last read of futures on this Mac is more than seven days old, so it is not shown: old prices "
           "look exactly like live ones. Read futures again to see current prices.")
NO_KEY_FOR_VIEW = "Opening futures that are already on this Mac needs no key and spends no credits."

#: Futures a person can pick: one sport key per league. Fixed and dated, from the Odds API's sports list
#: (https://the-odds-api.com/sports-odds-data/sports-apis.html, read 2026-10-13).
KEYS_READ = "2026-10-13"


@dataclass(frozen=True)
class FuturesMarket:
    alias: str          # the league's alias, as everywhere else
    label: str          # the league, for a person
    key: str            # the Odds API's sport key for the futures market
    question: str       # what the market asks


FUTURES: tuple = (
    FuturesMarket("nfl", "NFL", "americanfootball_nfl_super_bowl_winner", "Super Bowl winner"),
    FuturesMarket("ncaaf", "College football", "americanfootball_ncaaf_championship_winner",
                  "College football champion"),
    FuturesMarket("nba", "NBA", "basketball_nba_championship_winner", "NBA champion"),
    FuturesMarket("ncaab", "College basketball", "basketball_ncaab_championship_winner",
                  "College basketball champion"),
    FuturesMarket("mlb", "MLB", "baseball_mlb_world_series_winner", "World Series winner"),
    FuturesMarket("nhl", "NHL", "icehockey_nhl_championship_winner", "Stanley Cup winner"),
)
_BY_ALIAS = {f.alias: f for f in FUTURES}
_BY_KEY = {f.key: f for f in FUTURES}
OUTRIGHTS = "outrights"


def aliases() -> list:
    return [f.alias for f in FUTURES]


# ------------------------------------------------------------ the cost, said before the press

@dataclass(frozen=True)
class Estimate:
    """What one futures read will cost, worked out before anything is fetched."""

    markets: tuple          # FuturesMarket picked
    regions: tuple

    @property
    def per_market(self) -> int:
        # THE RULE: one market (outrights) x regions, for one futures key.
        return len(self.regions)

    @property
    def credits(self) -> int:
        return self.per_market * len(self.markets)

    def sentence(self) -> str:
        if not self.markets:
            return "No futures are picked, so nothing would be read and no credits would be spent."
        n, k, r = self.credits, len(self.markets), len(self.regions)
        return (
            f"Reading futures uses up to {n} of your Odds API credit{'s' if n != 1 else ''}: "
            f"{k} futures market{'s' if k != 1 else ''} "
            f"({', '.join(f.question for f in self.markets)}) x "
            f"{r} region{'s' if r != 1 else ''} ({', '.join(self.regions)}), at 1 credit each. "
            "A futures market The Odds API is not listing right now, or has no prices for, costs nothing.")

    def as_dict(self) -> dict:
        return {
            "credits": self.credits, "per_market": self.per_market, "markets": len(self.markets),
            "regions": len(self.regions), "region_keys": list(self.regions),
            "leagues": [f.alias for f in self.markets],
            "by_league": {f.alias: self.per_market for f in self.markets},
            "text": self.sentence(), "rule": COST_RULE, "rule_source": COST_RULE_SOURCE,
        }


def estimate(leagues=None, regions=None) -> Estimate:
    """Validate the choices and price them. No network, no key. Nothing picked is a cost of 0: futures
    are off until a league is picked, and a key the person did not pick is never read."""
    picked = _pick(leagues, _BY_ALIAS, "futures league", ())
    return Estimate(tuple(_BY_ALIAS[a] for a in picked), _pick(regions, REGIONS, "region", DEFAULT_REGIONS))


def choices(est: Estimate) -> dict:
    """Everything the window needs to draw its pickers, from the engine."""
    return {
        "leagues": [{"alias": f.alias, "label": f.label, "question": f.question, "key": f.key,
                     "picked": f in est.markets} for f in FUTURES],
        "regions": [{"key": k, "label": v, "picked": k in est.regions} for k, v in REGIONS.items()],
        "keys_read": KEYS_READ,
    }


# ------------------------------------------------------------ reading the answer

def parse_outrights(payload, sport: str, received_at: float) -> tuple:
    """One futures answer into markets, one per event, quotes named for the outcome.

    The answer is a list of events, each with `bookmakers` > `markets` > `outcomes`
    (`{name, price}`), `last_update` on the market. Only the `outrights` market is read: a lay price is
    not one you can back. An event's `commence_time` is NOT used to leave it off as under way: a title
    market is open all season.

    Returns `(markets, skipped)`; `skipped` counts a name a book listed twice (the first stands).
    """
    if not isinstance(payload, list):
        raise FeedError(f"expected a list of events, got {type(payload).__name__}")
    markets, skipped = [], 0
    for event in payload:
        if not isinstance(event, dict):
            raise FeedError("expected an event object")
        try:
            event_id = str(event["id"])
        except KeyError as exc:
            raise FeedError(f"event missing {exc}, so the partial answer was refused")
        market = Market(event_id=event_id, sport=sport, market_type=OUTRIGHTS, quotes=[], starts_at=None)
        for book in event.get("bookmakers") or []:
            book_key = str(book.get("key") or "")
            if not book_key:
                raise FeedError(f"{event_id}: a bookmaker block has no key")
            for m in book.get("markets") or []:
                if str(m.get("key") or "") != OUTRIGHTS:
                    continue
                stamp_text = m.get("last_update") or book.get("last_update")
                seen_at = parse_time(stamp_text) if stamp_text else received_at
                for outcome in m.get("outcomes") or []:
                    name = " ".join(str(outcome.get("name") or "").split())
                    if not name:
                        raise FeedError(f"{event_id}: an outcome has no name")
                    try:
                        price = float(outcome["price"])
                    except (KeyError, TypeError, ValueError) as exc:
                        raise FeedError(f"{event_id} {name}: bad outcome ({exc})")
                    if price <= MIN_DECIMAL:
                        raise FeedError(f"{event_id} {name}: price {price} is not decimal odds")
                    if any(q.book == engine_book(book_key) and q.outcome.name == name for q in market.quotes):
                        skipped += 1
                        continue
                    market.quotes.append(Quote(book=engine_book(book_key), outcome=Outcome(name=name),
                                               decimal=price, seen_at=seen_at))
        if market.quotes:
            markets.append(market)
    return markets, skipped


@dataclass
class KeyRead:
    market: FuturesMarket
    events: int
    from_cache: bool
    fetched_at: float
    credits: int | None         # what this call cost; 0 off the disk; None if the API did not say
    outcomes: int = 0


@dataclass
class Read:
    estimate: Estimate
    reads: list = field(default_factory=list)
    skipped: list = field(default_factory=list)         # (FuturesMarket, sentence): not read, cost nothing
    errors: list = field(default_factory=list)
    quota: Quota = field(default_factory=Quota)
    now: float = 0.0
    dated: int = 0
    undated: int = 0
    skewed: int = 0
    stored: int = 0

    @property
    def spent(self) -> int:
        return sum(r.credits or 0 for r in self.reads)

    @property
    def spent_known(self) -> bool:
        return all(r.credits is not None for r in self.reads if not r.from_cache)

    @property
    def all_cached(self) -> bool:
        return bool(self.reads) and all(r.from_cache for r in self.reads)

    def as_dict(self) -> dict:
        return {
            "spent": self.spent if self.spent_known else None, "cached": self.all_cached,
            "remaining": self.quota.remaining, "used": self.quota.used, "last": self.quota.last,
            "text": self.credits_line(), "errors": list(self.errors),
            "skipped": [why for _, why in self.skipped], "stored": self.stored, "fetched_at": self.now,
            "leagues": [{"alias": r.market.alias, "label": r.market.label, "question": r.market.question,
                         "from_cache": r.from_cache, "credits": r.credits, "names": r.outcomes,
                         "fetched_at": r.fetched_at} for r in self.reads],
            "dated": self.dated, "undated": self.undated, "skewed": self.skewed,
        }

    def credits_line(self) -> str:
        if not self.reads:
            used = "No futures prices were read, so no credits were spent."
        elif self.all_cached:
            used = "No credits were spent: these prices were fetched in the last minute."
        elif self.spent_known:
            used = f"This read used {self.spent} credit{'s' if self.spent != 1 else ''}."
        else:
            used = "The Odds API did not say what this read cost."
        if self.quota.known:
            left = f" {self.quota.remaining} left this month ({self.quota.used} used so far)."
        else:
            left = " The Odds API did not say how many credits are left."
        return used + left


def read(est: Estimate, key: str, *, clock=None, cache: Cache | None = None, fetcher=None,
         where=None) -> Read:
    """Read exactly the futures the person picked, store each, and return what was read.

    The order is the promise. The free list of sports is asked first; a picked key it does not list is
    skipped without a request. Each remaining key is one request (or the last minute's answer off the
    disk). A failure before anything was read raises, so a person is never shown an empty view that was
    really an error; after something was read it ends the run and keeps what there is. Only the picked
    keys are ever requested, and the key never leaves the fetcher.
    """
    clock = clock if clock is not None else time.time
    cache = cache if cache is not None else Cache()
    fetcher = fetcher if fetcher is not None else odds_api_fetcher()
    where = where if where is not None else futurestore.folder()
    out = Read(estimate=est)
    if not est.markets:
        raise OddsApiError("Pick at least one league to read futures for.", reason="bad_choice")

    try:
        listed, _ = fetcher("/v4/sports", {"apiKey": key})
        if not isinstance(listed, list):
            raise FeedError("expected a list of sports")
        open_keys = {str(s["key"]): s for s in listed if isinstance(s, dict) and s.get("key")}
    except Exception as exc:                                    # noqa: BLE001
        raise _problem(exc, "the list of futures markets") from None

    regions = est.regions
    bound = len(regions)                    # the most ONE futures key can cost: 1 market x regions
    names: dict = {}
    for m in est.markets:
        entry = open_keys.get(m.key)
        if entry is None or entry.get("active") is False or entry.get("has_outrights") is False:
            out.skipped.append((m, f"{m.question} is not listed by The Odds API right now, so it was not "
                                   "read and cost nothing."))
            continue
        if out.quota.remaining is not None and out.quota.remaining < bound:
            out.errors.append(f"Futures stopped before {m.question}: it needs up to {bound} credits and "
                              f"you have {out.quota.remaining} left this month.")
            break
        hit = cache.get(m.key, regions, (OUTRIGHTS,), clock())
        try:
            if hit is not None:
                payload, headers, got_at = hit.payload, hit.headers, hit.fetched_at
            else:
                got_at = clock()
                payload, headers = fetcher(f"/v4/sports/{m.key}/odds", {
                    "apiKey": key, "regions": ",".join(regions), "markets": OUTRIGHTS,
                    "oddsFormat": "decimal", "dateFormat": "iso"})
            markets, _dupes = parse_outrights(payload, m.key, got_at)
        except Exception as exc:                                # noqa: BLE001
            problem = _problem(exc, f"{m.question} prices")
            if not out.reads and problem.reason != "rejected":
                raise problem from None
            out.errors.append(str(problem))
            if problem.reason == "rejected":
                continue                    # one market the API would not answer; the rest may be fine
            break
        credits = 0
        if hit is None:
            cache.put(m.key, regions, (OUTRIGHTS,), payload, headers, got_at)
            quota = read_quota(headers)
            out.quota = quota
            cache.remember(quota, got_at)
            credits = quota.last
        snap = stamp(markets, got_at, "oddsapi")
        out.dated += snap.dated
        out.undated += snap.undated
        out.skewed += snap.skewed
        out.reads.append(KeyRead(m, len(payload), hit is not None, got_at, credits,
                                 max((len({q.outcome.name for q in x.quotes}) for x in snap.markets), default=0)))
        for event in payload:
            for b in event.get("bookmakers") or []:
                raw = str(b.get("key") or "")
                names.setdefault(engine_book(raw), str(b.get("title") or raw))
        if snap.markets:
            if futurestore.record(where, alias=m.alias, key=m.key, fetched_at=got_at, regions=regions,
                                  question=m.question, markets=snap.markets, names=names):
                out.stored += 1
        else:
            out.skipped.append((m, f"No book had {m.question} prices in this read, so the earlier read "
                                   "(if any) is kept."))
        if credits is not None and credits > bound:
            # The documented rule says this cannot happen. If it did, the rule is wrong or has changed,
            # and every further request would be charged at a rate nobody was told.
            out.errors.append(
                f"The Odds API charged {credits} credits for one futures market, and Bookbreaker's count allows "
                f"{bound}. Futures stopped. Check for a newer Bookbreaker.")
            break
    out.now = clock()
    return out


# ------------------------------------------------------------ the view

def formula_sentence(setting) -> str:
    """One line on how futures are priced: the person's EV formula, held, or the engine's own blend."""
    built = setting.built() if setting is not None else None
    if built is None:
        return ""
    if setting.paused:
        return ("Your EV formula is held because Recommended is on, so futures are priced with Bookbreaker's own "
                "blend of books.")
    return "Futures are priced with your EV formula, the same way +EV bets are."


def _american(decimal: float) -> int:
    return round(decimal_to_american(decimal))


def _pct(x: float, places: int = 1) -> str:
    return f"{x * 100:.{places}f}%"


def _signed(x: float) -> str:
    return f"{x * 100:+.1f}%"


def _fair_block(fv) -> dict | None:
    """A fair probability as a price a person can read, with the range the methods and books allow."""
    if fv is None or not 0.0 < fv.prob < 1.0:
        return None
    out = {"prob": fv.prob, "prob_text": _pct(fv.prob), "decimal": round(1.0 / fv.prob, 3),
           "american": _american(1.0 / fv.prob), "anchored": fv.anchored}
    if 0.0 < fv.low <= fv.prob <= fv.high < 1.0:
        lo, hi = _american(1.0 / fv.high), _american(1.0 / fv.low)      # a likelier outcome is a shorter price
        out["low_american"], out["high_american"] = lo, hi
        out["range_text"] = f"{lo:+d} to {hi:+d}"
    else:
        out["range_text"] = ""
    return out


def _list_of(names: list) -> str:
    names = list(names)
    if len(names) <= 1:
        return "".join(names)
    return ", ".join(names[:-1]) + " and " + names[-1]


def _popular(key: str) -> int:
    from .screen import popular
    return popular(key)


def _board(rec: dict, market: Market, now: float, *, formula, min_ev: float, books: dict, can=None) -> dict:
    """One futures market as the window draws it. Every figure is the engine's. `can` is the books a person may
    be told to bet at (`oddsapi.bettable_in(state)`); every other book is a reference price."""
    can = set(BETTABLE) if can is None else can
    names = dict(BETTABLE)
    names.update(rec.get("names") or {})

    def name_of(b: str) -> str:
        return names.get(b) or b.replace("_", " ").title()

    quotes_by: dict = {}
    for q in market.quotes:
        quotes_by.setdefault(q.outcome.key, {})[q.book] = q
    priced_by = {k: len(v) for k, v in quotes_by.items()}
    all_books = sorted({q.book for q in market.quotes})
    # The list the fair price is made on: every name two books price (all of them if only one book priced).
    field_keys = [k for k in quotes_by if priced_by[k] >= 2] if len(all_books) >= 2 else list(quotes_by)
    fm = Market(event_id=market.event_id, sport=market.sport, market_type=OUTRIGHTS,
                quotes=[q for q in market.quotes if q.outcome.key in field_keys])
    complete = fm.complete_books() if len(field_keys) >= 2 else []

    # -- the hold, per book that priced the whole list
    holds = {}
    for b in complete:
        try:
            holds[b] = hold_of([fm.by_book(b)[k].decimal for k in field_keys])
        except Exception:                                       # noqa: BLE001
            continue
    if holds:
        low_b, high_b = min(holds, key=holds.get), max(holds, key=holds.get)
        if len(holds) == 1 or abs(holds[low_b] - holds[high_b]) < 0.0005:
            hold_sentence = (f"{name_of(high_b)} keeps about {_pct(holds[high_b])} of the money bet on this list "
                             "in its prices (its hold), because its prices add up to more than a 100% chance.")
        else:
            hold_sentence = (f"The books that price the whole list keep between {_pct(holds[low_b])} "
                             f"({name_of(low_b)}) and {_pct(holds[high_b])} ({name_of(high_b)}) of the money bet "
                             "in their prices (the hold), because each book's prices add up to more than a 100% chance.")
    else:
        hold_sentence = ("No sportsbook priced every name on the list, so the hold, the cut a book builds into "
                         "its prices, could not be worked out.")

    # -- the fair price: the person's own formula when set, the engine's own blend otherwise
    fairs, fair_why, used_formula = {}, "", False
    if len(field_keys) >= 2 and complete:
        if formula is not None:
            from . import formula as formula_mod
            got, presence = formula_mod.blended(fm, books, formula)
            if presence.meets:
                fairs, used_formula = got, True
            else:
                fair_why = (f"Your EV formula: only {formula_mod.percent(presence.share)} of its weight priced "
                            f"this whole list, which is under your threshold of "
                            f"{formula_mod.threshold_text(formula.threshold)}, so no fair price is shown.")
        else:
            fairs = fair_mod.fair_value(fm, books)
    elif len(field_keys) >= 2:
        fair_why = ("No sportsbook priced every name on the list, so there is no fair price. Books that price "
                    "only part of a list cannot have the hold taken out of their prices.")
    else:
        fair_why = "Fewer than two names are priced by more than one book, so there is no fair price."
    anchored = bool(fairs) and next(iter(fairs.values())).anchored
    contributors = sorted(next(iter(fairs.values())).contributors) if fairs else []
    if fairs and used_formula:
        fair_sentence = ("Fair price: the hold taken out of each book that priced the whole list, then blended "
                         "with your EV formula's weights.")
    elif fairs:
        fair_sentence = ("Fair price: the hold taken out of each book that priced the whole list, then blended "
                         "with Bookbreaker's own weights, which count Pinnacle and the exchanges most.")
    else:
        fair_sentence = fair_why
    partial = [b for b in all_books if b not in complete]
    if fairs and partial:
        one = len(partial) == 1
        fair_sentence += (f" {_list_of([name_of(b) for b in partial])} priced only part of the list, so "
                          f"{'it is' if one else 'they are'} shown but "
                          f"{'does' if one else 'do'} not help set the fair price.")

    # -- +EV: the board's own test, kept only where it could be bet
    edges = {}
    if fairs:
        for e in find_edges(fm, books, now, min_ev=min_ev, fill_model=FillModel(), latency_model=LatencyModel(),
                            formula=formula if used_formula else None):
            if e.book in can:
                edges[(e.outcome, e.book)] = e
    # -- the grid
    stale_total = cells_total = 0
    rows = []
    for key in quotes_by:
        quotes = quotes_by[key]
        bet = [q for b, q in quotes.items() if b in can]
        top = max((q.decimal for q in bet), default=None)
        fv = fairs.get(key)
        fair = _fair_block(fv)
        long_shot = fv is not None and fv.prob < LONG_SHOT
        cells = {}
        for b, q in quotes.items():
            age = round(max(0.0, now - q.seen_at), 1)
            got = price_age(age, OUTRIGHTS)
            cell = {"american": _american(q.decimal), "decimal": round(q.decimal, 4), "age": age,
                    "age_text": f"last confirmed {ago(age)}", "age_brief": got["brief"],
                    "stale": got["stale"], "stale_reason": got["reason"]}
            if top is not None and b in can and q.decimal == top:
                cell["best"] = True
            edge = edges.get((key, b))
            if edge is not None:
                cell["ev"] = {
                    "ev": edge.ev, "ev_text": _signed(edge.ev), "low_text": _signed(edge.ev_low),
                    "long_shot": long_shot,
                    "text": (f"{_signed(edge.ev)} above this name's fair price at {name_of(b)} (at worst "
                             f"{_signed(edge.ev_low)})." + (" A long shot: the least certain kind of edge."
                                                           if long_shot else ""))}
            cells[b] = cell
            cells_total += 1
            stale_total += 1 if got["stale"] else 0
        best = None
        if top is not None:
            best = {"american": _american(top), "decimal": round(top, 4),
                    "books": sorted(b for b, q in quotes.items() if b in can and q.decimal == top)}
        rows.append({"outcome": key, "label": key, "best": best, "fair": fair, "cells": cells,
                     "in_list": key in field_keys, "long_shot": long_shot, "priced_by": priced_by[key],
                     "_order": (0, -fv.prob) if fv is not None else (1, min(q.decimal for q in quotes.values()))})
    rows.sort(key=lambda r: (r["_order"], r["label"].lower()))
    for r in rows:
        del r["_order"]

    # -- the books: those you can bet at first, then the reference books
    seen = {}
    for q in market.quotes:
        seen[q.book] = seen.get(q.book, 0) + 1
    cols = [{"key": b, "name": name_of(b), "bettable": b in can, "prices": n,
             "hold": holds.get(b), "hold_text": _pct(holds[b]) if b in holds else "",
             "whole_list": b in complete}
            for b, n in seen.items()]
    cols.sort(key=lambda c: (not c["bettable"], -c["prices"], _popular(c["key"]), c["name"].lower()))

    plays = []
    for (key, b), e in sorted(edges.items(), key=lambda kv: kv[1].realised_ev, reverse=True)[:10]:
        cell = next(r for r in rows if r["outcome"] == key)["cells"][b]
        plays.append({"outcome": key, "book": b, "book_name": name_of(b), "american": cell["american"],
                      "age_brief": cell["age_brief"], "stale": cell["stale"], **cell["ev"],
                      "fair_american": (next(r for r in rows if r["outcome"] == key)["fair"] or {}).get("american")})

    old = stale_total
    limit = price_age(0.0, OUTRIGHTS)["limit_text"]
    age = round(max(0.0, now - rec["fetched_at"]), 1)
    notes = []
    if fairs and not anchored and not used_formula:
        notes.append("No Pinnacle or exchange price priced this whole list, so no +EV future is marked. Add the "
                     "Europe region when you read futures to price them.")
    return {
        "league": rec["alias"], "league_label": _BY_ALIAS[rec["alias"]].label if rec["alias"] in _BY_ALIAS
        else rec["alias"], "question": rec.get("question") or "", "market": OUTRIGHTS,
        "read_at": rec["fetched_at"], "age": age, "age_text": ago(age), "regions": list(rec.get("regions") or []),
        "books": cols, "rows": rows, "names": len(rows), "plays": plays,
        "hold_sentence": hold_sentence, "fair_sentence": fair_sentence, "fair": bool(fairs),
        "formula_used": used_formula, "anchored": anchored,
        "fair_books": [name_of(b) for b in contributors],
        "stale_prices": old,
        "stale_note": (f"{old} of {cells_total} prices are greyed: each was last confirmed more than {limit} ago. "
                       "A book may still be offering one, so check it there before you bet." if old else ""),
        "warning": (f"These prices were read {ago(age)}. A sportsbook can change a price at any moment, so use "
                    "the grid to look, and check each price at the book before you bet.") if age > 600.0 else "",
        "notes": notes,
    }


def build(records: list, now: float, *, formula=None, min_ev: float = 0.0, books: dict | None = None,
          show_for: float = SHOW_FOR, only=None, state: str | None = None) -> dict:
    """The whole view: one grid per league that was read, newest prices as they were stored.

    `formula` is a `formula.Formula` (the person's, already unpaused) or None for the engine's blend.
    `only` is the aliases to draw, or None for every league read. `state` (two letters) keeps every best price and
    +EV mark at a sportsbook licensed there. Reads nothing: it is handed records.
    """
    from .oddsapi import bettable_in, books_for
    can = bettable_in(state)
    books = books if books is not None else books_table()
    order = {f.alias: i for i, f in enumerate(FUTURES)}
    kept = sorted((r for r in records if only is None or r["alias"] in only),
                  key=lambda r: order.get(r["alias"], 99))
    fresh = [r for r in kept if now - r["fetched_at"] <= show_for]
    if not fresh:
        return {"has_futures": False, "now": now, "boards": [], "leagues": [], "min_ev": min_ev,
                "books_for": books_for(state),
                "message": TOO_OLD if kept else NONE_YET, "ties_up": TIES_UP, "long_shot": LONG_SHOT_NOTE}
    boards = []
    for rec in fresh:
        for market in futurestore.to_markets(rec):
            if market.quotes:
                boards.append(_board(rec, market, now, formula=formula, min_ev=min_ev, books=books, can=can))
    return {
        "has_futures": bool(boards), "now": now, "boards": boards,
        "leagues": [{"alias": b["league"], "label": b["league_label"], "question": b["question"]}
                    for b in boards],
        "read_at": max(r["fetched_at"] for r in fresh), "oldest": min(r["fetched_at"] for r in fresh),
        "min_ev": min_ev, "min_ev_text": f"{min_ev * 100:g}%", "show_for": show_for,
        "message": "" if boards else NONE_YET,
        "ties_up": TIES_UP, "long_shot": LONG_SHOT_NOTE, "books_for": books_for(state),
        "note": ("Prices are as they were when read, and a book can change one at any moment. Check the price at "
                 "the book before you bet. Pinnacle and the other reference books price the market; you cannot bet "
                 "at them from the US, so they are never marked best or +EV."),
    }


def from_store(where=None, now: float | None = None, **kw) -> dict:
    """The view from what reads left on this Mac. Reads files; touches no network and no key."""
    return build(futurestore.load(where if where is not None else futurestore.folder()),
                 time.time() if now is None else now, **kw)
