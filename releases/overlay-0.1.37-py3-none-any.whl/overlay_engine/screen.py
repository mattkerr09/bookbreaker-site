"""The odds screen: every sportsbook's price on every game, in one grid.

A bettor shopping a line wants one thing from a screen: for this game and this
side, who is paying the most. Rows are games and sides, columns are books, and
the best price in each row is marked.

**It is made from prices already on this Mac.** Two sources, both local:

  * the refresh that has just happened (`from_refresh`), so pressing Live
    sportsbook odds draws the grid from the very same read the board's plays
    came from; and
  * the record every refresh leaves in `oddshistory` (`from_history`), so the
    grid can be opened again later, after the window was closed, without a key,
    without a request and without a credit.

Nothing here fetches anything. `from_history` is given a folder and reads files.
A test hands it no network at all, and another proves the window's call for it
(`board --feed oddsapi --screen`) never reaches for the key or the fetcher.

**Every price carries the time it was read.** Each grid says when its league was
read and how old that is, and each cell says how old its book's own last update
was. A grid of old prices is still shown (the person may only want to look), but
it says so; one older than `SHOW_FOR` is not shown, because a screen of
yesterday's prices reads exactly like a screen of live ones.

**The best price is the best price you can bet.** Pinnacle, the Europe region
and the exchanges whose fees these prices do not include price a market and are
shown in their own columns, marked reference. They are never the highlighted
best price, in the same way they are never a leg on the board: a highlight is an
instruction to go and place a bet.

**The window computes nothing.** It receives American prices, the best price per
row and which cells are best, and draws them.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from . import oddshistory
from .odds import decimal_to_american
# The wording of an age is one function, in staleness.py with the limit that decides when a price is too old.
from .staleness import STALE_AFTER, ago, price_age

#: The three bet types the feed carries, in the order they are offered.
MARKET_ORDER = ("h2h", "spreads", "totals")
MARKET_LABELS = {"h2h": "Moneyline", "spreads": "Spread", "totals": "Total"}

#: Prices older than this are not drawn. Six hours is long enough to open the
#: screen after dinner on a read taken at lunch, and short enough that a grid
#: of last night's lines is never mistaken for tonight's.
SHOW_FOR = 6 * 3600.0

NONE_YET = ("No sportsbook odds have been read on this Mac yet, so there is nothing to lay out. Press Live "
            "sportsbook odds on the Arbitrage page (it needs your Odds API key) and the grid fills from that read.")
TOO_OLD = ("The last read of sportsbook odds on this Mac is more than six hours old, so it is not shown: "
           "a grid of old prices looks exactly like a grid of live ones. Press Live sportsbook odds on the Arbitrage "
           "page to read fresh prices.")


#: A grid read longer ago than this carries a warning. Ten minutes is far past
#: the minute the feed is cached for, and a price can change in seconds. It is
#: the same limit that greys a single price (`staleness.STALE_AFTER`).
OLD_AFTER = STALE_AFTER["default"]


def american(decimal: float) -> int:
    """The price the way a US book prints it, so the window never converts one."""
    return round(decimal_to_american(decimal))


def _cap(text: str) -> str:
    return text[:1].upper() + text[1:]


def parse_key(key: str) -> tuple:
    """`Outcome.key` is `name@line` (or just `name`); this is its two parts."""
    name, at, line = str(key).rpartition("@")
    if not at:
        return str(key), None
    try:
        return name, float(line)
    except ValueError:
        return str(key), None


def side_label(key: str, market_type: str) -> str:
    """A side as a bettor writes it: `Chiefs -3.5`, `Over 47.5`, `Bills`."""
    name, line = parse_key(key)
    name = _cap(name)
    if line is None:
        return name
    if market_type == "spreads":
        return f"{name} {line:+g}"
    return f"{name} {line:g}"


@dataclass
class Read:
    """One league's markets as one read of the feed brought them."""

    alias: str
    label: str
    fetched_at: float
    markets: list
    events: dict = field(default_factory=dict)      # event id -> {"label", "starts"}
    names: dict = field(default_factory=dict)       # engine book key -> display name


#: Where books tie on how many rows they price, the ones most people have
#: accounts at come first, so the screen opens on familiar columns.
POPULAR = ("dk", "fd", "mgm", "caesars", "espnbet", "fanatics", "betrivers", "hardrockbet")


def popular(key: str) -> int:
    """Where a book sits in the order people expect to see them."""
    return POPULAR.index(key) if key in POPULAR else len(POPULAR)


def book_name(key: str, names: dict) -> str:
    return names.get(key) or _cap(str(key).replace("_", " "))


def _group_key(line):
    # A spread's two sides carry opposite signs on one number; they are one pair.
    return None if line is None else abs(line)


def _rows(market, bettable, now: float, teams: tuple = ()) -> list:
    """One row per side per line, with a cell for each book that prices it.

    `teams` is (away, home) when the game's name says so, so a pair of sides
    reads in the same order as the title: Bills at Chiefs lists the Bills first.
    """
    by_key: dict = {}
    order: list = []
    for q in market.quotes:
        if q.outcome.key not in by_key:
            by_key[q.outcome.key] = {}
            order.append(q.outcome.key)
        by_key[q.outcome.key][q.book] = q

    groups: dict = {}
    for key in order:
        groups.setdefault(_group_key(parse_key(key)[1]), []).append(key)

    def depth(item):
        # The line most books agree on first; then the smaller line.
        _, keys = item
        books = {b for k in keys for b in by_key[k]}
        line = item[0]
        return (-len(books), 0.0 if line is None else line)

    out = []
    for _, keys in sorted(groups.items(), key=depth):
        # Over before Under; teams in the order the game's name gives them; any
        # other pair keeps the order the feed gave it.
        def rank(k):
            name = parse_key(k)[0]
            if name.lower() in ("over", "under"):
                return (0 if name.lower() == "over" else 1, order.index(k))
            return (2 + (teams.index(name) if name in teams else 0), order.index(k))

        keys = sorted(keys, key=rank)
        for key in keys:
            quotes = by_key[key]
            can = [q for b, q in quotes.items() if bettable is None or b in bettable]
            top = max((q.decimal for q in can), default=None)
            cells = {}
            for b, q in quotes.items():
                age = round(max(0.0, now - q.seen_at), 1)
                got = price_age(age, market.market_type)
                cell = {"american": american(q.decimal), "decimal": round(q.decimal, 4),
                        "age": age, "age_text": f"last confirmed {ago(age)}",
                        # What the cell says under its price, and whether it is greyed and why.
                        "age_brief": got["brief"], "stale": got["stale"], "stale_reason": got["reason"]}
                if q.limit is not None:
                    cell["limit"] = q.limit
                if top is not None and (bettable is None or b in bettable) and q.decimal == top:
                    cell["best"] = True
                cells[b] = cell
            best = None
            if top is not None:
                best = {"american": american(top), "decimal": round(top, 4),
                        "books": sorted(b for b, q in quotes.items()
                                        if (bettable is None or b in bettable) and q.decimal == top)}
            out.append({"outcome": key, "label": side_label(key, market.market_type),
                        "line": parse_key(key)[1], "best": best, "cells": cells})
    return out


def _grid(read: Read, market_type: str, markets: list, bettable, now: float, names: dict) -> dict:
    games = []
    seen_books: dict = {}
    under_way = 0
    for m in markets:
        if m.starts_at is not None and m.starts_at <= now:
            under_way += 1
            continue
        info = read.events.get(str(m.event_id), {})
        title = info.get("label") or ""
        away, at, home = title.partition(" at ")
        rows = _rows(m, bettable, now, (away, home) if at else ())
        if not rows:
            continue
        for row in rows:
            for b in row["cells"]:
                seen_books[b] = seen_books.get(b, 0) + 1
        games.append({"event_id": str(m.event_id), "game": info.get("label") or str(m.event_id),
                      "starts": m.starts_at,
                      "rows": rows})
    games.sort(key=lambda g: (g["starts"] is None, g["starts"] if isinstance(g["starts"], (int, float)) else 0,
                              g["game"]))
    books = [{"key": b, "name": book_name(b, names), "bettable": bettable is None or b in bettable,
              "prices": n}
             for b, n in seen_books.items()]
    # Books you can bet at first, the ones that price the most rows leftmost;
    # reference-only books after them.
    books.sort(key=lambda b: (not b["bettable"], -b["prices"], popular(b["key"]), b["name"].lower()))
    age = round(max(0.0, now - read.fetched_at), 1)
    warning = ""
    if age > OLD_AFTER:
        warning = (f"These prices were read {ago(age)}. A sportsbook can change a price at any moment, so use "
                   "the grid to look, and check each price at the book before you bet.")
    cells = [c for g in games for r in g["rows"] for c in r["cells"].values()]
    old = sum(1 for c in cells if c["stale"])
    limit = price_age(0.0, market_type)["limit_text"]
    # Said once above the grid, so the greyed cells are explained where they are seen.
    stale_note = (f"{old} of {len(cells)} prices are greyed: each was last confirmed more than {limit} ago. "
                  "A book may still be offering one, so check it there before you bet."
                  if old else "")
    return {"league": read.alias, "league_label": read.label, "market": market_type,
            "market_label": MARKET_LABELS.get(market_type, market_type),
            "read_at": read.fetched_at, "age": age, "age_text": ago(age), "warning": warning,
            "stale_prices": old, "stale_limit_text": limit, "stale_note": stale_note,
            "books": books, "games": games, "under_way": under_way}


def build(reads: list, bettable, now: float, show_for: float = SHOW_FOR) -> dict:
    """The whole screen: a grid for each league and bet type that was read.

    `bettable` is the set of book keys a person can place a bet at, or None
    when every book can be (a recorded snapshot has no opinion).
    """
    grids = []
    for read in reads:
        if now - read.fetched_at > show_for:
            continue
        names = dict(read.names)
        types = []
        for m in read.markets:
            if m.market_type not in types:
                types.append(m.market_type)
        for t in sorted(types, key=lambda t: MARKET_ORDER.index(t) if t in MARKET_ORDER else 99):
            grid = _grid(read, t, [m for m in read.markets if m.market_type == t], bettable, now, names)
            if grid["games"] or grid["under_way"]:
                grids.append(grid)
    if not grids:
        stale = any(now - r.fetched_at > show_for for r in reads)
        return {"has_odds": False, "grids": [], "leagues": [], "markets": [], "now": now,
                "message": TOO_OLD if stale else NONE_YET}
    leagues, kinds = [], []
    for g in grids:
        if g["league"] not in [x["alias"] for x in leagues]:
            leagues.append({"alias": g["league"], "label": g["league_label"]})
        if g["market"] not in [x["key"] for x in kinds]:
            kinds.append({"key": g["market"], "label": g["market_label"]})
    kinds.sort(key=lambda k: MARKET_ORDER.index(k["key"]) if k["key"] in MARKET_ORDER else 99)
    return {"has_odds": True, "now": now, "leagues": leagues, "markets": kinds, "grids": grids,
            "read_at": max(g["read_at"] for g in grids), "oldest": min(g["read_at"] for g in grids),
            "under_way": sum(g["under_way"] for g in grids), "show_for": show_for,
            "note": ("Prices are as they were when read, and a book can change one at any moment. "
                     "Check the price at the book before you bet. Pinnacle and the other reference books "
                     "price the market; you cannot bet at them from the US, so they are never marked best.")}


def from_refresh(got, bettable, now: float | None = None) -> dict:
    """The screen from a refresh that has just been made: the same markets, the
    same read times and the same book names the board's plays came from."""
    now = got.now if now is None else now
    reads = []
    for r in got.reads:
        reads.append(Read(alias=r.league.alias, label=r.league.label, fetched_at=r.fetched_at,
                          markets=[m for m in got.markets if m.sport == r.league.key],
                          events=got.event_info, names=got.book_names))
    return build(reads, bettable, now)


def history_reads(folder, now: float, show_for: float = SHOW_FOR):
    """The newest recorded read of each league and bet type, as `Read`s, and whether
    older reads exist that were too old to use. Reads files; touches no network and
    no key.

    For each league and bet type the newest read that has it is used, so a
    moneyline read at lunch and a total read at dinner both appear, each with
    its own time. Shared by the odds screen and the low hold view, so the two
    can never disagree about which prices are on this Mac.
    """
    from .oddsapi import BETTABLE, LEAGUES

    chosen: dict = {}
    for snap in oddshistory.snapshots(folder, since=now - show_for):
        by_type: dict = {}
        for m in oddshistory.to_markets(snap):
            by_type.setdefault(m.market_type, []).append(m)
        for t, markets in by_type.items():
            chosen[(snap["league"], t)] = (snap, markets)

    if not chosen:
        # Nothing recent. If older reads are on disk, say they are too old to draw
        # rather than that nothing was ever read.
        try:
            older = any(Path(folder).glob("*.jsonl"))
        except OSError:
            older = False
        return [], older

    rank = {lg.key: i for i, lg in enumerate(LEAGUES)}
    label = {lg.key: lg.label for lg in LEAGUES}
    reads = []
    for (league, t), (snap, markets) in sorted(chosen.items(), key=lambda kv: (rank.get(kv[0][0], 99), kv[0][1])):
        names = dict(BETTABLE)
        names.update(snap.get("names") or {})
        reads.append(Read(alias=snap.get("alias") or league, label=label.get(league, snap.get("alias") or league),
                          fetched_at=snap["fetched_at"], markets=markets, events=snap.get("events") or {},
                          names=names))
    return reads, False


def from_history(folder, bettable, now: float, show_for: float = SHOW_FOR) -> dict:
    """The screen from what refreshes left on this Mac. Reads files; touches no
    network and no key."""
    reads, older = history_reads(folder, now, show_for)
    if not reads:
        return {"has_odds": False, "grids": [], "leagues": [], "markets": [], "now": now,
                "message": TOO_OLD if older else NONE_YET}
    return build(reads, bettable, now, show_for)
