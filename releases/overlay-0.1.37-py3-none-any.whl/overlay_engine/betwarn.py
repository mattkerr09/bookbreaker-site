"""Bet warnings: what a play on the board runs into among the bets you already have open on this Mac.

OddsJam has three Bet Warnings switches (same game, conflicting, previously placed). The same idea here, worked
out by the engine against the person's own ledger and nothing else:

  * **already placed**: an open bet on the same game, market and side (at any book: a second Over 219 at another
    book is still the same bet twice);
  * **conflicting**: an open bet on the other side of the same market. Together the two hedge each other. That is
    what an arb you meant is, so it is said plainly and never blocked;
  * **same game**: an open bet on the same game in another market, or on the same side at another line. Bets on
    one game tend to win or lose together.

**A warning is a sentence and never a filter.** Every play stays on the board with its warnings; the window
shows or hides a *kind* of warning by the person's switch, exactly as Recommended is shown or hidden by a flag,
so switching reads nothing and costs no credit. A warned play is never dropped here.

**An open bet is one with no result yet.** The ledger is opened read-only and never created: a new install has no
ledger, which means no open bets, which means nothing to warn about.

**Some bets and some plays cannot be matched, and the engine says so.** A bet read in from a book's export may carry
no game (`import:...`), and a Live prices pair (Kalshi against Polymarket US) comes from venues that share no game
id with the ledger. Neither is guessed at by name: a warning that could be wrong in either direction is worse than
the sentence "no warning could be checked".
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from .odds import decimal_to_american
from .screen import book_name, parse_key, side_label

CODES = ("placed", "conflict", "game")

#: The three switches, in the engine's words. The window shows `label` on the row and beside the switch.
SWITCHES = [
    {"code": "placed", "label": "Already placed",
     "note": "An open bet of yours is on this game, market and side, so this play would place it a second time."},
    {"code": "conflict", "label": "Conflicting",
     "note": "An open bet of yours is on the other side of this market. The two would hedge each other, which "
             "is fine if you meant it."},
    {"code": "game", "label": "Same game",
     "note": "An open bet of yours is on this game in another market, or on the same side at another line. "
             "Bets on one game tend to win or lose together."},
]

#: At most this many warnings of one kind are listed on one play; the rest are counted in one more line.
MAX_PER_CODE = 3

_MARKET_WORDS = {"h2h": "moneyline", "moneyline": "moneyline", "spreads": "spread", "totals": "total"}

UNCHECKED_PAIR = ("This pair comes from Kalshi and Polymarket US, which carry no game id that matches your saved "
                  "bets, so no warning could be checked for it.")


# ---------------------------------------------------------------------------------------------------- the bets

def open_bets(path) -> tuple:
    """`(bets, readable)`: the person's open bets, read from the ledger file without opening it for writing.

    A missing ledger is a new install: no bets, readable. A ledger that cannot be read gives `([], False)` so the
    board says it could not check and does not say there was nothing to find."""
    p = Path(path)
    if not p.exists():
        return [], True
    try:
        con = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        try:
            con.row_factory = sqlite3.Row
            base = ("SELECT b.id, b.event_id, b.market_type, b.outcome, b.book, b.decimal_odds, b.stake, "
                    "{sel} FROM bets b {join} WHERE b.profit IS NULL ORDER BY b.id")
            try:
                rows = con.execute(base.format(sel="l.selection AS selection",
                                               join="LEFT JOIN bet_labels l ON l.bet_id = b.id")).fetchall()
            except sqlite3.OperationalError:       # a ledger from before bets were labelled
                rows = con.execute(base.format(sel="NULL AS selection", join="")).fetchall()
            return [dict(r) for r in rows], True
        finally:
            con.close()
    except (sqlite3.Error, OSError):
        return [], False


def _has_game(bet: dict) -> bool:
    event = str(bet.get("event_id") or "")
    return bool(event) and not event.startswith("import:")


# ---------------------------------------------------------------------------------------------------- the words

def _market_word(market: str) -> str:
    if market in _MARKET_WORDS:
        return _MARKET_WORDS[market]
    from .oddsapi import PROP_LABELS
    return str(PROP_LABELS.get(market) or market.replace("_", " ")).lower()


def _signed(american: int) -> str:
    return f"+{american}" if american > 0 else f"{american}"


def _held(bet: dict, names: dict) -> str:
    """One open bet, the way the person would say it: what, where, at what price, for how much."""
    what = bet.get("selection") or side_label(bet["outcome"], bet["market_type"])
    price = _signed(round(decimal_to_american(float(bet["decimal_odds"]))))
    return (f"{what} on the {_market_word(bet['market_type'])} at {book_name(bet['book'], names)}, "
            f"{price}, ${float(bet['stake']):,.2f}")


def _split(key: str) -> tuple:
    """`(subject, side, line)` of a side's key. A prop's subject is the player ("LeBron James Over" is the player
    LeBron James on the Over); in a team market the side is the team and there is no subject."""
    name, line = parse_key(key)
    low = name.strip().lower()
    for word in ("over", "under"):
        if low == word:
            return "", word, line
        if low.endswith(" " + word):
            return low[: -len(word)].strip(), word, line
    return "", low, line


def _relation(bet_key: str, leg_key: str) -> str:
    """How an open bet's side stands to a play's side in the same market: `placed` (same side, same line),
    `conflict` (the other side), `line` (the same side at another line) or `other` (another player)."""
    b_sub, b_side, b_line = _split(bet_key)
    l_sub, l_side, l_line = _split(leg_key)
    if b_sub != l_sub:
        return "other"
    if b_side == l_side:
        return "placed" if b_line == l_line else "line"
    return "conflict"


# ---------------------------------------------------------------------------------------------------- one play

def game_of(row: dict):
    """The game a play is on, as the ledger names it, or None when the play comes from a source with no game id."""
    legs = row.get("legs") or []
    if row.get("cross") or (legs and "venue" in legs[0] and "book" not in legs[0]):
        return None
    return row.get("event_id") or row.get("event") or None


def unchecked(why: str = UNCHECKED_PAIR) -> dict:
    """The block for a play that could not be checked, and why."""
    return {"checked": False, "items": [], "why": why}


def warn_row(row: dict, bets: list, names: dict | None = None) -> dict:
    """The block a play carries: `{"checked": True, "items": [...]}`, each item `{code, text, bet_id}`; or
    `{"checked": False, "items": [], "why": ...}` for a play whose game cannot be matched to the ledger."""
    names = names or {}
    event = game_of(row)
    if event is None:
        return unchecked()
    market = str(row.get("market", ""))
    legs = [(str(leg.get("outcome", "")), str(leg.get("book", ""))) for leg in row.get("legs") or []]
    found: list = []
    for bet in bets:
        if str(bet["event_id"]) != str(event):
            continue
        held = _held(bet, names)
        ident = f"bet {bet['id']}: {held}"
        here: list = []
        rels = []
        if bet["market_type"] == market:
            for key, book in legs:
                how = _relation(bet["outcome"], key)
                rels.append(how)
                at = f"{side_label(key, market)} at {book_name(book, names)}"
                if how == "placed":
                    here.append({"code": "placed", "text": (
                        f"You already have this bet open ({ident}); this play's {at} would place it a second "
                        "time.")})
                elif how == "conflict":
                    here.append({"code": "conflict", "text": (
                        f"This play's {at} is the other side of your open bet {bet['id']} ({held}); the two "
                        "together hedge each other, which is fine if you meant that.")})
        if not here:
            if "line" in rels:
                text = (f"You also have an open bet on the same side of this market at another line ({ident}); "
                        "the two tend to win or lose together.")
            elif rels:
                text = (f"You also have an open bet on this game, on another player in the same kind of market "
                        f"({ident}); bets on one game tend to win or lose together.")
            else:
                text = (f"You also have an open bet on this game in another market ({ident}); bets on one game "
                        "tend to win or lose together.")
            here.append({"code": "game", "text": text})
        found += [{**x, "bet_id": int(bet["id"])} for x in here]
    items: list = []
    for code in CODES:
        mine = [x for x in found if x["code"] == code]
        items += mine[:MAX_PER_CODE]
        if len(mine) > MAX_PER_CODE:
            left = len(mine) - MAX_PER_CODE
            items.append({"code": code, "bet_id": None, "more": left,
                          "text": f"{left} more of your open bets match this warning too. They are on My bets."})
    return {"checked": True, "items": items}


# ---------------------------------------------------------------------------------------------------- one board

def _plays(n: int) -> str:
    return f"{n} play{'s' if n != 1 else ''}"


def _count_sentence(code: str, n: int) -> str:
    if code == "placed":
        return f"{_plays(n)} would repeat a bet you already have open."
    if code == "conflict":
        return f"{_plays(n)} {'takes' if n == 1 else 'take'} the other side of a bet you have open."
    return f"{_plays(n)} {'is' if n == 1 else 'are'} on a game you have another open bet in."


def attach(rows: list, ledger_path, names: dict | None = None) -> dict:
    """Put a `warnings` block on every play (dicts, in place) and return the board's summary.

    Nothing is removed or reordered, and the ledger is only read. The summary is `{switches, checked, open_bets,
    sentence, by_code}`; `by_code` holds one engine sentence per kind of warning that at least one play carries."""
    bets, readable = open_bets(ledger_path)
    blocks = []
    for row in rows:
        block = warn_row(row, bets, names) if readable else unchecked(
            "Your saved bets could not be read, so no warning was checked.")
        row["warnings"] = block
        blocks.append(block)
    n = len(bets)
    homeless = sum(1 for b in bets if not _has_game(b))
    cannot = sum(1 for b in blocks if not b["checked"])
    if not readable:
        sentence = "Your saved bets could not be read, so no warning was checked on this board."
    elif not n:
        sentence = "You have no open bets saved on this Mac, so there is nothing to warn about."
    else:
        sentence = f"Checked against your {n} open bet{'s' if n != 1 else ''} saved on this Mac."
        if homeless:
            sentence += (f" {homeless} of them came in without a game, so {'it' if homeless == 1 else 'they'} cannot "
                         "be matched to a play.")
    if readable and cannot:
        sentence += (f" {_plays(cannot)} come{'s' if cannot == 1 else ''} from a source with no game id, so no "
                     "warning could be checked for " + ("it." if cannot == 1 else "them."))
    by = []
    for code in CODES:
        count = sum(1 for b in blocks if any(i["code"] == code for i in b["items"]))
        if count:
            by.append({"code": code, "count": count, "sentence": _count_sentence(code, count)})
    return {"switches": [dict(s) for s in SWITCHES], "checked": readable, "open_bets": n, "sentence": sentence,
            "by_code": by}
