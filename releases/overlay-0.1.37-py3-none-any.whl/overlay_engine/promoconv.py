"""Convert my own promo: a promotion the person already holds, turned into a plan.

The Promos page prices every book's welcome offer from the offers feed. This is the
other half of that screen, the one a person with a bonus bet in their account asks
for: *I have this promo at this book, what do I do with it and what is it worth?*
It answers with three things, all from the engine:

  1. what the promo is worth, labelled the way the Promos cards label it. A bonus bet
     hedged at two real prices keeps the same amount whichever side wins, so it is a
     locked amount (if both bets are accepted and stand). A refund that arrives as
     bonus bets, a profit boost no pair can lock, and a deposit match are averages and
     are called that.
  2. the two outcomes, with the cash kept in each.
  3. the pair of bets: the best one in the odds the person's own Odds API key has
     already read on this Mac, or, when none has been read, the stakes at a stated
     example price and a sentence saying so.

**It never fetches.** It reads `oddshistory`, the record of the person's last press of
Live sportsbook odds, exactly as Ask's board and goal tools do. A converter that spent
Odds API credits every time someone changed a number would be a different product.

**The example price is a prior, and says so.** With no read, the promo bet is placed at
the same +300 and the hedge found at the same 2% two-book margin the Promos cards use
(`welcome.PRIOR_*`), imported rather than retyped so the two cannot drift.

**Longshots are limited, in the open.** A bonus bet converts best at the longest
price and needs the biggest hedge there, and a table sorted by profit alone puts a
+960 against a -501 on top. The pair is chosen between -200 and +500 for the promo
bet (`PRICE_MIN`, `PRICE_MAX`), and `max_hedge` drops any pair whose hedge is more
than the person can place.
"""

from __future__ import annotations

import math
import statistics
import time
from pathlib import Path

from . import oddshistory, promo, welcome
from .odds import decimal_to_american

KINDS = {
    "bonus_bet": "Bonus bet",
    "refund": "No-sweat or second-chance bet",
    "boost": "Profit boost",
    "deposit_match": "Deposit match",
}

#: The promo bet's decimal price is kept between -200 and +500: the shortest a bonus
#: bet is usually allowed to be placed at, and the longest before the hedge it needs is
#: more than most people can put on a second book.
PRICE_MIN = 1.5
PRICE_MAX = 6.0

#: A read older than this is not a pair to place bets from. The same twelve hours Ask's
#: goal tool allows before it says there is nothing recent.
MAX_AGE = 12 * 3600.0

#: Past this the pair is still shown, with a line saying how old the prices are.
FRESH = 6 * 3600.0

#: PRIOR. What a deposit match's playthrough costs per dollar: a -110 / -110 market's
#: hold, the engine's own default in `promo.deposit_match_value`.
PRIOR_PLAYTHROUGH_HOLD = 0.045

NO_READ = ("No live sportsbook odds have been read on this Mac yet, so these stakes use an "
           "example price. With your own Odds API key (Odds source page), pressing Live "
           "sportsbook odds on the Arbitrage page reads real prices, and Bookbreaker would then "
           "find a real pair here. This page never fetches odds and never spends your credits.")


class PromoError(ValueError):
    """The promo could not be priced as asked; the message is the sentence the person sees."""


def _money(x: float) -> str:
    return f"{x:,.2f}"


def _american(decimal: float) -> int:
    return int(round(decimal_to_american(decimal)))


def _family(book: str) -> str:
    """Hard Rock posts one price per state under four keys; they are one operator."""
    return "hardrockbet" if str(book).startswith("hardrockbet") else str(book)


def _finite(value, *, low: float, high: float, what: str) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError):
        raise PromoError(f"Type {what} as a number.") from None
    if not math.isfinite(x) or not low <= x <= high:
        raise PromoError(f"Type {what} between {low:g} and {high:,.0f}.")
    return x


# ------------------------------------------------------------ the person's recorded odds

def _two_way_markets(snaps: list, now: float) -> list:
    """Every market in the recorded odds with exactly two sides, each side's newest price
    by book. Three-way markets (a draw) cannot be hedged with one bet and are left out, and
    so is any game that has started since the read."""
    from . import oddsapi

    out = []
    for snap in snaps:
        events = snap.get("events", {})
        for mkt in oddsapi.split_by_line(oddshistory.to_markets(snap)):
            if mkt.starts_at is not None and mkt.starts_at <= now:
                continue
            sides: dict = {}
            for q in mkt.quotes:
                key = (q.outcome.name, q.outcome.line)
                book = sides.setdefault(key, {})
                if q.book not in book or q.seen_at > book[q.book].seen_at:
                    book[q.book] = q
            if len(sides) != 2:
                continue
            out.append({
                "league": str(snap.get("alias", "")).upper(),
                "game": events.get(str(mkt.event_id), {}).get("label") or str(mkt.event_id),
                "market": mkt.market_type, "starts": mkt.starts_at, "read_at": snap["fetched_at"],
                "sides": [(key, {b: q.decimal for b, q in books.items()}) for key, books in sides.items()],
            })
    return out


def _side_label(market: str, name: str, line) -> str:
    if line is None:
        return str(name)
    return f"{name} {line:g}" if market == "totals" else f"{name} {line:+g}"


_MARKET_NAME = {"h2h": "Moneyline", "spreads": "Spread", "totals": "Total"}


def _candidates(book: str, snaps: list, now: float, bettable=None) -> list:
    """Every way to put a promo bet at `book` on one side of a two-way market and a hedge on
    the other at the best price any other bettable book posts. Prices outside
    PRICE_MIN..PRICE_MAX are not candidates."""
    from . import oddsapi

    out = []
    for m in _two_way_markets(snaps, now):
        for i in (0, 1):
            (pkey, pbooks), (hkey, hbooks) = m["sides"][i], m["sides"][1 - i]
            mine = [(b, d) for b, d in pbooks.items() if _family(b) == _family(book)]
            others = [(b, d) for b, d in hbooks.items()
                      if _family(b) != _family(book) and b in (oddsapi.BETTABLE if bettable is None else bettable)]
            if not mine or not others:
                continue
            pb, pd = max(mine, key=lambda t: t[1])
            hb, hd = max(others, key=lambda t: t[1])
            if not PRICE_MIN <= pd <= PRICE_MAX or hd <= 1.0:
                continue
            # The chance of the promo side: each book that prices both sides, devigged
            # on its own, then the middle of them. Never one book's price against another's.
            shares = [(1.0 / pbooks[b]) / (1.0 / pbooks[b] + 1.0 / hbooks[b])
                      for b in pbooks if b in hbooks]
            out.append({
                "m": m, "promo_book": pb, "promo_dec": pd, "promo_side": _side_label(m["market"], *pkey),
                "hedge_book": hb, "hedge_dec": hd, "hedge_side": _side_label(m["market"], *hkey),
                "chance": statistics.median(shares) if shares else None,
                "n_books": len(shares),
            })
    return out


def _name(book: str) -> str:
    """A book's name. The window's one "Hard Rock Bet" is the operator; the feed's four keys are its states."""
    from . import oddsapi
    return "Hard Rock Bet" if book == "hardrockbet" else oddsapi.BETTABLE.get(book, book)


def _leg(book: str, side: str, decimal: float, stake: float, *, bonus: bool = False) -> dict:
    return {"book": book, "book_name": _name(book) if book else "", "side": side,
            "american": _american(decimal), "decimal": round(decimal, 4),
            "stake": round(stake, 2), "bonus": bonus}


# ------------------------------------------------------------ the two-bet arithmetic

def _boosted_decimal(stake: float, decimal: float, boost: float, max_win: float | None) -> float:
    """The price the boosted bet pays: the boost on the profit, within the cap on winnings."""
    profit = stake * (decimal - 1.0)
    boosted = profit * (1.0 + boost)
    if max_win is not None:
        boosted = max(profit, min(boosted, max_win))
    return 1.0 + boosted / stake


def _hedge_plan(kind: str, amount: float, promo_dec: float, hedge_dec: float):
    """(exact hedge, floor_for(h), exact floor) for a bonus bet (the stake is not yours and
    is not returned) or a cash bet at its boosted price."""
    if kind == "bonus_bet":
        won = amount * (promo_dec - 1.0)
        exact = won / hedge_dec

        def floor_for(h: float) -> float:
            return min(won - h, h * (hedge_dec - 1.0))
    else:
        won = amount * (promo_dec - 1.0)
        exact = amount * promo_dec / hedge_dec

        def floor_for(h: float) -> float:
            return min(won - h, h * (hedge_dec - 1.0) - amount)
    return exact, floor_for, floor_for(exact)


def _rank_pairs(kind: str, amount: float, cands: list, boost: float | None,
                max_win: float | None, max_hedge: float | None) -> list:
    """Candidates with their rounded hedge and the amount kept, best first."""
    ranked = []
    for c in cands:
        eff = c["promo_dec"] if kind == "bonus_bet" else _boosted_decimal(amount, c["promo_dec"], boost, max_win)
        exact, floor_for, exact_floor = _hedge_plan(kind, amount, eff, c["hedge_dec"])
        if exact_floor <= 0:
            continue
        h, floor, _ = welcome.human_stake(exact, floor_for, exact_floor)
        if max_hedge is not None and h > max_hedge:
            continue
        ranked.append(dict(c, eff=eff, hedge_stake=h, floor=floor, exact_floor=exact_floor))
    ranked.sort(key=lambda r: (r["floor"], r["exact_floor"]), reverse=True)
    return ranked


def _hedged_outcomes(kind: str, amount: float, eff: float, hedge_dec: float, h: float) -> list:
    if kind == "bonus_bet":
        win_p, lose_p = amount * (eff - 1.0), 0.0
        notes = ("A bonus bet pays only its winnings, not its stake.",
                 "The bonus bet is used up, and it cost you no cash.")
        names = ("If the bonus bet wins", "If the hedge wins")
    else:
        win_p, lose_p = amount * (eff - 1.0), -amount
        notes = ("The boost is paid on the winnings.", "Your stake on the boosted bet is lost.")
        names = ("If the boosted bet wins", "If the hedge wins")
    win_h, lose_h = -h, h * (hedge_dec - 1.0)
    return [
        {"name": names[0], "from_promo": round(win_p, 2), "from_hedge": round(win_h, 2),
         "kept": round(win_p + win_h, 2), "note": notes[0]},
        {"name": names[1], "from_promo": round(lose_p, 2), "from_hedge": round(lose_h, 2),
         "kept": round(lose_p + lose_h, 2), "note": notes[1]},
    ]


# ------------------------------------------------------------ the answer

def _read(history: Path | None, now: float) -> tuple[list, str, float | None]:
    """(snapshots, what to say if none are usable, read_at of the newest)."""
    folder = history if history is not None else oddshistory.history_folder()
    every = oddshistory.latest(folder, now=now)
    if not every:
        return [], NO_READ, None
    snaps = oddshistory.latest(folder, now=now, max_age=MAX_AGE)
    if not snaps:
        newest = max(s["fetched_at"] for s in every)
        return [], (f"Live sportsbook odds were last read {(now - newest) / 3600:.0f} hours ago, which is too "
                    "old to pair bets from, so these stakes use an example price. Press Live sportsbook odds on "
                    "the Arbitrage page to read them again."), newest
    return snaps, "", max(s["fetched_at"] for s in snaps)


def convert(kind: str, book: str, amount: float, *, boost_pct: float | None = None,
            max_win: float | None = None, match_pct: float | None = None,
            rollover: float | None = None, max_hedge: float | None = None,
            history: Path | None = None, now: float | None = None, state: str | None = None) -> dict:
    """The converter's whole answer for one promo. Raises PromoError with a plain sentence.

    `state` (two letters) keeps every hedge at a sportsbook licensed there (`oddsapi.bettable_in`)."""
    from . import oddsapi

    now = time.time() if now is None else now
    if kind not in KINDS:
        raise PromoError("Pick a promo type: bonus bet, no-sweat bet, profit boost or deposit match.")
    book = str(book or "")
    if kind != "deposit_match" and book not in oddsapi.BETTABLE:
        raise PromoError("Pick the sportsbook the promo is at.")
    amount = _finite(amount, low=1.0, high=1_000_000.0, what="the amount")
    boost = None
    if kind == "boost":
        if boost_pct is None:
            raise PromoError("Type the boost as a percentage, like 50.")
        boost = _finite(boost_pct, low=0.1, high=500.0, what="the boost percentage") / 100.0
        if max_win is not None:
            max_win = _finite(max_win, low=0.01, high=10_000_000.0, what="the max winnings")
    if max_hedge is not None:
        max_hedge = _finite(max_hedge, low=1.0, high=10_000_000.0, what="the most you can hedge")

    out = {"command": "promo", "type": kind, "type_name": KINDS[kind], "book": book,
           "book_name": _name(book) if book else "", "amount": round(amount, 2)}

    if kind == "deposit_match":
        out.update(_deposit_match(amount, match_pct, rollover))
        return out

    snaps, why_not, read_at = _read(history, now)
    cands = _candidates(book, snaps, now, oddsapi.bettable_in(state)) if snaps else []
    out["books_for"] = oddsapi.books_for(state)
    if snaps and not cands:
        why_not = (f"The last read of live sportsbook odds has no game with a {out['book_name']} price between "
                   f"{_american(PRICE_MIN)} and +{_american(PRICE_MAX)} and a second book on the other side, so "
                   "these stakes use an example price.")

    if kind in ("bonus_bet", "boost"):
        ranked = _rank_pairs(kind, amount, cands, boost, max_win, max_hedge)
        if not ranked and cands and max_hedge is not None and _rank_pairs(kind, amount, cands, boost, max_win, None):
            why_not = (f"No pair in your last read of live sportsbook odds needs a hedge of ${_money(max_hedge)} "
                       "or less, so these stakes use an example price.")
            cands = []
        if ranked:
            best = ranked[0]
            pair = _pair_from_feed(kind, amount, best, len(cands), read_at, now)
            return _hedged(out, kind, amount, boost, max_win, best["eff"], best["hedge_dec"], best["hedge_stake"],
                           pair, assumptions=_feed_line(read_at, now))
        # No feed pair locks it: a boost then falls back to its average; a bonus bet is
        # shown at the example price.
        if kind == "boost" and cands:
            return _boost_average(out, amount, boost, max_win, cands, read_at, now)
        return _example(out, kind, amount, boost, max_win, why_not, max_hedge)

    # A refund is an average whatever the prices are.
    return _refund(out, amount, [c for c in cands if c["chance"] is not None], read_at, now, why_not)


def _feed_line(read_at: float, now: float) -> str:
    age = max(0.0, now - read_at)
    when = f"{age / 60:.0f} minutes ago" if age < 3600 else f"{age / 3600:.1f} hours ago"
    stale = (" Prices move: check both before you bet." if age <= FRESH else
             " That is a while ago, so treat the pair as a place to look and check both prices before you bet.")
    return f"Prices from your last read of live sportsbook odds, {when}.{stale}"


def _pair_from_feed(kind: str, amount: float, best: dict, considered: int, read_at: float, now: float) -> dict:
    m = best["m"]
    return {
        "source": "feed", "example": False, "league": m["league"], "game": m["game"],
        "market": _MARKET_NAME.get(m["market"], m["market"]), "starts": m["starts"],
        "promo": _leg(best["promo_book"], best["promo_side"], best["promo_dec"], amount, bonus=kind == "bonus_bet"),
        "hedge": _leg(best["hedge_book"], best["hedge_side"], best["hedge_dec"], best["hedge_stake"]),
        "considered": considered, "read_at": read_at, "age_seconds": round(max(0.0, now - read_at)),
        "why": ("Of the pairs in your last read it keeps the most once the hedge is rounded to a stake a book "
                "will see as ordinary. A longer price keeps a bigger share of the promo and needs a bigger "
                f"hedge, so pairs are limited to {_american(PRICE_MIN)} to +{_american(PRICE_MAX)} on the promo bet."),
    }


def _hedged(out: dict, kind: str, amount: float, boost, max_win, eff: float, hedge_dec: float, h: float,
            pair: dict, *, assumptions: str, extra: str = "") -> dict:
    outcomes = _hedged_outcomes(kind, amount, eff, hedge_dec, h)
    kept = min(o["kept"] for o in outcomes)
    if kind == "bonus_bet":
        caption = f"locked from ${_money(amount)} in bonus if both bets are accepted and stand"
        face = amount
    else:
        caption = f"locked on a ${_money(amount)} bet boosted {boost * 100:g}% if both bets are accepted and stand"
        face = amount
    out.update({
        "worth": {"locked": True, "amount": kept, "face": round(face, 2), "caption": caption,
                  "rate": round(kept / face, 4) if face else 0.0},
        "outcomes": outcomes, "pair": pair,
        "assumptions": assumptions,
        "notes": [welcome.KEEP_THE_ACCOUNT,
                  "Check the offer's own terms before you place either bet: the minimum odds it allows, "
                  "the markets it counts, and the day it ends. Both books must also be open to you where you bet."]
                 + ([extra] if extra else []),
    })
    return out


def _prior_chance() -> float:
    return (1.0 / welcome.PRIOR_BONUS_DECIMAL) / (1.0 + welcome.PRIOR_TWO_BOOK_HOLD)


def _prior_conversion() -> float:
    hedge = welcome.hedge_decimal(welcome.PRIOR_BONUS_DECIMAL, welcome.PRIOR_TWO_BOOK_HOLD)
    return promo.bonus_bet_conversion(welcome.PRIOR_BONUS_DECIMAL, hedge, 1.0).guaranteed


def _example_line() -> str:
    hedge = welcome.hedge_decimal(welcome.PRIOR_BONUS_DECIMAL, welcome.PRIOR_TWO_BOOK_HOLD)
    return (f"Example price, a prior and not a quote: the promo bet at +{_american(welcome.PRIOR_BONUS_DECIMAL)}, "
            f"the hedge at {_american(hedge)}, about {welcome.PRIOR_TWO_BOOK_HOLD:.0%} margin across two books.")


def _example(out: dict, kind: str, amount: float, boost, max_win, why_not: str, max_hedge=None) -> dict:
    dec = welcome.PRIOR_BONUS_DECIMAL
    hedge = welcome.hedge_decimal(dec, welcome.PRIOR_TWO_BOOK_HOLD)
    eff = dec if kind == "bonus_bet" else _boosted_decimal(amount, dec, boost, max_win)
    exact, floor_for, exact_floor = _hedge_plan(kind, amount, eff, hedge)
    if exact_floor <= 0:
        # A boost too small to beat the margin between two books: nothing to lock.
        return _boost_average(out, amount, boost, max_win, [], None, None, why_not=why_not)
    h, _, _ = welcome.human_stake(exact, floor_for, exact_floor)
    pair = {
        "source": "example", "example": True, "league": "", "game": "", "market": "", "starts": None,
        "promo": _leg("", "the side you pick", dec, amount, bonus=kind == "bonus_bet"),
        "hedge": _leg("", "the other side", hedge, h),
        "considered": 0, "read_at": None, "age_seconds": None,
        "why": why_not,
    }
    pair["promo"]["book_name"] = out["book_name"]
    pair["hedge"]["book_name"] = "a second book"
    extra = (f"At this example price the hedge is ${_money(h)}, more than the ${_money(max_hedge)} you can place. "
             "A shorter price on the promo bet needs a smaller hedge, and keeps less." if max_hedge is not None and h > max_hedge else "")
    return _hedged(out, kind, amount, boost, max_win, eff, hedge, h, pair, assumptions=_example_line(), extra=extra)


def _boost_average(out: dict, amount: float, boost: float, max_win, cands: list, read_at, now,
                   why_not: str = "") -> dict:
    """A boost no pair locks: the boosted bet on its own, at the best price at the book."""
    if cands:
        usable = [c for c in cands if c["chance"] is not None]
        best = max(usable or cands, key=lambda c: promo.profit_boost_value(
            amount, c["promo_dec"], c["chance"] if c["chance"] is not None else _prior_chance(), boost, max_win).expected)
        dec, q = best["promo_dec"], best["chance"] if best["chance"] is not None else _prior_chance()
        where = {"league": best["m"]["league"], "game": best["m"]["game"],
                 "market": _MARKET_NAME.get(best["m"]["market"], best["m"]["market"]), "side": best["promo_side"],
                 "book": best["promo_book"]}
        line = _feed_line(read_at, now)
        why = ("No pair in your last read keeps a profit once the boosted bet is hedged, so this is the boosted bet "
               "on its own at the price that is worth most.")
        src = "feed"
    else:
        dec, q = welcome.PRIOR_BONUS_DECIMAL, _prior_chance()
        where = {"league": "", "game": "", "market": "", "side": "the side you pick", "book": out["book"]}
        line = _example_line()
        why = why_not or "The boost is too small to beat the margin between two books, so it cannot be hedged to a profit."
        src = "example"
    v = promo.profit_boost_value(amount, dec, q, boost, max_win)
    eff = _boosted_decimal(amount, dec, boost, max_win)
    win = amount * (eff - 1.0)
    out.update({
        "worth": {"locked": False, "amount": round(v.expected, 2), "face": round(win, 2),
                  "caption": "expected on average. A boost cannot be hedged to a fixed amount.",
                  "rate": None},
        "outcomes": [
            {"name": "If the boosted bet wins", "from_promo": round(win, 2), "kept": round(win, 2),
             "note": "The boost is paid on the winnings."},
            {"name": "If it loses", "from_promo": round(-amount, 2), "kept": round(-amount, 2),
             "note": "The whole stake is lost."}],
        "pair": {"source": src, "example": src == "example", "league": where["league"], "game": where["game"],
                 "market": where["market"], "starts": None,
                 "promo": _leg(where["book"], where["side"], dec, amount),
                 "hedge": None, "considered": len(cands), "read_at": read_at,
                 "age_seconds": None if read_at is None else round(max(0.0, now - read_at)), "why": why},
        "chance": round(q, 4),
        "assumptions": f"{line} The chance of winning is {q:.1%}: " + (
            "the middle of the books' own no-vig prices." if cands else "a prior from that price and margin."),
        "notes": [v.note, "Check the offer's own terms before you place the bet: the minimum odds it allows, "
                          "the markets it counts, and the day it ends."],
    })
    out["pair"]["promo"]["book_name"] = out["pair"]["promo"]["book_name"] or out["book_name"]
    return out


def _refund(out: dict, amount: float, cands: list, read_at, now, why_not: str) -> dict:
    conv = _prior_conversion()
    if cands:
        best = max(cands, key=lambda c: promo.safety_net_value(
            amount, c["promo_dec"], c["chance"], conv).expected)
        dec, q = best["promo_dec"], best["chance"]
        m = best["m"]
        where = {"league": m["league"], "game": m["game"], "market": _MARKET_NAME.get(m["market"], m["market"]),
                 "side": best["promo_side"], "book": best["promo_book"]}
        line, src = _feed_line(read_at, now), "feed"
        why = ("Of the prices at this book in your last read it is worth the most: a refund pays when the bet loses, "
               f"and a longer price loses more often and pays more when it wins. Limited to {_american(PRICE_MIN)} "
               f"to +{_american(PRICE_MAX)}.")
    else:
        dec, q = welcome.PRIOR_BONUS_DECIMAL, _prior_chance()
        where = {"league": "", "game": "", "market": "", "side": "the side you pick", "book": out["book"]}
        line, src = _example_line(), "example"
        why = why_not
    v = promo.safety_net_value(amount, dec, q, conv)
    win = amount * (dec - 1.0)
    back = amount * conv
    out.update({
        "worth": {"locked": False, "amount": round(v.expected, 2), "face": round(amount, 2),
                  "caption": "expected on average. It only pays if your first bet loses, so it cannot be locked in.",
                  "rate": None},
        "outcomes": [
            {"name": "If the promo bet wins", "from_promo": round(win, 2), "kept": round(win, 2),
             "note": "You are paid in cash and the refund is not needed."},
            {"name": "If it loses", "from_promo": round(-amount, 2), "from_refund": round(back, 2),
             "kept": round(back - amount, 2),
             "note": f"The book refunds the stake in bonus bets, which convert to about {conv:.0%} of their face."}],
        "pair": {"source": src, "example": src == "example", "league": where["league"], "game": where["game"],
                 "market": where["market"], "starts": None,
                 "promo": _leg(where["book"], where["side"], dec, amount),
                 "hedge": None, "considered": len(cands), "read_at": read_at,
                 "age_seconds": None if read_at is None else round(max(0.0, now - read_at)), "why": why},
        "chance": round(q, 4),
        "assumptions": (f"{line} The chance of winning is {q:.1%}: " + (
            "the middle of the books' own no-vig prices. " if cands else "a prior from that price and margin. ")
            + f"A refund in bonus bets converts at about {conv:.0%} (a prior)."),
        "notes": [v.note, "Check the offer's own terms before you place the bet: the minimum odds it allows, "
                          "whether the refund is bonus bets or cash, and the day it ends."],
    })
    out["pair"]["promo"]["book_name"] = out["pair"]["promo"]["book_name"] or out["book_name"]
    return out


def _deposit_match(deposit: float, match_pct, rollover) -> dict:
    if match_pct is None:
        raise PromoError("Type the match as a percentage, like 100.")
    match = _finite(match_pct, low=1.0, high=1000.0, what="the match percentage")
    if rollover is None:
        raise PromoError("Type the playthrough from the offer's terms, like 10 for 10 times.")
    times = _finite(rollover, low=0.0, high=1000.0, what="the playthrough")
    bonus = deposit * match / 100.0
    v = promo.deposit_match_value(deposit, bonus, times, hold_per_bet=PRIOR_PLAYTHROUGH_HOLD)
    base = deposit + bonus
    return {
        "worth": {"locked": False, "amount": round(v.expected, 2), "face": round(bonus, 2),
                  "caption": "expected on average. This kind of offer cannot be locked in.", "rate": None},
        "outcomes": [],
        "pair": None,
        "deposit": round(deposit, 2), "bonus": round(bonus, 2), "rollover": times,
        "turnover": round(times * base, 2), "cost": round(v.cost, 2), "hold": PRIOR_PLAYTHROUGH_HOLD,
        "breakeven_hold": round(promo.breakeven_hold(deposit, bonus, times), 6),
        "assumptions": (f"Assumes the playthrough counts your deposit and the bonus together, and that you can "
                        f"churn it at a {PRIOR_PLAYTHROUGH_HOLD:.1%} hold (a prior: a -110 / -110 market). "
                        "Check the offer's terms for both."),
        "notes": [v.note],
    }
