"""When the window may show "Open this offer", and what goes beside it.

The CEO's guardrails (2026-10-13), held here so the window computes nothing:
  * a link only for a sportsbook licensed in the person's chosen state (the jurisdiction catalog, the same one the
    site uses), never an offshore book, never one that has left the US;
  * 21+ and the state's own helpline beside it (helplines.csv, copied from the site's table with its sources and
    read dates; the national 1-800-MY-RESET when a state names none);
  * a line on how Bookbreaker is paid, pointing to bookbreaker.bet/how-we-are-paid/. The app cannot know when a
    program approves bookbreaker.bet (that lives in the site's partners table), so it never says "not paid" or
    "may be paid" itself: it says where the true answer is, which stays true either way;
  * the link always goes through bookbreaker.bet/go/ (the shell builds it: ui/src-tauri/src/main.rs open_go), and
    only from the offer pages, never beside an arb, a +EV bet or hedge steps.
"""

from __future__ import annotations

import csv
from functools import lru_cache
from pathlib import Path

from .ask import HELPLINE
from .catalog import VENUES

#: The sportsbooks the shell will open (main.rs GO_BOOKS; a test holds the two lists equal).
GO_BOOKS = ("bally", "bet365", "betparx", "betrivers", "borgata", "caesars", "dk", "eagle", "fanatics", "fd",
            "firekeepers", "fourwinds", "hardrock", "mgm", "prime", "sportsbook-ri", "thescore")
LABEL = "Open this offer"
PAID = ("Links go through bookbreaker.bet. Whether Bookbreaker is paid for any of them is on "
        "bookbreaker.bet/how-we-are-paid/, which changes the day a program approves it.")
DATA = Path(__file__).parent / "data" / "helplines.csv"


@lru_cache(maxsize=1)
def _helplines() -> dict:
    with DATA.open(newline="") as f:
        return {r["state"].strip().upper(): r for r in csv.DictReader(f)}


def can_link(book: str, state: str | None) -> bool:
    """True when the window may show the button for `book` to someone in `state`."""
    st = (state or "").strip().upper()
    venue = VENUES.get(book)
    return bool(st) and book in GO_BOOKS and venue is not None and not venue.exited and venue.available_in(st)


def link(book: str, state: str | None) -> dict | None:
    st = (state or "").strip().upper()
    return {"book": book, "state": st, "label": LABEL} if can_link(book, st) else None


def compliance(state: str | None) -> dict | None:
    """What goes under the offers whenever a link can show: age, the state's helpline with its source, and the
    line on how Bookbreaker is paid."""
    st = (state or "").strip().upper()
    if not st:
        return None
    row = _helplines().get(st) or {}
    line = (row.get("line") or "").strip() or (row.get("gambler_wording") or "").strip()
    age = (row.get("min_age") or "21").strip() or "21"
    help_text = (f"{st}'s problem gambling helpline: {line}." if line
                 else f"National problem gambling helpline: {HELPLINE}.")
    return {"age": f"{age}+", "helpline": help_text, "helpline_source": row.get("source") or "",
            "helpline_read": row.get("read") or "", "national": HELPLINE, "paid": PAID,
            "text": f"{age}+ and in {st}. {help_text} {PAID}"}
