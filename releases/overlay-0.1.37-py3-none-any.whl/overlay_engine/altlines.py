"""Alternate lines: every spread and total a book posts for one game, as a ladder.

OddsJam opens an ALTERNATE LINES pane under a game on its screen: the same book columns, one row per line. This is
that, on the same footing as player props and futures: **off until asked for, one game at a time, the cost said
before the press, nothing read that was not picked.**

**Where they come from.** The Odds API lists `alternate_spreads` ("All available point spread outcomes for each
team") and `alternate_totals` ("All available over/under outcomes") as additional markets, which "need to be
accessed one event at a time" on `/v4/sports/{sport}/events/{eventId}/odds`
(https://the-odds-api.com/sports-odds-data/betting-markets.html, read 2026-10-13).

**What they cost.** The same rule as player props, which use the same endpoint (`oddsapi.PROPS_COST_RULE`):
unique markets returned x regions, for each request. One game is one request, so its alternate lines cost at most
(markets picked) x (regions picked) credits, and `estimate` says that number before anything is fetched. It is an
upper bound: a market no book posts is not returned and is not charged.

`read` asks for one game, once, and keeps the answer (the Odds API's own shape) with what it cost. It stops before
asking when the credits left are fewer than the bound, and flags a request charged more than the rule allows.
Turning the answer into a ladder comes next.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path

from .feed import FeedError
from .oddsapi import (_BY_ALIAS, DEFAULT_REGIONS, PROPS_COST_RULE, PROPS_COST_RULE_SOURCE, REGIONS, Cache,
                      OddsApiError, _pick, _problem)
from .restfeed import read_quota

#: The two ladders, by the Odds API's key, in plain words.
ALT_MARKETS: dict = {"alternate_spreads": "Alternate spreads", "alternate_totals": "Alternate totals"}
DEFAULT_ALT_MARKETS = ("alternate_spreads", "alternate_totals")

SOURCE = "https://the-odds-api.com/sports-odds-data/betting-markets.html (Additional Markets, read 2026-10-13)"
COST_RULE, COST_RULE_SOURCE = PROPS_COST_RULE, PROPS_COST_RULE_SOURCE

#: An Odds API event id: letters and digits only. Anything else is refused before it can reach a URL.
_EVENT_ID = re.compile(r"[A-Za-z0-9]{8,64}")


@dataclass(frozen=True)
class Estimate:
    """What reading one game's alternate lines will cost, worked out before anything is fetched."""

    league: str         # alias, like "nfl"
    event_id: str
    markets: tuple
    regions: tuple

    @property
    def credits(self) -> int:
        # THE RULE: unique markets x regions, for the one request this game needs.
        return len(self.markets) * len(self.regions)

    def sentence(self) -> str:
        what = " and ".join(ALT_MARKETS[m].lower() for m in self.markets)
        regions = " and ".join(REGIONS[r].split(",")[0].split(" (")[0] for r in self.regions)
        n = self.credits
        return (f"Reading this game's {what} costs up to {n} credit{'s' if n != 1 else ''} from your Odds API "
                f"allowance: {len(self.markets)} market{'s' if len(self.markets) != 1 else ''} x "
                f"{len(self.regions)} region{'s' if len(self.regions) != 1 else ''} ({regions}). A market no book "
                f"posts is not charged. Nothing is read until you press Read.")

    def as_dict(self) -> dict:
        return {"league": self.league, "event_id": self.event_id, "markets": list(self.markets),
                "regions": list(self.regions), "credits": self.credits, "sentence": self.sentence(),
                "rule": COST_RULE, "rule_source": COST_RULE_SOURCE, "source": SOURCE}


def estimate(league: str, event_id: str, markets=None, regions=None) -> Estimate:
    """Validate one game's choices and price them. No network, no key."""
    alias = str(league or "").strip().lower()
    if alias not in _BY_ALIAS:
        raise OddsApiError(f"{league!r} is not a league Bookbreaker knows. Choose from {', '.join(_BY_ALIAS)}.",
                           reason="bad_choice")
    event = str(event_id or "").strip()
    if not _EVENT_ID.fullmatch(event):
        raise OddsApiError("Pick a game from the Odds screen: that game's id is missing or not one the Odds API "
                           "uses.", reason="bad_choice")
    return Estimate(alias, event, _pick(markets, ALT_MARKETS, "alternate line market", DEFAULT_ALT_MARKETS),
                    _pick(regions, REGIONS, "region", DEFAULT_REGIONS))


@dataclass
class Read:
    """One game's alternate lines as the Odds API sent them, and what asking cost."""

    estimate: Estimate
    payload: dict = field(default_factory=dict)
    fetched_at: float = 0.0
    from_cache: bool = False
    credits: int | None = None      # x-requests-last; None when unknown or read from the cache
    remaining: int | None = None
    warning: str = ""               # set when the Odds API charged more than the rule allows


def read(est: Estimate, key: str, *, clock=None, cache: Cache | None = None, fetcher=None,
         remaining: int | None = None) -> Read:
    """Ask the Odds API for one game's alternate lines, once. Raises OddsApiError with a sentence, never the key.

    `remaining` is the credits left as last recorded on this Mac; a read that could cost more is refused before any
    request. A second press inside the cache's window reads the stored answer and spends nothing.
    """
    from .oddsapi import _BY_ALIAS as leagues, odds_api_fetcher

    clock = clock or time.time
    cache = cache or Cache()
    league = leagues[est.league]
    bound = est.credits
    if remaining is not None and remaining < bound:
        raise OddsApiError(f"Reading this game's alternate lines needs up to {bound} credits and you have "
                           f"{remaining} left this month.", reason="credits")
    tag = f"alt/{league.key}/{est.event_id}"
    entry = cache.get(tag, est.regions, est.markets, clock())
    if entry is not None:
        return Read(est, entry.payload[0], entry.fetched_at, from_cache=True, remaining=remaining)
    fetcher = fetcher or odds_api_fetcher()
    got_at = clock()
    try:
        payload, headers = fetcher(f"/v4/sports/{league.key}/events/{est.event_id}/odds",
                                   {"apiKey": key, "regions": ",".join(est.regions),
                                    "markets": ",".join(est.markets), "oddsFormat": "decimal",
                                    "dateFormat": "iso"})
        if not isinstance(payload, dict) or not isinstance(payload.get("bookmakers", []), list):
            raise FeedError("expected one game with a list of bookmakers")
    except Exception as exc:                         # noqa: BLE001
        raise _problem(exc, "this game's alternate lines") from None
    cache.put(tag, est.regions, est.markets, [payload], headers, got_at)
    quota = read_quota(headers)
    cache.remember(quota, got_at)
    out = Read(est, payload, got_at, credits=quota.last, remaining=quota.remaining)
    save(out)                                        # so the ladder reopens later for nothing
    if quota.last is not None and quota.last > bound:
        # The documented rule says this cannot happen. If it did, the rule is wrong or has changed.
        out.warning = (f"The Odds API charged {quota.last} credits for this game's alternate lines, and "
                       f"Bookbreaker's count allows {bound}. Check for a newer Bookbreaker before reading another.")
    return out


# ------------------------------------------------------------ the ladder

NOTE = ("Prices are as they were when read, and a book can change one at any moment. Check the price at the book "
        "before you bet. Pinnacle and the other reference books help set the fair price; you cannot bet at them "
        "from the US, so they are never marked best or +EV. Arbs and middles between alternate lines are not "
        "looked for yet.")


def _as_main(payload: dict) -> list:
    """The one game in the bulk endpoint's shape, with the two ladders under the main market keys, so the main
    parser (`restfeed.markets_from_payload`) reads them. Any other market in the answer is dropped."""
    rename = {"alternate_spreads": "spreads", "alternate_totals": "totals"}
    event = {k: v for k, v in payload.items() if k != "bookmakers"}
    event["bookmakers"] = [
        dict(b, markets=[dict(m, key=rename[m.get("key")]) for m in b.get("markets") or [] if m.get("key") in rename])
        for b in payload.get("bookmakers") or []]
    return [event]


def _pairs(market, home: str) -> list:
    """One two-sided market per line. A total pairs Over and Under at the same number; a spread pairs a team's line
    with the other team's opposite number (Chiefs -3.5 with Bills +3.5, never with Bills -3.5), keyed from the home
    team's side. A line only one side of which was priced is left out: it cannot be devigged."""
    from dataclasses import replace

    from .screen import parse_key
    groups: dict = {}
    for q in market.quotes:
        name, line = parse_key(q.outcome.key)
        if line is None:
            continue
        key = line if market.market_type == "totals" or name == home else -line
        groups.setdefault(round(key, 2), []).append(q)
    out = []
    for key in sorted(groups):
        quotes = groups[key]
        if len({q.outcome.key for q in quotes}) == 2:
            out.append((key, replace(market, quotes=quotes)))
    return out


def ladder(got: Read, *, now: float | None = None, state: str | None = None, formula=None, min_ev: float = 0.0,
           books: dict | None = None) -> dict:
    """The ladder the window draws for one game, from a read. Reads nothing. Every figure is the engine's.

    Each line is its own two-sided market: the cells, the best price (only at a book licensed in `state`), the fair
    price (the hold taken out of each book that priced both sides of that line, blended by the engine's weights or
    the person's EV formula), and +EV marks from the board's own test, kept only where the bet can be placed.
    """
    from dataclasses import replace

    from . import fair as fair_mod
    from .ev import find_edges
    from .oddsapi import BETTABLE, bettable_in, books_for, books_table, engine_book
    from .restfeed import markets_from_payload
    from .screen import _rows, american
    from .staleness import FillModel, LatencyModel

    now = time.time() if now is None else now
    books = books if books is not None else books_table()
    can = bettable_in(state)
    payload = got.payload
    home, away = str(payload.get("home_team") or ""), str(payload.get("away_team") or "")
    names = dict(BETTABLE)
    for b in payload.get("bookmakers") or []:
        raw = str(b.get("key") or "")
        names.setdefault(engine_book(raw), str(b.get("title") or raw))
    markets = []
    for m in markets_from_payload(_as_main(payload), got.estimate.league, got.fetched_at):
        markets.append(replace(m, quotes=[replace(q, book=engine_book(q.book)) for q in m.quotes]))
    sections = []
    seen_books: dict = {}
    for m in sorted(markets, key=lambda m: m.market_type):
        lines = []
        for key, pair in _pairs(m, home):
            if formula is not None:
                from . import formula as formula_mod
                fairs, presence = formula_mod.blended(pair, books, formula)
                if not presence.meets:
                    fairs = {}
            else:
                fairs = fair_mod.fair_value(pair, books)
            edges = {}
            if fairs:
                for e in find_edges(pair, books, now, min_ev=min_ev, fill_model=FillModel(),
                                    latency_model=LatencyModel(), formula=formula):
                    if e.book in can:
                        edges[(e.outcome, e.book)] = e
            rows = _rows(pair, can, now, (away, home) if away and home else ())
            for row in rows:
                fv = fairs.get(row["outcome"])
                row["fair"] = (None if fv is None or not 0.0 < fv.prob < 1.0 else
                               {"prob": round(fv.prob, 4), "american": american(1.0 / fv.prob)})
                for b, cell in row["cells"].items():
                    seen_books[b] = seen_books.get(b, 0) + 1
                    e = edges.get((row["outcome"], b))
                    if e is not None:
                        cell["ev"] = round(e.ev, 4)
                        cell["ev_text"] = f"+{e.ev * 100:.1f}% EV"
            lines.append({"line": key, "rows": rows})
        if lines:
            sections.append({"market": m.market_type,
                             "label": ALT_MARKETS["alternate_" + m.market_type], "lines": lines})
    cols = [{"key": b, "name": names.get(b) or b.replace("_", " ").title(), "bettable": b in can, "prices": n}
            for b, n in seen_books.items()]
    cols.sort(key=lambda c: (not c["bettable"], -c["prices"], c["name"].lower()))
    game = f"{away} at {home}" if away and home else got.estimate.event_id
    return {"has_lines": bool(sections), "game": game, "event_id": got.estimate.event_id,
            "league": got.estimate.league, "read_at": got.fetched_at, "age": round(max(0.0, now - got.fetched_at), 1),
            "from_cache": got.from_cache, "credits": got.credits, "warning": got.warning,
            "sections": sections, "books": cols, "books_for": books_for(state), "min_ev": min_ev,
            "message": "" if sections else ("No book posted alternate lines for this game in the regions read."),
            "note": NOTE}


# ------------------------------------------------------------ kept on this Mac

KEEP_DAYS = 30


def folder() -> Path:
    """Where each game's newest alternate-lines read is kept, beside the other reads the key paid for."""
    from .ledger import home
    return home() / "oddsapi" / "altlines"


def _file(where: Path, league: str, event_id: str) -> Path:
    return Path(where) / f"{league}-{event_id}.json"


def save(got: Read, where: Path | None = None) -> bool:
    """Write one game's read, as it was read. Never raises: a store that cannot be written costs the reopened view,
    not the read just paid for. An older read never replaces a newer one."""
    try:
        where = Path(where or folder())
        where.mkdir(parents=True, exist_ok=True)
        for d in (where.parent, where):
            os.chmod(d, 0o700)
        path = _file(where, got.estimate.league, got.estimate.event_id)
        try:
            if json.loads(path.read_text())["fetched_at"] > got.fetched_at:
                return False
        except (OSError, ValueError, KeyError, TypeError):
            pass
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"league": got.estimate.league, "event_id": got.estimate.event_id,
                                   "markets": list(got.estimate.markets), "regions": list(got.estimate.regions),
                                   "fetched_at": got.fetched_at, "payload": got.payload}))
        os.chmod(tmp, 0o600)
        tmp.replace(path)
        return True
    except (OSError, TypeError, ValueError):
        return False


def load(league: str, event_id: str, where: Path | None = None, now: float | None = None) -> Read | None:
    """The stored read for one game, or None when there is none or it is older than KEEP_DAYS. Reads a file only."""
    now = time.time() if now is None else now
    try:
        est = estimate(league, event_id)
        data = json.loads(_file(Path(where or folder()), est.league, est.event_id).read_text())
        if now - float(data["fetched_at"]) > KEEP_DAYS * 86400:
            return None
        est = Estimate(est.league, est.event_id, tuple(data["markets"]), tuple(data["regions"]))
        return Read(est, dict(data["payload"]), float(data["fetched_at"]), from_cache=True)
    except (OSError, ValueError, KeyError, TypeError, OddsApiError):
        return None


def clear(where: Path) -> int:
    n = 0
    try:
        for f in Path(where).glob("*.json"):
            f.unlink()
            n += 1
        shutil.rmtree(where, ignore_errors=True)
    except OSError:
        pass
    return n
