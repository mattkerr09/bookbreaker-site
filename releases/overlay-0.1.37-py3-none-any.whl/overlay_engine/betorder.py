"""What each result pays, and which bet to place first.

Two things OddsJam's arbitrage and middle screens show beside a pair of bets,
done here from numbers the engine already has and nothing else.

**Outcomes.** A pair of bets pays something different for each way the game can
end, and the headline figure is only one of them. An arbitrage has two results
(side A wins, side B wins) and its locked profit is the smaller one. A middle has
three: only the first bet wins, both win (the window), only the second wins. Each
figure is a number the staking code already worked out for that leg, copied here
with a plain label; this module adds, subtracts and divides nothing except the
bar scale below.

**Order.** The two bets are placed one after the other, and the second is placed
knowing whether the first was accepted. If the first is refused or the price
moves, the second has not been placed, so nothing is exposed. So the bet that is
most likely to go wrong goes first. "Most likely to go wrong" is read from what
the engine can measure, in this order:

  1. the lower chance the price is still there (`FillModel.p_fill`, from how old
     the price is and how fast that book moves). A prior is a prior: with no
     fitted record it is the stated survival prior, and the board says so.
  2. on a tie, the bigger bet, which is the one a book is likelier to cut back.

Prediction-market pairs have a measured thinness instead of an age, so there the
bet that uses the larger share of what is on offer goes first.

The rule is returned as one sentence with every row, so the window prints the
engine's words and not its own.
"""

from __future__ import annotations

#: Said when every leg has a fill chance.
RULE_FILL = ("Place the bet whose price is least likely to still be there first, judged by how old each price is "
             "and how fast its book moves, and if that is a tie, the bigger bet.")

#: Said when the board has no price ages to judge by (a recorded snapshot, the demo market).
RULE_STAKE = ("This board has no price ages to judge by, so the bigger bet goes first, "
              "since it is the one a book is likelier to cut back.")

#: Said for a pair of prediction-market bets.
RULE_THIN = ("Place the bet on the thinner side first: the one that uses the larger share "
             "of what is on offer at its price.")


def _places(ranked: list) -> list:
    out = [0] * len(ranked)
    for place, leg in enumerate(ranked, start=1):
        out[leg] = place
    return out


def by_fill(fills: list, stakes: list) -> tuple:
    """(place of each leg, 1 = first, and the rule's sentence).

    `fills` is each leg's chance its price is still there, or None when the
    board could not say. One unknown leg makes every comparison unfair, so then
    the bigger bet goes first and the sentence says that is why.
    """
    n = len(stakes)
    if n and all(f is not None for f in fills):
        ranked = sorted(range(n), key=lambda i: (round(fills[i], 4), -stakes[i], i))
        return _places(ranked), RULE_FILL
    ranked = sorted(range(n), key=lambda i: (-stakes[i], i))
    return _places(ranked), RULE_STAKE


def by_thinness(shares: list) -> tuple:
    """Order for pairs priced off an order book: the larger share of what is on
    offer goes first. Equal shares keep the listed order."""
    ranked = sorted(range(len(shares)), key=lambda i: (-round(shares[i], 6), i))
    return _places(ranked), RULE_THIN


def outcome_rows(items: list) -> list:
    """`items` is [(label, net profit, [legs that win])].

    Returned with the figure unchanged and a `scale` between 0 and 1 for a bar
    (this result's size against the largest result), the one division here.
    """
    top = max((abs(net) for _, net, _ in items), default=0.0)
    return [{"label": label, "net": net, "legs": list(legs),
             "scale": round(abs(net) / top, 3) if top else 0.0}
            for label, net, legs in items]


def arb_outcomes(labels: list, nets: list) -> list:
    """One result per side: that side wins and the other loses."""
    return outcome_rows([(f"{label} wins", net, [i])
                         for i, (label, net) in enumerate(zip(labels, nets))])


def middle_outcomes(first: str, second: str, only_first: float, both: float,
                    only_second: float, window: str = "") -> list:
    """The three results of a middle, in the order the lines sit.

    `window` is a phrase for where the result lands for both bets to win, such
    as "the total lands between 220.5 and 223.5"; empty when the market is not
    one where that can be said without a sign convention.
    """
    both_label = f"Both win ({window})" if window else "Both bets win"
    return outcome_rows([
        (f"Only {first} wins", only_first, [0]),
        (both_label, both, [0, 1]),
        (f"Only {second} wins", only_second, [1]),
    ])
