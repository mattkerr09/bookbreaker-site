"""A Kalshi or Polymarket US contract price, as the sportsbook odds it really pays once the venue's taker fee is added.

A contract pays $1 if it wins, so its price in cents reads like a chance and like odds. The venue adds a taker fee to
every order (the formulas and their read date are in xvenue.py), so the contract really costs a little more than its
price and pays shorter odds than the price suggests: 47c on Kalshi is +105 after the fee, not +113. The parity bar
(ODDSJAM_BAR #15) names a prediction-market price converter as a real gap for a beginner.

Everything the window shows is worded here; the window does no arithmetic.
"""

from __future__ import annotations

from .odds import OddsError, decimal_to_american
from .xvenue import FEES_READ, FEE_SOURCES, KALSHI_FEE_MULTIPLIER, KALSHI_TAKER_RATE, kalshi_fee, pmus_fee

VENUES = {"kalshi": "Kalshi", "polymarket": "Polymarket US", "polymarket_us": "Polymarket US", "pmus": "Polymarket US"}
LEGAL = "Whether these sports contracts are legal is disputed state by state; check your own state before using either venue."


def _venue(text: str) -> str:
    key = (text or "").strip().lower().replace(" ", "_")
    if key.startswith("k"):
        return "Kalshi"
    if key.startswith("p"):
        return "Polymarket US"
    raise OddsError("Choose a venue: Kalshi or Polymarket US.")


def price_odds(price, venue: str, sport: str = "", contracts: int = 100) -> dict:
    """`price` in cents (47) or as a fraction (0.47). Raises OddsError with a plain sentence on bad input."""
    try:
        p = float(str(price).strip().rstrip("c").replace("¢", ""))
    except ValueError:
        raise OddsError(f"“{price}” is not a price I can read. Type cents, like 47.") from None
    if p >= 1:
        p = p / 100
    if not 0 < p < 1:
        raise OddsError("A contract price is between 1 and 99 cents.")
    p = round(p, 4)
    name = _venue(venue)
    n = int(contracts)
    if not 1 <= n <= 100_000:
        raise OddsError("Contracts must be between 1 and 100,000.")
    league = (sport or "").strip().lower()
    if name == "Kalshi":
        multiplier = KALSHI_FEE_MULTIPLIER.get(league, 1.0) if league else 1.0
        fee = kalshi_fee(n, p, rate=KALSHI_TAKER_RATE * multiplier)
    else:
        multiplier = 1.0
        fee = pmus_fee(n, p)
    cost_each = (p * n + fee) / n
    decimal = 1 / cost_each
    american = round(decimal_to_american(decimal))
    raw_american = round(decimal_to_american(1 / p))
    cents = round(p * 100, 2)
    cents_text = f"{cents:g}c"
    rows = [["Price", f"{cents_text}, a {p:.0%} chance as priced (reads {raw_american:+d} before the fee)"],
            [f"{name} taker fee on {n:,} contracts", f"${fee:,.2f}"],
            ["Cost per contract with the fee", f"{cost_each * 100:.2f}c"],
            ["Win chance you need to break even", f"{cost_each:.2%}"],
            ["Odds after the fee", f"{american:+d} (decimal {decimal:.3f})"]]
    notes = [f"Fee formulas read {FEES_READ} from each venue's own fee page ({', '.join(FEE_SOURCES)}). The fee is "
             "charged on the whole order, so a few contracts pay more per contract than many."]
    if name == "Kalshi" and multiplier != 1.0:
        notes.append(f"{league.upper()} game series on Kalshi charge {multiplier:g} of the usual fee.")
    notes.append(LEGAL)
    return {"venue": name, "price": p, "contracts": n, "fee": fee, "cost_each": round(cost_each, 6),
            "breakeven": round(cost_each, 6), "decimal": round(decimal, 6), "american": american,
            "raw_american": raw_american, "multiplier": multiplier,
            "headline": f"{american:+d}",
            "say": (f"A {cents_text} {name} contract pays {american:+d} once its ${fee:,.2f} fee on {n:,} contracts is "
                    f"added; the price alone reads {raw_american:+d}. Compare {american:+d} with a sportsbook's price "
                    "for the same team."),
            "rows": rows, "notes": notes}
