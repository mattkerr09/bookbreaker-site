"""What a new person can do before they have an Odds API key.

The window opens on Ask. Two of its sample questions (the best +EV bets, tonight's arbs) need live sportsbook odds,
which come only through the person's own free Odds API key, and nothing said so: a new person pressed them and got a
refusal. With no key saved, `key status --json` now carries a `start` block: three things that work right away, the
key steps last, and which sample questions need a key. The window draws it and computes nothing.
"""

from __future__ import annotations

KEY_SITE = "https://the-odds-api.com/"

STEPS = (
    {"title": "See the sign-up offers in your state",
     "text": "Pick your state in the top bar. Promos lists every sportsbook offer there, ranked by what you keep "
             "after hedging, not by the headline amount. No key needed.",
     "panel": "welcome"},
    {"title": "Price a promo you already have",
     "text": "Convert my own promo works out what a bonus bet, a refund, a profit boost or a deposit match is worth, "
             "with both outcomes shown. No key needed.",
     "panel": "convert"},
    {"title": "Add a free Odds API key for live odds",
     "text": "1. Go to the-odds-api.com and choose the free plan (500 credits a month). 2. Copy the key from the "
             "email they send. 3. Paste it on Bookbreaker's Odds source page. It is kept in your Mac's Keychain "
             "and sent only to The Odds API, and every refresh says its cost before it runs.",
     "panel": "odds"},
)

#: The Ask sample questions that need live sportsbook odds, by their text in the window.
NEEDS_KEY = ("Best +EV bets right now", "Any arbs on tonight’s games?")
NEEDS_KEY_LABEL = "needs a free Odds API key"


def start(key_is_set: bool) -> dict | None:
    """The Start here block, or None once a key is saved."""
    if key_is_set:
        return None
    return {"title": "Start here", "steps": [dict(s) for s in STEPS], "key_site": KEY_SITE,
            "needs_key": list(NEEDS_KEY), "needs_key_label": NEEDS_KEY_LABEL}
