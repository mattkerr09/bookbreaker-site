"""How many plays each filter on the board would leave, counted before the person changes it.

OddsJam's filter drawer prints "Show N results" and moves it as you tick. Ours counts from the plays the engine
already sent, so the number is there before the switch is touched and **changing a filter reads nothing and spends no
credit**. The window prints these sentences and counts nothing of its own.

What each filter does to the list:

  * **Recommended** shows or hides plays by the `recommended` flag the engine put on each (`preset`).
  * **Hide under** is applied by the engine when it reads: it leaves out an arb whose margin is under the figure.
    Only arbs are held to it (`board.scan` and `xvenue.scan` pass it to nothing else), so a +EV bet or a middle is
    never counted out by it. A read can therefore say, exactly, what a *higher* figure would leave, and nothing about
    a lower one, because those plays were left out of the read. A lower figure is marked "not counted" and the
    window says to press Find arbs, which is the only thing that reads.
  * **The EV formula** (`formula`) is applied by the engine when it reads, like Hide under. When one was set, the
    counts above are of the plays it left (it changes which +EV bets exist and at what price), and a `formula` block
    says how many +EV bets it shows, how many there would be without it, and how many it left out for too little of
    its weight. No block is sent when no formula was.
  * **Bet warnings** only mark plays and never remove one, so each switch says how many plays it marks and that the
    list stays as it is.

A count is of the plays the read found. A play the person hid themselves is still counted, and the note says so.
"""

from __future__ import annotations

from . import betwarn

#: The Hide under figures offered, in percent. The figure the read used is added to them.
STEPS = (0.5, 1.0, 2.0, 3.0, 5.0)

NOTE = ("Counts are of the plays this read found. A play you hid yourself is still counted. Changing a filter reads "
        "nothing and spends no credit.")
APPLY = "Press Find arbs to use it. Nothing is read until you do."


def _plays(n: int) -> str:
    return f"{n} play{'s' if n != 1 else ''}"


def _pct(x: float) -> str:
    return f"{x:g}%"


def _left(plays: list, step: float, recommended_only: bool) -> int:
    """Plays left at a Hide under figure. Only an arb is held to it, by the margin test the engine itself uses."""
    floor = step / 100.0
    return sum(1 for margin, is_arb, recommended in plays
               if (recommended or not recommended_only) and (not is_arb or margin >= floor))


def build(plays: list, min_margin: float = 0.0, left_out: int = 0, warned: list | None = None,
          formula: dict | None = None) -> dict:
    """The counts for one read.

    `plays` is one `(margin as a fraction, is an arb, is recommended)` per play the read sent. `min_margin` is the
    Hide under figure the read used, in percent, and `left_out` how many arbs it left out. `warned` is the board's
    `by_code` list from `betwarn.attach` (`code`, `count`).
    """
    total = len(plays)
    kept = sum(1 for _, _, rec in plays if rec)
    figure = float(min_margin or 0.0)
    steps = sorted({0.0, figure, *STEPS})
    under = []
    for step in steps:
        entry = {"key": f"{step:g}", "label": _pct(step), "pct": step}
        if step >= figure:
            rec, every = _left(plays, step, True), _left(plays, step, False)
            entry.update(known=True, rec=rec, all=every, left_text=f"{every} left",
                         left_text_rec=f"{rec} left",
                         text_rec=f"Hide under {_pct(step)}: {rec} left with Recommended on",
                         text_all=f"Hide under {_pct(step)}: {every} left with Recommended off")
        else:
            why = f"Hide under {_pct(step)}: not counted, because this read already left out plays under {_pct(figure)}"
            entry.update(known=False, rec=None, all=None, left_text="not counted", left_text_rec="not counted",
                         text_rec=why, text_all=why)
        under.append(entry)
    emptied = bool(total == 0 and figure > 0 and left_out > 0)
    if figure > 0:
        said = (f"Hide under {_pct(figure)} left out {_plays(left_out)} on this read." if left_out
                else f"Hide under {_pct(figure)} left nothing out on this read.")
    else:
        said = ""
    counts = {code: n for code, n in ((w["code"], w["count"]) for w in (warned or []))}
    out = {
        "total": total, "min_margin": figure, "left_out": left_out,
        "recommended": {
            "kept": kept,
            "if_on": f"Recommended on: {kept} of {_plays(total)}",
            "if_off": f"Recommended off: {total} of {_plays(total)}",
        },
        "under": under, "under_said": said, "apply": APPLY,
        "empty_by_under": emptied,
        "empty_text": (f"Hide under {_pct(figure)} left out {_plays(left_out)}, so nothing is on this board."
                       if emptied else ""),
        "undo_under": {"key": "0", "label": "Set Hide under to 0%"},
        "warn": {code: (f"Marks {_plays(counts[code])}; the list stays as it is." if counts.get(code)
                        else "Marks no plays on this board; the list stays as it is.")
                 for code in betwarn.CODES},
        "note": NOTE,
    }
    if formula is not None:
        out["formula"] = formula
    return out


def of_rows(rows: list, min_margin: float = 0.0, left_out: int = 0, warned: list | None = None,
            formula: dict | None = None) -> dict:
    """`build` for the board's `Row`s or the live `Pairing`s: anything with a margin, a kind (a Pairing is an arb)
    and `preset_misses`."""
    return build([(r.margin, getattr(r, "kind", "arb") == "arb", not r.preset_misses) for r in rows],
                 min_margin, left_out, warned, formula)
