"""A price over time: one book's price on one side of one market, across every read of live
odds this Mac has kept, with the fair (no-vig) price beside it and the person's own bet marked.

The reads are `oddshistory`'s: each press of Live sportsbook odds writes what the books were
quoting to a file on this Mac, and nothing here fetches anything. The window draws what this
module returns and measures none of it, so the line is returned as finished geometry: the
path of each series in the chart's own coordinates, the position of each tick and marker, and
the words for every label. There is no chart library and no network request behind it.

**A line needs two reads.** One read is a point, and a point is not a movement. Fewer than two
reads of the book's price gives "No history yet" and says how many this Mac has.

**The first price seen is not the opener.** The line starts at the first read this Mac kept,
and the summary says so. Nothing before it is guessed.

**The line is a step.** A price is held until the next read, so the chart steps (across, then
up or down) and never draws a slope between two reads that nobody saw.

**The fair price is the row's own method.** At each read it is `fair.fair_value` over that
read's two-sided market at the same line, with the same books table the row used, so the
last point of the fair line is the fair price the row's own detail shows. A middle bets two
different lines and has no one fair price, so it gets the price line alone.

**Prices are drawn in decimal and labelled in American.** American odds jump from -100 to +100
and are not a straight scale; a chart on them would bend at the break. Decimal is straight,
and a higher price is higher on the chart. The labels are the American prices a bettor reads.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

from . import oddshistory
from .fair import fair_value
from .models import Market
from .screen import _group_key, american, parse_key, side_label

#: A line is thinned to this many reads. The first and last are always kept.
MAX_POINTS = 60

#: Reads older than this are not drawn. A game is on the board for about a week.
SINCE_DAYS = 7

WIDTH, HEIGHT = 520, 176
LEFT, RIGHT, TOP, BOTTOM = 48, 14, 12, 28


def _signed(n: int) -> str:
    return f"+{n}" if n > 0 else f"{n}"


def when(epoch: float, tz=None) -> str:
    """'Oct 9, 3:10 PM' on this Mac's clock (or in `tz`)."""
    d = datetime.fromtimestamp(float(epoch), tz)
    hour = d.hour % 12 or 12
    return f"{d.strftime('%b')} {d.day}, {hour}:{d.minute:02d} {'AM' if d.hour < 12 else 'PM'}"


def _thin(items: list, cap: int) -> list:
    n = len(items)
    if n <= cap:
        return items
    keep = sorted({round(k * (n - 1) / (cap - 1)) for k in range(cap)})
    return [items[i] for i in keep]


def my_bets(path, events: set) -> list:
    """The person's bets on these events, read straight from the ledger file without opening it for writing.

    Empty when there is no ledger, which is the normal state of a new install."""
    if not events:
        return []
    try:
        p = Path(path)
        if not p.exists():
            return []
        con = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        try:
            con.row_factory = sqlite3.Row
            marks = ",".join("?" for _ in events)
            rows = con.execute(
                f"SELECT event_id, market_type, outcome, book, decimal_odds, stake, placed_at FROM bets "
                f"WHERE event_id IN ({marks})", sorted(events)).fetchall()
            return [dict(r) for r in rows]
        finally:
            con.close()
    except (sqlite3.Error, OSError):
        return []


class LineHistory:
    """Every kept read, indexed by game and market, and the person's bets on them.

    Built once per board and read only when a row asks for a chart, so a board with no rows
    reads no history. `load_reads()` gives the kept reads (oldest first); `load_bets(events)`
    gives the person's bets on those games."""

    def __init__(self, load_reads, load_bets=None, tz=None):
        self._load_reads = load_reads
        self._load_bets = load_bets
        self._tz = tz
        self._reads: dict | None = None
        self._bets: list | None = None
        self._fair: dict = {}

    @classmethod
    def from_disk(cls, folder, ledger_path=None, now: float = 0.0, tz=None) -> "LineHistory":
        """The reads kept on this Mac for the last `SINCE_DAYS` days and, if there is a ledger file, the bets."""
        since = now - SINCE_DAYS * 86400 if now else None
        return cls(lambda: oddshistory.snapshots(folder, since=since),
                   (lambda events: my_bets(ledger_path, events)) if ledger_path is not None else None, tz)

    # ------------------------------------------------------------ the index

    def _load(self) -> dict:
        if self._reads is None:
            reads: dict = {}
            for snap in self._load_reads():
                for raw in snap["markets"]:
                    reads.setdefault((str(raw["event"]), raw["type"]), []).append((snap, raw))
            for found in reads.values():
                found.sort(key=lambda sr: sr[0]["fetched_at"])
            self._reads = reads
        return self._reads

    def _my_bets(self, event: str) -> list:
        if self._bets is None:
            self._bets = (self._load_bets({str(k[0]) for k in self._load()})
                          if self._load_bets is not None else [])
        return [b for b in self._bets if str(b["event_id"]) == str(event)]

    # ------------------------------------------------------------ the series

    def _series(self, event: str, market_type: str, outcome: str, book: str, books, with_fair: bool) -> dict:
        _, line = parse_key(outcome)
        group = _group_key(line)
        price, fair = [], []
        for snap, raw in self._load().get((str(event), market_type), []):
            starts = raw.get("starts")
            if starts is not None and snap["fetched_at"] >= starts:
                continue                      # in-play prices are not the line a person bets into
            market = oddshistory.market_from(snap, raw)
            quotes = [q for q in market.quotes if _group_key(q.outcome.line) == group]
            mine = [q for q in quotes if q.book == book and q.outcome.key == outcome]
            if mine:
                price.append((snap["fetched_at"], mine[-1].decimal))
            if with_fair:
                key = (str(event), market_type, group, snap["fetched_at"], snap["league"])
                if key not in self._fair:
                    fvs = fair_value(Market(event_id=market.event_id, sport=market.sport,
                                            market_type=market_type, quotes=quotes,
                                            starts_at=market.starts_at), books)
                    self._fair[key] = {k: v.fair_decimal for k, v in fvs.items()}
                value = self._fair[key].get(outcome)
                if value is not None:
                    fair.append((snap["fetched_at"], value))
        return {"price": price, "fair": fair}

    # ------------------------------------------------------------ the chart

    def charts(self, market, legs: list, kind: str, books, names_of) -> list:
        """One chart per leg. `legs` is [{"book", "outcome"}]; `names_of(book)` is its display name."""
        return [self.chart(market, leg["book"], leg["outcome"], kind, books, names_of) for leg in legs]

    def chart(self, market, book: str, outcome: str, kind: str, books, names_of) -> dict:
        book_name = names_of(book)
        label = side_label(outcome, market.market_type)
        base = {"outcome": outcome, "label": label, "book": book, "book_name": book_name}
        s = self._series(market.event_id, market.market_type, outcome, book, books, with_fair=kind != "middle")
        price = s["price"]
        if len(price) < 2:
            n = len(price)
            why = (f"No history yet. This Mac has read {book_name}'s price on {label} "
                   f"{'once' if n == 1 else str(n) + ' times'}"
                   if n else f"No history yet. This Mac has not read {book_name}'s price on {label} before")
            if market.market_type not in ("h2h", "spreads", "totals"):
                why += ", and player props are not kept in the price history"
            why += ". A line needs two reads: press Live sportsbook odds again later and it fills in."
            return {**base, "available": False, "reads": n, "why": why}
        kept = len(price)
        price = _thin(price, MAX_POINTS)
        # The fair price is drawn only across the span the book's price is: a point outside it has no price to sit beside.
        fair = (_thin([f for f in s["fair"] if price[0][0] <= f[0] <= price[-1][0]], MAX_POINTS)
                if kind != "middle" else [])
        bets = [b for b in self._my_bets(market.event_id)
                if b["market_type"] == market.market_type and b["outcome"] == outcome]
        return {**base, "available": True, "reads": kept,
                **_geometry(price, fair, bets, book_name, label, self._tz, kept=kept,
                            fair_wanted=kind != "middle", names_of=names_of)}


def _mark(bet: dict, decimal: float, x, y, t0: float, t1: float, names_of, tz) -> dict:
    """Where the person's own bet sits on the chart, and the words for it."""
    edge = "before" if bet["placed_at"] < t0 else "after" if bet["placed_at"] > t1 else None
    text = (f"Your bet: {_signed(american(decimal))} at {names_of(bet['book'])} for ${bet['stake']:,.2f}, "
            f"{when(bet['placed_at'], tz)}")
    if edge:
        text += (f". That is {'before the first' if edge == 'before' else 'after the last'} read this Mac kept, "
                 "so it is drawn at the edge")
    return {"x": x(bet["placed_at"]), "y": y(decimal), "american": american(decimal), "book": bet["book"],
            "stake": bet["stake"], "edge": edge, "label": text + "."}


def _geometry(price: list, fair: list, bets: list, book_name: str, label: str, tz, kept: int,
              fair_wanted: bool, names_of) -> dict:
    t0, t1 = price[0][0], price[-1][0]
    marks = [(b, float(b["decimal_odds"])) for b in bets]
    ys = [d for _, d in price] + [d for _, d in fair] + [d for _, d in marks]
    lo, hi = min(ys), max(ys)
    span = hi - lo
    if span < 0.04:
        mid = (hi + lo) / 2
        lo, hi = mid - 0.03, mid + 0.03
    else:
        pad = span * 0.12
        lo, hi = lo - pad, hi + pad
    pw, ph = WIDTH - LEFT - RIGHT, HEIGHT - TOP - BOTTOM

    def x(t: float) -> float:
        return round(LEFT + (min(max(t, t0), t1) - t0) / (t1 - t0) * pw, 1)

    def y(d: float) -> float:
        return round(TOP + (hi - d) / (hi - lo) * ph, 1)

    def step(points: list) -> str:
        head = f"M{x(points[0][0])} {y(points[0][1])}"
        body = "".join(f" H{x(t)} V{y(d)}" for t, d in points[1:])
        return head + body

    y_ticks = [{"y": y(d), "american": american(d)}
               for d in (hi - (hi - lo) * 0.1, (hi + lo) / 2, lo + (hi - lo) * 0.1)]
    x_ticks = [{"x": x(t), "label": when(t, tz), "anchor": a}
               for t, a in ((t0, "start"), ((t0 + t1) / 2, "middle"), (t1, "end"))]
    chart = {"width": WIDTH, "height": HEIGHT,
             "plot": {"x": LEFT, "y": TOP, "w": pw, "h": ph, "x2": LEFT + pw, "y2": TOP + ph},
             "y_label_x": LEFT - 8, "x_label_y": TOP + ph + 18,
             "y_ticks": y_ticks, "x_ticks": x_ticks,
             "price": {"label": book_name, "path": step(price), "end": {"x": x(t1), "y": y(price[-1][1])},
                       "first": american(price[0][1]), "last": american(price[-1][1])},
             "fair": ({"label": "Fair price", "path": step(fair), "end": {"x": x(fair[-1][0]), "y": y(fair[-1][1])},
                       "first": american(fair[0][1]), "last": american(fair[-1][1])}
                      if len(fair) >= 2 else None),
             "mine": [_mark(b, d, x, y, t0, t1, names_of, tz) for b, d in marks]}
    first, last = american(price[0][1]), american(price[-1][1])
    moved = (f"{book_name}'s price on {label} has gone from {_signed(first)} to {_signed(last)}"
             if first != last else f"{book_name}'s price on {label} has held at {_signed(first)}")
    text = f"{moved} over {kept} reads since {when(t0, tz)}, the first time this Mac read it."
    if len(fair) >= 2:
        f0, f1 = american(fair[0][1]), american(fair[-1][1])
        text += (f" The fair price went from {_signed(f0)} to {_signed(f1)}." if f0 != f1
                 else f" The fair price held at {_signed(f0)}.")
    text += " That is the first price seen, not necessarily the opener."
    if len(price) < kept:
        text += f" Drawn from {len(price)} of the {kept} reads."
    return {"chart": chart, "from": when(t0, tz), "to": when(t1, tz), "text": text,
            "note": ("The line steps because a price is held until the next read; nothing is drawn between reads."
                     + ("" if fair_wanted else " A middle bets two lines, so there is no one fair price to draw."))}
