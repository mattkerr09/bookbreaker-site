"""Parlays: what they pay, what they should pay, and the gap.

A parlay is the most popular bet in the American market and the worst-priced.
The reason is not that any individual leg is bad — it is that the margin
compounds. A book holding 4.55% on a single holds far more on four of them
multiplied together, and the product page never mentions it because the payout
number gets bigger while the value gets smaller.

    four legs at -110      pays 12.28 to 1
    four fair coin flips   should pay 15 to 1

That is the whole subject. Everything here computes that gap.

**Correlation is the other half, and it cuts both ways.** Legs within one game
are not independent — a team covering the spread makes the over more likely,
not less. Books price same-game parlays with a correlation adjustment precisely
because a naive multiplication would be exploitable. So the independent
calculation below is an *upper bound* on what a same-game parlay is worth, and
saying otherwise would be inventing an edge. It is labelled rather than
silently applied.
"""

from __future__ import annotations

from dataclasses import dataclass

from .odds import OddsError, decimal_to_prob


def parlay_decimal(legs: list[float]) -> float:
    """Combined decimal price of a parlay. The product of its legs.

    Every book computes it this way, which is the point: the payout is the
    honest product of the prices, and the prices are each already shaded.
    """
    if len(legs) < 2:
        raise OddsError("a parlay needs at least two legs")
    total = 1.0
    for leg in legs:
        if leg <= 1.0:
            raise OddsError(f"decimal odds must exceed 1.0, got {leg}")
        total *= leg
    return total


def parlay_fair(probs: list[float]) -> float:
    """Fair decimal price for independent legs at these probabilities.

    Independent. Same-game legs are not, and this returns the wrong answer for
    them — deliberately, because the right answer needs a correlation the book
    knows and the bettor does not.
    """
    if len(probs) < 2:
        raise OddsError("a parlay needs at least two legs")
    combined = 1.0
    for p in probs:
        if not 0.0 < p < 1.0:
            raise OddsError(f"probability must lie in (0, 1), got {p!r}")
        combined *= p
    return 1.0 / combined


@dataclass(frozen=True)
class ParlayValue:
    """What a parlay pays against what it should."""

    legs: int
    offered: float
    fair: float
    leg_hold: float

    @property
    def hold(self) -> float:
        """The book's margin on the parlay, as a fraction of stake.

        Compounds with legs: a 4.55% single becomes about 17% over four legs,
        because the bettor has to beat the margin once per leg and the misses
        multiply.
        """
        return 1.0 - self.offered / self.fair

    @property
    def multiple(self) -> float:
        """How many times the single-bet hold this parlay costs."""
        return self.hold / self.leg_hold if self.leg_hold else 0.0

    @property
    def ev(self) -> float:
        """Expected value per unit staked. Negative unless the legs are +EV."""
        return self.offered / self.fair - 1.0

    def describe(self) -> str:
        return (
            f"{self.legs} legs: pays {self.offered - 1:.2f} to 1 where fair is "
            f"{self.fair - 1:.2f} to 1 — a {self.hold:.1%} hold, "
            f"{self.multiple:.1f}x the {self.leg_hold:.1%} on a single"
        )


#: A standard two-way market, -110 on both sides: the books' own margin on a coin flip. 2 x 110/210.
STANDARD_OVERROUND = 2 * 110 / 210
STANDARD_HOLD = 1.0 - 1.0 / STANDARD_OVERROUND          # 4.55%
ASSUMPTION = ("Only each leg's own price was given, so each leg is taken to carry the margin of a standard "
              "-110 / -110 market (4.55%), removed in proportion to its price. With both sides of a leg's market, "
              "Fair odds gives its real fair price.")


def value(legs: list[float], probs: list[float] | None = None) -> ParlayValue:
    """Price a parlay against its fair value.

    Without `probs`, each leg is taken to carry the margin of a standard -110 / -110 market, removed in proportion
    to its price: a -110 leg is a fair coin flip, a +150 leg (40.0% implied) is 38.2%. One price cannot say more
    than that; with the other side of the market, devig it instead. This used to devig each leg against a copy of
    itself, which made every leg a coin flip whatever its price: a +150 leg became a 50% chance and a parlay with
    one looked like a bet with an edge.
    """
    if probs is None:
        probs = [decimal_to_prob(leg) / STANDARD_OVERROUND for leg in legs]

    offered = parlay_decimal(legs)
    fair = parlay_fair(probs)
    return ParlayValue(legs=len(legs), offered=offered, fair=fair, leg_hold=STANDARD_HOLD)


def break_even_legs(leg_hold: float, target: float) -> int:
    """How many legs it takes for the compounded hold to reach `target`.

    The answer for a standard -110 market and a 25% target is six, which is
    roughly where a parlay stops being a bet and becomes a lottery ticket.
    """
    if not 0.0 < leg_hold < 1.0:
        raise OddsError("leg hold must lie in (0, 1)")
    if not 0.0 < target < 1.0:
        raise OddsError("target must lie in (0, 1)")
    n, hold = 1, leg_hold
    while hold < target and n < 100:
        n += 1
        hold = 1.0 - (1.0 - leg_hold) ** n
    return n


def correlation_note(same_game: bool) -> str:
    """What the independent calculation does and does not cover."""
    if not same_game:
        return ("Legs in different games are close enough to independent that "
                "multiplying the probabilities is the right sum.")
    return (
        "These legs are in one game and are not independent. A team covering "
        "the spread makes the over more likely, not less. Books price "
        "same-game parlays with a correlation adjustment for exactly that "
        "reason, so the independent figure above is an upper bound on what "
        "this is worth, not an estimate of it."
    )
