"""Live sportsbook odds from The Odds API, read with the person's own key.

OddsJam's core is a board of live prices across every US book. Bookbreaker gets
there at no cost to us: each person signs up for a free key of their own
(Starter: 500 credits a month), saves it in their Mac's Keychain
(`keystore.py`), and presses a button. Their terms forbid reselling the data as
a data product; a person looking at their own key's data in their own app is
not that, and this module is built so it stays not that:

**The key and the odds go to one host.** `api.the-odds-api.com`, over https,
and nowhere else. The fetcher builds that URL and refuses any other, follows no
redirect (a redirect would carry the key in the query string to whoever the
answer named), and turns every failure into a sentence that has neither the URL
nor the key in it. The odds are cached on this Mac for sixty seconds and never
sent anywhere.

**Credits are counted out loud, before and after.** The rule, from the API's
own usage page (https://the-odds-api.com/liveapi/guides/v4/, "Usage Quota
Costs", read 2026-10-09):

    The usage quota cost is 1 per region per market.
    cost = [number of markets specified] x [number of regions specified]

and a call is made per league, so one refresh is leagues x regions x markets.
`estimate()` says that number before anything is fetched, and the number shown
is exactly that product: it is an upper bound, because the same page says
"Responses with empty data do not count towards the usage quota" and counts
unique markets *in the response*, so a league with no games listed, or a market
no book posted, costs less. What a refresh actually cost is read back off the
`x-requests-last` header, and what is left off `x-requests-remaining`.

**Player props are a separate, opt-in group, and cost far more.** They are not
on the bulk endpoint: each game is read on its own (`/events/{id}/odds`), and
each such request costs unique markets returned x regions specified
(https://the-odds-api.com/liveapi/guides/v4/, "GET event odds", read
2026-10-12; see docs/odds-api-player-props.md). So a props refresh is games x
markets x regions per league, the games capped per league so the number can be
said before the press. `estimate(props=...)` says it, split from the main-market
cost; with props off (the default) nothing here changes.

**Futures are a third opt-in group, in `futures.py`.** A title market (who wins the Super Bowl) is the
`outrights` market on its own sport key, so it costs 1 credit per region per key picked, said before the press
(`futures.estimate`). Nothing here reads one; `Cache` is shared and `Cache.clear` removes what they stored.

**A double click never spends twice.** Each league's answer is kept on disk
with the time it was fetched and reused for 60 seconds, keyed by league,
regions and markets (never by the key).

**Prices are dated by the book, not by us.** `restfeed` stamps each quote with
the feed's own `last_update`; `feed.stamp` then classifies it, so an undated
price reads as `assumed` and decays like one. Games already under way are left
off: an in-play price is stale by the time it is read.

**Only books you can bet at are shown as bets.** A Europe region is asked for so
Pinnacle can price the fair odds. A US bettor cannot place a bet at Pinnacle,
so its price, and every other reference price (Europe, offshore books, the US
exchanges whose fees these prices do not include), prices the market and never
appears as a leg. `board.scan(bettable=...)` enforces it.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from dataclasses import replace as _replace
from datetime import date, datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, build_opener

from . import futurestore, oddshistory
from .feed import FeedError, stamp
from .ledger import home
from .models import Book, BookTier, Market, Outcome, Quote
from .restfeed import MIN_DECIMAL, Quota, RestProvider, parse_time, read_quota

HOST = "api.the-odds-api.com"
BASE = f"https://{HOST}"

#: A fetched answer is reused for this long. A double click, the window opening
#: while a refresh is out, a script run twice: none of them may spend a credit.
CACHE_SECONDS = 60.0

#: The sentence the cost rests on, kept verbatim so a test can hold it.
COST_RULE = ("The usage quota cost is 1 per region per market. "
             "cost = [number of markets specified] x [number of regions specified]")
COST_RULE_SOURCE = "https://the-odds-api.com/liveapi/guides/v4/ (GET odds, Usage Quota Costs)"

SIGNUP = "the-odds-api.com"

NO_KEY = ("No Odds API key is set. Get a free key at the-odds-api.com, then save it "
          "in Bookbreaker's Odds source page.")
CREDITS_GONE = ("Your Odds API credits for this month are used up. They come back when "
                "your monthly allowance resets, or you can add a paid plan on "
                "the-odds-api.com.")


class OddsApiError(FeedError):
    """The Odds API said no, or could not be reached. The message is a sentence
    for a beginner and never contains the key or the request's address."""

    def __init__(self, message: str, reason: str = "error", status: int | None = None):
        super().__init__(message)
        self.reason = reason
        self.status = status


# ------------------------------------------------------------ what can be asked

@dataclass(frozen=True)
class League:
    alias: str
    label: str
    key: str            # the Odds API's sport key
    opens: tuple        # (month, day) odds usually start being listed
    closes: tuple       # (month, day) the last game is usually played

    def in_season(self, day: date) -> bool:
        here = (day.month, day.day)
        if self.opens <= self.closes:
            return self.opens <= here <= self.closes
        return here >= self.opens or here <= self.closes


#: The six leagues. Keys are the Odds API's (the sports list at
#: https://the-odds-api.com/sports-odds-data/sports-apis.html, read 2026-10-09).
#: The windows are the usual span of each league's listed games, rounded
#: outward a little; they only decide what is ticked by default. A league
#: outside its window can still be asked for by name, and a league with no
#: games listed costs nothing.
LEAGUES: tuple = (
    League("nfl", "NFL", "americanfootball_nfl", (9, 1), (2, 15)),
    League("ncaaf", "College football", "americanfootball_ncaaf", (8, 25), (1, 25)),
    League("nba", "NBA", "basketball_nba", (10, 15), (6, 25)),
    League("ncaab", "College basketball", "basketball_ncaab", (11, 1), (4, 10)),
    League("mlb", "MLB", "baseball_mlb", (3, 20), (11, 5)),
    League("nhl", "NHL", "icehockey_nhl", (10, 1), (6, 25)),
)
_BY_ALIAS = {lg.alias: lg for lg in LEAGUES}
_BY_KEY = {lg.key: lg for lg in LEAGUES}

#: Region keys, as the Odds API names them, and what each is in plain words.
REGIONS: dict = {
    "us": "US sportsbooks (DraftKings, FanDuel, BetMGM and more)",
    "us2": "More US sportsbooks (Hard Rock Bet, theScore Bet, betPARX and more)",
    "eu": "Europe, which includes Pinnacle, the sharpest book (prices fair odds only)",
    "us_ex": "US exchanges (Kalshi, Polymarket and more; prices fair odds only)",
}
DEFAULT_REGIONS = ("us", "eu")

MARKETS: dict = {"h2h": "Moneyline", "spreads": "Spread", "totals": "Total"}
DEFAULT_MARKETS = ("h2h",)

_PLAIN_MARKET = {"h2h": "moneyline", "spreads": "spread", "totals": "total"}

#: The sentence the player-props cost rests on, kept verbatim so a test can hold
#: it. Event odds are billed by markets RETURNED, so the figure said before a
#: press (markets asked) is an upper bound that a market with no prices lowers.
PROPS_COST_RULE = ("The usage quota cost depends on the number of markets and regions used in "
                   "the request. cost = [number of unique markets returned] x "
                   "[number of regions specified]")
PROPS_COST_RULE_SOURCE = ("https://the-odds-api.com/liveapi/guides/v4/ "
                          "(GET event odds, Usage Quota Costs; the games list is free)")

#: Player-prop markets per league: only ones that are a number the player goes
#: over or under (yards, points, strikeouts). Yes/No markets (anytime
#: touchdown), over-only markets and the `_alternate` milestone lines are left
#: out: a prop is only paired as a two-way over/under at one line. Keys are the
#: Odds API's (https://the-odds-api.com/sports-odds-data/betting-markets.html,
#: read 2026-10-12).
_FOOTBALL = {
    "player_pass_yds": "Passing yards", "player_pass_tds": "Passing touchdowns",
    "player_pass_completions": "Pass completions", "player_pass_attempts": "Pass attempts",
    "player_pass_interceptions": "Interceptions thrown", "player_rush_yds": "Rushing yards",
    "player_rush_attempts": "Rushing attempts", "player_receptions": "Receptions",
    "player_reception_yds": "Receiving yards", "player_rush_reception_yds": "Rushing + receiving yards",
}
_BASKETBALL = {
    "player_points": "Points", "player_rebounds": "Rebounds", "player_assists": "Assists",
    "player_threes": "Three-pointers made", "player_points_rebounds_assists": "Points + rebounds + assists",
    "player_blocks": "Blocks", "player_steals": "Steals", "player_turnovers": "Turnovers",
}
PROP_MARKETS: dict = {
    "nfl": _FOOTBALL,
    "ncaaf": _FOOTBALL,
    "nba": _BASKETBALL,
    "ncaab": _BASKETBALL,
    "mlb": {
        "pitcher_strikeouts": "Pitcher strikeouts", "pitcher_outs": "Pitcher outs",
        "pitcher_hits_allowed": "Hits allowed", "pitcher_earned_runs": "Earned runs allowed",
        "pitcher_walks": "Pitcher walks", "batter_hits": "Batter hits",
        "batter_total_bases": "Total bases", "batter_rbis": "RBIs",
        "batter_runs_scored": "Runs scored", "batter_strikeouts": "Batter strikeouts",
    },
    "nhl": {
        "player_points": "Points", "player_assists": "Assists",
        "player_shots_on_goal": "Shots on goal", "player_total_saves": "Goalie saves",
        "player_power_play_points": "Power-play points", "player_blocked_shots": "Blocked shots",
    },
}
#: What is ticked when props are switched on and nothing more is chosen. Three
#: or two per league, because every market is charged per game.
DEFAULT_PROPS: dict = {
    "nfl": ("player_pass_yds", "player_rush_yds", "player_reception_yds"),
    "ncaaf": ("player_pass_yds", "player_rush_yds", "player_reception_yds"),
    "nba": ("player_points", "player_rebounds", "player_assists"),
    "ncaab": ("player_points", "player_rebounds", "player_assists"),
    "mlb": ("pitcher_strikeouts", "batter_total_bases"),
    "nhl": ("player_shots_on_goal", "player_points"),
}
PROP_LABELS: dict = {k: v for table in PROP_MARKETS.values() for k, v in table.items()}
PROP_KEYS: tuple = tuple(PROP_LABELS)

#: Props are read in the US region unless more are asked for; a region asked for
#: is charged whether or not it prices anything.
DEFAULT_PROP_REGIONS = ("us",)
#: Games per league, soonest first. The cap is what lets the cost be said before
#: the press: the list of games is only fetched after it.
DEFAULT_PROP_GAMES = 3
MAX_PROP_GAMES = 10


def league_aliases() -> list:
    return [lg.alias for lg in LEAGUES]


def in_season(today: date | None = None) -> list:
    today = today or date.today()
    return [lg for lg in LEAGUES if lg.in_season(today)]


def _pick(values, allowed: dict, what: str, default):
    if not values:
        return tuple(default)
    out = []
    for v in values:
        v = str(v).strip().lower()
        if v not in allowed:
            raise OddsApiError(
                f"{v!r} is not a {what} Bookbreaker knows. Choose from "
                f"{', '.join(allowed)}.", reason="bad_choice")
        if v not in out:
            out.append(v)
    return tuple(out)


@dataclass(frozen=True)
class Props:
    """The player-props group, switched on. `None` in an Estimate means off, which
    is the default: nothing about props is asked for, priced or fetched."""

    keys: tuple         # prop markets picked; () means each league's own defaults
    regions: tuple
    games: int          # per league, soonest first

    def keys_for(self, league: League) -> tuple:
        """The prop markets this league will be asked for: the ones picked that
        the league offers. A key the league does not offer is never sent to it."""
        if not self.keys:
            return DEFAULT_PROPS[league.alias]
        offered = PROP_MARKETS[league.alias]
        return tuple(k for k in self.keys if k in offered)


@dataclass(frozen=True)
class Estimate:
    """What one refresh will cost, worked out before anything is fetched."""

    leagues: tuple
    regions: tuple
    markets: tuple
    props: Props | None = None

    @property
    def per_league(self) -> int:
        # THE RULE: markets x regions, for one league's request.
        return len(self.markets) * len(self.regions)

    @property
    def main_total(self) -> int:
        """The bulk-endpoint part: leagues x regions x markets."""
        return self.per_league * len(self.leagues)

    # -- player props: one request per game, billed per market per region ------

    def prop_plan(self) -> list:
        """`[(league, prop keys)]` for each league that has any asked for."""
        if self.props is None:
            return []
        return [(lg, keys) for lg in self.leagues if (keys := self.props.keys_for(lg))]

    @property
    def props_games(self) -> int:
        """Games counted: the per-league cap, for each league asked about."""
        return 0 if self.props is None else self.props.games * len(self.prop_plan())

    @property
    def props_game_markets(self) -> int:
        """Markets counted over all those games (a game with 3 markets is 3)."""
        if self.props is None:
            return 0
        return self.props.games * sum(len(keys) for _, keys in self.prop_plan())

    @property
    def props_total(self) -> int:
        # THE EVENT-ODDS RULE: markets x regions, once for EVERY GAME. Counting
        # it once per league (the bulk rule) undercounts by the number of games.
        if self.props is None:
            return 0
        return self.props_game_markets * len(self.props.regions)

    def props_by_league(self) -> dict:
        if self.props is None:
            return {}
        return {lg.alias: self.props.games * len(keys) * len(self.props.regions)
                for lg, keys in self.prop_plan()}

    @property
    def total(self) -> int:
        return self.main_total + self.props_total

    def props_sentence(self) -> str:
        p = self.props
        if p is None:
            return ""
        plan = self.prop_plan()
        names = "; ".join(f"{lg.label}: {', '.join(PROP_LABELS[k] for k in keys)}" for lg, keys in plan)
        g, gm, r = self.props_games, self.props_game_markets, len(p.regions)
        return (
            f"Player props are read one game at a time: up to {p.games} game{'s' if p.games != 1 else ''} "
            f"per league, the soonest first, so {g} game{'s' if g != 1 else ''} and {gm} "
            f"game-market{'s' if gm != 1 else ''} counted ({names}), x "
            f"{r} region{'s' if r != 1 else ''} ({', '.join(p.regions)}), at 1 credit each: "
            f"up to {self.props_total} credit{'s' if self.props_total != 1 else ''}. "
            "A market no book prices for a game costs nothing for it.")

    def main_sentence(self) -> str:
        n = self.main_total
        bets = ", ".join(_PLAIN_MARKET.get(m, m) for m in self.markets)
        return (
            f"This refresh uses up to {n} of your Odds API credit{'s' if n != 1 else ''}: "
            f"{len(self.leagues)} league{'s' if len(self.leagues) != 1 else ''} "
            f"({', '.join(lg.label for lg in self.leagues)}) x "
            f"{len(self.regions)} region{'s' if len(self.regions) != 1 else ''} "
            f"({', '.join(self.regions)}) x "
            f"{len(self.markets)} bet type{'s' if len(self.markets) != 1 else ''} "
            f"({bets}), at 1 credit each. A league with no games listed costs nothing.")

    def sentence(self) -> str:
        if self.props is None:
            return self.main_sentence()
        n = self.total
        return (
            f"This refresh uses up to {n} of your Odds API credit{'s' if n != 1 else ''}: "
            f"{self.main_total} for the main odds and {self.props_total} for player props. "
            + self.main_sentence().split(": ", 1)[1] + " " + self.props_sentence())

    def as_dict(self) -> dict:
        out = {
            "credits": self.total, "per_league": self.per_league,
            "leagues": len(self.leagues), "regions": len(self.regions),
            "markets": len(self.markets), "text": self.sentence(),
            "rule": COST_RULE, "rule_source": COST_RULE_SOURCE,
            "by_league": {lg.alias: self.per_league for lg in self.leagues},
            "main_credits": self.main_total, "props": None,
        }
        if self.props is not None:
            out["props"] = {
                "credits": self.props_total, "games": self.props_games,
                "games_per_league": self.props.games, "game_markets": self.props_game_markets,
                "regions": len(self.props.regions), "region_keys": list(self.props.regions),
                "by_league": self.props_by_league(),
                "markets": {lg.alias: list(keys) for lg, keys in self.prop_plan()},
                "text": self.props_sentence(),
                "rule": PROPS_COST_RULE, "rule_source": PROPS_COST_RULE_SOURCE,
            }
        return out


def props_plan(keys=None, regions=None, games=None) -> Props:
    """Validate a props choice. `keys=None` means each league's own defaults."""
    picked = _pick(keys, PROP_LABELS, "player prop", ()) if keys else ()
    n = DEFAULT_PROP_GAMES if games is None else games
    if not isinstance(n, int) or isinstance(n, bool) or not 1 <= n <= MAX_PROP_GAMES:
        raise OddsApiError(f"Games per league for player props must be from 1 to {MAX_PROP_GAMES}.",
                           reason="bad_choice")
    return Props(picked, _pick(regions, REGIONS, "region", DEFAULT_PROP_REGIONS), n)


def estimate(sports=None, regions=None, markets=None, today: date | None = None,
             props: Props | None = None) -> Estimate:
    """Validate the choices and price them. No network, no key.

    Nothing chosen means the defaults: the leagues in season, regions us and eu
    (so Pinnacle can price fair odds), moneylines only, and no player props.
    """
    if sports:
        leagues = tuple(_pick(sports, _BY_ALIAS, "league", ()))
        leagues = tuple(_BY_ALIAS[a] for a in leagues)
    else:
        leagues = tuple(in_season(today))
        if not leagues:
            raise OddsApiError("No league is in season right now. Choose one by name.",
                               reason="bad_choice")
    got = Estimate(leagues, _pick(regions, REGIONS, "region", DEFAULT_REGIONS),
                   _pick(markets, MARKETS, "bet type", DEFAULT_MARKETS), props)
    if props is not None and not got.prop_plan():
        raise OddsApiError(
            "None of the player props you picked is offered for the leagues you chose. "
            "Pick a league that has them, or other props.", reason="bad_choice")
    return got


FREE_MONTHLY = 500      # the free plan's credits a month (the-odds-api.com, read 2026-10-09)


def budget(cost: int, credits: dict | None) -> dict:
    """How many refreshes like this one the credits cover, said beside the cost. From the credits left after the
    last refresh when this Mac has seen one, otherwise from the free plan's 500 a month. Reads nothing."""
    remaining = (credits or {}).get("remaining")
    if not cost:
        return {"refreshes": None, "remaining": remaining, "text": ""}
    if remaining is not None:
        n = max(0, int(remaining) // cost)
        text = (f"You had {remaining} credits left after your last refresh: enough for {n} more like this one."
                if n else f"You had {remaining} credits left after your last refresh, fewer than this one costs.")
        return {"refreshes": n, "remaining": remaining, "text": text}
    n = FREE_MONTHLY // cost
    return {"refreshes": n, "remaining": None,
            "text": f"The free plan's {FREE_MONTHLY} credits a month cover {n} refreshes like this one."}


def choices(est: Estimate, today: date | None = None) -> dict:
    """Everything the window needs to draw its pickers, from the engine."""
    today = today or date.today()
    p = est.props
    return {
        "leagues": [{"alias": lg.alias, "label": lg.label, "key": lg.key,
                     "in_season": lg.in_season(today), "picked": lg in est.leagues}
                    for lg in LEAGUES],
        "regions": [{"key": k, "label": v, "picked": k in est.regions}
                    for k, v in REGIONS.items()],
        "markets": [{"key": k, "label": v, "picked": k in est.markets}
                    for k, v in MARKETS.items()],
        # Off unless asked for. Its own group, so the main-market pickers above
        # (and the cost of the main-market endpoint) mean what they always did.
        "props": {
            "on": p is not None,
            "games": p.games if p else DEFAULT_PROP_GAMES,
            "max_games": MAX_PROP_GAMES,
            "regions": [{"key": k, "label": v, "picked": k in (p.regions if p else DEFAULT_PROP_REGIONS)}
                        for k, v in REGIONS.items()],
            "leagues": {alias: [{"key": k, "label": v,
                                 "picked": (k in p.keys if p and p.keys else k in DEFAULT_PROPS[alias])}
                                for k, v in table.items()]
                        for alias, table in PROP_MARKETS.items()},
        },
    }


# ------------------------------------------------------------ the books

#: The Odds API's key -> the key this engine already uses for the same book, so
#: the engine's tiers, latency priors and the window's tiles all apply.
ENGINE_KEY = {
    "draftkings": "dk", "fanduel": "fd", "betmgm": "mgm",
    "williamhill_us": "caesars", "betfair_ex_eu": "betfair",
}

#: Books a person in a regulated US state can bet at, by engine key. Everything
#: else in a response is a reference price. Chosen conservatively: an
#: offshore book, a social or sweepstakes app, or a book this table has not
#: heard of is left out of the bets rather than guessed in, because every row on
#: the board is an instruction to stake money.
BETTABLE: dict = {
    "dk": "DraftKings", "fd": "FanDuel", "mgm": "BetMGM", "caesars": "Caesars",
    "betrivers": "BetRivers", "fanatics": "Fanatics", "ballybet": "Bally Bet",
    "betparx": "betPARX", "espnbet": "theScore Bet",
    "hardrockbet": "Hard Rock Bet (IN)", "hardrockbet_az": "Hard Rock Bet (AZ)",
    "hardrockbet_fl": "Hard Rock Bet (FL)", "hardrockbet_oh": "Hard Rock Bet (OH)",
}


#: A bettable feed key -> its venue in the jurisdiction table (catalog.VENUES), where the keys differ.
CATALOG_KEY = {"ballybet": "bally", "espnbet": "thescore", "hardrockbet": "hardrock",
               "hardrockbet_az": "hardrock", "hardrockbet_fl": "hardrock", "hardrockbet_oh": "hardrock"}
#: Feed keys that carry one state's prices: Hard Rock posts each state under its own key.
FEED_STATE = {"hardrockbet": "IN", "hardrockbet_az": "AZ", "hardrockbet_fl": "FL", "hardrockbet_oh": "OH"}
NO_STATE = ("Pick your state in the top bar to see only the sportsbooks licensed there. Until you do, a price can be "
            "at a book you cannot use where you are.")


def bettable_in(state: str | None) -> set:
    """The books a person can be told to bet at: `BETTABLE`, narrowed to those licensed in `state` (two letters).

    Every best price, board leg, hedge and alert is drawn from this set, so a Michigan profile is never shown a price
    at a book Michigan has not licensed. With no state, every book in `BETTABLE` (and the window says `NO_STATE`). A
    book the jurisdiction table does not know is left out once a state is given, never guessed in.
    """
    if not state:
        return set(BETTABLE)
    from . import catalog
    st = state.strip().upper()
    out = set()
    for key in BETTABLE:
        venue = catalog.VENUES.get(CATALOG_KEY.get(key, key))
        if venue is not None and venue.available_in(st) and FEED_STATE.get(key, st) == st:
            out.add(key)
    return out


def books_for(state: str | None) -> dict:
    """What the window says about whose prices it shows: the state, and a sentence when none was picked."""
    st = (state or "").strip().upper() or None
    return {"state": st, "books": sorted(bettable_in(st)), "sentence": "" if st else NO_STATE}


def engine_book(key: str) -> str:
    return ENGINE_KEY.get(key, key)


def books_table() -> dict:
    """The engine's books plus the ones this feed adds, for `board.scan`."""
    from .cli import DEFAULT_BOOKS

    table = dict(DEFAULT_BOOKS)
    for key, name in BETTABLE.items():
        table.setdefault(key, Book(key, name, BookTier.RETAIL))
    for key, name in (("polymarket", "Polymarket"), ("prophetx", "ProphetX")):
        table.setdefault(key, Book(key, name, BookTier.EXCHANGE, limits_winners=False))
    return table


# ------------------------------------------------------------ the disk

@dataclass
class Entry:
    payload: list
    headers: dict
    fetched_at: float


class Cache:
    """One file per (league, regions, markets), holding the last answer and when
    it was fetched. Never holds the key; readable by its owner only."""

    def __init__(self, folder=None, ttl: float = CACHE_SECONDS):
        self.folder = Path(folder) if folder else home() / "oddsapi"
        self.ttl = ttl

    def _file(self, sport, regions, markets) -> Path:
        tag = f"{sport}|{','.join(sorted(regions))}|{','.join(sorted(markets))}"
        return self.folder / "cache" / (hashlib.sha1(tag.encode()).hexdigest()[:20] + ".json")

    def get(self, sport, regions, markets, now: float):
        """The answer fetched less than `ttl` seconds ago, or None."""
        try:
            data = json.loads(self._file(sport, regions, markets).read_text())
            fetched = float(data["fetched_at"])
            payload, headers = data["payload"], dict(data["headers"])
        except (OSError, ValueError, KeyError, TypeError):
            return None
        if not isinstance(payload, list) or not (0.0 <= now - fetched < self.ttl):
            return None
        return Entry(payload, headers, fetched)

    def put(self, sport, regions, markets, payload, headers, fetched_at: float) -> None:
        try:
            path = self._file(sport, regions, markets)
            path.parent.mkdir(parents=True, exist_ok=True)
            for d in (self.folder, path.parent):
                os.chmod(d, 0o700)
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps({
                "fetched_at": fetched_at, "sport": sport,
                "regions": sorted(regions), "markets": sorted(markets),
                "headers": {k: v for k, v in headers.items()
                            if str(k).lower().startswith("x-requests-")},
                "payload": payload,
            }))
            os.chmod(tmp, 0o600)
            os.replace(tmp, path)
            self._prune(fetched_at)
        except OSError:
            pass            # a cache that cannot be written only costs a refetch

    def _prune(self, now: float) -> None:
        """An hour is far past the minute anything here is reused for. Judged by
        the fetch time written inside each file, on the same clock that wrote
        it, never by the file's own timestamp."""
        for old in (self.folder / "cache").glob("*.json"):
            try:
                if now - float(json.loads(old.read_text())["fetched_at"]) > 3600:
                    old.unlink()
            except (OSError, ValueError, KeyError, TypeError):
                try:
                    old.unlink()
                except OSError:
                    pass

    def clear(self) -> int:
        n = 0
        for f in list((self.folder / "cache").glob("*")) + [self.folder / "credits.json"]:
            try:
                f.unlink()
                n += 1
            except OSError:
                pass
        # The odds this key fetched include the history of them (`oddshistory`).
        n += oddshistory.clear(self.folder / "history")
        # ...and the futures it read (`futures.py`), kept apart from the history of the main odds.
        n += futurestore.clear(self.folder / "futures")
        # ...and each game's alternate lines (`altlines.py`).
        from . import altlines
        n += altlines.clear(self.folder / "altlines")
        return n

    # The last credits reading, kept so the window can say how many are left
    # without spending one to find out.
    def remember(self, quota: Quota, at: float) -> None:
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            os.chmod(self.folder, 0o700)
            path = self.folder / "credits.json"
            path.write_text(json.dumps({"remaining": quota.remaining, "used": quota.used,
                                        "last": quota.last, "at": at}))
            os.chmod(path, 0o600)
        except OSError:
            pass

    def recall(self):
        try:
            data = json.loads((self.folder / "credits.json").read_text())
            return {"remaining": data.get("remaining"), "used": data.get("used"),
                    "last": data.get("last"), "at": data.get("at")}
        except (OSError, ValueError, AttributeError):
            return None


# ------------------------------------------------------------ the network

def explain(status: int | None, body: str, headers: dict) -> OddsApiError:
    """An HTTP failure in plain words.

    The body's `error_code` is the API's own name for what went wrong
    (https://the-odds-api.com/liveapi/guides/v4/api-error-codes.html); the
    status is the fallback; `x-requests-remaining: 0` settles an ambiguous
    refusal as the allowance being spent.
    """
    code = ""
    try:
        data = json.loads(body)
        code = str(data.get("error_code") or "") if isinstance(data, dict) else ""
    except (ValueError, TypeError):
        pass
    lower = {str(k).lower(): v for k, v in (headers or {}).items()}
    spent_up = str(lower.get("x-requests-remaining", "")).strip() == "0"

    if code == "OUT_OF_USAGE_CREDITS" or (status in (401, 429) and spent_up):
        return OddsApiError(CREDITS_GONE, "out_of_credits", status)
    if code == "DEACTIVATED_KEY":
        return OddsApiError(
            "That Odds API key has been turned off, usually because the plan was "
            "cancelled. Sign in at the-odds-api.com to start a new one.", "bad_key", status)
    if code in ("INVALID_KEY", "MISSING_KEY") or status == 401:
        return OddsApiError(
            "The Odds API did not accept your key. Check it was copied whole from "
            "the email The Odds API sent you, then save it again.", "bad_key", status)
    if code == "EXCEEDED_FREQ_LIMIT" or status == 429:
        return OddsApiError(
            "The Odds API asked Bookbreaker to slow down. Wait a few seconds and "
            "press the button again.", "slow_down", status)
    if status is not None and status >= 500:
        return OddsApiError(
            "The Odds API had a problem on its side. Try again in a minute.",
            "their_problem", status)
    return OddsApiError(
        "The Odds API did not understand that request"
        + (f" ({code})" if code else "") + ". Check for a newer Bookbreaker.",
        "rejected", status)


class NoRedirect(HTTPRedirectHandler):
    """The key is in the query string, so a redirect would hand it to whoever
    the answer named. The 3xx surfaces as an HTTPError instead, unfollowed."""

    def redirect_request(self, *args, **kwargs):
        return None


def odds_api_fetcher(timeout: float = 15.0, opener=None):
    """`(path, params) -> (payload, headers)`, the only code that sends the key.

    `opener` is a seam for tests; the default follows no redirects.
    """
    open_ = opener if opener is not None else build_opener(NoRedirect).open

    def _fetch(path: str, params: dict):
        url = f"{BASE}{path}?{urlencode(params)}"
        if not url.startswith(f"https://{HOST}/"):
            raise OddsApiError("Bookbreaker only talks to The Odds API.", "refused")
        try:
            with open_(url, timeout=timeout) as response:
                body = response.read().decode("utf-8", "replace")
                headers = dict(response.headers.items())
        except HTTPError as exc:
            try:
                text = exc.read().decode("utf-8", "replace")
            except Exception:                            # noqa: BLE001
                text = ""
            raise explain(exc.code, text, dict(exc.headers.items() if exc.headers else [])) from None
        except (URLError, OSError, ValueError):
            raise OddsApiError(
                "Bookbreaker could not reach The Odds API. Check your internet "
                "connection and try again.", "offline") from None
        try:
            return json.loads(body), headers
        except ValueError:
            raise OddsApiError(
                "The Odds API sent an answer Bookbreaker could not read. Try again "
                "in a minute.", "unreadable") from None

    return _fetch


# ------------------------------------------------------------ one refresh

@dataclass
class LeagueRead:
    league: League
    events: int
    from_cache: bool
    fetched_at: float
    credits: int | None         # what this call cost; 0 when it came off the disk


@dataclass
class PropRead:
    """One league's player props: the games read, and what they cost."""

    league: League
    games: int                  # games whose props were read
    cached: int                 # of those, answered off the disk (no credits)
    credits: int | None         # what the fetched ones cost; None if the API did not say
    fetched_at: float
    bound: int = 0              # the most this league could cost, by the rule


@dataclass
class Refresh:
    estimate: Estimate
    markets: list = field(default_factory=list)
    event_info: dict = field(default_factory=dict)      # event id -> label, league, start
    book_names: dict = field(default_factory=dict)      # engine key -> display name
    reads: list = field(default_factory=list)
    quota: Quota = field(default_factory=Quota)
    errors: list = field(default_factory=list)
    dated: int = 0
    undated: int = 0
    skewed: int = 0
    under_way: int = 0
    now: float = 0.0
    # Player props, kept apart from `markets`: they are not recorded in the line
    # history, not offered to Ask, and not scanned for middles.
    props: list = field(default_factory=list)           # one Market per game, market, player and line
    prop_reads: list = field(default_factory=list)
    props_skipped: int = 0                              # outcomes that were not a priced over/under

    @property
    def spent(self) -> int:
        return (sum(r.credits or 0 for r in self.reads)
                + sum(r.credits or 0 for r in self.prop_reads))

    @property
    def spent_known(self) -> bool:
        return (all(r.credits is not None for r in self.reads if not r.from_cache)
                and all(r.credits is not None for r in self.prop_reads if r.games > r.cached))

    @property
    def oldest(self) -> float:
        return min([r.fetched_at for r in self.reads] + [r.fetched_at for r in self.prop_reads],
                   default=self.now)

    @property
    def all_cached(self) -> bool:
        return (bool(self.reads) and all(r.from_cache for r in self.reads)
                and all(r.games == r.cached for r in self.prop_reads))

    def sharp_prices(self) -> bool:
        from .cli import DEFAULT_BOOKS
        return any(DEFAULT_BOOKS.get(q.book) is not None
                   and DEFAULT_BOOKS[q.book].tier in (BookTier.SHARP, BookTier.EXCHANGE)
                   for m in self.markets for q in m.quotes)

    def sharp_props(self) -> bool:
        from .cli import DEFAULT_BOOKS
        return any(DEFAULT_BOOKS.get(q.book) is not None
                   and DEFAULT_BOOKS[q.book].tier in (BookTier.SHARP, BookTier.EXCHANGE)
                   for m in self.props for q in m.quotes)


class _Tap:
    """A fetcher that remembers what it returned, so the caller can cache it."""

    def __init__(self, inner):
        self.inner = inner
        self.payload = None
        self.headers: dict = {}

    def __call__(self, path, params):
        self.payload, self.headers = self.inner(path, params)
        return self.payload, self.headers


def _label(event: dict) -> str:
    home_t, away_t = event.get("home_team"), event.get("away_team")
    return f"{away_t} at {home_t}" if home_t and away_t else str(event.get("id", ""))


# ------------------------------------------------------------ player props

def _player(name) -> str:
    """The name two books must share for their prices to be about one player.
    Case and spacing are ignored; anything else (a suffix, an initial) is a
    different key, so a spelling the books disagree on costs a pair and never
    makes a false one."""
    return " ".join(str(name or "").split()).casefold()


def parse_prop_event(event, sport: str, received_at: float, asked) -> tuple:
    """One event-odds answer into markets, one per (market, player, line).

    The answer is one game with `bookmakers` > `markets` > `outcomes`, each
    outcome `{name: Over|Under, description: <player>, price, point}` and
    `last_update` on the market (the guide, "GET event odds", read 2026-10-12;
    tests/fixtures/oddsapi/event_odds_props.json is that shape written out).

    **Only the same player, market and line are ever pooled.** A Market here is
    one player's one market at one line, so no book's Over can meet another
    player's Under, or the same player's Under at a different line. That is
    structural, not a filter after the fact: the pair does not exist to be
    found. The player is also in each outcome's name.

    Returns `(markets, skipped)`. `skipped` counts outcomes that were not a
    priced Over or Under for a named player at a line (Yes/No markets, Over-only
    ones, a missing point); a market whose key was not asked for is ignored.
    """
    if not isinstance(event, dict):
        raise FeedError(f"expected one event, got {type(event).__name__}")
    try:
        event_id = str(event["id"])
        starts_at = parse_time(event["commence_time"])
    except (KeyError, TypeError) as exc:
        raise FeedError(f"event missing {exc} — refusing a partial map")

    grouped: dict = {}
    shown: dict = {}
    skipped = 0
    for book in event.get("bookmakers") or []:
        book_key = str(book.get("key") or "")
        if not book_key:
            raise FeedError(f"{event_id}: a bookmaker block has no key")
        for market in book.get("markets") or []:
            mkey = str(market.get("key") or "")
            if mkey not in asked:
                continue
            stamp_text = market.get("last_update") or book.get("last_update")
            seen_at = parse_time(stamp_text) if stamp_text else received_at
            for outcome in market.get("outcomes") or []:
                side = str(outcome.get("name") or "").strip().lower()
                who = " ".join(str(outcome.get("description") or "").split())
                point = outcome.get("point")
                if side not in ("over", "under") or not who or point is None:
                    skipped += 1
                    continue
                try:
                    price, line = float(outcome["price"]), float(point)
                except (KeyError, TypeError, ValueError) as exc:
                    raise FeedError(f"{event_id} {mkey}: bad outcome ({exc})")
                if price <= MIN_DECIMAL:
                    raise FeedError(f"{event_id} {mkey}: price {price} is not decimal odds")
                slot = grouped.get((mkey, _player(who), line))
                if slot is None:
                    slot = grouped[(mkey, _player(who), line)] = Market(
                        event_id=event_id, sport=sport, market_type=mkey, quotes=[],
                        starts_at=starts_at)
                    shown[id(slot)] = who           # the first spelling seen names him
                name = f"{shown[id(slot)]} {side.capitalize()}"
                if any(q.book == engine_book(book_key) and q.outcome.name == name for q in slot.quotes):
                    skipped += 1        # a book listing one side twice: the first stands
                    continue
                slot.quotes.append(Quote(book=engine_book(book_key), outcome=Outcome(name=name, line=line),
                                         decimal=price, seen_at=seen_at))
    return list(grouped.values()), skipped


def _problem(exc: Exception, what: str) -> OddsApiError:
    """Any failure out of a call that held the key, as a sentence that does not
    carry the key or the address."""
    if isinstance(exc, OddsApiError):
        return exc
    if isinstance(exc, FeedError):
        return OddsApiError(f"The Odds API sent {what} Bookbreaker could not read, so none "
                            "are shown for it.", "unreadable")
    return OddsApiError(f"Reading {what} failed unexpectedly ({type(exc).__name__}). "
                        "Try again in a minute.", "unexpected")


def _read_props(out: Refresh, key: str, *, clock, cache: Cache, fetcher) -> None:
    """Player props for each league asked about, one free list of games and then
    one event-odds request per game, soonest first, up to `games` of them.

    Stops, keeping what was read, at the first thing that should end a spending
    run: a failure that is not about one game, credits too few for the next
    request, or a request charged more than the rule allows. A single game the
    API rejects (it may have started since it was listed) is skipped and said.
    """
    est = out.estimate
    props = est.props
    regions = props.regions
    for league, keys in est.prop_plan():
        bound = len(keys) * len(regions)            # the most ONE game can cost
        listed = cache.get(f"{league.key}/events", (), (), clock())
        try:
            if listed is not None:
                games = listed.payload
            else:
                games, _ = fetcher(f"/v4/sports/{league.key}/events",
                                   {"apiKey": key, "dateFormat": "iso"})
                if not isinstance(games, list):
                    raise FeedError("expected a list of games")
                cache.put(f"{league.key}/events", (), (), games, {}, clock())
            upcoming = []
            for g in games:
                try:
                    start = parse_time(g["commence_time"])
                    upcoming.append((start, str(g["id"]), g))
                except (KeyError, TypeError, FeedError):
                    continue
        except Exception as exc:                     # noqa: BLE001
            out.errors.append(str(_problem(exc, f"{league.label} games")))
            return
        upcoming = sorted((u for u in upcoming if u[0] > clock()), key=lambda u: u[:2])[:props.games]

        read = PropRead(league, 0, 0, 0, clock(), 0)
        out.prop_reads.append(read)
        stop = False
        for start, event_id, g in upcoming:
            if out.quota.remaining is not None and out.quota.remaining < bound:
                out.errors.append(
                    f"Player props stopped before {_label(g)}: it needs up to {bound} credits and "
                    f"you have {out.quota.remaining} left this month.")
                stop = True
                break
            tag = f"{league.key}/{event_id}"
            entry = cache.get(tag, regions, keys, clock())
            try:
                if entry is not None:
                    payload, headers, got_at = entry.payload[0], entry.headers, entry.fetched_at
                else:
                    got_at = clock()
                    payload, headers = fetcher(
                        f"/v4/sports/{league.key}/events/{event_id}/odds",
                        {"apiKey": key, "regions": ",".join(regions), "markets": ",".join(keys),
                         "oddsFormat": "decimal", "dateFormat": "iso"})
                markets, skipped = parse_prop_event(payload, league.key, got_at, set(keys))
            except Exception as exc:                 # noqa: BLE001
                problem = _problem(exc, f"{_label(g)} player props")
                out.errors.append(str(problem))
                if problem.reason == "rejected":
                    continue                         # one game gone; the rest may be fine
                stop = True
                break
            read.fetched_at = min(read.fetched_at, got_at)
            read.bound += bound
            read.games += 1
            if entry is not None:
                read.cached += 1
            else:
                cache.put(tag, regions, keys, [payload], headers, got_at)
                quota = read_quota(headers)
                out.quota = quota
                cache.remember(quota, got_at)
                if quota.last is None:
                    read.credits = None             # unknown stays unknown
                elif read.credits is not None:
                    read.credits += quota.last
                if quota.last is not None and quota.last > bound:
                    # The documented rule says this cannot happen. If it did, the
                    # rule is wrong or has changed, and every further request
                    # would be charged at a rate nobody was told.
                    out.errors.append(
                        f"The Odds API charged {quota.last} credits for one game's player props, "
                        f"and Bookbreaker's count allows {bound}. Player props stopped. Check "
                        "for a newer Bookbreaker.")
                    stop = True
            snap = stamp(markets, got_at, "oddsapi")
            out.dated += snap.dated
            out.undated += snap.undated
            out.skewed += snap.skewed
            out.props_skipped += skipped
            out.props.extend(snap.markets)
            out.event_info.setdefault(event_id, {
                "label": _label(g), "league": league.label, "starts": g.get("commence_time")})
            for b in payload.get("bookmakers") or []:
                raw = str(b.get("key") or "")
                out.book_names.setdefault(engine_book(raw), str(b.get("title") or raw))
            if stop:
                break
        if stop:
            return


def refresh(est: Estimate, key: str, *, clock=None, cache: Cache | None = None,
            fetcher=None) -> Refresh:
    """Fetch every league (or reuse the last minute's answer), through
    `RestProvider`, and return stamped markets.

    A failure after at least one league was read ends the refresh and keeps what
    was read, with the reason in `errors`; a failure before any raises, so a
    person is never shown an empty board that was really an error.
    """
    clock = clock if clock is not None else time.time
    cache = cache if cache is not None else Cache()
    fetcher = fetcher if fetcher is not None else odds_api_fetcher()
    out = Refresh(estimate=est)

    for league in est.leagues:
        entry = cache.get(league.key, est.regions, est.markets, clock())
        if entry is not None:
            tap = _Tap(lambda path, params, e=entry: (e.payload, e.headers))
            got_at = entry.fetched_at
        else:
            tap = _Tap(fetcher)
            got_at = clock()
        provider = RestProvider(
            fetcher=tap, api_key=key, regions=",".join(est.regions),
            market_keys=tuple(est.markets), sport_keys=(league.key,),
            key="oddsapi", received_at=got_at)
        try:
            mapped = provider.fetch(league.key)
        except OddsApiError as exc:
            if not out.reads:
                raise
            out.errors.append(str(exc))
            break
        except FeedError:
            problem = OddsApiError(
                f"The Odds API sent {league.label} odds Bookbreaker could not read, "
                "so none are shown for it.", "unreadable")
            if not out.reads:
                raise problem from None
            out.errors.append(str(problem))
            break
        except Exception as exc:                         # noqa: BLE001
            # Anything else came out of a call that had the key in its
            # parameters. Its message is not shown: it may hold the address,
            # and the address holds the key. Only its type is.
            problem = OddsApiError(
                f"Reading {league.label} odds failed unexpectedly "
                f"({type(exc).__name__}). Try again in a minute.", "unexpected")
            if not out.reads:
                raise problem from None
            out.errors.append(str(problem))
            break

        payload = tap.payload
        if entry is None:
            cache.put(league.key, est.regions, est.markets, payload, tap.headers, got_at)
            cache.remember(provider.quota, got_at)
        out.quota = provider.quota
        spent = 0 if entry is not None else provider.quota.last

        for event in payload:
            for book in event.get("bookmakers") or []:
                raw = str(book.get("key") or "")
                out.book_names.setdefault(engine_book(raw), str(book.get("title") or raw))
            out.event_info[str(event.get("id"))] = {
                "label": _label(event), "league": league.label,
                "starts": event.get("commence_time")}

        for market in mapped:
            for quote in market.quotes:
                quote.book = engine_book(quote.book)
        snap = stamp(mapped, got_at, "oddsapi")
        out.dated += snap.dated
        out.undated += snap.undated
        out.skewed += snap.skewed
        out.reads.append(LeagueRead(league, len(payload), entry is not None, got_at, spent))
        out.markets.extend(snap.markets)

    # Player props only after the main read went through whole: a failure there
    # (out of credits, a bad key) is not made worse by asking for the dearer part.
    if est.props is not None and not out.errors:
        _read_props(out, key, clock=clock, cache=cache, fetcher=fetcher)

    out.now = clock()
    # A game under way is left off: its price is stale by the time it is read,
    # and the second leg of an arb is the one that is not there.
    began = {m.event_id for m in out.markets + out.props
             if m.starts_at is not None and m.starts_at <= out.now}
    out.under_way = len(began)
    out.markets = [m for m in out.markets if m.event_id not in began]
    out.props = [m for m in out.props if m.event_id not in began]
    for name, known in BETTABLE.items():
        out.book_names[name] = known
    # Kept so a line move can be measured later from the first price seen.
    oddshistory.record(out, cache.folder / "history")
    return out


def split_by_line(markets) -> list:
    """Spreads and totals as one market per line.

    The API sends every line a book posts for a game inside one market, so a
    spread market holds Chiefs -3.5, Chiefs -2.5 and Bills +3.5 side by side.
    The engine compares one pair of sides at a time, and a market holding
    several lines either finds nothing (no book prices every outcome) or, worse,
    would set the two sides of different bets against each other. Grouping by
    the size of the line gives each its own two-sided market: Over 47.5 meets
    Under 47.5, Chiefs -3.5 meets Bills +3.5, and a half-point difference is a
    middle (found separately, on the unsplit market) and never an arb.
    """
    out = []
    for market in markets:
        if market.market_type not in ("spreads", "totals"):
            out.append(market)
            continue
        groups: dict = {}
        for quote in market.quotes:
            line = quote.outcome.line
            groups.setdefault(None if line is None else abs(line), []).append(quote)
        out.extend(_replace(market, quotes=quotes) for quotes in groups.values())
    return out


# ------------------------------------------------------------ what the board says

def source_line(r: Refresh) -> str:
    when = datetime.fromtimestamp(r.oldest, timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    base = (f"The Odds API, regions {', '.join(r.estimate.regions)}, "
            f"{', '.join(r.estimate.markets)}, prices fetched {when}")
    if r.estimate.props is not None:
        games = sum(x.games for x in r.prop_reads)
        base += (f"; player props from {games} game{'s' if games != 1 else ''} "
                 f"(regions {', '.join(r.estimate.props.regions)})")
    if r.all_cached:
        base += f" (reused for {int(CACHE_SECONDS)} seconds, so no credits were spent)"
    return base


def credits_line(r: Refresh) -> str:
    if r.all_cached:
        used = "No credits were spent: these prices were fetched in the last minute."
    elif r.spent_known:
        used = f"This refresh used {r.spent} credit{'s' if r.spent != 1 else ''}."
    else:
        used = "The Odds API did not say what this refresh cost."
    if r.quota.known:
        left = f" {r.quota.remaining} left this month ({r.quota.used} used so far)."
    else:
        left = " The Odds API did not say how many credits are left."
    return used + left


def summary(r: Refresh, state: str | None = None) -> dict:
    """The `odds` block of the board's JSON: everything the window prints about
    where the prices came from and what they cost. `state` narrows the books a bet
    is shown at to those licensed there (`bettable_in`)."""
    everything = r.markets + r.props
    read_books = {q.book for m in everything for q in m.quotes}
    can = bettable_in(state)
    reference = sorted({r.book_names.get(q.book, q.book)
                        for m in everything for q in m.quotes if q.book not in BETTABLE})
    notes = []
    if r.markets and not r.sharp_prices():
        notes.append("No Pinnacle or exchange prices were in this read, so +EV bets "
                     "could not be priced. Add the Europe region to price them.")
    if r.under_way:
        notes.append(f"{r.under_way} game{'s' if r.under_way != 1 else ''} already under way "
                     "left off: a price changes too fast in play to bet from here.")
    props = None
    if r.estimate.props is not None:
        if not r.props:
            notes.append("No player props were priced for these games. Books often post them "
                         "close to game time, and only some post them at all.")
        elif not r.sharp_props():
            notes.append("No Pinnacle or exchange price was on any player prop, so +EV prop bets "
                         "could not be priced. Arbs between the books that did price them still show.")
        props = {
            "games": sum(x.games for x in r.prop_reads),
            "markets_priced": len(r.props), "skipped": r.props_skipped,
            "estimate": r.estimate.props_total,
            "spent": (sum(x.credits or 0 for x in r.prop_reads)
                      if all(x.credits is not None for x in r.prop_reads if x.games > x.cached) else None),
            "leagues": [{"alias": x.league.alias, "label": x.league.label, "games": x.games,
                         "from_cache": x.cached, "credits": x.credits, "most": x.bound}
                        for x in r.prop_reads],
        }
    return {
        "props": props,
        "fetched_at": r.oldest, "cached": r.all_cached, "cache_seconds": CACHE_SECONDS,
        "regions": list(r.estimate.regions), "markets": list(r.estimate.markets),
        "leagues": [{"alias": x.league.alias, "label": x.league.label, "events": x.events,
                     "from_cache": x.from_cache, "credits": x.credits} for x in r.reads],
        "cost": {"estimate": r.estimate.total, "spent": r.spent if r.spent_known else None,
                 "remaining": r.quota.remaining, "used": r.quota.used,
                 "last": r.quota.last, "text": credits_line(r)},
        "dated": r.dated, "undated": r.undated, "skewed": r.skewed,
        "under_way": r.under_way, "errors": list(r.errors), "notes": notes,
        "reference_only": reference,
        "bet_at": sorted(BETTABLE[b] for b in read_books if b in can),
        # US-licensed books this read priced that are not licensed in the person's state: shown nowhere as a bet.
        "not_licensed": sorted(BETTABLE[b] for b in read_books if b in BETTABLE and b not in can),
        "books_for": books_for(state),
    }


def describe_rows(rows, r: Refresh) -> list:
    """The board's rows with names a person can read in place of ids."""
    out = []
    for row in rows:
        d = row.as_dict()
        info = r.event_info.get(row.event, {})
        d["event_id"] = row.event
        d["event"] = info.get("label", row.event)
        d["league"] = info.get("league", "")
        d["starts_at"] = info.get("starts")
        d["market_label"] = PROP_LABELS.get(row.market, "")      # "" for the main markets
        d["prop"] = row.market in PROP_LABELS
        for leg in d["legs"]:
            leg["book_name"] = r.book_names.get(leg["book"], leg["book"])
        out.append(d)
    return out
