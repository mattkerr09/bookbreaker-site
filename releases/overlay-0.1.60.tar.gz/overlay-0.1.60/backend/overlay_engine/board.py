"""The screen a bettor actually wants: every play on one board, ranked.

This is the thing the product was missing, and the reason someone who has used
OddsJam or AVO opens Bookbreaker and does not recognise it. Those tools answer
"what should I bet right now" with a table you scan top to bottom. Ours
answered "what is this price worth", one price at a time, which is a
statistician's question and not a bettor's.

**A board is only as real as its prices.** Every row here comes from a market
this process was handed — a recorded snapshot, or a live provider when one is
configured. Nothing is generated to fill the screen. With no source of prices
there are no rows, and the caller is told that plainly rather than shown a
plausible table. A board that invents its own rows is the single most
expensive lie this codebase could tell, because every row is an instruction to
go and stake money.

**Ranked by what you actually collect.** Not by headline margin: an arb whose
second leg is unlikely to still be there when you get to it is worth less than
a smaller one that will be. `realised` is margin multiplied by the chance both
legs survive, and that is the sort order.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from dataclasses import replace as _replace

from . import betorder, preset, tracking
from .arb import find_arbs, stake_arb
from .detail import FairCache, row_detail
from .ev import find_edges
from .middles import find_middles
from .odds import decimal_to_american
from .screen import side_label
from .staleness import price_age


def _american(decimal: float) -> int:
    """The price the way a US book prints it, so the window never converts one."""
    return round(decimal_to_american(decimal))


@dataclass
class Row:
    """One play, with everything needed to place it and nothing else."""

    kind: str                      # arb | ev | middle
    event: str
    sport: str
    market: str
    legs: list[dict] = field(default_factory=list)
    margin: float = 0.0            # the headline number, before survival
    realised: float = 0.0          # margin x chance both legs are still there
    p_fill: float = 1.0
    age: float = 0.0
    stakes: list[float] = field(default_factory=list)
    profit: float = 0.0
    outcomes: list[dict] = field(default_factory=list)
    """What the pair pays for each way the game can end (see `betorder`). Empty
    for a single +EV bet, which has no pair to compare."""
    order_rule: str = ""
    """The one sentence that numbered the legs, so the window prints the engine's
    reason and not its own."""
    detail: dict | None = None
    """The fair price, EV by book and the two-sided price table (`detail`)."""
    preset_misses: list = field(default_factory=list)
    """Why the Recommended preset would hide this play (`preset.misses`); empty when it would not."""
    starts_at: float | None = None
    """When the game starts, epoch seconds, where the data carries it (`boardfilter` judges game state and the date
    range from it)."""
    window_points: float | None = None
    """A middle's window: the gap in points between its two lines. None for every other kind (`boardfilter`)."""

    def as_dict(self) -> dict:
        # How old each price is, worded by the engine, and whether it is past the limit (`staleness.price_age`).
        # The row's own age is its oldest leg's, floored by the feed's latency exactly as the fill chance is.
        # The legs are the row's own dicts, not copies: `oddsapi.describe_rows` names the books on the dicts it gets.
        for leg in self.legs:
            if "age" in leg:
                leg["price_age"] = price_age(leg["age"], self.market)
        return {
            "kind": self.kind, "event": self.event, "sport": self.sport,
            "market": self.market, "legs": self.legs,
            "margin": self.margin, "realised": self.realised,
            "p_fill": self.p_fill, "age": self.age,
            "price_age": price_age(self.age, self.market),
            "stakes": self.stakes, "profit": self.profit,
            "staked": round(sum(self.stakes), 2),
            # The return on the stakes the card shows, after rounding. `margin` is the arb's margin on exact stakes;
            # a card labelled RETURN showed 1.65% beside $15.00 on $970, which is 1.55% (audit M5, 2026-11-04).
            "return_on_stake": (self.profit / sum(self.stakes)
                                if self.kind == "arb" and self.profit is not None and sum(self.stakes) > 0 else None),
            "outcomes": self.outcomes, "order_rule": self.order_rule,
            "detail": self.detail,
            "recommended": not self.preset_misses, "preset_misses": self.preset_misses,
            "start_epoch": self.starts_at, "window_points": self.window_points,
            "window_text": "" if self.window_points is None else f"{self.window_points:g}-point window",
            # A suggested stake for a +EV play, filled in only when a bankroll is given (kelly.stake_rows).
            "sizing": None,
        }


#: The three shapes of play both OddsJam and AVO put on their screens. Ours
#: was arbitrage only, which is the rarest of the three — a board that shows
#: just arbs is empty most of the time and gives the impression the tool has
#: found nothing, when what it has found is that today is a +EV day.
KINDS = ("arb", "ev", "middle")


def scan(markets, books=None, *, bankroll: float = 1000.0,
         min_margin: float = 0.0, now: float | None = None,
         fill_model=None, latency_model=None,
         kinds: tuple = KINDS, min_ev: float = 0.0,
         bettable=None, detail: bool = False,
         names: dict | None = None, history=None, stats: dict | None = None, formula=None) -> list[Row]:
    """Every playable arbitrage across every market handed in, best first.

    `markets` is whatever the caller has — a replay snapshot, a live provider's
    fetch, one demonstration market. This function does not go and get them,
    which is what keeps it honest: it cannot invent a row it was not given.

    `bettable` is the set of book keys a person can actually place a bet at.
    Left as None, every book is (a snapshot of recorded prices has no opinion).
    Given, a book outside it still PRICES the market, so Pinnacle's line can
    set the fair odds, but it is never a leg of an arb, a middle or a +EV bet:
    a row whose leg sits at a book the person cannot use is not a play.

    `detail` adds to each row the fair price, EV by book and the full price
    table for its market (`detail.row_detail`). It is off unless asked for,
    because it is a good deal more than most callers print; `names` gives the
    display name of each book for it. `history` adds, to each detail, a chart of
    each leg's price over the reads kept on this Mac (`linehistory`).

    `stats`, when given, gains `under_margin`: how many arbs `min_margin` left out, for the filter counts
    (`filtercounts`). It changes no row.

    `formula` (`formula.Formula`, or None for the engine's own blend) is the person's EV formula: every +EV bet is
    priced against the weighted blend of the formula's books and kept only when enough of the formula's weight priced
    it, and the detail agrees with the row. Arbs and middles do not use a fair price and are not touched. With
    `stats`, it gains `formula_shown`, `formula_default` (what the bets would be without it) and `formula_below`
    (+EV bets left out for too little of the formula's weight).
    """
    if books is None:
        from .cli import DEFAULT_BOOKS
        books = DEFAULT_BOOKS
    now = time.time() if now is None else now
    rows: list[Row] = []
    cache = FairCache(formula)

    def detailed(market, legs, kind):
        if not detail:
            return None
        return row_detail(market, books, [{"book": leg["book"], "outcome": leg["outcome"]} for leg in legs],
                          kind, bettable=bettable, now=now, cache=cache, names=names, history=history)

    # The books a leg may sit at. Arbs and middles are built from these alone;
    # +EV is priced against all of them and then kept only where it can be bet.
    placeable = markets if bettable is None else [
        _replace(m, quotes=[q for q in m.quotes if q.book in bettable])
        for m in markets]

    for full, market in zip(markets, placeable):
        if "arb" not in kinds:
            break
        arbs = find_arbs(market, books, now, min_margin=min_margin,
                         fill_model=fill_model, latency_model=latency_model)
        if stats is not None and min_margin > 0:
            every = find_arbs(market, books, now, min_margin=0.0,
                              fill_model=fill_model, latency_model=latency_model)
            stats["under_margin"] = stats.get("under_margin", 0) + len(every) - len(arbs)
        for found in arbs:
            # Staked through the same searcher the arb calculator uses, so a
            # row on the board and the same play typed into the calculator
            # cannot disagree. The legs come back with net decimals; stakes
            # are computed on those, because commission decides the split.
            plan = stake_arb(
                [leg["net_decimal"] for leg in found["legs"]],
                bankroll,
                books=[leg["book"] for leg in found["legs"]],
                outcomes=[leg["outcome"] for leg in found["legs"]],
            )
            legs = [
                {
                    "book": leg["book"],
                    "outcome": leg["outcome"],
                    "decimal": leg["decimal"],
                    "net_decimal": leg["net_decimal"],
                    "age": round(leg["age"], 1),
                    "stake": staked.stake,
                    "american": _american(leg["decimal"]),
                    # What the whole pair makes if THIS leg is the one that
                    # wins. The locked `profit` is the smaller of these.
                    "if_wins": round(staked.payout - plan.total_stake, 2),
                }
                for leg, staked in zip(found["legs"], plan.legs)
            ]
            fills = [None if fill_model is None else
                     fill_model.p_fill(leg["book"], found["market_type"], leg["age"])
                     for leg in found["legs"]]
            place, rule = betorder.by_fill(fills, [leg["stake"] for leg in legs])
            for leg, f, n in zip(legs, fills, place):
                leg["order"] = n
                leg["p_fill"] = None if f is None else round(f, 3)
            if detail:
                tracking.attach("arb", full, books, legs, cache, names)
            rows.append(Row(
                kind="arb",
                event=found["event_id"],
                sport=found["sport"],
                market=found["market_type"],
                legs=legs,
                margin=found["margin"],
                realised=found["realised_margin"],
                p_fill=found["p_fill"],
                age=found["max_age"],
                stakes=[leg["stake"] for leg in legs],
                # The profit that is locked IF BOTH BETS ARE ACCEPTED at these
                # prices AND STAND — the worst outcome once stakes are rounded
                # — not margin x bankroll, which describes a position nobody
                # holds. It is conditional: a book can refuse a bet, cut a
                # limit or void one, and then nothing is locked.
                profit=plan.profit,
                outcomes=betorder.arb_outcomes(
                    [side_label(leg["outcome"], found["market_type"]) for leg in legs],
                    [leg["if_wins"] for leg in legs]),
                order_rule=rule,
                detail=detailed(full, legs, "arb"),
                # A sportsbook's price carries no amount on offer, so only the market, the price and the width
                # can mark it down.
                preset_misses=preset.misses(found["market_type"], [leg["decimal"] for leg in legs],
                                            None, preset.market_width(full)),
                starts_at=getattr(full, "starts_at", None),
            ))

    if "ev" in kinds:
        for market in markets:
            tally = {} if formula is not None else None
            if formula is not None and stats is not None:
                stats["formula_default"] = stats.get("formula_default", 0) + sum(
                    1 for e in find_edges(market, books, now, min_ev=min_ev, fill_model=fill_model,
                                          latency_model=latency_model)
                    if bettable is None or e.book in bettable)
            edges = find_edges(market, books, now, min_ev=min_ev, fill_model=fill_model,
                               latency_model=latency_model, formula=formula, tally=tally)
            if tally and stats is not None:
                stats["formula_below"] = stats.get("formula_below", 0) + sum(
                    1 for held in tally.get("below", []) if bettable is None or held in bettable)
            for edge in edges:
                if bettable is not None and edge.book not in bettable:
                    continue
                if formula is not None and stats is not None:
                    stats["formula_shown"] = stats.get("formula_shown", 0) + 1
                # One leg, not two: a +EV bet is a single price you believe is
                # mispriced, so there is no second stake and nothing locked. The
                # profit shown is an EXPECTATION over the stake, and the row
                # says so — quoting it beside an arb's locked figure
                # without that distinction is the most misleading thing a
                # board of mixed play types can do.
                stake = round(bankroll * 0.01, 2)
                ev_legs = [{"book": edge.book, "outcome": edge.outcome,
                            "decimal": edge.decimal,
                            "net_decimal": edge.decimal,
                            "age": round(edge.quote_age, 1),
                            "stake": stake,
                            "p_fill": round(edge.p_fill, 3),
                            "fair_prob": round(edge.fair_prob, 6), "ev_low": round(edge.ev_low, 6),
                            "american": _american(edge.decimal),
                            "if_wins": round(stake * (edge.decimal - 1.0), 2)}]
                if detail:
                    tracking.attach("ev", market, books, ev_legs, cache, names)
                rows.append(Row(
                    kind="ev",
                    event=edge.event_id, sport=edge.sport,
                    market=edge.market_type,
                    legs=ev_legs,
                    margin=edge.ev,
                    realised=edge.ev * edge.p_fill,
                    p_fill=edge.p_fill,
                    age=edge.quote_age,
                    stakes=[stake],
                    profit=round(edge.ev * stake, 2),
                    detail=detailed(market, [{"book": edge.book, "outcome": edge.outcome}], "ev"),
                    preset_misses=preset.misses(edge.market_type, [edge.decimal], None,
                                                preset.market_width(market)),
                    starts_at=getattr(market, "starts_at", None),
                ))

    if "middle" in kinds:
        for full, market in zip(markets, placeable):
            for plan in find_middles(market, books, total=bankroll, now=now):
                low_q = _quote(market, plan.low_book, ("over", "home"), plan.low_line)
                high_q = _quote(market, plan.high_book, ("under", "away"), plan.high_line)
                quotes = (low_q, high_q)
                # How old each leg's price is, floored by its feed's latency exactly as an arb's legs are, and the
                # chance it is still there. A middle used to say 0s and 100% for both, which no price is.
                ages = [0.0 if q is None else q.age(
                    now, latency_floor=0.0 if latency_model is None else latency_model.typical(q.book))
                    for q in quotes]
                fills = [None if fill_model is None or q is None else fill_model.p_fill(q.book, market.market_type, a)
                         for q, a in zip(quotes, ages)]
                place, rule = betorder.by_fill(fills, [plan.low_stake, plan.high_stake])
                legs = [
                    # Each leg is named by its own quote: a spread middle read "Over -3 / Under -2" when both were
                    # hard-coded over and under (audit B7, 2026-11-04). A total's quotes are over and under anyway.
                    {"book": plan.low_book,
                     "outcome": f"{low_q.outcome.name if low_q is not None else 'over'}@{plan.low_line}",
                     "decimal": plan.low_decimal,
                     "net_decimal": plan.low_decimal,
                     "age": round(ages[0], 1), "stake": plan.low_stake,
                     "american": _american(plan.low_decimal),
                     "order": place[0], "p_fill": None if fills[0] is None else round(fills[0], 3)},
                    {"book": plan.high_book,
                     "outcome": f"{high_q.outcome.name if high_q is not None else 'under'}@{plan.high_line}",
                     "decimal": plan.high_decimal,
                     "net_decimal": plan.high_decimal,
                     "age": round(ages[1], 1), "stake": plan.high_stake,
                     "american": _american(plan.high_decimal),
                     "order": place[1], "p_fill": None if fills[1] is None else round(fills[1], 3)},
                ]
                if detail:
                    tracking.attach("middle", full, books, legs, cache, names,
                                    keys=[q.outcome.key if q is not None else leg["outcome"]
                                          for q, leg in zip(quotes, legs)])
                both_fill = 1.0 if any(f is None for f in fills) else fills[0] * fills[1]
                # The three results, worded from the two quotes the legs are
                # (a total reads "Over 47.5"; a spread names its team). Where
                # the result must land for both to win is said only for a total,
                # where "above" and "below" need no sign convention.
                first, second = (side_label(q.outcome.key, market.market_type) if q is not None else leg["outcome"]
                                 for q, leg in zip(quotes, legs))
                window = (f"the total lands between {plan.low_line:g} and {plan.high_line:g}"
                          if market.market_type == "totals" else "")
                rows.append(Row(
                    kind="middle",
                    event=getattr(market, "event_id", ""),
                    sport=getattr(market, "sport", ""),
                    market=getattr(market, "market_type", ""),
                    legs=legs,
                    margin=plan.p_middle,
                    realised=plan.p_middle,
                    p_fill=both_fill,
                    age=max(ages),
                    stakes=[plan.low_stake, plan.high_stake],
                    profit=0.0,
                    outcomes=betorder.middle_outcomes(
                        first, second, round(plan.low_only_profit, 2), round(plan.middle_profit, 2),
                        round(plan.high_only_profit, 2), window),
                    order_rule=rule,
                    detail=(detailed(full, [{"book": q.book, "outcome": q.outcome.key} for q in quotes], "middle")
                            if all(q is not None for q in quotes) else None),
                    # Two different lines have no one width, so only the market and the prices can mark it down.
                    preset_misses=preset.misses(market.market_type, [plan.low_decimal, plan.high_decimal]),
                    starts_at=getattr(market, "starts_at", None),
                    window_points=round(plan.high_line - plan.low_line, 2),
                ))

    return _rank(rows)


def _quote(market, book: str, names: tuple, line: float):
    """The quote a middle's leg is: that book, that side, that line."""
    for q in market.quotes:
        if q.book == book and q.outcome.line == line and q.outcome.name.lower() in names:
            return q
    return None


def _rank(rows: list[Row]) -> list[Row]:
    """Best first, by what survives rather than by the headline.

    Its own function so a test can prove the ordering on a fixture where the
    two keys disagree. Ranking inside scan() meant the only available fixture
    was a single row, where every sort key looks identical and a break case
    that ranked by raw margin went undetected.
    """
    return sorted(rows, key=lambda r: r.realised, reverse=True)
