"""The Arb calculator's leg lock and target profit (the AVO bar's item 16): hold one side's stake and size the others
around it, or find the smallest total that locks at least an amount, never over the most to bet."""
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine.arb import stake_arb
from overlay_engine.odds import parse_odds

ROOT = Path(__file__).resolve().parents[1]
PRICES = ["-110", "+120"]
D = [parse_odds(p) for p in PRICES]


def run(*extra, stake="2000", ok=True):
    r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "arb", *PRICES, "--stake", stake, *extra, "--json"],
                       cwd=ROOT / "backend", capture_output=True, text=True)
    out = json.loads(r.stdout)
    if ok:
        assert r.returncode == 0 and "error" not in out, out
    return r.returncode, out


def test_a_held_side_keeps_its_stake_and_every_result_returns_the_same():
    _, d = run("--lock=1=250")
    assert d["legs"][0]["stake"] == pytest.approx(250.0)
    returns = [l["stake"] * l["decimal"] for l in d["legs"]]
    assert max(returns) - min(returns) < 0.01
    assert d["total_stake"] == pytest.approx(250 * D[0] * sum(1 / x for x in D))
    assert d["solve"]["kind"] == "lock" and "Side 1 is held at $250.00" in d["solve"]["text"]


def test_a_hold_that_needs_more_than_the_most_to_bet_is_one_sentence():
    code, d = run("--lock=2=900", stake="1000", ok=False)
    assert code == 2 and d["error"].startswith("Holding side 2 at $900.00 needs $")
    assert "more than the $1,000.00 you set" in d["error"]


@pytest.mark.parametrize("extra,words", [(["--lock=3=10"], "There is no side 3"), (["--lock=x"], "like 1=250"),
                                         (["--lock=1=0"], "more than zero"), (["--lock=1=50", "--target=5"], "not both"),
                                         (["--target=lots"], "like 25"), (["--target=-5"], "more than zero")])
def test_a_solve_that_cannot_be_read_is_refused(extra, words):
    code, d = run(*extra, ok=False)
    assert code == 2 and words in d["error"]


@pytest.mark.parametrize("rounding", ["10", "exact", "auto"])
def test_the_target_total_is_the_smallest_that_reaches_it_at_the_rounding_chosen(rounding):
    _, d = run("--target=25", "--round", rounding)
    assert d["profit"] >= 25 - 1e-9 and d["total_stake"] <= 2000
    if rounding == "10":
        smaller = stake_arb(D, total=d["total_stake"] - 10, step=10.0)
        assert smaller.profit < 25, "a total one step smaller would have reached the target too"
    assert "if every bet is accepted and stands" in d["solve"]["text"]


def test_a_target_out_of_reach_is_one_sentence():
    code, d = run("--target=25", stake="1000", ok=False)
    assert code == 2 and d["error"].startswith("Locking $25.00 at these prices needs about $")


def test_the_words_never_promise():
    for extra in (["--lock=1=250"], ["--target=25"]):
        t = run(*extra)[1]["solve"]["text"]
        assert not re.search(r"guarantee|risk.free|either way|free bet|\bwin\b|sure thing", t, re.I)


def test_the_window_sends_one_token_each_and_draws_the_engines_sentence():
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    assert '...(val("arb-lock-side") && val("arb-lock") ? [`--lock=${val("arb-lock-side")}=${val("arb-lock")}`] : [])' in js
    assert '...(val("arb-target") ? [`--target=${val("arb-target")}`] : [])' in js
    assert '${out.solve ? `<p class="ans-say">${esc(out.solve.text)}</p>` : ""}' in js


def _text(*argv):
    r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "arb", *argv], cwd=ROOT / "backend",
                       capture_output=True, text=True)
    return r.returncode, r.stdout


def test_text_mode_holds_the_lock_and_the_target_like_the_window():
    """Audit M4 (2026-11-04): text mode printed the unlocked 493.98 / 506.02 plan for --lock 1=250."""
    code, out = _text("2.10", "2.05", "--stake", "1000", "--lock=1=250")
    assert code == 0 and "Side 1 is held at $250.00" in out
    assert "250.00 at +110" in out and "256.10 at +105" in out and "493.98" not in out
    code, out = _text("2.10", "2.05", "--stake", "1000", "--target=25")
    assert code == 0 and "The smallest total that locks at least $25.00" in out
    code, out = _text("2.10", "2.05", "--stake", "300", "--lock=1=250")
    assert code == 2 and "more than the $300.00 you set" in out


@pytest.mark.parametrize("prices,stake", [(["+250", "+300", "+200"], "1000"), (["+120", "-105"], "500"),
                                          (["2.10", "2.05"], "1000")])
def test_text_mode_never_shows_exact_stakes_as_round_ones(prices, stake):
    """Audit M3 (2026-11-04): exact stakes were printed to the dollar under 'round stakes' beside the exact profit,
    $1,001 staked of $1,000 for more than those stakes lock. Every block's profit is its own stakes' worst case."""
    _, out = _text(*prices, "--stake", stake, "--round", "exact")
    assert "round stakes" not in out
    for block in out.split("\n\n")[1:]:
        stakes = [float(m) for m in re.findall(r"^\s+([\d.]+) at ", block, re.M)]
        if not stakes:
            continue
        decs = [parse_odds(p) for p in prices]
        worst = min(s * d for s, d in zip(stakes, decs)) - sum(stakes)
        profit, staked = map(float, re.search(r"profit (-?[\d.]+) on ([\d.]+)", block).groups())
        assert profit == pytest.approx(worst, abs=0.011) and staked == pytest.approx(sum(stakes), abs=0.011)
        assert staked <= float(stake) + 0.005


def test_a_rounding_that_cannot_hold_the_arb_says_so():
    """Audit B3 (2026-11-04): +110/+105 at $40 rounded to $25 came back as $19.76 / $20.24 without a word."""
    r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "arb", "+110", "+105", "--stake", "40", "--round",
                        "25", "--json"], cwd=ROOT / "backend", capture_output=True, text=True)
    d = json.loads(r.stdout)
    assert d["rounded"] is False and d["round_note"].startswith("No stakes in $25 steps keep this an arb")
    for extra in (["--stake", "1000", "--round", "25"], ["--stake", "40", "--round", "exact"]):
        r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "arb", "+110", "+105", *extra, "--json"],
                           cwd=ROOT / "backend", capture_output=True, text=True)
        assert json.loads(r.stdout)["round_note"] is None, extra
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    assert '${out.round_note ? `<p class="note warn">${esc(out.round_note)}</p>` : ""}' in js
