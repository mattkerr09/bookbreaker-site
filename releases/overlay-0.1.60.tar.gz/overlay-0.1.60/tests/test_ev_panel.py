"""One +EV calculator (the AVO bar's item 17): the Bet size panel takes the book's price and up to three sharp books'
prices for the same market, and the engine returns the fair chance, the edge, the expected profit and the stake,
sized on the worst case across the books and methods."""
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine.devig import devig_all
from overlay_engine.kelly import size_bet
from overlay_engine.odds import parse_odds

ROOT = Path(__file__).resolve().parents[1]
SHARP = ["-105/-115", "+100/-120"]


def run(*argv, ok=True):
    r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "kelly", *argv, "--json"], cwd=ROOT / "backend",
                       capture_output=True, text=True)
    if ok:
        assert r.returncode == 0, r.stdout + r.stderr
    return r.returncode, json.loads(r.stdout)


def _books():
    return [devig_all([parse_odds(p) for p in pair.split("/")]) for pair in SHARP]


def test_the_fair_chance_is_the_average_over_the_sharp_books_and_the_low_end_is_the_worst_case():
    _, d = run("--odds=+110", *[f"--sharp={s}" for s in SHARP], "--bankroll", "2000")
    spreads = _books()
    assert d["fair"]["chance"] == pytest.approx(sum(s.consensus(0) for s in spreads) / 2)
    assert d["fair"]["chance_low"] == pytest.approx(min(s.low(0) for s in spreads))
    assert d["fair"]["ev"] == pytest.approx(d["fair"]["chance"] * parse_odds("+110") - 1)
    assert [b["prices"] for b in d["fair"]["books"]] == [[-105, -115], [100, -120]]


def test_one_method_is_used_for_every_book_when_chosen():
    _, d = run("--odds=+110", *[f"--sharp={s}" for s in SHARP], "--method", "shin")
    assert d["fair"]["chance"] == pytest.approx(sum(s.by_method["shin"][0] for s in _books()) / 2)


def test_the_stake_is_sized_on_the_worst_case_not_the_average():
    _, d = run("--odds=+110", *[f"--sharp={s}" for s in SHARP], "--bankroll", "2000")
    want = size_bet(parse_odds("+110"), d["fair"]["chance"], bankroll=2000, fraction=0.25,
                    prob_low=d["fair"]["chance_low"]).stake
    assert d["stake"] == pytest.approx(want)
    assert d["prob"] == pytest.approx(d["fair"]["chance"]) and d["prob_low"] == pytest.approx(d["fair"]["chance_low"])


def test_a_price_no_better_than_fair_says_there_is_no_edge_and_bets_nothing():
    _, d = run("--odds=-130", *[f"--sharp={s}" for s in SHARP])
    assert d["fair"]["ev"] < 0 and d["stake"] == 0
    assert "no edge to bet" in d["fair"]["text"]


def test_prices_that_cannot_be_read_are_one_sentence():
    code, d = run("--odds=+110", "--sharp=-105", ok=False)
    assert code == 2 and d["error"].startswith("Sharp book 1: type its two prices as your side/other side")


def test_the_words_never_promise():
    for odds in ("+110", "-130"):
        _, d = run(f"--odds={odds}", *[f"--sharp={s}" for s in SHARP])
        t = d["fair"]["text"] + " " + d["fair"]["sized_on"]
        assert not re.search(r"guarantee|risk.free|either way|free bet|\block\b|sure thing", t, re.I)
    _, d = run("--odds=+110", *[f"--sharp={s}" for s in SHARP])
    assert "Any one bet can lose." in d["fair"]["text"]


def test_the_window_sends_the_sharp_prices_and_draws_the_engines_words():
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    html = (ROOT / "ui" / "src" / "index.html").read_text()
    for fid in ("k-s1", "k-s2", "k-s3"):
        assert f'id="{fid}"' in html
        assert f'...(val("{fid}") ? [`--sharp=${{val("{fid}")}}`] : [])' in js, "one token, so a minus price is a value"
    assert "esc(out.fair.text)" in js and "esc(out.fair.sized_on)" in js


def test_a_sharp_pair_typed_with_a_space_is_read():
    """Audit B8 (2026-11-04): `--sharp -120/+105` said "expected one argument"; argparse took the pair for an option."""
    spaced, joined = run("--odds=+110", "--sharp", "-120/+105")[1], run("--odds=+110", "--sharp=-120/+105")[1]
    assert spaced["fair"] == joined["fair"] and spaced["stake"] == joined["stake"]


def test_a_cleared_win_chance_is_no_value_not_an_error():
    """Audit B8: with sharp prices typed and the win chance box cleared, the engine said "'' is not a number"."""
    _, d = run("--odds=+110", "--sharp=-120/+105", "--prob=")
    assert d["fair"]["chance"] > 0 and "error" not in d
    code, d = run("--odds=+110", "--prob=", ok=False)
    assert code == 2 and d["error"].startswith("Fill in the win chance")
