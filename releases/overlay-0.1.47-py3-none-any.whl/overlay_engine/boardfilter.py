"""Board filters: the engine's half of sorting and narrowing the Arbitrage page's board.

OddsJam and AVO let a bettor sort the board and narrow it by price, by game state, by when the game starts, by league
and by bet type. The window here does no arithmetic, so all of it happens in the engine: the window passes flags to
`board` and draws what comes back, in the engine's words.

What each one does:

  * **Sort** (`--sort return|edge|start`). With none, the board keeps the order it always had. *Return* is the dollars
    a play pays (an arb's locked return, a +EV bet's expected profit). *Edge* is the headline percentage. A middle has
    no single dollar return and its percentage is a chance of landing, not an edge, so middles come after the plays
    that have one, in the order of their chance. *Start time* is soonest first, and a play with no start time in the
    data comes last.
  * **Price range** (`--min-price`, `--max-price`, American odds). Only a +EV bet is held to it: it is the one play
    that is a single price you chose to back. An arb's and a middle's prices are set by the pair, so they pass.
  * **Game state** (`--game-state not_started|in_play`) and **date range** (`--within hour|today|24h|7d`) are judged
    from the start time the data carries against the moment of the read. A play whose start time the data does not
    carry cannot be placed on either, so these filters leave it out and the engine says how many that was. A read of
    sportsbook odds leaves games already under way off the board, so "in play" finds plays only among Live prices
    pairs and recorded snapshots.
  * **League and bet type** (`--league-off`, `--bet-type-off`, repeatable) are toggles: a league or a bet type is on
    until it is named here. The window keeps what is off; the engine counts what is on the board.
  * **Smallest window** (`--min-window`, in points) holds a middle to a window (the gap between its two lines) of at
    least that many points. An arb and a +EV bet have no window and pass.

**Filters read nothing.** They work on the plays a read already found, so changing one costs no credit. Like Hide under
they are applied when the board is built, so the engine counts, before anything is changed, how many plays each choice
would leave, and the window says to press the button that builds the board to use it. Every count is also given with
Recommended on, because that is how the board is usually seen.

**A filter never touches alerts, warnings or the hidden list.** Those are worked out on every play the read found; the
filters only decide which of them are sent to be drawn, so a filter cannot make an old play look new on a later read.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, replace

from .hidden import starts_at as _starts_at

SORTS = ("return", "edge", "start")
STATES = ("not_started", "in_play")
WITHIN = ("hour", "today", "24h", "7d")

#: What the window offers, and the words for each. The window's controls carry the same keys (a test holds them).
SORT_LABELS = {"return": "Return", "edge": "Edge", "start": "Start time"}
STATE_LABELS = {"not_started": "Not started", "in_play": "In play"}
WITHIN_LABELS = {"hour": "Next hour", "today": "Today", "24h": "Next 24 hours", "7d": "Next 7 days"}

#: The figures offered as one press, so the count for each is there before anything is typed. American odds.
PRICE_MIN_STEPS = (-300, -200, -150, -110, 100, 150)
PRICE_MAX_STEPS = (100, 150, 200, 300, 500)
#: Points between a middle's two lines.
WINDOW_STEPS = (1.0, 2.0, 3.0, 5.0)

BET_LABELS = {"h2h": "Moneyline", "moneyline": "Moneyline", "spreads": "Spread", "totals": "Total"}

APPLY = "Press Find arbs or Read the odds to use it. Nothing is read until you do."
NOTE = ("Counts are of the plays this read found. A play you hid yourself is still counted. Changing a filter reads "
        "nothing and spends no credit.")
SORT_TEXT = {
    "return": "Return: the dollars a play pays, largest first. A middle has no single return, so middles come after "
              "the plays that have one.",
    "edge": "Edge: the headline percentage, largest first. A middle's percentage is its chance of landing, not an "
            "edge, so middles come after the plays that have an edge.",
    "start": "Start time: soonest first. A play with no start time in the data comes last.",
}
STATE_NOTE = ("Game state and the date range come from the start time the data carries. A read of sportsbook odds "
              "leaves games already under way off the board, so In play finds plays only among Live prices pairs "
              "and recorded snapshots.")
PRICE_NOTE = "Only +EV bets are held to a price range. An arb and a middle are priced as a pair, so they pass."
WINDOW_NOTE = ("Only middles are held to a window, the gap in points between the two lines. An arb and a +EV bet "
               "have none, so they pass.")


class FilterError(ValueError):
    """A filter the engine cannot use. The text is a sentence the window can print."""


def _plays(n: int) -> str:
    return f"{n} play{'s' if n != 1 else ''}"


def american_text(price: int) -> str:
    return f"+{price}" if price > 0 else f"{price}"


def parse_price(text, flag: str) -> int | None:
    """An American price as typed (+150, 150, -110), or None for nothing typed. Anything between -100 and +100 is not
    a price a book prints, so it is refused rather than read as something near."""
    if text is None or str(text).strip() == "":
        return None
    raw = str(text).strip().replace("−", "-")
    try:
        value = float(raw)
    except ValueError:
        raise FilterError(f"{flag} needs an American price like -150 or +200, not {str(text).strip()!r}.") from None
    if not math.isfinite(value) or value != int(value) or abs(value) < 100 or abs(value) > 100000:
        raise FilterError(f"{flag} needs an American price like -150 or +200. A price is -100 or lower, or +100 or "
                          f"higher.")
    return int(value)


def parse_points(text, flag: str) -> float | None:
    """A window in points as typed, or None for nothing typed."""
    if text is None or str(text).strip() == "":
        return None
    try:
        value = float(str(text).strip())
    except ValueError:
        raise FilterError(f"{flag} needs a number of points like 2, not {str(text).strip()!r}.") from None
    if not math.isfinite(value) or value <= 0 or value > 100:
        raise FilterError(f"{flag} needs a number of points above 0, like 2.")
    return round(value, 2)


@dataclass(frozen=True)
class Spec:
    """Every filter the person set. Nothing set is no filter."""

    sort: str | None = None
    min_price: int | None = None
    max_price: int | None = None
    state: str | None = None
    within: str | None = None
    leagues_off: frozenset = frozenset()
    bet_types_off: frozenset = frozenset()
    min_window: float | None = None

    @property
    def active(self) -> bool:
        return bool(self.min_price is not None or self.max_price is not None or self.state or self.within
                    or self.leagues_off or self.bet_types_off or self.min_window is not None)


def _fold(items) -> frozenset:
    return frozenset(str(i).strip().casefold() for i in (items or ()) if str(i).strip())


def parse(sort=None, min_price=None, max_price=None, state=None, within=None, leagues_off=(), bet_types_off=(),
          min_window=None) -> Spec:
    """The flags as a `Spec`, or a `FilterError` saying which one is wrong."""
    if sort not in (None, *SORTS):
        raise FilterError(f"--sort is one of {', '.join(SORTS)}.")
    if state not in (None, *STATES):
        raise FilterError(f"--game-state is one of {', '.join(STATES)}.")
    if within not in (None, *WITHIN):
        raise FilterError(f"--within is one of {', '.join(WITHIN)}.")
    low, high = parse_price(min_price, "--min-price"), parse_price(max_price, "--max-price")
    if low is not None and high is not None and low > high:
        raise FilterError(f"--min-price {american_text(low)} is above --max-price {american_text(high)}, so no price "
                          "is left.")
    return Spec(sort, low, high, state, within, _fold(leagues_off), _fold(bet_types_off),
                parse_points(min_window, "--min-window"))


FLAGS = ("sort", "min_price", "max_price", "game_state", "within", "league_off", "bet_type_off", "min_window")


def flags_given(args) -> bool:
    """True when the person asked for any board filter on the command line."""
    return any(getattr(args, name, None) not in (None, [], "") for name in FLAGS)


def from_args(args) -> tuple:
    """`(spec, problem)` for a `board` command. A filter the engine cannot use gives no filter and the sentence that
    says why, so a typo in a price box never takes the board away."""
    try:
        return parse(getattr(args, "sort", None), getattr(args, "min_price", None), getattr(args, "max_price", None),
                     getattr(args, "game_state", None), getattr(args, "within", None),
                     getattr(args, "league_off", None) or (), getattr(args, "bet_type_off", None) or (),
                     getattr(args, "min_window", None)), ""
    except FilterError as exc:
        return Spec(), str(exc)


# ------------------------------------------------------------------------------------------------ one play's facts

#: League names by the Odds API sport key, so the demonstration board names its league the way a read of live
#: sportsbook odds does.
def _league_labels() -> dict:
    from .oddsapi import LEAGUES
    return {lg.key: lg.label for lg in LEAGUES}


@dataclass
class _Facts:
    kind: str
    league: str
    market: str
    market_label: str
    start: float | None
    price: int | None
    window: float | None
    margin: float
    profit: float
    recommended: bool


def _league(d: dict, labels: dict) -> str:
    named = str(d.get("league") or "").strip()
    if named:
        return named.upper() if named.islower() else named
    sport = str(d.get("sport") or "")
    if sport in labels:
        return labels[sport]
    parts = str(d.get("event") or d.get("game") or "").split("_")
    if len(parts) >= 4:                                   # the demonstration board's id: nba_2026_bos_lal
        return parts[0].upper()
    return sport.upper()


def _market_label(d: dict, market: str) -> str:
    return str(d.get("market_label") or "") or BET_LABELS.get(market) or market.replace("_", " ").capitalize()


def _facts(d: dict, labels: dict) -> _Facts:
    kind = str(d.get("kind") or "arb")
    market = str(d.get("market") or "moneyline")
    legs = d.get("legs") or []
    price = None
    if kind == "ev" and legs and isinstance(legs[0].get("american"), (int, float)):
        price = int(legs[0]["american"])
    window = d.get("window_points")
    epoch = d.get("start_epoch")
    start = float(epoch) if isinstance(epoch, (int, float)) and not isinstance(epoch, bool) else _starts_at(d)
    return _Facts(kind, _league(d, labels), market, _market_label(d, market), start, price,
                  float(window) if isinstance(window, (int, float)) else None,
                  float(d.get("margin") or 0.0), float(d.get("profit") or 0.0), d.get("recommended") is not False)


def _bounds(now: float, key: str):
    if key == "today":
        lt = time.localtime(now)
        return (time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1)),
                time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday + 1, 0, 0, 0, 0, 0, -1)))
    return now, now + {"hour": 3600.0, "24h": 86400.0, "7d": 7 * 86400.0}[key]


# --------------------------------------------------------------------------------------------- what each filter passes

def _passes(f: _Facts, spec: Spec, now: float, skip: str = "") -> bool:
    if skip != "price" and f.price is not None:
        if spec.min_price is not None and f.price < spec.min_price:
            return False
        if spec.max_price is not None and f.price > spec.max_price:
            return False
    if skip != "state" and spec.state:
        if f.start is None or (f.start <= now) != (spec.state == "in_play"):
            return False
    if skip != "within" and spec.within:
        if f.start is None:
            return False
        low, high = _bounds(now, spec.within)
        if not (low <= f.start < high if spec.within == "today" else low <= f.start <= high):
            return False
    if skip != "league" and f.league.casefold() in spec.leagues_off:
        return False
    if skip != "bet_type" and (f.market.casefold() in spec.bet_types_off or f.market_label.casefold() in spec.bet_types_off):
        return False
    if skip != "window" and f.kind == "middle" and spec.min_window is not None:
        if f.window is None or f.window < spec.min_window:
            return False
    return True


def _sort_key(sort: str, f: _Facts, i: int):
    has = f.kind != "middle"
    if sort == "return":
        return (0, -f.profit, -f.margin, i) if has else (1, 0.0, -f.margin, i)
    if sort == "edge":
        return (0, -f.margin, -f.profit, i) if has else (1, 0.0, -f.margin, i)
    return (f.start is None, f.start or 0.0, i)


# ------------------------------------------------------------------------------------------------------- the answer

def _count(facts: list, spec: Spec, now: float, **only) -> tuple:
    """`(plays left, plays left with Recommended on)` under `spec`."""
    left = [f for f in facts if _passes(f, spec, now, **only)]
    return len(left), sum(1 for f in left if f.recommended)


def _chip(key: str, label: str, what: str, counts: tuple, **extra) -> dict:
    every, rec = counts
    return {"key": key, "label": label, "all": every, "rec": rec,
            "left_text": f"{every} left", "left_text_rec": f"{rec} left",
            "text_rec": f"{what}: {rec} left with Recommended on",
            "text_all": f"{what}: {every} left with Recommended off", **extra}


def _toggle(label: str, on: bool, plays: tuple, what: str) -> dict:
    every, rec = plays
    return {"key": label, "label": label, "on": on, "count": every, "count_rec": rec,
            "left_text": _plays(every), "left_text_rec": _plays(rec),
            "text_rec": f"{what} {label} has {_plays(rec)} on this board, with your other filters and Recommended on",
            "text_all": f"{what} {label} has {_plays(every)} on this board, with your other filters and Recommended off"}


def apply(views: list, spec: Spec, now: float | None, problem: str = "") -> tuple:
    """`(order, block)`: the indexes of `views` to draw, in the order to draw them, and the engine's words.

    `views` is each play as the board sends it (a dict). `now` is the moment of the read (None for a board with no
    clock, which has no way to place a start time). Nothing is removed from `views`; the caller keeps the ones named.
    """
    now = time.time() if now is None else float(now)
    labels = _league_labels()
    facts = [_facts(v, labels) for v in views]
    total = len(facts)
    kept = [i for i, f in enumerate(facts) if _passes(f, spec, now)]
    if spec.sort:
        kept.sort(key=lambda i: _sort_key(spec.sort, facts[i], i))
    left, left_rec = _count(facts, spec, now)

    unknown = sum(1 for f in facts if f.start is None)
    evs = sum(1 for f in facts if f.kind == "ev")
    middles = sum(1 for f in facts if f.kind == "middle")

    def chips(none_label, current, steps, make, what_of, label_of):
        out = [_chip("", none_label, f"{what_of(None)}", _count(facts, make(None), now), on=current is None)]
        out += [_chip(f"{s:g}", label_of(s), what_of(s), _count(facts, make(s), now), on=current == s) for s in steps]
        return out

    price = {
        "min": spec.min_price, "max": spec.max_price, "applies_to": evs,
        "min_chips": chips("No lowest", spec.min_price, PRICE_MIN_STEPS,
                           lambda s: replace(spec, min_price=s),
                           lambda s: "No lowest price" if s is None else f"Lowest price {american_text(s)}",
                           american_text),
        "max_chips": chips("No highest", spec.max_price, PRICE_MAX_STEPS,
                           lambda s: replace(spec, max_price=s),
                           lambda s: "No highest price" if s is None else f"Highest price {american_text(s)}",
                           american_text),
        "note": PRICE_NOTE,
        "sentence": (f"{_plays(evs)} on this board {'is a +EV bet' if evs == 1 else 'are +EV bets'}, "
                     "the only plays a price range holds back."),
    }
    state = {
        "chosen": spec.state, "unknown": unknown, "note": STATE_NOTE,
        "options": [_chip("", "Any", "Any game state", _count(facts, replace(spec, state=None), now),
                          on=spec.state is None)]
                   + [_chip(k, STATE_LABELS[k], STATE_LABELS[k], _count(facts, replace(spec, state=k), now),
                            on=spec.state == k) for k in STATES],
        "sentence": (f"{_plays(unknown)} on this board {'has' if unknown == 1 else 'have'} no start time in the data, so "
                     "a game-state or date filter leaves "
                     f"{'it' if unknown == 1 else 'them'} out.") if unknown else "",
    }
    within = {
        "chosen": spec.within, "unknown": unknown,
        "options": [_chip("", "Any time", "Any start time", _count(facts, replace(spec, within=None), now),
                          on=spec.within is None)]
                   + [_chip(k, WITHIN_LABELS[k], WITHIN_LABELS[k], _count(facts, replace(spec, within=k), now),
                            on=spec.within == k) for k in WITHIN],
        "sentence": "Today is the day on this Mac's clock, from midnight to midnight; the other ranges count forward "
                    "from the moment of the read.",
    }
    window = {
        "min": spec.min_window, "applies_to": middles,
        "chips": chips("No smallest", spec.min_window, WINDOW_STEPS,
                       lambda s: replace(spec, min_window=s),
                       lambda s: "No smallest window" if s is None else f"Smallest window {s:g} {'point' if s == 1 else 'points'}",
                       lambda s: f"{s:g} pts"),
        "note": WINDOW_NOTE,
        "sentence": (f"{_plays(middles)} on this board {'is a middle' if middles == 1 else 'are middles'}, "
                     "the only plays a window holds back."),
    }
    seen_leagues, seen_types = {}, {}
    for f in facts:
        seen_leagues.setdefault(f.league.casefold(), f.league)
        seen_types.setdefault(f.market.casefold(), (f.market, f.market_label))
    leagues = [_toggle(name, key not in spec.leagues_off,
                       _count([f for f in facts if f.league.casefold() == key], spec, now, skip="league"),
                       "League")
               for key, name in sorted(seen_leagues.items(), key=lambda kv: kv[1].casefold())]
    types = []
    for key, (market, label) in sorted(seen_types.items(), key=lambda kv: kv[1][1].casefold()):
        item = _toggle(label, key not in spec.bet_types_off and label.casefold() not in spec.bet_types_off,
                       _count([f for f in facts if f.market.casefold() == key], spec, now, skip="bet_type"),
                       "Bet type")
        item["key"] = market
        types.append(item)

    emptied = bool(total and not left and spec.active)
    if problem:
        sentence = problem + " The board is shown without board filters."
    elif spec.active or spec.sort:
        parts = []
        if spec.active:
            parts.append(f"Board filters leave {left} of {_plays(total)}.")
        if spec.sort:
            parts.append(f"Sorted by {SORT_LABELS[spec.sort].lower()}.")
        sentence = " ".join(parts)
    else:
        sentence = ""
    block = {
        "enabled": not problem, "error": problem, "active": spec.active, "sorted_by": spec.sort,
        "total": total, "left": left, "left_rec": left_rec,
        "empty_by_filters": emptied,
        "empty_text": (f"Board filters leave nothing: all {_plays(total)} this read found are filtered out."
                       if emptied else ""),
        "sentence": sentence,
        "sort": {"chosen": spec.sort,
                 "options": [{"key": "", "label": "Best first", "text": "Best first: the board's own order, by what "
                              "survives (return times the chance both bets are still there)."}]
                            + [{"key": k, "label": SORT_LABELS[k], "text": SORT_TEXT[k]} for k in SORTS]},
        "price": price, "state": state, "within": within, "window": window,
        "leagues": leagues, "bet_types": types,
        "apply": APPLY, "note": NOTE,
        "undo": {"label": "Clear filters"},
    }
    return kept, block
