"""Track this bet: a bet the person placed from the board, saved to this Mac with the fair price it was
found against, and settled by them when the game is over.

Why it exists. The My bets page sets what you made against what the fair prices expected
(`tracker.actual_vs_expected`), and that is only possible for a bet that has a fair price saved with it.
A bet read in from a book's export or a pasted slip has none: its row holds the break-even price as a
stand-in. The board is the one place the engine has priced a bet, so the board is where a bet gets
saved with that price.

**The window sends back what the engine sent.** Each leg of a board row carries a `track` block made
here (`leg_pick`): the book, the market, the side, the price, the stake the engine suggested, the fair
price and how it was made, and the numbers the ledger needs to learn from the bet later (the probability
each devig method gave and each book's own). The window shows it on a form, lets the person change the
stake and the price they actually got, and hands the block back. It computes none of it.

**The fair price does not move when the price you got does.** A different price at the book changes
what the bet is worth (the engine says how much, at the price saved) and leaves the chance of winning
alone.

**No fair price is a saved bet with no fair price.** A market no sharp book priced, or a middle whose
legs sit on lines nothing compares them to, has none. The bet is still saved, marked as tracked, with the
break-even price as a stand-in and an empty spread, exactly as an imported bet is, so it counts in the
record and never in actual against expected profit (`tracker._priced`).

**It never places a bet.** Nothing here reaches a book; it writes one row to the ledger on this Mac.
Saving the same form twice saves once: the form's token is the bet's `external_ref`.

**The person says how it ended.** Settling a tracked bet writes its result and its profit
(`Ledger.settle_result`), worked out here from the stake and the price saved, and leaves the closing
price alone. A settled bet is never rewritten.
"""

from __future__ import annotations

import json
import time

from . import wallet
from .detail import FairCache, _name
from .ev import ev_per_unit
from .ledger import AtBet, Ledger, LedgerError
from .odds import OddsError, decimal_to_american, parse_odds, prob_to_american
from .screen import side_label

#: The source the ledger keeps on a bet saved from the board.
SOURCE = "tracked"

#: Said on the form, in these words.
NEVER_PLACES = ("Bookbreaker never places a bet. Place this one yourself at the book; this only records it here, "
                "on this Mac. Nothing is sent anywhere.")

NO_FAIR_SAVED = ("This bet has no fair price, so it will be saved without one. It counts in your record, and not in "
                 "actual against expected profit.")

RESULT_WORDS = {"won": "won", "lost": "lost", "push": "a push", "void": "void"}


# ------------------------------------------------------------ the block each leg carries

def _how_made(fv, books, names) -> str:
    total = sum(fv.contributors.values()) or 1.0
    used = sorted(fv.contributors.items(), key=lambda kv: -kv[1])
    methods = sorted({m for spread in fv.spreads.values() for m in spread.by_method})
    lead_book, lead_weight = used[0]
    text = (f"Each book's own prices for both sides have its margin taken out {len(methods)} ways "
            f"({', '.join(methods)}) and averaged. The books are then blended, weighted by how sharp each is: "
            f"{_name(books, names, lead_book)} counts for {lead_weight / total:.0%}. The book you bet at is left "
            "out of it, so it never helps set the price it is judged by.")
    if not fv.anchored:
        text += (" No sharp book or exchange priced this market, so this is only the retail books' own view and "
                 "is not anchored.")
    return text


def fair_record(market, books, outcome: str, book_key: str, cache: FairCache | None = None,
                names: dict | None = None) -> dict | None:
    """The fair price of one side of a market, as the ledger will keep it, or None when there is none.

    It is the fair value the row itself is judged by: `ev.fair_without`, the call `find_edges` makes
    and the detail's EV by book makes, with the book you bet at left out."""
    cache = cache or FairCache()
    fv = cache.without(market, books, book_key).get(outcome)
    if fv is None:
        return None
    index = market.outcomes().index(outcome)
    devig: dict = {}
    for method in sorted({m for spread in fv.spreads.values() for m in spread.by_method}):
        num = den = 0.0
        for book, spread in fv.spreads.items():
            if method in spread.by_method:
                w = fv.contributors.get(book, 0.0)
                num += w * spread.by_method[method][index]
                den += w
        if den > 0.0:
            devig[method] = num / den
    book_probs = {book: spread.consensus(index) for book, spread in fv.spreads.items()}
    if not devig:
        return None
    return {
        "prob": fv.prob, "low": min(fv.low, fv.prob), "high": max(fv.high, fv.prob),
        "american": round(prob_to_american(fv.prob)),
        "devig": devig, "book_probs": book_probs, "anchored": fv.anchored,
        "text": _how_made(fv, books, names),
    }


def _line_market(market, outcome: str, cache: FairCache):
    """The two-sided market on this side's own line, cut out of a market holding several lines.

    A middle's legs sit on two different lines of one market. Each leg has a fair price on its own
    line, the one `find_edges` would use for it; the middle as a whole has none."""
    for part in cache.lines(market):
        if outcome in part.outcomes():
            return part
    return None


def leg_pick(row_kind: str, market, books, leg: dict, cache: FairCache, names: dict | None = None,
             p_fill=None, key: str | None = None) -> dict:
    """The `track` block for one leg of a board row.

    `key` is the side's `Outcome.key` where the leg's own text differs from it (a middle writes
    `over@220.0` where the market says `over@220`): the ledger keeps the market's, since that is what
    the grader looks a close up by."""
    key = key or leg["outcome"]
    book = books.get(leg["book"])
    own = _line_market(market, key, cache) if row_kind == "middle" else market
    fair = fair_record(own, books, key, leg["book"], cache, names) if own is not None else None
    pick = {
        "event_id": market.event_id, "sport": market.sport, "market_type": market.market_type,
        "outcome": key, "book": leg["book"],
        "book_name": _name(books, names, leg["book"]),
        "selection": side_label(key, market.market_type),
        "decimal": leg["decimal"], "american": leg["american"],
        "commission": book.commission if book is not None else 0.0,
        "stake": leg["stake"], "kind": row_kind,
        "p_fill": p_fill, "starts_at": getattr(market, "starts_at", None),
        "fair": fair, "no_fair": None,
    }
    if fair is None:
        pick["no_fair"] = ("No book in this market quotes both sides with a known tier, so there is no price to "
                           "take the margin out of. " + NO_FAIR_SAVED)
    return pick


def attach(row_kind: str, market, books, legs: list, cache: FairCache, names: dict | None = None,
           keys: list | None = None) -> None:
    """Put a `track` block on every leg of a row, in place."""
    for i, leg in enumerate(legs):
        leg["track"] = leg_pick(row_kind, market, books, leg, cache, names, p_fill=leg.get("p_fill"),
                                key=None if keys is None else keys[i])


# ------------------------------------------------------------ saving

def _money(x: float) -> str:
    return f"${abs(x):,.2f}"


def _signed_pct(x: float) -> str:
    return f"{'-' if x < 0 else '+'}{abs(x) * 100:.1f}%"


def _signed_money(x: float) -> str:
    return ("-" if x < 0 else "+") + _money(x)


def read_pick(text: str) -> dict:
    """The block the window handed back, checked."""
    try:
        pick = json.loads(text)
    except (TypeError, ValueError):
        raise LedgerError("That bet could not be read back from the board. Press Find arbs again and track it "
                          "from the new board.") from None
    if not isinstance(pick, dict):
        raise LedgerError("That bet could not be read back from the board.")
    for key in ("event_id", "sport", "market_type", "outcome", "book"):
        if not isinstance(pick.get(key), str) or not pick[key].strip():
            raise LedgerError(f"That bet has no {key.replace('_', ' ')}, so it cannot be saved.")
    return pick


def _at_bet(pick: dict, p_fill) -> AtBet | None:
    fair = pick.get("fair")
    if not fair:
        return None
    try:
        return AtBet(fair_prob=float(fair["prob"]), fair_low=float(fair["low"]), fair_high=float(fair["high"]),
                     devig={str(k): float(v) for k, v in (fair.get("devig") or {}).items()},
                     book_probs={str(k): float(v) for k, v in (fair.get("book_probs") or {}).items()},
                     p_fill=1.0 if p_fill is None else float(p_fill))
    except (KeyError, TypeError, ValueError):
        raise LedgerError("The fair price on that bet could not be read, so it was not saved.") from None


def _wallet_line(moved: dict | None) -> str:
    """One short line on the book's balance, only when that book has one."""
    return "" if moved is None else f" {moved['name']} balance: {moved['balance_text']}."


def save(db: Ledger, pick: dict, *, price: str, stake: str, game: str = "", league: str = "",
         ref: str | None = None, now: float | None = None) -> dict:
    """Write the bet and say what was saved. `price` and `stake` are what the person typed."""
    now = time.time() if now is None else now
    if ref:
        old = db.bet_by_ref(ref)
        if old is not None:
            return {"saved": True, "duplicate": True, "bet_id": old,
                    "text": f"Already saved as bet {old}. Pressing Save twice saves it once."}
    try:
        decimal = parse_odds(price)
    except OddsError as exc:
        raise LedgerError(str(exc)) from None
    try:
        amount = float(str(stake).replace(",", "").replace("$", "").strip())
    except ValueError:
        raise LedgerError(f"{stake!r} is not an amount. Type what you bet, like 25 or 25.50.") from None
    if not amount > 0 or amount != amount or amount > 10_000_000:
        raise LedgerError("The amount you bet must be more than zero.")
    amount = round(amount, 2)

    commission = float(pick.get("commission") or 0.0)
    net = 1.0 + (decimal - 1.0) * (1.0 - commission) if commission > 0.0 else decimal
    at_bet = _at_bet(pick, pick.get("p_fill"))
    common = dict(event_id=pick["event_id"], sport=pick["sport"], market_type=pick["market_type"],
                  outcome=pick["outcome"], book=pick["book"], decimal_odds=net, stake=amount)
    if at_bet is not None:
        bet_id = db.record_bet(**common, at_bet=at_bet, placed_at=now, source=SOURCE, external_ref=ref)
    else:
        bet_id = db.import_bet(**common, placed_at=now, external_ref=ref, source=SOURCE)
    selection = pick.get("selection") or side_label(pick["outcome"], pick["market_type"])
    starts = pick.get("starts_at")
    db.label_bet(bet_id, game=(game or "").strip() or None, league=(league or "").strip() or None,
                 selection=selection, starts_at=float(starts) if isinstance(starts, (int, float)) else None)

    american = round(decimal_to_american(decimal))
    price_words = f"{'+' if american > 0 else '-'}{abs(american)}"
    what = f"{selection} at {pick.get('book_name') or pick['book']}, {price_words}, {_money(amount)}"
    moved = wallet.on_bet(db, pick["book"], amount)
    out = {"saved": True, "duplicate": False, "bet_id": bet_id, "priced": at_bet is not None,
           "expected": None, "ledger": str(db.path), "wallet": moved}
    if at_bet is None:
        out["text"] = (f"Saved as bet {bet_id}: {what}. It has no fair price, so it counts in your record and not in "
                       "actual against expected profit." + _wallet_line(moved))
        return out
    ev = ev_per_unit(net, at_bet.fair_prob)
    low = ev_per_unit(net, at_bet.fair_low)
    high = ev_per_unit(net, at_bet.fair_high)
    out["expected"] = {"ev": ev, "ev_low": low, "ev_high": high, "money": round(ev * amount, 2)}
    out["text"] = (f"Saved as bet {bet_id}: {what}. At the price you got, its fair price expects "
                   f"{_signed_pct(ev)} (between {_signed_pct(low)} and {_signed_pct(high)}), about "
                   f"{_signed_money(ev * amount)}. That is an average over many bets like it; this one can lose. "
                   "Once you settle it, it counts in actual against expected profit." + _wallet_line(moved))
    return out


# ------------------------------------------------------------ settling

def profit_for(bet: dict, result: str) -> float:
    """What the bet made or lost, from its stake and the price saved."""
    if result == "won":
        return round(bet["stake"] * (bet["decimal_odds"] - 1.0), 2)
    if result == "lost":
        return round(-bet["stake"], 2)
    return 0.0


def settle(db: Ledger, bet_id: int, result: str, now: float | None = None) -> dict:
    bet = db.get_bet(bet_id)
    if bet is None:
        raise LedgerError(f"There is no bet {bet_id}.")
    if result not in RESULT_WORDS:
        raise LedgerError(f"{result!r} is not a result. Use won, lost, push or void.")
    profit = profit_for(bet, result)
    db.settle_result(bet_id, result=result, profit=profit, settled_at=now)
    moved = wallet.on_settle(db, bet["book"], bet["stake"], result, profit)
    if result in ("won", "lost"):
        words = f"{_signed_money(profit)}"
    else:
        words = "no profit or loss; the stake comes back"
    return {"settled": True, "bet_id": bet_id, "result": result, "profit": profit, "wallet": moved,
            "text": f"Bet {bet_id} settled as {RESULT_WORDS[result]}: {words}. Your record is updated."
                    + _wallet_line(moved)}


__all__ = ["attach", "fair_record", "leg_pick", "read_pick", "save", "settle", "profit_for", "SOURCE",
           "NEVER_PLACES", "NO_FAIR_SAVED"]
