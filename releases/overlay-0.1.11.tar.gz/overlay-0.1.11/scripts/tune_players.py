#!/usr/bin/env python3
"""Tune the NFL player projections and write backend/overlay_engine/data/nfl_tuned.json.

This is how the shipped settings were made, kept so they can be made again. It is
not part of the gates (it needs 2012 on, about 120 MB) and it never runs on a
person's Mac.

    python3 scripts/tune_players.py --folder /path/to/nfl2012   # downloads 2012 on if empty
    python3 scripts/tune_players.py --folder ... --only "passing yards"

What it does, per stat, and nothing else:

  1. tune the settings on 2012-2017 (the found seasons) for the smallest average miss;
  2. keep the variant (own level / + team / + opponent / + script) with the smallest
     miss on 2018-2021 (the validated seasons);
  3. read the miss distribution (what happened over what was projected, in four
     bands by the size of the projection) off the found and validated seasons;
  4. only then look at 2022 on (the final seasons): the average miss, and the
     calibration table, recorded as the reference the person's own copy is compared with.

Nothing from 2022 on is used in 1 to 3.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from overlay_engine import nflverse, playerproj  # noqa: E402


def one(args):
    folder, name = args
    folder = Path(folder)
    stat = playerproj.STATS[name]
    rows = [r for r in nflverse.read_weekly(folder) if playerproj.relevant(stat, r)]
    ctx = playerproj.context(nflverse.read_games(folder))
    t0 = time.time()
    tuned = playerproj.tune(rows, ctx, stat, log=lambda m: print(m, flush=True))
    chosen = tuned["chosen"]
    params = tuned["variants"][chosen]["params"]
    pairs, _ = playerproj.project(rows, ctx, stat, params)
    spread = playerproj.build_spread(pairs, stat)
    cal = playerproj.calibration(pairs, stat, spread)
    return name, {
        "variant": chosen, "params": params,
        "found_miss": tuned["variants"][chosen]["found_miss"],
        "validated_miss": tuned["variants"][chosen]["validated_miss"],
        "final_miss": round(playerproj.miss(pairs, stat, "final") or 0.0, 3),
        "variants": {k: {"found_miss": v["found_miss"], "validated_miss": v["validated_miss"]}
                     for k, v in tuned["variants"].items()},
        "spread": spread, "reference_calibration": cal,
        "seconds": round(time.time() - t0),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--folder", required=True)
    ap.add_argument("--only", action="append")
    ap.add_argument("--out", default=str(playerproj.DATA))
    ap.add_argument("--workers", type=int, default=4)
    args = ap.parse_args()
    folder = Path(args.folder)
    if not nflverse.have_data(folder):
        print("downloading nflverse 2012 on (public files from GitHub)...", flush=True)
        rep = nflverse.update(folder=folder, first_season=2012)
        print(f"  {len(rep.fetched)} files, {rep.bytes / 1e6:.0f} MB", flush=True)
    man = nflverse.read_manifest(folder)["files"]
    names = args.only or list(playerproj.STATS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        results = dict(pool.map(one, [(str(folder), n) for n in names]))
    out = {
        "version": playerproj.MODEL_VERSION,
        "tuned_on": time.strftime("%Y-%m-%d"),
        "blocks": {k: list(v) for k, v in playerproj.BLOCKS.items()},
        "how": playerproj.__doc__.split("\n\n")[1] if playerproj.__doc__ else "",
        "source": {"player_stats": nflverse.PLAYER_URL, "games": nflverse.GAMES_URL,
                   "files": {n: {"file_date": f.get("file_date"), "bytes": f.get("bytes")}
                             for n, f in sorted(man.items())}},
        "stats": {n: results[n] for n in names},
    }
    path = Path(args.out)
    path.write_text(json.dumps(out, indent=1, sort_keys=True))
    print(f"wrote {path} ({path.stat().st_size // 1024} KB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
