#!/usr/bin/env bash
# Build Bookbreaker.app.
#   ./scripts/build_app.sh           ad-hoc signed, runs locally
#   ./scripts/build_app.sh --ship    Developer-ID sign + notarize + staple + DMG,
#                                    then the signed updater download (step 7)
#
# The sidecar is INJECTED after `tauri build` rather than declared in
# bundle.resources: Tauri's resource copier cannot follow the Python.framework
# symlinks inside a PyInstaller onedir ("Not a directory"), and `cp -R` can.
# That is Docket's flow, and it is here because it is proven rather than because
# it is elegant.
#
# Never `codesign --deep` for a notarized build — sign nested Mach-O inside-out.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

MODE="adhoc"; PROFILE="debug"
for a in "$@"; do
  case "$a" in
    --ship) MODE="ship"; PROFILE="release" ;;
    --release) PROFILE="release" ;;
    *) echo "unknown flag: $a" >&2; exit 2 ;;
  esac
done

APP="ui/src-tauri/target/$PROFILE/bundle/macos/Bookbreaker.app"
SIDECAR="build/sidecar/dist/overlay-engine"

# The key that signs what the in-app updater downloads. Checked before
# anything is built, so a ship build cannot spend ten minutes of Apple's time
# and then stop for want of it. An update is remote code execution by design:
# every installed copy refuses a download this key did not sign, so a ship
# without it would be a release no installed copy could take. A missing key
# is a refusal, never a warning. It lives outside every repository; only the
# public half is in tauri.conf.json.
UPD_KEY="${BOOKBREAKER_UPDATER_KEY:-$HOME/.bookbreaker-updater/bookbreaker_updater.key}"
if [ "$MODE" = "ship" ] && [ ! -f "$UPD_KEY" ]; then
  echo "the updater signing key is missing at $UPD_KEY; refusing to ship an update installed copies cannot verify" >&2
  exit 1
fi

# 1) The engine, ALWAYS rebuilt ----------------------------------------------
#
# Never reuse a sidecar lying on disk. The first bundle of this app shipped an
# engine built before `--json` existed, so the window asked a question its own
# engine could not answer — and nothing about the .app looked wrong.
echo "==> building the engine sidecar"
rm -rf build/sidecar
mkdir -p build
# Ask answers through Claude with the person's own key, and that needs the
# `anthropic` package inside the frozen engine. The wheel does not require it (it
# is the optional `ask` extra), so the BUILD must: a sidecar frozen without it
# would run every other verb and tell the person Ask cannot use their key.
# PyInstaller follows `import anthropic` on its own, but the package loads parts
# of itself by name, so it is collected whole with the packages it stands on.
python3 -c "import anthropic" 2>/dev/null \
  || { echo "the anthropic package is not installed here, so Ask would be missing from the app: pip install 'anthropic>=0.98'" >&2; exit 1; }
python3 -m PyInstaller --noconfirm --clean \
  --distpath build/sidecar/dist --workpath build/sidecar/build \
  --specpath build/sidecar --name overlay-engine --console \
  --paths backend --hidden-import overlay_engine.cli --hidden-import overlay_engine.cmds_ask \
  --collect-all anthropic --collect-all pydantic --collect-all pydantic_core --collect-all httpx \
  --collect-all httpcore --collect-all anyio --collect-all certifi --collect-all jiter \
  --add-data "$PWD/backend/overlay_engine/data:overlay_engine/data" \
  backend/overlay_engine/__main__.py >build/pyinstaller.log 2>&1 \
  || { echo "PyInstaller failed:" >&2; grep -E "ERROR|Error" build/pyinstaller.log | tail -5 >&2; exit 1; }
# Absolute, because PyInstaller resolves --add-data against --specpath rather
# than the working directory. And logged rather than sent to /dev/null: the
# first attempt at bundling this directory failed with the script printing
# nothing at all after "building the engine sidecar".

# It must answer EVERY verb the window is allowed to send, read from the
# shell's own allow-list so the two cannot drift. This used to probe devig,
# arb and kelly by hand while the window sent ten verbs: `welcome` shipped
# into a build that crashed on it, because its data file was never bundled
# and nothing here ever asked the built engine about offers. A verb with no
# probe below fails the build rather than being skipped.
TMPH="$(mktemp -d)"
ALLOWED=$(grep -o 'const ALLOWED: \[&str; [0-9]*\] = \[[^]]*\]' ui/src-tauri/src/*.rs \
  | grep -o '"[a-z-]*"' | tr -d '"')
for verb in $ALLOWED; do
  case "$verb" in
    devig)       probe=(devig -110 -110) ;;
    arb)         probe=(arb 2.10 2.05 --stake 1000) ;;
    kelly)       probe=(kelly --odds 2.5 --prob 0.45 --bankroll 1000) ;;
    parlay)      probe=(parlay -110 -110) ;;
    fill)        probe=(fill --age 10 --book dk --market h2h) ;;
    board)       probe=(board) ;;
    welcome)     probe=(welcome) ;;
    performance) probe=(performance --db "$TMPH/probe.db") ;;
    paste)       probe=(paste "--text=DraftKings Celtics -150 Wager \$30.00" --db "$TMPH/probe.db") ;;
    import)      probe=(import "--text=date,sportsbook,odds,stake,result,profit
2026-09-01,FanDuel,-120,60,won,50" --db "$TMPH/probe.db") ;;
    key)         probe=(key status) ;;
    players)     probe=(players --status) ;;
    goal)        probe=(goal --bankroll 10 --target 200 --tickets 10) ;;
    ask)         probe=(ask --engine builtin "fair odds on -150 / +130") ;;
    *) echo "the window can send '$verb' and build_app.sh has no probe for it" >&2; exit 1 ;;
  esac
  OVERLAY_HOME="$TMPH" "$SIDECAR/overlay-engine" "${probe[@]}" --json >/dev/null \
    || { echo "the sidecar cannot answer '$verb --json'" >&2; exit 1; }
done
# `key status` above proves the verb is wired; this proves the live-odds path is
# too. It prices a refresh and fetches nothing: no key, no network, no credits.
OVERLAY_HOME="$TMPH" "$SIDECAR/overlay-engine" board --feed oddsapi --estimate --json >/dev/null \
  || { echo "the sidecar cannot price a live-odds refresh" >&2; exit 1; }
# ...and that the Anthropic package really is inside the frozen engine. `ask --status`
# imports it and says so; a sidecar that cannot import it would let Ask tell every
# person with a key that it cannot use it.
OVERLAY_HOME="$TMPH" "$SIDECAR/overlay-engine" ask --status --json | grep -q '"sdk": true' \
  || { echo "the sidecar was built without the anthropic package, so Ask could not use a person's key" >&2; exit 1; }
rm -rf "$TMPH"
echo "    sidecar answers devig, arb and kelly ($(du -sh "$SIDECAR" | cut -f1))"

# 2) The shell ---------------------------------------------------------------
echo "==> building the window"
cd ui
[ -d node_modules ] || npm install --silent
if [ "$PROFILE" = "release" ]; then npx tauri build --bundles app >/dev/null
else npx tauri build --debug --bundles app >/dev/null; fi
cd "$ROOT"
[ -d "$APP" ] || { echo "tauri build produced no app at $APP" >&2; exit 1; }

# 3) Inject ------------------------------------------------------------------
echo "==> injecting the engine"
RES="$APP/Contents/Resources"
rm -rf "$RES/engine"; mkdir -p "$RES/engine"
cp -R "$SIDECAR/." "$RES/engine/"
"$RES/engine/overlay-engine" devig -110 -110 --json >/dev/null \
  || { echo "the injected engine does not run" >&2; exit 1; }

# 4) Record what this build read --------------------------------------------
#
# Tauri compiles ui/src into the Rust binary, so the shipped UI cannot be read
# back off disk to answer "was this built from the code in front of me". Hashes
# answer it and are immune to how the assets were encoded. Written BEFORE
# signing: anything added afterwards invalidates the signature.
{
  echo "# GENERATED by build_app.sh — the frontend this build read."
  for f in index.html app.css app.js; do
    printf '%s  %s\n' "$(shasum -a 256 "ui/src/$f" | cut -d' ' -f1)" "$f"
  done
} > "$RES/frontend.sha256"

# 5) Sign --------------------------------------------------------------------
sign_nested() {                      # $1 = identity, "-" for ad-hoc
  find "$RES/engine" -type f \( -perm -111 -o -name "*.dylib" -o -name "*.so" \) \
    -print0 | while IFS= read -r -d '' f; do
      if [ "$1" = "-" ]; then codesign --force -s - "$f" 2>/dev/null || true
      else codesign --force --timestamp --options runtime -s "$1" "$f" 2>/dev/null || true; fi
    done
}

if [ "$MODE" = "ship" ]; then
  IDENTITY="${BOOKBREAKER_SIGN_IDENTITY:-Developer ID Application: MATTHEW BENJAMIN-LEE KERR (9N3Z6J63T4)}"
  echo "==> signing inside-out with $IDENTITY"
  sign_nested "$IDENTITY"
  codesign --force --timestamp --options runtime -s "$IDENTITY" "$APP"
  codesign --verify --strict --verbose=2 "$APP"
else
  # Ad-hoc signing is what lets a locally-built .app launch at all on Apple
  # Silicon; without it the loader refuses the injected, unsigned sidecar.
  echo "==> ad-hoc signing (local use only)"
  sign_nested "-"
  codesign --force -s - "$APP" 2>/dev/null || true
fi

# 6) Notarize, staple, DMG ---------------------------------------------------
if [ "$MODE" = "ship" ]; then
  # Two ways to reach Apple's notary, neither of which puts a password in
  # front of whoever runs this: a notarytool keychain profile (the way Docket
  # and AdPlaybook ship; Matthew chose it for 0.1.7, 2026-10-08), or the
  # APPLE_ID / APPLE_PASSWORD / APPLE_TEAM_ID triple from secrets.env.
  if [ -n "${BOOKBREAKER_NOTARY_PROFILE:-}" ]; then
    NOTARY=(--keychain-profile "$BOOKBREAKER_NOTARY_PROFILE")
  else
    # shellcheck disable=SC1090
    [ -f "$HOME/.outlier/secrets.env" ] && . "$HOME/.outlier/secrets.env"
    : "${APPLE_ID:?set APPLE_ID, or BOOKBREAKER_NOTARY_PROFILE}" "${APPLE_PASSWORD:?set APPLE_PASSWORD}" "${APPLE_TEAM_ID:?set APPLE_TEAM_ID}"
    NOTARY=(--apple-id "$APPLE_ID" --password "$APPLE_PASSWORD" --team-id "$APPLE_TEAM_ID")
  fi

  echo "==> notarizing"
  ZIP="build/Bookbreaker.zip"
  rm -f "$ZIP"; ditto -c -k --keepParent "$APP" "$ZIP"
  xcrun notarytool submit "$ZIP" "${NOTARY[@]}" --wait
  xcrun stapler staple "$APP"
  xcrun stapler validate "$APP"

  echo "==> building the DMG"
  DMG="dist/Bookbreaker-$(plutil -extract CFBundleShortVersionString raw \
        "$APP/Contents/Info.plist").dmg"
  mkdir -p dist; rm -f "$DMG"
  STAGE="$(mktemp -d)"; cp -R "$APP" "$STAGE/"; ln -s /Applications "$STAGE/Applications"
  hdiutil create -volname Bookbreaker -srcfolder "$STAGE" -ov -format UDZO "$DMG" >/dev/null
  rm -rf "$STAGE"
  codesign --force --timestamp -s "$IDENTITY" "$DMG"

  # The DMG needs its OWN notarisation ticket. Notarising the .app and then
  # stapling the disk image fails with "Record not found" — Apple has no ticket
  # for that container, only for what is inside it. The first ship build did
  # exactly that and reported success anyway, because the staple was guarded
  # with `|| true`: a stapled app inside an unstapled image, which works online
  # and stalls on a machine that cannot reach Apple.
  echo "==> notarizing the DMG"
  xcrun notarytool submit "$DMG" "${NOTARY[@]}" --wait
  xcrun stapler staple "$DMG"
  xcrun stapler validate "$DMG"

  echo
  echo "  $DMG"
  echo "  sha256  $(shasum -a 256 "$DMG" | cut -d' ' -f1)"
  # The check Gatekeeper actually runs, on the artifact a stranger downloads.
  spctl -a -vvv -t install "$APP" 2>&1 | sed 's/^/  /'

  # 7) The in-app updater's download ---------------------------------------
  #
  # What Check for updates installs: the notarised, stapled app, tarred and
  # signed with the updater key. Made HERE, after stapling, and not by
  # `tauri build` (createUpdaterArtifacts is false): Tauri would tar the app
  # before the engine is injected and before Apple has seen it, and an
  # installed copy would replace itself with an app that has no engine and
  # trips Gatekeeper offline. The archive holds Bookbreaker.app at its top
  # level, because the updater drops the first path component on unpacking.
  VER="$(plutil -extract CFBundleShortVersionString raw "$APP/Contents/Info.plist")"
  UPD_TGZ="dist/Bookbreaker-$VER.app.tar.gz"
  echo "==> signing the updater download ($UPD_TGZ)"
  rm -f "$UPD_TGZ" "$UPD_TGZ.sig"
  # COPYFILE_DISABLE keeps macOS ._AppleDouble files out of the archive.
  ( cd "$(dirname "$APP")" && COPYFILE_DISABLE=1 tar -czf - "$(basename "$APP")" ) > "$UPD_TGZ"
  ( cd ui && npx --no-install tauri signer sign -f "$UPD_KEY" -p "" "$ROOT/$UPD_TGZ" ) >/dev/null
  [ -s "$UPD_TGZ.sig" ] || { echo "no updater signature was produced; refusing to ship an unsigned update" >&2; exit 1; }

  # Unpack it and prove the copy an update installs is signed, stapled and
  # runs its engine. "The archive was made" and "the app inside it works"
  # are separate claims; Docket shipped a non-starting app eight times
  # because nothing ever unpacked its artefact and tried it.
  UPD_CHK="$(mktemp -d)"
  tar -xzf "$UPD_TGZ" -C "$UPD_CHK"
  codesign --verify --strict "$UPD_CHK/Bookbreaker.app" \
    || { echo "the app inside the updater download does not verify" >&2; rm -rf "$UPD_CHK"; exit 1; }
  xcrun stapler validate "$UPD_CHK/Bookbreaker.app" >/dev/null \
    || { echo "the app inside the updater download has no notarisation ticket" >&2; rm -rf "$UPD_CHK"; exit 1; }
  "$UPD_CHK/Bookbreaker.app/Contents/Resources/engine/overlay-engine" devig -110 -110 --json >/dev/null \
    || { echo "the engine inside the updater download does not run" >&2; rm -rf "$UPD_CHK"; exit 1; }
  rm -rf "$UPD_CHK"
  echo "  $UPD_TGZ"
  echo "  $UPD_TGZ.sig"
  echo "  next: python3 scripts/updater_manifest.py $VER <notes file>   (writes dist/updater.json)"
fi

echo
echo "  $APP"
du -sh "$APP" | sed 's/^/  /'
echo "  BUILD OK"
