"""The goal planner: "if I have ten $1 bets, what are the best ten parlays to make $200?"

Every chance here can be checked by hand, so it is: the chance at least one parlay hits is
1 - prod(1 - p_i), tickets that share legs are worked out exactly (and checked against every outcome
of the legs), and with no edge no plan beats bankroll / target. Nothing here is a simulation of the
fixed tickets; only the multi-round plans are, and they say so.
"""

import itertools
import math
from datetime import date

import pytest

from overlay_engine import cli, goal
from overlay_engine.goal import Leg


def _legs(n, decimal=1.909091, p=0.5, margin_step=0.0):
    return [Leg(f"leg {i}", f"g{i}", decimal * (1 - margin_step * i), p, p) for i in range(n)]


# ------------------------------------------------------------ the arithmetic

def test_the_chance_at_least_one_parlay_hits_is_one_minus_the_product_of_one_minus_each():
    """Fixed case, by hand: ten parlays of nine -110 legs, each a 1-in-512 shot, in different games."""
    plan = goal.plan(10, 200, 10)
    p_each = 0.5 ** 9
    assert plan["chance_any_hits"] == pytest.approx(1 - (1 - p_each) ** 10, rel=1e-12)
    assert plan["chance_any_hits"] == pytest.approx(0.0193604796, abs=1e-9)
    assert "1 - (1 - p1)(1 - p2)" in plan["chance_any_hits_formula"]
    assert plan["tickets_share_legs"] is False
    assert len(plan["parlays"]) == 10 and all(len(t["legs"]) == 9 for t in plan["parlays"])


def test_every_ticket_shows_its_price_payout_and_chance_and_they_agree():
    plan = goal.plan(10, 200, 10)
    for t in plan["parlays"]:
        assert t["stake"] == 1.0
        assert t["decimal"] == pytest.approx(math.prod(l["decimal"] for l in t["legs"]), rel=1e-3)
        assert t["payout"] == pytest.approx(t["stake"] * t["decimal"], abs=0.02)
        assert t["profit_if_hit"] == pytest.approx(t["payout"] - t["stake"], abs=0.02)
        assert t["chance"] == pytest.approx(math.prod(l["chance"] for l in t["legs"]))
        assert t["payout"] >= 200, "each parlay must pay the target on its own"
        assert t["american"] > 0


def test_the_expected_return_is_the_sum_of_what_each_ticket_pays_times_its_chance():
    plan = goal.plan(10, 200, 10)
    want = sum(t["payout"] * t["chance"] for t in plan["parlays"])
    assert plan["expected_return"] == pytest.approx(want, abs=0.02)
    assert plan["expected_profit"] == pytest.approx(plan["expected_return"] - 10, abs=0.01)
    assert plan["expected_return"] < plan["bankroll"], "with no edge a parlay returns less than it costs"
    for t in plan["parlays"]:
        assert t["value_factor"] < 1, "every leg pays the margin again"


def test_with_no_edge_no_plan_beats_the_bankroll_over_the_target():
    for bankroll, target, n in ((10, 200, 10), (100, 1000, 4), (50, 400, 1), (20, 100, 5)):
        plan = goal.plan(bankroll, target, n)
        assert plan["ceiling"] == pytest.approx(bankroll / target, abs=1e-4)
        assert plan["ceiling_applies"] is True
        for s in plan["strategies"]:
            assert s["chance_to_reach"] <= plan["ceiling"] + 0.01, (s["strategy"], s["chance_to_reach"])


def test_splitting_into_many_parlays_that_each_need_the_target_lowers_the_chance():
    """The claim the answer makes in words, shown by the numbers it comes from."""
    plan = goal.plan(10, 200, 10)
    by = {s["strategy"]: s for s in plan["strategies"]}
    assert by["bold play"]["chance_to_reach"] > by["one parlay"]["chance_to_reach"] > by["10 parlays"]["chance_to_reach"]
    assert by["one parlay"]["chance_to_reach"] == pytest.approx(0.5 ** 5, abs=1e-4)      # five -110 legs pay 25x
    rr = next(s for s in plan["strategies"] if s["strategy"].startswith("round robin"))
    assert rr["chance_to_reach"] == 0.0 and rr["chance_something_back"] > 0.5
    assert "Splitting lowers the chance" in plan["read_this"]
    assert "every leg pays the book's margin again" in plan["read_this"]
    assert "does not find a bet that beats the book" in plan["read_this"]


def test_the_round_robin_is_exact_and_gets_something_back_more_often():
    plan = goal.plan(10, 200, 10)
    rr = next(s for s in plan["strategies"] if s["strategy"].startswith("round robin"))
    # Pairs of the best five legs: the chance no pair hits is the chance at most one of five legs wins: 6/32.
    assert rr["chance_nothing_back"] == pytest.approx(6 / 32)
    assert rr["method"] == "exact"
    assert rr["expected_return"] == pytest.approx(10 * (1.909091 ** 2) * 0.25, abs=0.02)


# ------------------------------------------------------------ tickets that share legs

def _brute_force_any(tickets, p):
    legs = sorted({i for t in tickets for i in t})
    total = 0.0
    for outcome in itertools.product((0, 1), repeat=len(legs)):
        won = {legs[k] for k, w in enumerate(outcome) if w}
        pr = math.prod(p[i] if i in won else 1 - p[i] for i in legs)
        if any(all(i in won for i in t) for t in tickets):
            total += pr
    return total


def test_tickets_that_share_legs_are_worked_out_exactly_not_as_if_independent():
    p = [0.5, 0.4, 0.6, 0.3, 0.7, 0.55]
    tickets = [[0, 1, 2], [0, 3, 4], [1, 4, 5], [2, 3, 5]]
    got, exact = goal.p_any(tickets, p)
    assert exact and got == pytest.approx(_brute_force_any(tickets, p), abs=1e-12)
    naive = 1 - math.prod(1 - math.prod(p[i] for i in t) for t in tickets)
    assert abs(got - naive) > 1e-3, "sharing legs must change the answer"


def test_disjoint_tickets_are_the_closed_form():
    p = [0.5] * 12
    got, exact = goal.p_any([[0, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10, 11]], p)
    assert exact and got == pytest.approx(1 - (1 - 0.125) ** 4)


def test_a_small_board_builds_distinct_tickets_that_share_as_few_legs_as_it_can():
    legs = _legs(14, margin_step=0.002)
    tickets = goal.build_tickets(legs, 10, 200.0)
    assert len(tickets) == 10
    assert len({tuple(sorted(t)) for t in tickets}) == 10, "no two tickets are the same bet"
    for t in tickets:
        assert math.prod(legs[i].decimal for i in t) >= 200
        assert len({legs[i].game for i in t}) == len(t), "no two legs of one ticket from the same game"
    used = [i for t in tickets for i in t]
    assert max(used.count(i) for i in set(used)) - min(used.count(i) for i in set(used)) <= 4, "uses are spread out"


def test_a_plan_on_a_small_board_says_its_tickets_lose_together():
    plan = goal.plan(10, 200, 6, _legs(14, margin_step=0.002), legs_from="a test board")
    assert plan["tickets_share_legs"] is True and plan["shared_leg_uses"] > 0
    assert "share legs" in plan["read_this"] or "lose together" in plan["read_this"]
    t = [[next(i for i, l in enumerate(_legs(14, margin_step=0.002)) if l.label == leg["label"]) for leg in p["legs"]]
         for p in plan["parlays"]]
    got, _ = goal.p_any(t, [0.5] * 14)
    assert plan["chance_any_hits"] == pytest.approx(got)


# ------------------------------------------------------------ where the legs come from is always said

def test_without_a_board_the_legs_are_typical_minus_110_bets_and_it_says_so():
    plan = goal.plan(10, 200, 10)
    assert plan["legs_source"] == "assumed"
    assert "no edge by construction" in plan["legs_from"] and "-110" in plan["legs_from"]


def test_positive_value_legs_lift_the_ceiling_and_add_steady_bets_and_say_the_chances_assume_theyre_right():
    legs = [Leg(f"edge {i}", f"g{i}", 2.2, 0.50, 0.48) for i in range(14)]     # priced above a 0.45 fair chance
    plan = goal.plan(100, 1000, 4, legs, legs_from="edge board")
    assert plan["ceiling_applies"] is False
    assert any(s["strategy"] == "steady bets" for s in plan["strategies"])
    assert "assume those fair chances are right" in plan["read_this"] or "assume those fair chances are right" in " ".join(
        s["how"] for s in plan["strategies"] if s["strategy"] == "steady bets")


def test_a_goal_that_cannot_be_a_goal_is_refused_in_a_sentence():
    for args in ((0, 100, 1), (10, 10, 1), (10, 5, 1), (10, 200, 0), (10, 200, 500), (float("nan"), 100, 1)):
        with pytest.raises(goal.GoalError):
            goal.plan(*args)


def test_goal_refresh_is_the_one_way_to_spend_credits_and_says_the_cost_before_it_fetches(tmp_path, monkeypatch, capsys):
    """With the person's own key, `goal --refresh` reads live odds the way the board does, records them, and builds the
    parlays from them. Nothing else in goal, Ask or the window fetches odds."""
    import json
    import sys
    from types import SimpleNamespace
    sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
    import test_keystore as tk
    import test_oddsapi as to
    from overlay_engine import keystore, oddsapi
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    fake = tk.FakeSecurity(stored=to.KEY)
    monkeypatch.setattr(keystore, "_available", lambda: None)
    monkeypatch.setattr(keystore.subprocess, "run", fake)
    api = to.FakeApi()
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=to.Clock()))
    assert cli.main(["goal", "--bankroll", "10", "--target", "50", "--tickets", "2", "--sport", "nfl", "--refresh", "--json"]) == 0
    out = capsys.readouterr()
    assert "uses up to" in out.err and "credit" in out.err, "the cost is said before the fetch"
    assert len(api.calls) == 1 and api.calls[0][0].endswith("/americanfootball_nfl/odds")
    got = json.loads(out.out)
    assert got["legs_source"] == "board" and "games from the live sportsbook odds read" in got["legs_from"]
    assert to.KEY not in out.out and to.KEY not in out.err
    # Without --refresh a second run fetches nothing: it builds from what was recorded.
    assert cli.main(["goal", "--bankroll", "10", "--target", "50", "--tickets", "2", "--json"]) == 0
    assert len(api.calls) == 1


def test_goal_refresh_without_a_key_says_how_to_add_one_and_fetches_nothing(tmp_path, monkeypatch, capsys):
    import sys
    sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
    import test_keystore as tk
    from overlay_engine import keystore, oddsapi
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(keystore, "_available", lambda: None)
    monkeypatch.setattr(keystore.subprocess, "run", tk.FakeSecurity())
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: (_ for _ in ()).throw(AssertionError("fetched")))
    assert cli.main(["goal", "--bankroll", "10", "--target", "50", "--sport", "nfl", "--refresh"]) == 2
    assert "No Odds API key is set" in capsys.readouterr().err


def test_the_goal_command_prints_the_comparison_and_the_json_has_the_same_numbers(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    assert cli.main(["goal", "--bankroll", "10", "--target", "200", "--tickets", "10", "--json"]) == 0
    import json
    got = json.loads(capsys.readouterr().out)
    assert got["bankroll"] == 10 and got["target"] == 200 and got["tickets"] == 10 and len(got["parlays"]) == 10
    assert got["tables"] and got["sentence"].startswith("There is no recent read of live sportsbook odds")
    assert cli.main(["goal", "--bankroll", "10", "--target", "200", "--tickets", "10"]) == 0
    text = capsys.readouterr().out
    assert "Chance at least one hits: 1.94%" in text and "bold play" in text and "round robin" in text
    assert cli.main(["goal", "--bankroll", "10", "--target", "5"]) == 2
    assert "more than the bankroll" in capsys.readouterr().err
