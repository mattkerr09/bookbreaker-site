"""nflverse's public files are downloaded only on a press, from GitHub, and every one is dated.

Nothing here touches a network: `update()` takes the fetch as a parameter, and the tests hand it
recorded bytes shaped like the real files (column names read from the real ones on 2026-10-09).
"""

import json
from datetime import date

import pytest

from overlay_engine import nflverse, playerproj

PLAYER_CSV = ("player_id,player_name,player_display_name,position,season,week,season_type,team,opponent_team,"
              "completions,attempts,passing_yards,passing_tds,passing_interceptions,carries,rushing_yards,"
              "receptions,receiving_yards\n00-1,P.Mahomes,Patrick Mahomes,QB,2025,1,REG,KC,BAL,24,36,291,2,0,3,11,0,0\n")
GAMES_CSV = ("game_id,season,game_type,week,gameday,away_team,away_score,home_team,home_score,result,spread_line,total_line\n"
             "2025_01_BAL_KC,2025,REG,1,2025-09-05,BAL,20,KC,27,7,3.0,46.5\n")


class FakeGitHub:
    """What GitHub's release assets do, by URL; records every request."""

    def __init__(self, missing=(), bodies=None):
        self.requests = []
        self.missing = set(missing)
        self.bodies = bodies or {}

    def __call__(self, url):
        self.requests.append(url)
        if url in self.missing:
            raise nflverse.NotFound("nope")
        body = self.bodies.get(url)
        if body is None:
            body = GAMES_CSV if url.endswith("games.csv") else PLAYER_CSV
        return body.encode(), {"Last-Modified": "Fri, 09 Oct 2026 12:08:25 GMT", "ETag": '"abc"'}


@pytest.fixture
def folder(tmp_path):
    return tmp_path / "nfl"


def test_the_urls_are_the_documented_release_assets():
    assert nflverse.PLAYER_URL == ("https://github.com/nflverse/nflverse-data/releases/download/"
                                   "stats_player/stats_player_week_{season}.csv")
    assert nflverse.GAMES_URL == "https://github.com/nflverse/nflverse-data/releases/download/schedules/games.csv"


def test_an_update_fetches_each_season_from_the_first_to_the_current_and_the_games(folder):
    get = FakeGitHub()
    report = nflverse.update(get, today=date(2026, 10, 9), folder=folder, first_season=2024)
    assert report.current_season == 2026
    assert set(get.requests) == {
        nflverse.GAMES_URL, *(nflverse.PLAYER_URL.format(season=s) for s in (2024, 2025, 2026))}
    assert nflverse.have_data(folder)
    assert sorted(report.fetched) == ["games.csv", "stats_player_week_2024.csv", "stats_player_week_2025.csv",
                                      "stats_player_week_2026.csv"]


def test_every_file_is_recorded_with_its_source_its_date_and_when_it_was_downloaded(folder):
    nflverse.update(FakeGitHub(), today=date(2026, 10, 9), now=1_790_000_000.0, folder=folder, first_season=2025)
    files = {f["file"]: f for f in nflverse.describe(folder)["files"]}
    f = files["stats_player_week_2025.csv"]
    assert f["url"] == nflverse.PLAYER_URL.format(season=2025)
    assert f["file_date"] == "Fri, 09 Oct 2026 12:08:25 GMT"
    assert f["downloaded_at"] == 1_790_000_000.0
    assert len(f["sha256"]) == 64 and f["bytes"] == len(PLAYER_CSV)
    on_disk = json.loads((folder / "manifest.json").read_text())
    assert on_disk["files"]["games.csv"]["url"] == nflverse.GAMES_URL
    assert nflverse.describe(folder)["downloaded_at"] == 1_790_000_000.0


def test_a_connection_that_drops_part_way_keeps_what_arrived_and_the_next_update_only_fetches_the_rest(folder):
    class Drops(FakeGitHub):
        def __call__(self, url):
            if len(self.requests) >= 3:
                raise nflverse.NflverseError("Bookbreaker could not reach GitHub.")
            return super().__call__(url)
    with pytest.raises(nflverse.NflverseError):
        nflverse.update(Drops(), today=date(2026, 10, 9), folder=folder, first_season=2023)
    kept = set(nflverse.read_manifest(folder)["files"])
    assert len(kept) == 3 and not nflverse.have_data(folder), "the games file never arrived, so it is not usable yet"
    again = FakeGitHub()
    nflverse.update(again, today=date(2026, 10, 9), folder=folder, first_season=2023)
    assert set(again.requests) == {nflverse.PLAYER_URL.format(season=2026), nflverse.PLAYER_URL.format(season=2025), nflverse.GAMES_URL}
    assert nflverse.have_data(folder)


def test_a_season_not_started_yet_falls_back_to_last_year(folder):
    """Before a new season's file exists GitHub answers 404 for it; the current season is the newest that has one."""
    get = FakeGitHub(missing={nflverse.PLAYER_URL.format(season=2026)})
    report = nflverse.update(get, today=date(2026, 3, 1), folder=folder, first_season=2025)
    assert report.current_season == 2025
    assert "stats_player_week_2026.csv" not in report.fetched


def test_a_second_update_fetches_only_the_current_season_and_the_games(folder):
    nflverse.update(FakeGitHub(), today=date(2026, 10, 9), folder=folder, first_season=2024)
    again = FakeGitHub()
    report = nflverse.update(again, today=date(2026, 10, 9), folder=folder, first_season=2024)
    assert set(again.requests) == {nflverse.PLAYER_URL.format(season=2026), nflverse.GAMES_URL}
    assert sorted(report.kept) == ["stats_player_week_2024.csv", "stats_player_week_2025.csv"]


def test_a_file_that_is_not_the_csv_it_claims_to_be_is_refused_and_the_old_one_kept(folder):
    nflverse.update(FakeGitHub(), today=date(2026, 10, 9), folder=folder, first_season=2026)
    before = (folder / "games.csv").read_bytes()
    html = FakeGitHub(bodies={nflverse.GAMES_URL: "<html>rate limited</html>"})
    with pytest.raises(nflverse.NflverseError, match="did not look like"):
        nflverse.update(html, today=date(2026, 10, 9), folder=folder, first_season=2026)
    assert (folder / "games.csv").read_bytes() == before


def test_only_github_is_ever_downloaded_from():
    assert nflverse._allowed("https://github.com/nflverse/nflverse-data/releases/download/x/y.csv")
    assert nflverse._allowed("https://release-assets.githubusercontent.com/github-production-release-asset/1/2")
    assert nflverse._allowed("https://raw.githubusercontent.com/nflverse/nfldata/master/data/games.csv")
    for url in ("http://github.com/x", "https://evil.example/github.com", "https://github.com.evil.example/x",
                "https://notgithub.com/x", "ftp://github.com/x"):
        assert not nflverse._allowed(url), url
    with pytest.raises(nflverse.NflverseError, match="only downloads from GitHub"):
        nflverse.urllib_get("https://evil.example/x.csv")


def test_a_redirect_away_from_github_is_not_followed():
    handler = nflverse._GitHubOnly()
    with pytest.raises(nflverse.NflverseError):
        handler.redirect_request(None, None, 302, "Found", {}, "https://evil.example/steal")


def test_a_query_with_nothing_downloaded_says_what_to_do_and_downloads_nothing(folder, monkeypatch):
    def boom(url):
        raise AssertionError("a query must never download")
    monkeypatch.setattr(nflverse, "urllib_get", boom)
    with pytest.raises(playerproj.ProjectionError, match="players --update"):
        playerproj.answer("passing yards", 299.5, folder=folder)
    assert not nflverse.have_data(folder)
    assert nflverse.describe(folder)["estimate_megabytes"] == nflverse.ESTIMATE_MB


def test_the_readers_return_what_the_projection_needs(folder):
    nflverse.update(FakeGitHub(), today=date(2025, 10, 9), folder=folder, first_season=2025)
    game = nflverse.read_games(folder)[0]
    assert (game["home"], game["away"], game["line"], game["total"], game["result"]) == ("KC", "BAL", 3.0, 46.5, 7.0)
    row = nflverse.read_weekly(folder)[0]
    assert (row["name"], row["pos"], row["team"], row["opp"], row["passing_yards"]) == ("Patrick Mahomes", "QB", "KC", "BAL", 291.0)
