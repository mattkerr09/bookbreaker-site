import datetime as dt


def test_a_court_ordered_block_removes_a_nationwide_venue_from_that_state():
    """Kalshi and Polymarket US are nationwide except where a court or regulator has
    blocked their sports contracts; a user in Michigan must not be shown either as a
    venue."""
    from overlay_engine.catalog import EXCLUSION_SOURCES, VENUES, for_state
    for key in ("kalshi", "polymarket_us"):
        venue = VENUES[key]
        for st in ("MA", "MI", "NV", "WA"):
            assert not venue.available_in(st), (key, st)
            assert key not in {v.key for v in for_state(st)}, (key, st)
        for st in ("NY", "oh", "NJ", "AZ", "PA", "IL", "MD"):
            assert venue.available_in(st), (key, st)
    for key, v in VENUES.items():
        if v.excluded:
            assert key in EXCLUSION_SOURCES, f"{key} excludes states with no source"
            assert v.nationwide, f"{key} has exclusions but is not nationwide"


def test_polymarket_us_replaces_the_unverified_international_polymarket():
    """US persons may not trade the international Polymarket, so the catalog has one
    Polymarket and it is the exchange they can: nationwide, verified, with a state list."""
    from overlay_engine.catalog import VENUES, for_state
    from overlay_engine.models import BookTier
    assert "polymarket" not in VENUES
    pm = VENUES["polymarket_us"]
    assert pm.name == "Polymarket US" and pm.tier is BookTier.EXCHANGE
    assert pm.nationwide and pm.verified and not pm.jurisdiction_unknown and not pm.limits_winners
    assert pm.excluded == frozenset({"MA", "MI", "NV", "WA"})
    assert "polymarket_us" in {v.key for v in for_state("NJ")} and "polymarket_us" in {v.key for v in for_state("PA")}
    assert "polymarket_us" not in {v.key for v in for_state("NV")}


def test_every_state_row_rests_on_a_dated_source_and_the_excluded_set_is_the_restricted_rows():
    """One table decides which states a venue is hidden in and which carry a note. A row
    with no source, a source with no date, or an `excluded` set that is not exactly the
    restricted rows is a table that says something nobody can check."""
    from overlay_engine.catalog import (EXCLUSION_SOURCES, STATE_NAMES, STATE_STATUS, VENUES,
                                        restricted_states, state_status)
    assert set(STATE_STATUS) == {"kalshi", "polymarket_us"} == {k for k, v in VENUES.items() if v.excluded}
    for key, rows in STATE_STATUS.items():
        names = {s.name for s in EXCLUSION_SOURCES[key]}
        for st, row in rows.items():
            assert st in STATE_NAMES, (key, st)
            assert row.kind in ("restricted", "contested"), (key, st)
            assert row.sources and set(row.sources) <= names, (key, st)
            found = state_status(key, st.lower())
            assert found and [s.name for s in found[1]] == list(row.sources)
        assert VENUES[key].excluded == restricted_states(key) == {s for s, r in rows.items() if r.kind == "restricted"}
        for src in EXCLUSION_SOURCES[key]:
            published, read = dt.date.fromisoformat(src.published), dt.date.fromisoformat(src.read)
            assert published <= read, (key, src)
            assert src.url.startswith("https://") and src.name
    assert state_status("kalshi", "PA") is None and state_status("polymarket_us", "NJ") is None


def test_the_dated_sources_are_the_ones_the_rows_were_read_from():
    from overlay_engine.catalog import EXCLUSION_SOURCES, STATE_STATUS
    by_name = {s.name: s for s in EXCLUSION_SOURCES["polymarket_us"]}
    assert by_name["Fox Sports"].published == "2026-10-05"
    assert by_name["Fox Sports"].url == "https://www.foxsports.com/stories/betting/prediction-markets-legal-states"
    assert by_name["CBS Sports"].published == "2026-10-08"
    assert by_name["CBS Sports"].url == "https://www.cbssports.com/prediction/news/polymarket-promo-code/"
    # CBS names Nevada only; Fox's table has Nevada and the three other restricted states.
    assert STATE_STATUS["polymarket_us"]["NV"].sources == ("Fox Sports", "CBS Sports")
    assert STATE_STATUS["polymarket_us"]["MI"].sources == ("Fox Sports",)
    assert EXCLUSION_SOURCES["kalshi"][0].read == "2026-10-07", "Kalshi's rows were first read on the 7th"


def test_fox_sports_contested_states_are_shown_not_hidden_and_new_jersey_is_open():
    """Fox's table marks MA, MI, NV and WA Restricted, a list of states Contested (the platforms
    operate while a case runs) and New Jersey Available. Its separate bullet for OG, a different
    exchange, which lists NJ among restricted states, is not about Polymarket US."""
    from overlay_engine.catalog import STATE_STATUS, VENUES
    for key in ("kalshi", "polymarket_us"):
        rows = STATE_STATUS[key]
        assert {s for s, r in rows.items() if r.kind == "contested"} >= {"AZ", "IL", "MD", "NY", "OH"}
        assert "NJ" not in rows and "PA" not in rows
        for st, r in rows.items():
            if r.kind == "contested":
                assert VENUES[key].available_in(st), (key, st)


# ------------------------------------------------------- Michigan, 2026-10-09
# The owner looked at the Promos page for Michigan, saw nine books, and said there were
# many more. The Michigan Gaming Control Board's own list names thirteen. These make the
# table equal that list, and keep it equal.

MICHIGAN_KEYS = {"dk", "fd", "mgm", "caesars", "bet365", "fanatics", "hardrock", "thescore",
                 "betrivers", "betparx", "fourwinds", "firekeepers", "eagle"}


def test_michigan_offers_exactly_the_brands_its_regulator_lists():
    """The list is pinned here as well as recorded in the catalog, so an edit to one cannot
    quietly move the other. The regulator's own August 2026 release says 13 operators offer
    online sports betting: twelve casinos from its provider page, plus bet365 at Odawa."""
    from overlay_engine.catalog import REGULATOR_LISTS, for_state
    from overlay_engine.models import BookTier
    reg = REGULATOR_LISTS["MI"]
    offered = {v.key for v in for_state("MI") if v.tier is BookTier.RETAIL}
    assert offered == {b.key for b in reg.brands} == MICHIGAN_KEYS
    assert len(reg.brands) == reg.stated_count == 13
    for b in reg.brands:
        assert b.operator and b.platform and b.brand, b


def test_a_brand_the_regulator_says_has_left_is_not_offered_in_the_state():
    """SI Sportsbook stopped taking Michigan bets on 2025-07-28; Hard Rock Bet took the
    tribe's licence on 2025-12-02. An exit removes the brand, and the key stays so bets
    already in a ledger resolve."""
    from overlay_engine.catalog import EXITED, REGULATOR_LISTS, VENUES, for_state
    reg = REGULATOR_LISTS["MI"]
    assert [e.key for e in reg.exits] == ["si"]
    for e in reg.exits:
        assert e.key in EXITED and VENUES[e.key].exited
        assert not VENUES[e.key].available_in("MI")
        assert e.key not in {v.key for v in for_state("MI", include_unverified=True)}
        assert e.source.startswith("https://") and e.ended <= "2026-10-09"
    assert next(b for b in reg.brands if b.key == "hardrock").since == "2025-12-02"


def test_casino_only_authorisations_are_not_sportsbooks():
    """The regulator authorizes Caesars Horseshoe (Kewadin) and Golden Nugget (Ojibwa) for
    online casino games only; neither is a sportsbook in Michigan. PrizePicks and Underdog
    are fantasy contests, noted and not offered."""
    from overlay_engine.catalog import REGULATOR_LISTS, for_state
    reg = REGULATOR_LISTS["MI"]
    assert len(reg.casino_only) == 2
    names = " ".join(v.name for v in for_state("MI", include_unverified=True))
    assert "Golden Nugget" not in names and "Horseshoe" not in names
    assert "PrizePicks" in reg.daily_fantasy and "Underdog" in reg.daily_fantasy
    assert "underdog" not in {v.key for v in for_state("MI", include_unverified=True)}


def test_the_regulator_check_can_fail(monkeypatch):
    """regulator_problems() is what scripts/check_catalog.py runs. Each way the venue table
    can disagree with the list is one it must name."""
    import dataclasses
    from overlay_engine import catalog
    today = dt.date(2026, 10, 9)
    assert catalog.regulator_problems(today=today) == []

    def change(key, **changes):
        monkeypatch.setitem(catalog.VENUES, key, dataclasses.replace(catalog.VENUES[key], **changes))

    change("eagle", states=frozenset())           # a listed brand the table does not offer
    assert any("Eagle Casino & Sports" in p for p in catalog.regulator_problems(today=today))
    monkeypatch.undo()
    change("prime", states=catalog.VENUES["prime"].states | {"MI"})   # one it does not list
    assert any("does not list" in p and "prime" in p for p in catalog.regulator_problems(today=today))
    monkeypatch.undo()
    change("si", states=frozenset({"MI"}))        # a brand that left, offered again
    assert any("SI Sportsbook" in p for p in catalog.regulator_problems(today=today))
    monkeypatch.undo()
    assert any("past the" in p for p in catalog.regulator_problems(today=dt.date(2027, 3, 1)))
    reg = catalog.REGULATOR_LISTS["MI"]           # a count the list does not match
    monkeypatch.setitem(catalog.REGULATOR_LISTS, "MI", reg._replace(stated_count=14))
    assert any("says 14" in p for p in catalog.regulator_problems(today=today))


def test_michigans_list_has_its_own_read_date_and_the_books_command_prints_it():
    import subprocess
    import sys
    from pathlib import Path
    from overlay_engine.catalog import REGULATOR_LISTS, state_summary
    reg = REGULATOR_LISTS["MI"]
    assert reg.read == max(s.read for s in reg.sources) == "2026-10-09"
    for s in reg.sources:
        assert s.url.startswith("https://") and s.name
        assert not s.published or s.published <= s.read
    assert state_summary("MI")["regulator"]["read"] == "2026-10-09"
    assert state_summary("NJ")["regulator"] is None
    root = Path(__file__).resolve().parent.parent
    done = subprocess.run([sys.executable, str(root / "backend" / "cli.py"), "books", "MI"],
                          capture_output=True, text=True, timeout=120)
    assert done.returncode == 0, done.stderr[:400]
    out = done.stdout
    assert "MI — 13 venues" in out
    assert "Michigan Gaming Control Board's own list, read 2026-10-09" in out
    for b in reg.brands:
        assert b.operator in out and b.platform in out, b.brand
    assert "Left MI: SI Sportsbook, 2025-07-28" in out
