"""The Ask page, its settings, and the shell commands behind them keep their promises.

Static, like test_odds_source_window.py: none of it needs a GUI. What a screenshot cannot show:

  * Ask is the first place on the rail and the page the window opens on, and nothing on it runs by
    itself: asking is a press, and the page's first button is not a spending one;
  * the question reaches the engine on standard input and never on a command line, and lives in this
    page's memory only;
  * the Anthropic key travels by one road (the shell's save_anthropic_key, down a pipe), the box is
    emptied the moment it is sent, and only its last four characters are ever shown;
  * everything an answer carries is drawn as text, never as markup;
  * what the privacy note says leaves this Mac is true;
  * the shell allows the new verbs and gives standard input to none of them but ask.
"""

import html
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()
RUST = (UI / "src-tauri" / "src" / "main.rs").read_text()
BUILD = (ROOT / "scripts" / "build_app.sh").read_text()
PYPROJECT = (ROOT / "pyproject.toml").read_text()


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def _text(markup: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", "", markup))).strip()


PANEL = HTML[HTML.index('id="panel-ask"'):HTML.index('id="panel-board"')]


# ------------------------------------------------------------ the first place

def test_ask_is_the_first_place_on_the_rail_and_the_page_the_window_opens_on():
    navs = re.findall(r'<button class="nav[^"]*" data-section="([a-z]+)" data-panel="([a-z]+)"', HTML)
    assert navs[0] == ("ask", "ask") and [s for s, _ in navs][1] == "arbs"
    assert len(navs) <= 6
    assert re.search(r'<button class="nav is-on" data-section="ask" data-panel="ask"', HTML)
    assert len(re.findall(r'<section class="panel is-on"', HTML)) == 1
    assert '<section class="panel is-on" id="panel-ask" data-section="ask">' in HTML
    assert '<b id="top-title">Ask</b>' in HTML and 'ask: "Ask"' in JS
    assert JS.count('\nshow("ask");') == 1


def test_the_page_offers_the_example_questions_as_chips():
    chips = re.findall(r'<button class="chip" type="button" data-ask="([^"]+)">', PANEL)
    chips = [html.unescape(c) for c in chips]
    assert "Who is most likely to pass for 300 yards this week?" in chips
    assert "If I have 10 $1 bets, what are the best 10 parlays to make $200?" in chips
    assert "Best +EV bets right now" in chips
    assert any(c.startswith("Any arbs on tonight") for c in chips)
    assert "Fair odds on -150 / +130" in chips


def test_nothing_on_the_page_runs_by_itself_and_its_first_button_is_not_a_spending_one():
    assert 'data-run=' not in PANEL, "prime() would run the page's first data-run button when it is first shown"
    for timer in ("setInterval", "setTimeout", "requestAnimationFrame"):
        for m in re.finditer(timer + r"\(", JS):
            for reach in ("askSend", "askDirect", "askEngine", "refreshAskStatus"):
                assert reach not in JS[m.start():m.start() + 300], f"a {timer} reaches {reach}"
    sends = [m.start() for m in re.finditer(r"\baskSend\(", JS)]
    assert len(sends) == 4, "askSend is defined, and called by a chip, the form and Enter: nothing else"
    assert len(re.findall(r"\baskDirect\(", JS)) == 3, "askDirect is defined and called by the two form buttons"
    at_load = re.findall(r"^(refreshAskStatus|askSend|askDirect)\(", JS, re.M)
    assert at_load == ["refreshAskStatus"], "the one thing run at load is the local status"
    assert ASK_BUILDERS["status"] == '"ask", "--status"'


ASK_BUILDERS = dict(re.findall(r'^\s{2}([a-z]+): \(\) => \[(.*?)\],?$', _braced(JS, "const ASK = {"), re.M | re.S))


# ------------------------------------------------------------ the question

def test_the_question_reaches_the_engine_on_standard_input_and_never_on_a_command_line():
    assert JS.count('invoke("engine_stdin"') == 1
    assert '"ask", "--stdin"' in ASK_BUILDERS["ask"]
    assert "question" not in ASK_BUILDERS["ask"], "the question is not an argument"
    ask_call = _braced(JS, "async function askSend(")
    assert 'askEngine("ask", JSON.stringify({ question, history: ASKHIST.slice(-6) }))' in ask_call
    # The conversation is in this page's memory only.
    assert "ASKHIST" in JS and not re.search(r'store\.set\([^)]*(ASKHIST|question|history)', JS)
    assert set(re.findall(r'store\.set\("([^"]+)"', JS)) == {"bb.state", "bb.live", "bb.odds", "bb.askmodel"}
    assert "localStorage" not in JS.replace(_braced(JS, "const store = {"), "")


def test_the_shell_gives_standard_input_to_ask_and_to_nothing_else():
    run = _braced(RUST, "fn run_engine_with(")
    assert 'input.is_some() && verb != "ask"' in run
    assert "Only a question for Ask is ever sent to the engine on standard input." in run
    command = _braced(RUST, "async fn engine_stdin(")
    assert "run_engine_with(&args, &p, Some(&input))" in command
    assert "engine_stdin" in re.search(r"generate_handler!\[([^\]]*)\]", RUST).group(1)


def test_ask_may_read_the_live_venues_only_while_the_live_switch_is_on():
    assert '...(liveOn() ? ["--live"] : [])' in ASK_BUILDERS["ask"]
    assert ASK_BUILDERS["ask"].count("--live") == 1


# ------------------------------------------------------------ the key

def test_the_anthropic_key_box_is_a_password_field_that_keeps_nothing():
    tag = re.search(r'<input id="ask-key-in"[^>]*>', HTML).group(0)
    assert 'type="password"' in tag and 'autocomplete="off"' in tag and 'spellcheck="false"' in tag
    assert re.search(r'<button class="go" id="ask-key-save" type="button">Save key</button>', HTML)
    assert re.search(r'<button class="go ghost" id="ask-key-clear" type="button">Clear key</button>', HTML)


def test_the_key_is_sent_by_one_road_and_the_box_is_emptied_first():
    save = _braced(JS, "async function saveAskKey(")
    assert save.count('invoke("save_anthropic_key", { key })') == 1 and JS.count('"save_anthropic_key"') == 1
    assert save.index('invoke("save_anthropic_key"') < save.index('input.value = "";') < save.index("if (out.error)")
    assert '"key", "set"' not in JS
    assert dict(re.findall(r'^\s*(askkeystatus|askkeyclear): \(\) => \[(.*?)\],?$', JS, re.M)) == {
        "askkeystatus": '"key", "status", "--service", "anthropic"', "askkeyclear": '"key", "clear", "--service", "anthropic"'}
    reads = re.findall(r'getElementById\("ask-key-in"\)', JS)
    assert len(reads) == 2, "the key box is read by Save and by Enter, and nothing else"
    for leak in ("innerHTML", "askKeyMessage(key", "store.", "console", "ASKHIST"):
        assert leak not in save, leak
    assert not re.search(r"\bconsole\.(log|warn|error|info|debug|trace)\b", JS)


def test_only_the_last_four_characters_and_whether_a_key_is_set_are_ever_drawn():
    status = _braced(JS, "function drawAskStatus(")
    assert "key.last4" in status and "key.set" in status
    assert not re.search(r"\bkey\.(value|secret|key)\b", status)


def test_the_one_link_out_goes_through_the_shell_and_names_no_address():
    assert JS.count('"open_anthropic_console"') == 1
    assert re.search(r'<button type="button" class="linkish" id="ask-console">console\.anthropic\.com</button>', HTML)
    assert 'invoke("open_anthropic_console")' in JS
    opener = _braced(RUST, "fn open_anthropic_console(")
    assert 'Command::new("/usr/bin/open").arg(ANTHROPIC_CONSOLE)' in opener and opener.count(".arg(") == 1
    assert 'const ANTHROPIC_CONSOLE: &str = "https://console.anthropic.com/settings/keys";' in RUST
    for name, text in (("index.html", HTML), ("app.js", JS), ("app.css", CSS)):
        assert re.findall(r"https?://", text) == [], name


def test_the_shell_saves_the_anthropic_key_on_standard_input_and_nowhere_else():
    save = _braced(RUST, "fn save_anthropic(")
    assert '.args(["key", "set", "--service", "anthropic", "--json"])' in save
    assert ".stdin(Stdio::piped())" in save and "write_all(key.as_bytes())" in save
    assert save.count(".args(") == 1 and ".arg(" not in save, "the key must not become an argument"
    assert "format!" not in save.split("write_all")[0]
    command = _braced(RUST, "async fn save_anthropic_key(")
    assert "save_anthropic(&key, &p)" in command
    for sink in ("println!", "eprintln!", "dbg!", "log::", "tracing::"):
        assert sink not in save and sink not in command, sink
    handlers = re.search(r"generate_handler!\[([^\]]*)\]", RUST).group(1)
    assert "save_anthropic_key" in handlers and "open_anthropic_console" in handlers


def test_the_generic_engine_call_still_cannot_set_either_key():
    run = _braced(RUST, "fn run_engine_with(")
    assert 'Some("status") | Some("clear")' in run
    assert "Odds source page or from Ask's settings" in run


def test_the_new_verbs_are_on_the_shells_allow_list_and_the_build_asks_each_one():
    allowed = re.search(r'const ALLOWED: \[&str; (\d+)\] = \[([^\]]+)\]', RUST)
    verbs = re.findall(r'"([a-z-]+)"', allowed.group(2))
    assert int(allowed.group(1)) == len(verbs) == 14
    assert {"players", "goal", "ask"} <= set(verbs) and "edges" not in verbs
    for verb in ("players", "goal", "ask"):
        assert re.search(rf"^\s+{verb}\)\s+probe=", BUILD, re.M), verb


# ------------------------------------------------------------ the package

def test_the_wheel_has_no_dependency_and_the_app_bundle_has_the_anthropic_package():
    assert re.search(r"^dependencies = \[\]$", PYPROJECT, re.M)
    assert re.search(r'^\[project\.optional-dependencies\]\nask = \[', PYPROJECT.replace("\n#", "\n#"), re.M) or \
        re.search(r'\[project\.optional-dependencies\](?:\n#.*)*\nask = \["anthropic', PYPROJECT)
    assert "--collect-all anthropic" in BUILD
    assert 'grep -q \'"sdk": true\'' in BUILD, "the build asks the frozen engine whether it can import the package"
    assert 'python3 -c "import anthropic"' in BUILD
    assert "release.sh" and "no dependencies pulled in" in (ROOT / "scripts" / "release.sh").read_text()


# ------------------------------------------------------------ what a person is told

def test_the_privacy_note_names_ask_and_the_download_and_what_each_sends():
    note = re.search(r'<div class="privacy-pop">(.*?)</div>', HTML, re.S).group(1)
    items = [_text(i) for i in re.findall(r"<li>(.*?)</li>", note, re.S)]
    assert len(items) == 5
    ask_item = items[3]
    assert ask_item.startswith("Ask, when you send a question")
    assert "only if you have added your own Anthropic key" in ask_item
    assert "api.anthropic.com" in ask_item and "Anthropic sees this Mac" in ask_item
    assert "your question, the conversation so far and the results of the lookups" in ask_item.lower()
    assert "nothing about your bets leaves unless you ask claude about them" in ask_item.lower()
    assert "local Ollama model nothing leaves your Mac at all" in ask_item
    download = items[4]
    assert download.startswith("Download NFL data, when you press it")
    assert "public nflverse files from GitHub" in download and "about 50 MB" in download
    assert "Five things reach the internet" in _text(note) and "all five are yours to start" in _text(note)


def test_the_ask_page_says_the_same_thing_beside_the_box():
    sends = _text(re.search(r'<p class="sends" id="ask-sends">(.*?)</p>', PANEL, re.S).group(1))
    assert "only when you have added your own Anthropic key" in sends
    assert "local Ollama model nothing leaves your Mac" in sends
    assert "Nothing about your bets leaves unless you ask Claude about them" in sends


def test_the_settings_say_where_the_key_lives_what_an_answer_costs_and_that_nothing_is_installed():
    settings = _text(PANEL[PANEL.index('id="ask-settings"'):])
    assert "kept in your Mac’s Keychain and only ever sent to Anthropic" in settings
    assert "Claude Opus 5.5" in settings and "Claude Sonnet 5.5" in settings and "$4 in / $20 out" in settings and "$2 in / $10 out" in settings
    assert "shows what it cost" in settings and "It never installs or downloads a model" in settings
    assert '<option value="opus">' in PANEL and '<option value="sonnet">' in PANEL


def test_the_download_is_a_button_that_says_what_it_fetches_and_how_big():
    assert re.search(r'<button class="go" id="ask-download" type="button">Download NFL data</button>', HTML)
    line = _braced(JS, "function dataLine(")
    assert "nothing is downloaded until you do" in line and "estimate_megabytes" in line
    assert "Source: the nflverse project" in line
    click = JS[JS.index('ASKEL("ask-download").addEventListener'):]
    assert click.count('askEngine("download")') == 1 and "ASK.download" not in click


def test_the_page_never_says_guaranteed_or_risk_free():
    for text in (_text(PANEL), JS[JS.index("const ASK = {"):JS.index("/* ── Check for updates")]):
        low = text.lower()
        assert "risk-free" not in low and "riskfree" not in low and "guarantee" not in low and "either way" not in low


# ------------------------------------------------------------ drawing

def test_everything_an_answer_carries_is_drawn_as_text_never_as_markup():
    card = _braced(JS, "function askCard(")
    for expr in re.findall(r"\$\{([^}]*)\}", card):
        ok = (expr.startswith(("esc(", "askBadges(", "askParas(", "askTable", "(out.tables", "(out.notes", "(out.ungrounded", "tools",
                               "cost", "out.ungrounded", "out.notes", "out.left_this_mac ? ` ${esc("))
              or expr in ("tools", "cost") or "toLocaleString" in expr or "toFixed" in expr or "esc(" in expr)
        assert ok, f"askCard writes {expr!r} without esc()"
    para = JS[JS.index("const askParas = "):JS.index("function askTable(")]
    assert "esc(p)" in para
    table = _braced(JS, "function askTable(")
    for raw in ("${c}", "${r}", "${t.title}", "${t.note}", "${t.columns", "${t.rows"):
        assert raw not in table, f"askTable writes {raw} without esc()"
    for needed in ("esc(c)", "esc(t.title)", "esc(t.note)"):
        assert needed in table, needed
    badge = _braced(JS, "function askBadges(")
    assert badge.count("esc(out.model") == 2
    ask_js = JS[JS.index("const ASK = {"):JS.index("/* ── Check for updates")]
    for sink in ("document.write", "outerHTML", "insertAdjacentHTML"):
        assert sink not in ask_js
    assert 'el.textContent = text;' in _braced(JS, "function askBubble(")


def test_every_class_the_ask_page_uses_has_a_rule():
    used = {"engine", "chip", "ask-chips", "asklog", "askempty", "bubble", "answerbox", "waitbox", "answer-head", "answer-text",
            "tablewrap", "tscroll", "asktable", "askmeta", "askbar", "askcard", "asktools", "asktools-grid", "asksettings", "askmodel"}
    for cls in used:
        assert re.search(rf"\.{re.escape(cls)}\b[^{{}}]*\{{", CSS), f".{cls} has no rule in app.css"
        assert cls in HTML or cls in JS, f".{cls} is styled and unused"
    assert '.nav[data-section="ask"]' in CSS and ".t-ask" in CSS and 'body[data-section="ask"]' in CSS


# ------------------------------------------------------------ the window reads only what the engine sends

@pytest.fixture(scope="module")
def engine_output(tmp_path_factory):
    import contextlib
    import io
    import os
    import test_ask as ta
    import ask_fixtures as fx
    from overlay_engine import ask as ask_mod
    from overlay_engine import asktools, cli, keystore, localai

    home = tmp_path_factory.mktemp("home")
    os.environ["OVERLAY_HOME"] = str(home)
    fx.write_nfl(home / "nfl")
    saved = (keystore.subprocess.run, localai._http)
    keystore.subprocess.run = lambda *a, **k: (_ for _ in ()).throw(AssertionError("real keychain"))
    localai._http = lambda *a, **k: (_ for _ in ()).throw(OSError("no ollama"))

    def call(argv):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            cli.main(argv)
        return json.loads(out.getvalue())

    try:
        ctx = asktools.Context(db=str(home / "x.db"))
        fake = ta.FakeClaude(ta.response([ta.tool_use("devig", {"odds": ["-150", "+130"]})], stop="tool_use"),
                             ta.response([ta.text("-150 is 58.2%.")], i=1500, o=300))
        claude = ask_mod.ask("fair odds on -150 / +130", ctx=ctx, key_getter=lambda: ta.KEY, client_factory=lambda k: fake, today="2026-10-09")
        built = call(["ask", "--engine", "builtin", "fair odds on -150 / +130", "--json"])
        yield {"claude": claude, "builtin": built, "goal": call(["goal", "--bankroll", "10", "--target", "200", "--tickets", "10", "--json"]),
               "players_status": call(["players", "--status", "--json"])}
    finally:
        keystore.subprocess.run, localai._http = saved
        os.environ.pop("OVERLAY_HOME", None)


def test_every_field_the_answer_card_reads_is_one_the_engine_sends(engine_output):
    claude, built = engine_output["claude"], engine_output["builtin"]
    card = _braced(JS, "function askCard(") + _braced(JS, "function askBadges(")
    read = set(re.findall(r"\bout\.([a-z_]+)", card))
    assert read >= {"answer", "tables", "tools", "cost", "notes", "ungrounded", "left_this_mac", "mode", "model"}
    assert read <= set(claude) and read <= set(built), f"read but never sent: {sorted(read - set(claude))}"
    cost_reads = set(re.findall(r"\bc\.([a-z_]+)", card))
    assert cost_reads <= set(claude["cost"]), sorted(cost_reads - set(claude["cost"]))
    assert {"title", "columns", "rows", "note"} <= set(claude["tables"][0]) and set(re.findall(r"\bt\.([a-z]+)", _braced(JS, "function askTable("))) <= set(claude["tables"][0])
    assert set(re.findall(r"\bleft_this_mac\.([a-z]+)", card)) <= set(claude["left_this_mac"])
    assert claude["cost"]["usd"] > 0 and claude["mode"] == "claude" and built["cost"] is None


def test_every_field_the_status_and_data_lines_read_is_one_the_engine_sends(monkeypatch, tmp_path):
    from overlay_engine import cmds_ask, keystore, localai, nflverse
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(keystore, "status", lambda runner=None, name="oddsapi": keystore.Status(True, "ABCD", "Anthropic API"))
    monkeypatch.setattr(localai, "status", lambda http=None: {"running": True, "models": ["m"], "tool_models": ["m"]})
    status = cmds_ask.ask_status()
    draw = _braced(JS, "function drawAskStatus(") + _braced(JS, "function dataLine(")
    assert set(re.findall(r"\bs\.([a-z_]+)", draw)) <= set(status)
    assert set(re.findall(r"\bkey\.([a-z0-9_]+)", draw)) <= set(status["key"])
    assert set(re.findall(r"\bs\.ollama\.([a-z_]+)", draw)) <= set(status["ollama"])
    line = _braced(JS, "function dataLine(")
    assert set(re.findall(r"\bd\.([a-z_]+)", line)) <= set(status["players"])
    assert set(re.findall(r"\bf\.([a-z_]+)", line)) <= {"bytes", "file_date", "file", "url", "downloaded_at", "sha256"}
    assert status["players"]["estimate_megabytes"] == nflverse.ESTIMATE_MB


def test_the_forms_draw_the_same_card_from_tools_that_send_their_own_table_and_sentence(engine_output):
    for name in ("goal",):
        got = engine_output[name]
        assert "sentence" in got and "tables" in got, name
    direct = _braced(JS, "async function askDirect(")
    assert "out.sentence" in direct and "out.tables" in direct
    assert engine_output["goal"]["tables"][0]["rows"]
    assert engine_output["players_status"]["data"]["downloaded"] is True
