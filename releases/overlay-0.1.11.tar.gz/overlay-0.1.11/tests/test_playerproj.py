"""NFL player projections: what they use, how a chance is read, and what was kept out of sample.

Run on a synthetic league (`ask_fixtures.write_nfl`), never on the network. What is pinned, because
each is a way for a projection to look better than it is:

  * a projection never sees its own week (changing a later game cannot move an earlier projection);
  * the chance of clearing a line is the share of earlier misses that would clear it, from the
    player's band, and is not a normal curve with a guessed spread;
  * the settings and the miss distribution that ship were tuned on 2012-2017, chosen on 2018-2021,
    and the calibration table is made only from 2022 on;
  * a line of 300 means 300 or more, and a projection is never called an edge.
"""

import json
import math
import sys
from datetime import date
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ask_fixtures as fx  # noqa: E402

from overlay_engine import cli, nflverse, playerproj  # noqa: E402

TODAY = date(2023, 9, 27)
PARAMS = {"lam": 0.9, "rho": 0.6, "K": 2.0, "a": 0.0, "c": 0.0, "b": 0.0, "Kd": 20.0}


@pytest.fixture(scope="module")
def league(tmp_path_factory):
    folder = tmp_path_factory.mktemp("nfl")
    made = fx.write_nfl(folder)
    return folder, made


@pytest.fixture(scope="module")
def tuned(league):
    """Shipped-shape settings built from the fixture itself: the same functions that made the real file."""
    folder, _ = league
    games, rows = nflverse.read_games(folder), nflverse.read_weekly(folder)
    ctx = playerproj.context(games)
    out = {"stats": {}}
    for name, stat in playerproj.STATS.items():
        pairs, _ = playerproj.project([r for r in rows if playerproj.relevant(stat, r)], ctx, stat, PARAMS)
        out["stats"][name] = {"variant": "own level", "params": PARAMS, "found_miss": 1.0, "validated_miss": 1.0,
                              "spread": playerproj.build_spread(pairs, stat)}
    return out


# ------------------------------------------------------------ the chance comes from the misses

def test_a_chance_is_the_share_of_earlier_misses_that_would_clear_the_line_not_a_normal_curve():
    # A lopsided miss distribution: mostly small shortfalls, a few huge games. A normal curve with a
    # guessed spread cannot reproduce this; reading the share of misses does.
    ratios = sorted([0.8] * 70 + [1.0] * 20 + [2.5] * 10)
    spread = {"n": 100, "edges": [], "bands": [ratios], "counts": [100]}
    projection = 100.0
    assert playerproj.chance_over(spread, projection, 150.0) == pytest.approx(0.10)       # only the 2.5x games
    assert playerproj.chance_over(spread, projection, 90.0) == pytest.approx(0.30)        # the 1.0x and 2.5x games
    assert playerproj.chance_over(spread, projection, 50.0) == pytest.approx(1.0)
    assert playerproj.chance_over(spread, projection, 300.0) == pytest.approx(0.0)
    # A normal curve centred on the mean ratio (1.06) with the sample's own sd would say about 49% for "above 106":
    mean = sum(ratios) / len(ratios)
    assert playerproj.chance_over(spread, projection, mean * projection) != pytest.approx(0.5, abs=0.15)


def test_the_chance_falls_as_the_line_rises(tuned):
    spread = tuned["stats"]["passing yards"]["spread"]
    chances = [playerproj.chance_over(spread, 250.0, x + 0.5) for x in range(0, 700, 25)]
    assert chances == sorted(chances, reverse=True)
    assert chances[0] > 0.95 and chances[-1] < 0.02


def test_misses_are_kept_in_bands_because_a_star_and_a_part_timer_do_not_miss_alike(tuned):
    s = tuned["stats"]["passing yards"]["spread"]
    assert len(s["bands"]) == playerproj.BANDS and len(s["edges"]) == playerproj.BANDS - 1
    assert s["edges"] == sorted(s["edges"])
    assert sum(s["counts"]) == s["n"] > 0
    # Each band's ratios are stored sorted, as quantiles, with the full count kept beside them.
    for band in s["bands"]:
        assert band == sorted(band) and len(band) <= playerproj.QUANTILES


def test_a_line_of_300_means_300_or_more():
    assert playerproj.at_least(300) == 299.5
    assert playerproj.at_least(299.5) == 299.5
    assert playerproj.at_least(0.5) == 0.5


# ------------------------------------------------------------ nothing sees the future

def test_a_projection_never_sees_its_own_week(league):
    folder, _ = league
    games, rows = nflverse.read_games(folder), nflverse.read_weekly(folder)
    stat = playerproj.STATS["passing yards"]
    ctx = playerproj.context(games)
    mine = [r for r in rows if playerproj.relevant(stat, r)]
    before, _ = playerproj.project(mine, ctx, stat, PARAMS)
    # Change a LATE game's result wildly: no earlier projection may move.
    late = max(mine, key=lambda r: (r["season"], r["week"]))
    changed = [dict(r, passing_yards=r["passing_yards"] + 999) if r is late else r for r in mine]
    after, _ = playerproj.project(changed, ctx, stat, PARAMS)
    assert len(before) == len(after)
    for (r0, p0), (r1, p1) in zip(before, after):
        if r0 is not late:
            assert p0 == p1


def test_the_blocks_keep_the_tuning_seasons_apart():
    assert playerproj.BLOCKS == {"found": (2012, 2017), "validated": (2018, 2021), "final": (2022, 2099)}
    assert [playerproj.block(s) for s in (2012, 2017, 2018, 2021, 2022, 2026, 2011)] == [
        "found", "found", "validated", "validated", "final", "final", None]


def test_the_miss_distribution_is_built_only_from_found_and_validated_seasons(league):
    folder, _ = league
    games, rows = nflverse.read_games(folder), nflverse.read_weekly(folder)
    stat = playerproj.STATS["passing yards"]
    pairs, _ = playerproj.project([r for r in rows if playerproj.relevant(stat, r)], playerproj.context(games), stat, PARAMS)
    seasons = {r["season"] for r, _ in pairs}
    assert {2022, 2023} <= seasons                   # there are final-season projections...
    spread = playerproj.build_spread(pairs, stat)
    usable = [p for r, p in pairs if playerproj.block(r["season"]) in ("found", "validated") and p > 0]
    assert spread["n"] == len(usable)                # ...and none of them is in the distribution


def test_the_calibration_table_is_made_from_2022_on_and_states_what_it_checked(league, tuned):
    folder, _ = league
    games, rows = nflverse.read_games(folder), nflverse.read_weekly(folder)
    stat = playerproj.STATS["passing yards"]
    pairs, _ = playerproj.project([r for r in rows if playerproj.relevant(stat, r)], playerproj.context(games), stat, PARAMS)
    cal = playerproj.calibration(pairs, stat, tuned["stats"]["passing yards"]["spread"])
    assert cal["seasons"] == "2022 on" and cal["n"] > 100
    assert sum(b["n"] for b in cal["buckets"]) == cal["n"]
    for b in cal["buckets"]:
        assert 0 <= b["stated"] <= 1 and 0 <= b["happened"] <= 1
        assert b["gap"] == pytest.approx(b["happened"] - b["stated"], abs=1e-3)
    assert cal["mean_gap"] == pytest.approx(
        sum(abs(b["gap"]) * b["n"] for b in cal["buckets"]) / cal["n"], abs=2e-3)
    only_old = [(r, p) for r, p in pairs if r["season"] < 2022]
    assert playerproj.calibration(only_old, stat, tuned["stats"]["passing yards"]["spread"])["n"] == 0


# ------------------------------------------------------------ this week, and who

def test_this_week_is_the_first_game_not_yet_played_and_not_yet_past(league):
    folder, _ = league
    games = nflverse.read_games(folder)
    assert playerproj.this_week(games, TODAY) == (2023, 5)
    assert playerproj.resolve_week(games, "this", TODAY) == (2023, 5)
    with pytest.raises(playerproj.ProjectionError, match="no later week"):
        playerproj.resolve_week(games, "next", TODAY)
    with pytest.raises(playerproj.ProjectionError, match="no week 9"):
        playerproj.resolve_week(games, "9", TODAY)
    # With nothing left to play, it says so instead of inventing a week.
    with pytest.raises(playerproj.ProjectionError, match="no upcoming"):
        playerproj.this_week([g for g in games if g["result"] is not None], TODAY)


def test_the_answer_ranks_quarterbacks_by_their_chance_with_the_game_around_them(league, tuned):
    folder, made = league
    ans = playerproj.answer("passing yards", 299.5, "this", folder=folder, tuned=tuned, today=TODAY)
    d = ans.as_dict()
    assert d["stat"] == "passing yards" and d["line"] == 299.5 and d["threshold"] == 299.5
    assert d["meaning"] == "reach 300 yards or more"
    assert (d["season"], d["week"]) == (2023, 5)
    rows = d["rows"]
    assert rows and all(r["position"] == "QB" for r in rows)
    assert [r["chance"] for r in rows] == sorted((r["chance"] for r in rows), reverse=True)
    for r in rows:
        assert r["opponent"] and r["team"] != r["opponent"] and isinstance(r["home"], bool)
        assert r["total"] in (44.5, 45.5, 46.5)
        assert r["games"] >= 1 and 0 <= r["chance"] <= 1
        assert r["miss_sample"] > 0                    # the sample behind the chance is shown with it
    # The best-rated team QB projects highest in this league, and so ranks first.
    best_team = max(made["strength"], key=made["strength"].get)
    assert any(r["team"] == best_team for r in rows[:3])
    assert d["sample"]["seasons"] == "2012-2021" and d["sample"]["n"] == tuned["stats"]["passing yards"]["spread"]["n"]
    assert d["edge"] is False and "not an edge" in d["not_an_edge"]


def test_teams_that_have_already_played_this_week_are_left_out_and_it_says_so(league, tuned):
    folder, _ = league
    ans = playerproj.answer("passing yards", 299.5, "this", folder=folder, tuned=tuned, today=TODAY, limit=50)
    assert {r["team"] for r in ans.rows}.isdisjoint({"ARI", "BUF"})
    assert any("already played week 5" in n and "ARI" in n and "BUF" in n for n in ans.notes)


def test_without_a_line_it_ranks_by_projection(league, tuned):
    folder, _ = league
    ans = playerproj.answer("rushing yards", None, "this", folder=folder, tuned=tuned, today=TODAY, limit=50)
    assert all("chance" not in r for r in ans.rows)
    proj = [r["projection"] for r in ans.rows]
    assert proj == sorted(proj, reverse=True)
    assert ans.as_dict()["meaning"] is None


def test_other_positions_are_chosen_by_the_touches_the_team_has_given_them(league, tuned):
    folder, _ = league
    rec = playerproj.answer("receptions", 4.5, "this", folder=folder, tuned=tuned, today=TODAY, limit=50)
    assert {r["position"] for r in rec.rows} <= {"WR", "RB", "TE"} and rec.rows
    team = rec.rows[0]["team"]
    only = playerproj.answer("receptions", 4.5, "this", team=team, folder=folder, tuned=tuned, today=TODAY, limit=50)
    assert {r["team"] for r in only.rows} == {team}
    named = playerproj.answer("receptions", 4.5, "this", player="Receiver", folder=folder, tuned=tuned, today=TODAY, limit=50)
    assert all("Receiver" in r["player"] for r in named.rows) and named.rows


def test_every_stat_has_a_name_and_aliases_people_use():
    assert set(playerproj.STATS) == {"passing yards", "completions", "pass attempts", "passing TDs", "interceptions",
                                     "rushing yards", "carries", "receiving yards", "receptions"}
    for text, want in (("pass yards", "passing yards"), ("QB passing yards", "passing yards"), ("catches", "receptions"),
                       ("Rush yds", "rushing yards"), ("touchdown passes", "passing TDs"), ("picks", "interceptions")):
        assert playerproj.stat_for(text).name == want
    with pytest.raises(playerproj.ProjectionError, match="not a stat"):
        playerproj.stat_for("sacks")


# ------------------------------------------------------------ what ships

def test_the_shipped_settings_cover_every_stat_and_were_tuned_where_they_say():
    shipped = playerproj.load_tuned()
    assert shipped["blocks"] == {"found": [2012, 2017], "validated": [2018, 2021], "final": [2022, 2099]}
    assert set(shipped["stats"]) == set(playerproj.STATS)
    assert "stats_player_week_{season}.csv" in shipped["source"]["player_stats"]
    for name, s in shipped["stats"].items():
        assert set(s["params"]) >= {"lam", "rho", "K", "a", "c", "b"}
        assert s["spread"]["n"] > 1000 and len(s["spread"]["bands"]) == playerproj.BANDS
        assert s["spread"]["counts"] and sum(s["spread"]["counts"]) == s["spread"]["n"]
        cal = s["reference_calibration"]
        assert cal["seasons"] == "2022 on" and cal["n"] > 1000
        assert cal["mean_gap"] < 0.05, f"{name}: stated chances were off by {cal['mean_gap']:.1%} on average out of sample"
        # The shipped miss distribution is real ratios, sorted, around 1.
        for band in s["spread"]["bands"]:
            # (A few are below zero, a runner can lose yards, and the smallest-projection band holds the
            # part-timer who had a big day, so its top ratio is large.)
            assert band == sorted(band) and all(math.isfinite(x) for x in band) and len(band) <= playerproj.QUANTILES
        assert s["found_miss"] > 0 and s["validated_miss"] > 0 and s["final_miss"] > 0


def test_the_wheel_ships_the_settings_file():
    pyproject = (Path(__file__).resolve().parent.parent / "pyproject.toml").read_text()
    assert '"data/*.json"' in pyproject
    assert playerproj.DATA.exists()


# ------------------------------------------------------------ the command

@pytest.fixture
def home(monkeypatch, tmp_path, league):
    import shutil
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    shutil.copytree(league[0], tmp_path / "nfl")
    return tmp_path


def _run(argv, capsys):
    code = cli.main(argv)
    return code, capsys.readouterr()


def test_the_command_answers_in_json_with_the_data_it_used(home, capsys, monkeypatch, tuned):
    monkeypatch.setattr(playerproj, "load_tuned", lambda path=None: tuned)
    monkeypatch.setattr(playerproj, "date", type("D", (), {"today": staticmethod(lambda: TODAY)}), raising=False)
    code, out = _run(["players", "--stat", "passing yards", "--line", "299.5", "--week", "this", "--json"], capsys)
    got = json.loads(out.out)
    assert code == 0 and got["command"] == "players" and got["rows"] and got["data"]["downloaded"] is True
    assert got["tables"] and got["sentence"].startswith("Most likely to reach 300 yards or more in week 5")
    assert got["edge"] is False and "not an edge" in got["not_an_edge"]
    code, out = _run(["players", "--stat", "passing yards", "--line", "299.5"], capsys)
    assert code == 0 and "chance of reaching 300 yards or more" in out.out and "A projection is not an edge" in out.out


def test_the_status_says_where_the_files_came_from_and_how_old_they_are(home, capsys):
    code, out = _run(["players", "--status", "--json"], capsys)
    data = json.loads(out.out)["data"]
    assert code == 0 and data["downloaded"] is True
    assert {f["file"] for f in data["files"]} >= {"games.csv", "stats_player_week_2023.csv"}
    assert all(f["url"] and f["file_date"] and f["downloaded_at"] for f in data["files"])


def test_with_nothing_downloaded_the_command_refuses_and_downloads_nothing(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(nflverse, "urllib_get", lambda url: (_ for _ in ()).throw(AssertionError("downloaded")))
    code, out = _run(["players", "--stat", "passing yards", "--line", "300"], capsys)
    assert code == 2 and "players --update" in out.err and "about" in out.err
    code, out = _run(["players", "--status", "--json"], capsys)
    assert json.loads(out.out)["data"]["downloaded"] is False


def test_asking_for_nothing_says_which_stats_there_are(home, capsys):
    code, out = _run(["players"], capsys)
    assert code == 2 and "passing yards" in out.err
