"""What Ask's request looks like on the wire, as the real SDK sends it, captured by a mock transport.

No network and no real key: the SDK is the installed one, its HTTP layer is replaced by a transport that
records the request and answers with a canned response shaped like the Messages API's. So what these
pin is the request the API will actually receive (path, beta header, body fields, where the key rides)
and that the SDK's own response objects are read correctly.
"""

import json

import pytest

anthropic = pytest.importorskip("anthropic")
try:
    import httpx2 as httpx
except ImportError:                                        # the SDK before its move to httpx2
    httpx = pytest.importorskip("httpx")

from overlay_engine import ask, asktools, keystore, localai  # noqa: E402

KEY = "sk-ant-api03-" + "k" * 40 + "ABCD"


@pytest.fixture(autouse=True)
def nothing_real_is_asked(monkeypatch):
    monkeypatch.setattr(localai, "_http", lambda *a, **k: (_ for _ in ()).throw(OSError("no Ollama in tests")))
    monkeypatch.setattr(keystore.subprocess, "run", lambda *a, **k: (_ for _ in ()).throw(AssertionError("real Keychain")))


def message(content, stop="end_turn", model="claude-opus-5-5", **usage):
    return {"id": "msg_1", "type": "message", "role": "assistant", "model": model, "content": content, "stop_reason": stop,
            "stop_sequence": None, "usage": {"input_tokens": 1200, "output_tokens": 300, "cache_read_input_tokens": 50,
                                             "cache_creation_input_tokens": 0, **usage}}


class Wire:
    """A mock transport that records every request and answers from a script."""

    def __init__(self, *answers):
        self.answers = list(answers)
        self.requests = []

    def __call__(self, request):
        self.requests.append(request)
        out = self.answers.pop(0)
        return out(request) if callable(out) else httpx.Response(200, json=out)

    def client(self, monkeypatch=None):
        return ask.make_client(KEY, http_client=httpx.Client(transport=httpx.MockTransport(self)))

    def body(self, i=0):
        return json.loads(self.requests[i].content)


def run(wire, question="fair odds on -150 / +130", model="opus", history=()):
    return ask.claude_turn(question, list(history), wire.client(), model, asktools.Context(), "2026-10-09")


def test_the_request_the_api_receives_is_the_documented_one(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "https://evil.example")          # must not matter
    wire = Wire(message([{"type": "text", "text": "Hello."}]))
    turn = run(wire)
    request, body = wire.requests[0], wire.body()
    assert request.url.host == "api.anthropic.com" and request.url.path == "/v1/messages"
    assert request.headers["anthropic-beta"] == "server-side-fallback-2026-07-01"
    assert request.headers["x-api-key"] == KEY and "authorization" not in request.headers
    assert KEY not in str(request.url) and KEY not in request.content.decode()
    assert body["model"] == "claude-opus-5-5" and body["max_tokens"] == 16000
    assert body["thinking"] == {"type": "adaptive"} and body["output_config"] == {"effort": "high"}
    assert body["fallbacks"] == "default" and body["cache_control"] == {"type": "ephemeral"}
    assert "tool_choice" not in body and not {"temperature", "top_p", "top_k"} & set(body)
    assert [t["name"] for t in body["tools"]] == ["players", "goal", "board", "devig", "parlay", "kelly", "welcome", "performance"]
    assert all(t["input_schema"]["additionalProperties"] is False for t in body["tools"])
    assert body["system"].startswith("You are Bookbreaker's analyst") and "Today is 2026-10-09." in body["system"]
    assert body["messages"] == [{"role": "user", "content": "fair odds on -150 / +130"}]
    assert turn.text == "Hello." and turn.usage == {"input": 1200, "output": 300, "cache_read": 50, "cache_write": 0}


def test_the_cheaper_model_is_the_only_difference():
    wire = Wire(message([{"type": "text", "text": "ok"}], model="claude-sonnet-5-5"))
    run(wire, model="sonnet")
    assert wire.body()["model"] == "claude-sonnet-5-5" and wire.body()["thinking"] == {"type": "adaptive"}


def test_a_tool_loop_replays_the_thinking_and_the_tool_call_and_answers_all_calls_in_one_message():
    first = message([{"type": "thinking", "thinking": "", "signature": "sig-abc"},
                     {"type": "tool_use", "id": "toolu_1", "name": "devig", "input": {"odds": ["-150", "+130"]}},
                     {"type": "tool_use", "id": "toolu_2", "name": "parlay", "input": {"odds": ["-110", "-110"]}}], stop="tool_use")
    wire = Wire(first, message([{"type": "text", "text": "-150 is 58.2%."}]))
    turn = run(wire)
    second = wire.body(1)["messages"]
    assert [m["role"] for m in second] == ["user", "assistant", "user"]
    assert [b["type"] for b in second[1]["content"]] == ["thinking", "tool_use", "tool_use"]
    assert second[1]["content"][0]["signature"] == "sig-abc", "thinking goes back unchanged"
    assert [b["type"] for b in second[2]["content"]] == ["tool_result", "tool_result"]
    assert [b["tool_use_id"] for b in second[2]["content"]] == ["toolu_1", "toolu_2"]
    assert json.loads(second[2]["content"][0]["content"])["command"] == "devig"
    assert turn.usage["input"] == 2400 and [c["name"] for c in turn.calls] == ["devig", "parlay"]
    assert wire.body(0)["system"] == wire.body(1)["system"] and wire.body(0)["tools"] == wire.body(1)["tools"], "the cached prefix is stable"


def test_a_refusal_is_said_and_a_cut_off_answer_says_so():
    assert run(Wire(message([], stop="refusal"))).text == "Claude declined to answer that one."
    cut = run(Wire(message([{"type": "text", "text": "Partly"}], stop="max_tokens")))
    assert cut.text.startswith("Partly") and "cut off" in cut.text


@pytest.mark.parametrize("status,error,want", [
    (401, "authentication_error", "did not accept your API key"),
    (403, "permission_error", "not allowed to use that model"),
    (429, "rate_limit_error", "slow down"),
    (400, "invalid_request_error", "refused the request"),
    (500, "api_error", "problem on its side"),
])
def test_what_the_api_says_back_becomes_one_plain_sentence_with_no_key_in_it(status, error, want):
    def refuse(request):
        return httpx.Response(status, json={"type": "error", "error": {"type": error, "message": f"bad x-api-key {KEY}"}})
    wire = Wire(refuse)
    client = ask.make_client(KEY, http_client=httpx.Client(transport=httpx.MockTransport(wire)))
    client.max_retries = 0
    with pytest.raises(ask.AskError) as caught:
        ask.claude_turn("hi", [], client, "opus", asktools.Context(), "2026-10-09")
    assert want in str(caught.value) and KEY not in str(caught.value)


def test_a_failed_call_ends_in_a_built_in_answer_and_a_note_with_no_key_anywhere():
    def refuse(request):
        return httpx.Response(401, json={"type": "error", "error": {"type": "authentication_error", "message": KEY}})
    wire = Wire(refuse, refuse, refuse)
    out = ask.ask("fair odds on -150 / +130", key_getter=lambda: KEY, ctx=asktools.Context(),
                  client_factory=lambda k: _no_retry(ask.make_client(k, http_client=httpx.Client(transport=httpx.MockTransport(wire)))))
    assert out["mode"] == "builtin" and any("did not accept your API key" in n for n in out["notes"])
    assert KEY not in json.dumps(out)


def _no_retry(client):
    client.max_retries = 0
    return client
