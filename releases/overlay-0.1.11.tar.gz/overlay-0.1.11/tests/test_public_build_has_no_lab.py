"""The public app carries none of the research lab.

The lab (`backend/edgelab` on the edge-lab branch: its findings, its packed
snapshot, its Ask assistant) is not public. Matthew has not decided whether
its findings stay private, and a release is irreversible: an installed copy
keeps whatever it shipped with. So the public window may not send a `lab` verb,
the shell may not allow one, and neither the app bundle, the wheel nor the
source tarball may pick up `edgelab` code or data, even after a merge brings
the directory into this tree.
"""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JS = (ROOT / "ui" / "src" / "app.js").read_text()
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
RUST = "\n".join(p.read_text() for p in (ROOT / "ui" / "src-tauri" / "src").glob("*.rs"))
BUILD = (ROOT / "scripts" / "build_app.sh").read_text()
PYPROJECT = (ROOT / "pyproject.toml").read_text()
MANIFEST = (ROOT / "MANIFEST.in").read_text()


def test_the_window_sends_no_lab_verb():
    """Every engine command the window can build, by its first word."""
    verbs = {m.group(1) for m in re.finditer(r'^\s*[a-z-]+:\s*\(\)\s*=>\s*\[\s*"([a-z-]+)"', JS, re.M)}
    assert verbs, "no argv builders found: the extractor has drifted"
    assert "lab" not in verbs, "the public window builds a lab command"
    assert '"lab"' not in JS


def test_the_shell_allows_no_lab_verb():
    allowed = re.search(r'const ALLOWED: \[&str; \d+\] = \[([^\]]+)\]', RUST)
    assert allowed, "the allow-list moved"
    assert '"lab"' not in allowed.group(1)


def test_the_window_has_no_lab_pages():
    """The lab's places (Today's best bets, Research, My books' feed key, and the
    lab's own Ask bar) are edge-lab's. Their engine calls are gone above; their pages
    go too. The public window has its OWN Ask (a first place on the rail, tested in
    tests/test_ask_window.py): general machinery that answers from this app's own tools
    with the person's own key, not the lab's assistant."""
    for page in ("panel-moves", "panel-props", "panel-edges", "panel-books", "ask-bar"):
        assert f'id="{page}"' not in HTML, page
    for lab_word in ("edgelab", "moves-log", "lab.json", "Check now"):
        assert lab_word not in (JS + HTML), lab_word


def test_the_app_bundle_adds_no_lab_code_or_data():
    assert "edgelab" not in BUILD, "build_app.sh names the lab"
    assert re.search(r"--hidden-import overlay_engine\.cli", BUILD), "the build's import line moved"


def test_the_wheel_packages_only_the_engine():
    find = PYPROJECT[PYPROJECT.index("[tool.setuptools.packages.find]"):]
    find = find[:find.find("\n[", 1) if "\n[" in find[1:] else len(find)]
    include = re.search(r'^include = \[([^\]]*)\]', find, re.M)
    assert include, "pyproject's package list moved"
    assert include.group(1).replace(" ", "") == '"overlay_engine*"', include.group(1)
    assert "edgelab" not in PYPROJECT


def test_the_source_tarball_leaves_the_lab_out():
    """`recursive-include backend *.py` would sweep in backend/edgelab the day
    a merge brings it here. The prune says it never ships."""
    assert re.search(r"^prune backend/edgelab$", MANIFEST, re.M)



# ---------------------------------------------------------------- the lab's findings, as data

#: A hypothesis id from the research ledger: the letter H and three digits. It names a finding, and a finding in a public
#: build is the lab's work given away. This file only ever names the pattern, never an id, and it is scanned like the rest.
_LEDGER_ID = re.compile(r"\bH0\d\d\b")
_SHIPPED_TEXT = (".py", ".json", ".csv", ".js", ".html", ".css", ".sh", ".toml", ".md", ".in", ".rs")


def _shipped_files():
    """Everything the wheel, the sdist and the app bundle can pick up: the engine package, the window, the
    scripts and the tests (the sdist ships tests/), this file included, minus the recorded network payloads."""
    for base in ("backend/overlay_engine", "ui/src", "ui/src-tauri/src", "scripts", "tests", "data"):
        for path in (ROOT / base).rglob("*"):
            if path.is_file() and path.suffix in _SHIPPED_TEXT and "fixtures/live" not in str(path):
                yield path


def test_no_shipped_file_names_a_ledger_hypothesis():
    found = {str(p.relative_to(ROOT)): _LEDGER_ID.findall(p.read_text(errors="ignore")) for p in _shipped_files()}
    found = {k: v[:3] for k, v in found.items() if v}
    assert not found, f"a public build would carry the lab's hypothesis ids: {found}"


def test_the_engine_carries_no_edge_list_and_no_edges_module():
    """The lab's confirmed rules are its findings. They live on the edge-lab branch and in the lab's own Ask, never
    in the package, so no wheel, tarball or app bundle can carry one, and nothing here can read one."""
    package = ROOT / "backend" / "overlay_engine"
    assert not list((package / "data").glob("*edge*")), "an edge list is inside the package"
    assert not (package / "edges.py").exists(), "an edges module is back in the package"
    assert "edges" not in MANIFEST.replace("find_edges", ""), "MANIFEST.in packages an edge list"


def test_the_window_and_ask_name_no_confirmed_edge():
    """Ask recommends from live arbs and +EV prices only, and the window never shows or sends a confirmed-edge verb."""
    asktext = "".join(p.read_text() for p in (ROOT / "backend" / "overlay_engine").glob("ask*.py"))
    for text in (JS, HTML, asktext):
        assert not re.search(r"confirmed edges?|confirmed rules?|edge_backed", text, re.I)
    assert '"edges"' not in JS and '"edges"' not in RUST
