"""The record of live odds the app keeps on this Mac: every refresh is written once, readable by its owner only,
pruned after thirty days, cleared with the key's other data, and never carries the key."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ask_fixtures as fx  # noqa: E402

from overlay_engine import oddshistory  # noqa: E402

T0 = 1_800_000_000.0
LABEL = "Buffalo Bills at Kansas City Chiefs"


@pytest.fixture
def history(tmp_path):
    return tmp_path / "history"


def test_a_recorded_read_comes_back_as_the_engines_own_markets(history):
    fx.write_history(history, [fx.read("americanfootball_nfl", "nfl", T0, LABEL, "spreads", fx.spread_quotes(-2.5))])
    snap = oddshistory.snapshots(history)[0]
    market = oddshistory.to_markets(snap)[0]
    assert market.market_type == "spreads" and market.sport == "americanfootball_nfl"
    assert {q.book for q in market.quotes} == {"dk", "fd"}
    assert {q.outcome.line for q in market.quotes} == {-2.5, 2.5}


def test_the_odds_a_refresh_fetched_are_recorded_and_a_cached_read_is_not_recorded_twice(tmp_path, monkeypatch):
    import test_oddsapi as to
    from overlay_engine import oddsapi
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    cache = oddsapi.Cache(tmp_path / "oddsapi")
    clock = to.Clock()
    api = to.FakeApi()
    est = oddsapi.estimate(["nfl"], None, None, today=to.TODAY)
    oddsapi.refresh(est, to.KEY, clock=clock, cache=cache, fetcher=api)
    folder = tmp_path / "oddsapi" / "history"
    assert len(oddshistory.snapshots(folder)) == 1
    oddsapi.refresh(est, to.KEY, clock=clock, cache=cache, fetcher=api)       # inside the minute: served from the cache
    assert len(api.calls) == 1 and len(oddshistory.snapshots(folder)) == 1
    clock.now += 600
    oddsapi.refresh(est, to.KEY, clock=clock, cache=cache, fetcher=api)
    assert len(oddshistory.snapshots(folder)) == 2
    # The key is nowhere in what was written.
    assert all(to.KEY not in f.read_text() for f in folder.glob("*.jsonl"))
    # Clearing the key's data clears the history it built.
    assert cache.clear() > 0 and not list(folder.glob("*.jsonl"))


def test_reads_older_than_thirty_days_are_dropped(history):
    old = T0 - 40 * 86400
    fx.write_history(history, [fx.read("americanfootball_nfl", "nfl", old, LABEL, "spreads", fx.spread_quotes(-2.5)),
                               fx.read("americanfootball_nfl", "nfl", T0 - 86400, LABEL, "spreads", fx.spread_quotes(-2.5))])
    oddshistory._prune(history, T0)
    assert [f.stem for f in history.glob("*.jsonl")] == [oddshistory._day(T0 - 86400)]


def test_the_history_is_readable_by_its_owner_only(tmp_path):
    import os
    import test_oddsapi as to
    from overlay_engine import oddsapi
    cache = oddsapi.Cache(tmp_path / "oddsapi")
    oddsapi.refresh(oddsapi.estimate(["nfl"], None, None, today=to.TODAY), to.KEY, clock=to.Clock(), cache=cache, fetcher=to.FakeApi())
    folder = tmp_path / "oddsapi" / "history"
    assert os.stat(folder).st_mode & 0o777 == 0o700
    assert [os.stat(f).st_mode & 0o777 for f in folder.glob("*.jsonl")] == [0o600]
