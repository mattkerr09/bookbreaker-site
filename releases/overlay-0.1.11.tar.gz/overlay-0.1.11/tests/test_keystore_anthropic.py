"""The Anthropic key lives where the Odds API key does, under the same four rules.

Nothing here touches a Keychain: `security` is the recorded fake from test_keystore.py. The key is a
made-up value shaped like the real ones (sk-ant- and a long run of letters, digits, - and _).
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_keystore import FakeSecurity  # noqa: E402

from overlay_engine import keystore  # noqa: E402

KEY = "sk-ant-api03-" + "AbC_-0123456789" * 6
ODDS_KEY = "0123456789abcdef0123456789abcdef"


def test_it_has_its_own_keychain_item_and_the_odds_key_keeps_its_own():
    assert keystore.SERVICE_ANTHROPIC == "bookbreaker.anthropic" and keystore.SERVICE == "bookbreaker.oddsapi"
    fake = FakeSecurity()
    keystore.set_key(KEY, runner=fake, name="anthropic")
    _, stdin = fake.calls[0]
    assert "-s bookbreaker.anthropic " in stdin and "bookbreaker.oddsapi" not in stdin
    other = FakeSecurity()
    keystore.set_key(ODDS_KEY, runner=other)
    assert "-s bookbreaker.oddsapi " in other.calls[0][1]


def test_the_key_is_never_in_any_argument_and_reaches_security_on_standard_input():
    fake = FakeSecurity()
    keystore.set_key(KEY, runner=fake, name="anthropic")
    keystore.status(runner=fake, name="anthropic")
    keystore.get_key(runner=fake, name="anthropic")
    keystore.clear_key(runner=fake, name="anthropic")
    assert fake.calls
    assert fake.calls[0][0] == [keystore.SECURITY, "-i"] and KEY in fake.calls[0][1]
    for argv, _ in fake.calls:
        assert all(KEY not in part for part in argv), argv
    assert KEY not in fake.argv_text()


@pytest.mark.parametrize("bad", [
    "", "   ", "sk-ant-short", ODDS_KEY, "sk-ant-api03-has a space in the middle of it 123456789",
    KEY + "\nsecurity delete-generic-password -s something",          # a second command
    'sk-ant-api03-abc"def0123456789abcdef', "sk-ant-api03-abc;def0123456789abcdef",
    "https://api.anthropic.com/v1/messages?key=" + KEY, "Bearer " + KEY, "x" * 600,
])
def test_something_that_is_not_an_anthropic_key_is_refused_before_anything_runs(bad):
    fake = FakeSecurity()
    with pytest.raises(keystore.KeyStoreError) as caught:
        keystore.set_key(bad, runner=fake, name="anthropic")
    assert fake.calls == [], "a refused key must not reach the Keychain"
    assert bad.strip() == "" or bad.strip() not in str(caught.value), "the refusal repeats what was typed"
    assert "Anthropic" in str(caught.value) or "key" in str(caught.value)


def test_each_kind_of_key_is_refused_by_the_other_services_check():
    with pytest.raises(keystore.KeyStoreError):
        keystore.set_key(KEY, runner=FakeSecurity())                      # an Anthropic key is not an Odds API key (too long)
    with pytest.raises(keystore.KeyStoreError):
        keystore.set_key(ODDS_KEY, runner=FakeSecurity(), name="anthropic")


def test_status_shows_the_last_four_and_names_the_key_it_is_about():
    fake = FakeSecurity(stored=KEY)
    got = keystore.status(runner=fake, name="anthropic")
    assert got.is_set and got.last4 == KEY[-4:] and got.as_dict() == {"set": True, "last4": KEY[-4:]}
    assert got.describe() == f"An Anthropic API key is set (ends in {KEY[-4:]})."
    assert KEY not in got.describe() and KEY[:-4] not in got.describe()
    none = keystore.status(runner=FakeSecurity(), name="anthropic")
    assert not none.is_set and none.describe() == "No Anthropic API key is set."


def test_an_unknown_kind_of_key_is_a_sentence():
    with pytest.raises(keystore.KeyStoreError, match="not a key Bookbreaker keeps"):
        keystore.service("openai")


def test_a_save_the_keychain_did_not_keep_is_not_reported_as_saved():
    from types import SimpleNamespace

    class Forgetful(FakeSecurity):
        def __call__(self, argv, input=None, **kw):
            if argv[1] == "-i":
                self.calls.append((list(argv), input))
                return SimpleNamespace(returncode=0, stdout="", stderr="")
            return super().__call__(argv, input=input, **kw)
    with pytest.raises(keystore.KeyStoreError, match="did not keep"):
        keystore.set_key(KEY, runner=Forgetful(), name="anthropic")
