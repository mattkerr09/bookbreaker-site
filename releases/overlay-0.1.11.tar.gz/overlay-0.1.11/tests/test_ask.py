"""Ask: every number comes from a tool, and nothing here calls Anthropic, Ollama or nflverse.

The Claude client is a recorded fake that answers the way the Messages API does (blocks, a stop
reason, usage), so what these pin is what Bookbreaker sends and how it reads what comes back:

  * the request is the one the API documents for Claude Opus 5.5: adaptive thinking, an explicit
    effort, no forced tool choice, server-side fallbacks, and tools that all refuse unknown arguments;
  * thinking blocks go back unchanged inside a tool loop, and all tool results go in one message;
  * the client is pinned to Anthropic's own address with the person's own key, and the key is in no
    request body, no answer, no note and no error;
  * every figure in an answer is looked for in what the tools returned, and one that is not is flagged;
  * with no key and no model the two example questions still work.
"""

import json
import re
import socket
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ask_fixtures as fx  # noqa: E402

from overlay_engine import (ask, askground, askparse, asktables, asktools, cli, keystore, localai,  # noqa: E402
                            nflverse, playerproj)

KEY = "sk-ant-api03-" + "k" * 40 + "ABCD"
TODAY = "2026-10-09"


@pytest.fixture(autouse=True)
def nothing_real_is_asked(monkeypatch):
    """Not the Keychain, not Ollama (which may well be running on the machine these tests run on), not Anthropic.
    A test that wants one of them hands in its own fake."""
    def no_ollama(*a, **k):
        raise OSError("no Ollama in tests")

    def no_keychain(*a, **k):
        raise AssertionError("a test asked the real Keychain")
    monkeypatch.setattr(localai, "_http", no_ollama)
    monkeypatch.setattr(keystore.subprocess, "run", no_keychain)


# ------------------------------------------------------------ a recorded Messages API

def text(t):
    return SimpleNamespace(type="text", text=t)


def thinking(sig="sig-1"):
    return SimpleNamespace(type="thinking", thinking="", signature=sig)


def tool_use(name, args, ident="toolu_1"):
    return SimpleNamespace(type="tool_use", id=ident, name=name, input=args)


def usage(i=1000, o=200, cr=0, cw=0):
    return SimpleNamespace(input_tokens=i, output_tokens=o, cache_read_input_tokens=cr, cache_creation_input_tokens=cw)


def response(content, stop="end_turn", **u):
    return SimpleNamespace(content=content, stop_reason=stop, usage=usage(**u))


class FakeClaude:
    """`client.beta.messages.create`, scripted. Records every request it is sent."""

    def __init__(self, *responses):
        self.responses = list(responses)
        self.requests = []
        self.beta = SimpleNamespace(messages=SimpleNamespace(create=self._create))

    def _create(self, **kw):
        self.requests.append(json.loads(json.dumps(kw, default=lambda o: repr(o))) | {"_raw_messages": list(kw["messages"])})
        out = self.responses.pop(0)
        if isinstance(out, Exception):
            raise out
        return out


@pytest.fixture
def league(tmp_path):
    folder = tmp_path / "nfl"
    fx.write_nfl(folder)
    return folder


@pytest.fixture
def ctx(tmp_path, league, monkeypatch):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return asktools.Context(nfl=league, history=tmp_path / "history", db=str(tmp_path / "ledger.db"))


@pytest.fixture
def tuned(league, monkeypatch):
    games, rows = nflverse.read_games(league), nflverse.read_weekly(league)
    params = {"lam": 0.9, "rho": 0.6, "K": 2.0, "a": 0.0, "c": 0.0, "b": 0.0, "Kd": 20.0}
    out = {"stats": {}}
    for name, stat in playerproj.STATS.items():
        pairs, _ = playerproj.project([r for r in rows if playerproj.relevant(stat, r)], playerproj.context(games), stat, params)
        out["stats"][name] = {"variant": "own level", "params": params, "found_miss": 1.0, "validated_miss": 1.0,
                              "spread": playerproj.build_spread(pairs, stat)}
    monkeypatch.setattr(playerproj, "load_tuned", lambda path=None: out)
    import datetime
    monkeypatch.setattr(playerproj, "date", type("D", (datetime.date,), {"today": staticmethod(lambda: datetime.date(2023, 9, 27))}))
    return out


# ------------------------------------------------------------ the request is the documented one

def test_the_request_is_the_one_documented_for_claude_opus_5_5(ctx):
    fake = FakeClaude(response([text("Hello.")]))
    turn = ask.claude_turn("hi", [], fake, "opus", ctx, TODAY)
    kw = fake.requests[0]
    assert kw["model"] == "claude-opus-5-5"
    assert kw["thinking"] == {"type": "adaptive"}
    assert kw["output_config"] == {"effort": "high"}
    assert kw["betas"] == ["server-side-fallback-2026-07-01"] and kw["extra_body"] == {"fallbacks": "default"}
    assert kw["max_tokens"] == 16000 and kw["cache_control"] == {"type": "ephemeral"}
    assert "tool_choice" not in kw, "forced tool use is rejected by this model"
    for banned in ("temperature", "top_p", "top_k", "budget_tokens"):
        assert banned not in json.dumps(kw), banned
    assert turn.text == "Hello." and turn.model == "claude-opus-5-5"


def test_the_cheaper_model_is_sonnet_5_5_and_nothing_else_changes(ctx):
    fake = FakeClaude(response([text("ok")]))
    ask.claude_turn("hi", [], fake, "sonnet", ctx, TODAY)
    assert fake.requests[0]["model"] == "claude-sonnet-5-5"
    assert fake.requests[0]["thinking"] == {"type": "adaptive"} and "tool_choice" not in fake.requests[0]
    assert set(ask.MODELS) == {"opus", "sonnet"} and ask.DEFAULT_MODEL == "opus"


def test_every_tool_refuses_arguments_it_does_not_declare_and_says_what_it_requires():
    defs = asktools.tool_defs(live=True)
    names = [t["name"] for t in defs]
    assert names == ["players", "goal", "board", "devig", "parlay", "kelly", "welcome", "performance", "live_prices"]
    assert "live_prices" not in [t["name"] for t in asktools.tool_defs(live=False)]
    for t in defs:
        s = t["input_schema"]
        assert s["type"] == "object" and s["additionalProperties"] is False and t["description"]
        assert set(s["required"]) <= set(s["properties"])
    assert set(asktools.HANDLERS) == set(names)


def test_a_tool_called_wrongly_comes_back_as_an_error_the_model_can_correct(ctx):
    for name, args, want in (("devig", {"odds": ["-110", "-110"], "stake": 5}, "unknown argument"),
                             ("goal", {"bankroll": 10}, "missing target"),
                             ("nope", {}, "no tool named"), ("players", "not an object", "must be an object")):
        out, err = asktools.run_tool(ctx, name, args)
        assert err is True and want in out


def test_tool_inputs_go_back_unchanged_in_the_loop_and_every_result_goes_in_one_message(ctx):
    first = response([thinking(), text("Looking."), tool_use("devig", {"odds": ["-150", "+130"]}, "toolu_a"),
                      tool_use("parlay", {"odds": ["-110", "-110", "+150"]}, "toolu_b")], stop="tool_use")
    fake = FakeClaude(first, response([text("Done.")]))
    turn = ask.claude_turn("fair odds and a parlay", [], fake, "opus", ctx, TODAY)
    second = fake.requests[1]["_raw_messages"]
    assert second[-2]["role"] == "assistant" and second[-2]["content"] == first.content, "thinking blocks go back unchanged"
    results = second[-1]
    assert results["role"] == "user" and [r["tool_use_id"] for r in results["content"]] == ["toolu_a", "toolu_b"]
    assert all(r["type"] == "tool_result" and "is_error" not in r for r in results["content"])
    assert [c["name"] for c in turn.calls] == ["devig", "parlay"]
    assert json.loads(turn.calls[0]["result"])["command"] == "devig"


def test_a_tool_that_fails_is_reported_as_an_error_result_not_dropped(ctx):
    fake = FakeClaude(response([tool_use("goal", {"bankroll": 10, "target": 5})], stop="tool_use"), response([text("Cannot.")]))
    ask.claude_turn("goal", [], fake, "opus", ctx, TODAY)
    result = fake.requests[1]["_raw_messages"][-1]["content"][0]
    assert result["is_error"] is True and "more than the bankroll" in result["content"]


def test_after_a_fallback_the_blocks_the_new_model_cannot_continue_from_are_not_echoed(ctx):
    marker = SimpleNamespace(type="fallback")
    content = [thinking(), tool_use("devig", {"odds": [1.9, 1.9]}, "t0"), marker, text("kept"), tool_use("devig", {"odds": [1.8, 2.1]}, "t1")]
    echoed = ask._echo(content)
    assert [getattr(b, "type") for b in echoed] == ["fallback", "text", "tool_use"]
    assert ask._echo([thinking(), text("a")]) == [thinking(), text("a")] or len(ask._echo([thinking(), text("a")])) == 2


def test_a_conversation_so_far_goes_as_plain_turns_and_no_more_than_six(ctx):
    fake = FakeClaude(response([text("ok")]))
    history = [{"q": f"q{i}", "a": f"a{i}"} for i in range(9)]
    ask.claude_turn("now", history, fake, "opus", ctx, TODAY)
    msgs = fake.requests[0]["_raw_messages"]
    assert len(msgs) == 13 and msgs[-1] == {"role": "user", "content": "now"} and msgs[0]["content"] == "q3"


# ------------------------------------------------------------ what it costs

def test_the_cost_is_worked_out_from_the_responses_own_token_counts():
    u = {"input": 1_000_000, "output": 1_000_000, "cache_read": 1_000_000, "cache_write": 1_000_000}
    assert ask.cost(u, "claude-opus-5-5") == pytest.approx(4.0 + 20.0 + 0.20 + 5.0)
    assert ask.cost(u, "claude-sonnet-5-5") == pytest.approx(2.0 + 10.0 + 0.20 + 2.5)
    assert ask.cost({}, "claude-opus-5-5") is None and ask.cost(u, "some-other-model") is None


def test_a_claude_answer_shows_its_cost_and_the_others_show_none(ctx):
    fake = FakeClaude(response([text("Hi.")], i=2000, o=500, cr=10000))
    out = ask.ask("hello", ctx=ctx, key_getter=lambda: KEY, client_factory=lambda k: fake, today=TODAY)
    assert out["mode"] == "claude" and out["model"] == "claude-opus-5-5"
    c = out["cost"]
    assert c["usd"] == pytest.approx(round((2000 * 4 + 500 * 20 + 10000 * 0.2) / 1e6, 4))
    assert (c["input_tokens"], c["output_tokens"], c["cached_tokens"]) == (2000, 500, 10000) and c["prices_read"]
    assert out["left_this_mac"]["anthropic"] is True
    built = ask.ask("fair odds on -150 / +130", engine="builtin", ctx=ctx)
    assert built["cost"] is None and built["left_this_mac"] == {"anthropic": False, "what": "Nothing left this Mac."}


# ------------------------------------------------------------ the key

def test_the_key_is_in_no_request_no_answer_no_note_and_no_error(ctx):
    fake = FakeClaude(response([text("fine")]))
    out = ask.ask("hello", ctx=ctx, key_getter=lambda: KEY, client_factory=lambda k: fake, today=TODAY)
    assert KEY not in json.dumps(out) and KEY not in repr(fake.requests)
    boom = FakeClaude(RuntimeError(f"connection to https://api.anthropic.com failed with x-api-key {KEY}"))
    out = ask.ask("fair odds on -150 / +130", ctx=ctx, key_getter=lambda: KEY, client_factory=lambda k: boom)
    assert out["mode"] == "builtin" and KEY not in json.dumps(out)
    assert any("Claude could not answer" in n and "RuntimeError" in n for n in out["notes"])


def test_the_client_is_pinned_to_anthropics_address_with_the_persons_own_key(monkeypatch):
    pytest.importorskip("anthropic")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "https://evil.example")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-from-the-environment")
    monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "token-from-the-environment")
    client = ask.make_client(KEY)
    assert str(client.base_url).rstrip("/") == "https://api.anthropic.com"
    assert client.api_key == KEY and client.auth_token is None


def test_the_failures_a_person_can_hit_are_each_one_plain_sentence_that_never_quotes_the_exception():
    anthropic = pytest.importorskip("anthropic")
    httpx = pytest.importorskip("httpx")
    req = httpx.Request("POST", "https://api.anthropic.com/v1/messages")

    def resp(status):
        return httpx.Response(status, request=req)
    cases = [
        (anthropic.AuthenticationError(f"bad key {KEY}", response=resp(401), body=None), "did not accept your API key"),
        (anthropic.PermissionDeniedError(f"no {KEY}", response=resp(403), body=None), "not allowed to use that model"),
        (anthropic.RateLimitError(f"slow {KEY}", response=resp(429), body=None), "slow down"),
        (anthropic.BadRequestError(f"credit {KEY}", response=resp(400), body=None), "refused the request"),
        (anthropic.APIConnectionError(request=req), "could not reach Anthropic"),
        (anthropic.InternalServerError(f"boom {KEY}", response=resp(500), body=None), "problem on its side"),
    ]
    for exc, want in cases:
        said = ask._plain(exc)
        assert want in said and KEY not in said and said.endswith(".")


def test_a_claude_failure_is_a_note_and_the_question_is_still_answered(ctx):
    boom = FakeClaude(RuntimeError("down"))
    out = ask.ask("who is most likely to pass for 300 yards this week", ctx=ctx, key_getter=lambda: KEY,
                  client_factory=lambda k: boom, http=lambda *a, **k: (_ for _ in ()).throw(OSError("no ollama")))
    assert out["mode"] == "builtin" and any("Answering without Claude" in n for n in out["notes"])


# ------------------------------------------------------------ which engine answers

def _ollama(chat):
    def http(method, path, body=None, timeout=0):
        if path == "/api/tags":
            return {"models": [{"name": "plain:1b"}, {"name": "tools:7b"}]}
        if path == "/api/show":
            return {"capabilities": ["tools"] if body["model"] == "tools:7b" else ["completion"]}
        if path == "/api/chat":
            return chat(body)
        raise AssertionError(path)
    return http


def _call(name, args):
    return {"message": {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": args}}]}}


def _say(t):
    return {"message": {"role": "assistant", "content": t}}


def test_no_key_and_no_local_model_means_the_built_in_answerer(ctx):
    def down(*a, **k):
        raise OSError("refused")
    out = ask.ask("fair odds on -150 / +130", ctx=ctx, key_getter=lambda: None, http=down)
    assert out["mode"] == "builtin" and out["model"] is None and "Answered without an AI" in " ".join(out["notes"])


def test_only_a_local_model_that_can_use_tools_is_used_and_it_is_asked_on_this_mac_only():
    got = localai.status(_ollama(lambda b: None))
    assert got == {"running": True, "models": ["plain:1b", "tools:7b"], "tool_models": ["tools:7b"]}
    assert localai.BASE == "http://127.0.0.1:11434" and localai.HOST == "127.0.0.1"
    assert localai.status(lambda *a, **k: (_ for _ in ()).throw(OSError()))["running"] is False


def test_a_local_model_calls_the_tools_and_its_figures_are_checked_against_them(ctx):
    steps = iter([_call("devig", {"odds": ["-150", "+130"]}), _say("The fair chance on the -150 side is 58.2%.")])
    out = ask.ask("fair odds on -150 / +130", ctx=ctx, key_getter=lambda: None, http=_ollama(lambda b: next(steps)))
    assert out["mode"] == "ollama" and out["model"] == "tools:7b" and out["tables"] and out["ungrounded"] == []
    assert out["left_this_mac"]["anthropic"] is False and out["cost"] is None


def test_a_local_model_that_makes_up_a_figure_is_replaced_by_the_lookups_own_words(ctx):
    steps = iter([_call("devig", {"odds": ["-150", "+130"]}), _say("The fair chance is 71.3% and it pays 412.")])
    out = ask.ask("fair odds on -150 / +130", ctx=ctx, key_getter=lambda: None, http=_ollama(lambda b: next(steps)))
    assert out["mode"] == "builtin" and "71.3" not in out["answer"] and "58.2%" in out["answer"]
    assert any("stated figures no lookup returned" in n and "71.3%" in n for n in out["notes"])


def test_a_local_model_that_answers_without_looking_anything_up_is_not_shown(ctx):
    out = ask.ask("fair odds on -150 / +130", ctx=ctx, key_getter=lambda: None, http=_ollama(lambda b: _say("It is about 60%.")))
    assert out["mode"] == "builtin" and "60%" not in out["answer"]
    assert any("without looking anything up" in n for n in out["notes"])


def test_the_local_model_is_asked_with_the_same_rules_and_the_same_tools(ctx):
    seen = {}

    def chat(body):
        seen.update(body)
        return _say("done")
    ask.ask("hello there", ctx=ctx, key_getter=lambda: None, http=_ollama(chat))
    assert seen["model"] == "tools:7b" and seen["stream"] is False
    assert [t["function"]["name"] for t in seen["tools"]][:3] == ["players", "goal", "board"]
    assert "never place bets" in seen["messages"][0]["content"] and "Do no arithmetic of your own" in seen["messages"][0]["content"]


def test_forcing_an_engine_that_is_not_there_is_a_sentence_not_a_guess(ctx):
    with pytest.raises(ask.AskError, match="No Anthropic API key"):
        ask.ask("hi", ctx=ctx, engine="claude", key_getter=lambda: None)
    with pytest.raises(ask.AskError, match="Ollama is not running"):
        ask.ask("hi", ctx=ctx, engine="ollama", http=lambda *a, **k: (_ for _ in ()).throw(OSError()))
    with pytest.raises(ask.AskError, match="Type a question"):
        ask.ask("   ", ctx=ctx)


def test_a_key_without_the_package_says_so_plainly_and_still_answers(ctx, monkeypatch):
    monkeypatch.setattr(ask, "sdk_present", lambda: False)
    out = ask.ask("fair odds on -150 / +130", ctx=ctx, key_getter=lambda: KEY, http=lambda *a, **k: (_ for _ in ()).throw(OSError()))
    assert out["mode"] == "builtin" and ask.NO_SDK in out["notes"]
    assert "overlay[ask]" in ask.NO_SDK and "without the Anthropic software" in ask.NO_SDK
    with pytest.raises(ask.AskError, match="overlay\\[ask\\]"):
        ask.ask("hi", ctx=ctx, engine="claude", key_getter=lambda: KEY)


# ------------------------------------------------------------ every number comes from a tool

def test_a_figure_that_is_in_no_lookup_is_flagged_in_a_claude_answer(ctx):
    fake = FakeClaude(response([tool_use("devig", {"odds": ["-150", "+130"]})], stop="tool_use"),
                      response([text("The fair chance is 58.2%, and it will win by 14.5 points.")]))
    out = ask.ask("fair odds on -150 / +130", ctx=ctx, key_getter=lambda: KEY, client_factory=lambda k: fake, today=TODAY)
    assert out["mode"] == "claude" and out["ungrounded"] == ["14.5"]
    assert "Not from any lookup, so unchecked: 14.5" in out["answer"]
    assert any("14.5" in n for n in out["notes"])


def test_a_claude_answer_that_only_quotes_the_tools_is_not_flagged(ctx):
    fake = FakeClaude(response([tool_use("devig", {"odds": ["-150", "+130"]})], stop="tool_use"),
                      response([text("-150 is a 58.2% chance and +130 a 41.8% one; the margin is 3.4%, fair prices -139 and +139.")]))
    out = ask.ask("fair odds on -150 / +130", ctx=ctx, key_getter=lambda: KEY, client_factory=lambda k: fake, today=TODAY)
    assert out["ungrounded"] == [] and "unchecked" not in out["answer"]


def test_the_grounding_check_reads_numbers_the_way_people_write_them():
    tool = json.dumps({"consensus": 0.58226, "american": -150, "per_100": {"wins": 811.16}, "week": 6, "n": 6102,
                       "text": "chance 3.9% of the time"})
    ok = ["58%", "58.2%", "$811.16", "811", "-150", "6,102", "3.9%", "week 6", "the 1st of 3 tickets", "in 2026"]
    for phrase in ok:
        assert askground.ungrounded(f"It is {phrase} here.", [tool]) == [], phrase
    bad = {"It is 59.9% likely": ["59.9%"], "pays $912.50": ["$912.50"], "a total of 4,123 yards": ["4,123"], "by 7.5 points": ["7.5"]}
    for phrase, want in bad.items():
        assert askground.ungrounded(phrase, [tool]) == want, phrase
    assert askground.ungrounded("He needs 300 yards", ["who will pass for 300 yards"]) == [], "the person's own numbers are allowed"
    assert askground.ungrounded("Three legs, week 5, rank 2.", []) == [], "small whole numbers are language, not statistics"


# ------------------------------------------------------------ the built-in answerer

def test_the_two_example_questions_are_recognised_with_no_ai():
    plan = askparse.parse("who is most likely to pass for 300 yards this week")
    assert plan.calls == [("players", {"stat": "passing yards", "week": "this", "line": 300.0})]
    plan = askparse.parse("if i have 10 $1 bets, what are the best 10 parlays to do to potentially make $200+")
    assert plan.calls == [("goal", {"bankroll": 10.0, "target": 200.0, "tickets": 10})]
    plan = askparse.parse("Who's most likely to pass for 300 yards? next week")
    assert plan.calls[0][1]["week"] == "next"


@pytest.mark.parametrize("question,tools", [
    ("Best +EV bets right now", ["board"]), ("any arbs on tonight's games?", ["board"]),
    ("best bets", ["board"]), ("what should I bet tonight", ["board"]),
    ("Fair odds on -150 / +130", ["devig"]), ("what does a -110 -110 +150 parlay pay", ["parlay"]),
    ("how much should I bet at +150 if I win 45% with a $10,000 bankroll", ["kelly"]),
    ("welcome offers in New Jersey", ["welcome"]), ("how am I doing", ["performance"]),
    ("any middles?", ["board"]),
    ("who will catch 6 passes this week", ["players"]), ("who will rush for 100 yards", ["players"]),
    ("I have $100, how do I turn it into $1,000", ["goal"]), ("anything on kalshi", ["live_prices"]),
])
def test_the_common_shapes_go_to_the_right_tool(question, tools):
    plan = askparse.parse(question)
    assert plan is not None and [c[0] for c in plan.calls] == tools, question


def test_what_it_does_not_recognise_gets_a_list_of_what_it_can_do_not_a_guess(ctx):
    assert askparse.parse("who wins the super bowl in 2031") is None
    out = ask.ask("who wins the super bowl in 2031", engine="builtin", ctx=ctx)
    assert out["tools"] == [] and out["answer"] == askparse.HELP and "Anthropic key" in out["answer"]


def test_who_is_most_likely_to_pass_for_300_yards_is_answered_from_the_downloaded_files(ctx, tuned):
    out = ask.ask("who is most likely to pass for 300 yards this week", engine="builtin", ctx=ctx)
    assert out["mode"] == "builtin" and [t["name"] for t in out["tools"]] == ["players"]
    assert out["answer"].startswith("Most likely to reach 300 yards or more in week 5")
    table = out["tables"][0]
    assert table["columns"][:3] == ["Player", "Team", "Opponent"] and "Chance" in table["columns"] and table["rows"]
    assert "not recommendations" in out["answer"] and "21+. Gambling problem? Call 1-800-GAMBLER." in out["answer"]
    assert "not an edge" in table["note"]


def test_players_without_the_download_says_what_to_press_and_downloads_nothing(tmp_path, monkeypatch):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(nflverse, "urllib_get", lambda url: (_ for _ in ()).throw(AssertionError("downloaded")))
    c = asktools.Context(nfl=tmp_path / "nothing", history=tmp_path / "h")
    out = ask.ask("who is most likely to pass for 300 yards this week", engine="builtin", ctx=c)
    assert "Download NFL data" in out["answer"] and "nothing is downloaded until you do" in out["answer"]
    assert out["tables"] == []


def test_ten_one_dollar_bets_to_200_is_answered_with_the_numbers_the_planner_returns(ctx):
    out = ask.ask("if I have 10 $1 bets, what are the best 10 parlays to make $200?", engine="builtin", ctx=ctx)
    assert [t["name"] for t in out["tools"]] == ["goal"]
    assert "no edge by construction" in out["answer"] and "1.9%" in out["answer"] and "3.1%" in out["answer"]
    assert [t["title"] for t in out["tables"]][0].startswith("The 10 parlays") and len(out["tables"][0]["rows"]) == 10
    assert any(r[0] == "10 parlays" and r[1] == "1.94%" for r in out["tables"][1]["rows"])
    assert out["ungrounded"] == []


def test_the_built_in_answers_never_use_the_words_a_promise_would(ctx, tuned):
    import re
    questions = ["who is most likely to pass for 300 yards this week", "if I have 10 $1 bets, what are the best 10 parlays to make $200",
                 "best bets", "any arbs", "fair odds on -150 / +130", "welcome offers in NJ", "how am I doing",
                 "what does a -110 -110 +150 parlay pay", "best +EV bets right now"]
    for q in questions:
        text = ask.ask(q, engine="builtin", ctx=ctx)["answer"]
        for banned in (r"guarantee", r"risk-free", r"risk free", r"\block\b", r"either way", r"sure thing", r"free money"):
            assert not re.search(banned, text, re.I), (q, banned)


def test_nothing_in_a_builtin_answer_is_computed_here_each_figure_is_in_the_tools_result(ctx, tuned):
    for q in ("who is most likely to pass for 300 yards this week", "if I have 10 $1 bets, what are the best 10 parlays to make $200",
              "fair odds on -150 / +130", "what does a -110 -110 +150 parlay pay"):
        out = ask.ask(q, engine="builtin", ctx=ctx)
        results = [asktools.run_tool(ctx, t["name"], t["args"])[0] for t in out["tools"]]
        assert askground.ungrounded(out["answer"], [q, *results]) == [], q


def test_asking_never_reaches_a_network_with_no_ai(ctx, tuned, monkeypatch):
    def refuse(*a, **k):
        raise AssertionError("a socket was opened")
    monkeypatch.setattr(socket.socket, "connect", refuse)
    monkeypatch.setattr(socket, "create_connection", refuse)
    for q in ("who is most likely to pass for 300 yards this week", "best bets", "any arbs", "fair odds on -150 / +130",
              "if I have 10 $1 bets, what are the best 10 parlays to make $200", "how am I doing"):
        assert ask.ask(q, engine="builtin", ctx=ctx)["mode"] == "builtin"


# ------------------------------------------------------------ the board

def _arb_history(folder, now):
    quotes = [("dk", "Kansas City Chiefs", None, 2.10), ("dk", "Buffalo Bills", None, 1.80),
              ("fd", "Kansas City Chiefs", None, 1.80), ("fd", "Buffalo Bills", None, 2.05),
              ("pinnacle", "Kansas City Chiefs", None, 1.95), ("pinnacle", "Buffalo Bills", None, 1.95)]
    fx.write_history(folder, [fx.read("americanfootball_nfl", "nfl", now - 300, "Buffalo Bills at Kansas City Chiefs", "h2h", quotes)])


def test_best_bets_calls_the_board_and_recommends_from_live_arbs_and_ev_prices_only(ctx):
    now = 1_800_000_000.0
    ctx.now = now
    _arb_history(ctx.history, now)
    out = ask.ask("best bets", engine="builtin", ctx=ctx)
    assert [t["name"] for t in out["tools"]] == ["board"]
    assert "arb" in out["answer"].lower()


def test_the_board_tool_reads_only_what_is_on_this_mac_and_never_fetches(ctx, monkeypatch):
    from overlay_engine import oddsapi
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: (_ for _ in ()).throw(AssertionError("fetched")))
    empty = json.loads(asktools.run_tool(ctx, "board", {})[0])
    assert empty["has_odds"] is False and "never spends your credits" in empty["message"]
    now = 1_800_000_000.0
    ctx.now = now
    _arb_history(ctx.history, now)
    got = json.loads(asktools.run_tool(ctx, "board", {"kinds": ["arb"]})[0])
    assert got["has_odds"] and got["counts"]["arb"] == 1 and got["stale"] is False
    row = got["rows"][0]
    assert row["kind"] == "arb" and {leg["book_name"] for leg in row["legs"]} == {"DraftKings", "FanDuel"}
    assert "locked only if every bet is accepted" in got["note"]
    ctx.now = now + 9 * 3600
    assert json.loads(asktools.run_tool(ctx, "board", {"kinds": ["arb"]})[0])["stale"] is True


def test_the_goal_tool_builds_from_the_last_read_when_there_is_a_recent_one_and_says_which(ctx):
    now = 1_800_000_000.0
    ctx.now = now
    reads = []
    for g in range(12):
        quotes = [("dk", f"Home{g}", None, 1.95), ("dk", f"Away{g}", None, 1.95),
                  ("pinnacle", f"Home{g}", None, 1.95), ("pinnacle", f"Away{g}", None, 1.95)]
        reads.append(fx.read("americanfootball_nfl", "nfl", now - 600, f"Away{g} at Home{g}", "h2h", quotes, event=f"e{g}"))
    snap = reads[0]
    for r in reads[1:]:
        snap["events"].update(r["events"])
        snap["markets"] += r["markets"]
    fx.write_history(ctx.history, [snap])
    got = json.loads(asktools.run_tool(ctx, "goal", {"bankroll": 10, "target": 100, "tickets": 3})[0])
    assert got["legs_source"] == "board" and "12 games from the live sportsbook odds read 10 minutes ago" in got["legs_from"]
    assert got["parlays"] and all(leg["book"] == "DraftKings" for t in got["parlays"] for leg in t["legs"])
    assert got["ceiling_applies"] is True, "a retail price below its fair chance is not an edge"
    out = asktools.run_tool(ctx, "goal", {"bankroll": 10, "target": 100, "legs": "board"})
    ctx.history = ctx.history.parent / "none"
    assert asktools.run_tool(ctx, "goal", {"bankroll": 10, "target": 100, "legs": "board"})[1] is True


def test_live_prices_exist_only_while_the_switch_is_on_and_say_so_when_it_is_off(ctx):
    out, err = asktools.run_tool(ctx, "live_prices", {})
    assert err is True and "Live prices is off" in out


# ------------------------------------------------------------ the rules it answers by

def test_the_prompt_has_the_rules_of_the_house_and_recommends_from_live_arbs_and_ev_prices_only():
    prompt = ask.system_prompt(TODAY)
    for phrase in ("Every statistic", "A projection is not an edge", "live arbs and +EV prices only", "locked only if every bet is accepted",
                   "never place bets", "1-800-GAMBLER", "21+", "Do no arithmetic of your own", "call board (arbs and +EV bets)"):
        assert phrase in prompt, phrase
    assert "Today is 2026-10-09." in prompt
    assert ask.system_prompt(TODAY) == ask.system_prompt(TODAY), "byte-stable, so the cache can hold it"


def test_the_prompt_carries_no_finding_from_the_research_lab():
    prompt = ask.system_prompt(TODAY).lower()
    for leaked in ("lab.json", "edgelab", "confirmed edge", "ledger", "opening number", "hypothes", "next man up", "neutral-site",
                   "neutral site", "unders at the opener", "watch list"):
        assert leaked not in prompt, leaked
    assert not re.search(r"\bh0\d\d\b", prompt)


def test_the_compact_prompt_is_the_same_short_prompt():
    assert ask.system_prompt(TODAY, compact=True) == ask.system_prompt(TODAY)


# ------------------------------------------------------------ the command

def test_the_question_can_come_on_standard_input_with_the_conversation_so_far(ctx, tuned, monkeypatch, capsys):
    import io
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps({"question": "fair odds on -150 / +130", "history": [{"q": "hi", "a": "hello"}]})))
    assert cli.main(["ask", "--stdin", "--engine", "builtin", "--json"]) == 0
    got = json.loads(capsys.readouterr().out)
    assert got["command"] == "ask" and got["mode"] == "builtin" and got["tables"] and got["question"] == "fair odds on -150 / +130"
    assert set(got) >= {"answer", "mode", "model", "tools", "tables", "cost", "notes", "ungrounded", "left_this_mac"}


def test_the_status_says_who_would_answer_and_asks_nothing(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None, name="oddsapi": None)
    monkeypatch.setattr(localai, "status", lambda http=None: {"running": False, "models": [], "tool_models": []})
    assert cli.main(["ask", "--status", "--json"]) == 0
    got = json.loads(capsys.readouterr().out)
    assert got["answers_with"] == "the built-in answerer" and got["key"]["set"] is False and isinstance(got["sdk"], bool)
    assert got["models"]["opus"]["id"] == "claude-opus-5-5" and got["models"]["sonnet"]["id"] == "claude-sonnet-5-5"
    assert got["players"]["downloaded"] is False


def test_an_empty_question_is_a_sentence_and_exit_2(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    assert cli.main(["ask", "--engine", "builtin"]) == 2
    assert "Type a question first" in capsys.readouterr().err


def test_the_anthropic_key_has_its_own_command_and_its_own_keychain_item(monkeypatch, tmp_path, capsys):
    import io

    import test_keystore as tk
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    fake = tk.FakeSecurity()
    monkeypatch.setattr(keystore, "_available", lambda: None)
    monkeypatch.setattr(keystore.subprocess, "run", fake)
    stream = io.StringIO(KEY)
    stream.isatty = lambda: False
    monkeypatch.setattr(sys, "stdin", stream)
    assert cli.main(["key", "set", "--service", "anthropic", "--json"]) == 0
    saved = json.loads(capsys.readouterr().out)
    assert saved["service"] == "anthropic" and saved["last4"] == KEY[-4:] and KEY not in json.dumps(saved)
    argv, stdin = fake.calls[0]
    assert argv == [keystore.SECURITY, "-i"] and "-s bookbreaker.anthropic" in stdin and KEY in stdin
    assert all(KEY not in part for a, _ in fake.calls for part in a), "the key is never an argument"
    assert cli.main(["key", "status", "--service", "anthropic", "--json"]) == 0
    status = json.loads(capsys.readouterr().out)
    assert status == {"action": "status", "command": "key", "last4": KEY[-4:], "service": "anthropic", "set": True,
                      "text": f"An Anthropic API key is set (ends in {KEY[-4:]})."}
    assert cli.main(["key", "clear", "--service", "anthropic", "--json"]) == 0
    assert json.loads(capsys.readouterr().out)["removed"] is True
    assert fake.stored is None
