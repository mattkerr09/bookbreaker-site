"""Synthetic stand-ins for the files and feeds Ask reads. Nothing here is real data.

`write_nfl` writes a few seasons of nflverse-shaped CSVs (player weekly stats and games with
spread and total lines) with deterministic, team-dependent numbers, plus a manifest as
`nflverse.update` would have written it. `history_line` and `write_history` build recorded reads
of live odds in the shape `oddshistory` keeps them, so the board and Ask can be driven
without a key, a socket or a credit.
"""

from __future__ import annotations

import csv
import hashlib
import json
import random
from datetime import date, timedelta
from pathlib import Path

TEAMS = ["ARI", "BUF", "CIN", "DAL", "GB", "HOU", "KC", "LA"]
SEASONS = (2014, 2015, 2018, 2022, 2023)
WEEKS = 4


def _stat(rng, mean, sd, lo=0.0):
    return max(lo, round(rng.gauss(mean, sd)))


def write_nfl(folder: Path, today_week=5, played_early=("ARI", "BUF")) -> dict:
    """Write games.csv and stats_player_week_YYYY.csv for the fixture seasons.

    Season 2023 also has `today_week`: its games are unplayed (no result) except one between
    `played_early`, which has been played and has player rows, like a Thursday night game."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    rng = random.Random(7)
    strength = {t: rng.uniform(210, 300) for t in TEAMS}           # a team's QB's usual passing yards
    games, stats = [], {s: [] for s in SEASONS}
    players = {t: [(f"QB-{t}", f"{t[0]}. Quarterback {t}", "QB"), (f"RB-{t}", f"{t[0]}. Runner {t}", "RB"),
                   (f"WR1-{t}", f"{t[0]}. Receiver {t}", "WR"), (f"WR2-{t}", f"{t[0]}. Wideout {t}", "WR")]
               for t in TEAMS}
    for season in SEASONS:
        last = WEEKS + (1 if season == 2023 else 0)
        for week in range(1, last + 1):
            order = TEAMS[:]
            random.Random(season * 100 + week).shuffle(order)
            if season == 2023 and week == today_week:
                order = list(played_early) + [t for t in order if t not in played_early]
            for g in range(len(order) // 2):
                home, away = order[2 * g], order[2 * g + 1]
                line = round((strength[home] - strength[away]) / 14 * 2) / 2
                total = 44.5 + (g % 3)
                future = season == 2023 and week == today_week
                early = future and {home, away} == set(played_early)
                played = (not future) or early
                gid = f"{season}_{week:02d}_{away}_{home}"
                games.append({
                    "game_id": gid, "season": season, "game_type": "REG", "week": week,
                    "gameday": (date(season, 9, 1) + timedelta(days=7 * (week - 1))).isoformat(),
                    "away_team": away, "home_team": home,
                    "result": "" if not played else str(round(rng.gauss(line, 10))),
                    "spread_line": str(line), "total_line": str(total)})
                if not played:
                    continue
                for team, opp in ((home, away), (away, home)):
                    qb, rb, wr1, wr2 = players[team]
                    att = _stat(rng, 33, 4)
                    comp = min(att, _stat(rng, att * 0.64, 3))
                    rows = [(qb, dict(attempts=att, completions=comp, passing_yards=_stat(rng, strength[team], 55),
                                      passing_tds=_stat(rng, 1.6, 1), passing_interceptions=_stat(rng, 0.7, 0.8),
                                      carries=_stat(rng, 3, 2), rushing_yards=_stat(rng, 12, 8))),
                            (rb, dict(carries=_stat(rng, 15, 4), rushing_yards=_stat(rng, 64, 24),
                                      receptions=_stat(rng, 2.5, 1.5), receiving_yards=_stat(rng, 18, 12))),
                            (wr1, dict(receptions=_stat(rng, 6, 2), receiving_yards=_stat(rng, 75, 28))),
                            (wr2, dict(receptions=_stat(rng, 4, 2), receiving_yards=_stat(rng, 48, 22)))]
                    for (pid, name, pos), vals in rows:
                        stats[season].append(dict(
                            player_id=pid, player_display_name=name, position=pos, season=season, week=week,
                            season_type="REG", team=team, opponent_team=opp, **vals))
    cols = ["player_id", "player_display_name", "position", "season", "week", "season_type", "team", "opponent_team",
            "completions", "attempts", "passing_yards", "passing_tds", "passing_interceptions", "carries",
            "rushing_yards", "receptions", "receiving_yards"]
    manifest = {"files": {}, "updated_at": 1_800_000_000.0, "current_season": 2023, "first_season": SEASONS[0]}
    for season, rows in stats.items():
        path = folder / f"stats_player_week_{season}.csv"
        with path.open("w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=cols, restval="0")
            w.writeheader()
            w.writerows(rows)
        _note(manifest, path, f"https://example.test/stats_player_week_{season}.csv")
    gpath = folder / "games.csv"
    with gpath.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(games[0]))
        w.writeheader()
        w.writerows(games)
    _note(manifest, gpath, "https://example.test/games.csv")
    (folder / "manifest.json").write_text(json.dumps(manifest))
    return {"games": games, "stats": stats, "strength": strength}


def _note(manifest: dict, path: Path, url: str) -> None:
    data = path.read_bytes()
    manifest["files"][path.name] = {"url": url, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                                    "file_date": "Fri, 06 Oct 2023 12:00:00 GMT", "etag": None,
                                    "downloaded_at": 1_800_000_000.0}


# ------------------------------------------------------------ recorded reads of live odds

def read(league_key, alias, fetched_at, label, market_type, quotes, event="ev1", starts=None):
    """One recorded league read with one market. quotes: [(book, outcome, line, decimal)]."""
    return {"v": 1, "league": league_key, "alias": alias, "fetched_at": fetched_at,
            "events": {event: {"label": label, "starts": starts or fetched_at + 86400}},
            "markets": [{"event": event, "type": market_type, "starts": starts or fetched_at + 86400,
                         "q": [[b, n, line, d, fetched_at - 5] for b, n, line, d in quotes]}]}


def write_history(folder: Path, reads: list) -> None:
    from overlay_engine import oddshistory
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    by_day = {}
    for r in reads:
        by_day.setdefault(oddshistory._day(r["fetched_at"]), []).append(r)
    for day, rs in by_day.items():
        (folder / f"{day}.jsonl").write_text("\n".join(json.dumps(r) for r in rs) + "\n")


def spread_quotes(chiefs_line, books=("dk", "fd"), price=1.909, home="Kansas City Chiefs", away="Buffalo Bills"):
    out = []
    for b in books:
        out += [(b, home, chiefs_line, price), (b, away, -chiefs_line, price)]
    return out
