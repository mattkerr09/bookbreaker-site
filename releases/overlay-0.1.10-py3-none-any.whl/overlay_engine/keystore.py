"""Where the Odds API key lives: the Mac's login Keychain, and nowhere else.

Bookbreaker can read live sportsbook odds with a key the person gets, free,
from The Odds API. That key is a credential: whoever holds it spends the
person's monthly allowance. So it has exactly one home, the macOS login
Keychain, and four rules about how it gets there and back.

**Never on a command line.** `ps` shows every process's arguments to every
other process of the same user for as long as it runs. The key is read from
standard input (or typed at a hidden prompt), and it reaches `/usr/bin/security`
the same way: `security -i` takes its commands on standard input, so the
`add-generic-password ... -w <key>` line travels down a pipe and the only
arguments any process ever has are `security -i`. The obvious spelling,
`security add-generic-password -w <key>`, would put the key in `security`'s
argv for the instant it ran.

**Never printed.** Not by `key set`, not by `key status`, not in `--json`, not
in an error. Status says whether a key is set and the last four characters,
which is how a person recognises which key it is. Every message here is built
without the key in scope, so none can leak it by formatting.

**Checked before it is kept.** `security -i` exits 0 whether or not the
command inside it worked, so a save is believed only after the Keychain is read
back and returns the same key. A key that fails the shape check (letters,
digits, `-` and `_`, 16 to 128 of them) is refused before anything is run, which
also means nothing a person pastes can carry a newline or a quote into the
`security -i` command line.

**Clearing is final and quiet.** `clear` deletes the item. A key that was never
set is not an error: the person asked for it to be gone and it is.

The runner is a parameter so every one of these is tested against a recorded
fake without touching a Keychain.
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from dataclasses import dataclass

SECURITY = "/usr/bin/security"
SERVICE = "bookbreaker.oddsapi"
ACCOUNT = "default"

#: `security` exits 44 when the item is not in the Keychain.
NOT_FOUND = 44

#: What The Odds API's keys look like (32 hex characters today). Wider than that
#: on purpose, so a change on their side does not lock a person out, but narrow
#: enough that nothing pasted by accident (a URL, a sentence, a second line)
#: passes for a key.
_SHAPE = re.compile(r"^[A-Za-z0-9_-]{16,128}$")

#: A save or a read that hangs (a locked Keychain waiting on a dialog nobody
#: can see) is ended rather than left holding the window.
TIMEOUT = 20


class KeyStoreError(ValueError):
    """The key could not be stored, read or cleared. The message is always a
    sentence a person can act on, and never contains the key."""


@dataclass(frozen=True)
class Status:
    """Whether a key is set. `last4` is the only part of it ever shown."""

    is_set: bool
    last4: str = ""

    def as_dict(self) -> dict:
        return {"set": self.is_set, "last4": self.last4 or None}

    def describe(self) -> str:
        if not self.is_set:
            return "No Odds API key is set."
        return f"An Odds API key is set (ends in {self.last4})."


def clean(text) -> str:
    """The key as typed, trimmed, or a refusal that does not repeat it."""
    key = (text or "").strip()
    if not key:
        raise KeyStoreError(
            "No key was given. Paste the key from the email The Odds API sent you.")
    if not _SHAPE.match(key):
        raise KeyStoreError(
            "That does not look like an Odds API key. It is one run of letters and "
            "numbers, about 32 characters, with no spaces. Copy it again from the "
            "email The Odds API sent you.")
    return key


def mask(key: str) -> str:
    """The last four characters, which is all that is ever shown."""
    return key[-4:] if key else ""


def _available() -> None:
    if sys.platform != "darwin" or not os.path.exists(SECURITY):
        raise KeyStoreError(
            "Bookbreaker keeps your Odds API key in the Mac's Keychain, and this "
            "computer does not have one.")


def _run(runner, argv, stdin=None):
    """One `security` call. A timeout or a missing binary is a sentence."""
    call = subprocess.run if runner is None else runner
    if runner is None:
        _available()
    try:
        return call(argv, input=stdin, capture_output=True, text=True,
                    timeout=TIMEOUT)
    except subprocess.TimeoutExpired:
        raise KeyStoreError(
            "The Mac's Keychain did not answer. If it asked for your password, "
            "answer it, then try again.") from None
    except OSError:
        raise KeyStoreError(
            "Bookbreaker could not reach the Mac's Keychain.") from None


def get_key(runner=None):
    """The stored key, or None when there is none.

    The key comes back on standard output of a child process and goes straight
    to the caller. Nothing here logs, prints or formats it.
    """
    done = _run(runner, [SECURITY, "find-generic-password",
                         "-s", SERVICE, "-a", ACCOUNT, "-w"])
    if done.returncode == NOT_FOUND:
        return None
    if done.returncode != 0:
        raise KeyStoreError(
            "The Mac's Keychain would not give Bookbreaker the key "
            f"(security exited with {done.returncode}). If it asked for your "
            "password, answer it and try again.")
    return (done.stdout or "").strip() or None


def set_key(text, runner=None) -> Status:
    """Validate, store, and read back. Returns the status, never the key."""
    key = clean(text)
    # The command goes down the pipe, not onto a command line. `-U` updates an
    # existing item instead of failing on it, so saving twice replaces.
    line = (f'add-generic-password -s {SERVICE} -a {ACCOUNT} -w "{key}" -U\n')
    _run(runner, [SECURITY, "-i"], stdin=line)
    # `security -i` exits 0 whatever happened inside it. Believe the Keychain.
    if get_key(runner) != key:
        raise KeyStoreError(
            "The Mac's Keychain did not keep the key. Unlock the Keychain "
            "(open Keychain Access, then the login keychain) and try again.")
    return Status(True, mask(key))


def clear_key(runner=None) -> bool:
    """Delete the key. True when one was removed, False when none was set."""
    done = _run(runner, [SECURITY, "delete-generic-password",
                         "-s", SERVICE, "-a", ACCOUNT])
    if done.returncode == NOT_FOUND:
        return False
    if done.returncode != 0:
        raise KeyStoreError(
            "The Mac's Keychain would not remove the key "
            f"(security exited with {done.returncode}).")
    return True


def status(runner=None) -> Status:
    key = get_key(runner)
    return Status(True, mask(key)) if key else Status(False)
