"""Live sportsbook odds from The Odds API, read with the person's own key.

OddsJam's core is a board of live prices across every US book. Bookbreaker gets
there at no cost to us: each person signs up for a free key of their own
(Starter: 500 credits a month), saves it in their Mac's Keychain
(`keystore.py`), and presses a button. Their terms forbid reselling the data as
a data product; a person looking at their own key's data in their own app is
not that, and this module is built so it stays not that:

**The key and the odds go to one host.** `api.the-odds-api.com`, over https,
and nowhere else. The fetcher builds that URL and refuses any other, follows no
redirect (a redirect would carry the key in the query string to whoever the
answer named), and turns every failure into a sentence that has neither the URL
nor the key in it. The odds are cached on this Mac for sixty seconds and never
sent anywhere.

**Credits are counted out loud, before and after.** The rule, from the API's
own usage page (https://the-odds-api.com/liveapi/guides/v4/, "Usage Quota
Costs", read 2026-10-09):

    The usage quota cost is 1 per region per market.
    cost = [number of markets specified] x [number of regions specified]

and a call is made per league, so one refresh is leagues x regions x markets.
`estimate()` says that number before anything is fetched, and the number shown
is exactly that product: it is an upper bound, because the same page says
"Responses with empty data do not count towards the usage quota" and counts
unique markets *in the response*, so a league with no games listed, or a market
no book posted, costs less. What a refresh actually cost is read back off the
`x-requests-last` header, and what is left off `x-requests-remaining`.

**A double click never spends twice.** Each league's answer is kept on disk
with the time it was fetched and reused for 60 seconds, keyed by league,
regions and markets (never by the key).

**Prices are dated by the book, not by us.** `restfeed` stamps each quote with
the feed's own `last_update`; `feed.stamp` then classifies it, so an undated
price reads as `assumed` and decays like one. Games already under way are left
off: an in-play price is stale by the time it is read.

**Only books you can bet at are shown as bets.** A Europe region is asked for so
Pinnacle can price the fair odds. A US bettor cannot place a bet at Pinnacle,
so its price, and every other reference price (Europe, offshore books, the US
exchanges whose fees these prices do not include), prices the market and never
appears as a leg. `board.scan(bettable=...)` enforces it.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from dataclasses import replace as _replace
from datetime import date, datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, build_opener

from .feed import FeedError, stamp
from .ledger import home
from .models import Book, BookTier
from .restfeed import Quota, RestProvider

HOST = "api.the-odds-api.com"
BASE = f"https://{HOST}"

#: A fetched answer is reused for this long. A double click, the window opening
#: while a refresh is out, a script run twice: none of them may spend a credit.
CACHE_SECONDS = 60.0

#: The sentence the cost rests on, kept verbatim so a test can hold it.
COST_RULE = ("The usage quota cost is 1 per region per market. "
             "cost = [number of markets specified] x [number of regions specified]")
COST_RULE_SOURCE = "https://the-odds-api.com/liveapi/guides/v4/ (GET odds, Usage Quota Costs)"

SIGNUP = "the-odds-api.com"

NO_KEY = ("No Odds API key is set. Get a free key at the-odds-api.com, then save it "
          "in Bookbreaker's Odds source page.")
CREDITS_GONE = ("Your Odds API credits for this month are used up. They come back when "
                "your monthly allowance resets, or you can add a paid plan on "
                "the-odds-api.com.")


class OddsApiError(FeedError):
    """The Odds API said no, or could not be reached. The message is a sentence
    for a beginner and never contains the key or the request's address."""

    def __init__(self, message: str, reason: str = "error", status: int | None = None):
        super().__init__(message)
        self.reason = reason
        self.status = status


# ------------------------------------------------------------ what can be asked

@dataclass(frozen=True)
class League:
    alias: str
    label: str
    key: str            # the Odds API's sport key
    opens: tuple        # (month, day) odds usually start being listed
    closes: tuple       # (month, day) the last game is usually played

    def in_season(self, day: date) -> bool:
        here = (day.month, day.day)
        if self.opens <= self.closes:
            return self.opens <= here <= self.closes
        return here >= self.opens or here <= self.closes


#: The six leagues. Keys are the Odds API's (the sports list at
#: https://the-odds-api.com/sports-odds-data/sports-apis.html, read 2026-10-09).
#: The windows are the usual span of each league's listed games, rounded
#: outward a little; they only decide what is ticked by default. A league
#: outside its window can still be asked for by name, and a league with no
#: games listed costs nothing.
LEAGUES: tuple = (
    League("nfl", "NFL", "americanfootball_nfl", (9, 1), (2, 15)),
    League("ncaaf", "College football", "americanfootball_ncaaf", (8, 25), (1, 25)),
    League("nba", "NBA", "basketball_nba", (10, 15), (6, 25)),
    League("ncaab", "College basketball", "basketball_ncaab", (11, 1), (4, 10)),
    League("mlb", "MLB", "baseball_mlb", (3, 20), (11, 5)),
    League("nhl", "NHL", "icehockey_nhl", (10, 1), (6, 25)),
)
_BY_ALIAS = {lg.alias: lg for lg in LEAGUES}
_BY_KEY = {lg.key: lg for lg in LEAGUES}

#: Region keys, as the Odds API names them, and what each is in plain words.
REGIONS: dict = {
    "us": "US sportsbooks (DraftKings, FanDuel, BetMGM and more)",
    "us2": "More US sportsbooks (Hard Rock Bet, theScore Bet, betPARX and more)",
    "eu": "Europe, which includes Pinnacle, the sharpest book (prices fair odds only)",
    "us_ex": "US exchanges (Kalshi, Polymarket and more; prices fair odds only)",
}
DEFAULT_REGIONS = ("us", "eu")

MARKETS: dict = {"h2h": "Moneyline", "spreads": "Spread", "totals": "Total"}
DEFAULT_MARKETS = ("h2h",)

_PLAIN_MARKET = {"h2h": "moneyline", "spreads": "spread", "totals": "total"}


def league_aliases() -> list:
    return [lg.alias for lg in LEAGUES]


def in_season(today: date | None = None) -> list:
    today = today or date.today()
    return [lg for lg in LEAGUES if lg.in_season(today)]


def _pick(values, allowed: dict, what: str, default):
    if not values:
        return tuple(default)
    out = []
    for v in values:
        v = str(v).strip().lower()
        if v not in allowed:
            raise OddsApiError(
                f"{v!r} is not a {what} Bookbreaker knows. Choose from "
                f"{', '.join(allowed)}.", reason="bad_choice")
        if v not in out:
            out.append(v)
    return tuple(out)


@dataclass(frozen=True)
class Estimate:
    """What one refresh will cost, worked out before anything is fetched."""

    leagues: tuple
    regions: tuple
    markets: tuple

    @property
    def per_league(self) -> int:
        # THE RULE: markets x regions, for one league's request.
        return len(self.markets) * len(self.regions)

    @property
    def total(self) -> int:
        return self.per_league * len(self.leagues)

    def sentence(self) -> str:
        n = self.total
        bets = ", ".join(_PLAIN_MARKET.get(m, m) for m in self.markets)
        return (
            f"This refresh uses up to {n} of your Odds API credit{'s' if n != 1 else ''}: "
            f"{len(self.leagues)} league{'s' if len(self.leagues) != 1 else ''} "
            f"({', '.join(lg.label for lg in self.leagues)}) x "
            f"{len(self.regions)} region{'s' if len(self.regions) != 1 else ''} "
            f"({', '.join(self.regions)}) x "
            f"{len(self.markets)} bet type{'s' if len(self.markets) != 1 else ''} "
            f"({bets}), at 1 credit each. A league with no games listed costs nothing.")

    def as_dict(self) -> dict:
        return {
            "credits": self.total, "per_league": self.per_league,
            "leagues": len(self.leagues), "regions": len(self.regions),
            "markets": len(self.markets), "text": self.sentence(),
            "rule": COST_RULE, "rule_source": COST_RULE_SOURCE,
            "by_league": {lg.alias: self.per_league for lg in self.leagues},
        }


def estimate(sports=None, regions=None, markets=None, today: date | None = None) -> Estimate:
    """Validate the choices and price them. No network, no key.

    Nothing chosen means the defaults: the leagues in season, regions us and eu
    (so Pinnacle can price fair odds), moneylines only.
    """
    if sports:
        leagues = tuple(_pick(sports, _BY_ALIAS, "league", ()))
        leagues = tuple(_BY_ALIAS[a] for a in leagues)
    else:
        leagues = tuple(in_season(today))
        if not leagues:
            raise OddsApiError("No league is in season right now. Choose one by name.",
                               reason="bad_choice")
    return Estimate(leagues, _pick(regions, REGIONS, "region", DEFAULT_REGIONS),
                    _pick(markets, MARKETS, "bet type", DEFAULT_MARKETS))


def choices(est: Estimate, today: date | None = None) -> dict:
    """Everything the window needs to draw its pickers, from the engine."""
    today = today or date.today()
    return {
        "leagues": [{"alias": lg.alias, "label": lg.label, "key": lg.key,
                     "in_season": lg.in_season(today), "picked": lg in est.leagues}
                    for lg in LEAGUES],
        "regions": [{"key": k, "label": v, "picked": k in est.regions}
                    for k, v in REGIONS.items()],
        "markets": [{"key": k, "label": v, "picked": k in est.markets}
                    for k, v in MARKETS.items()],
    }


# ------------------------------------------------------------ the books

#: The Odds API's key -> the key this engine already uses for the same book, so
#: the engine's tiers, latency priors and the window's tiles all apply.
ENGINE_KEY = {
    "draftkings": "dk", "fanduel": "fd", "betmgm": "mgm",
    "williamhill_us": "caesars", "betfair_ex_eu": "betfair",
}

#: Books a person in a regulated US state can bet at, by engine key. Everything
#: else in a response is a reference price. Chosen conservatively: an
#: offshore book, a social or sweepstakes app, or a book this table has not
#: heard of is left out of the bets rather than guessed in, because every row on
#: the board is an instruction to stake money.
BETTABLE: dict = {
    "dk": "DraftKings", "fd": "FanDuel", "mgm": "BetMGM", "caesars": "Caesars",
    "betrivers": "BetRivers", "fanatics": "Fanatics", "ballybet": "Bally Bet",
    "betparx": "betPARX", "espnbet": "theScore Bet",
    "hardrockbet": "Hard Rock Bet (IN)", "hardrockbet_az": "Hard Rock Bet (AZ)",
    "hardrockbet_fl": "Hard Rock Bet (FL)", "hardrockbet_oh": "Hard Rock Bet (OH)",
}


def engine_book(key: str) -> str:
    return ENGINE_KEY.get(key, key)


def books_table() -> dict:
    """The engine's books plus the ones this feed adds, for `board.scan`."""
    from .cli import DEFAULT_BOOKS

    table = dict(DEFAULT_BOOKS)
    for key, name in BETTABLE.items():
        table.setdefault(key, Book(key, name, BookTier.RETAIL))
    for key, name in (("polymarket", "Polymarket"), ("prophetx", "ProphetX")):
        table.setdefault(key, Book(key, name, BookTier.EXCHANGE, limits_winners=False))
    return table


# ------------------------------------------------------------ the disk

@dataclass
class Entry:
    payload: list
    headers: dict
    fetched_at: float


class Cache:
    """One file per (league, regions, markets), holding the last answer and when
    it was fetched. Never holds the key; readable by its owner only."""

    def __init__(self, folder=None, ttl: float = CACHE_SECONDS):
        self.folder = Path(folder) if folder else home() / "oddsapi"
        self.ttl = ttl

    def _file(self, sport, regions, markets) -> Path:
        tag = f"{sport}|{','.join(sorted(regions))}|{','.join(sorted(markets))}"
        return self.folder / "cache" / (hashlib.sha1(tag.encode()).hexdigest()[:20] + ".json")

    def get(self, sport, regions, markets, now: float):
        """The answer fetched less than `ttl` seconds ago, or None."""
        try:
            data = json.loads(self._file(sport, regions, markets).read_text())
            fetched = float(data["fetched_at"])
            payload, headers = data["payload"], dict(data["headers"])
        except (OSError, ValueError, KeyError, TypeError):
            return None
        if not isinstance(payload, list) or not (0.0 <= now - fetched < self.ttl):
            return None
        return Entry(payload, headers, fetched)

    def put(self, sport, regions, markets, payload, headers, fetched_at: float) -> None:
        try:
            path = self._file(sport, regions, markets)
            path.parent.mkdir(parents=True, exist_ok=True)
            for d in (self.folder, path.parent):
                os.chmod(d, 0o700)
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps({
                "fetched_at": fetched_at, "sport": sport,
                "regions": sorted(regions), "markets": sorted(markets),
                "headers": {k: v for k, v in headers.items()
                            if str(k).lower().startswith("x-requests-")},
                "payload": payload,
            }))
            os.chmod(tmp, 0o600)
            os.replace(tmp, path)
            self._prune(fetched_at)
        except OSError:
            pass            # a cache that cannot be written only costs a refetch

    def _prune(self, now: float) -> None:
        """An hour is far past the minute anything here is reused for. Judged by
        the fetch time written inside each file, on the same clock that wrote
        it, never by the file's own timestamp."""
        for old in (self.folder / "cache").glob("*.json"):
            try:
                if now - float(json.loads(old.read_text())["fetched_at"]) > 3600:
                    old.unlink()
            except (OSError, ValueError, KeyError, TypeError):
                try:
                    old.unlink()
                except OSError:
                    pass

    def clear(self) -> int:
        n = 0
        for f in list((self.folder / "cache").glob("*")) + [self.folder / "credits.json"]:
            try:
                f.unlink()
                n += 1
            except OSError:
                pass
        return n

    # The last credits reading, kept so the window can say how many are left
    # without spending one to find out.
    def remember(self, quota: Quota, at: float) -> None:
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            os.chmod(self.folder, 0o700)
            path = self.folder / "credits.json"
            path.write_text(json.dumps({"remaining": quota.remaining, "used": quota.used,
                                        "last": quota.last, "at": at}))
            os.chmod(path, 0o600)
        except OSError:
            pass

    def recall(self):
        try:
            data = json.loads((self.folder / "credits.json").read_text())
            return {"remaining": data.get("remaining"), "used": data.get("used"),
                    "last": data.get("last"), "at": data.get("at")}
        except (OSError, ValueError, AttributeError):
            return None


# ------------------------------------------------------------ the network

def explain(status: int | None, body: str, headers: dict) -> OddsApiError:
    """An HTTP failure in plain words.

    The body's `error_code` is the API's own name for what went wrong
    (https://the-odds-api.com/liveapi/guides/v4/api-error-codes.html); the
    status is the fallback; `x-requests-remaining: 0` settles an ambiguous
    refusal as the allowance being spent.
    """
    code = ""
    try:
        data = json.loads(body)
        code = str(data.get("error_code") or "") if isinstance(data, dict) else ""
    except (ValueError, TypeError):
        pass
    lower = {str(k).lower(): v for k, v in (headers or {}).items()}
    spent_up = str(lower.get("x-requests-remaining", "")).strip() == "0"

    if code == "OUT_OF_USAGE_CREDITS" or (status in (401, 429) and spent_up):
        return OddsApiError(CREDITS_GONE, "out_of_credits", status)
    if code == "DEACTIVATED_KEY":
        return OddsApiError(
            "That Odds API key has been turned off, usually because the plan was "
            "cancelled. Sign in at the-odds-api.com to start a new one.", "bad_key", status)
    if code in ("INVALID_KEY", "MISSING_KEY") or status == 401:
        return OddsApiError(
            "The Odds API did not accept your key. Check it was copied whole from "
            "the email The Odds API sent you, then save it again.", "bad_key", status)
    if code == "EXCEEDED_FREQ_LIMIT" or status == 429:
        return OddsApiError(
            "The Odds API asked Bookbreaker to slow down. Wait a few seconds and "
            "press the button again.", "slow_down", status)
    if status is not None and status >= 500:
        return OddsApiError(
            "The Odds API had a problem on its side. Try again in a minute.",
            "their_problem", status)
    return OddsApiError(
        "The Odds API did not understand that request"
        + (f" ({code})" if code else "") + ". Check for a newer Bookbreaker.",
        "rejected", status)


class NoRedirect(HTTPRedirectHandler):
    """The key is in the query string, so a redirect would hand it to whoever
    the answer named. The 3xx surfaces as an HTTPError instead, unfollowed."""

    def redirect_request(self, *args, **kwargs):
        return None


def odds_api_fetcher(timeout: float = 15.0, opener=None):
    """`(path, params) -> (payload, headers)`, the only code that sends the key.

    `opener` is a seam for tests; the default follows no redirects.
    """
    open_ = opener if opener is not None else build_opener(NoRedirect).open

    def _fetch(path: str, params: dict):
        url = f"{BASE}{path}?{urlencode(params)}"
        if not url.startswith(f"https://{HOST}/"):
            raise OddsApiError("Bookbreaker only talks to The Odds API.", "refused")
        try:
            with open_(url, timeout=timeout) as response:
                body = response.read().decode("utf-8", "replace")
                headers = dict(response.headers.items())
        except HTTPError as exc:
            try:
                text = exc.read().decode("utf-8", "replace")
            except Exception:                            # noqa: BLE001
                text = ""
            raise explain(exc.code, text, dict(exc.headers.items() if exc.headers else [])) from None
        except (URLError, OSError, ValueError):
            raise OddsApiError(
                "Bookbreaker could not reach The Odds API. Check your internet "
                "connection and try again.", "offline") from None
        try:
            return json.loads(body), headers
        except ValueError:
            raise OddsApiError(
                "The Odds API sent an answer Bookbreaker could not read. Try again "
                "in a minute.", "unreadable") from None

    return _fetch


# ------------------------------------------------------------ one refresh

@dataclass
class LeagueRead:
    league: League
    events: int
    from_cache: bool
    fetched_at: float
    credits: int | None         # what this call cost; 0 when it came off the disk


@dataclass
class Refresh:
    estimate: Estimate
    markets: list = field(default_factory=list)
    event_info: dict = field(default_factory=dict)      # event id -> label, league, start
    book_names: dict = field(default_factory=dict)      # engine key -> display name
    reads: list = field(default_factory=list)
    quota: Quota = field(default_factory=Quota)
    errors: list = field(default_factory=list)
    dated: int = 0
    undated: int = 0
    skewed: int = 0
    under_way: int = 0
    now: float = 0.0

    @property
    def spent(self) -> int:
        return sum(r.credits or 0 for r in self.reads)

    @property
    def spent_known(self) -> bool:
        return all(r.credits is not None for r in self.reads if not r.from_cache)

    @property
    def oldest(self) -> float:
        return min((r.fetched_at for r in self.reads), default=self.now)

    @property
    def all_cached(self) -> bool:
        return bool(self.reads) and all(r.from_cache for r in self.reads)

    def sharp_prices(self) -> bool:
        from .cli import DEFAULT_BOOKS
        return any(DEFAULT_BOOKS.get(q.book) is not None
                   and DEFAULT_BOOKS[q.book].tier in (BookTier.SHARP, BookTier.EXCHANGE)
                   for m in self.markets for q in m.quotes)


class _Tap:
    """A fetcher that remembers what it returned, so the caller can cache it."""

    def __init__(self, inner):
        self.inner = inner
        self.payload = None
        self.headers: dict = {}

    def __call__(self, path, params):
        self.payload, self.headers = self.inner(path, params)
        return self.payload, self.headers


def _label(event: dict) -> str:
    home_t, away_t = event.get("home_team"), event.get("away_team")
    return f"{away_t} at {home_t}" if home_t and away_t else str(event.get("id", ""))


def refresh(est: Estimate, key: str, *, clock=None, cache: Cache | None = None,
            fetcher=None) -> Refresh:
    """Fetch every league (or reuse the last minute's answer), through
    `RestProvider`, and return stamped markets.

    A failure after at least one league was read ends the refresh and keeps what
    was read, with the reason in `errors`; a failure before any raises, so a
    person is never shown an empty board that was really an error.
    """
    clock = clock if clock is not None else time.time
    cache = cache if cache is not None else Cache()
    fetcher = fetcher if fetcher is not None else odds_api_fetcher()
    out = Refresh(estimate=est)

    for league in est.leagues:
        entry = cache.get(league.key, est.regions, est.markets, clock())
        if entry is not None:
            tap = _Tap(lambda path, params, e=entry: (e.payload, e.headers))
            got_at = entry.fetched_at
        else:
            tap = _Tap(fetcher)
            got_at = clock()
        provider = RestProvider(
            fetcher=tap, api_key=key, regions=",".join(est.regions),
            market_keys=tuple(est.markets), sport_keys=(league.key,),
            key="oddsapi", received_at=got_at)
        try:
            mapped = provider.fetch(league.key)
        except OddsApiError as exc:
            if not out.reads:
                raise
            out.errors.append(str(exc))
            break
        except FeedError:
            problem = OddsApiError(
                f"The Odds API sent {league.label} odds Bookbreaker could not read, "
                "so none are shown for it.", "unreadable")
            if not out.reads:
                raise problem from None
            out.errors.append(str(problem))
            break
        except Exception as exc:                         # noqa: BLE001
            # Anything else came out of a call that had the key in its
            # parameters. Its message is not shown: it may hold the address,
            # and the address holds the key. Only its type is.
            problem = OddsApiError(
                f"Reading {league.label} odds failed unexpectedly "
                f"({type(exc).__name__}). Try again in a minute.", "unexpected")
            if not out.reads:
                raise problem from None
            out.errors.append(str(problem))
            break

        payload = tap.payload
        if entry is None:
            cache.put(league.key, est.regions, est.markets, payload, tap.headers, got_at)
            cache.remember(provider.quota, got_at)
        out.quota = provider.quota
        spent = 0 if entry is not None else provider.quota.last

        for event in payload:
            for book in event.get("bookmakers") or []:
                raw = str(book.get("key") or "")
                out.book_names.setdefault(engine_book(raw), str(book.get("title") or raw))
            out.event_info[str(event.get("id"))] = {
                "label": _label(event), "league": league.label,
                "starts": event.get("commence_time")}

        for market in mapped:
            for quote in market.quotes:
                quote.book = engine_book(quote.book)
        snap = stamp(mapped, got_at, "oddsapi")
        out.dated += snap.dated
        out.undated += snap.undated
        out.skewed += snap.skewed
        out.reads.append(LeagueRead(league, len(payload), entry is not None, got_at, spent))
        out.markets.extend(snap.markets)

    out.now = clock()
    # A game under way is left off: its price is stale by the time it is read,
    # and the second leg of an arb is the one that is not there.
    began = {m.event_id for m in out.markets if m.starts_at is not None and m.starts_at <= out.now}
    out.under_way = len(began)
    out.markets = [m for m in out.markets if m.event_id not in began]
    for name, known in BETTABLE.items():
        out.book_names[name] = known
    return out


def split_by_line(markets) -> list:
    """Spreads and totals as one market per line.

    The API sends every line a book posts for a game inside one market, so a
    spread market holds Chiefs -3.5, Chiefs -2.5 and Bills +3.5 side by side.
    The engine compares one pair of sides at a time, and a market holding
    several lines either finds nothing (no book prices every outcome) or, worse,
    would set the two sides of different bets against each other. Grouping by
    the size of the line gives each its own two-sided market: Over 47.5 meets
    Under 47.5, Chiefs -3.5 meets Bills +3.5, and a half-point difference is a
    middle (found separately, on the unsplit market) and never an arb.
    """
    out = []
    for market in markets:
        if market.market_type not in ("spreads", "totals"):
            out.append(market)
            continue
        groups: dict = {}
        for quote in market.quotes:
            line = quote.outcome.line
            groups.setdefault(None if line is None else abs(line), []).append(quote)
        out.extend(_replace(market, quotes=quotes) for quotes in groups.values())
    return out


# ------------------------------------------------------------ what the board says

def source_line(r: Refresh) -> str:
    when = datetime.fromtimestamp(r.oldest, timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    base = (f"The Odds API, regions {', '.join(r.estimate.regions)}, "
            f"{', '.join(r.estimate.markets)}, prices fetched {when}")
    if r.all_cached:
        base += f" (reused for {int(CACHE_SECONDS)} seconds, so no credits were spent)"
    return base


def credits_line(r: Refresh) -> str:
    if r.all_cached:
        used = "No credits were spent: these prices were fetched in the last minute."
    elif r.spent_known:
        used = f"This refresh used {r.spent} credit{'s' if r.spent != 1 else ''}."
    else:
        used = "The Odds API did not say what this refresh cost."
    if r.quota.known:
        left = f" {r.quota.remaining} left this month ({r.quota.used} used so far)."
    else:
        left = " The Odds API did not say how many credits are left."
    return used + left


def summary(r: Refresh) -> dict:
    """The `odds` block of the board's JSON: everything the window prints about
    where the prices came from and what they cost."""
    reference = sorted({r.book_names.get(q.book, q.book)
                        for m in r.markets for q in m.quotes if q.book not in BETTABLE})
    notes = []
    if r.markets and not r.sharp_prices():
        notes.append("No Pinnacle or exchange prices were in this read, so +EV bets "
                     "could not be priced. Add the Europe region to price them.")
    if r.under_way:
        notes.append(f"{r.under_way} game{'s' if r.under_way != 1 else ''} already under way "
                     "left off: a price changes too fast in play to bet from here.")
    return {
        "fetched_at": r.oldest, "cached": r.all_cached, "cache_seconds": CACHE_SECONDS,
        "regions": list(r.estimate.regions), "markets": list(r.estimate.markets),
        "leagues": [{"alias": x.league.alias, "label": x.league.label, "events": x.events,
                     "from_cache": x.from_cache, "credits": x.credits} for x in r.reads],
        "cost": {"estimate": r.estimate.total, "spent": r.spent if r.spent_known else None,
                 "remaining": r.quota.remaining, "used": r.quota.used,
                 "last": r.quota.last, "text": credits_line(r)},
        "dated": r.dated, "undated": r.undated, "skewed": r.skewed,
        "under_way": r.under_way, "errors": list(r.errors), "notes": notes,
        "reference_only": reference,
        "bet_at": sorted(BETTABLE[b] for b in {q.book for m in r.markets for q in m.quotes}
                         if b in BETTABLE),
    }


def describe_rows(rows, r: Refresh) -> list:
    """The board's rows with names a person can read in place of ids."""
    out = []
    for row in rows:
        d = row.as_dict()
        info = r.event_info.get(row.event, {})
        d["event_id"] = row.event
        d["event"] = info.get("label", row.event)
        d["league"] = info.get("league", "")
        d["starts_at"] = info.get("starts")
        for leg in d["legs"]:
            leg["book_name"] = r.book_names.get(leg["book"], leg["book"])
        out.append(d)
    return out
