"""Which books exist, where they are legal, and what each one costs you.

Three facts about a book decide everything downstream, and only one of them is
usually recorded anywhere:

  **Tier** — is this price evidence, or a product being sold? Sets fair-value
  weight (`fair.py`).
  **Limits winners** — does beating this book cost you the account? Sets
  whether anti-limiting shaping applies at all (`heat.py`).
  **Jurisdiction** — can this user legally hold the account? Sets whether the
  edge is reachable.

A screen that surfaces an arbitrage between two books the user cannot both
hold is not an opportunity, it is noise with a number attached. So state
filtering is not a settings page, it is the first filter in the pipeline.

## On the state data

State-by-state legality moves constantly — markets launch, operators withdraw,
and any table like this is a snapshot with a shelf life. So every entry carries
its source and the date it was read, `coverage_gaps()` names the jurisdictions
this file knows it does not cover, and `stale_days()` exists so the UI can say
"checked 60 days ago" rather than implying currency it does not have.

**This is a starting point for the user's own check, not legal advice.** The
book's own site is authoritative about whether it will accept them.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from dataclasses import replace as _dc_replace
from typing import NamedTuple

from .models import Book, BookTier

# When the operator/state table below was read, and from where. Any consumer
# showing this data should show this date next to it.
AS_OF = "2026-09-24"
# Re-checked book by book on 2026-09-24 against operator sites and filings, state
# regulators' licensee lists and dated trade press (STATE_SOURCES below). The
# 2026-08-17 source, Action Network's sportsbooks-by-state grid, was itself stale:
# its 2026-09-07 version still listed BetFred, WynnBET, Sporttrade, Betr and Betly,
# and left out BetMGM NY and most of BetRivers' states, so re-reading it would
# not have fixed this table.
SOURCE = "operator sites and filings, state regulators, dated trade press (STATE_SOURCES)"
AS_OF_EPOCH = 1_790_208_000.0  # 2026-09-24T00:00:00Z, checked against
# datetime rather than typed from memory — the first value here was a year out
# and made a fresh table report itself as 365 days stale.


@dataclass(frozen=True)
class Venue:
    """A book, its economics, and where it operates."""

    key: str
    name: str
    tier: BookTier
    states: frozenset[str] = frozenset()
    commission: float = 0.0
    limits_winners: bool = True
    nationwide: bool = False
    note: str = ""
    verified: bool = True
    """False when this entry was added from a weaker source than SOURCE and
    has not been confirmed. Unverified venues are excluded from `for_state`
    unless explicitly asked for — an unverified 'legal here' is the one error
    in this table that could cost a user more than a missed bet."""
    exited: str = ""
    """When and why a book stopped taking bets everywhere, e.g. "2025-07-31".
    Set, a venue with no states is a recorded fact; unset, it is an orphan
    that check_catalog.py refuses. The key is kept either way so bets already
    in someone's ledger at that book still resolve."""
    excluded: frozenset[str] = frozenset()
    """States a nationwide venue may not serve, each by a court order or a
    regulator, with its source in EXCLUSION_SOURCES. Added 2026-10-07: Kalshi
    was listed as nationwide a month after a Michigan court ordered it to block
    Michigan residents from its sports contracts. Never typed here: it is the
    "restricted" rows of STATE_STATUS, so a state is hidden or shown by editing
    one table."""

    def to_book(self) -> Book:
        return Book(
            key=self.key,
            name=self.name,
            tier=self.tier,
            commission=self.commission,
            limits_winners=self.limits_winners,
        )

    def available_in(self, state: str) -> bool:
        st = state.upper()
        return (self.nationwide and st not in self.excluded) or st in self.states

    @property
    def jurisdiction_unknown(self) -> bool:
        """True when this venue's availability was never established.

        Distinct from "not available here". Pinnacle carries no state list
        because we do not know its, not because we know it is empty — and those are different answers to give a user. `for_state`
        hides them by default and `include_unverified=True` surfaces them as
        "check this yourself", which is the only honest thing to say.
        """
        return not self.verified and not self.states and not self.nationwide


def _s(*states: str) -> frozenset[str]:
    return frozenset(states)


# Retail operators, by the states each was listed in on AS_OF. These are the
# books where the edge is — and where the account risk is.
_RETAIL = [
    # NH and OR are exclusive lottery contracts rather than open markets, which
    # is why DraftKings is the whole list in both.
    ("dk", "DraftKings", _s("AZ", "AR", "CO", "CT", "DC", "IA", "IL", "IN", "KS",
                            "KY", "LA", "MA", "MD", "ME", "MI", "MO", "NC", "NH",
                            "NJ", "NY", "OH", "OR", "PA", "TN", "VA", "VT", "WV",
                            "WY")),
    ("fd", "FanDuel", _s("AZ", "AR", "CO", "CT", "DC", "IA", "IL", "IN", "KS",
                         "KY", "LA", "MA", "MD", "MI", "MO", "NC", "NJ", "NY",
                         "OH", "PA", "TN", "VA", "VT", "WV", "WY")),
    # NV needs one in-person registration visit before the app takes bets.
    ("mgm", "BetMGM", _s("AZ", "CO", "DC", "IA", "IL", "IN", "KS", "KY", "LA",
                         "MA", "MD", "MI", "MO", "NC", "NJ", "NV", "NY", "OH",
                         "PA", "TN", "VA", "WV", "WY")),
    ("caesars", "Caesars", _s("AZ", "CO", "DC", "IA", "IL", "IN", "KS", "KY",
                              "LA", "MA", "MD", "ME", "MI", "MO", "NC", "NJ",
                              "NV", "NY", "OH", "PA", "TN", "VA", "WV", "WY")),
    ("bet365", "bet365", _s("AZ", "CO", "DC", "IA", "IL", "IN", "KS", "KY",
                            "LA", "MD", "MI", "MO", "NC", "NJ", "OH", "PA", "TN",
                            "VA", "WV")),
    ("fanatics", "Fanatics", _s("AZ", "CO", "CT", "DC", "IA", "IL", "IN", "KS",
                                "KY", "LA", "MA", "MD", "MI", "MO", "NC", "NJ",
                                "NY", "OH", "PA", "TN", "VA", "VT", "WV", "WY")),
    ("hardrock", "Hard Rock Bet", _s("AZ", "CO", "FL", "IL", "IN", "MI", "NJ",
                                     "OH", "TN", "VA")),
    ("thescore", "theScore Bet", _s("AZ", "CO", "IA", "IL", "IN", "KS", "KY",
                                    "LA", "MA", "MD", "MI", "MO", "NC", "NJ",
                                    "NY", "OH", "PA", "TN", "VA", "WV")),
    ("betrivers", "BetRivers", _s("AZ", "CO", "DE", "IA", "IL", "IN", "LA",
                                  "MD", "MI", "NJ", "NY", "OH", "PA", "VA",
                                  "WV")),
    # IL is left out on purpose: ballybet.com/il says "Bally Bet is here" while the
    # Illinois Gaming Board lists Bally's online brand as N/A. Unverified is not live.
    ("bally", "Bally Bet", _s("AZ", "CO", "IA", "IN", "MA", "MD", "NJ", "NY",
                              "OH", "TN", "VA")),
    # Books that have left online betting keep their key, with no states, so
    # nothing that names them breaks; they are simply available nowhere.
    ("betfred", "BetFred", _s()),       # left the US; PA, the last state, closed 2025-07-31
    ("betparx", "betPARX", _s("MD", "NJ", "PA")),
    ("betr", "Betr", _s()),             # VA ended 2025-07-01; no OH online handle since Nov 2025
    # Delaware North replaced Betly with Ember Sportsbook on 2026-07-01 (OH, WV);
    # Betly left TN on 2025-12-29. The key stays "betly" so references hold.
    ("betly", "Ember Sportsbook", _s("OH", "WV")),
    ("prime", "Prime Sportsbook", _s("KY", "NJ", "OH")),
    ("wynn", "WynnBET", _s()),          # ceased everywhere but a Nevada app not shown to be statewide
    ("superbook", "SuperBook", _s()),   # Westgate SuperBook's mobile betting is the Caesars app since 2026-07-28
    ("underdog", "Underdog Sports", _s()),  # stopped taking NC wagers 2025-12-16
    # Lottery-run single-operator markets, read 2026-08-17. These sat in
    # COVERAGE_GAPS until now: each state licenses exactly one online book, so
    # the operator list is one row rather than a market.
    ("sportsbook-ri", "Sportsbook Rhode Island", _s("RI")),
    ("sports-bet-mt", "Sports Bet Montana", _s("MT")),
    # Added 2026-10-07 for the offers feed, from the book's own promotion
    # terms: "physically present in the state of Arizona (but not on Indian
    # lands)". The terms name the operator as Desert Diamond Mobile LLC.
    ("desertdiamond", "Bet Desert Diamond", _s("AZ")),
    # Added 2026-10-07: the NJ Division of Gaming Enforcement lists Borgata's
    # own online sportsbook, borgataonline.com/en/sports, beside BetMGM's. PA is
    # left out: the PA Gaming Control Board's online sports wagering operator
    # list, read the same day, does not name Borgata.
    ("borgata", "Borgata", _s("NJ")),
]

# Sharp books: low margin, high limits, and they do not limit winners. Their
# prices anchor fair value; betting them costs no account lifetime.
_SHARP = [
    Venue("circa", "Circa Sports", BookTier.SHARP,
          _s("CO", "IA", "IL", "KY", "MO", "NV"),
          limits_winners=False,
          note="posts early, takes size, does not limit winners"),
    Venue("pinnacle", "Pinnacle", BookTier.SHARP, frozenset(),
          limits_winners=False, verified=False,
          note="the standard fair-value anchor; not licensed in US states — "
               "check your own jurisdiction before assuming access"),
]

# --- prediction markets: which states a venue's sports contracts are open in ------
#
# Kalshi and Polymarket US are federally regulated, so they are "nationwide" and
# the question is only where a court or a regulator has said otherwise. Every row
# below is one claim from one dated source, and the same table decides two things:
#
#   restricted  a court order currently blocks or limits the venue's sports
#               contracts. The state is the venue's `excluded` set: no live pair
#               is shown there, and no price is read.
#   contested   a case is under way and the venue still operates. A pair is
#               shown, with one plain line saying so.
#
# A state in neither is "available" in that source. Change a state by changing
# its row; nothing else in this file or in xvenue.py spells a state out.

class ExclusionSource(NamedTuple):
    """A dated article a state row rests on. `published` is the date it prints;
    `read` is when this file last checked it."""
    name: str
    published: str
    read: str
    url: str


_FOX = ExclusionSource(
    "Fox Sports", "2026-10-05", "2026-10-09",
    "https://www.foxsports.com/stories/betting/prediction-markets-legal-states")
_CBS = ExclusionSource(
    "CBS Sports", "2026-10-08", "2026-10-09",
    "https://www.cbssports.com/prediction/news/polymarket-promo-code/")

#: The articles behind each exchange's state rows, by venue key. Kalshi's was
#: first read 2026-10-07; the article is the same one, published 2026-10-05.
EXCLUSION_SOURCES: dict[str, tuple[ExclusionSource, ...]] = {
    "kalshi": (_FOX._replace(read="2026-10-07",
                             url="https://foxsports.com/stories/betting/prediction-markets-legal-states"),),
    "polymarket_us": (_FOX, _CBS),
}

# What the sources say, read 2026-10-09.
#   Fox Sports, published 2026-10-05: a state-by-state table headed "Prediction
#   Market Availability by State at a Glance", which says it covers the leading
#   CFTC-regulated platforms, Kalshi and Polymarket. Restricted is a court order
#   that currently blocks or limits access, most often to sports contracts;
#   Contested is a lawsuit or enforcement action under way while the platforms
#   still operate. Under "Which Prediction Market Platforms Are Available?" its
#   Polymarket bullet says the Polymarket US app "follows a broadly similar state
#   footprint", which is why the table's rows are applied to it as they are to
#   Kalshi.
#   CBS Sports, published 2026-10-08: Polymarket US is available in every state
#   except Nevada.
# Fox's bullet for OG, a different exchange (Crypto.com / Nadex), lists New York
# and Arizona as unavailable and sports restricted in IL, MD, MA, MI, NV, NJ and
# OH. It is not about Polymarket US and must not be read as if it were: doing so
# hides New Jersey, which Fox's own table calls available.
_FOX_RESTRICTED = ("MA", "MI", "NV", "WA")
_FOX_CONTESTED = ("AZ", "CA", "CT", "IL", "MD", "MN", "NM", "NY", "OH", "RI", "TN", "TX", "UT", "WI")


class StateStatus(NamedTuple):
    kind: str                       # "restricted" or "contested"
    sources: tuple                  # names of sources in EXCLUSION_SOURCES[venue]


def _rows(restricted: dict, contested: dict) -> dict:
    out = {st: StateStatus("contested", names) for st, names in contested.items()}
    out.update({st: StateStatus("restricted", names) for st, names in restricted.items()})
    return out


STATE_STATUS: dict[str, dict[str, StateStatus]] = {
    "kalshi": _rows({st: ("Fox Sports",) for st in _FOX_RESTRICTED},
                    {st: ("Fox Sports",) for st in _FOX_CONTESTED}),
    "polymarket_us": _rows({**{st: ("Fox Sports",) for st in _FOX_RESTRICTED}, "NV": ("Fox Sports", "CBS Sports")},
                           {st: ("Fox Sports",) for st in _FOX_CONTESTED}),
}


def restricted_states(venue_key: str) -> frozenset:
    return frozenset(st for st, row in STATE_STATUS.get(venue_key, {}).items() if row.kind == "restricted")


STATE_NAMES = {
    "AK": "Alaska", "AL": "Alabama", "AR": "Arkansas", "AZ": "Arizona", "CA": "California", "CO": "Colorado",
    "CT": "Connecticut", "DC": "the District of Columbia", "DE": "Delaware", "FL": "Florida", "GA": "Georgia",
    "HI": "Hawaii", "IA": "Iowa", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "KS": "Kansas",
    "KY": "Kentucky", "LA": "Louisiana", "MA": "Massachusetts", "MD": "Maryland", "ME": "Maine",
    "MI": "Michigan", "MN": "Minnesota", "MO": "Missouri", "MS": "Mississippi", "MT": "Montana",
    "NC": "North Carolina", "ND": "North Dakota", "NE": "Nebraska", "NH": "New Hampshire", "NJ": "New Jersey",
    "NM": "New Mexico", "NV": "Nevada", "NY": "New York", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon",
    "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee",
    "TX": "Texas", "UT": "Utah", "VA": "Virginia", "VT": "Vermont", "WA": "Washington", "WI": "Wisconsin",
    "WV": "West Virginia", "WY": "Wyoming",
}


def state_status(venue_key: str, state: str):
    """What the dated sources say about a venue in a state: (the row, the sources
    it rests on), or None where no source says anything against the venue."""
    row = STATE_STATUS.get(venue_key, {}).get(state.strip().upper())
    if row is None:
        return None
    by_name = {src.name: src for src in EXCLUSION_SOURCES[venue_key]}
    return row, tuple(by_name[name] for name in row.sources)


# Exchanges and prediction markets: commission instead of vig, and no
# bookmaker to be limited by. Structurally the best place for a consistent
# winner, and the reason `heat.py` spends no effort protecting these accounts.
_EXCHANGE = [
    Venue("kalshi", "Kalshi", BookTier.EXCHANGE, frozenset(), nationwide=True,
          commission=0.0, limits_winners=False,
          excluded=restricted_states("kalshi"),
          note="CFTC-regulated event contracts; fee schedule varies by market "
               "and is not a flat commission — set per-market before relying "
               "on a net price. Sports contracts are blocked by court order or "
               "regulator in Massachusetts, Michigan, Nevada and Washington, and "
               "contested in several more (read 2026-10-07)"),
    # Stopped taking wagers 2026-05-25 while its CFTC application is pending.
    Venue("sporttrade", "Sporttrade", BookTier.EXCHANGE,
          frozenset(), commission=0.02, limits_winners=False,
          note="exchange model, commission on winnings; no US wagering since "
               "2026-05-25 while a CFTC application is pending"),
    Venue("prophetx", "ProphetX", BookTier.EXCHANGE, frozenset(),
          commission=0.02, limits_winners=False, verified=False,
          note="peer-to-peer; availability unverified in this snapshot"),
    # The CFTC-regulated exchange US persons trade on (docs.polymarket.us), with its
    # own markets, order books and fees. The international Polymarket, which US
    # persons may not trade, is not in this table and nothing here reads it.
    Venue("polymarket_us", "Polymarket US", BookTier.EXCHANGE, frozenset(), nationwide=True,
          commission=0.0, limits_winners=False,
          excluded=restricted_states("polymarket_us"),
          note="CFTC-regulated exchange; taker fee 0.0695 x contracts x p x (1 - p) per "
               "docs.polymarket.us/fees, read 2026-10-09. Sports contracts are restricted in "
               "Massachusetts, Michigan, Nevada and Washington and contested in several more "
               "(Fox Sports 2026-10-05; CBS Sports 2026-10-08 names Nevada only)"),
    Venue("betfair", "Betfair Exchange", BookTier.EXCHANGE, frozenset(),
          commission=0.02, limits_winners=False, verified=False,
          note="not US-licensed; listed for non-US users"),
]

# Where each row above was confirmed on 2026-09-24: the operator's own page or
# filing, a regulator's licensee list, or dated trade press, in that order of
# preference. A row this does not name was confirmed unchanged from the same kinds
# of source. Shown to the user beside AS_OF by anything that renders this table.
STATE_SOURCES: dict[str, str] = {
    "dk": "https://www.sec.gov/Archives/edgar/data/1883685/000188368526000029/dkng-20260630.htm",
    "fd": "https://www.actionnetwork.com/online-sports-betting/district-of-columbia",
    "mgm": "https://sports.betmgm.com/en/blog/discover-betmgm-across-america/",
    "caesars": "https://www.caesars.com/sportsbook-and-casino/nv/",
    "bet365": "https://www.tn.gov/swac/licensees-registrants.html",
    "fanatics": "https://betfanatics.com/blog/where-sports-betting-is-legal",
    "hardrock": "https://www.hardrock.bet/sportsbook/ohio/",
    "thescore": "https://thescorebethelp.zendesk.com/hc/en-us/articles/40514453048333-ESPN-BET-Rebrand-to-theScore-Bet",
    "betrivers": "https://ir.rushstreetinteractive.com/news/news-details/2026/Rush-Street-Interactive-Announces-Second-Quarter-2026-Results-and-Raises-Full-Year-Guidance/default.aspx",
    "bally": "https://www.ballybet.com/",
    "betfred": "https://www.covers.com/industry/betfred-the-latest-sportsbook-to-abandon-us-market-july-29-2025",
    "betparx": "https://www.betparx.com/",
    "betr": "https://help.betr.app/en/articles/11585542-virginia-cessation-faq-s",
    "betly": "https://www.prnewswire.com/news-releases/delaware-north-launches-ember-entertainment-to-unify-casinos-digital-gaming-and-rewards-program-302815287.html",
    "prime": "https://www.primesportsbook.com/help-center/about-prime-sportsbook/",
    "wynn": "https://www.wynnbet.com/faq/",
    "superbook": "https://newsroom.caesars.com/press-releases/press-release-details/2026/Caesars-Sportsbook-Powers-New-Era-of-Betting-at-Westgate-SuperBook-2026-TfcI9jJOji/default.aspx",
    "underdog": "https://ncgaming.gov/north-carolina-state-lottery-commission-shares-upcoming-change-to-sports-wagering-operator/",
    "circa": "https://www.circasports.com/",
    "desertdiamond": "https://cms.ddc.whitehatgaming.com/en/promotions?device=desktop&userType=new_user&jurisdiction=US-AZ",
    "borgata": "https://www.njoag.gov/about/divisions-and-offices/division-of-gaming-enforcement-home/sports-wagering/",
    "sporttrade": "https://www.yogonet.com/international/news/2026/05/19/121042-sporttrade-to-exit-us-online-sports-betting-markets-while-awaiting-cftc-decision",
}

VENUES: dict[str, Venue] = {}
for _key, _name, _states in _RETAIL:
    VENUES[_key] = Venue(_key, _name, BookTier.RETAIL, _states)
for _v in _SHARP + _EXCHANGE:
    VENUES[_v.key] = _v

# Books that left every US market, with the date their last state closed.
# Recorded by the 2026-09-24 state-table re-check (c5b5590), sources in
# STATE_SOURCES. Without this, a deliberate, sourced exit and a book that
# silently fell out of the table look identical, and the catalog gate went
# red on main for eleven days because it could not tell them apart.
EXITED = {
    "betfred": "2025-07-31 — left the US; Pennsylvania, its last state, closed",
    "betr": "2025-11 — Virginia ended 2025-07-01; no Ohio online handle since November",
    "wynn": "ceased everywhere but a Nevada app not shown to be statewide",
    "superbook": "2026-07-28 — Westgate SuperBook's mobile betting is now the Caesars app",
    "underdog": "2025-12-16 — stopped taking North Carolina wagers",
    "sporttrade": "2026-05-25 — no US wagers while its CFTC application is pending",
}
for _key, _why in EXITED.items():
    VENUES[_key] = _dc_replace(VENUES[_key], exited=_why)


# Jurisdictions with legal online betting this table does not describe. Empty
# is the goal, and it is empty as of 2026-08-17 — the five lottery-run markets
# that were here are now catalogued with their single operator each.
COVERAGE_GAPS: dict[str, str] = {}

# States where betting is legal but only in person. Not a gap in this table —
# there is no online venue to catalogue, which is a different answer from "we
# have not looked" and was previously conflated with it. A user here is not
# missing data; they are missing an online market.
RETAIL_ONLY: dict[str, str] = {
    "MS": "retail sportsbooks only, no online betting",
    "NM": "tribal casinos only, no state-regulated online betting",
    "ND": "tribal casinos only, no state-regulated online betting",
    "SD": "Deadwood and tribal casinos only, no online betting",
    "WI": "tribal casinos only, no state-regulated online betting",
    "WA": "tribal casinos only, including on-premises mobile, no statewide online betting",
    "NE": "licensed casinos only; online betting is on the 2026-11-03 ballot",
}

# Why a one-row operator list is a fact about the state rather than a thin
# table. Read 2026-08-17; RI and MT re-checked 2026-09-24 (Bally Bet is RI's second
# licensee but cannot launch before 2026-11-26).
SINGLE_OPERATOR: dict[str, str] = {
    "NH": "an exclusive lottery contract with DraftKings",
    "OR": "an exclusive lottery partnership with DraftKings",
    "DE": "a lottery market run by BetRivers",
    "RI": "a lottery market run on the IGT platform",
    "MT": "a lottery market run by Intralot, where the app only works inside "
          "authorised Sports Bet Montana locations",
}

# States with no legal sports betting at all as of AS_OF. Listed so the UI can
# tell a user in one of them that the answer is "none", which is a real answer
# and better than an empty screen that looks like a bug.
NO_LEGAL_BETTING = frozenset(
    ("AL", "AK", "CA", "GA", "HI", "ID", "MN", "OK", "SC", "TX", "UT")
)


def for_state(state: str, include_unverified: bool = False) -> list[Venue]:
    """Venues a user in this state can plausibly hold, best-anchored first.

    Sorted sharp → exchange → retail, because that is the order in which they
    matter: without at least one sharp or exchange price there is no anchored
    fair value, and the +EV screen has nothing to measure against.
    """
    order = {BookTier.SHARP: 0, BookTier.EXCHANGE: 1,
             BookTier.RETAIL: 2, BookTier.UNKNOWN: 3}
    # Case-folded so bet365 and betPARX sort among the b's, not after theScore.
    out = [
        v for v in VENUES.values()
        if (v.available_in(state) and v.verified)
        or (include_unverified and (v.jurisdiction_unknown or v.available_in(state)))
    ]
    return sorted(out, key=lambda v: (order[v.tier], v.name.lower()))


def books_for_state(state: str, include_unverified: bool = False) -> dict[str, Book]:
    """`for_state` as the `{key: Book}` mapping the engine takes."""
    return {v.key: v.to_book() for v in for_state(state, include_unverified)}


def all_books() -> dict[str, Book]:
    """Every venue, ignoring jurisdiction. For backtests and offline work."""
    return {k: v.to_book() for k, v in VENUES.items()}


def has_anchor(state: str) -> bool:
    """Whether a state has any sharp or exchange price to anchor fair value.

    False means +EV numbers in that state rest on retail books alone — a poll
    of the people you intend to beat. `fair.py` already flags this per market;
    this answers it up front, before a user pays for a screen that cannot work
    where they live.
    """
    return any(
        v.tier in (BookTier.SHARP, BookTier.EXCHANGE) for v in for_state(state)
    )


def state_summary(state: str) -> dict:
    """Everything the UI needs to explain a jurisdiction in one call."""
    st = state.upper()
    venues = for_state(st)
    return {
        "state": st,
        "legal": st not in NO_LEGAL_BETTING,
        "covered": st not in COVERAGE_GAPS,
        "gap_reason": COVERAGE_GAPS.get(st, ""),
        "online": st not in RETAIL_ONLY and st not in NO_LEGAL_BETTING,
        "retail_only": RETAIL_ONLY.get(st, ""),
        "single_operator": SINGLE_OPERATOR.get(st, ""),
        "venues": len(venues),
        "retail": sum(1 for v in venues if v.tier is BookTier.RETAIL),
        "anchors": sum(
            1 for v in venues
            if v.tier in (BookTier.SHARP, BookTier.EXCHANGE)
        ),
        "has_anchor": has_anchor(st),
        "never_limit": [v.key for v in venues if not v.limits_winners],
        "as_of": AS_OF,
        "stale_days": stale_days(),
    }


def stale_days(now: float | None = None) -> int:
    """Days since the operator table was read.

    Exists so no screen can show this data without being able to say how old
    it is. A jurisdiction table presented without its age asserts "true now",
    forever.
    """
    now = time.time() if now is None else now
    return max(0, int((now - AS_OF_EPOCH) // 86400))


def coverage_gaps() -> dict[str, str]:
    return dict(COVERAGE_GAPS)


def retail_only() -> dict[str, str]:
    return dict(RETAIL_ONLY)


def single_operator() -> dict[str, str]:
    return dict(SINGLE_OPERATOR)
