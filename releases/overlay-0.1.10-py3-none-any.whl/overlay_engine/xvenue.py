"""Live arbitrage between Kalshi and Polymarket US on the same game.

The one live, free, keyless arbitrage this product can offer. Both venues
publish order books without an account, both list NFL, MLB, NBA and NHL games
as two-sided markets, and their prices disagree now and then. What makes it
worth building carefully is that every way it can go wrong is a way of showing
a row that loses money:

**The Polymarket leg is on Polymarket US, and only there.** International
Polymarket (gamma-api / clob) is not open to US persons; Polymarket US is a
separate CFTC-regulated exchange with its own markets, order books and fees
(docs.polymarket.us), and its public market data needs no key
(gateway.polymarket.us). Nothing here reads the international one.

**Matching is by team code and date, never by title.** Kalshi's event ticker
ends in the two teams' codes (KXNFLGAME-26OCT08TBDAL) and each market's ticker
ends in the one team it pays on. Polymarket US says not to parse its slugs or
symbols and to read the typed fields instead, so its two teams are the two
market sides' `team` objects: each abbreviation is checked against a fixed team
table, each team's name against the team that code names, and a game that does
not match on both is refused rather than guessed. Both venues date a game in
Eastern time (Polymarket US from the game's start time, converted here by the
US rule rather than a system time zone database), so the dates must agree
exactly, in every league: baseball plays the same two teams on consecutive days
(a day of slack once paired today's game with tomorrow's). A game that two
listings could both be is priced as neither.

**Which side is which on Polymarket US.** A market has ONE instrument, the
team its `long` side names (docs: "Each market on Polymarket US has one
instrument"). Backing that team is buying the instrument: you pay the best
ask. Backing the other team is selling it, which the exchange records as a
short; the seller receives the bid and posts $1.00 of collateral, so the cost
of a contract that pays $1 if the other team wins is 1 - the best bid, and
the quantity on offer is what is resting at that bid. The market's own
longQuote and shortQuote say the same (0.2350 and 0.7675 against a book of
0.2325 bid and 0.2350 ask), and a market whose side quotes contradict this
mapping is refused. A wrong mapping here prices an "arbitrage" that loses money.

**Prices are asks, not quotes.** Polymarket US's market list carries a best bid
and ask, and no size, and it can be cents off the book (a game under way moves
faster than the list does). Those listed prices only decide which games are
worth a look at the order book; the book sets the price.

**Every price is sized to what is resting at it.** Kalshi reports the number of
contracts at its best ask. For every leg that could be an arbitrage the Polymarket
US order book is read, and the leg is priced at the book's best price on the
side the leg trades and limited to the contracts resting there. A leg whose book
is not known is not priced: an arbitrage not shown to be fillable is not one.
The pair is sized to the smallest of the two books and the money you said you
would bet, fees included, and says which of the three set the size.

**Fees are the venues' own published formulas, read from the venues.**
Kalshi: rate x C x p x (1 - p) rounded up to the cent, rate 0.07 times the
series' fee multiplier (read from the series: MLB is half). Polymarket US:
taker fee = coefficient x C x p x (1 - p), the coefficient 0.0695 read from each
market's feeCoefficient, rounded to the cent with banker's rounding (round half
to even; an order that fills against several resting orders is charged no more
than the rounding of its whole exact fee, so the whole order's rounding is the
most it can cost). p is the price of the contract traded; the formula is the
same for a price and its complement, so a short at 0.2325 costs what a buy at
0.7675 does. Where a coefficient cannot be read the dearer, recorded one is
charged. A margin that disappears after fees is not shown as an arb.

**Resolution rules were read, and they agree except in one place.** Both
venues settle on the official winner, overtime included. An NFL tie pays 50c
per side on both, so the arb survives it. A postponement does not: Kalshi
settles at a fair price if the game has not been played within 48 hours (two
days in baseball); Polymarket US lets the rescheduled game settle it if that is
played before the contract expires (about two weeks) and otherwise settles at the
last fair market price. A settlement at a fair price is not promised to leave the
two bets worth a dollar together. Every pairing says so.

**A pair is shown only where both venues are open.** Kalshi and Polymarket US
are federally regulated and still blocked in some states by court order. The
person's state decides, from the dated table in `catalog`: where either venue's
sports contracts are restricted, nothing is read at all and the answer says
which venue, why, and from which source and date; with no state given the scan
runs and shows no pairs, because a pair someone cannot place is the error that
matters; where a case is under way and the venues still operate, pairs are shown
with one plain line saying so.

**Nothing here is shown unless it pays.** A pairing is listed only when it
leaves a profit after both fees at the size on offer. Near misses are priced
and never listed: a list of things that do not pay, however labelled, is
padding. When nothing pays, the answer is that nothing does.

The fetch is a seam, as in `pubfeed`: `fetch` is a callable from a URL to
parsed JSON, so everything that can be wrong is tested against recorded
payloads. Nothing in this module opens a socket.
"""

from __future__ import annotations

import datetime as dt
import math
import re
import time
from dataclasses import dataclass, field
from decimal import ROUND_HALF_EVEN, Decimal, InvalidOperation
from urllib.parse import quote

from . import catalog

LEAGUES = ("nfl", "mlb", "nba", "nhl")
KALSHI_SERIES = {"nfl": "KXNFLGAME", "mlb": "KXMLBGAME", "nba": "KXNBAGAME", "nhl": "KXNHLGAME"}

KALSHI_EVENTS = ("https://api.elections.kalshi.com/trade-api/v2/events"
                 "?series_ticker={series}&status=open&with_nested_markets=true&limit=200")
KALSHI_SERIES_URL = "https://api.elections.kalshi.com/trade-api/v2/series/{series}"

PMUS_HOST = "https://gateway.polymarket.us"
PMUS_SPORTS = PMUS_HOST + "/v1/sports"
PMUS_PAGE = 100
PMUS_MAX_PAGES = 6
#: A league's open game moneylines, by the league's tag. Not the events list: an
#: NFL event carries three hundred prop markets and the league's came to 3.6 MB for
#: three games. `marketTypes=moneyline` is the game winners and the first-half and
#: first-five ones are told apart again in `pmus_games` by `sportsMarketType`.
PMUS_GAMES = (PMUS_HOST + "/v1/markets?limit=" + str(PMUS_PAGE) +
              "&offset={offset}&active=true&closed=false&marketTypes=moneyline&tagIds={tag}")
PMUS_BOOK = PMUS_HOST + "/v1/markets/{slug}/book"
#: The full-game winner of each league, as the docs' sports schema names it
#: (`<sport>_team_full_game_winner`). A first-half winner is a different bet.
PMUS_WINNER = {"nfl": "football_team_full_game_winner", "mlb": "baseball_team_full_game_winner",
               "nba": "basketball_team_full_game_winner", "nhl": "hockey_team_full_game_winner"}
PMUS_OPEN = "MARKET_STATE_OPEN"

#: Read 2026-10-09. Kalshi: kalshi.com/fee-schedule (taker 0.07 x C x p(1-p)) and
#: each game series' object (fee_type quadratic_with_maker_fees; fee_multiplier
#: 1, MLB 0.5). Polymarket US: docs.polymarket.us/fees, effective exchange-wide from
#: 2026-10-01 (taker 0.0695 x C x p x (1 - p), banker's rounding to the cent) and each
#: market's feeCoefficient.
KALSHI_TAKER_RATE = 0.07
KALSHI_QUADRATIC = ("quadratic", "quadratic_with_maker_fees")
#: What each series charged when read; used only if the series cannot be read.
KALSHI_FEE_MULTIPLIER = {"nfl": 1.0, "mlb": 0.5, "nba": 1.0, "nhl": 1.0}
PMUS_TAKER_COEFF = 0.0695
#: Charged when a market's own coefficient cannot be read: the dearest one the fee
#: page lists (Table Tennis, from 2026-10-07; not one of ours).
PMUS_DEARER_COEFF = 0.10
FEES_READ = "2026-10-09"
FEE_SOURCES = ("https://kalshi.com/fee-schedule",
               "https://docs.polymarket.us/fees")

_POSTPONED = ("Kalshi settles at a fair price if the game has not been played within 48 hours{baseball}, while "
              "Polymarket US lets the rescheduled game settle it if that is played before the contract expires, "
              "about two weeks, and otherwise settles at the last fair market price. A fair-price settlement is "
              "not promised to leave the two bets worth a dollar together. That is the risk left.")
RESIDUAL_RISK_NFL = ("Both venues settle on the official winner, overtime included, and a tie pays 50c per side on "
                     "both, so a tie leaves the pair whole. They differ if the game is postponed: "
                     + _POSTPONED.format(baseball=""))
RESIDUAL_RISK = ("Both venues settle on the official winner, overtime included. They differ if the game is "
                 "postponed: " + _POSTPONED.format(baseball=" (two days in baseball)"))

#: Kalshi's code -> (city, nickname), so a Polymarket US team can be checked
#: against the team its abbreviation names. From ESPN's public team lists (2026-10-06).
LEAGUE_TEAMS = {
    "nfl": {
        "ARI": ("Arizona", "Cardinals"), "ATL": ("Atlanta", "Falcons"), "BAL": ("Baltimore", "Ravens"),
        "BUF": ("Buffalo", "Bills"), "CAR": ("Carolina", "Panthers"), "CHI": ("Chicago", "Bears"),
        "CIN": ("Cincinnati", "Bengals"), "CLE": ("Cleveland", "Browns"), "DAL": ("Dallas", "Cowboys"),
        "DEN": ("Denver", "Broncos"), "DET": ("Detroit", "Lions"), "GB": ("Green Bay", "Packers"),
        "HOU": ("Houston", "Texans"), "IND": ("Indianapolis", "Colts"), "JAX": ("Jacksonville", "Jaguars"),
        "KC": ("Kansas City", "Chiefs"), "LAC": ("Los Angeles", "Chargers"), "LAR": ("Los Angeles", "Rams"),
        "LV": ("Las Vegas", "Raiders"), "MIA": ("Miami", "Dolphins"), "MIN": ("Minnesota", "Vikings"),
        "NE": ("New England", "Patriots"), "NO": ("New Orleans", "Saints"), "NYG": ("New York", "Giants"),
        "NYJ": ("New York", "Jets"), "PHI": ("Philadelphia", "Eagles"), "PIT": ("Pittsburgh", "Steelers"),
        "SEA": ("Seattle", "Seahawks"), "SF": ("San Francisco", "49ers"), "TB": ("Tampa Bay", "Buccaneers"),
        "TEN": ("Tennessee", "Titans"), "WAS": ("Washington", "Commanders"),
    },
    "mlb": {
        "ATH": ("Athletics", "Athletics"), "ATL": ("Atlanta", "Braves"), "AZ": ("Arizona", "Diamondbacks"),
        "BAL": ("Baltimore", "Orioles"), "BOS": ("Boston", "Red Sox"), "CHC": ("Chicago", "Cubs"),
        "CIN": ("Cincinnati", "Reds"), "CLE": ("Cleveland", "Guardians"), "COL": ("Colorado", "Rockies"),
        "CWS": ("Chicago", "White Sox"), "DET": ("Detroit", "Tigers"), "HOU": ("Houston", "Astros"),
        "KC": ("Kansas City", "Royals"), "LAA": ("Los Angeles", "Angels"), "LAD": ("Los Angeles", "Dodgers"),
        "MIA": ("Miami", "Marlins"), "MIL": ("Milwaukee", "Brewers"), "MIN": ("Minnesota", "Twins"),
        "NYM": ("New York", "Mets"), "NYY": ("New York", "Yankees"), "PHI": ("Philadelphia", "Phillies"),
        "PIT": ("Pittsburgh", "Pirates"), "SD": ("San Diego", "Padres"), "SEA": ("Seattle", "Mariners"),
        "SF": ("San Francisco", "Giants"), "STL": ("St. Louis", "Cardinals"), "TB": ("Tampa Bay", "Rays"),
        "TEX": ("Texas", "Rangers"), "TOR": ("Toronto", "Blue Jays"), "WSH": ("Washington", "Nationals"),
    },
    "nba": {
        "ATL": ("Atlanta", "Hawks"), "BKN": ("Brooklyn", "Nets"), "BOS": ("Boston", "Celtics"),
        "CHA": ("Charlotte", "Hornets"), "CHI": ("Chicago", "Bulls"), "CLE": ("Cleveland", "Cavaliers"),
        "DAL": ("Dallas", "Mavericks"), "DEN": ("Denver", "Nuggets"), "DET": ("Detroit", "Pistons"),
        "GSW": ("Golden State", "Warriors"), "HOU": ("Houston", "Rockets"), "IND": ("Indiana", "Pacers"),
        "LAC": ("LA", "Clippers"), "LAL": ("Los Angeles", "Lakers"), "MEM": ("Memphis", "Grizzlies"),
        "MIA": ("Miami", "Heat"), "MIL": ("Milwaukee", "Bucks"), "MIN": ("Minnesota", "Timberwolves"),
        "NOP": ("New Orleans", "Pelicans"), "NYK": ("New York", "Knicks"), "OKC": ("Oklahoma City", "Thunder"),
        "ORL": ("Orlando", "Magic"), "PHI": ("Philadelphia", "76ers"), "PHX": ("Phoenix", "Suns"),
        "POR": ("Portland", "Trail Blazers"), "SAC": ("Sacramento", "Kings"), "SAS": ("San Antonio", "Spurs"),
        "TOR": ("Toronto", "Raptors"), "UTA": ("Utah", "Jazz"), "WAS": ("Washington", "Wizards"),
    },
    "nhl": {
        "ANA": ("Anaheim", "Ducks"), "BOS": ("Boston", "Bruins"), "BUF": ("Buffalo", "Sabres"),
        "CAR": ("Carolina", "Hurricanes"), "CBJ": ("Columbus", "Blue Jackets"), "CGY": ("Calgary", "Flames"),
        "CHI": ("Chicago", "Blackhawks"), "COL": ("Colorado", "Avalanche"), "DAL": ("Dallas", "Stars"),
        "DET": ("Detroit", "Red Wings"), "EDM": ("Edmonton", "Oilers"), "FLA": ("Florida", "Panthers"),
        "LA": ("Los Angeles", "Kings"), "MIN": ("Minnesota", "Wild"), "MTL": ("Montreal", "Canadiens"),
        "NJ": ("New Jersey", "Devils"), "NSH": ("Nashville", "Predators"), "NYI": ("New York", "Islanders"),
        "NYR": ("New York", "Rangers"), "OTT": ("Ottawa", "Senators"), "PHI": ("Philadelphia", "Flyers"),
        "PIT": ("Pittsburgh", "Penguins"), "SEA": ("Seattle", "Kraken"), "SJ": ("San Jose", "Sharks"),
        "STL": ("St. Louis", "Blues"), "TB": ("Tampa Bay", "Lightning"), "TOR": ("Toronto", "Maple Leafs"),
        "UTA": ("Utah", "Mammoth"), "VAN": ("Vancouver", "Canucks"), "VGK": ("Vegas", "Golden Knights"),
        "WPG": ("Winnipeg", "Jets"), "WSH": ("Washington", "Capitals"),
    },
}

#: Where a venue spells a team differently from the table above (checked
#: against both venues' full team lists, 2026-10-09). Kalshi spells Jacksonville
#: JAC; Polymarket US spells four NBA teams and four NHL teams its own way.
KALSHI_TO_TABLE = {"nfl": {"JAC": "JAX", "LA": "LAR", "WSH": "WAS", "LVR": "LV", "OAK": "LV"},
                   "mlb": {}, "nba": {}, "nhl": {}}
PMUS_TO_TABLE = {
    "nfl": {"JAC": "JAX"},
    "mlb": {},
    "nba": {"GS": "GSW", "NO": "NOP", "NY": "NYK", "PHO": "PHX", "SA": "SAS"},
    "nhl": {"MON": "MTL", "NAS": "NSH", "VEG": "VGK", "WAS": "WSH"},
}

_MONTHS = {m: i for i, m in enumerate(
    ("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"), start=1)}


def team_key(league: str, code: str, spellings: dict) -> str | None:
    """A venue's code for a team, as the table's key, or None if it is not a team in the league."""
    c = str(code).strip().upper()
    c = spellings.get(league, {}).get(c, c)
    return c if c in LEAGUE_TEAMS.get(league, {}) else None


def team_name(league: str, code: str) -> str:
    """The full name: 'Buffalo Sabres'."""
    city, nick = LEAGUE_TEAMS[league][code]
    return nick if city == nick else f"{city} {nick}"


def nickname(league: str, code: str) -> str:
    return LEAGUE_TEAMS[league][code][1].lower()


def _named(league: str, code: str, outcome: str) -> bool:
    """Is `outcome` this team's name? Its nickname, its full name, or its
    city alone where no other team in the league shares the city."""
    loc, nick = LEAGUE_TEAMS[league][code]
    o = str(outcome).strip().lower()
    shared = sum(1 for lc, _ in LEAGUE_TEAMS[league].values() if lc == loc) > 1
    return o in (nick.lower(), f"{loc} {nick}".lower()) or (o == loc.lower() and not shared)


# --- dates: both venues use Eastern time ---------------------------------------

def _eastern_offset(utc: dt.datetime) -> int:
    """Hours from UTC to US Eastern at this instant. Daylight time runs from 02:00
    on the second Sunday of March to 02:00 on the first Sunday of November (the rule
    since 2007), worked out here rather than read from a system time zone
    database: the engine ships frozen, and a frozen Python may have none."""
    tz = dt.timezone.utc
    march = dt.datetime(utc.year, 3, 1, 7, tzinfo=tz)                       # 02:00 EST
    start = march + dt.timedelta(days=(6 - march.weekday()) % 7 + 7)
    november = dt.datetime(utc.year, 11, 1, 6, tzinfo=tz)                   # 02:00 EDT
    end = november + dt.timedelta(days=(6 - november.weekday()) % 7)
    return -4 if start <= utc < end else -5


def eastern_date(epoch: float) -> dt.date:
    """The calendar date, in US Eastern time, of an instant."""
    utc = dt.datetime.fromtimestamp(epoch, dt.timezone.utc)
    return (utc + dt.timedelta(hours=_eastern_offset(utc))).date()


# --- fees --------------------------------------------------------------------

def kalshi_fee(contracts: int, price: float, rate: float = KALSHI_TAKER_RATE) -> float:
    """Taker fee, rounded UP to the cent on the whole order."""
    return math.ceil(rate * contracts * price * (1 - price) * 100 - 1e-9) / 100


def pmus_fee(contracts: int, price: float, coeff: float = PMUS_TAKER_COEFF) -> float:
    """Polymarket US taker fee: coeff x C x p x (1 - p), to the cent with banker's
    rounding (docs.polymarket.us/fees: "round half to even", $0.025 is $0.02).

    Exact decimal arithmetic, because the rounding is on a half: 280 contracts at
    50c is exactly $4.865, which is $4.86; a float rounds it up to $4.87. Charged on
    the whole order. When it fills against several resting orders the venue charges
    each fill its own rounded fee and caps the order's total at the rounding of the
    exact sum, so this is the most it can cost. `price` is the price of the contract
    traded; p x (1 - p) is the same for a price and its complement."""
    p = Decimal(str(round(price, 6)))
    exact = Decimal(str(coeff)) * Decimal(int(contracts)) * p * (1 - p)
    return float(exact.quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN))


@dataclass
class Game:
    venue: str                        # "kalshi" or "polymarket_us"
    teams: tuple                      # the two table keys, sorted
    date: dt.date                     # Eastern time
    ask: dict                         # team -> price of $1 if that team wins
    ref: str                          # ticker or slug, for the person to find it
    league: str = "nfl"               # codes repeat across leagues (MIN, CHI...): never paired across them
    #: team -> contracts resting at that ask. A team with no entry has no known
    #: size, and a leg with no known size is not priced.
    size: dict = field(default_factory=dict)
    #: Polymarket US: the team its one instrument pays on. That team is bought at
    #: the instrument's ask; the other is bought by selling the instrument, at 1 - its bid.
    long: str | None = None
    fee_rate: float = KALSHI_TAKER_RATE
    min_size: float = 1.0             # the fewest contracts the venue takes in one order
    read_at: float = 0.0              # when this game's price was read
    depth_at: dict = field(default_factory=dict)     # team -> when its book was read
    starts_at: float | None = None    # epoch seconds, where the venue says
    unread: set = field(default_factory=set)         # teams whose book could not be read

    def fee(self, contracts: int, price: float) -> float:
        if self.venue == "kalshi":
            return kalshi_fee(contracts, price, self.fee_rate)
        return pmus_fee(contracts, price, self.fee_rate)


# --- reading the venues -------------------------------------------------------

def _num(value) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _dec(value) -> Decimal | None:
    """An exact decimal from a string or number, or from an Amount
    ({"value": "0.2350", "currency": "USD"}); None for anything else, and for an
    Amount in another currency."""
    if isinstance(value, dict):
        if value.get("currency") not in (None, "USD"):
            return None
        value = value.get("value")
    if value is None or isinstance(value, bool):
        return None
    try:
        out = Decimal(str(value).strip())
    except InvalidOperation:
        return None
    return out if out.is_finite() else None


def kalshi_games(payload: dict, league: str, fee_rate: float | None = None, read_at: float = 0.0) -> list:
    """Kalshi's games for a league. Tickers carry the date, sometimes a start
    time, then both team codes (KXMLBGAME-26OCT081700CLECWS); each market's
    ticker ends in the one team it pays on, and the two must be exactly the
    pair the event names, in either order."""
    out = []
    rate = KALSHI_TAKER_RATE * KALSHI_FEE_MULTIPLIER[league] if fee_rate is None else fee_rate
    for ev in (payload or {}).get("events") or []:
        tick = ev.get("event_ticker", "")
        m = re.match(r"KX[A-Z]+GAME-(\d{2})([A-Z]{3})(\d{2})(?:\d{4})?([A-Z]+)$", tick)
        if not m or m.group(2) not in _MONTHS:
            continue
        yy, mon, dd, pair = m.groups()
        try:
            date = dt.date(2000 + int(yy), _MONTHS[mon], int(dd))
        except ValueError:
            continue
        ask, size, raw = {}, {}, []
        for mk in ev.get("markets") or []:
            if mk.get("status") not in (None, "active", "open"):
                continue
            code = mk.get("ticker", "").rsplit("-", 1)[-1]
            key = team_key(league, code, KALSHI_TO_TABLE)
            price = _num(mk.get("yes_ask_dollars"))
            if key is None or price is None or not 0 < price < 1:
                continue
            ask[key] = price
            raw.append(code)
            n = _num(mk.get("yes_ask_size_fp"))
            if n is not None and n >= 0:
                size[key] = math.floor(n)
        # Both teams priced, and they are the two the event ticker names. The
        # ticker's own spelling is compared with the ticker's own spelling:
        # Kalshi writes JAC where the table says JAX.
        if len(ask) != 2 or pair not in ("".join(raw), "".join(reversed(raw))):
            continue
        out.append(Game("kalshi", tuple(sorted(ask)), date, ask, tick, league=league, size=size,
                        fee_rate=rate, read_at=read_at))
    return out


def _pmus_start(mk: dict) -> float | None:
    raw = str(mk.get("gameStartTime") or "").strip()
    if not raw:
        return None
    try:
        when = dt.datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=dt.timezone.utc)
    return when.timestamp()


def _pmus_fee_rate(mk: dict) -> float:
    """The market's own feeCoefficient; the dearer, recorded one where it is
    missing or implausible."""
    rate = _dec(mk.get("feeCoefficient"))
    if rate is not None and 0 < rate <= Decimal("0.25"):
        return float(rate)
    return PMUS_DEARER_COEFF


def _pmus_team(side, league: str):
    """(table key, long flag) for one market side, or None. The abbreviation must
    be a team in the league's table AND the team's own name must be that team's:
    two checks, so a wrong code or a wrong name alone refuses the market."""
    if not isinstance(side, dict) or not isinstance(side.get("long"), bool):
        return None
    team = side.get("team")
    if not isinstance(team, dict) or str(team.get("league") or "").lower() != league:
        return None
    key = team_key(league, team.get("abbreviation") or "", PMUS_TO_TABLE)
    if key is None or not _named(league, key, team.get("name") or ""):
        return None
    return key, side["long"]


def _pmus_game(mk, league: str, read_at: float):
    if not isinstance(mk, dict) or mk.get("sportsMarketType") != PMUS_WINNER[league]:
        return None
    if mk.get("closed") or mk.get("active") is False or mk.get("hidden") \
            or mk.get("status") not in (None, "MARKET_STATUS_OPEN"):
        return None
    slug = mk.get("slug")
    sides = mk.get("marketSides")
    if not isinstance(slug, str) or not slug or not isinstance(sides, list) or len(sides) != 2:
        return None
    read = [_pmus_team(s, league) for s in sides]
    if None in read or read[0][0] == read[1][0] or sorted(r[1] for r in read) != [False, True]:
        return None
    start = _pmus_start(mk)
    best_ask, best_bid = _dec(mk.get("bestAskQuote")), _dec(mk.get("bestBidQuote"))
    if start is None or best_ask is None or best_bid is None:
        return None
    # One instrument: the long team is bought at its ask, the other by selling the
    # instrument at its bid, which costs 1 - the bid.
    cost, long_key = {}, None
    for (key, is_long), side in zip(read, sides):
        cost[key] = best_ask if is_long else 1 - best_bid
        if is_long:
            long_key = key
        # The side's own quote is what the venue says that side costs to buy. A
        # mapping that disagrees with it is a flipped long flag: refuse the market.
        said = _dec(side.get("quote"))
        if said is not None and abs(said - cost[key]) > Decimal("0.00001"):
            return None
    if not all(0 < p < 1 for p in cost.values()):
        return None
    floor = _dec(mk.get("minimumTradeQty"))
    return Game("polymarket_us", tuple(sorted(cost)), eastern_date(start), {k: float(v) for k, v in cost.items()},
                slug, league=league, long=long_key, fee_rate=_pmus_fee_rate(mk),
                min_size=float(floor) if floor is not None and floor > 0 else 1.0,
                read_at=read_at, starts_at=start)


def pmus_games(payload, league: str, read_at: float = 0.0) -> list:
    """Polymarket US's full-game winners for a league, from its market list. Each
    market's two teams come from its typed `team` objects, not its slug; the dates
    from its start time, in Eastern time; a game that does not read cleanly on every
    count is refused."""
    markets = payload.get("markets") if isinstance(payload, dict) else None
    out = []
    for mk in markets if isinstance(markets, list) else []:
        game = _pmus_game(mk, league, read_at)
        if game is not None:
            out.append(game)
    return out


class NotOpen(Exception):
    """A market that is not open for trading."""


def _levels(entries) -> list:
    """(price, quantity) of every usable level: a price strictly between $0 and $1
    and a quantity above zero, read as exact decimals."""
    out = []
    for e in entries if isinstance(entries, list) else []:
        if not isinstance(e, dict):
            continue
        p, n = _dec(e.get("px")), _dec(e.get("qty"))
        if p is not None and n is not None and 0 < p < 1 and n > 0:
            out.append((p, n))
    return out


def pmus_book_top(payload, slug: str) -> dict:
    """The top of a Polymarket US order book: {"offer": (price, quantity), "bid":
    (price, quantity)}, each None for an empty side. The offer is what the long team
    costs to buy; the bid is what selling the instrument receives, so the other team
    costs 1 - it. The quantity is everything resting at exactly that price.

    The gateway sends prices as Amount objects holding a decimal string and quantities
    as decimal strings ("0.2350", "536958.2300"); the integer-with-a-scale encoding in
    the trader guide belongs to the exchange API. A price outside (0, 1), as a wrongly
    scaled one would be, is not a level. A book for another market, a market that is
    not open, and a book whose best bid is not below its best offer are errors."""
    data = payload.get("marketData") if isinstance(payload, dict) else None
    if not isinstance(data, dict) or data.get("marketSlug") != slug:
        raise ValueError("the book is for another market")
    if data.get("state") != PMUS_OPEN:
        raise NotOpen(slug)
    offers, bids = _levels(data.get("offers")), _levels(data.get("bids"))
    offer = None
    if offers:
        best = min(p for p, _ in offers)
        offer = (best, sum(n for p, n in offers if p == best))
    bid = None
    if bids:
        best = max(p for p, _ in bids)
        bid = (best, sum(n for p, n in bids if p == best))
    if offer and bid and bid[0] >= offer[0]:
        raise ValueError("a crossed book")
    return {"offer": offer, "bid": bid}


def add_pmus_depth(fetch, games: list, wanted: set, clock=time.time) -> list:
    """For each Polymarket US game with a leg in `wanted` ((ref, team) pairs), read
    its order book once and set both legs from it: the long team at the best offer,
    the other at 1 - the best bid, each with the contracts resting there. Size 0
    where a side is empty or the book cannot be read, because an arbitrage not shown
    to be fillable is not one. Returns the sentences for the books that could not be
    read."""
    from concurrent.futures import ThreadPoolExecutor

    by_ref = {g.ref: g for g in games if g.venue == "polymarket_us"}
    slugs = sorted({ref for ref, _ in wanted if ref in by_ref})

    def read(slug):
        return pmus_book_top(fetch(PMUS_BOOK.format(slug=quote(slug, safe=""))), slug), clock()

    problems = []
    with ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(lambda s: _attempt(read, s), slugs))
    for slug, (ok, got, _exc) in zip(slugs, results):
        g = by_ref[slug]
        if not ok:
            for team in g.teams:
                g.size[team] = 0.0
                g.unread.add(team)
                if (slug, team) in wanted:
                    problems.append(f"Polymarket US's book for {team_name(g.league, team)} could not be read ({got})")
            continue
        top, when = got
        for team in g.teams:
            g.depth_at[team] = when
            if team == g.long:
                level = top["offer"]
                price = level[0] if level else None
            else:
                level = top["bid"]
                price = 1 - level[0] if level else None
            if level:
                g.ask[team], g.size[team] = float(price), float(level[1])
            else:
                g.size[team] = 0.0
    return problems


def _attempt(fn, arg):
    """(True, value, None), or (False, the plain reason, the exception)."""
    try:
        return True, fn(arg), None
    except Exception as exc:                                      # noqa: BLE001 - one read failing is not the scan failing
        return False, _why(exc), exc


def _why(exc: BaseException) -> str:
    """A plain reason for a failed read; never the raw exception text."""
    if isinstance(exc, NotOpen):
        return "the market is not open for trading"
    code = getattr(exc, "code", None)
    if isinstance(code, int):
        return f"HTTP {code}"
    name = type(exc).__name__
    text = f"{name} {exc}".lower()
    if "timed out" in text or "timeout" in text:
        return "timed out"
    if "certificate" in text or "[ssl" in text or "ssl" in name.lower():
        return "the secure connection failed"
    if isinstance(exc, (ValueError, KeyError, TypeError)) or "json" in text:
        return "an answer this version does not understand"
    return "no connection"


def kalshi_events(fetch, series: str, clock=time.time, max_pages: int = 5) -> tuple:
    """(payload, read_at): every open game of a series, following Kalshi's cursor."""
    events, cursor, first = [], "", None
    for _ in range(max_pages):
        url = KALSHI_EVENTS.format(series=series) + (f"&cursor={quote(cursor)}" if cursor else "")
        page = fetch(url) or {}
        first = clock() if first is None else first
        events += page.get("events") or []
        cursor = page.get("cursor") or ""
        if not cursor:
            break
    return {"events": events}, first


class UnknownFee(ValueError):
    """A fee schedule this version has no formula for."""


def kalshi_fee_rate(fetch, league: str) -> float:
    """The taker rate the series itself publishes: 0.07 times its multiplier.
    A fee type this version does not know is an error, not a guess."""
    got = fetch(KALSHI_SERIES_URL.format(series=KALSHI_SERIES[league])) or {}
    series = got.get("series", got)
    if series.get("fee_type") not in KALSHI_QUADRATIC:
        raise UnknownFee(f"fee type {series.get('fee_type')!r}")
    mult = _num(series.get("fee_multiplier"))
    mult = 1.0 if mult is None else mult
    if not 0 < mult <= 2:
        raise UnknownFee("fee multiplier")
    return KALSHI_TAKER_RATE * mult


def pmus_league_tags(sports) -> dict:
    """league -> Polymarket US's tag id, looked up from its /v1/sports list on every
    run rather than written here: a hard-coded id breaks silently the day they
    renumber it. A league the venue says is not operational is left out."""
    out = {}
    rows = sports.get("sports") if isinstance(sports, dict) else None
    for s in rows if isinstance(rows, list) else []:
        name = str(s.get("sport") or "").lower()
        tag = str(s.get("tags") or "").strip()
        if name in LEAGUES and tag.isdigit() and s.get("isOperational") is not False:
            out[name] = tag
    return out


def pmus_markets(fetch, tag: str, clock=time.time, max_pages: int = PMUS_MAX_PAGES) -> tuple:
    """(markets, read_at): a league's open game moneylines, a page at a time."""
    out, first = [], None
    for page in range(max_pages):
        got = fetch(PMUS_GAMES.format(tag=tag, offset=page * PMUS_PAGE))
        first = clock() if first is None else first
        rows = got.get("markets") if isinstance(got, dict) else None
        rows = rows if isinstance(rows, list) else []
        out += rows
        if len(rows) < PMUS_PAGE:
            break
    return out, first


# --- matching and pricing ------------------------------------------------------

def match(kalshi: list, pmus: list) -> list:
    """Same league, same two teams, same Eastern date. A game that more than one
    listing could be is priced as none of them: two games on one date (a
    doubleheader) cannot be told apart by team and date."""
    pairs = [(k, p) for k in kalshi for p in pmus
             if k.league == p.league and k.teams == p.teams and k.date == p.date]
    k_uses = {}
    p_uses = {}
    for k, p in pairs:
        k_uses[id(k)] = k_uses.get(id(k), 0) + 1
        p_uses[id(p)] = p_uses.get(id(p), 0) + 1
    return [(k, p) for k, p in pairs if k_uses[id(k)] == 1 and p_uses[id(p)] == 1]


#: How far under break-even, per contract, a quoted pair may sit and still be
#: worth a look at the order book. The market list's quote can be cents off its
#: book in either direction, so the screen is wide and the book decides.
SCREEN_SLACK = 0.03


def worth_a_book(pairs: list) -> set:
    """The (Polymarket US ref, team) legs whose quoted price is near enough to a
    profit, after both fees and before any rounding, to be worth a look at the
    order book. Only these games' books are read: a book per game on the venue
    would be hundreds of requests."""
    out = set()
    for k, p in pairs:
        a, b = k.teams
        for k_team, p_team in ((a, b), (b, a)):
            ka, pa = k.ask[k_team], p.ask[p_team]
            if k.size.get(k_team, 0) < 1 or p.long is None:
                continue
            unit = (k.fee_rate * ka * (1 - ka)) + (p.fee_rate * pa * (1 - pa))
            if 1.0 - ka - pa - unit > -SCREEN_SLACK:
                out.add((p.ref, p_team))
    return out


@dataclass
class Pairing:
    league: str
    teams: tuple
    game: str                         # 'Buffalo Sabres vs Dallas Stars'
    legs: list                        # [the Kalshi leg, the Polymarket US leg]
    contracts: int
    cost_per_pair: float              # the two asks added
    fees: float
    profit: float                     # after both fees, on `contracts`, whichever team wins
    margin: float                     # profit / money staked
    staked: float                     # both venues' cost and fees: what the pair takes to place
    limited_by: str                   # what set the size: 'kalshi', 'polymarket_us' or 'bankroll'
    kalshi_ref: str
    polymarket_us_ref: str
    read_at: float
    age: float                        # seconds since the oldest price here was read
    starts_at: float | None
    in_play: bool
    note: str

    def as_dict(self) -> dict:
        d = dict(self.__dict__)
        d["teams"] = list(self.teams)
        return d


def _sized(k: Game, p: Game, k_team: str, p_team: str, bankroll: float):
    """(contracts, what set the size) for one direction, or None when it cannot
    be placed: a size unknown or empty on either side, or less than the venue's
    smallest order. Whole contracts, fees inside the bankroll."""
    ka, pa = k.ask[k_team], p.ask[p_team]
    k_cap, p_cap = int(k.size.get(k_team) or 0), int(p.size.get(p_team) or 0)
    if k_cap < 1 or p_cap < 1 or bankroll <= 0:
        return None
    per = ka + pa
    unit = per + (k.fee_rate * ka * (1 - ka)) + (p.fee_rate * pa * (1 - pa))
    afford = int(bankroll / unit)
    limits = [("polymarket_us", p_cap), ("kalshi", k_cap), ("bankroll", afford)]
    who, c = min(limits, key=lambda x: x[1])
    # Rounding the Kalshi fee up to the cent can push the last contract over.
    while c >= 1 and c * per + k.fee(c, ka) + p.fee(c, pa) > bankroll + 1e-9:
        c -= 1
        who = "bankroll"
    if c < 1 or c < k.min_size or c < p.min_size:
        return None
    return c, who


def price_pairs(pairs: list, bankroll: float = 1000.0, now: float | None = None) -> list:
    """Both ways round for every matched game, after both venues' fees and at
    the size actually resting. Returns every pairing that can be placed,
    profitable or not, best margin first; the caller lists only those that pay.

    Ranked by margin, not dollars: a size-limited pairing earns few dollars
    on a fat margin, and sorted by dollars a four-contract pairing losing 18
    cents outranked a thousand-contract one simply for being small.
    """
    now = time.time() if now is None else now
    out = []
    for k, p in pairs:
        a, b = k.teams
        for k_team, p_team in ((a, b), (b, a)):
            sized = _sized(k, p, k_team, p_team, bankroll)
            if sized is None:
                continue
            c, who = sized
            ka, pa = k.ask[k_team], p.ask[p_team]
            kf, pf = k.fee(c, ka), p.fee(c, pa)
            cost = c * (ka + pa)
            profit = round(c * 1.0 - cost - kf - pf, 2)
            staked = round(cost + kf + pf, 2)
            stamps = [t for t in (k.read_at, p.read_at, p.depth_at.get(p_team)) if t]
            read_at = min(stamps) if stamps else now
            # Equal contracts on each side pay the same $1 whichever team wins
            # (and $0.50 each in an NFL tie), so the pair makes `profit` whichever team wins.
            out.append(Pairing(
                league=k.league, teams=(a, b),
                game=f"{team_name(k.league, a)} vs {team_name(k.league, b)}",
                legs=[
                    {"venue": "kalshi", "team": k_team, "name": team_name(k.league, k_team), "unit": "contracts",
                     "ask": ka, "cents": round(ka * 100, 2), "contracts": c, "on_offer": int(k.size.get(k_team, 0)),
                     "cost": round(c * ka, 2), "fee": kf, "if_wins": profit, "ref": k.ref},
                    {"venue": "polymarket_us", "team": p_team, "name": team_name(k.league, p_team),
                     "unit": "contracts", "ask": pa, "cents": round(pa * 100, 2), "contracts": c,
                     "on_offer": int(p.size.get(p_team, 0)), "cost": round(c * pa, 2), "fee": pf,
                     "if_wins": profit, "ref": p.ref},
                ],
                contracts=c, cost_per_pair=round(ka + pa, 4), fees=round(kf + pf, 2), profit=profit,
                margin=round(profit / staked, 5) if staked else 0.0, staked=staked, limited_by=who,
                kalshi_ref=k.ref, polymarket_us_ref=p.ref, read_at=read_at, age=max(0.0, round(now - read_at, 1)),
                starts_at=p.starts_at, in_play=p.starts_at is not None and p.starts_at <= now,
                note=RESIDUAL_RISK_NFL if k.league == "nfl" else RESIDUAL_RISK))
    out.sort(key=lambda r: (r.margin, r.profit), reverse=True)
    return out


# --- where the person is -----------------------------------------------------------

#: The two venues a live pair stands on, as catalog keys.
LIVE_VENUES = ("kalshi", "polymarket_us")
PICK_STATE = "Pick your state to see pairs you can place."


def _words(iso: str) -> str:
    """'2026-10-05' as 'Oct 5 2026'."""
    d = dt.date.fromisoformat(iso)
    return f"{d.strftime('%b')} {d.day} {d.year}"


def _cite(sources) -> str:
    return "(" + "; ".join(f"{s.name}, {_words(s.published)}" for s in sources) + ")"


def _groups(rows: list) -> list:
    """[(venue keys, sources)] with venues that rest on the same sources together."""
    out: dict = {}
    for key, sources in rows:
        out.setdefault(tuple((s.name, s.published) for s in sources), ([], sources))[0].append(key)
    return list(out.values())


def _venue_names(keys) -> str:
    return " and ".join(catalog.VENUES[k].name for k in keys)


def _possessive(keys) -> str:
    return " and ".join(catalog.VENUES[k].name + "'s" for k in keys)


@dataclass
class StateGate:
    """What the dated sources say about the two venues where a person is."""
    state: str | None
    unavailable: list                 # one dict per venue whose sports contracts are restricted there
    notes: list                       # plain lines for venues that operate while a case is under way
    message: str                      # why nothing is shown, or ""


def state_gate(state: str | None) -> StateGate:
    """The venues unavailable in a state, with the source and date behind each, and
    the plain sentence for them. With no state, no venue is unavailable, and the scan
    asks for one. A state this version has no name for is refused by the caller."""
    st = (state or "").strip().upper() or None
    if st is None:
        return StateGate(None, [], [], "")
    if st not in catalog.STATE_NAMES:
        raise ValueError(f"{state!r} is not a US state code")
    name = catalog.STATE_NAMES[st]
    blocked, contested = [], []
    for key in LIVE_VENUES:
        found = catalog.state_status(key, st)
        if found is None:
            continue
        row, sources = found
        (blocked if row.kind == "restricted" else contested).append((key, sources))
    unavailable = [{
        "venue": key, "name": catalog.VENUES[key].name, "state": st, "state_name": name, "kind": "restricted",
        "sources": [{"name": s.name, "date": s.published, "read": s.read, "url": s.url} for s in sources],
    } for key, sources in blocked]
    message = ""
    if blocked:
        clauses = [f"{_possessive(keys)} sports contracts are not open in {name} {_cite(sources)}"
                   for keys, sources in _groups(blocked)]
        message = (f"{clauses[0]}, so live pairs are hidden there." if len(clauses) == 1
                   else ". ".join(clauses) + ". Live pairs are hidden there.")
    notes = []
    if not blocked:
        for keys, sources in _groups(contested):
            verb = "decide" if len(keys) > 1 else "decides"
            notes.append(f"Prediction markets are being challenged in court in {name} {_cite(sources)}. "
                         f"{_venue_names(keys)} {verb} at sign-up whether you can trade there.")
    return StateGate(st, unavailable, notes, message)


# --- the scan --------------------------------------------------------------------

@dataclass
class Scan:
    """Everything one press of Find arbs reads, and what it came to."""
    read_at: float
    bankroll: float
    leagues: dict                      # league -> {kalshi_games, polymarket_us_games, matched}
    priced: int                        # pairings that could be placed at a size
    pairs: list                        # the Pairings that pay, best margin first
    errors: list
    min_margin: float = 0.0
    state: str | None = None
    ran: bool = True                   # False when the state meant nothing was read
    unavailable: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    message: str = ""                  # why no pair is shown, when that is the state's doing

    @property
    def needs_state(self) -> bool:
        return self.state is None and self.ran

    @property
    def kalshi_games(self) -> int:
        return sum(v["kalshi_games"] for v in self.leagues.values())

    @property
    def polymarket_us_games(self) -> int:
        return sum(v["polymarket_us_games"] for v in self.leagues.values())

    @property
    def matched(self) -> int:
        return sum(v["matched"] for v in self.leagues.values())

    @property
    def read_anything(self) -> bool:
        return bool(self.kalshi_games or self.polymarket_us_games)

    def source(self) -> str:
        if not self.ran:
            return f"NOT READ — {self.message}"
        head = (f"LIVE — {self.kalshi_games} Kalshi games and {self.polymarket_us_games} Polymarket US games read, "
                f"{self.matched} on both")
        if self.needs_state:
            return f"{head}; {PICK_STATE[0].lower() + PICK_STATE[1:]}"
        return f"{head}, {len(self.pairs)} playable"

    def as_dict(self) -> dict:
        return {
            "read_at": self.read_at, "bankroll": self.bankroll, "min_margin": self.min_margin,
            "leagues": self.leagues, "kalshi_games": self.kalshi_games,
            "polymarket_us_games": self.polymarket_us_games,
            "matched": self.matched, "priced": self.priced, "playable": len(self.pairs),
            "pairs": [r.as_dict() for r in self.pairs], "errors": self.errors, "read_anything": self.read_anything,
            "fees_read": FEES_READ, "fee_sources": list(FEE_SOURCES),
            "state": self.state, "needs_state": self.needs_state, "ran": self.ran,
            "unavailable": self.unavailable, "state_notes": self.notes,
            "message": self.message or None,
        }


def _gather(tasks: dict) -> dict:
    """Run named reads side by side: name -> (ok, value or the plain reason, exception)."""
    from concurrent.futures import ThreadPoolExecutor

    names = list(tasks)
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(lambda n: _attempt(lambda _: tasks[n](), n), names))
    return dict(zip(names, results))


def scan(fetch, bankroll: float = 1000.0, min_margin: float = 0.0, leagues=LEAGUES, clock=time.time,
         state: str | None = None) -> Scan:
    """Read Kalshi and Polymarket US for each league, match the games, look at the
    order book behind every game that could pay, and price every pairing at the
    size resting. `min_margin` is a fraction (0.01 for 1%).

    `state` is where the person is. Where either venue's sports contracts are
    restricted, `fetch` is never called and the answer says why. With no state the
    scan runs, for what it read, and lists no pair: one that cannot be placed is the
    error that matters. Every read is its own failure: one league or one book that
    cannot be read is named in `errors` and the rest still count."""
    gate = state_gate(state)
    if gate.unavailable:
        return Scan(clock(), bankroll, {}, 0, [], [], min_margin, state=gate.state, ran=False,
                    unavailable=gate.unavailable, message=gate.message)

    errors: list[str] = []
    started = clock()

    first = {}
    for lg in leagues:
        first[f"k:{lg}"] = (lambda lg=lg: kalshi_events(fetch, KALSHI_SERIES[lg], clock))
        first[f"f:{lg}"] = (lambda lg=lg: kalshi_fee_rate(fetch, lg))
    first["sports"] = lambda: fetch(PMUS_SPORTS)
    got = _gather(first)

    kalshi: dict = {}
    for lg in leagues:
        ok, ev, _ = got[f"k:{lg}"]
        if not ok:
            errors.append(f"Kalshi {lg.upper()} prices could not be read ({ev})")
            continue
        ok_fee, rate, why = got[f"f:{lg}"]
        if isinstance(why, UnknownFee):
            # A formula this version does not have: guessing one prices a fee that is not charged.
            errors.append(f"Kalshi's {lg.upper()} games are not priced: their fee schedule is one this version does not know")
            continue
        if not ok_fee:
            rate = KALSHI_TAKER_RATE * KALSHI_FEE_MULTIPLIER[lg]
            errors.append(f"Kalshi's {lg.upper()} fee schedule could not be read ({rate / KALSHI_TAKER_RATE:g}x "
                          f"the standard rate, as recorded {FEES_READ}, was charged)")
        kalshi[lg] = kalshi_games(ev[0], lg, fee_rate=rate, read_at=ev[1])

    ok, sports, _ = got["sports"]
    tags = pmus_league_tags(sports) if ok else {}
    if not ok:
        errors.append(f"Polymarket US's list of leagues could not be read ({sports})")
    second = {}
    for lg in leagues:
        if lg in tags:
            second[f"p:{lg}"] = (lambda lg=lg: pmus_markets(fetch, tags[lg], clock))
        elif ok:
            errors.append(f"Polymarket US lists no {lg.upper()} games")
    got2 = _gather(second)

    pmus: dict = {}
    for lg in leagues:
        if f"p:{lg}" not in got2:
            continue
        ok, mk, _ = got2[f"p:{lg}"]
        if not ok:
            errors.append(f"Polymarket US {lg.upper()} prices could not be read ({mk})")
            continue
        if len(mk[0]) >= PMUS_MAX_PAGES * PMUS_PAGE:
            errors.append(f"Polymarket US lists more {lg.upper()} games than this version reads")
        pmus[lg] = pmus_games({"markets": mk[0]}, lg, read_at=mk[1])

    pairs, counts = [], {}
    for lg in leagues:
        k, p = kalshi.get(lg, []), pmus.get(lg, [])
        found = match(k, p)
        pairs += found
        counts[lg] = {"kalshi_games": len(k), "polymarket_us_games": len(p), "matched": len(found)}

    wanted = worth_a_book(pairs)
    if wanted:
        errors += add_pmus_depth(fetch, [p for _, p in pairs], wanted, clock)

    finished = clock()
    priced = price_pairs(pairs, bankroll=bankroll, now=finished)
    playable = [r for r in priced if r.profit > 0 and r.margin >= min_margin]
    out = Scan(finished, bankroll, counts, len(priced), playable, errors, min_margin, state=gate.state,
               notes=gate.notes)
    if gate.state is None:
        out.pairs, out.message = [], PICK_STATE
    return out
