"""The EV formula: the books you trust, weighted, as your own true price (OddsJam parity matrix row 20).

A bettor names the sharp books they trust, gives each a weight from 0 to 10, and sets how much of that weight must
have priced a market before a +EV bet in it is shown. These pin:

  * **The rule.** The fair price of a market is the engine's own log-odds blend of just the formula books that priced
    both sides, weighted as the person said, and a +EV bet is kept only when the weight of those books over the total
    weight reaches the threshold. A book the formula does not name sets nothing, a book that quoted one side is absent,
    and the book you would bet at is left out of its own price.
  * **No formula is today's board.** All weights 0, a formula held by Recommended, and no formula at all give the same
    rows, filters and details on the same stored read, byte for byte; and a board sent no formula carries no formula
    key anywhere.
  * **Nothing is spent.** The formula reads no price of its own: the same requests go out with and without it. A formula
    book in a region the person did not pick is absent, and the engine says what picking it would cost and changes
    nothing.
  * **Only books the feed can send.** Pinnacle and BetOnline are in The Odds API; Circa and BookMaker are not, so they
    are said to be left out and are not keys anywhere.
  * **A setting is bounded.** Unknown books are dropped, weights and the threshold clamped, and text that cannot be read
    is no formula with a one-line notice.
  * **The window** keeps it on this Mac, greys the panel under Recommended, draws the engine's words and works out
    nothing, and the filter counts carry the formula's effect.
"""

import contextlib
import io
import json
import math
import re
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

import test_oddsapi as to  # noqa: E402
from overlay_engine import board as board_mod  # noqa: E402
from overlay_engine import cli, filtercounts, formula, keystore, oddsapi, oddshistory  # noqa: E402
from overlay_engine.devig import devig_all  # noqa: E402
from overlay_engine.detail import FairCache, row_detail  # noqa: E402
from overlay_engine.ev import find_edges  # noqa: E402
from overlay_engine.models import Market, Outcome, Quote  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
JS = (ROOT / "ui" / "src" / "app.js").read_text()
CSS = (ROOT / "ui" / "src" / "app.css").read_text()
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way", "free bet", "—")

NOW = 1000.0
BOOKS = oddsapi.books_table()


@pytest.fixture(autouse=True)
def throwaway_home(monkeypatch, tmp_path):
    """Never the real ~/.overlay."""
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for k, v in value.items():
            yield str(k)
            yield from strings(v)
    elif isinstance(value, list):
        for v in value:
            yield from strings(v)


def market(prices: dict, event: str = "g", market_type: str = "h2h") -> Market:
    """One two-sided market. `prices` is book -> (home, away); a None side is a book that quoted only one side."""
    quotes = []
    for book, (home, away) in prices.items():
        for side, price in (("home", home), ("away", away)):
            if price is not None:
                quotes.append(Quote(book, Outcome(side), price, NOW - 3))
    return Market(event, "nfl", market_type, quotes, NOW + 3600)


def setting(weights: dict, threshold: int = 50, paused: bool = False):
    return formula.parse(json.dumps({"weights": weights, "threshold": threshold}), paused=paused)


def scan(markets, formula_=None, **kw):
    return board_mod.scan(markets, BOOKS, now=NOW, kinds=("ev",), formula=formula_, **kw)


def books_of(rows):
    return [r.legs[0]["book"] for r in rows]


#: Pinnacle and BetOnline agree at 1.95 / 1.95 and about 1.93 / 1.97; DraftKings and FanDuel are off them.
SHARP = {"pinnacle": (1.95, 1.95), "betonlineag": (1.93, 1.97)}
RETAIL = {"dk": (2.15, 1.75), "fd": (1.80, 2.10)}
FULL = market({**SHARP, **RETAIL})


# ================================================================ 1. a setting is bounded and checked

def test_a_good_setting_is_read_as_sent():
    s = formula.parse('{"weights": {"pinnacle": 2, "betonlineag": 1}, "threshold": 60}')
    assert s.notice == "" and s.threshold == 60
    assert s.built().weights == (("betonlineag", 1), ("pinnacle", 2)) and s.built().total == 3


def test_weights_are_clamped_to_zero_through_ten_and_the_threshold_to_zero_through_a_hundred():
    s = formula.parse('{"weights": {"pinnacle": 99, "betonlineag": -4, "kalshi": 3.6}, "threshold": 250}')
    assert s.weights["pinnacle"] == 10 and s.weights["betonlineag"] == 0 and s.weights["kalshi"] == 4
    assert s.threshold == 100
    assert formula.parse('{"weights": {}, "threshold": -5}').threshold == 0


def test_the_threshold_is_fifty_percent_unless_changed():
    assert formula.parse('{"weights": {"pinnacle": 1}}').threshold == 50 == formula.DEFAULT_THRESHOLD
    assert formula.parse(None).threshold == 50


def test_a_book_the_feed_cannot_send_is_dropped_with_a_notice():
    s = formula.parse('{"weights": {"pinnacle": 2, "circa": 5, "bookmaker": 5, "nonsense": 1}}')
    assert s.built().keys() == ("pinnacle",)
    assert "3 parts of your saved formula could not be used" in s.notice and "\n" not in s.notice


@pytest.mark.parametrize("text", [
    "", "{", "[]", "null", "5", '"x"', "true", '{"weights": []}', '{"weights": "x"}', '{"weights": 4}',
    "[" * 20000, "[" * 3000, '{"weights":' * 1500, '{"weights": {"pinnacle": 1}}' + " " * formula.MAX_TEXT, "\x00\x01", "\ud800", "{'a': 1}",
])
def test_text_that_cannot_be_read_is_no_formula_and_one_line_not_a_crash(text):
    s = formula.parse(text)
    assert s.built() is None and s.formula is None
    assert s.notice == formula.NOTICE_UNREADABLE and "\n" not in s.notice


def test_a_weight_that_is_not_a_number_is_dropped_and_a_book_is_not_a_bool():
    s = formula.parse('{"weights": {"pinnacle": true, "betonlineag": "3", "kalshi": NaN, "dk": Infinity, "fd": null, "mgm": 2}}')
    assert s.built().keys() == ("mgm",)
    assert "5 parts" in s.notice


def test_the_extra_book_cards_are_bounded_checked_and_not_repeated():
    keys = ["kalshi", "kalshi", "nope", 7] + [b.key for b in formula.BOOKS]
    s = formula.parse(json.dumps({"weights": {}, "shown": keys}))
    assert len(s.shown) <= formula.MAX_SHOWN and len(set(s.shown)) == len(s.shown)
    assert all(k in formula.BY_KEY for k in s.shown)


def test_no_text_is_not_a_malformed_setting_and_all_zero_is_no_formula():
    assert formula.parse(None).notice == "" and formula.parse(None).built() is None
    assert formula.parse('{"weights": {"pinnacle": 0, "betonlineag": 0}}').built() is None


def test_a_formula_held_by_recommended_is_no_formula_to_price_with():
    held = setting({"pinnacle": 2}, paused=True)
    assert held.built() is not None and held.formula is None


# ================================================================ 2. the books a formula may use

def test_only_books_the_odds_api_can_send_are_offered_and_circa_and_bookmaker_are_not():
    keys = {b.key for b in formula.BOOKS}
    assert {"pinnacle", "betonlineag"} <= keys
    assert not keys & {"circa", "bookmaker", "circasports", "bookmaker_eu"}
    # Each key is one the engine already knows from the feed, or the Odds API's own key for BetOnline.
    assert keys <= set(BOOKS) | {"betonlineag"}
    for b in formula.BOOKS:
        assert b.regions and set(b.regions) <= set(oddsapi.REGIONS), b.key
    names = {x["name"] for x in formula.NOT_IN_FEED}
    assert names == {"Circa", "BookMaker"}
    for x in formula.NOT_IN_FEED:
        assert "not in The Odds API" in x["why"]


def test_the_preset_cards_are_the_two_in_the_feed_in_the_order_openers_show_them():
    cards = formula.panel(formula.parse(None))["books"]
    assert [c["key"] for c in cards] == ["pinnacle", "betonlineag"] and all(c["preset"] for c in cards)
    assert all(c["weight"] == 0 and c["share_text"] == "0%" for c in cards)


# ================================================================ 3. the shares, the steppers, the Requires line

def test_two_and_one_are_sixty_six_point_seven_and_thirty_three_point_three_percent():
    cards = {c["key"]: c for c in formula.panel(setting({"pinnacle": 2, "betonlineag": 1}))["books"]}
    assert cards["pinnacle"]["share_text"] == "66.7%" and cards["betonlineag"]["share_text"] == "33.3%"
    assert math.isclose(cards["pinnacle"]["share"], 2 / 3)


def test_a_stepper_goes_up_and_down_by_one_and_stops_at_zero_and_ten():
    cards = {c["key"]: c for c in formula.panel(setting({"pinnacle": 10, "betonlineag": 0, "kalshi": 4}))["books"]}
    assert cards["pinnacle"]["plus"] == 10 and cards["pinnacle"]["can_plus"] is False and cards["pinnacle"]["minus"] == 9
    assert cards["betonlineag"]["minus"] == 0 and cards["betonlineag"]["can_minus"] is False
    assert cards["betonlineag"]["plus"] == 1 and cards["betonlineag"]["can_plus"] is True
    assert cards["kalshi"]["minus"] == 3 and cards["kalshi"]["plus"] == 5


def test_a_book_the_person_added_has_a_card_and_can_be_removed_only_at_zero():
    s = formula.parse('{"weights": {}, "shown": ["kalshi"]}')
    cards = {c["key"]: c for c in formula.panel(s)["books"]}
    assert cards["kalshi"]["removable"] is True and cards["pinnacle"]["removable"] is False
    assert "kalshi" not in {m["key"] for m in formula.panel(s)["more"]}
    held = {c["key"]: c for c in formula.panel(formula.parse('{"weights": {"kalshi": 2}}'))["books"]}
    assert held["kalshi"]["removable"] is False, "a book with weight keeps its card"


@pytest.mark.parametrize("weights, threshold, line", [
    ({"pinnacle": 2, "betonlineag": 1}, 50, "Requires Pinnacle."),
    ({"pinnacle": 2, "betonlineag": 1}, 100, "Requires BetOnline and Pinnacle."),
    ({"pinnacle": 2, "betonlineag": 1}, 0, "Requires at least one of your formula's books."),
    ({"pinnacle": 1, "betonlineag": 1}, 50, "Requires books that add up to at least 50% of the weight; no one book is needed on its own."),
    ({"pinnacle": 3, "betonlineag": 1, "kalshi": 1}, 90,
     "Requires BetOnline, Kalshi and Pinnacle."),
    ({"pinnacle": 4, "betonlineag": 1, "kalshi": 1}, 80,
     "Requires Pinnacle, and enough of the others to reach 80% of the weight."),
    ({"pinnacle": 2}, 50, "Requires Pinnacle."),
])
def test_the_requires_line_names_the_books_without_which_the_threshold_cannot_be_reached(weights, threshold, line):
    assert formula.requires(setting(weights, threshold).built()) == line


def test_there_is_no_requires_line_without_a_formula():
    assert formula.requires(None) == "" and formula.panel(formula.parse(None))["requires"] == ""


def test_the_threshold_reads_any_book_to_all_books_with_fifty_percent_by_default():
    t = formula.panel(formula.parse(None))["threshold"]
    assert (t["min"], t["max"], t["value"], t["text"]) == (0, 100, 50, "50%")
    assert (t["min_text"], t["max_text"]) == ("Any book", "All books")
    assert t["label"] == "Only show bets when book weights reach this threshold"
    assert formula.threshold_text(0) == "Any book" and formula.threshold_text(100) == "All books"


# ================================================================ 4. the rule

def _independent_blend(prices: dict, weights: dict, outcome: int) -> float:
    """The weighted log-odds blend of each formula book's own devigged probability, worked out here from the devig."""
    total = sum(weights.values())
    acc = 0.0
    for book, w in weights.items():
        spread = devig_all(list(prices[book]))
        p = spread.consensus(outcome)
        acc += (w / total) * math.log(p / (1 - p))
    return 1 / (1 + math.exp(-acc))


def test_the_fair_price_is_the_weighted_blend_of_the_formula_books_and_nothing_else():
    s = setting({"pinnacle": 2, "betonlineag": 1})
    edges = find_edges(FULL, BOOKS, NOW, formula=s.formula)
    dk_home = next(e for e in edges if e.book == "dk" and e.outcome == "home")
    assert math.isclose(dk_home.fair_prob, _independent_blend(SHARP, {"pinnacle": 2, "betonlineag": 1}, 0), rel_tol=1e-9)
    # Not the engine's own tiered blend, which gives BetOnline no say and DraftKings and FanDuel a little.
    own = next(e for e in find_edges(FULL, BOOKS, NOW) if e.book == "dk" and e.outcome == "home")
    assert not math.isclose(dk_home.fair_prob, own.fair_prob, rel_tol=1e-4)


def test_weights_change_the_price_in_the_direction_of_the_heavier_book():
    pin_heavy = find_edges(FULL, BOOKS, NOW, formula=setting({"pinnacle": 9, "betonlineag": 1}).formula)
    bol_heavy = find_edges(FULL, BOOKS, NOW, formula=setting({"pinnacle": 1, "betonlineag": 9}).formula)
    pick = lambda edges: next(e for e in edges if e.book == "dk" and e.outcome == "home").fair_prob  # noqa: E731
    assert pick(pin_heavy) != pick(bol_heavy)
    pinnacle_only = _independent_blend(SHARP, {"pinnacle": 1}, 0)
    betonline_only = _independent_blend(SHARP, {"betonlineag": 1}, 0)
    lo, hi = sorted((pinnacle_only, betonline_only))
    assert lo <= pick(pin_heavy) <= hi and lo <= pick(bol_heavy) <= hi
    assert abs(pick(pin_heavy) - pinnacle_only) < abs(pick(bol_heavy) - pinnacle_only)


def test_a_book_the_formula_does_not_name_sets_nothing():
    s = setting({"pinnacle": 2, "betonlineag": 1})
    base = next(e for e in find_edges(FULL, BOOKS, NOW, formula=s.formula) if e.book == "dk" and e.outcome == "home")
    moved = market({**SHARP, "dk": (2.15, 1.75), "fd": (1.30, 3.60), "mgm": (1.50, 2.60)})
    again = next(e for e in find_edges(moved, BOOKS, NOW, formula=s.formula) if e.book == "dk" and e.outcome == "home")
    assert again.fair_prob == base.fair_prob


def test_a_book_in_the_formula_that_quoted_one_side_is_absent():
    one_sided = market({"pinnacle": (1.95, 1.95), "betonlineag": (1.93, None), "dk": (2.15, 1.75)})
    fairs, pres = formula.blended(one_sided, BOOKS, setting({"pinnacle": 2, "betonlineag": 1}).built())
    assert pres.present == ("pinnacle",) and pres.missing == ("betonlineag",)
    assert math.isclose(pres.share, 2 / 3) and pres.meets
    held = setting({"pinnacle": 2, "betonlineag": 1}, threshold=67)
    assert scan([one_sided], held.formula) == [], "66.7% present is under a 67% threshold"
    assert books_of(scan([one_sided], setting({"pinnacle": 2, "betonlineag": 1}, 66).formula)) == ["dk"]


@pytest.mark.parametrize("threshold, shown", [(0, True), (33, True), (34, False), (50, False), (66, False), (100, False)])
def test_a_bet_is_shown_only_when_the_weight_present_reaches_the_threshold(threshold, shown):
    """BetOnline (weight 1 of 3) is the only formula book that priced it: a share of one third."""
    only = market({"betonlineag": (1.93, 1.97), "dk": (2.15, 1.75)})
    rows = scan([only], setting({"pinnacle": 2, "betonlineag": 1}, threshold).formula)
    assert bool(rows) is shown


def test_the_share_reaches_a_threshold_on_the_nose_without_rounding_it_away():
    assert formula.meets(2 / 3, 66) and not formula.meets(2 / 3, 67)
    assert formula.meets(1 / 3, 33) and not formula.meets(1 / 3, 34)
    assert formula.meets(1.0, 100) and formula.meets(0.5, 50) and formula.meets(0.0, 0)


def test_all_books_needs_every_formula_book_to_have_priced_the_market():
    s = setting({"pinnacle": 1, "betonlineag": 1, "kalshi": 1}, 100)
    assert scan([FULL], s.formula) == []
    full = market({**SHARP, "kalshi": (1.94, 1.96), **RETAIL})
    assert set(books_of(scan([full], s.formula))) == {"dk", "fd"}


def test_any_book_still_needs_one_book_because_with_none_there_is_no_price():
    none_priced = market({"dk": (2.15, 1.75), "fd": (1.80, 2.10)})
    assert scan([none_priced], setting({"pinnacle": 1, "betonlineag": 1}, 0).formula) == []
    assert scan([market({"betonlineag": (1.93, 1.97), **RETAIL})], setting({"pinnacle": 1, "betonlineag": 1}, 0).formula)


def test_the_book_you_would_bet_at_is_left_out_of_its_own_price_and_its_weight_is_not_counted_present():
    both = market({**SHARP, "dk": (2.15, 1.75)})
    s = setting({"pinnacle": 2, "betonlineag": 1, "dk": 1}, threshold=70)
    fairs, pres = formula.blended(both, BOOKS, s.built(), left_out="dk")
    assert pres.left_out == "dk" and "dk" not in pres.present
    assert math.isclose(pres.share, 3 / 4) and pres.meets
    # Betting at Pinnacle itself: only BetOnline and DraftKings are left, a share of 2 of 4.
    _, at_pin = formula.blended(both, BOOKS, s.built(), left_out="pinnacle")
    assert at_pin.present == ("betonlineag", "dk") and math.isclose(at_pin.share, 2 / 4) and not at_pin.meets
    rows = scan([both], s.formula)
    assert "pinnacle" not in books_of(rows)
    fair = _independent_blend({**SHARP, "dk": (2.15, 1.75)}, {"pinnacle": 2, "betonlineag": 1}, 0)
    dk = next(e for e in find_edges(both, BOOKS, NOW, formula=s.formula) if e.book == "dk" and e.outcome == "home")
    assert math.isclose(dk.fair_prob, fair, rel_tol=1e-9), "DraftKings' own 1 point is not in DraftKings' price"


def test_a_book_the_engine_has_no_tier_for_counts_as_a_sharp_one_only_inside_a_formula():
    assert "betonlineag" not in BOOKS or BOOKS["betonlineag"].tier.value == "unknown"
    default = scan([FULL])
    assert books_of(default) == books_of(scan([market({**{"pinnacle": SHARP["pinnacle"]}, **RETAIL})]))
    assert [round(r.margin, 9) for r in default] == [round(r.margin, 9) for r in scan(
        [market({"pinnacle": SHARP["pinnacle"], **RETAIL})])], "BetOnline moves nothing outside a formula"
    with_it = scan([FULL], setting({"betonlineag": 1}).formula)
    assert with_it and [round(r.margin, 9) for r in with_it] != [round(r.margin, 9) for r in default]


def test_a_formula_does_not_touch_arbs_or_middles():
    arb = market({"dk": (2.20, 1.70), "fd": (1.70, 2.20), **SHARP})
    plain = board_mod.scan([arb], BOOKS, now=NOW, kinds=("arb",))
    held = board_mod.scan([arb], BOOKS, now=NOW, kinds=("arb",), formula=setting({"betonlineag": 1}).formula)
    assert [r.as_dict() for r in plain] == [r.as_dict() for r in held] and plain


# ================================================================ 5. no formula is today's board

def _dump(rows):
    return json.dumps([r.as_dict() for r in rows], sort_keys=True, default=str)


@pytest.mark.parametrize("sent", [
    pytest.param(None, id="none"),
    pytest.param('{"weights": {}}', id="no weights"),
    pytest.param('{"weights": {"pinnacle": 0, "betonlineag": 0}, "threshold": 90}', id="all zero"),
    pytest.param('{"weights": {"pinnacle": 3}, "paused": 1}', id="held"),
])
def test_all_weights_zero_or_held_gives_exactly_todays_rows_and_details(sent):
    markets = [FULL, market({**SHARP, **RETAIL}, event="g2", market_type="totals")]
    base = _dump(board_mod.scan(markets, BOOKS, now=NOW, detail=True, names={"dk": "DraftKings"}))
    s = formula.parse(sent, paused=sent is not None and "paused" in sent)
    got = _dump(board_mod.scan(markets, BOOKS, now=NOW, detail=True, names={"dk": "DraftKings"}, formula=s.formula))
    assert got == base and base != "[]"


def test_a_formula_changes_the_rows_so_the_comparison_above_can_fail():
    markets = [FULL]
    base = _dump(board_mod.scan(markets, BOOKS, now=NOW, detail=True))
    got = _dump(board_mod.scan(markets, BOOKS, now=NOW, detail=True, formula=setting({"betonlineag": 1}).formula))
    assert got != base


def _formula_world():
    def b(key, home, away):
        return to.book(key, home, away)
    return [to.event("g1", [b("draftkings", 2.15, 1.75), b("fanduel", 1.80, 2.10), b("betmgm", 1.95, 1.90),
                            b("pinnacle", 1.95, 1.95), b("betonlineag", 1.93, 1.97)])]


class RegionApi(to.FakeApi):
    """The Odds API sends a book only in the regions that carry it: Pinnacle in eu, BetOnline in us and eu."""

    SENT_IN = {"pinnacle": {"eu"}, "betonlineag": {"us", "eu"}}

    def __call__(self, path, params):
        payload, headers = super().__call__(path, params)
        asked = set(params["regions"].split(","))
        return [{**ev, "bookmakers": [b for b in ev["bookmakers"] if self.SENT_IN.get(b["key"], {"us"}) & asked]}
                for ev in payload], headers


@pytest.fixture
def feed(monkeypatch):
    """The Odds API with a fake fetcher and a fixed clock; each call gets its own home so no cache is shared."""
    state = SimpleNamespace(api=None)

    def run(tmp_path, tag, *argv):
        monkeypatch.setenv("OVERLAY_HOME", str(tmp_path / tag))
        state.api = RegionApi({"americanfootball_nfl": _formula_world()})
        monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: state.api)
        monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=to.Clock()))
        monkeypatch.setattr(keystore, "get_key", lambda runner=None: to.KEY)
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--market", "h2h", *argv, "--json"])
        return code, json.loads(out.getvalue()), state.api
    return run


def test_a_board_read_with_no_formula_is_the_same_as_one_with_all_zero_or_a_held_formula(feed, tmp_path):
    _, base, _ = feed(tmp_path, "a")
    _, zero, _ = feed(tmp_path, "b", "--formula", '{"weights": {"pinnacle": 0}}')
    _, held, _ = feed(tmp_path, "c", "--formula", '{"weights": {"pinnacle": 4, "betonlineag": 1}}', "--formula-paused")
    assert "formula" not in zero["filters"]
    # A held formula adds one line to the counts saying it is held, and changes no row.
    assert held["filters"].pop("formula")["paused"] is True
    for other in (zero, held):
        other = dict(other)
        sent = other.pop("formula")
        assert sent["active"] is False
        assert json.dumps(other, sort_keys=True) == json.dumps(base, sort_keys=True)


def test_the_same_stored_read_gives_the_same_board_with_no_formula_zero_weights_or_held(tmp_path, monkeypatch):
    """Read once, then rebuild the markets from what the read left on this Mac and scan them three ways."""
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path / "stored"))
    api = to.FakeApi({"americanfootball_nfl": _formula_world()})
    got = oddsapi.refresh(to.est("nfl", markets=["h2h"]), to.KEY, clock=to.Clock(), fetcher=api)
    stored = oddshistory.latest(oddshistory.history_folder(), now=to.NOW)
    assert stored, "the read must have left something on this Mac"
    markets = oddsapi.split_by_line([m for snap in stored for m in oddshistory.to_markets(snap)])
    assert len(markets) == len(oddsapi.split_by_line(got.markets))
    names = {"dk": "DraftKings"}
    plain = board_mod.scan(markets, BOOKS, now=to.NOW, detail=True, names=names, bettable=set(oddsapi.BETTABLE))
    for text, paused in ((None, False), ('{"weights": {}}', False), ('{"weights": {"pinnacle": 3}}', True)):
        s = formula.parse(text, paused=paused)
        again = board_mod.scan(markets, BOOKS, now=to.NOW, detail=True, names=names, bettable=set(oddsapi.BETTABLE),
                               formula=s.formula)
        assert _dump(again) == _dump(plain)
    assert any(r.kind == "ev" for r in plain)
    live = board_mod.scan(markets, BOOKS, now=to.NOW, detail=True, names=names, bettable=set(oddsapi.BETTABLE),
                          formula=setting({"betonlineag": 1}).formula)
    assert _dump(live) != _dump(plain)


def test_a_board_sent_no_formula_carries_no_formula_key_anywhere(feed, tmp_path):
    _, out, _ = feed(tmp_path, "none")
    assert "formula" not in out and "formula" not in out["filters"]
    assert all("formula" not in (r["detail"] or {}) for r in out["rows"])


# ================================================================ 6. a read with a formula

FORMULA = '{"weights": {"pinnacle": 2, "betonlineag": 1}, "threshold": 50}'


def test_a_read_with_a_formula_prices_ev_bets_against_it_and_says_so(feed, tmp_path):
    _, base, _ = feed(tmp_path, "a")
    code, out, _ = feed(tmp_path, "b", "--formula", FORMULA)
    assert code == 0
    ev = [r for r in out["rows"] if r["kind"] == "ev"]
    assert ev and [r["kind"] for r in out["rows"] if r["kind"] != "ev"] == [r["kind"] for r in base["rows"] if r["kind"] != "ev"]
    blk = out["formula"]
    assert blk["active"] is True and blk["requires"] == "Requires Pinnacle."
    assert blk["sentence"].startswith("Priced with your EV formula.")
    assert [r["margin"] for r in ev] != [r["margin"] for r in base["rows"] if r["kind"] == "ev"], "the formula's price, not ours"
    for r in ev:
        d = r["detail"]["formula"]
        assert d["active"] and d["meets"] and {b["book"] for b in d["books"]} == {"pinnacle", "betonlineag"}
        assert d["present_text"] == "100%" and d["books"][0]["book"] == "pinnacle"
        assert "Your EV formula sets this price" in r["detail"]["fair"]["text"]


def test_each_ev_rows_own_ev_is_the_line_for_its_book_in_its_own_detail(feed, tmp_path):
    _, out, _ = feed(tmp_path, "b", "--formula", FORMULA)
    ev = [r for r in out["rows"] if r["kind"] == "ev"]
    assert ev
    for r in ev:
        mine = [x for blk in r["detail"]["ev_by_book"] for x in blk["rows"] if x["mine"]]
        assert mine and math.isclose(mine[0]["ev"], r["margin"], rel_tol=1e-9)


def test_the_filter_counts_carry_the_formulas_effect(feed, tmp_path):
    _, plain, _ = feed(tmp_path, "a")
    _, out, _ = feed(tmp_path, "b", "--formula", FORMULA)
    f = out["filters"]
    assert f["total"] == len(out["rows"])
    block = f["formula"]
    shown = sum(1 for r in out["rows"] if r["kind"] == "ev")
    assert block["active"] and block["shown"] == shown and block["without"] == sum(1 for r in plain["rows"] if r["kind"] == "ev")
    assert block["left_out"] == 0 and block["text"].startswith(f"{shown} +EV bet")
    assert out["filters"]["formula"]["text"] in out["formula"]["sentence"]
    # A threshold nothing can reach (BetOnline only, 50%) leaves bets out, and the count says how many.
    _, tight, _ = feed(tmp_path, "c", "--formula", '{"weights": {"kalshi": 1, "betonlineag": 1}, "threshold": 100}')
    t = tight["filters"]["formula"]
    assert t["shown"] == 0 and t["left_out"] >= 1 and t["without"] == block["without"]
    assert f"{t['left_out']} +EV bet" in t["text"] and "left out because too little of your formula's weight" in t["text"]
    assert tight["filters"]["total"] == len(tight["rows"]) == len(plain["rows"]) - block["without"]


def test_the_counts_say_when_recommended_holds_the_formula():
    s = setting({"pinnacle": 2}, paused=True)
    block = formula.counts(s, {})
    assert block["active"] is False and block["paused"] is True and "Held by Recommended" in block["text"]
    assert formula.counts(formula.parse(None), {}) is None
    assert formula.counts(formula.parse('{"weights": {}}'), {}) is None


def test_the_filter_counts_module_adds_the_block_only_when_given_one():
    assert "formula" not in filtercounts.build([])
    assert filtercounts.build([], formula={"text": "x"})["formula"] == {"text": "x"}


def test_a_formula_spends_no_credits_and_asks_for_the_same_regions_and_bet_types(feed, tmp_path):
    _, _, plain_api = feed(tmp_path, "a", "--region", "us")
    _, _, api = feed(tmp_path, "b", "--region", "us", "--formula", FORMULA)
    assert api.calls == plain_api.calls and len(api.calls) == 1
    assert api.calls[0][1]["regions"] == "us"
    assert api.used == plain_api.used


def test_a_formula_book_in_a_region_that_is_not_picked_is_said_plainly_and_the_regions_are_unchanged(feed, tmp_path):
    code, out, api = feed(tmp_path, "a", "--region", "us", "--formula", '{"weights": {"pinnacle": 2}}')
    assert code == 0
    assert api.calls[0][1]["regions"] == "us", "the engine never changes a region on its own"
    note = out["formula"]["regions"]
    assert note["missing"] == ["pinnacle"] and (note["credits_now"], note["credits_with"]) == (1, 2)
    assert "Pinnacle is in your formula but is only sent in the eu (Europe) region, which is not picked" in note["text"]
    assert "from up to 1 credit to up to 2" in note["text"] and "never changes your regions by itself" in note["text"]
    assert [r for r in out["rows"] if r["kind"] == "ev"] == [], "no Pinnacle price was read, so no bet is priced by it"


def test_regions_note_counts_with_the_existing_estimate_and_changes_nothing():
    est = oddsapi.estimate(["nfl", "nba"], ["us"], ["h2h", "totals"])
    before = (est.regions, est.total)
    note = formula.regions_note({"pinnacle": 1, "kalshi": 1, "betonlineag": 1}, est)
    assert (est.regions, est.total) == before
    assert note["missing"] == ["pinnacle", "kalshi"] or set(note["missing"]) == {"pinnacle", "kalshi"}
    assert (note["credits_now"], note["credits_with"]) == (4, 12), "2 leagues x 2 bet types x (1 region, then 3)"
    assert "eu (Europe)" in note["text"] and "us_ex (US exchanges)" in note["text"] and "regions, which are not picked" in note["text"]


def test_a_book_sent_in_any_picked_region_is_not_missing_and_a_formula_without_weights_says_nothing():
    est = oddsapi.estimate(["nfl"], ["eu"], ["h2h"])
    assert formula.regions_note({"pinnacle": 1, "betonlineag": 1}, est)["text"] == "", "BetOnline is sent in eu too"
    assert formula.regions_note({"pinnacle": 0, "kalshi": 0}, est)["text"] == ""
    assert formula.regions_note({"kalshi": 1}, None)["text"] == ""


def test_player_props_read_in_a_region_without_a_formula_book_say_so_with_the_props_cost():
    est = oddsapi.estimate(["nfl"], ["us", "eu"], ["h2h"], props=oddsapi.props_plan(None, ["us"], 2))
    note = formula.regions_note({"pinnacle": 1}, est)
    assert note["missing"] == ["pinnacle"] and note["credits_with"] > note["credits_now"]
    assert est.props.regions == ("us",), "the props regions were not changed"


# ================================================================ 7. the row's detail names the books that priced it

def test_a_plays_detail_says_which_formula_books_priced_it_and_how_much_of_the_formula_was_there():
    one_sided = market({"pinnacle": (1.95, 1.95), "betonlineag": (1.93, None), "dk": (2.15, 1.75)})
    s = setting({"pinnacle": 2, "betonlineag": 1}, threshold=50)
    [row] = [r for r in board_mod.scan([one_sided], BOOKS, now=NOW, kinds=("ev",), detail=True, formula=s.formula)
             if r.legs[0]["outcome"] == "home"]
    d = row.detail["formula"]
    assert d["present_text"] == "66.7%" and d["meets"] is True and d["threshold_text"] == "50%"
    by = {b["book"]: b for b in d["books"]}
    assert by["pinnacle"]["priced"] and by["pinnacle"]["status"] == "priced this market"
    assert not by["betonlineag"]["priced"] and by["betonlineag"]["status"] == "did not price this market"
    assert "66.7% of your formula's weight priced this market (Pinnacle)" in d["sentence"]
    assert "Not priced: BetOnline." in d["sentence"]


def test_a_bet_at_a_formula_book_says_its_own_price_is_left_out():
    both = market({**SHARP, "dk": (2.15, 1.75)})
    s = setting({"pinnacle": 2, "betonlineag": 1, "dk": 1}, threshold=70)
    d = formula.detail_block(both, BOOKS, s.built(), "dk", lambda b: formula.BY_KEY[b].name)
    assert "DraftKings's own price is left out, because you would bet there." in d["sentence"]
    assert {b["book"]: b["status"] for b in d["books"]}["dk"] == "left out, you would bet here"


def test_a_plays_detail_leaves_the_book_bet_at_out_when_it_is_a_formula_book():
    both = market({**SHARP, "dk": (2.15, 1.75)})
    s = setting({"pinnacle": 2, "betonlineag": 1, "dk": 1}, threshold=70)
    rows = board_mod.scan([both], BOOKS, now=NOW, kinds=("ev",), detail=True, formula=s.formula)
    [row] = [r for r in rows if r.legs[0]["book"] == "dk" and r.legs[0]["outcome"] == "home"]
    by = {b["book"]: b for b in row.detail["formula"]["books"]}
    assert by["dk"]["left_out"] is True and by["dk"]["priced"] is False and row.detail["formula"]["present_text"] == "75%"
    assert "DraftKings" in row.detail["formula"]["sentence"] or "dk" in row.detail["formula"]["sentence"].lower()


def test_an_arbs_detail_shows_the_formula_too_and_a_middles_does_not():
    arb = market({"dk": (2.20, 1.70), "fd": (1.70, 2.20), **SHARP})
    s = setting({"pinnacle": 2, "betonlineag": 1})
    [row] = board_mod.scan([arb], BOOKS, now=NOW, kinds=("arb",), detail=True, formula=s.formula)
    assert row.detail["formula"]["meets"] is True
    cache = FairCache(s.formula)
    mid = row_detail(arb, BOOKS, [{"book": "dk", "outcome": "home"}, {"book": "fd", "outcome": "away"}], "middle", cache=cache)
    assert "formula" not in mid


def test_a_market_the_formula_cannot_price_has_no_fair_price_and_says_why_in_the_formula_words():
    none = market({"dk": (2.15, 1.75), "fd": (1.80, 2.10)})
    s = setting({"pinnacle": 2, "betonlineag": 1})
    arb = market({"dk": (2.20, 1.70), "fd": (1.70, 2.20)})
    [row] = board_mod.scan([arb], BOOKS, now=NOW, kinds=("arb",), detail=True, formula=s.formula)
    fair = row.detail["fair"]
    assert fair["available"] is False and fair["why"].startswith("Your EV formula has no price for this market")
    assert row.detail["formula"]["present_text"] == "0%" and scan([none], s.formula) == []
    # Some of the formula priced it, but under the threshold: the price is there to compute and is not offered.
    thin = market({"dk": (2.20, 1.70), "fd": (1.70, 2.20), "betonlineag": (1.93, 1.97)})
    [row] = board_mod.scan([thin], BOOKS, now=NOW, kinds=("arb",), detail=True, formula=s.formula)
    assert row.detail["formula"]["present_text"] == "33.3%" and row.detail["formula"]["meets"] is False
    assert row.detail["fair"]["available"] is False and row.detail["ev_by_book"][0]["rows"] == []


# ================================================================ 8. the panel, said by the engine

def test_the_panel_is_the_engines_words_for_every_part_of_it():
    est = oddsapi.estimate(["nfl"], ["us"], ["h2h"])
    p = formula.panel(setting({"pinnacle": 2, "betonlineag": 1}), est)
    assert p["name"] == "EV formula" and p["has_formula"] and p["active"] and not p["paused"]
    assert p["requires"] == "Requires Pinnacle." and p["apply"].startswith("Press Live sportsbook odds to use it.")
    assert p["lock_text"] == ("Recommended is on, and it prices bets with Bookbreaker's own blend of books, so your formula is "
                              "paused. Turn Recommended off to use it.")
    assert "spends no credits" in p["where"] and "arbs and middles do not use a fair price" in p["where"]
    cards = {c["key"]: c for c in p["books"]}
    assert cards["pinnacle"]["picked"] is False and "Its region is not picked" in cards["pinnacle"]["region_note"]
    assert cards["betonlineag"]["picked"] is True and cards["betonlineag"]["region_note"] == ""
    assert cards["pinnacle"]["region_text"] == "Sent in the eu (Europe) region"
    assert cards["betonlineag"]["region_text"] == "Sent in the us (US) or eu (Europe) regions"
    assert p["regions"]["text"] and p["notice"] == ""
    assert {m["key"] for m in p["more"]} == {b.key for b in formula.BOOKS} - {"pinnacle", "betonlineag"}
    assert [x["name"] for x in p["not_in_feed"]] == ["Circa", "BookMaker"]


def test_a_paused_formula_is_said_to_be_paused_and_a_missing_one_says_what_the_default_is():
    assert formula.panel(setting({"pinnacle": 2}, paused=True))["paused"] is True
    off = formula.panel(formula.parse(None))
    assert off["has_formula"] is False and off["off_text"] == formula.OFF_TEXT and off["active"] is False


def test_the_estimate_carries_the_panel_without_reading_a_key_or_a_network(monkeypatch, tmp_path):
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: (_ for _ in ()).throw(AssertionError("read the key")))
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: (_ for _ in ()).throw(AssertionError("fetched")))
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        code = cli.main(["board", "--feed", "oddsapi", "--estimate", "--region", "us", "--sport", "nfl", "--json",
                         "--formula", '{"weights": {"pinnacle": 2, "betonlineag": 1, "circa": 3}}'])
    got = json.loads(out.getvalue())
    assert code == 0 and got["formula"]["requires"] == "Requires Pinnacle."
    assert "circa" not in {c["key"] for c in got["formula"]["books"]} and "left out" in got["formula"]["notice"]
    assert got["formula"]["regions"]["missing"] == ["pinnacle"]
    # With no formula sent the panel is still there, so the window can draw its cards before anything is set.
    out2 = io.StringIO()
    with contextlib.redirect_stdout(out2):
        cli.main(["board", "--feed", "oddsapi", "--estimate", "--json", "--sport", "nfl"])
    assert json.loads(out2.getvalue())["formula"]["has_formula"] is False


# ================================================================ 9. the CLI

def _cli(*argv):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = cli.main(["board", *argv])
    return code, out.getvalue(), err.getvalue()


def test_a_malformed_formula_is_no_formula_and_a_one_line_notice_and_the_board_is_whole():
    code, out, _ = _cli("--json", "--formula", "{not json")
    got = json.loads(out)
    _, base_out, _ = _cli("--json")
    assert code == 0 and got["formula"]["notice"] == formula.NOTICE_UNREADABLE and got["formula"]["active"] is False
    assert got["rows"] == json.loads(base_out)["rows"] and "formula" not in got["filters"]
    code, text, _ = _cli("--formula", "[]")
    assert code == 0 and formula.NOTICE_UNREADABLE in text


def test_the_demonstration_board_can_be_priced_with_a_formula_too():
    code, out, _ = _cli("--json", "--formula", '{"weights": {"pinnacle": 1}, "threshold": 30}')
    got = json.loads(out)
    assert code == 0 and got["formula"]["active"] is True and got["filters"]["formula"]["active"] is True


def test_the_formula_is_refused_where_there_is_no_fair_price_to_blend():
    code, out, err = _cli("--live", "--formula", FORMULA)
    assert code == 2 and "Live prices pairs have no fair price to blend" in err
    code, out, err = _cli("--feed", "oddsapi", "--screen", "--formula", FORMULA)
    assert code == 2 and "--screen and --lowhold" in err
    code, out, err = _cli("--formula-paused")
    assert code == 2 and "--formula-paused only works with --formula" in err


def test_the_printed_board_says_the_formula_it_used():
    code, out, _ = _cli("--formula", '{"weights": {"pinnacle": 1}, "threshold": 30}')
    assert code == 0 and "Priced with your EV formula. Requires Pinnacle." in out


def test_the_flag_is_in_the_help_and_says_it_spends_no_credit():
    out = io.StringIO()
    with contextlib.redirect_stdout(out), pytest.raises(SystemExit):
        cli.main(["board", "--help"])
    text = " ".join(out.getvalue().split())
    assert "--formula JSON" in text and "spends no credits and never changes a region" in text and "--formula-paused" in text


# ================================================================ 10. the words

def _everything():
    est = oddsapi.estimate(["nfl"], ["us"], ["h2h"], props=oddsapi.props_plan(None, ["us"], 2))
    s = setting({"pinnacle": 2, "betonlineag": 1, "kalshi": 2, "dk": 1})
    out = [formula.panel(s, est), formula.panel(formula.parse("{"), est), formula.panel(setting({"pinnacle": 1}, paused=True))]
    out.append(formula.board_block(s, {"formula_shown": 2, "formula_default": 5, "formula_below": 1}, est))
    out.append(formula.board_block(setting({"pinnacle": 1}, paused=True), {}))
    one_sided = market({"pinnacle": (1.95, 1.95), "betonlineag": (1.93, None), "dk": (2.15, 1.75)})
    out.append(formula.detail_block(one_sided, BOOKS, s.built(), "dk", lambda b: formula.BY_KEY[b].name))
    out.append(formula.counts(s, {"formula_shown": 1}))
    out.append([formula.requires(setting(w, t).built()) for w in ({"pinnacle": 2, "betonlineag": 1}, {"pinnacle": 1, "betonlineag": 1})
                for t in (0, 50, 100)])
    return out


def test_every_sentence_the_engine_writes_keeps_the_house_rules():
    seen = [t for blob in _everything() for t in strings(blob)]
    assert len(seen) > 60
    for text in seen:
        low = text.lower()
        for word in BANNED:
            assert word not in low, (word, text)
    for name in ("notice", "requires", "sentence", "apply", "lock_text", "where", "off_text"):
        for blob in _everything()[:5]:
            if isinstance(blob, dict) and blob.get(name):
                assert "\n" not in blob[name], name


def test_the_words_a_bettor_has_to_decode_are_explained_in_the_panel():
    p = formula.panel(formula.parse(None))
    assert "pays more than its chance of winning is worth" in p["intro"]
    assert "weight 2 counts twice as much as one with weight 1" in p["intro"]
    assert "formula book did not quote on both sides" in p["threshold"]["why"]


def test_the_engine_module_makes_no_network_call_and_reads_no_file():
    src = Path(formula.__file__).read_text()
    for word in ("urllib", "socket", "requests", "http", "open(", "sqlite3", "time.", "os.environ", "subprocess"):
        assert word not in src.replace("`", ""), word


# ================================================================ 11. the window

SECTION_START = "/* ------------------------------------------------------------ EV formula"
SECTION = JS[JS.index(SECTION_START):JS.index("/* ------------------------------------------------------------ Filter counts")]
CODE = SECTION[SECTION.index("*/"):]
CSS_SECTION = CSS[CSS.index("/* ------------------------------------------------------------ EV formula"):]


def _panel_block(html: str) -> str:
    start = html.index('id="formula-box"')
    return html[start:html.index("</details>", start)]


def test_the_panel_sits_in_the_arbitrage_settings_after_the_filters_and_before_alerts():
    board = HTML[HTML.index('<section class="panel" id="panel-board"'):]
    board = board[:board.index("</section>")]
    assert board.index('id="b-min"') < board.index('id="b-preset"') < board.index('data-run="board"')
    assert board.index('id="fcounts"') < board.index('id="formula-box"') < board.index('id="alerts-box"')
    block = _panel_block(board)
    assert "data-run" not in block, "nothing in the panel starts a read"
    for ident in ("formula-cards", "formula-more", "formula-add", "formula-threshold", "formula-requires", "formula-clear",
                  "formula-lock", "formula-regions", "formula-notice", "formula-state", "formula-gone", "formula-set"):
        assert f'id="{ident}"' in block, ident
    assert '<input type="range" id="formula-threshold" min="0" max="100" step="5" value="50">' in block
    assert "Only show bets when book weights reach this threshold" in block
    assert '<fieldset class="formula-set" id="formula-set">' in block
    assert block.index('id="formula-set"') < block.index('id="formula-clear"') < block.index("</fieldset>"), "Clear is greyed with the rest"


def test_the_formula_rides_on_the_odds_board_and_the_estimate_and_on_nothing_else():
    argv = JS[JS.index("  const argv = {"):JS.index("  }[kind]();")]
    for line in re.findall(r"^    (\w+): \(\) =>.*?(?=^    \w+: \(\) =>|\Z)", argv, re.S | re.M):
        pass
    oddsboard = argv[argv.index("    oddsboard:"):argv.index("    oddsestimate:")]
    estimate = argv[argv.index("    oddsestimate:"):argv.index("    // The Odds screen")]
    assert "...formulaFlags()" in oddsboard and "...formulaFlags()" in estimate
    assert argv.count("formulaFlags()") == 2
    assert "--formula-paused" in _braced(CODE, "function formulaFlags(") and "PRESET.on" in _braced(CODE, "function formulaFlags(")


def test_the_formula_is_kept_on_this_mac_the_way_the_other_settings_are():
    assert 'store.get("bb.formula", null)' in CODE and 'store.set("bb.formula", next)' in CODE
    assert len(re.findall(r'store\.set\(', CODE)) == 1
    keep = _braced(CODE, "function formulaKeep(")
    assert "run(\"oddsestimate\")" in keep and "AGAIN.add(\"oddsestimate\")" in keep, "the engine words the panel again"
    assert 'run("oddsboard")' not in CODE and "data-run" not in CODE, "changing it reads no price"


def test_recommended_greys_the_panel_and_holds_the_formula():
    draw = _braced(CODE, "function drawFormula(")
    assert 'const locked = PRESET.on;' in draw and '$("formula-set").disabled = locked;' in draw
    assert "F.lock_text" in draw and '"formula-box").classList.toggle("is-locked", locked)' in draw
    assert "drawFormula();" in _braced(JS, "function setPreset(on)")
    click = _braced(CODE, 'document.addEventListener("click"')
    assert "PRESET.on" in click, "a stepper does nothing while locked"
    assert 'formulaKeep(null)' in CODE and "PRESET.on" in CODE[CODE.index('"formula-clear"'):][:200]
    assert "#formula-set:disabled" in CSS_SECTION.replace(".formula-set", "#formula-set") or ".formula-set:disabled" in CSS_SECTION


def test_the_window_prints_the_engines_words_and_every_field_it_reads_is_one_the_engine_sends():
    s = setting({"pinnacle": 2, "betonlineag": 1})
    est = oddsapi.estimate(["nfl"], ["us"], ["h2h"])
    panel = formula.panel(s, est)
    draw = _braced(CODE, "function drawFormula(")
    for var, keys in (("F", panel), ("T", panel["threshold"]), ("F.regions", panel["regions"])):
        read = set(re.findall(rf"(?<![\w.]){re.escape(var)}\.([a-z_]+)", draw))
        read -= {"length", "map", "join"}
        assert read <= set(keys), f"{var}: read but never sent: {sorted(read - set(keys))}"
    card = _braced(CODE, "function formulaCardHTML(")
    assert set(re.findall(r"\bb\.([a-z_]+)", card)) <= set(panel["books"][0])
    one_sided = market({"pinnacle": (1.95, 1.95), "dk": (2.15, 1.75)})
    d = formula.detail_block(one_sided, BOOKS, s.built(), "dk", lambda b: b)
    assert set(re.findall(r"\bb\.([a-z_]+)", _braced(CODE, "function formulaCard("))) <= set(d["books"][0])
    assert set(re.findall(r"\bf\.([a-z_]+)", _braced(CODE, "function formulaCard("))) <= set(d)
    block = formula.board_block(s, {}, est)
    assert set(re.findall(r"\bf\.([a-z_]+)", _braced(CODE, "function formulaLine("))) <= set(block)
    assert "formula: out.formula" in _braced(JS, "function showOddsboard(") and "setFormula(out.formula)" in _braced(JS, "function showOddsestimate(")
    assert "${formulaLine()}" in _braced(JS, "function drawBoard(") and "formulaCard(d.formula)" in _braced(JS, "function detailHTML(")


def test_the_filter_counts_draw_the_formulas_line_from_the_engine():
    draw = _braced(JS, "function drawFilterCounts(")
    assert "F.formula.text" in draw and "${esc(F.formula.text)}" in draw


def test_the_window_computes_nothing_in_the_new_code():
    for banned in (".toFixed(", ".reduce(", "parseFloat", "Math.", "toLocaleString", "toPrecision", "Date.now", "new Date",
                   "setTimeout", "setInterval", "fetch(", "XMLHttpRequest", "WebSocket", "document.write", "eval(", "new Function",
                   "invoke("):
        assert banned not in CODE, banned
    leaves = re.findall(r"\$\{([^{}]*)\}", CODE)
    assert len(leaves) >= 20, "the extractor has drifted"
    for expr in leaves:
        bare = re.sub(r"\"[^\"]*\"|'[^']*'", "''", expr)
        assert not re.search(r"[\w)\]]\s*[*/%]\s*[\w(]|[\w)\]]\s+[+-]\s+[\w(]", bare), f"arithmetic: {expr}"


def test_every_engine_string_is_drawn_as_text_not_markup():
    card, line, fcard = (_braced(CODE, f"function {n}(") for n in ("formulaCardHTML", "formulaLine", "formulaCard"))
    for body in (card, line, fcard):
        for expr in re.findall(r"\$\{([^{}]*)\}", body):
            if re.search(r"\b[bfFxm]\.[a-z_]+", expr):
                assert ("esc(" in expr or "?" in expr or expr.strip().startswith("bookTile(")
                        or expr.strip() in {"b.minus", "b.plus", "b.weight"}), expr
    draw = _braced(CODE, "function drawFormula(")
    assert draw.count("textContent") >= 12 and ".innerHTML" in draw and "esc(m.name)" in draw and "esc(x.why)" in draw


def test_the_page_has_a_rule_for_every_class_the_new_markup_draws():
    heads = {"formula-set": ".formula-set{", "formula-cards": ".formula-cards{", "fcard": ".fcard{", "fcard-n": ".fcard-n{",
             "fstep": ".fstep{", "fstep-b": ".fstep-b{", "fstep-v": ".fstep-v{", "fshare": ".fshare{", "formula-add": ".formula-add{",
             "formula-thr": ".formula-thr{", "formula-ends": ".formula-ends{", "formula-requires": ".formula-requires{",
             "fb-row": ".fb-row{", "fb-n": ".fb-n{", "fb-w": ".fb-w{", "fb-s": ".fb-s{", "formula-lock": ".formula.is-locked .formula-lock{"}
    drawn = CODE + HTML
    for cls, head in heads.items():
        assert head in CSS_SECTION, f".{cls} has no rule in app.css"
        assert re.search(rf"\b{re.escape(cls)}\b", drawn), f".{cls} is styled and never drawn"


def test_the_new_styles_use_the_windows_tokens_and_no_colour_of_their_own():
    assert CSS_SECTION.count("{") >= 20
    assert not re.search(r"#[0-9a-fA-F]{3,8}\b", CSS_SECTION) and not re.search(r"\b(rgba?|hsla?)\(", CSS_SECTION)
    root = CSS[CSS.index(":root{"):CSS.index("}", CSS.index(":root{"))]
    for token in sorted(set(re.findall(r"var\((--[\w-]+)", CSS_SECTION))):
        assert f"{token}:" in root, f"{token} is not one of the window's tokens"


def test_the_panels_static_text_keeps_the_house_rules_and_matches_the_engines_intro():
    block = _panel_block(HTML)
    text = re.sub(r"<[^>]+>", " ", block)
    for word in BANNED:
        assert word not in text.lower(), word
    assert " ".join(formula.panel(formula.parse(None))["intro"].split()) in " ".join(text.split())
    for word in BANNED:
        assert word not in CODE.lower(), word
