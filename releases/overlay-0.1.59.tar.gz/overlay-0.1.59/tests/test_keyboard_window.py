"""Keyboard control for the window (AVO bar item 31: arrow keys move between cards).

The window's Keyboard section selects a play and moves focus, and nothing else. These pin:

  * Up and Down (or k and j) move the selected play by pressing the next card, so a key goes through the same click
    handler as the mouse; the ends stay where they are; Enter with nothing focused presses the selected card, and
    Enter on a button is left to the button;
  * Escape closes the open details the focus is in, else the open menu; / focuses the first box on the page;
  * a key does nothing while focus is in an input, select, textarea or editable area, with Cmd, Ctrl or Alt held,
    with a dialog open, or off the Arbitrage page (the arrows);
  * the cards are options of a listbox: role, aria-selected kept in step with the selection, one Tab stop;
  * a ring shows where the keyboard is, and the page says what the keys are;
  * nothing a key does reads the network, starts an engine command, stores a setting or touches the plays.

Most of it runs the section's own code in node against a small stand-in for the page (tests/keys_driver.js); the
rest reads app.js as text, like the other window tests.
"""
import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
JS = (ROOT / "ui" / "src" / "app.js").read_text()
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
CSS = (ROOT / "ui" / "src" / "app.css").read_text()
NODE = shutil.which("node")

START = "/* ------------------------------------------------------------ Keyboard"
SECTION = JS[JS.index(START):JS.index('\nshow("ask");\n')]
CODE = SECTION[SECTION.index("*/"):]          # the section without its own comment
needs_node = pytest.mark.skipif(NODE is None, reason="node is not installed")


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


@pytest.fixture(scope="module")
def ran():
    run = subprocess.run([NODE, str(ROOT / "tests" / "keys_driver.js"), str(ROOT / "ui" / "src" / "app.js")],
                         capture_output=True, text=True, timeout=60)
    assert run.returncode == 0, run.stderr[-600:]
    return json.loads(run.stdout)


def nothing(r):
    return r["clicks"] == [] and r["focused"] == [] and r["prevented"] is False


# ------------------------------------------------------------ moving between plays

@needs_node
def test_down_and_j_press_the_next_card_and_k_and_up_the_one_before(ran):
    for name, to in (("down", 2), ("j", 2), ("up", 0), ("k", 0)):
        assert ran[name]["clicks"] == [to], name
        assert ran[name]["focused"] == [to], f"{name}: the focus ring needs the keyboard focus on the card"
        assert ran[name]["prevented"] is True, name
        assert ran[name]["on"].index(True) == to, name


@needs_node
def test_a_key_selects_through_the_click_handler_and_the_screen_reader_state_follows(ran):
    r = ran["down"]
    assert r["aria"] == ["false", "false", "true"], "aria-selected follows the selection"
    assert r["tab"] == [-1, -1, 0], "one Tab stop in the list: the selected card"


@needs_node
def test_the_ends_of_the_list_stay_where_they_are(ran):
    for name in ("atEnd", "atStart"):
        assert ran[name]["clicks"] == [] and ran[name]["focused"] == [], name
    assert ran["noneSelected"]["clicks"] == [0], "with nothing selected, a key lands on the first play"


@needs_node
def test_an_empty_board_leaves_the_key_alone(ran):
    assert nothing(ran["noCards"])


@needs_node
def test_the_arrows_work_on_the_arbitrage_page_only(ran):
    assert nothing(ran["elsewhere"])
    assert nothing(ran["enterElsewhere"])


@needs_node
def test_enter_with_nothing_focused_presses_the_selected_card_and_a_button_keeps_its_enter(ran):
    assert ran["enterBody"]["clicks"] == [1] and ran["enterBody"]["prevented"] is True
    assert nothing(ran["enterNoSelection"])
    assert nothing(ran["enterButton"]), "a focused button presses itself; the window must not take its Enter"


def test_a_key_chooses_a_play_only_by_pressing_its_card():
    assert re.search(r"function keysPick\(card\) \{\s*card\.click\(\);\s*card\.focus\(\);\s*\}", CODE)
    for second_way in ('classList.toggle("is-on"', 'classList.add("is-on"', "consoleHTML", "detailHTML", "drawBoard(",
                       "redrawBoard", "outerHTML", "innerHTML", "pickedPlay"):
        assert second_way not in CODE, second_way


# ------------------------------------------------------------ keeping out of the way

@needs_node
def test_a_key_does_nothing_while_the_focus_is_in_a_field(ran):
    for key in ("ArrowDown", "ArrowUp", "j", "k", "Enter", "Escape", "/"):
        assert nothing(ran[f"typing_{key}"]), f"{key} in an input, select or textarea"
        assert nothing(ran[f"editable_{key}"]), f"{key} in an editable area"
    assert ran["typing_Escape"]["prevented"] is False


@needs_node
def test_cmd_ctrl_and_alt_shortcuts_are_left_alone(ran):
    for name in ("mod_metaKey", "mod_ctrlKey", "mod_altKey", "mod_shiftKey", "metaJ", "ctrlSlash", "metaEscape"):
        assert nothing(ran[name]), name


@needs_node
def test_an_open_dialog_has_the_keyboard_to_itself(ran):
    assert nothing(ran["dialog"]) and nothing(ran["dialogEscape"])


@needs_node
def test_a_key_already_handled_or_part_of_composing_text_is_left_alone(ran):
    assert nothing(ran["composing"]) and nothing(ran["alreadyHandled"])


def test_the_guards_come_before_any_key_is_read():
    handler = JS[JS.index('document.addEventListener("keydown", (ev) => {\n  if (ev.defaultPrevented'):JS.index('\nshow("ask");\n')]
    body = handler[handler.index("{"):]
    first_key = body.index("ev.key")
    for guard in ("ev.ctrlKey || ev.metaKey || ev.altKey", "keysTyping(ev.target)", 'dialog[open]'):
        assert guard in body and body.index(guard) < first_key, guard
    assert "contenteditable" in SECTION and "isContentEditable" in SECTION
    assert "input, select, textarea" in SECTION


# ------------------------------------------------------------ Escape and /

@needs_node
def test_escape_closes_the_details_the_focus_is_in_and_returns_to_its_summary(ran):
    assert ran["escDetails"] == {"returned": True, "open": False, "summaryFocused": True}
    assert ran["escDetailsKey"]["prevented"] is True


@needs_node
def test_escape_closes_the_open_menu_when_the_focus_is_elsewhere_and_otherwise_does_nothing(ran):
    assert ran["escMenu"]["returned"] is True and ran["escMenu"]["open"] is False
    assert ran["escMenuKey"] == {"prevented": True, "open": False}
    assert nothing(ran["escNothing"]), "with nothing open Escape stays the browser's"
    assert 'details.privacy[open]' in SECTION


@needs_node
def test_slash_goes_to_the_first_box_that_can_be_typed_in(ran):
    s = ran["slash"]
    assert s["first"] is True and s["picked"] is True and s["prevented"] is True
    assert s["others"] == [False] * 6, "not a checkbox, a slider, a hidden, read-only or disabled box, or a later one"
    assert ran["slashTextarea"]["got"] is True
    assert nothing(ran["slashNone"]) and nothing(ran["slashNoPage"]), "no box, no key taken"


# ------------------------------------------------------------ the list is a listbox

def test_each_card_is_an_option_with_aria_selected_and_one_tab_stop():
    card = _braced(JS, "function listCard(")
    assert 'role="option"' in card
    assert 'aria-selected="${on ? "true" : "false"}"' in card
    assert 'tabindex="${on ? 0 : -1}"' in card
    assert card.index('data-pick="${i}"') < card.index('role="option"'), "the pinned text before data-pick is unchanged"


def test_the_list_is_a_listbox_when_it_has_plays_and_the_click_handler_keeps_it_in_step():
    board = _braced(JS, "function drawBoard(")
    assert "role=\"listbox\" aria-label=\"Plays on the board\"" in board
    assert "kept.length ?" in board, "a listbox with no option in it is not drawn"
    click = JS[JS.index('document.addEventListener("click", (ev) => {\n  const c = ev.target.closest && ev.target.closest("[data-pick]");'):
               JS.index("/* ------------------------------------------------------------ tools */")]
    assert "keysMark(c);" in click
    mark = _braced(CODE, "function keysMark(")
    assert 'setAttribute("aria-selected"' in mark and "a.tabIndex" in mark


def test_keyboard_focus_is_visible_in_the_windows_colours():
    rule = re.search(r"\.acard:focus-visible\{([^}]*)\}", CSS)
    assert rule, "no focus ring on a card"
    assert "outline:2px solid var(--accent)" in rule.group(1) and "none" not in rule.group(1)
    assert "--accent" in CSS and not re.search(r"#[0-9a-fA-F]{3,8}\b|rgba?\(", rule.group(1))
    assert CSS.count("{") == CSS.count("}")


def test_the_page_lists_the_keys_under_the_board_and_it_is_not_a_control():
    note = re.search(r'<p class="small keys-note" id="keys-note">(.*?)</p>', HTML, re.S)
    assert note and HTML.index('id="out-board"') < note.start() < HTML.index('id="track-dlg"')
    text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", note.group(1)))
    for word in ("Keys", "Up and Down", "K and J", "Enter", "Esc", "/", "typing"):
        assert word in text, word
    assert "keys-note" in CSS


# ------------------------------------------------------------ a key only selects

def test_no_key_reads_the_network_starts_a_command_stores_anything_or_touches_the_plays():
    assert len(CODE) > 1500, "the extractor has drifted"
    for banned in ("run(", "invoke(", "fetch(", "await", "async", "XMLHttpRequest", "store.", "localStorage",
                   "sessionStorage", "setInterval", "setTimeout", "requestAnimationFrame", "PLAYS", "BOARD", "HIDDEN",
                   "splice", ".sort(", ".push(", "Math.", "toFixed", "parseFloat", "Date", "document.write",
                   "insertAdjacentHTML", "eval(", "new Function"):
        assert banned not in CODE, banned


def test_the_keyboard_code_is_its_own_section_with_its_own_header_and_hide_does_not_change():
    assert JS.count(START) == 1
    assert SECTION.lstrip().startswith("/* ---") and "Keyboard" in SECTION.splitlines()[0]
    for mutation in ("PLAYS =", "PLAYS.splice", "PLAYS.filter", "PLAYS.push", "PLAYS.pop", "PLAYS.shift", ".sort("):
        assert mutation not in SECTION, mutation


def test_the_new_key_listener_is_added_once_and_leaves_the_enter_that_runs_a_page_alone():
    assert len(re.findall(r'addEventListener\("keydown", \(ev\) => \{\n  if \(ev\.defaultPrevented', JS)) == 1
    assert 'event.key !== "Enter" || input.tagName !== "INPUT"' in JS, "Enter in a box still runs the page"
