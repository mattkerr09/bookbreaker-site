"""Find a hedge from odds already read (the AVO bar's item 18): an open bet's other side is found in the prices a read
left on this Mac, at books licensed in the chosen state, best price first, and planned as a typed price would be. It
reads files only and spends no credit."""
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

import test_lowhold_view as lv  # noqa: E402
from overlay_engine import cli, hedge, oddsapi, oddshistory, screen  # noqa: E402
from overlay_engine.ledger import Ledger, LedgerError  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
home = lv.home


def _bet(db, outcome=lv.HOME, book="dk", price=1.91, stake=100.0, profit=None):
    return db.import_bet(event_id="g1", sport="americanfootball_nfl", market_type="h2h", outcome=outcome, book=book,
                         decimal_odds=price, stake=stake, placed_at=lv.NOW - 600, profit=profit,
                         result=None if profit is None else "won", settled_at=None if profit is None else lv.NOW)


def _reads():
    reads, _ = screen.history_reads(oddshistory.history_folder(), lv.NOW + 30)
    return reads


def test_the_best_price_on_the_other_side_is_found_and_planned(home):
    lv.read()
    with Ledger(home / "overlay.db") as db:
        bid = _bet(db)
        out = hedge.from_reads(db, bid, _reads(), set(oddsapi.BETTABLE), lv.NOW + 30)
    away = {lv.KEY[b]: p[1] for b, p in lv.ML.items() if lv.KEY[b] in oddsapi.BETTABLE}
    best_book = max(away, key=away.get)
    assert out["found"]["book"] == best_book
    assert [o["decimal"] for o in out["options"]] == sorted(away.values(), reverse=True)
    assert out["rows"] == hedge.plan(100.0, 1.91, out["found"]["american"])["rows"]
    assert "pinnacle" not in {o["book"] for o in out["options"]}, "a reference book is never a hedge"
    assert "Check it at the book before you bet" in out["found"]["text"]


def test_only_books_licensed_in_the_state_are_used(home):
    lv.read()
    with Ledger(home / "overlay.db") as db:
        bid = _bet(db)
        allowed = {"dk", "fd"}
        out = hedge.from_reads(db, bid, _reads(), allowed, lv.NOW + 30)
    assert {o["book"] for o in out["options"]} <= allowed


def test_no_other_side_read_or_a_settled_bet_is_one_sentence(home):
    with Ledger(home / "overlay.db") as db:
        bid = _bet(db)
        with pytest.raises(LedgerError, match="not in the odds read on this Mac"):
            hedge.from_reads(db, bid, [], set(oddsapi.BETTABLE), lv.NOW)
        done = _bet(db, profit=91.0)
        with pytest.raises(LedgerError, match="already settled"):
            hedge.from_reads(db, done, [], set(oddsapi.BETTABLE), lv.NOW)


def test_the_command_reads_files_only_and_needs_a_price_or_the_reads(home, monkeypatch, capsys):
    lv.read()
    with Ledger(home / "overlay.db") as db:
        bid = _bet(db)
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: (_ for _ in ()).throw(AssertionError("no read")))
    reads = _reads()
    monkeypatch.setattr(screen, "history_reads", lambda folder, now: (reads, False))
    assert cli.main(["hedge", f"--bet={bid}", "--from-reads", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["found"] and out["rows"]
    assert cli.main(["hedge", f"--bet={bid}", "--json"]) == 0
    assert "Type the other side's price" in json.loads(capsys.readouterr().out)["error"]


def test_an_unreadable_price_is_a_sentence_not_a_crash(home, capsys):
    """Since 0.1.42 cmd_hedge caught OddsError without importing it, so a bad price crashed (found 2026-11-01)."""
    assert cli.main(["hedge", "--stake", "50", "--held", "+150", "--other", "abc", "--json"]) == 0
    assert "Type the other side's price" in json.loads(capsys.readouterr().out)["error"]


def test_the_words_never_promise(home):
    lv.read()
    with Ledger(home / "overlay.db") as db:
        out = hedge.from_reads(db, _bet(db), _reads(), set(oddsapi.BETTABLE), lv.NOW + 30)
    assert not re.search(r"guarantee|risk.free|either way|free bet|\block\b|sure thing", out["found"]["text"], re.I)


def test_the_window_asks_the_reads_when_no_price_is_typed_and_draws_the_engines_words():
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    assert ('...(HEDGE.other ? [`--other=${HEDGE.other}`] : ["--from-reads", ...stateFlags()])') in js
    assert "esc(out.found.text)" in js and "esc(o.age_text)" in js
