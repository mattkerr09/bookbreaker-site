"""One price in every form (the AVO bar's item 32): Fair odds with only one price converts it, and with two it shows
each price as American, decimal, fractional and break-even chance beside the fair prices."""
import json
import re
import subprocess
import sys
from fractions import Fraction
from pathlib import Path

import pytest

from overlay_engine.odds import parse_odds

ROOT = Path(__file__).resolve().parents[1]


def run(*prices):
    r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "devig", "--json", *prices], cwd=ROOT / "backend",
                       capture_output=True, text=True, check=True)
    return json.loads(r.stdout)


@pytest.mark.parametrize("price", ["+150", "-145", "+100", "-110", "2.75"])
def test_every_form_of_one_price_agrees(price):
    d = run(price)
    c = d["convert"][0]
    dec = parse_odds(price)
    assert d["single"] is True and c["decimal"] == round(dec, 3)
    assert c["implied"] == pytest.approx(1 / dec)
    n, m = map(int, c["fractional"].split("/"))
    assert Fraction(n, m) == Fraction(dec - 1).limit_denominator(100)
    assert abs(n / m - (dec - 1)) < 0.01
    assert c["american_text"].lstrip("+") == str(c["american"])


def test_two_prices_still_take_the_cut_out_and_also_convert_each():
    d = run("-145", "+125")
    assert d["single"] is False and len(d["convert"]) == 2 and d["chosen"]["outcomes"]
    assert [c["american"] for c in d["convert"]] == [-145, 125]


def test_one_price_says_how_to_take_the_cut_out_and_never_promises():
    d = run("+150")
    assert "Type the other side's price" in d["note"]
    assert not re.search(r"guarantee|risk.free|either way|free bet|\block\b|sure thing", d["convert"][0]["text"], re.I)


def test_the_window_sends_one_price_alone_and_draws_the_engines_figures():
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    assert 'val("devig-a"), ...(val("devig-b") ? [val("devig-b")] : [])],' in js
    assert "if (out.single) {" in js and "esc(out.convert[0].text)" in js and "${convertTable(out)}" in js
