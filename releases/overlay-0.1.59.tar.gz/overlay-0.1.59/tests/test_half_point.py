"""Is buying a half point worth it (the AVO bar's item 36).

Three things are pinned here, because each one can be wrong while the others look fine:
  * the data: NFL margins, rebuilt by a script from nflverse's schedule file, and checked against the site's own figures;
  * the arithmetic: how often a game lands on the number, the break-even price, and what the extra cost buys on average;
  * the words and the window: every figure and sentence is the engine's, and none of them promises.
"""
import csv
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import halfpoint
from overlay_engine.halfpoint import half_point_cost, wilson
from overlay_engine.odds import OddsError, american_to_decimal as a2d, parse_odds

ROOT = Path(__file__).resolve().parents[1]
SHIPPED = ROOT / "backend" / "overlay_engine" / "data" / "nfl_margins.csv"
SITE = Path("/Users/matthewkerr/bookbreaker-site/_data/nfl_key_numbers.csv")
LAB_GAMES = Path("/Users/matthewkerr/bb-lab/research/nfl/data/games.csv")
JS = (ROOT / "ui" / "src" / "app.js").read_text()
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
RUST = (ROOT / "ui" / "src-tauri" / "src" / "main.rs").read_text()

#: What a calculator may never say to a person who is about to place a bet.
BANNED = re.compile(r"guarantee|risk.free|free bet|either way|\block|\bwin\b|sure thing|can.t lose", re.I)


def _script():
    spec = importlib.util.spec_from_file_location("build_nfl_margins", ROOT / "scripts" / "build_nfl_margins.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _rows():
    with open(SHIPPED, newline="") as f:
        return list(csv.DictReader(f))


def _get(table, scope, key):
    for r in _rows():
        if (r["table"], r["scope"], r["key"]) == (table, scope, str(key)):
            return int(r["count"]), int(r["of"]), r["pct"]
    raise KeyError((table, scope, key))


def cost(market="spread", line=-3.0, bought=-2.5, price="-110", bprice="-130", side="over"):
    return half_point_cost(market, line, bought, parse_odds(price), parse_odds(bprice), side=side)


# ------------------------------------------------------------------ the data

def test_every_row_says_where_it_came_from_which_seasons_and_when_it_was_read():
    rows = _rows()
    assert len(rows) > 200
    for r in rows:
        assert r["source"] == "https://github.com/nflverse/nflverse-data/releases/download/schedules/games.csv"
        assert r["seasons"] == "2015-2025"
        assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", r["read"])


def test_the_counts_add_up_and_the_percentages_are_their_counts():
    rows = _rows()
    for table, scope in (("margin", "regular"), ("margin", "regular_and_playoffs"), ("points", "regular")):
        part = [r for r in rows if (r["table"], r["scope"]) == (table, scope)]
        assert sum(int(r["count"]) for r in part) == int(part[0]["of"]), (table, scope)
    for r in rows:
        assert r["pct"] == f"{100 * int(r['count']) / int(r['of']):.2f}"


def test_the_regular_season_table_has_the_regular_season_games_of_2015_to_2025_only():
    count, of, _ = _get("margin", "regular", 3)
    # 11 seasons: 256 games in 2015 to 2020, 272 in 2021 and later, one fewer in 2022 (a game cancelled and not replayed).
    assert of == 6 * 256 + 4 * 272 + 271
    assert halfpoint.load().games == of


def test_the_site_figures_are_reproduced_from_this_table_by_the_site_own_counting():
    """The site counts regular-season and playoff games together (its builder says so). Counted that way, this table
    gives the site's margin 3 and margin 7 to 0.01 percentage points, and its pushes on a line of 3 and of 7."""
    if not SITE.exists():
        pytest.skip("the site's _data/nfl_key_numbers.csv is not on this Mac")
    site = {r["key"]: r["value"] for r in csv.DictReader(open(SITE))}
    for k in (3, 7):
        count, of, pct = _get("margin", "regular_and_playoffs", k)
        assert abs(100 * count / of - float(site[f"margin_{k}_pct"])) <= 0.01, k
        assert of == int(site["games"])
        pushes, games, pct = _get("spread_line", "regular_and_playoffs", k)
        assert (games, pushes) == (int(site[f"line_{k}_games"]), int(site[f"line_{k}_pushes"])), k
        assert abs(100 * pushes / games - float(site[f"line_{k}_push_pct"])) <= 0.01, k


def test_the_regular_season_figures_sit_close_to_the_sites_and_the_gap_is_the_playoffs():
    """The task's figures are regular season only, so they are a little different from the site's, which also counts the
    playoffs. 14.65 against 14.83 and 8.67 against 8.69: close, and not the same number, and the test says so."""
    if not SITE.exists():
        pytest.skip("the site's _data/nfl_key_numbers.csv is not on this Mac")
    site = {r["key"]: r["value"] for r in csv.DictReader(open(SITE))}
    for k in (3, 7):
        c_reg, n_reg, _ = _get("margin", "regular", k)
        c_all, n_all, _ = _get("margin", "regular_and_playoffs", k)
        assert n_all - n_reg == 133 and c_all >= c_reg
        assert abs(100 * c_reg / n_reg - float(site[f"margin_{k}_pct"])) < 0.25


def test_the_shipped_table_is_what_the_script_builds_from_the_nflverse_file():
    if not LAB_GAMES.exists():
        pytest.skip("the local copy of nflverse's games.csv is not on this Mac")
    mod = _script()
    shipped = _rows()
    with open(LAB_GAMES, newline="") as f:
        built = mod.build_rows(csv.DictReader(f), shipped[0]["read"])
    assert [list(r.values()) for r in shipped] == built


def _synthetic():
    head = "game_type,season,home_score,away_score,spread_line,total_line"
    return [dict(zip(head.split(","), line.split(","))) for line in [
        "REG,2015,27,24,3,51",       # home favoured by 3, won by 3: lands on a line of 3 and on a total of 51
        "REG,2016,17,20,-3,44.5",    # away favoured by 3, won by 3: lands on a line of 3
        "REG,2017,20,17,7,",         # won by 3 on a line of 7: not a push
        "REG,2018,24,24,0,40",       # a tie
        "DIV,2015,30,27,3,50",       # the playoffs: counted only where the site counts them
        "REG,2014,10,3,3,40",        # before the seasons covered
        "REG,2025,,,3,40",           # not played yet
        "REG,2026,10,3,3,40",        # after the seasons covered
        "REG,2019,30,20,6.5,NA",     # a half-point line is not a push line
        "REG,2020,20,23,3,",         # the home favourite lost by 3: ends 3 apart, but is not the favourite ahead by 3
    ]]


def test_the_script_counts_a_small_made_up_season_by_hand():
    rows = {(r[0], r[1], r[2]): (int(r[3]), int(r[4])) for r in _script().build_rows(_synthetic(), "2026-01-01")}
    assert rows[("margin", "regular", "3")] == (4, 6)
    assert rows[("margin", "regular", "0")] == (1, 6) and rows[("margin", "regular", "10")] == (1, 6)
    assert rows[("margin", "regular_and_playoffs", "3")] == (5, 7)
    assert rows[("spread_line", "regular", "3")] == (2, 3)
    assert rows[("spread_line", "regular", "7")] == (0, 1)
    assert rows[("spread_line", "regular_and_playoffs", "3")] == (3, 4)
    assert ("spread_line", "regular", "6") not in rows and ("spread_line", "regular", "0") not in rows
    assert rows[("total_line", "regular", "whole")] == (1, 2)
    assert rows[("points", "regular", "37")] == (2, 6) and rows[("points", "regular", "51")] == (1, 6)


def test_the_script_writes_the_file_and_names_the_source_the_seasons_and_the_read_date(tmp_path):
    games = tmp_path / "games.csv"
    games.write_text("game_type,season,home_score,away_score,spread_line,total_line\nREG,2015,27,24,3,51\n")
    out = tmp_path / "out.csv"
    done = subprocess.run([sys.executable, str(ROOT / "scripts" / "build_nfl_margins.py"), str(games),
                           "--read-date", "2026-11-01", "--out", str(out)], capture_output=True, text=True)
    assert done.returncode == 0, done.stderr
    rows = list(csv.DictReader(open(out)))
    assert {(r["source"], r["seasons"], r["read"]) for r in rows} == {(
        "https://github.com/nflverse/nflverse-data/releases/download/schedules/games.csv", "2015-2025", "2026-11-01")}


# ------------------------------------------------------------------ the arithmetic

def test_the_worked_example_minus_3_at_minus_110_against_minus_2_and_a_half_at_minus_130():
    r = cost()
    assert r["case"] == "push_to_pay" and r["number"] == 3
    assert (r["lands"]["games"], r["lands"]["of"]) == _get("spread_line", "regular", 3)[:2]
    q = r["lands"]["chance"]
    assert q == pytest.approx(44 / 418)
    # Before: pays, pushes and loses; after: the push becomes a payout and nothing else moves.
    assert r["without"]["push"] == pytest.approx(q) and r["with"]["push"] == 0
    assert r["with"]["pays"] == pytest.approx(r["without"]["pays"] + q)
    assert r["with"]["loses"] == pytest.approx(r["without"]["loses"])
    # Break-even is the price at which the two bets average the same; -130 is cheaper than that here.
    assert r["break_even"]["american"] == -136
    assert r["break_even"]["offered_is"] == "better"
    assert r["average"]["per_100"] == pytest.approx(1.84, abs=0.01)


def test_the_break_even_price_is_the_price_at_which_buying_costs_nothing_on_average():
    for args in [("spread", -3.0, -2.5), ("spread", 3.0, 3.5), ("spread", -3.5, -3.0), ("spread", 6.5, 7.0),
                 ("spread", -7.0, -6.5), ("total", 44.0, 43.5, "-110", "-110", "over"),
                 ("total", 44.5, 44.0, "-115", "-115", "over"), ("total", 47.0, 47.5, "-110", "-110", "under")]:
        first = cost(*args)
        even = first["break_even"]["decimal"]
        again = half_point_cost(args[0], args[1], args[2], first["price"]["decimal"], even,
                                side=args[5] if len(args) > 5 else "over")
        assert abs(again["average"]["per_100"]) < 0.01, args
        assert again["break_even"]["offered_is"] == "same", args


def test_a_cheaper_half_point_is_never_worse_and_the_verdict_follows_the_average():
    last = None
    for bprice in ("-160", "-145", "-135", "-130", "-125", "-115", "-110", "+100"):
        r = cost(bprice=bprice)
        if last is not None:
            assert r["average"]["per_100"] > last["average"]["per_100"]
        last = r
        assert (r["break_even"]["offered_is"] == "better") == (r["average"]["per_100"] > 0)
    assert cost(bprice="-170")["break_even"]["offered_is"] == "worse"


def test_the_range_brackets_the_average_and_is_wider_where_fewer_games_back_it():
    for args in [dict(), dict(line=-7.0, bought=-6.5), dict(line=-5.0, bought=-4.5), dict(line=-3.5, bought=-3.0)]:
        r = cost(**args)["average"]
        assert r["low"] <= r["per_100"] <= r["high"]
    three, seven = cost()["average"], cost(line=-7.0, bought=-6.5)["average"]
    assert seven["high"] - seven["low"] > three["high"] - three["low"], "163 games say less than 418"


def test_the_same_games_move_the_same_way_for_the_favourite_and_the_underdog():
    a, b = cost(line=-3.0, bought=-2.5), cost(line=3.0, bought=3.5)
    assert a["average"] == b["average"] and a["lands"]["chance"] == b["lands"]["chance"]
    c, d = cost(line=-3.5, bought=-3.0), cost(line=2.5, bought=3.0)
    assert c["case"] == d["case"] == "loss_to_push" and c["number"] == d["number"] == 3


def test_buying_onto_the_number_turns_a_loss_into_a_push_and_off_it_a_push_into_a_payout():
    onto = cost(line=-3.5, bought=-3.0)
    assert onto["case"] == "loss_to_push"
    assert onto["with"]["push"] == pytest.approx(onto["lands"]["chance"]) and onto["without"]["push"] == 0
    assert onto["with"]["loses"] == pytest.approx(onto["without"]["loses"] - onto["lands"]["chance"])
    assert "a push" in onto["moves"] and "loses" in onto["moves"]
    off = cost(line=-3.0, bought=-2.5)
    assert off["case"] == "push_to_pay" and "pays" in off["moves"]


def test_a_total_takes_the_over_down_and_the_under_up():
    over = cost("total", 44.0, 43.5, "-110", "-125", "over")
    under = cost("total", 44.0, 44.5, "-110", "-125", "under")
    assert over["case"] == under["case"] == "push_to_pay" and over["number"] == under["number"] == 44
    assert over["lands"]["of"] == under["lands"]["of"] and over["lands"]["games"] == under["lands"]["games"]
    for args in [("total", 44.0, 44.5, "-110", "-125", "over"), ("total", 44.0, 43.5, "-110", "-125", "under")]:
        with pytest.raises(OddsError, match="wrong way"):
            cost(*args)


def test_a_total_lands_on_its_line_less_often_than_the_unconditional_share_and_both_are_shown():
    r = cost("total", 44.0, 43.5, "-110", "-125", "over")
    count, of, _ = _get("total_line", "regular", "whole")
    assert (r["lands"]["games"], r["lands"]["of"]) == (count, of)
    assert r["all_games"]["games"] == _get("points", "regular", 44)[0]
    assert "points in all" in r["all_games"]["text"]


def test_a_spread_shows_how_often_any_game_ends_that_many_apart_beside_the_line_figure():
    r = cost()
    assert r["all_games"]["games"] == _get("margin", "regular", 3)[0]
    assert r["all_games"]["of"] == _get("margin", "regular", 3)[1]
    assert "ended exactly 3 apart" in r["all_games"]["text"]


def test_a_number_with_too_few_games_at_it_says_so_and_falls_back_rough():
    few = cost(line=-12.0, bought=-11.5)
    assert halfpoint.load().spread[12][1] < halfpoint.MIN_LINE_GAMES
    assert few["lands"]["used"] == "all games, halved" and "rough" in few["lands"]["basis"]
    assert cost(line=-3.0, bought=-2.5)["lands"]["used"] == "closing spread"


def test_a_pickem_line_lands_on_a_tie():
    r = cost(line=-0.5, bought=0.0, bprice="-115")
    assert r["number"] == 0 and r["lands"]["used"] == "ties" and "tied" in r["moves"]
    assert r["lands"]["games"] == _get("margin", "regular", 0)[0]


def test_the_wilson_range_is_the_textbook_one():
    lo, hi = wilson(44, 418)
    assert (lo, hi) == pytest.approx((0.0790, 0.1380), abs=0.0005)
    assert wilson(0, 61)[0] == 0 and 0.05 < wilson(0, 61)[1] < 0.07


@pytest.mark.parametrize("args,why", [
    (dict(line=-3.0, bought=-3.0), "half a point apart"),
    (dict(line=-3.0, bought=-2.0), "half a point apart"),
    (dict(line=-3.0, bought=-3.5), "wrong way"),
    (dict(line=-2.75, bought=-2.25), "halves"),
    (dict(market="total", line=0.5, bought=0.0), "at least one"),
])
def test_lines_that_are_not_a_bought_half_point_are_refused_in_plain_words(args, why):
    with pytest.raises(OddsError, match=why):
        cost(**args)


def test_other_sports_and_other_bets_are_refused():
    with pytest.raises(OddsError):
        half_point_cost("moneyline", -3, -2.5, 1.9, 1.8)
    with pytest.raises(OddsError):
        half_point_cost("total", 44, 43.5, 1.9, 1.8, side="both")


# ------------------------------------------------------------------ the words

def _sentences(r):
    return " ".join([r["headline"], r["moves"], *r["say"], r["assumption"], r["covers"], r["lands"]["text"],
                     *r["notes"], *(f"{k} {v}" for k, v in r["rows"])])


def test_the_engine_says_what_table_it_used_and_that_it_is_an_average():
    r = cost()
    assert "NFL 2015 to 2025, regular season" in r["covers"]
    assert "NFL 2015 to 2025, regular season" in " ".join(r["notes"])
    assert "average" in " ".join(r["say"]) and "can still lose" in " ".join(r["say"])
    assert "per $100" in " ".join(r["say"])
    assert "better than that" in " ".join(r["say"]) or "worse than that" in " ".join(r["say"])


def test_no_sentence_promises_anything_across_a_grid_of_lines_and_prices():
    for market, lines in (("spread", [(-3.0, -2.5), (3.0, 3.5), (-3.5, -3.0), (-6.5, -6.0), (-7.0, -6.5), (-10.0, -9.5),
                                      (-0.5, 0.0), (-14.0, -13.5)]),
                          ("total", [(44.0, 43.5), (44.5, 44.0), (37.0, 36.5), (51.0, 50.5)])):
        for line, bought in lines:
            for bprice in ("-105", "-115", "-130", "-150", "+105"):
                r = cost(market, line, bought, "-110", bprice)
                assert not BANNED.search(_sentences(r)), (market, line, bought, bprice, BANNED.search(_sentences(r)))


def test_the_page_text_around_the_card_promises_nothing_either():
    card = HTML[HTML.index('id="hp-market"') - 600:HTML.index('id="out-half"') + 100]
    assert not BANNED.search(re.sub(r"<[^>]+>", " ", card))


# ------------------------------------------------------------------ the verb and the window

def run(*argv):
    r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "devig", *argv], cwd=ROOT / "backend",
                       capture_output=True, text=True)
    return r


def test_devig_half_answers_through_the_existing_verb_with_json():
    r = run("--json", "--half", "--line=-3", "--bought-line=-2.5", "-110", "-130")
    assert r.returncode == 0, r.stderr
    out = json.loads(r.stdout)
    assert out["half"] is True and out["command"] == "devig" and out["number"] == 3
    assert out["break_even"]["american_text"] == "-136" and out["rows"] and out["notes"] and out["say"]


def test_devig_half_works_for_a_total_and_prints_words_without_json():
    r = run("--half", "--market=total", "--side=under", "--line=44", "--bought-line=44.5", "-110", "-120")
    assert r.returncode == 0, r.stderr
    assert "44" in r.stdout and "average" in r.stdout and "NFL 2015 to 2025, regular season" in r.stdout


def test_devig_half_refuses_a_missing_line_and_a_line_the_wrong_way_with_a_sentence():
    r = run("--json", "--half", "--line=-3", "-110", "-130")
    assert r.returncode == 2 and "line before and after" in r.stderr
    r = run("--json", "--half", "--line=-2.5", "--bought-line=-3", "-110", "-130")
    assert r.returncode == 2 and "wrong way" in r.stderr
    r = run("--json", "--half", "--line=-3", "--bought-line=-2.5", "-110")
    assert r.returncode == 2 and "two prices" in r.stderr


def test_devig_without_half_is_unchanged():
    out = json.loads(run("--json", "-110", "-110").stdout)
    assert out.get("half") is None and out["outcomes"]


def test_the_shell_allow_list_did_not_grow():
    assert re.search(r"const ALLOWED: \[&str; 22\]", RUST)


def test_the_card_is_in_the_tools_fair_odds_panel_with_every_control_read():
    panel = HTML[HTML.index('id="panel-devig"'):HTML.index('id="panel-kelly"')]
    for ident in ("hp-market", "hp-side", "hp-line", "hp-price", "hp-bline", "hp-bprice", "out-half"):
        assert f'id="{ident}"' in panel, ident
        if ident != "out-half":
            assert f'val("{ident}")' in JS, ident
    assert 'data-run="half"' in panel


def test_the_window_sends_both_lines_both_prices_and_the_market_to_devig():
    builder = JS[JS.index("    half: () =>"):]
    builder = builder[:builder.index("],\n") + 2]
    assert builder.startswith('    half: () => ["devig", "--half"')
    for part in ('`--market=${val("hp-market")}`', '`--side=${val("hp-side")}`', '`--line=${val("hp-line")}`',
                 '`--bought-line=${val("hp-bline")}`', 'val("hp-price")', 'val("hp-bprice")'):
        assert part in builder, part


def test_the_window_draws_the_engines_words_and_figures_and_does_no_arithmetic():
    body = JS[JS.index("function showHalf(box, out)"):]
    body = body[:body.index("\n}\n")]
    for field in ("out.headline", "out.moves", "out.say", "out.rows", "out.notes"):
        assert field in body, field
    assert not re.search(r"toFixed|Math\.|\bpct\(|\* ?100|parseFloat|Number\(", body), body
    assert "({ half: showHalf," in JS
