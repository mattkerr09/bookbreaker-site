"""Fixes from the full audit of 2026-11-04 that live in the app: the Arbitrage page never promises the difference
without its condition (L7), the compliance line says 21+ in every state with the legal minimum beside it (DC, WY), and
a win chance typed as a percentage is refused in a sentence, not a crash (B2)."""
import json
import os
import subprocess
import sys
from pathlib import Path

from overlay_engine import offerlink

ROOT = Path(__file__).resolve().parents[1]


def test_the_arbitrage_page_says_the_difference_holds_only_if_both_bets_stand():
    html = (ROOT / "ui" / "src" / "index.html").read_text()
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    for text in (html, js):
        for line in text.splitlines():
            if "keep the difference" in line:
                assert "accepted and stand" in line, line.strip()[:120]


def test_every_state_reads_21_plus_and_an_18_state_says_its_legal_minimum_beside_it():
    for st in ("DC", "WY"):
        c = offerlink.compliance(st)
        assert c["age"] == "21+" and c["text"].startswith(f"21+ and in {st}.")
        assert "The legal minimum in" in c["text"] and "is 18" in c["text"] and "18+" not in c["text"]
    mi = offerlink.compliance("MI")
    assert mi["age"] == "21+" and "legal minimum" not in mi["text"]


def test_a_win_chance_typed_as_a_percentage_is_a_sentence_not_a_crash(tmp_path):
    env = {**os.environ, "OVERLAY_HOME": str(tmp_path)}
    for prob, words in (("45", "Type it as a share between 0 and 1"), ("0", "must be more than 0")):
        r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "kelly", "--odds=+150", "--prob", prob, "--json"],
                           cwd=ROOT / "backend", capture_output=True, text=True, env=env)
        assert r.returncode == 2 and words in json.loads(r.stdout)["error"]
    assert not list((tmp_path / "crashes").glob("*.json")) if (tmp_path / "crashes").exists() else True
