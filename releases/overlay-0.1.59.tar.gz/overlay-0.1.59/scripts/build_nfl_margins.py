#!/usr/bin/env python3
"""Build backend/overlay_engine/data/nfl_margins.csv: how NFL games end, by the point, for the half-point cost.

    python3 scripts/build_nfl_margins.py <nflverse games.csv> [--read-date YYYY-MM-DD] [--out PATH]

Source: nflverse's public schedule file,
https://github.com/nflverse/nflverse-data/releases/download/schedules/games.csv (columns used: game_type, season,
home_score, away_score, spread_line, total_line). Seasons 2015 to 2025. Games with no final score are left out.

The file is long-format, one row per figure: table, scope, key, count, of, pct, source, seasons, read.

  margin / regular                 absolute final margin (home minus away), regular season: games ending that many apart
  margin / regular_and_playoffs    the same with the playoffs added; the site's own page counts this way, so the
                                   figures can be checked against it
  points / regular                 combined points (home plus away), regular season
  spread_line / regular            for each whole closing spread N: how many of the games with that closing spread had
                                   the favourite finish ahead by exactly N (the push a half point turns into a payout)
  spread_line / regular_and_playoffs   the same with the playoffs added, to check against the site
  total_line / regular             games with a whole closing total, and how many finished on exactly that total

Nothing is rounded except the printed percentage (two decimals); counts are exact, so a reader can redo any figure.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "backend" / "overlay_engine" / "data" / "nfl_margins.csv"
SOURCE = "https://github.com/nflverse/nflverse-data/releases/download/schedules/games.csv"
FIRST, LAST = 2015, 2025
SEASONS = f"{FIRST}-{LAST}"
HEADER = ["table", "scope", "key", "count", "of", "pct", "source", "seasons", "read"]
#: nflverse game types: REG is the regular season; the rest are the playoff rounds.
PLAYOFFS = {"WC", "DIV", "CON", "SB"}


def _num(x):
    """A number from a nflverse cell, or None when the cell is empty or NA."""
    if x is None or x.strip() in ("", "NA"):
        return None
    return float(x)


def _pct(count: int, of: int) -> str:
    return f"{100 * count / of:.2f}" if of else "0.00"


def build_rows(games, read_date: str) -> list[list[str]]:
    """The table's rows from nflverse game rows (dicts), in a fixed order."""
    margin = {"regular": collections.Counter(), "regular_and_playoffs": collections.Counter()}
    points = collections.Counter()
    # closing spread N -> games with that line, and how many had the favourite finish ahead by exactly N; per scope
    on_line = {"regular": collections.Counter(), "regular_and_playoffs": collections.Counter()}
    hit_line = {"regular": collections.Counter(), "regular_and_playoffs": collections.Counter()}
    total_games = total_hits = 0
    for g in games:
        season = int(g["season"])
        kind = g["game_type"]
        if not FIRST <= season <= LAST or (kind != "REG" and kind not in PLAYOFFS):
            continue
        home, away = _num(g["home_score"]), _num(g["away_score"])
        if home is None or away is None:
            continue
        diff = int(home - away)
        scopes = ["regular_and_playoffs"] + (["regular"] if kind == "REG" else [])
        # spread_line is the home team's closing margin: positive when home is favoured. A push on a whole line is a
        # home margin equal to it, which is the favourite finishing ahead by exactly that many either way round.
        line = _num(g.get("spread_line"))
        for scope in scopes:
            margin[scope][abs(diff)] += 1
            if line is not None and line == int(line) and line != 0:
                on_line[scope][int(abs(line))] += 1
                if diff == int(line):
                    hit_line[scope][int(abs(line))] += 1
        if kind != "REG":
            continue
        points[int(home + away)] += 1
        total = _num(g.get("total_line"))
        if total is not None and total == int(total):
            total_games += 1
            total_hits += int(home + away) == int(total)

    tail = [SOURCE, SEASONS, read_date]
    rows = []
    for scope in ("regular", "regular_and_playoffs"):
        n = sum(margin[scope].values())
        for k in range(0, max(margin[scope]) + 1):
            rows.append(["margin", scope, str(k), str(margin[scope][k]), str(n), _pct(margin[scope][k], n), *tail])
    n = sum(points.values())
    for k in range(0, max(points) + 1):
        rows.append(["points", "regular", str(k), str(points[k]), str(n), _pct(points[k], n), *tail])
    for scope in ("regular", "regular_and_playoffs"):
        for k in sorted(on_line[scope]):
            rows.append(["spread_line", scope, str(k), str(hit_line[scope][k]), str(on_line[scope][k]),
                         _pct(hit_line[scope][k], on_line[scope][k]), *tail])
    rows.append(["total_line", "regular", "whole", str(total_hits), str(total_games), _pct(total_hits, total_games), *tail])
    return rows


def write(path: Path, rows: list[list[str]]) -> None:
    with open(path, "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(HEADER)
        w.writerows(rows)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("games", help="nflverse schedules games.csv")
    ap.add_argument("--read-date", default=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d"),
                    help="the day the file was read (default: today, UTC)")
    ap.add_argument("--out", default=str(OUT))
    args = ap.parse_args(argv)
    with open(args.games, newline="") as f:
        rows = build_rows(csv.DictReader(f), args.read_date)
    write(Path(args.out), rows)
    print(f"wrote {len(rows)} rows to {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
