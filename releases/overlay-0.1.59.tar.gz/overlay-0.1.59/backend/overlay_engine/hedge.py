"""Hedge a bet you already have: what to bet on the other side, and what each result then pays.

The AVO bar's top gap (ops/qa/bookbreaker/AVO_BAR.md, 2026-10-30): a bet is open, its price has moved, and the
bettor wants to know what a bet on the other side would do. Two hedges are worked out from the bet's own stake and
price and the other side's price as typed:

  same result   the hedge stake that leaves the same result whichever side wins
  stake back    the smallest hedge stake that returns the original stake if the other side wins

and, beside them, what holding the bet alone pays. Results assume both bets are accepted and stand, and that the two
sides are the only outcomes (a push or a void returns each stake). It places nothing, reads nothing, and the window
does no arithmetic: every figure and sentence is worked out here.
"""
from __future__ import annotations

from .ledger import Ledger, LedgerError
from .odds import OddsError, decimal_to_american, parse_odds


def _money(x: float) -> str:
    return f"{'-' if x < 0 else ''}${abs(x):,.2f}"


def _signed(x: float) -> str:
    return f"{'+' if x >= 0 else '-'}${abs(x):,.2f}"


def _amer(decimal: float) -> str:
    a = round(decimal_to_american(decimal))
    return f"{'+' if a > 0 else '-'}{abs(a)}"


def plan(stake: float, held_decimal: float, other_price) -> dict:
    """The two hedges for a bet of `stake` at `held_decimal`, against `other_price` (American or decimal)."""
    try:
        other = parse_odds(other_price)
    except OddsError as exc:
        raise OddsError(f"{exc} Type the other side's price, like -120 or +105.") from None
    if not stake > 0:
        raise OddsError("The bet's stake must be more than zero.")
    held_win = stake * (held_decimal - 1.0)

    def row(name, h, why):
        h = round(h, 2)
        if_held = round(held_win - h, 2)
        if_other = round(h * (other - 1.0) - stake, 2)
        return {"name": name, "hedge_stake": h, "hedge_text": _money(h), "if_held_wins": if_held,
                "if_other_wins": if_other, "if_held_text": _signed(if_held), "if_other_text": _signed(if_other),
                "why": why}

    same = row("Same result", stake * held_decimal / other,
               "The hedge stake that leaves the same result whichever side wins.")
    back = row("Stake back", stake / (other - 1.0),
               "The smallest hedge that returns your original stake if the other side wins.")
    rows = [row("No hedge", 0.0, "Keep the bet as it is."), back, same]
    locked = same["if_held_wins"]
    if locked >= 0:
        headline = (f"Bet {same['hedge_text']} on the other side at {_amer(other)} and either result is "
                    f"{same['if_held_text']}, if both bets are accepted and stand.")
    else:
        headline = (f"At {_amer(other)} the other side costs more than your bet can cover: a same-result hedge of "
                    f"{same['hedge_text']} leaves {same['if_held_text']} on either result. Holding, or the stake-back "
                    "hedge, may suit you better.")
    return {"stake": round(stake, 2), "held_price": _amer(held_decimal), "other_price": _amer(other),
            "headline": headline, "rows": rows,
            "notes": ["Both bets must be accepted at these prices and both must stand.",
                      "A push or a void returns each stake.",
                      "Bookbreaker places nothing; the price you can get may differ from the one typed."]}


def from_reads(db: Ledger, bet_id: int, reads: list, bettable, now: float) -> dict:
    """The hedge for open bet `bet_id` at the best price on the other side in odds already read on this Mac (the AVO
    bar's item 18): the bet's game and market are found in `reads` (screen.history_reads), the opposite side is taken
    at every book in `bettable` (the books licensed in the chosen state), best price first, and the best is planned as
    `plan` does. It reads files only, places nothing, and says how old each price is."""
    from . import screen
    from .lowholdview import _two_way_sets
    bet = db.get_bet(bet_id)
    if bet is None:
        raise LedgerError(f"There is no bet {bet_id}.")
    if bet.get("profit") is not None:
        raise LedgerError(f"Bet {bet_id} is already settled, so there is nothing to hedge.")
    options, names = [], {}
    for read in reads:
        names.update(read.names)
        for market in read.markets:
            if str(market.event_id) != str(bet.get("event_id")) or market.market_type != bet.get("market_type"):
                continue
            for _line, keys, sides in _two_way_sets(market, bettable):
                if bet.get("outcome") not in keys:
                    continue
                other = keys[1] if keys[0] == bet.get("outcome") else keys[0]
                best: dict = {}
                for q in sides[other]:
                    if q.book not in best or q.decimal > best[q.book].decimal:
                        best[q.book] = q
                for q in best.values():
                    age = round(max(0.0, now - q.seen_at), 1)
                    options.append({"book": q.book, "book_name": screen.book_name(q.book, names), "decimal": q.decimal,
                                    "american": _amer(q.decimal), "age": age, "age_text": f"read {screen.ago(age)}"})
    if not options:
        raise LedgerError("The other side of this bet is not in the odds read on this Mac in the last six hours, at a "
                          "book licensed in your state. Type its price, or read the odds again.")
    options.sort(key=lambda o: (-o["decimal"], o["age"], o["book_name"]))
    top = options[0]
    out = plan(float(bet["stake"]), float(bet["decimal_odds"]), top["american"])
    out.update(bet_id=bet_id, selection=bet.get("selection") or bet.get("outcome"), game=bet.get("game") or "",
               options=options[:8],
               found={"book": top["book"], "book_name": top["book_name"], "american": top["american"],
                      "text": (f"Best price on the other side in the odds read on this Mac: {top['american']} at "
                               f"{top['book_name']}, {top['age_text']}. Check it at the book before you bet: a price "
                               "can move at any moment.")})
    return out


def for_bet(db: Ledger, bet_id: int, other_price) -> dict:
    """The hedges for open bet `bet_id` in this Mac's ledger."""
    bet = db.get_bet(bet_id)
    if bet is None:
        raise LedgerError(f"There is no bet {bet_id}.")
    if bet.get("profit") is not None:
        raise LedgerError(f"Bet {bet_id} is already settled, so there is nothing to hedge.")
    out = plan(float(bet["stake"]), float(bet["decimal_odds"]), other_price)
    out["bet_id"] = bet_id
    out["selection"] = bet.get("selection") or bet.get("outcome")
    out["game"] = bet.get("game") or ""
    return out
