"""Is buying a half point worth it? (the AVO bar's item 36)

Buying a half point moves a line by 0.5 in your favour for a worse price: -3 at -110 becomes -2.5 at -130. The line
only matters in the games that finish on the number the half point moves across. Everything else pays or loses exactly
as before. So the whole question is how often a game finishes on that number, and whether the extra cost is smaller or
larger than what that is worth.

Where the numbers come from: `data/nfl_margins.csv`, rebuilt by `scripts/build_nfl_margins.py` from nflverse's public
schedule file. NFL only, regular season 2015 to 2025, and the engine says so in every answer.

  * Spreads: of the games whose closing spread was exactly N, how many had the favourite finish ahead by exactly N.
    That is the share that pushes at N, pays at N+0.5 for the favourite's side and loses at N-0.5 for it. A number with
    fewer than `MIN_LINE_GAMES` games at it falls back to half the share of all games that ended N apart, and says so.
  * Totals: of the games whose closing total was a whole number, how many finished on exactly that total.

What the extra cost buys, as an average, is worked from one stated assumption: before the half point, the games that
do not land on the number split evenly between your side and the other. That is what a fair line is. The window shows
the assumption, and the answer is a range, not a point, because the share of games on the number is itself measured
from a limited number of games.
"""

from __future__ import annotations

import csv
import functools
import math
from pathlib import Path

from .odds import OddsError, decimal_to_american

DATA = Path(__file__).resolve().parent / "data" / "nfl_margins.csv"
#: The fewest games at a closing spread before that number's own share is trusted.
MIN_LINE_GAMES = 30
#: Which side of a total, as the engine takes it.
SIDES = ("over", "under")
MARKETS = ("spread", "total")
#: Under this many dollars per $100 the two bets are the same on average.
_SAME = 0.005
COVERS = "NFL 2015 to 2025, regular season"
ASSUMPTION_TEXT = ("The games that do not land on the number are taken as a coin flip before the half point, the way a "
                   "fair line sets them. If you think your side is better or worse than the line says, the half point "
                   "is worth a little more or less than this.")
COVERS_TEXT = ("The figures cover {covers}: {games:,} games, from nflverse's schedule file ({source}), read {read}. "
               "Other sports and other seasons are not in it.")


class Table:
    """The shipped counts, read once."""

    def __init__(self, rows: list[dict]):
        self.rows = rows
        self.source = rows[0]["source"]
        self.seasons = rows[0]["seasons"]
        self.read = rows[0]["read"]
        self.margin = {}
        self.points = {}
        self.spread = {}
        self.total = None
        for r in rows:
            if r["scope"] != "regular":
                continue
            key, count, of = r["key"], int(r["count"]), int(r["of"])
            if r["table"] == "margin":
                self.margin[int(key)] = (count, of)
            elif r["table"] == "points":
                self.points[int(key)] = (count, of)
            elif r["table"] == "spread_line":
                self.spread[int(key)] = (count, of)
            elif r["table"] == "total_line":
                self.total = (count, of)
        if not (self.margin and self.points and self.spread and self.total):
            raise OddsError("The NFL margins table is incomplete. Reinstall Bookbreaker.")
        self.games = next(iter(self.margin.values()))[1]


@functools.lru_cache(maxsize=1)
def load() -> Table:
    with open(DATA, newline="") as f:
        return Table(list(csv.DictReader(f)))


def wilson(count: int, of: int, z: float = 1.96) -> tuple[float, float]:
    """The 95% range the true share could be in, given `count` of `of` (Wilson's interval)."""
    if of <= 0:
        return 0.0, 1.0
    p = count / of
    d = 1 + z * z / of
    centre = (p + z * z / (2 * of)) / d
    half = z * math.sqrt(p * (1 - p) / of + z * z / (4 * of * of)) / d
    return max(0.0, centre - half), min(1.0, centre + half)


def _line(x: float) -> str:
    """A total the way a book prints it: 44, 44.5."""
    return f"{x:g}"


def _pc(x: float) -> str:
    """A share of games as a percentage, with a second decimal when it is under one percent."""
    return f"{x:.2%}" if x < 0.01 else f"{x:.1%}"


def _signed(x: float) -> str:
    return f"+{x:g}" if x > 0 else f"{x:g}"


def _american(decimal: float) -> tuple[int, str]:
    a = round(decimal_to_american(decimal))
    return a, f"{'+' if a > 0 else ''}{a}"


def _money(x: float) -> str:
    x = round(x, 2)
    return f"{'-' if x < 0 else ''}${abs(x):,.2f}"


def _share(table: Table, market: str, n: int) -> dict:
    """How often a game finishes on the number, with the range and where the figure came from."""
    if market == "total":
        count, of = table.total
        basis = (f"Of {of:,} games whose closing total was a whole number, {count:,} finished on exactly that total "
                 f"({count / of:.1%}).")
        used = "totals"
        of_what = "games with a whole-number closing total"
    elif n == 0:
        count, of = table.margin[0]
        basis = (f"{count:,} of the {of:,} games ended tied ({count / of:.1%}), and a pick'em line pushes on a tie.")
        used = "ties"
        of_what = "games"
    else:
        count, of = table.spread.get(n, (0, 0))
        if of >= MIN_LINE_GAMES:
            basis = (f"Of {of:,} games that closed at exactly {n}, the favourite finished ahead by exactly {n} in "
                     f"{count:,} ({count / of:.1%}).")
            used = "closing spread"
            of_what = f"games that closed at {n}"
        else:
            both, games = table.margin.get(n, (0, table.games))
            count, of = both / 2, games
            basis = (f"Only {table.spread.get(n, (0, 0))[1]} games closed at exactly {n}, too few to use on their own. "
                     f"This is half the share of all {games:,} games that ended exactly {n} apart "
                     f"({both:,}, {both / games:.1%}), so treat it as rough.")
            used = "all games, halved"
            of_what = f"games, roughly (one team's share of those ending {n} apart)"
    lo, hi = wilson(count, of)
    return {"p": count / of, "low": lo, "high": hi, "count": count, "of": of, "basis": basis, "used": used, "of_what": of_what}


def _outcomes(case: str, q: float) -> dict:
    """Win, push and loss chances for the line before and after the half point, from the one assumption stated:
    the games that do not land on the number split evenly before the half point is bought."""
    if case == "push_to_pay":      # the line you have is the whole number: those games push, and the bought line pays
        before = {"pays": (1 - q) / 2, "push": q, "loses": (1 - q) / 2}
        after = {"pays": (1 + q) / 2, "push": 0.0, "loses": (1 - q) / 2}
    else:                          # the bought line is the whole number: those games lose, and the bought line pushes
        before = {"pays": 0.5, "push": 0.0, "loses": 0.5}
        after = {"pays": 0.5, "push": q, "loses": 0.5 - q}
    return {"before": before, "after": after}


def _ev(chances: dict, decimal: float) -> float:
    """Average profit on a $1 bet, a push returning the stake."""
    return chances["pays"] * (decimal - 1.0) - chances["loses"]


def _at(case: str, q: float, d_before: float, d_after: float) -> tuple[float, float, float | None]:
    """(average profit before, average profit after, break-even decimal price for the bought half point) per $1."""
    o = _outcomes(case, q)
    ev0, ev1 = _ev(o["before"], d_before), _ev(o["after"], d_after)
    if o["after"]["pays"] <= 0:
        return ev0, ev1, None
    even = 1.0 + (ev0 + o["after"]["loses"]) / o["after"]["pays"]
    return ev0, ev1, (even if even > 1.0 else None)


def _all_games(table: Table, market: str, n: int) -> dict | None:
    """The same number in every game of the table, whatever the line was: context for the figure above."""
    if market == "spread":
        count, of = table.margin.get(n, (0, table.games))
        text = f"Across all {of:,} games in the table, {count / of:.1%} ended exactly {n} apart, with either team ahead."
    else:
        count, of = table.points.get(n, (0, table.games))
        text = f"Across all {of:,} games in the table, {count / of:.1%} finished with exactly {n} points in all."
    return {"games": count, "of": of, "chance": count / of, "text": text}


def _event(market: str, n: int) -> str:
    if market == "total":
        return f"the two teams score exactly {n} between them"
    if n == 0:
        return "the game ends tied"
    return f"the favourite finishes ahead by exactly {n}"


def half_point_cost(market: str, line: float, bought_line: float, price: float, bought_price: float,
                    side: str = "over") -> dict:
    """What a bought half point costs and what it is worth, on average.

    `line` and `price` are the bet without the half point, `bought_line` and `bought_price` with it. Prices are decimal.
    A spread is read from your side (-3 means you lay 3; +3 means you take 3). A total is the over or the under."""
    if market not in MARKETS:
        raise OddsError(f"Half-point cost is for a spread or a total, not {market!r}.")
    if side not in SIDES:
        raise OddsError("Say whether the total is the over or the under.")
    if price <= 1.0 or bought_price <= 1.0:
        raise OddsError("Type both prices, like -110 and -130.")
    for x in (line, bought_line):
        if not math.isfinite(x) or abs(x * 2 - round(x * 2)) > 1e-9:
            raise OddsError("Lines come in halves, like -3 or -2.5 or 44.5.")
    gain = (bought_line - line) if (market == "spread" or side == "under") else (line - bought_line)
    if abs(abs(gain) - 0.5) > 1e-9:
        raise OddsError("The two lines must be half a point apart, like -3 and -2.5.")
    if gain < 0:
        raise OddsError("That moves the line the wrong way for you. Buying a half point makes a spread half a point "
                        "higher (-3 becomes -2.5, +3 becomes +3.5), the over half a point lower and the under half a "
                        "point higher. Type the line you have, then the line with the half point bought.")
    if market == "total" and min(line, bought_line) < 1:
        raise OddsError("A total has to be at least one point.")

    case = "push_to_pay" if line == int(line) else "loss_to_push"
    n = int(abs(line)) if case == "push_to_pay" else int(abs(bought_line))
    table = load()
    share = _share(table, market, n)
    q, lo, hi = share["p"], share["low"], share["high"]

    ev0, ev1, even = _at(case, q, price, bought_price)
    delta = 100 * (ev1 - ev0)
    ends = []
    for edge in (lo, hi):
        e0, e1, ev = _at(case, edge, price, bought_price)
        ends.append((100 * (e1 - e0), ev))
    d_low, d_high = min(e[0] for e in ends), max(e[0] for e in ends)
    evens = [e[1] for e in ends if e[1] is not None]

    def price_of(decimal):
        if decimal is None:
            return None
        a, text = _american(decimal)
        return {"decimal": decimal, "american": a, "american_text": text}

    even_p = price_of(even)
    if abs(delta) < _SAME:
        offered_is = "same"
    else:
        offered_is = "better" if delta > 0 else "worse"
    o = _outcomes(case, q)
    side_word = ("the over" if side == "over" else "the under") if market == "total" else "your side"

    before_line, after_line = ((_signed(line), _signed(bought_line)) if market == "spread"
                               else (_line(line), _line(bought_line)))
    _, p0_text = _american(price)
    _, p1_text = _american(bought_price)
    what = _event(market, n)
    if case == "push_to_pay":
        moves = (f"At {before_line}, a game where {what} is a push and your stake comes back. At {after_line}, that "
                 f"same game pays.")
    else:
        moves = (f"At {before_line}, a game where {what} loses. At {after_line}, that same game is a push and your "
                 f"stake comes back.")
    lands = (f"{what[0].upper()}{what[1:]} in about {_pc(q)} of {share['of_what']}"
             f" (somewhere between {_pc(lo)} and {_pc(hi)}).")

    ev_range = sorted(evens)
    say = []
    if even_p is None:
        say.append("On these figures no price makes this half point worse than the bet you have.")
    else:
        rng = ""
        if len(ev_range) == 2 and _american(ev_range[0])[1] != _american(ev_range[1])[1]:
            rng = (f" It could be anywhere between {_american(ev_range[1])[1]} and {_american(ev_range[0])[1]}, because "
                   "how often games land on the number is measured from a limited number of games.")
        verdict = {"better": "better than that", "worse": "worse than that", "same": "the same as that"}[offered_is]
        say.append(f"The break-even price for the bought half point is about {even_p['american_text']}.{rng} "
                   f"You were offered {p1_text}, which is {verdict}.")
    if offered_is == "same":
        say.append("On average the half point costs about what it is worth.")
    else:
        say.append(f"On average, over many bets, buying it comes out about {_money(abs(delta))} "
                   f"{'better' if delta > 0 else 'worse'} per $100 bet (somewhere between {_money(d_low)} and "
                   f"{_money(d_high)}).")
    if d_low < 0 < d_high:
        say.append("The range runs from worse to better, so the games in the table cannot say which this half point is.")
    say.append("That is an average. Any one bet can still lose, and a run of bets can finish above or below it.")

    headline = {"better": f"At {p1_text}, the bought half point is priced better than its break-even",
                "worse": f"At {p1_text}, the bought half point is priced worse than its break-even",
                "same": f"At {p1_text}, the bought half point is priced about at its break-even"}[offered_is]
    if even_p is None:
        headline = f"At {p1_text}, the bought half point is priced better than anything it could cost"
    ways = lambda c: f"pays {c['pays']:.1%}, push {c['push']:.1%}, loses {c['loses']:.1%}"
    sign = lambda x: f"+{_money(x)}" if x > 0 else _money(x)
    rows = [
        [what[0].upper() + what[1:], f"{_pc(q)} of {share['of_what']} (somewhere between {_pc(lo)} and {_pc(hi)})"],
        ["Break-even price for the bought half point", even_p["american_text"] if even_p else "none"],
        ["Price you were offered", p1_text],
        ["Average difference per $100 bet", f"{sign(delta)} (somewhere between {sign(d_low)} and {sign(d_high)})"],
        [f"Without it: {before_line} at {p0_text}", f"{ways(o['before'])}; average {sign(100 * ev0)} per $100 bet"],
        [f"With it bought: {after_line} at {p1_text}", f"{ways(o['after'])}; average {sign(100 * ev1)} per $100 bet"],
    ]
    all_games = _all_games(table, market, n)
    return {
        "command": "devig", "half": True, "headline": headline, "rows": rows,
        "notes": [all_games["text"], share["basis"], ASSUMPTION_TEXT, COVERS_TEXT.format(
            covers=COVERS, games=table.games, source=table.source, read=table.read)], "market": market, "side": side if market == "total" else None,
        "line": line, "bought_line": bought_line,
        "line_text": before_line, "bought_line_text": after_line,
        "price": {"decimal": price, **dict(zip(("american", "american_text"), _american(price)))},
        "bought_price": {"decimal": bought_price, **dict(zip(("american", "american_text"), _american(bought_price)))},
        "case": case, "number": n, "event": what, "moves": moves,
        "lands": {"chance": q, "low": lo, "high": hi, "games": share["count"], "of": share["of"], "text": lands,
                  "basis": share["basis"], "used": share["used"]},
        "all_games": all_games,
        "break_even": {**(even_p or {}), "range": [price_of(e) for e in ev_range], "offered_is": offered_is},
        "average": {"per_100": round(delta, 2), "low": round(d_low, 2), "high": round(d_high, 2)},
        "without": {"pays": o["before"]["pays"], "push": o["before"]["push"], "loses": o["before"]["loses"],
                    "per_100": round(100 * ev0, 2)},
        "with": {"pays": o["after"]["pays"], "push": o["after"]["push"], "loses": o["after"]["loses"],
                 "per_100": round(100 * ev1, 2)},
        "say": say,
        "assumption": ASSUMPTION_TEXT,
        "covers": COVERS_TEXT.format(covers=COVERS, games=table.games, source=table.source, read=table.read),
    }
