"""Ask without a key: the same tools, answered by an AI running on this Mac.

When there is no Anthropic key, Ask can use a model served by Ollama on this computer
(http://127.0.0.1:11434). Nothing leaves the Mac: the question, the lookups and the
answer all stay local. It is a weaker AI than Claude at understanding a question and
explaining an answer; the numbers are the same, because the tools compute them either
way, and a small model's answer is checked against them (`askground.py`): one that states a
figure no lookup returned is thrown away and the lookup's own words are shown instead.

Only a model that can call tools is used (Ollama reports a "tools" capability). A
completion-only model cannot run the tools, so it would have to answer from memory,
which is exactly what Ask is built not to do.

**Nothing here installs, starts or downloads anything.** If Ollama is not running, or has
no tool-capable model, Ask says so and falls back to the built-in parser. The only socket
this module opens is to 127.0.0.1.

The HTTP call is a seam (`http`), so the loop is tested with no server.
"""

from __future__ import annotations

import json

BASE = "http://127.0.0.1:11434"
HOST = "127.0.0.1"
MAX_ROUNDS = 8

#: A smaller model drifts from the rules more easily, so they are restated plainly at
#: the end, where it reads them last.
LOCAL_RULES = """

You are running as a smaller model on the person's own computer. Keep to these strictly:
- Answer only from the tool results in this conversation. Never name a player, team, number, price or line that a tool result did not contain.
- Do no arithmetic of your own. Quote the figures the tools returned.
- Never say a bet "has value" or is "a good bet" unless a tool returned it.
- If a lookup returns nothing or an error, say so in one sentence; do not guess.
- Be brief: a short answer, then the supporting figures."""


def _http(method: str, path: str, body: dict | None = None, timeout: float = 120.0) -> dict:
    """The only part of this file that opens a socket: to this Mac only."""
    from urllib.request import Request, urlopen
    url = BASE + path
    if not url.startswith(f"http://{HOST}:"):
        raise OSError("Ollama is only ever asked on this Mac")
    data = None if body is None else json.dumps(body).encode()
    req = Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    with urlopen(req, timeout=timeout) as r:  # noqa: S310 - 127.0.0.1
        return json.loads(r.read().decode())


def status(http=None) -> dict:
    """Is Ollama running here, and which of its models can use tools?"""
    http = http or _http
    try:
        models = [m["name"] for m in http("GET", "/api/tags", timeout=1.5).get("models", [])]
    except Exception:              # noqa: BLE001 - not running is an answer, not an error
        return {"running": False, "models": [], "tool_models": []}
    tools = []
    for name in models:
        try:
            caps = http("POST", "/api/show", {"model": name}, timeout=5.0).get("capabilities") or []
        except Exception:          # noqa: BLE001
            caps = []
        if "tools" in caps:
            tools.append(name)
    return {"running": True, "models": models, "tool_models": tools}


def functions(defs: list) -> list:
    return [{"type": "function", "function": {"name": t["name"], "description": t["description"],
                                              "parameters": t["input_schema"]}} for t in defs]


def converse(question: str, history: list, model: str, system: str, defs: list, run, http=None) -> dict:
    """One question run to an answer with the local model calling the tools.

    `run(name, args) -> (text, is_error)` runs a tool. Returns {"text", "calls", "stop"}.
    `history` is [{"q", "a"}] of earlier turns in this conversation.
    """
    http = http or _http
    messages = [{"role": "system", "content": system + LOCAL_RULES}]
    for turn in history:
        messages += [{"role": "user", "content": turn["q"]}, {"role": "assistant", "content": turn["a"]}]
    messages.append({"role": "user", "content": question})
    calls = []
    for _ in range(MAX_ROUNDS):
        r = http("POST", "/api/chat", {"model": model, "messages": messages, "tools": functions(defs), "stream": False})
        msg = r.get("message") or {}
        messages.append({k: v for k, v in msg.items() if k in ("role", "content", "tool_calls")})
        tool_calls = msg.get("tool_calls") or []
        if not tool_calls:
            return {"text": (msg.get("content") or "").strip(), "calls": calls, "stop": "end_turn"}
        for tc in tool_calls:
            fn = tc.get("function") or {}
            name, args = fn.get("name", ""), fn.get("arguments") or {}
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except ValueError:
                    args = None
            args = args if isinstance(args, dict) else {}
            text, err = run(name, args)
            calls.append({"name": name, "args": args, "result": text, "error": err})
            messages.append({"role": "tool", "tool_name": name, "content": ("ERROR: " if err else "") + text})
    return {"text": "", "calls": calls, "stop": "max_rounds"}
