"""Ask with no AI at all: the common question shapes, recognised and sent to the right tool.

When there is no Anthropic key and no local model, Ask still answers the questions people
most often ask, because they have a fixed shape:

    "who is most likely to pass for 300 yards this week"      -> players
    "if I have 10 $1 bets, what are the best 10 parlays to make $200"   -> goal
    "best bets" / "any +EV" / "any arbs on tonight's games"    -> board
    "fair odds on -150 / +130"                                 -> devig
    "what does a -110 -110 +150 parlay pay"                    -> parlay
    "how much should I bet at +150 if I win 45%"               -> kelly
    "welcome offers in NJ"                                     -> welcome
    "how am I doing"                                           -> performance

It reads the question with plain patterns and never guesses: a question it does not
recognise gets a short list of what it can do, not a wrong answer. It computes nothing;
the tool it picks does, and `asktables.sentence` words the result.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from . import catalog, playerproj

_WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
          "eleven": 11, "twelve": 12, "fifteen": 15, "twenty": 20, "thirty": 30, "fifty": 50, "hundred": 100}

HELP = ("Without an AI I can answer these: who is most likely to pass for 300 yards this week (or rush, catch, throw touchdowns); "
        "'if I have 10 $1 bets, what are the best 10 parlays to make $200'; best bets; any arbs; any +EV bets; "
        "fair odds on -150 / +130; what a -110 -110 +150 parlay pays; how much to bet at +150 with a 45% chance; welcome offers in NJ; "
        "and how am I doing. For anything else, add your own Anthropic key in Ask's settings, or run a local model with Ollama.")


@dataclass
class Plan:
    calls: list = field(default_factory=list)      # [(tool name, args)]
    why: str = ""


def _clean(question: str) -> str:
    q = " ".join(question.lower().replace("’", "'").split())
    return re.sub(r"\b(" + "|".join(_WORDS) + r")\b", lambda m: str(_WORDS[m.group(1)]), q)


def _number(text: str) -> float:
    t = text.replace(",", "")
    mult = 1000 if t.endswith("k") else 1
    return float(t.rstrip("k")) * mult


_MONEY = re.compile(r"\$\s*(\d[\d,]*(?:\.\d+)?k?)")
_PRICE = re.compile(r"(?<![\w.$])([+-]\d{3,4})(?![\w.%])")
_DECIMAL = re.compile(r"(?<![\w.$+-])(\d\.\d{2,3})(?![\w.%])")


def _prices(q: str) -> list:
    found = [(m.start(), m.group(1)) for m in _PRICE.finditer(q)]
    found += [(m.start(), m.group(1)) for m in _DECIMAL.finditer(q)]
    return [p for _, p in sorted(found)]


def _stat(q: str):
    """The stat a question is about, from the verbs and nouns people use."""
    has = lambda *words: any(re.search(w, q) for w in words)  # noqa: E731
    if has(r"\bcompletions?\b"):
        return "completions"
    if has(r"\binterceptions?\b", r"\bints\b", r"\bpicks\b"):
        return "interceptions"
    if has(r"touchdown passes", r"\btd passes\b", r"passing t(d|ouchdown)s?", r"(pass|throw)\w* (for )?\d* ?(td|touchdown)", r"\btds thrown"):
        return "passing TDs"
    if has(r"pass attempts?", r"passing attempts?", r"\battempts?\b"):
        return "pass attempts"
    if has(r"\bcarries\b", r"\bcarry\b", r"rushing attempts?", r"rush attempts?"):
        return "carries"
    if has(r"receiving yards?", r"receiving yds", r"\bcatch\w* .*yards?", r"yards? receiving"):
        return "receiving yards"
    if has(r"\breceptions?\b", r"\bcatches\b", r"\bcatch\b"):
        return "receptions"
    if has(r"rushing yards?", r"\brush\w* .*yards?", r"yards? rushing", r"\brun\w* .*yards?"):
        return "rushing yards"
    if has(r"passing yards?", r"\b(pass|throw)\w* .*yards?", r"yards? passing", r"\bpass(es)? for\b"):
        return "passing yards"
    for alias in sorted(playerproj._ALIASES, key=len, reverse=True):
        if alias in q:
            return playerproj._ALIASES[alias]
    return None


def _players(q: str):
    if not re.search(r"\b(who|which|what|rank|top|leaders?|highest|most likely|best chance|likeliest|will)\b", q):
        return None
    stat = _stat(q)
    if stat is None:
        return None
    week = "this"
    if "next week" in q:
        week = "next"
    m = re.search(r"\bweek (\d{1,2})\b", q)
    if m:
        week = m.group(1)
    stripped = re.sub(r"\bweek \d{1,2}\b", " ", q)
    stripped = re.sub(r"\b(top|first|best|rank)\s+\d+\b", " ", stripped)
    nums = [m.group(1) for m in re.finditer(r"(?<![\w.])(\d{1,4}(?:\.\d)?)(?![\w.])", stripped)]
    args = {"stat": stat, "week": week}
    if nums:
        args["line"] = float(nums[0])
    return Plan([("players", args)], f"a question about {stat}")


def _goal(q: str):
    if not re.search(r"parlay|turn|bankroll|make|reach|win|bets?\b", q):
        return None
    money = [(m.start(), _number(m.group(1))) for m in _MONEY.finditer(q)]
    if not money:
        return None
    tickets = None
    bankroll = None
    m = re.search(r"(\d+)\s*(?:x\s*)?\$\s*(\d[\d,]*(?:\.\d+)?)\s*(?:bets?|tickets?|parlays?|each)", q)
    if m:
        tickets = int(m.group(1))
        bankroll = tickets * _number(m.group(2))
    else:
        m = re.search(r"(?:have|with|start(?:ing)? with|bankroll(?: of)?)\s*\$\s*(\d[\d,]*(?:\.\d+)?k?)", q)
        if m:
            bankroll = _number(m.group(1))
    m = re.search(r"(\d+)\s*(?:best\s*)?parlays?", q)
    if m and tickets is None:
        tickets = int(m.group(1))
    if bankroll is None:
        return None
    after = re.search(r"(?:make|win|reach|into|to|get|hit|\bfor)\s*(?:at least\s*)?\$\s*(\d[\d,]*(?:\.\d+)?k?)", q[(m.end() if m else 0):]) or \
        re.search(r"(?:make|win|reach|into|get|hit)\s*(?:at least\s*)?\$\s*(\d[\d,]*(?:\.\d+)?k?)", q)
    target = _number(after.group(1)) if after else max(v for _, v in money)
    if target <= bankroll:
        bigger = [v for _, v in money if v > bankroll]
        if not bigger:
            return None
        target = max(bigger)
    args = {"bankroll": bankroll, "target": target}
    if tickets:
        args["tickets"] = tickets
    return Plan([("goal", args)], "a goal question")


def _state(q: str):
    for code, name in catalog.STATE_NAMES.items():
        if re.search(r"\b" + re.escape(name.lower()) + r"\b", q):
            return code
    m = re.search(r"\b(?:in|for)\s+([a-z]{2})\b", q)
    if m and m.group(1).upper() in catalog.STATE_NAMES:
        return m.group(1).upper()
    return None


def parse(question: str, *, live: bool = False, state: str | None = None) -> Plan | None:
    """The tool calls a recognised question needs, or None."""
    q = _clean(question or "")
    if not q:
        return None
    if re.search(r"kalshi|polymarket", q):
        return Plan([("live_prices", {})], "a question about Kalshi and Polymarket US")
    got = _players(q)
    if got:
        return got
    got = _goal(q)
    if got:
        return got
    if re.search(r"best bets?|what should i bet|top plays?|plays? (for )?(today|tonight)|best \+?ev|picks", q):
        # What the board has: arbs and +EV bets. "+EV" asks for the +EV bets only.
        kinds = ["ev"] if re.search(r"\+ ?ev|positive ev", q) else ["ev", "arb"]
        return Plan([("board", {"kinds": kinds})], "a request for the best bets")
    if re.search(r"\barbs?\b|arbitrage|guaranteed", q):
        return Plan([("board", {"kinds": ["arb"]})], "a question about arbs")
    if re.search(r"\+ ?ev\b|positive ev|expected value bets|value bets?", q):
        return Plan([("board", {"kinds": ["ev"]})], "a question about +EV bets")
    if re.search(r"\bmiddles?\b", q):
        return Plan([("board", {"kinds": ["middle"]})], "a question about middles")
    prices = _prices(q)
    if re.search(r"fair (odds|price|value|chance)|devig|de-vig|no.?vig|true (odds|probability)|what('s| is) the (real|true)", q) and len(prices) >= 2:
        return Plan([("devig", {"odds": prices})], "a fair-odds question")
    if "parlay" in q and len(prices) >= 2:
        return Plan([("parlay", {"odds": prices, "same_game": bool(re.search(r"same.game|sgp", q))})], "a parlay question")
    if re.search(r"kelly|how much (should|do|to) i? ?(bet|stake|wager)|bet size|stake size", q) and prices:
        pct = re.search(r"(\d{1,2}(?:\.\d+)?)\s*%", q)
        bank = _MONEY.search(q)
        if pct:
            args = {"odds": prices[0], "prob": float(pct.group(1)) / 100.0}
            if bank:
                args["bankroll"] = _number(bank.group(1))
            return Plan([("kelly", args)], "a bet-size question")
    if re.search(r"welcome|sign.?up|promos?|bonus(es)?|offers?", q):
        st = _state(q) or state
        return Plan([("welcome", {"state": st} if st else {})], "a question about sign-up offers")
    if re.search(r"how am i doing|my record|my results|my roi|my profit|my bets|my performance|am i (winning|up|down)", q):
        return Plan([("performance", {})], "a question about the person's own record")
    return None
