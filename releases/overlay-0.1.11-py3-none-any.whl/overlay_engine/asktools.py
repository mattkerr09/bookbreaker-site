"""The tools Ask answers with: every number in an answer comes out of one of these.

A model (Claude, a local model, or the built-in parser) never produces a statistic of
its own. It picks a tool, the tool runs the same engine the calculators run, and what
comes back is the only source of numbers. Nine tools:

  players   NFL player projections and the chance of clearing a line      (playerproj.py)
  goal      "I have $X, the best parlays to turn it into $Y"                (goal.py)
  board     arbs, +EV bets and middles in the last read of live odds        (board.py)
  live_prices   Kalshi / Polymarket US pairs (only when Live prices is on)  (xvenue.py)
  devig     the fair odds of a market                                       (devig.py)
  parlay    what a parlay pays against what it should                       (parlay.py)
  kelly     how much to bet                                                 (kelly.py)
  welcome   sign-up offers for a state                                      (welcome.py)
  performance   the person's own record                                     (performance.py)

**No tool spends anything or places anything.** `board`
and `goal` read the odds already recorded on this Mac by the person's last press of
Live sportsbook odds; they never fetch, so a question cannot spend Odds API credits.
`live_prices` reads the public Kalshi and Polymarket US prices and exists only when the
person turned Live prices on. `players` reads files already downloaded and never starts
a download.

Each tool takes a fixed set of arguments and refuses any other, and a refusal goes back
to the model as an error it can correct. A handler returns plain JSON.
"""

from __future__ import annotations

import contextlib
import io
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace

from . import oddshistory
from . import goal as goal_mod
from . import nflverse, oddshistory, playerproj

#: Odds older than this are called stale when a board is read for a question.
BOARD_FRESH = 6 * 3600
#: The oldest read `goal` will build legs from before it says there is nothing recent.
GOAL_MAX_AGE = 12 * 3600


class ToolError(Exception):
    """A tool could not answer; the message is for the model and the person."""


@dataclass
class Context:
    """Where a question's tools look, and what the person has switched on."""

    state: str | None = None          # two letters, from the window's Promos choice
    live: bool = False                # the Live prices switch
    history: Path | None = None       # recorded odds
    nfl: Path | None = None           # downloaded nflverse files
    db: str | None = None             # the person's ledger
    now: float | None = None
    fetcher: object = None            # seam for live_prices
    cli: object = None                # seam: argv -> JSON, for the calculators
    notes: list = field(default_factory=list)

    def clock(self) -> float:
        return time.time() if self.now is None else self.now


_S = {"type": "string"}
_N = {"type": "number"}
_I = {"type": "integer"}


def _schema(properties: dict, required: list | None = None) -> dict:
    return {"type": "object", "properties": properties, "required": required or [], "additionalProperties": False}


def tool_defs(live: bool = False) -> list:
    """The tools as the model sees them. `live_prices` is offered only when Live prices is on."""
    defs = [
        {"name": "players",
         "description": ("NFL players ranked by the chance they clear a line this week (or by projection, with no line), from "
                         "their own game logs, their team's expected score and the opponent. Use for 'who is most likely to pass for 300 "
                         "yards', 'who will catch 6 passes', 'rushing leaders this week'. Each row has the projection, the chance, the "
                         "opponent, the game's spread and total, and the size of the sample behind the miss distribution. A line of 300 "
                         "means 300 or more. A projection is not an edge. If the data has not been downloaded it says so; tell the person "
                         "to press Download NFL data in Ask (or run players --update)."),
         "input_schema": _schema({
             "stat": dict(_S, enum=list(playerproj.STATS), description="the stat"),
             "line": dict(_N, description="the line, e.g. 299.5 or 300 (300 means 300 or more); omit to rank by projection"),
             "week": dict(_S, description="this, next, or a week number; default this"),
             "team": dict(_S, description="a team code like KC to show only that team"),
             "player": dict(_S, description="part of a player's name"),
             "limit": dict(_I, description="how many rows, default 10")}, ["stat"])},
        {"name": "goal",
         "description": ("Goal and bankroll questions: 'if I have ten $1 bets, what are the best ten parlays to make $200?', 'turn $100 into "
                         "$1,000'. Builds the tickets, gives each one's price, payout and chance, the chance at least one hits, the expected "
                         "return, and compares one big parlay, many smaller ones, a round robin and bold play. `target` is the amount to end "
                         "with, stake included. Legs come from the last read of live sportsbook odds when there is a recent one, else from "
                         "typical -110 bets with no edge, and the result says which."),
         "input_schema": _schema({
             "bankroll": dict(_N, description="the money to start with, e.g. 10"),
             "target": dict(_N, description="the amount to end with, e.g. 200"),
             "tickets": dict(_I, description="how many equal parlays to split the bankroll into, e.g. 10"),
             "legs": dict(_S, enum=["auto", "board", "assumed"], description="auto (default), board, or assumed")},
             ["bankroll", "target"])},
        {"name": "board",
         "description": ("Arbitrage, +EV bets and middles in the LAST read of live sportsbook odds (it never fetches or spends credits). "
                         "Each row has the books, prices and stakes. An arb is locked only if every bet is accepted and stands. A +EV return is an "
                         "average that can lose every time. Says how old the read is and how to refresh it."),
         "input_schema": _schema({
             "kinds": {"type": "array", "items": {"type": "string", "enum": ["arb", "ev", "middle"]}, "description": "which kinds; default all"},
             "bankroll": dict(_N, description="total to bet, default 1000"),
             "limit": dict(_I, description="how many rows, default 10")})},
        {"name": "devig",
         "description": "The fair odds of a market: take the margin out of every side's price. Give each side's price, American (-150) or decimal (1.67).",
         "input_schema": _schema({"odds": {"type": "array", "items": {"type": ["string", "number"]}, "minItems": 2,
                                           "description": "each side's price"}}, ["odds"])},
        {"name": "parlay",
         "description": "What a parlay pays against what it should, and the margin it costs. Give each leg's price.",
         "input_schema": _schema({"odds": {"type": "array", "items": {"type": ["string", "number"]}, "minItems": 2},
                                  "same_game": {"type": "boolean", "description": "all legs from one game"}}, ["odds"])},
        {"name": "kelly",
         "description": "How much to bet: the stake for a price, the person's own win chance and bankroll.",
         "input_schema": _schema({"odds": dict(_S, description="the price, American or decimal"),
                                  "prob": dict(_N, description="the person's win chance as a fraction, 0.45 for 45%"),
                                  "bankroll": dict(_N, description="bankroll, default 1000")}, ["odds", "prob"])},
        {"name": "welcome",
         "description": "Sportsbook sign-up offers, ranked by what they convert to, for a state (two letters).",
         "input_schema": _schema({"state": dict(_S, description="two-letter state code; default the person's state")})},
        {"name": "performance",
         "description": "The person's own record from their ledger: profit, return, win rate, by book and by sport. Only the person's own bets.",
         "input_schema": _schema({"book": _S, "sport": _S})},
    ]
    if live:
        defs.append({
            "name": "live_prices",
            "description": ("Pairs on the same game at Kalshi and Polymarket US that pay after both venues' fees, at the size on offer. Reads "
                            "the venues' public prices now. Locked only if both bets are accepted and stand."),
            "input_schema": _schema({"bankroll": dict(_N, description="most to bet, default 1000")})})
    return defs


# ------------------------------------------------------------ handlers

def _cli(ctx: Context, argv: list) -> dict:
    if ctx.cli is not None:
        return ctx.cli(argv)
    from . import cli
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        cli.main(list(argv) + ["--json"])
    text = out.getvalue().strip()
    try:
        data = json.loads(text)
    except ValueError:
        raise ToolError((err.getvalue() or text or "that did not run").strip()[:300]) from None
    if isinstance(data, dict) and data.get("error"):
        raise ToolError(str(data["error"]))
    return data


def _folder_history(ctx: Context) -> Path:
    return ctx.history or oddshistory.history_folder()


def t_players(ctx, stat, line=None, week="this", team=None, player=None, limit=10):
    folder = ctx.nfl or nflverse.cache_dir()
    if not nflverse.have_data(folder):
        return {"needs_download": True, "downloaded": False,
                "message": ("NFL player data has not been downloaded yet, so there are no projections to rank. Press Download NFL data in Ask, "
                            f"or run players --update. It downloads about {nflverse.ESTIMATE_MB} MB of public nflverse files from GitHub; "
                            "nothing is downloaded until you do."),
                "sources": {"player_stats": nflverse.PLAYER_URL, "games": nflverse.GAMES_URL}}
    try:
        got = playerproj.answer(stat, None if line is None else float(line), week, team=team, player=player,
                                limit=int(limit or 10), folder=folder)
    except playerproj.ProjectionError as exc:
        raise ToolError(str(exc)) from None
    out = got.as_dict()
    out["data"] = nflverse.describe(folder)
    return out


def t_goal(ctx, bankroll, target, tickets=None, legs="auto"):
    now = ctx.clock()
    pool, details, why = None, None, ""
    if legs in ("auto", "board"):
        snaps = oddshistory.latest(_folder_history(ctx), now=now, max_age=GOAL_MAX_AGE)
        if snaps:
            pool, details = goal_mod.board_pool(snaps)
            if len(pool) < 4:
                pool, why = None, "The last read of live odds had too few priced games to build parlays from, so "
        elif legs == "board":
            raise ToolError("There is no recent read of live sportsbook odds to build parlays from. Press Live sportsbook odds on the "
                            "Arbitrage page (it needs an Odds API key), then ask again.")
        else:
            why = "There is no recent read of live sportsbook odds (it needs an Odds API key), so "
    try:
        if pool:
            age = now - details["read_at"]
            text = (f"{details['games']} games from the live sportsbook odds read {int(age // 60)} minutes ago: each leg's fair chance is the "
                    "no-vig price of the books that price it, and its price is the best at a US sportsbook you can bet at")
            out = goal_mod.plan(float(bankroll), float(target), tickets, pool, legs_from=text, pool_details=details)
        else:
            out = goal_mod.plan(float(bankroll), float(target), tickets)
            out["legs_from"] = (why + "every leg is " + out["legs_from"]) if why else out["legs_from"]
    except goal_mod.GoalError as exc:
        raise ToolError(str(exc)) from None
    return out


def t_board(ctx, kinds=None, bankroll=1000, limit=10):
    from . import FillModel, LatencyModel, oddsapi
    from . import board as board_mod
    now = ctx.clock()
    snaps = oddshistory.latest(_folder_history(ctx))
    if not snaps:
        return {"has_odds": False, "rows": [],
                "message": ("No live sportsbook odds have been read yet, so there is no board to look at. Add an Odds API key on the Odds source "
                            "page and press Live sportsbook odds on the Arbitrage page; Ask never spends your credits by itself.")}
    kinds = tuple(kinds) if kinds else board_mod.KINDS
    books = oddsapi.books_table()
    markets, info = [], {}
    for s in snaps:
        markets += oddshistory.to_markets(s)
        info.update({k: dict(v, league=s["alias"].upper()) for k, v in s["events"].items()})
    read_at = max(s["fetched_at"] for s in snaps)
    common = dict(bankroll=float(bankroll), now=read_at, fill_model=FillModel(), latency_model=LatencyModel(),
                  bettable=set(oddsapi.BETTABLE))
    rows = []
    paired = tuple(k for k in kinds if k in ("arb", "ev"))
    if paired:
        rows += board_mod.scan(oddsapi.split_by_line(markets), books, kinds=paired, **common)
    if "middle" in kinds:
        rows += board_mod.scan(markets, books, kinds=("middle",), **common)
    rows = board_mod._rank(rows)
    fake = SimpleNamespace(event_info={k: {"label": v.get("label", k), "league": v.get("league", ""), "starts": v.get("starts")}
                                       for k, v in info.items()},
                           book_names=dict(oddsapi.BETTABLE))
    shown = oddsapi.describe_rows(rows, fake)
    age = now - read_at
    return {"has_odds": True, "read_at": read_at, "age_seconds": round(age), "stale": age > BOARD_FRESH,
            "leagues": sorted({s["alias"] for s in snaps}), "total_rows": len(shown),
            "counts": {k: sum(1 for r in shown if r["kind"] == k) for k in board_mod.KINDS},
            "rows": shown[:int(limit or 10)],
            "note": ("These prices are as of the last read, " + (f"{age / 3600:.1f} hours ago. " if age > 3600 else f"{round(age / 60)} minutes ago. ")
                     + "Prices move; check each at the book. An arb is locked only if every bet is accepted at the price shown and stands. "
                     "To read fresh odds, press Live sportsbook odds on the Arbitrage page."),
            "sizing": "A +EV row's stake is 1% of the bankroll given; its profit is an expectation, not a lock."}


def t_live_prices(ctx, bankroll=1000):
    if not ctx.live:
        raise ToolError("Live prices is off. The person turns it on from Arbitrage; Ask does not read Kalshi or Polymarket US without it.")
    from . import pubfeed, xvenue
    got = xvenue.scan(ctx.fetcher or pubfeed.urllib_fetcher, bankroll=float(bankroll), min_margin=0.0, state=ctx.state)
    out = got.as_dict()
    out["source"] = got.source()
    out["state_used"] = ctx.state
    if ctx.state is None:
        out["state_note"] = "No state was given, so no pair is listed: whether a pair can be placed depends on where the person is."
    return out


def t_devig(ctx, odds):
    return _cli(ctx, ["devig", *[str(o) for o in odds]])


def t_parlay(ctx, odds, same_game=False):
    data = _cli(ctx, ["parlay", *[str(o) for o in odds], *(["--same-game"] if same_game else [])])
    # The figures under `per_100` are for a $100 bet; saying so in the result lets an answer say "on $100".
    data["example_stake"] = 100
    return data


def t_kelly(ctx, odds, prob, bankroll=1000):
    return _cli(ctx, ["kelly", "--odds", str(odds), "--prob", str(prob), "--bankroll", str(bankroll)])


def t_welcome(ctx, state=None):
    st = (state or ctx.state or "").upper()
    data = _cli(ctx, ["welcome", *(["--state", st] if st else [])])
    keep = ("book", "name", "headline", "expected", "conversion", "cost", "face", "ends", "read", "source", "stale")
    offers = []
    for o in data.get("offers", []):
        if o.get("ended") or o.get("ineligible"):
            continue
        row = {k: o.get(k) for k in keep if k in o}
        row["locked_if_every_bet_stands"] = o.get("guaranteed")
        offers.append(row)
    data["offers"] = offers[:8]
    data["state"] = st or None
    return data


def t_performance(ctx, book=None, sport=None):
    argv = ["performance"]
    if ctx.db:
        argv += ["--db", ctx.db]
    if book:
        argv += ["--book", book]
    if sport:
        argv += ["--sport", sport]
    data = _cli(ctx, argv)
    for k in ("ledger",):
        data.pop(k, None)
    return data


HANDLERS = {"players": t_players, "goal": t_goal, "board": t_board, "live_prices": t_live_prices,
            "devig": t_devig, "parlay": t_parlay, "kelly": t_kelly, "welcome": t_welcome, "performance": t_performance}


def run_tool(ctx: Context, name: str, args, handlers: dict | None = None) -> tuple:
    """(json text, is_error). A bad call goes back to the model as an error it can fix."""
    fn = (handlers or HANDLERS).get(name)
    if fn is None:
        return f"no tool named {name}", True
    if not isinstance(args, dict):
        return "tool input must be an object", True
    schema = next((t["input_schema"] for t in tool_defs(True) if t["name"] == name), None)
    allowed = (schema or {}).get("properties", {})
    extra = sorted(set(args) - set(allowed))
    if extra:
        return f"unknown argument(s) {', '.join(extra)}; this tool takes {', '.join(allowed) or 'none'}", True
    missing = [r for r in (schema or {}).get("required", []) if r not in args]
    if missing:
        return f"missing {', '.join(missing)}", True
    try:
        result = fn(ctx, **args)
    except ToolError as exc:
        return str(exc), True
    except (TypeError, ValueError, KeyError) as exc:
        return f"{type(exc).__name__}: {exc}", True
    text = json.dumps(result, default=str)
    if len(text) > 60_000:
        text = text[:60_000] + ' ..."(truncated: ask a narrower question)"'
    return text, False
