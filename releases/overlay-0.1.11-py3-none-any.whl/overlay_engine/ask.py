"""Ask: a question in plain English, answered from the app's own tools.

    overlay ask "who is most likely to pass for 300 yards this week"
    overlay ask "if I have 10 $1 bets, what are the best 10 parlays to make $200"
    overlay ask --engine builtin "best bets"

Three ways to answer, in this order, and the answer says which one it used:

  1. **Claude, through the person's own Anthropic API key**, kept in the Mac's Keychain
     exactly like the Odds API key (`keystore.py`, service `bookbreaker.anthropic`). Claude
     picks the tools, reads what they return and writes the answer. `claude-opus-5-5` with
     adaptive thinking is the default; `claude-sonnet-5-5` is the cheaper choice. The cost of
     each answer is worked out from the response's own token counts and shown.
  2. **A local model through Ollama** on 127.0.0.1:11434, if one is running with tool support.
     Nothing leaves the Mac. Nothing is installed or downloaded.
  3. **The built-in parser** (`askparse.py`): the common question shapes, recognised with plain
     patterns and sent to the right tool. It needs no AI and no network, and answers the two
     questions most people open Ask with.

**Every number comes from a tool** (`asktools.py`). The model is told so, and then checked:
`askground.py` reads the answer for figures and looks for each in what the tools returned. A
figure found nowhere is named in the answer as unchecked; a local model's answer containing one
is replaced by the lookup's own words.

**What leaves this Mac.** Only when Claude answers: the question, the conversation so far and the
tools' results go to api.anthropic.com over https, with the person's own key, and nowhere else. The
client is pinned to that address, so a stray `ANTHROPIC_BASE_URL` cannot send the key elsewhere, and the
key is read from the Keychain for the call and never printed, logged or returned. With Ollama or the
built-in parser nothing leaves. The result says which, in `left_this_mac`.

**Nothing spends or places anything.** The tools read what is already on this Mac; none fetches odds,
none places a bet. Only Claude's own answer costs money, and that is the person's key and the person's
question.

The `anthropic` package is an optional extra (`overlay[ask]`): the engine's wheel has no required
dependency, and Ask says plainly when the package is missing.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import date

from . import askground, askparse, asktables, asktools, localai, keystore

#: The Claude models Ask offers. Opus is the default; Sonnet is the cheaper one.
MODELS = {"opus": "claude-opus-5-5", "sonnet": "claude-sonnet-5-5"}
DEFAULT_MODEL = "opus"
EFFORT = "high"
MAX_ROUNDS = 10
MAX_TOKENS = 16000
API_HOST = "https://api.anthropic.com"
FALLBACK_BETA = "server-side-fallback-2026-07-01"

#: Dollars per million tokens, from the Claude API's published prices (the claude-api skill's table, read 2026-09-25).
PRICES = {
    "claude-opus-5-5": {"input": 4.00, "output": 20.00, "cache_read": 0.20, "cache_write": 5.00},
    "claude-sonnet-5-5": {"input": 2.00, "output": 10.00, "cache_read": 0.20, "cache_write": 2.50},
}
PRICES_READ = "2026-09-25"

RG = "21+. Gambling problem? Call 1-800-GAMBLER."
NO_SDK = ("Ask found your Anthropic key, but this copy of Bookbreaker was built without the Anthropic software it needs "
          "(the optional ask extra). Update Bookbreaker, or install it with pip install 'overlay[ask]'. Answering without it.")

_PICKS = ("players", "goal", "board", "live_prices")


class AskError(Exception):
    """Claude could not answer. The message is a sentence for the person and never holds the key."""


# ------------------------------------------------------------ the prompt

def system_prompt(today: str | None = None, compact: bool = False) -> str:
    """The rules Ask answers by. `compact` is accepted for the small local model; the prompt is already short."""
    today = today or date.today().isoformat()
    return f"""You are Bookbreaker's analyst: a sharp, plain-spoken sports-betting analyst inside a free Mac app for US bettors. \
You answer by calling the app's tools, then saying what the results mean for a bet. You never place bets and you never ask anyone for \
a sportsbook login.

Rules that are never bent:
1. Every statistic, chance, price, line, count, percentage and dollar figure you state comes from a tool result in this conversation, \
or from the person's own words. If no tool measured it, say it is not measured. Do not fill gaps from memory: rosters, injuries, weather \
and lines change by the hour. Do no arithmetic of your own; the tools return figures already worked out. Quote them as returned, or \
rounded to a whole number or a whole percent.
2. Give the sample behind a number: how many games, bets or seasons, and what it is measured against. A small sample is a hint, not a finding.
3. A projection is not an edge. A fair price is not an edge. A hit rate is not an edge. Say which kind of number you are giving.
4. You recommend bets from live arbs and +EV prices only: what the board tool returns from the person's own read of live sportsbook odds. \
Say so plainly when asked what you rely on. Everything else is a projection, a fair price or an arbitrage, and you say which.
5. An arbitrage is locked only if every bet is accepted at the price shown and stands. A +EV return is an average over many bets and can \
lose every time. A middle pays only if the result lands in its window.
6. Words you never use: guaranteed, risk-free, lock (as a promise), either way, sure thing, free money, cannot lose.
7. When you give picks, best bets or parlays, end with: {RG}
8. Account advice is about bet shape only (stake sizes, timing, mixing markets). Never help with identity, KYC, device, location or \
multi-accounting workarounds.
9. If the person mentions chasing losses, money they cannot afford to lose, or trouble stopping, do not plan bets: say so kindly and give \
1-800-GAMBLER.
10. The tools never fetch odds or spend credits. `board` and `goal` use the last read of live sportsbook odds on this Mac, and say \
how old it is. If a tool says data has not been read or downloaded, tell the person exactly what to press (Live sportsbook odds on the \
Arbitrage page, or Download NFL data in Ask); do not work around it.

How to answer: lead with the answer, short. The window shows each tool's table beside your words, so do not repeat every row.
- "Best bets", "what should I bet": call board (arbs and +EV bets) and lead with the best. Say plainly when the board has nothing.
- "Who is most likely to ...", "who will pass for 300 yards": call players. Say it is a projection from game logs, give the opponent and the \
spread and total, the sample behind the miss distribution, and that who plays is not in the files (check inactives).
- Goals ("turn $10 into $200", "the best ten parlays for $200"): call goal. Lead with the ceiling for a bettor with no edge, then the plan \
that reaches the target most often and its chance, then the chance of getting nothing back. Say that splitting into smaller parlays that each \
need the target lowers the chance because every leg pays the book's margin again, and that a round robin buys a smaller win more often, not \
the target. Say whether the legs came from live odds or from typical -110 bets with no edge.
- Prices, fair odds, parlays, bet size, sign-up offers, the person's own record: devig, parlay, kelly, welcome, performance.

Today is {today}."""


# ------------------------------------------------------------ the answer

@dataclass
class Turn:
    text: str
    calls: list = field(default_factory=list)       # {"name","args","result","error"}
    usage: dict = field(default_factory=dict)
    model: str = ""
    stop: str = "end_turn"
    fallback: bool = False


def cost(usage: dict, model: str) -> float | None:
    p = PRICES.get(model)
    if not p or not usage:
        return None
    return (usage.get("input", 0) * p["input"] + usage.get("output", 0) * p["output"]
            + usage.get("cache_read", 0) * p["cache_read"] + usage.get("cache_write", 0) * p["cache_write"]) / 1e6


def sdk_present() -> bool:
    try:
        import anthropic  # noqa: F401
    except ImportError:
        return False
    return True


def make_client(key: str, http_client=None):
    """The SDK's client, pinned to Anthropic's own address with the person's own key.

    Pinned because the SDK would otherwise honour ANTHROPIC_BASE_URL from the environment, and the
    key would go wherever that names. It is also given the key explicitly, so it never goes looking
    in the environment or in another login for a credential. `http_client` is a seam for tests, which
    hand in a transport that records the request instead of sending it."""
    import anthropic
    extra = {} if http_client is None else {"http_client": http_client}
    return anthropic.Anthropic(api_key=key, base_url=API_HOST, max_retries=2, timeout=180.0, **extra)


def _plain(exc) -> str:
    """A failed Claude call as one sentence. Never the exception's own text: it can name the request."""
    try:
        import anthropic
    except ImportError:
        return f"Claude could not answer ({type(exc).__name__})."
    if isinstance(exc, anthropic.AuthenticationError):
        return "Anthropic did not accept your API key. Check it in Ask's settings and save it again."
    if isinstance(exc, anthropic.PermissionDeniedError):
        return "Your Anthropic key is not allowed to use that model. Check your plan at console.anthropic.com."
    if isinstance(exc, anthropic.RateLimitError):
        return "Anthropic asked Bookbreaker to slow down (a rate limit). Wait a minute and ask again."
    if isinstance(exc, anthropic.BadRequestError):
        return ("Anthropic refused the request. If the message mentions credit, add credit at console.anthropic.com; "
                f"otherwise check for a newer Bookbreaker (status {getattr(exc, 'status_code', 400)}).")
    if isinstance(exc, anthropic.APIConnectionError):
        return "Bookbreaker could not reach Anthropic. Check your internet connection."
    status = getattr(exc, "status_code", None)
    if status and status >= 500:
        return "Anthropic had a problem on its side. Try again in a minute."
    return f"Claude could not answer ({type(exc).__name__})."


def _echo(content) -> list:
    """The assistant's blocks to send back. After a fallback, blocks before the last `fallback` marker that
    the new model cannot continue from (thinking and tool_use) are left out, as the API's rules for echoing say."""
    blocks = list(content)
    last = max((i for i, b in enumerate(blocks) if getattr(b, "type", "") == "fallback"), default=None)
    if last is None:
        return blocks
    return [b for i, b in enumerate(blocks)
            if not (i < last and getattr(b, "type", "") in ("thinking", "redacted_thinking", "tool_use"))]


def claude_turn(question: str, history: list, client, model_key: str, ctx: asktools.Context, today: str | None = None,
                handlers: dict | None = None) -> Turn:
    """One question, run to a final answer by Claude calling the tools."""
    model = MODELS.get(model_key, MODELS[DEFAULT_MODEL])
    system = system_prompt(today)
    tools = asktools.tool_defs(ctx.live)
    messages = []
    for turn in history[-6:]:
        messages += [{"role": "user", "content": turn["q"]}, {"role": "assistant", "content": turn["a"]}]
    messages.append({"role": "user", "content": question})
    usage = {"input": 0, "output": 0, "cache_read": 0, "cache_write": 0}
    calls, fell_back = [], False
    resp = None
    for _ in range(MAX_ROUNDS):
        try:
            resp = client.beta.messages.create(
                model=model, max_tokens=MAX_TOKENS, system=system, tools=tools, messages=messages,
                thinking={"type": "adaptive"}, output_config={"effort": EFFORT},
                cache_control={"type": "ephemeral"},
                betas=[FALLBACK_BETA], extra_body={"fallbacks": "default"})
        except Exception as exc:                      # noqa: BLE001 - mapped to a sentence, never the exception's text
            raise AskError(_plain(exc)) from None
        u = resp.usage
        usage["input"] += getattr(u, "input_tokens", 0) or 0
        usage["output"] += getattr(u, "output_tokens", 0) or 0
        usage["cache_read"] += getattr(u, "cache_read_input_tokens", 0) or 0
        usage["cache_write"] += getattr(u, "cache_creation_input_tokens", 0) or 0
        if any(getattr(b, "type", "") == "fallback" for b in resp.content):
            fell_back = True
        messages.append({"role": "assistant", "content": _echo(resp.content)})
        if resp.stop_reason == "pause_turn":
            continue
        if resp.stop_reason != "tool_use":
            break
        results = []
        for b in resp.content:
            if getattr(b, "type", "") != "tool_use":
                continue
            text, err = asktools.run_tool(ctx, b.name, b.input, handlers)
            calls.append({"name": b.name, "args": dict(b.input) if isinstance(b.input, dict) else {}, "result": text, "error": err})
            row = {"type": "tool_result", "tool_use_id": b.id, "content": text}
            if err:
                row["is_error"] = True
            results.append(row)
        if not results:
            break                       # a stop for tool use with no tool call in it: nothing to answer, so the text so far stands
        messages.append({"role": "user", "content": results})
    else:
        return Turn("Claude made ten lookups without reaching an answer. Ask a narrower question.", calls, usage, model, "max_rounds", fell_back)
    text = "\n".join(b.text for b in resp.content if getattr(b, "type", "") == "text").strip()
    stop = resp.stop_reason
    if stop == "refusal":
        text = text or "Claude declined to answer that one."
    elif stop == "max_tokens":
        text += "\n\n(The answer was cut off at its length limit.)"
    return Turn(text or "(no answer)", calls, usage, model, stop, fell_back)


# ------------------------------------------------------------ putting an answer together

def _tables_for(calls: list) -> list:
    out = []
    for c in calls:
        if c["error"]:
            continue
        try:
            result = json.loads(c["result"])
        except ValueError:
            continue
        out += asktables.tables(c["name"], c["args"], result)
    return out


def _builtin(question: str, ctx: asktools.Context, history: list, handlers=None) -> tuple:
    """(text, calls) from the parser, or (help, [])."""
    plan = askparse.parse(question, live=ctx.live, state=ctx.state)
    if plan is None:
        return askparse.HELP, []
    calls, parts = [], []
    for name, args in plan.calls:
        text, err = asktools.run_tool(ctx, name, args, handlers)
        calls.append({"name": name, "args": args, "result": text, "error": err})
        if err:
            parts.append(text)
            continue
        parts.append(asktables.sentence(name, args, json.loads(text)))
    text = " ".join(p for p in parts if p).strip()
    if any(c["name"] in _PICKS and not c["error"] for c in calls):
        text += f" {RG}"
    return text, calls


def _sources(question: str, history: list, calls: list) -> list:
    return [question] + [h["q"] + " " + h["a"] for h in history] + [c["result"] for c in calls if not c["error"]]


def ask(question: str, history: list | None = None, *, engine: str = "auto", model: str = DEFAULT_MODEL,
        ctx: asktools.Context | None = None, key_getter=None, client_factory=None, http=None, today: str | None = None,
        handlers: dict | None = None) -> dict:
    """Answer one question. `engine`: auto, claude, ollama or builtin."""
    question = (question or "").strip()
    if not question:
        raise AskError("Type a question first.")
    history = [h for h in (history or []) if isinstance(h, dict) and "q" in h and "a" in h][-6:]
    ctx = ctx or asktools.Context()
    key_getter = key_getter or (lambda: keystore.get_key(name="anthropic"))
    client_factory = client_factory or make_client
    notes, turn, mode, used_model = [], None, "builtin", ""

    # 1. Claude, through the person's own key
    if engine in ("auto", "claude"):
        try:
            key = key_getter()
        except keystore.KeyStoreError as exc:
            key = None
            notes.append(f"Ask could not read the Keychain, so it did not use Claude: {exc}")
        if key:
            if not sdk_present() and client_factory is make_client:
                if engine == "claude":
                    raise AskError(NO_SDK)
                notes.append(NO_SDK)
            else:
                try:
                    turn = claude_turn(question, history, client_factory(key), model, ctx, today, handlers)
                    mode, used_model = "claude", turn.model
                except AskError as exc:
                    notes.append(f"{exc} Answering without Claude.")
                finally:
                    key = None
        elif engine == "claude":
            raise AskError("No Anthropic API key is set. Add yours in Ask's settings (it is kept in your Mac's Keychain).")

    # 2. A local model on this Mac
    if turn is None and engine in ("auto", "ollama"):
        found = localai.status(http)
        if found["running"] and found["tool_models"]:
            name = found["tool_models"][0]
            try:
                got = localai.converse(question, history, name, system_prompt(today, compact=True), asktools.tool_defs(ctx.live),
                                       lambda n, a: asktools.run_tool(ctx, n, a, handlers), http)
            except Exception:                         # noqa: BLE001
                notes.append("The local model did not answer. Answering without it.")
            else:
                turn = Turn(got["text"], got["calls"], {}, name, got["stop"])
                mode, used_model = "ollama", name
        elif engine == "ollama":
            raise AskError("Ollama is not running on this Mac with a model that can use tools. Nothing is installed or "
                           "downloaded for you.")

    # 3. The built-in parser
    if turn is None:
        text, calls = _builtin(question, ctx, history, handlers)
        turn = Turn(text, calls)

    flagged = []
    if mode == "ollama":
        # A small model that answered without looking anything up answered from memory, which is what
        # Ask exists not to do; one that states a figure no lookup returned has made it up.
        flagged = askground.ungrounded(turn.text, _sources(question, history, turn.calls)) if turn.calls else []
        if not turn.calls or flagged:
            text, calls = _builtin(question, ctx, history, handlers)
            notes.append("The local model answered without looking anything up, so its answer is not shown." if not turn.calls else
                         "The local model's answer stated figures no lookup returned (" + ", ".join(flagged[:4]) + "), so it is not shown.")
            turn, mode, used_model, flagged = Turn(text, calls), "builtin", "", []
            notes.append("Answered by recognising the shape of the question instead.")
    elif mode == "claude":
        flagged = askground.ungrounded(turn.text, _sources(question, history, turn.calls))
        if flagged:
            turn.text += f"\n\n(Not from any lookup, so unchecked: {', '.join(flagged)}.)"
            notes.append("Some figures in the answer are not in any lookup: " + ", ".join(flagged) + ".")
    if mode == "builtin" and not any("recognising" in n for n in notes):
        notes.append("Answered without an AI, by recognising the shape of the question. To ask anything else, add your own Anthropic key in "
                     "Ask's settings, or run a local model with Ollama.")

    spent = cost(turn.usage, turn.model) if mode == "claude" else None
    return {
        "command": "ask", "question": question, "answer": turn.text, "mode": mode, "model": used_model or None,
        "tools": [{"name": c["name"], "args": c["args"], "error": c["error"]} for c in turn.calls],
        "tables": _tables_for(turn.calls),
        "cost": None if spent is None else {
            "usd": round(spent, 4), "model": turn.model, "input_tokens": turn.usage["input"], "output_tokens": turn.usage["output"],
            "cached_tokens": turn.usage["cache_read"], "prices_read": PRICES_READ,
            "note": "Worked out from the response's own token counts at the published prices"
                    + ("; a fallback model answered part of it, so the bill may differ." if turn.fallback else ".")},
        "notes": notes, "ungrounded": flagged,
        "left_this_mac": {"anthropic": mode == "claude",
                          "what": ("Your question, this conversation and the tools' results went to Anthropic with your own key."
                                   if mode == "claude" else "Nothing left this Mac.")},
        "stop": turn.stop,
    }
