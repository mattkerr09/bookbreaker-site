"""The `players`, `goal` and `ask` commands.

They live here and not in cli.py so that the CLI file does not grow by another thousand lines;
`cli.main` calls `register()` to add their parsers. Each prints a table for a person and, with
`--json`, the same figures for the window: one call, two spellings.

    overlay players --update                                   download nflverse's public files (about 50 MB)
    overlay players --stat "passing yards" --line 299.5 --week this --json
    overlay players --calibration                              stated chance against how often it happened
    overlay goal --bankroll 10 --target 200 --tickets 10 --json
    overlay ask "who is most likely to pass for 300 yards this week"
"""

from __future__ import annotations

import json
import sys
import time

from . import ask as ask_mod
from . import asktools, goal as goal_mod, nflverse, oddshistory, playerproj


def _emit(payload: dict) -> int:
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def _view(name: str, payload: dict) -> dict:
    """The result with its table and sentence drawn by the engine (`asktables`), so the window shows a
    tool run directly exactly as it shows one run for a question: it draws, it does not compose."""
    from . import asktables
    return dict(payload, tables=asktables.tables(name, {}, payload), sentence=asktables.sentence(name, {}, payload))


def _table(columns: list, rows: list, indent: str = "  ") -> None:
    widths = [max(len(str(c)), *(len(str(r[i])) for r in rows)) if rows else len(str(c)) for i, c in enumerate(columns)]
    print(indent + "  ".join(str(c).ljust(w) for c, w in zip(columns, widths)).rstrip())
    for r in rows:
        print(indent + "  ".join(str(v).ljust(w) for v, w in zip(r, widths)).rstrip())


def _stamp(epoch) -> str:
    return "n/a" if not epoch else time.strftime("%Y-%m-%d %H:%M", time.localtime(epoch))


# ------------------------------------------------------------ players

def _data_lines(d: dict) -> None:
    if not d["downloaded"]:
        print(f"No NFL data is downloaded. `players --update` fetches about {d['estimate_megabytes']} MB of public files from GitHub.")
        return
    print(f"Data: nflverse public files, downloaded {_stamp(d['downloaded_at'])}:")
    for f in d["files"]:
        print(f"  {f['file']:<28} {f['bytes'] / 1e6:>5.1f} MB  file dated {f['file_date'] or 'n/a'}")
        print(f"  {'':<28} from {f['url']}")


def cmd_players(args) -> int:
    folder = nflverse.cache_dir()
    if args.update:
        report = nflverse.update()
        try:
            playerproj.calibration_table()
        except playerproj.ProjectionError:
            pass
        if not args.stat:
            if args.json:
                return _emit({"command": "players", "action": "update", **report.as_dict(), "data": nflverse.describe()})
            print(f"Downloaded {len(report.fetched)} file(s), {report.bytes / 1e6:.1f} MB; kept {len(report.kept)} earlier season(s) already here.")
            _data_lines(nflverse.describe())
            return 0
    if args.status:
        d = nflverse.describe(folder)
        if args.json:
            return _emit({"command": "players", "action": "status", "data": d})
        _data_lines(d)
        return 0
    if args.calibration:
        table = playerproj.stored_calibration(folder) or playerproj.calibration_table(folder)
        if args.stat:
            keep = playerproj.stat_for(args.stat).name
            table = dict(table, stats={keep: table["stats"][keep]})
        if args.json:
            return _emit({"command": "players", "action": "calibration", **table})
        print(table["note"])
        for name, cal in table["stats"].items():
            print(f"\n{name}: {cal['n']:,} stated chances, off by {cal['mean_gap']:.1%} on average (worst bucket {cal['worst_gap']:.1%})")
            _table(["stated", "n", "stated chance", "happened", "gap"],
                   [[b["bucket"], f"{b['n']:,}", f"{b['stated']:.1%}", f"{b['happened']:.1%}", f"{b['gap']:+.1%}"] for b in cal["buckets"]])
        return 0
    if not args.stat:
        print("Say which stat: --stat \"passing yards\" (or completions, pass attempts, passing TDs, interceptions, rushing yards, "
              "carries, receiving yards, receptions). Or --update, --status, --calibration.", file=sys.stderr)
        return 2
    got = playerproj.answer(args.stat, args.line, args.week, team=args.team, player=args.player, limit=args.limit, folder=folder)
    if args.json:
        return _emit(_view("players", {"command": "players", "data": nflverse.describe(folder), **got.as_dict()}))
    d = got.as_dict()
    print(f"{got.stat.name.capitalize()}, week {got.week} of {got.season}"
          + (f": chance of reaching {int(-(-playerproj.at_least(got.line) // 1))} {got.stat.unit} or more" if got.line is not None else ""))
    _data_lines(nflverse.describe(folder))
    print()
    cols = ["PLAYER", "TEAM", "OPP", "SPREAD", "TOTAL", "PROJ"] + (["CHANCE"] if got.line is not None else []) + ["GAMES"]
    rows = []
    for r in got.rows:
        row = [r["player"], r["team"], ("vs " if r["home"] else "@ ") + r["opponent"],
               "n/a" if r["spread"] is None else f"{r['spread']:+g}", "n/a" if r["total"] is None else f"{r['total']:g}",
               f"{r['projection']:.1f}"]
        if got.line is not None:
            row.append(f"{r['chance']:.0%}")
        row.append(str(r["games"]))
        rows.append(row)
    _table(cols, rows)
    s = got.sample
    print(f"\nThe chance is read from how {s['n']:,} earlier projections missed ({s['seasons']}, four bands by size), "
          "not from a normal curve.")
    if got.calibration:
        print(f"Checked on 2022 on: stated chances were off by {got.calibration['mean_gap']:.1%} on average "
              f"(`players --calibration` shows the table).")
    for n in got.notes:
        print(n)
    print(d["not_an_edge"])
    return 0


# ------------------------------------------------------------ goal

def _refresh_odds(args) -> None:
    """`goal --refresh`: read live sportsbook odds with the person's own key, the way `board --feed oddsapi`
    does, and record them, so the parlays are built from today's board. It says what it will cost BEFORE it
    fetches (on standard error, so the answer on standard output stays clean). Only this explicit flag does
    it: Ask and the window never spend credits."""
    from . import keystore, oddsapi
    est = oddsapi.estimate(args.sport or None, None, args.market or None)
    print(est.sentence(), file=sys.stderr, flush=True)
    key = keystore.get_key()
    if not key:
        raise oddsapi.OddsApiError(oddsapi.NO_KEY, "no_key")
    try:
        got = oddsapi.refresh(est, key)
    finally:
        key = None
    print(oddsapi.credits_line(got), file=sys.stderr, flush=True)


def cmd_goal(args) -> int:
    if args.refresh:
        _refresh_odds(args)
    snaps = []
    if args.legs in ("auto", "board"):
        snaps = oddshistory.latest(oddshistory.history_folder(), max_age=args.max_age_hours * 3600.0)
    pool, details = None, None
    if snaps:
        pool, details = goal_mod.board_pool(snaps, sports=args.sport or None)
        if len(pool) < 4:
            pool = None
    if args.legs == "board" and not pool:
        raise goal_mod.GoalError("There is no recent read of live sportsbook odds to build parlays from. Press Live sportsbook odds "
                                 "on the Arbitrage page (it needs an Odds API key).")
    if pool:
        age = time.time() - details["read_at"]
        text = (f"{details['games']} games from the live sportsbook odds read {int(age // 60)} minutes ago: each leg's fair chance is the "
                "no-vig price of the books that price it, and its price is the best at a US sportsbook you can bet at")
        out = goal_mod.plan(args.bankroll, args.target, args.tickets, pool, legs_from=text, pool_details=details)
    else:
        out = goal_mod.plan(args.bankroll, args.target, args.tickets, price=args.price)
        if args.legs == "auto":
            out["legs_from"] = ("There is no recent read of live sportsbook odds (it needs an Odds API key), so every leg is "
                                + out["legs_from"])
    if args.json:
        return _emit(_view("goal", out))
    print(f"${out['bankroll']:g} toward ${out['target']:g} ({out['needs']}).")
    print(f"Legs: {out['legs_from']}.\n")
    for note in out["notes"]:
        print(note)
    if out["parlays"]:
        print(f"The {len(out['parlays'])} parlays, ${out['stake_each']:g} each:")
        for t in out["parlays"]:
            print(f"  {t['n']:>2}. {len(t['legs'])} legs at {t['american']:+d} pays ${t['payout']:,.2f}, chance {t['chance']:.3%}")
            if args.verbose:
                for leg in t["legs"]:
                    print(f"        {leg['label']}  {leg['american']:+d}  {leg['chance']:.1%}")
        print(f"\nChance at least one hits: {out['chance_any_hits']:.2%}   ({out['chance_any_hits_formula']})")
        loss = out["expected_profit"]
        print(f"Expected return: ${out['expected_return']:,.2f} on ${out['bankroll']:g} "
              f"({'-' if loss < 0 else '+'}${abs(loss):,.2f})\n")
    print("Ways to stake it, best chance of reaching the target first:")
    _table(["PLAN", "REACHES", "SOMETHING BACK", "AVG RETURN", "HOW"],
           [[s["strategy"], f"{s['chance_to_reach']:.2%}", f"{s['chance_something_back']:.1%}", f"${s['expected_return']:,.2f}", s["method"]]
            for s in out["strategies"]])
    print(f"\n{out['read_this']}")
    return 0


# ------------------------------------------------------------ ask

def ask_status() -> dict:
    """What Ask can answer with right now: is the key set, is the package here, is a local model running."""
    from . import keystore, localai
    try:
        key = keystore.status(name="anthropic").as_dict()
    except keystore.KeyStoreError as exc:
        key = {"set": False, "last4": None, "error": str(exc)}
    sdk = ask_mod.sdk_present()
    local = localai.status()
    if key.get("set") and sdk:
        will = "Claude"
    elif local["running"] and local["tool_models"]:
        will = "a local model"
    else:
        will = "the built-in answerer"
    return {"command": "ask", "action": "status", "sdk": sdk, "key": key, "ollama": local,
            "models": {k: {"id": v, "input_per_million": ask_mod.PRICES[v]["input"], "output_per_million": ask_mod.PRICES[v]["output"]}
                       for k, v in ask_mod.MODELS.items()},
            "default_model": ask_mod.DEFAULT_MODEL, "prices_read": ask_mod.PRICES_READ, "answers_with": will,
            "players": nflverse.describe(),
            "sdk_note": None if sdk else ask_mod.NO_SDK}


def cmd_ask(args) -> int:
    if args.status:
        out = ask_status()
        if args.json:
            return _emit(out)
        print(f"Ask would answer with {out['answers_with']}.")
        print(f"Anthropic key: {'set (ends in ' + out['key']['last4'] + ')' if out['key'].get('set') else 'not set'}.  "
              f"Anthropic package: {'present' if out['sdk'] else 'missing'}.  "
              f"Ollama: {'running, tools: ' + ', '.join(out['ollama']['tool_models']) if out['ollama']['running'] else 'not running'}.")
        return 0
    history = []
    if args.stdin:
        raw = sys.stdin.read(60000) if sys.stdin is not None else ""
        try:
            data = json.loads(raw)
        except ValueError:
            raise ask_mod.AskError("Ask could not read the question it was handed.") from None
        question = str(data.get("question", ""))
        history = data.get("history") or []
    else:
        question = " ".join(args.question)
    ctx = asktools.Context(state=args.state, live=args.live)
    out = ask_mod.ask(question, history, engine=args.engine, model=args.model, ctx=ctx)
    if args.json:
        return _emit(out)
    print(out["answer"])
    for t in out["tables"]:
        print(f"\n{t['title']}")
        _table(t["columns"], t["rows"])
        if t["note"]:
            print(f"  {t['note']}")
    for n in out["notes"]:
        print(f"\n{n}")
    if out["cost"]:
        c = out["cost"]
        print(f"\n[{len(out['tools'])} lookups, {c['input_tokens'] + c['cached_tokens']:,} in / {c['output_tokens']:,} out tokens, "
              f"${c['usd']:.4f} on {c['model']}]")
    return 0


def register(sub, state_type) -> None:
    p = sub.add_parser("players", help="NFL player projections and the chance of clearing a line")
    p.add_argument("--stat", default=None, help="passing yards, completions, pass attempts, passing TDs, interceptions, rushing yards, "
                                                "carries, receiving yards or receptions")
    p.add_argument("--line", type=float, default=None, help="the line; 300 and 299.5 both mean 300 or more")
    p.add_argument("--week", default="this", help="this, next, or a week number")
    p.add_argument("--team", default=None)
    p.add_argument("--player", default=None)
    p.add_argument("--limit", type=int, default=15)
    p.add_argument("--update", action="store_true",
                   help="download nflverse's public files from GitHub (about 50 MB). Nothing downloads without this")
    p.add_argument("--status", action="store_true", help="what is downloaded, from where, and how old")
    p.add_argument("--calibration", action="store_true", help="stated chance against how often it happened, 2022 on")
    p.set_defaults(func=cmd_players)

    p = sub.add_parser("goal", help="the best parlays to turn a bankroll into a target")
    p.add_argument("--bankroll", type=float, required=True, help="the money to start with")
    p.add_argument("--target", type=float, required=True, help="the amount to end with, stake included")
    p.add_argument("--tickets", type=int, default=None, help="split the bankroll into this many equal parlays")
    p.add_argument("--legs", choices=("auto", "board", "assumed"), default="auto",
                   help="where the legs come from: the last read of live odds, or typical -110 bets with no edge")
    p.add_argument("--price", default="-110", help="with assumed legs, their price (the other side is the same)")
    p.add_argument("--sport", action="append", default=None, help="with board legs, only this league (nfl, nba, ...); repeatable")
    p.add_argument("--max-age-hours", type=float, default=12.0, help="the oldest read of live odds to build from")
    p.add_argument("--refresh", action="store_true",
                   help="first read live sportsbook odds with your own Odds API key (it says what that costs in credits "
                        "before it fetches), then build from them. Nothing else here spends credits")
    p.add_argument("--market", action="append", default=None, choices=("h2h", "spreads", "totals"),
                   help="with --refresh: a bet type to read; repeatable. Default: h2h")
    p.add_argument("--verbose", action="store_true", help="list every leg of every parlay")
    p.set_defaults(func=cmd_goal)

    p = sub.add_parser("ask", help="ask a question in plain English")
    p.add_argument("question", nargs="*", help="the question")
    p.add_argument("--stdin", action="store_true",
                   help="read {\"question\", \"history\"} as JSON from standard input, so the question is not on the command line")
    p.add_argument("--engine", choices=("auto", "claude", "ollama", "builtin"), default="auto")
    p.add_argument("--model", choices=tuple(ask_mod.MODELS), default=ask_mod.DEFAULT_MODEL, help="which Claude model")
    p.add_argument("--state", type=state_type, default=None, help="your state (two letters)")
    p.add_argument("--live", action="store_true", help="let Ask read Kalshi and Polymarket US prices (the Live prices switch)")
    p.add_argument("--status", action="store_true", help="what Ask can answer with right now; asks nothing")
    p.set_defaults(func=cmd_ask)
