"""Every number in an answer must come from a tool.

The rule Ask is built on is that a model is never a source of statistics. It is told so,
and then it is checked, because a model told not to invent a figure is not the same
as a model that cannot: an answer is read for numbers, and each one is looked for in what the
tools returned (and in the person's own question and the conversation so far). A number that is
nowhere in them is *ungrounded*, and the answer is flagged, or, for a small local model, replaced
by the lookup's own words.

What counts as a number to check: anything with a percent sign, a dollar sign or a decimal point,
and any whole number of 100 or more except a year. Small whole numbers ("three legs", "week 6",
"1.") are the language around a result, not statistics. A number is grounded if rounding any
number a tool returned to the answer's own precision gives it, as a plain number or as a
percentage (a tool's 0.3123 is a model's "31%"); numbers inside a tool's own sentences count too.

This does not check that a number is used correctly. It checks that it was not made up.
"""

from __future__ import annotations

import json
import re

_NUM = re.compile(r"(?<![\w.:])([+-]?)(\$?)(\d[\d,]*(?:\.\d+)?)(%?)(?![\w:])")
_ORDINAL = re.compile(r"\b\d+(st|nd|rd|th)\b")
#: The responsible-gambling number the answers end with is a constant of the app, not a statistic.
_HELPLINE = re.compile(r"1-800-GAMBLER", re.I)
_DP = (0, 1, 2, 3, 4)


def _walk(obj, out: list) -> None:
    if isinstance(obj, bool) or obj is None:
        return
    if isinstance(obj, (int, float)):
        out.append(float(obj))
    elif isinstance(obj, str):
        for m in _NUM.finditer(obj):
            try:
                out.append(float(m.group(3).replace(",", "")))
            except ValueError:
                pass
    elif isinstance(obj, dict):
        for k, v in obj.items():
            _walk(k, out)
            _walk(v, out)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            _walk(v, out)


def source_numbers(sources) -> list:
    """Every number in what the tools returned (JSON text or objects), the question and the conversation."""
    out: list = []
    for s in sources:
        if isinstance(s, str):
            try:
                _walk(json.loads(s), out)
                continue
            except ValueError:
                pass
        _walk(s, out)
    return out


class Index:
    """Numbers rounded every way an answer might quote them."""

    def __init__(self, numbers):
        self.plain = {dp: set() for dp in _DP}
        self.percent = {dp: set() for dp in _DP}
        for v in numbers:
            v = abs(v)
            for dp in _DP:
                self.plain[dp].add(round(v, dp))
                self.percent[dp].add(round(v * 100.0, dp))

    def has(self, value: float, dp: int, percent: bool) -> bool:
        v = round(abs(value), dp)
        if v in self.plain[dp]:
            return True
        return percent and v in self.percent[dp]


def ungrounded(text: str, sources) -> list:
    """The numbers in `text` that appear in none of `sources`, as written."""
    if not text:
        return []
    index = Index(source_numbers(sources))
    scrubbed = _HELPLINE.sub(" ", _ORDINAL.sub(" ", text))
    bad, seen = [], set()
    for m in _NUM.finditer(scrubbed):
        raw = m.group(3).replace(",", "")
        has_dp = "." in raw
        percent, dollar = m.group(4) == "%", m.group(2) == "$"
        value = float(raw)
        whole_year = not has_dp and not percent and not dollar and 1900 <= value <= 2100
        small = not has_dp and not percent and not dollar and value < 100
        if whole_year or small:
            continue
        dp = len(raw.split(".")[1]) if has_dp else 0
        if dp not in _DP:
            dp = 4
        if index.has(value, dp, percent):
            continue
        shown = f"{m.group(1)}{m.group(2)}{m.group(3)}{m.group(4)}"
        if shown not in seen:
            seen.add(shown)
            bad.append(shown)
    return bad
