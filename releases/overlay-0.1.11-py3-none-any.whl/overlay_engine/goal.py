"""Goal questions: "I have $10. What are the best ten $1 parlays to make $200?"

Every way of staking the money toward the target is worked out from each leg's own
chance and its real price:

  one parlay     everything on one parlay that pays the target;
  bold play      only the stake that would land exactly on the target, on the shortest
                 parlay that can, and again with what is left if it loses (Dubins and
                 Savage's best plan when there is no edge); simulated, round by round;
  N parlays      the money cut into N equal tickets, each long enough to pay the target
                 by itself, built from the legs with the least margin and sharing as
                 few legs as the board allows (the answer to "the best ten parlays");
  round robin    every two-leg parlay of the best few legs, the money shared out;
  steady bets    a quarter of the Kelly stake on each bet, bet after bet; offered only
                 when some leg is priced above its fair chance.

What comes out is each plan's chance of reaching the target, its chance of getting
nothing back, and what it returns on average. Where the plan is a fixed set of tickets
the chances are exact (inclusion-exclusion over tickets that share legs, or every
outcome of the legs when there are few); the multi-round plans are simulated and say so.

**Where the legs come from is said every time.** With a recent read of live sportsbook
odds (`oddshistory.py`, written by every `board --feed oddsapi` refresh), a leg is a
side of a game: its fair chance is the no-vig price blended from the books that price
it (`fair.py`), and its price is the best at a US book the person can bet at. Without
one, every leg is a typical -110 bet whose other side is also -110, so its fair chance
is 50% and the plan has no edge by construction. Nothing is fetched here: only the command's explicit
`--refresh` reads odds (with the person's own key, saying the cost first), and Ask never does.

**What the mathematics says, and the numbers show each time.** With no edge, the chance
of reaching a target can never exceed bankroll / target (the average return of any
plan is at most the money staked), and splitting the money into many parlays that each
need the target only lowers it: each needs more legs, and every leg pays the book's
margin again. Splitting does raise the chance of getting something back. A plan that
shares legs between tickets is worse still, because its tickets lose together. Nothing
here places a bet, and nothing here finds an edge: the legs are the board's own prices,
and a parlay is the worst-priced bet in the book.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from itertools import combinations

from .odds import decimal_to_american, parse_odds

SIMS = 20000
SEED = 7
FLOOR = 1.0                      # below a dollar a bankroll is gone
ASSUMED_PRICE = -110.0
EXACT_LEGS = 14                  # enumerate every outcome of this many legs, no more
EXACT_TICKETS = 16               # inclusion-exclusion over this many overlapping tickets
MAX_LEGS_PER_TICKET = 30


class GoalError(ValueError):
    """A goal that cannot be planned; the message is a sentence."""


@dataclass(frozen=True)
class Leg:
    label: str
    game: str
    decimal: float
    p: float
    p_low: float
    book: str = ""
    source: str = "assumed"

    @property
    def margin(self) -> float:
        """What the book keeps of this leg's fair value: 1 - chance x price."""
        return 1.0 - self.p * self.decimal

    @property
    def american(self) -> int:
        return round(decimal_to_american(self.decimal))

    def as_dict(self) -> dict:
        return {"label": self.label, "game": self.game, "american": self.american, "decimal": round(self.decimal, 4),
                "chance": round(self.p, 4), "chance_low": round(self.p_low, 4), "book": self.book}


def assumed_pool(count: int, price=ASSUMED_PRICE) -> list:
    """`count` typical bets with no edge: price `price` on both sides, so each side's
    no-vig chance is one half."""
    d = parse_odds(price)
    return [Leg(f"a typical {round(decimal_to_american(d)):+d} bet #{i + 1}", f"g{i}", d, 0.5, 0.5, "", "assumed")
            for i in range(count)]


def board_pool(snapshots, *, sports=None, min_chance=0.03, max_chance=0.92) -> tuple:
    """(legs, details) from recorded reads of live sportsbook odds: one leg for each side
    of each market whose fair chance is anchored by a sharp price, at the best price a
    person can bet at."""
    from . import oddsapi
    from .fair import fair_value
    books = oddsapi.books_table()
    keep = oddsapi.BETTABLE
    legs, games, newest = [], set(), 0.0
    for snap in snapshots:
        if sports and snap["alias"] not in sports:
            continue
        newest = max(newest, snap["fetched_at"])
        from . import oddshistory
        for market in oddsapi.split_by_line(oddshistory.to_markets(snap)):
            fv = fair_value(market, books)
            if not fv:
                continue
            label = snap["events"].get(market.event_id, {}).get("label") or market.event_id
            for key, value in fv.items():
                if not value.anchored or not (min_chance <= value.prob <= max_chance):
                    continue
                best = None
                for q in market.quotes:
                    if q.outcome.key == key and q.book in keep:
                        net = books[q.book].net_decimal(q.decimal) if q.book in books else q.decimal
                        if best is None or net > best[0]:
                            best = (net, q)
                if best is None:
                    continue
                q = best[1]
                kind = {"h2h": "moneyline", "spreads": "", "totals": ""}.get(market.market_type, market.market_type)
                name = key.replace("@", " ")
                text = f"{name} {kind}".strip() if market.market_type == "h2h" else name
                legs.append(Leg(f"{text} ({label})", f"{snap['league']}:{market.event_id}", best[0], value.prob, value.low,
                                keep[q.book], "board"))
                games.add(f"{snap['league']}:{market.event_id}")
    return legs, {"games": len(games), "legs": len(legs), "read_at": newest or None}


# ------------------------------------------------------------ building the tickets

def _fewest(legs: list, order: list, games_used: set, need: float):
    """Add legs in `order`, skipping a game already in the ticket, until the parlay pays `need`."""
    chosen, prod = [], 1.0
    for i in order:
        if legs[i].game in games_used:
            continue
        chosen.append(i)
        games_used = games_used | {legs[i].game}
        prod *= legs[i].decimal
        if prod >= need - 1e-9:
            break
        if len(chosen) >= MAX_LEGS_PER_TICKET:
            return None
    return chosen if prod >= need - 1e-9 else None


def build_tickets(legs: list, n: int, multiple: float) -> list:
    """`n` tickets, each of the fewest legs that pay `multiple` times the stake.

    Legs with the least margin go first, and a leg already used is taken again only
    when every unused one is gone, so tickets share as few legs as the board allows.
    Within one ticket no two legs are from the same game (their results move together,
    and a parlay's chance is only the product of its legs' chances when they do not)."""
    usage = [0] * len(legs)
    out = []
    for _ in range(n):
        order = sorted(range(len(legs)), key=lambda i: (usage[i], legs[i].margin, -legs[i].decimal))
        chosen = _fewest(legs, order, set(), multiple)
        if chosen is None:
            break
        # The last leg: of those not yet used by anything, the one that reaches the
        # multiple with the least overshoot, since overshoot is chance given away.
        if len(chosen) > 1:
            head, prod = chosen[:-1], math.prod(legs[i].decimal for i in chosen[:-1])
            taken = {legs[i].game for i in head}
            tier = usage[chosen[-1]]
            fits = [i for i in range(len(legs)) if usage[i] <= tier and legs[i].game not in taken
                    and i not in head and prod * legs[i].decimal >= multiple - 1e-9]
            if fits:
                chosen = head + [min(fits, key=lambda i: (prod * legs[i].decimal, legs[i].margin))]
        for i in chosen:
            usage[i] += 1
        out.append(chosen)
    return out


# ------------------------------------------------------------ the chances of a fixed set of tickets

def _union_find(tickets):
    parent = {}

    def find(x):
        while parent.setdefault(x, x) != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for t in tickets:
        for i in t[1:]:
            parent[find(i)] = find(t[0])
        find(t[0])
    groups = {}
    for k, t in enumerate(tickets):
        groups.setdefault(find(t[0]), []).append(k)
    return list(groups.values())


def p_any(tickets: list, p: list):
    """The chance at least one ticket wins, and whether it was exact.

    Tickets that share no leg are independent: 1 - prod(1 - p_i). Tickets that share
    legs are grouped, and each group is worked out by inclusion-exclusion over its
    tickets, which is exact for independent legs."""
    miss, exact = 1.0, True
    for group in _union_find(tickets):
        if len(group) == 1:
            miss *= 1.0 - math.prod(p[i] for i in tickets[group[0]])
            continue
        if len(group) > EXACT_TICKETS:
            exact = False
            hit = _simulate_any([tickets[k] for k in group], p)
            miss *= 1.0 - hit
            continue
        total = 0.0
        for mask in range(1, 1 << len(group)):
            union, bits = set(), 0
            for b, k in enumerate(group):
                if mask >> b & 1:
                    bits += 1
                    union.update(tickets[k])
            term = math.prod(p[i] for i in union)
            total += term if bits % 2 else -term
        miss *= 1.0 - total
    return 1.0 - miss, exact


def _simulate_any(tickets, p, sims=SIMS * 5, seed=SEED):
    rng = random.Random(seed)
    used = sorted({i for t in tickets for i in t})
    hits = 0
    for _ in range(sims):
        won = {i for i in used if rng.random() < p[i]}
        if any(all(i in won for i in t) for t in tickets):
            hits += 1
    return hits / sims


def outcome(plan: list, p: list, target: float, *, sims: int = SIMS, seed: int = SEED) -> dict:
    """Chance a set of fixed tickets returns at least `target`, chance it returns nothing,
    and what it returns on average. `plan` is [(stake, [leg indices], decimal)]."""
    tickets = [t[1] for t in plan]
    staked = sum(t[0] for t in plan)
    expected = sum(t[0] * t[2] * math.prod(p[i] for i in t[1]) for t in plan)
    nothing_back, exact_any = p_any(tickets, p)
    nothing_back = 1.0 - nothing_back
    alone = all(t[0] * t[2] >= target - 1e-9 for t in plan)
    if alone:
        return {"reach": 1.0 - nothing_back, "nothing_back": nothing_back, "expected": expected, "staked": staked,
                "method": "exact" if exact_any else "simulated"}
    legs = sorted({i for t in tickets for i in t})
    if len(legs) <= EXACT_LEGS:
        reach = 0.0
        for mask in range(1 << len(legs)):
            won = {legs[b] for b in range(len(legs)) if mask >> b & 1}
            pr = math.prod(p[i] if i in won else 1.0 - p[i] for i in legs)
            back = sum(t[0] * t[2] for t in plan if all(i in won for i in t[1]))
            if back >= target - 1e-9:
                reach += pr
        return {"reach": reach, "nothing_back": nothing_back, "expected": expected, "staked": staked, "method": "exact"}
    rng = random.Random(seed)
    hits = 0
    for _ in range(sims):
        won = {i for i in legs if rng.random() < p[i]}
        if sum(t[0] * t[2] for t in plan if all(i in won for i in t[1])) >= target - 1e-9:
            hits += 1
    return {"reach": hits / sims, "nothing_back": nothing_back, "expected": expected, "staked": staked, "method": "simulated"}


# ------------------------------------------------------------ plans played out round by round

def bold(legs: list, bankroll: float, target: float, *, sims: int = SIMS, seed: int = SEED, rounds: int = 30) -> dict:
    """Each round, the stake that lands exactly on the target on the shortest parlay of the
    best legs that can pay it (everything left on the longest if none can). Each round is a
    fresh slate of bets like these."""
    order = sorted(legs, key=lambda x: (x.margin, -x.decimal))
    D, P, d, q = [], [], 1.0, 1.0
    for leg in order:
        d *= leg.decimal
        q *= leg.p
        D.append(d)
        P.append(q)
    rng = random.Random(seed)
    reached = nothing = 0
    total_back = 0.0
    for _ in range(sims):
        bank = bankroll
        for _ in range(rounds):
            need = target - bank
            k = next((j for j in range(len(D)) if bank * (D[j] - 1) >= need - 1e-9), len(D) - 1)
            stake = need / (D[k] - 1) if bank * (D[k] - 1) >= need - 1e-9 else bank
            if rng.random() < P[k]:
                bank += stake * (D[k] - 1)
            else:
                bank -= stake
            if bank >= target - 1e-6 or bank < FLOOR:
                break
        if bank >= target - 1e-6:
            reached += 1
            total_back += target
        elif bank < FLOOR:
            nothing += 1
        else:
            total_back += bank
    return {"reach": reached / sims, "nothing_back": nothing / sims, "expected": total_back / sims, "staked": bankroll,
            "method": "simulated"}


def steady(legs: list, bankroll: float, target: float, *, sims: int = 4000, seed: int = SEED, max_bets: int = 500) -> dict | None:
    """A quarter of the Kelly stake on each bet (on the cautious chance), the legs taken
    in turn, until the target, a busted bankroll or `max_bets`. Only legs priced above
    their cautious fair chance are bet; with none, there is no such plan."""
    plays = [x for x in legs if x.p_low * x.decimal > 1.0]
    if not plays:
        return None
    frac = []
    for x in plays:
        b = x.decimal - 1.0
        frac.append(max(0.0, (x.p_low * b - (1 - x.p_low)) / b) / 4)
    rng = random.Random(seed)
    reached = nothing = 0
    total_back = 0.0
    for _ in range(sims):
        bank = bankroll
        for t in range(max_bets):
            x, f = plays[t % len(plays)], frac[t % len(plays)]
            stake = bank * f
            bank += stake * (x.decimal - 1) if rng.random() < x.p_low else -stake
            if bank >= target or bank < FLOOR:
                break
        if bank >= target:
            reached += 1
        elif bank < FLOOR:
            nothing += 1
        total_back += min(bank, target) if bank >= FLOOR else 0.0
    return {"reach": reached / sims, "nothing_back": nothing / sims, "expected": total_back / sims, "staked": bankroll,
            "method": "simulated", "legs_cycled": len(plays), "max_bets": max_bets}


# ------------------------------------------------------------ the plan

def _ticket(plan_index: int, stake: float, idx: list, legs: list) -> dict:
    d = math.prod(legs[i].decimal for i in idx)
    pr = math.prod(legs[i].p for i in idx)
    return {"n": plan_index, "stake": round(stake, 2), "legs": [legs[i].as_dict() for i in idx],
            "decimal": round(d, 2), "american": round(decimal_to_american(d)),
            "payout": round(stake * d, 2), "profit_if_hit": round(stake * (d - 1), 2),
            "chance": pr, "worth_on_average": round(stake * d * pr, 4),
            "value_factor": round(d * pr, 4)}


def plan(bankroll: float, target: float, tickets: int | None = None, legs: list | None = None, *,
         legs_from: str = "", pool_details: dict | None = None, sims: int = SIMS, seed: int = SEED, price=ASSUMED_PRICE) -> dict:
    """Every way of staking `bankroll` toward `target` (the amount to end with, stake
    included), and the `tickets` equal parlays that answer "the best N parlays"."""
    if not (bankroll > 0) or not math.isfinite(bankroll):
        raise GoalError("The bankroll has to be more than zero.")
    if not (target > bankroll) or not math.isfinite(target):
        raise GoalError("The target has to be more than the bankroll: it is the amount you want to end with, stake included.")
    n = 1 if tickets is None else int(tickets)
    if n < 1 or n > 100:
        raise GoalError("Choose between 1 and 100 tickets.")
    assumed = not legs
    each = bankroll / n
    multiple = target / each
    if assumed:
        d = parse_odds(price)
        per = max(1, math.ceil(math.log(multiple) / math.log(d) - 1e-12))
        pool = assumed_pool(max(per * n, per, 12), price)
        legs_from = legs_from or (f"a typical {round(decimal_to_american(d)):+d} bet whose other side is also "
                                  f"{round(decimal_to_american(d)):+d}: no edge by construction")
    else:
        pool = sorted(legs, key=lambda x: (x.margin, -x.decimal))
    p = [x.p for x in pool]
    p_low = [x.p_low for x in pool]
    edge_legs = any(x.p_low * x.decimal > 1.0 for x in pool)

    out_tickets = build_tickets(pool, n, multiple)
    result = {"command": "goal", "bankroll": bankroll, "target": target, "tickets": n, "stake_each": round(each, 2),
              "needs": f"{target / bankroll:g}x the bankroll, and {multiple:g}x on each of the {n} tickets",
              "legs_from": legs_from, "legs_source": "assumed" if assumed else "board", "pool": pool_details or {},
              "ceiling": round(bankroll / target, 4), "ceiling_applies": not edge_legs, "parlays": [],
              "strategies": [], "notes": []}
    if len(out_tickets) < n:
        result["notes"].append(
            f"Only {len(out_tickets)} of the {n} tickets could be built: the board's legs cannot make a parlay that pays "
            f"{multiple:g}x any more often than that.")

    strategies = []

    def add(name, how, res, tickets_used=None):
        strategies.append({"strategy": name, "how": how, "chance_to_reach": round(res["reach"], 4),
                           "chance_nothing_back": round(res["nothing_back"], 4),
                           "chance_something_back": round(1 - res["nothing_back"], 4),
                           "expected_return": round(res["expected"], 2), "expected_profit": round(res["expected"] - res["staked"], 2),
                           "staked": round(res["staked"], 2), "method": res["method"],
                           **({"tickets": tickets_used} if tickets_used else {})})

    if out_tickets:
        plan_n = [(each, t, math.prod(pool[i].decimal for i in t)) for t in out_tickets]
        res = outcome(plan_n, p, target, sims=sims, seed=seed)
        result["parlays"] = [_ticket(k + 1, each, t, pool) for k, t in enumerate(out_tickets)]
        shared = sum(len(t) for t in out_tickets) - len({i for t in out_tickets for i in t})
        result["chance_any_hits"] = p_any(out_tickets, p)[0]
        result["chance_any_hits_formula"] = ("1 - (1 - p1)(1 - p2)...(1 - pN), each p the product of that parlay's legs' chances"
                                             + ("" if shared == 0 else "; tickets that share legs are worked out by inclusion-exclusion"))
        result["tickets_share_legs"] = shared > 0
        result["shared_leg_uses"] = shared
        result["expected_return"] = round(res["expected"], 2)
        result["expected_profit"] = round(res["expected"] - bankroll, 2)
        result["chance_reach_target"] = round(res["reach"], 4)
        result["chance_nothing_back"] = round(res["nothing_back"], 4)
        add(f"{len(out_tickets)} parlays" if len(out_tickets) > 1 else "one parlay",
            f"{len(out_tickets)} parlays of ${each:,.2f}, each about {round(sum(len(t) for t in out_tickets) / len(out_tickets))} legs, "
            f"each paying the target on its own" + ("; some legs appear in more than one" if shared else "; no leg in two of them"),
            res, len(out_tickets))

    if n > 1:
        one = build_tickets(pool, 1, target / bankroll)
        if one:
            t = one[0]
            res = outcome([(bankroll, t, math.prod(pool[i].decimal for i in t))], p, target)
            add("one parlay", f"${bankroll:,.2f} on one {len(t)}-leg parlay paying "
                f"{math.prod(pool[i].decimal for i in t):.1f}x", res, 1)
    if pool:
        res = bold(pool, bankroll, target, sims=sims, seed=seed)
        add("bold play", "only the stake that lands exactly on the target, on the shortest parlay that can pay it; what is left "
            "goes again, on a later slate, if it loses", res)
    k = next((k for k in range(3, 9) if k * (k - 1) // 2 >= max(n, 3)), 5)
    k = min(k, len(pool))
    if k >= 3:
        pairs = list(combinations(range(k), 2))
        rr = [(bankroll / len(pairs), list(c), pool[c[0]].decimal * pool[c[1]].decimal) for c in pairs]
        res = outcome(rr, p, target)
        add(f"round robin, pairs of {k}", f"every 2-leg parlay of the best {k} legs ({len(pairs)} parlays, "
            f"${bankroll / len(pairs):,.2f} each)", res, len(pairs))
    st = steady(pool, bankroll, target, seed=seed) if edge_legs else None
    if st:
        add("steady bets", f"a quarter of the Kelly stake on each bet that is priced above its fair chance, bet after bet, "
            f"up to {st['max_bets']} bets; assumes those fair chances are right", st)
    strategies.sort(key=lambda s: -s["chance_to_reach"])
    result["strategies"] = strategies
    result["read_this"] = _words(result, bankroll, target, n, each, pool, out_tickets, assumed, edge_legs)
    return result


def _pct(x: float) -> str:
    if x < 0.001:
        return f"{x:.2%}"
    return f"{x:.1%}"


def _words(r: dict, bankroll: float, target: float, n: int, each: float, pool, out_tickets, assumed: bool, edge: bool) -> str:
    by = {}
    for s in r["strategies"]:
        by.setdefault(s["strategy"].split(",")[0], s)
    parts = []
    if r["ceiling_applies"]:
        parts.append(
            f"With no edge, no plan reaches ${target:g} from ${bankroll:g} more than {_pct(r['ceiling'])} of the time "
            f"(${bankroll:g} divided by ${target:g}), and the book's margin takes some of that.")
    else:
        parts.append("Some of these legs are priced above their fair chance, so the usual ceiling for a bettor with no edge "
                     f"({_pct(r['ceiling'])}, the bankroll divided by the target) does not strictly apply; the chances assume those fair chances are right.")
    if "bold play" in by:
        parts.append(f"Bold play (one big bet, then again with what is left) reaches it {_pct(by['bold play']['chance_to_reach'])} of the time; "
                     "for a bettor without an edge that is the plan the mathematics of gambling (Dubins and Savage) favours.")
    one = by.get("one parlay")
    if one and n > 1:
        parts.append(f"All ${bankroll:g} on one parlay reaches it {_pct(one['chance_to_reach'])} of the time.")
    many = next((s for s in r["strategies"] if s["strategy"].endswith("parlays") and s.get("tickets") == len(out_tickets)), None)
    if many and n > 1:
        same = abs(r['chance_any_hits'] - many['chance_to_reach']) < 1e-4
        parts.append(f"Your {len(out_tickets)} parlays of ${each:g} each pay about ${r['parlays'][0]['payout']:,.0f} if they hit. At least one "
                     f"hits {_pct(r['chance_any_hits'])} of the time"
                     + (", and because each pays the target on its own, that is also the chance of reaching it." if same
                        else f", and together they reach the target {_pct(many['chance_to_reach'])} of the time."))
        if one and many["chance_to_reach"] < one["chance_to_reach"]:
            parts.append("Splitting lowers the chance: each of the smaller parlays needs more legs to pay the target, and every leg "
                         "pays the book's margin again.")
    rr = next((s for s in r["strategies"] if s["strategy"].startswith("round robin")), None)
    if rr:
        parts.append(f"A round robin reaches the target {_pct(rr['chance_to_reach'])} of the time but gets something back "
                     f"{_pct(rr['chance_something_back'])} of the time: it buys a smaller win more often, not the target.")
    if out_tickets:
        t0 = r["parlays"][0]
        parts.append(f"On average each ${each:g} parlay is worth ${t0['worth_on_average']:.2f} (a loss of the rest to the book), "
                     f"and the whole plan returns ${r['expected_return']:.2f} on ${bankroll:g}.")
    if r.get("tickets_share_legs"):
        parts.append("Some tickets share legs, so they tend to lose together; that is the cost of a board with few games.")
    parts.append("This describes the odds of the prices shown. It does not find a bet that beats the book, and nothing here places a bet.")
    return " ".join(parts)
