"""NFL player projections: each player's stat for a week, and the chance of clearing a line.

For each player and each of nine stats (QB passing yards, completions, attempts,
touchdown passes and interceptions; rushing yards and carries; receiving yards
and receptions) the projection for a week uses only games played before it:

  his own level   a decaying average of his earlier games (the newest count most,
                  last season's games discounted again), pulled toward his
                  position's average by how little he has played;
  his team        scaled by the points his team is expected to score, from the
                  game's spread and total (both on the board before kickoff);
  the opponent    scaled by how much that defence has allowed to his position,
                  pulled toward average the same way;
  the script      rushing scaled by how much his team is favoured.

**How it was tuned, and what was kept apart.** Every setting is tuned stat by stat
to make the projection's average miss as small as possible on the 2012-2017
seasons (the *found* seasons); which scalings stay in is chosen on 2018-2021 (the
*validated* seasons); nothing is tuned on 2022 on (the *final* seasons). The
settings ship in `data/nfl_tuned.json` with the misses they produced, and
`tune()` below is the code that made them. Tuning needs 2012 on and is not run on
a person's Mac; a projection needs only the six seasons `nflverse.py` downloads.

**The chance of clearing a line is read from how earlier projections missed, never
from a normal curve with a guessed spread.** The miss is the ratio of what happened
to what was projected, taken over every player game of the found and validated
seasons. Misses are not the same size for a star as for a part-timer, so the
ratios are kept in four bands by the size of the projection, and a line's chance is
the share of the band's ratios that would clear it:

    chance(line) = share of ratios r in the player's band with r x projection > line

The shipped file holds those ratios (as 401 evenly spaced quantiles per band, with
the full count). It is *calibrated out of sample*: for every player game from 2022
on, at lines set at several multiples of the projection, the stated chance is put
beside how often it happened, in ten buckets, and the table is stored and shown on
request (`players --calibration`). A projection is not an edge: the books see the
same logs, and nothing here says a line is mispriced.

**A line of 300 means 300 or more.** `--line 299.5` and `--line 300` ask the same
question: does he reach 300? There is no push to price.

**Who plays is not in these files.** Injuries, inactives and benchings are not
published in the weekly stats, so a projection assumes the player takes his usual
role. The quarterback is the team's top passer in its last game; others are players
who touched the ball in the team's last three games. Check the inactive list before
kickoff.
"""

from __future__ import annotations

import json
import math
import time
from bisect import bisect_right
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

from . import nflverse

DATA = Path(__file__).resolve().parent / "data" / "nfl_tuned.json"

BLOCKS = {"found": (2012, 2017), "validated": (2018, 2021), "final": (2022, 2099)}
EDGE_NOTE = ("A projection is not an edge. Books set these lines from the same game logs, "
             "so a chance here says what the logs imply, not that a price is wrong.")

#: Lines for the calibration table, as multiples of each projection.
MULTIPLES = (0.4, 0.55, 0.7, 0.8, 0.9, 1.0, 1.1, 1.25, 1.5, 1.75, 2.2)
BUCKETS = 10
QUANTILES = 401
BANDS = 4
MODEL_VERSION = 1


@dataclass(frozen=True)
class Stat:
    name: str
    cols: tuple
    positions: tuple
    unit: str
    aliases: tuple
    usage: tuple | None = None       # (column, minimum in a recent game) for non-QB stats
    script: bool = False             # rushing is scaled by how much the team is favoured


STATS = {s.name: s for s in (
    Stat("passing yards", ("passing_yards",), ("QB",), "yards",
         ("pass yards", "passing yds", "pass yds", "passing yards", "yards passing", "passing yard")),
    Stat("completions", ("completions",), ("QB",), "completions", ("pass completions", "completion")),
    Stat("pass attempts", ("attempts",), ("QB",), "attempts", ("attempts", "passing attempts", "pass attempt")),
    Stat("passing TDs", ("passing_tds",), ("QB",), "touchdowns",
         ("passing touchdowns", "touchdown passes", "td passes", "pass tds", "passing td", "tds thrown")),
    Stat("interceptions", ("passing_interceptions",), ("QB",), "interceptions",
         ("interceptions thrown", "ints", "picks", "interception")),
    Stat("rushing yards", ("rushing_yards",), ("RB", "QB"), "yards",
         ("rush yards", "rushing yds", "rush yds", "yards rushing", "rushing yard"), ("carries", 3), True),
    Stat("carries", ("carries",), ("RB", "QB"), "carries",
         ("rushing attempts", "rush attempts", "rushes", "carry"), ("carries", 3), True),
    Stat("receiving yards", ("receiving_yards",), ("WR", "TE", "RB"), "yards",
         ("rec yards", "receiving yds", "rec yds", "yards receiving", "receiving yard"), ("receptions", 1)),
    Stat("receptions", ("receptions",), ("WR", "TE", "RB"), "receptions",
         ("catches", "rec", "reception", "recs"), ("receptions", 1)),
)}

_ALIASES = {}
for _s in STATS.values():
    _ALIASES[_s.name.lower()] = _s.name
    for _a in _s.aliases:
        _ALIASES[_a.lower()] = _s.name


class ProjectionError(ValueError):
    """A question the projections cannot answer; the message is a sentence."""


def stat_for(text: str) -> Stat:
    key = " ".join(str(text or "").lower().replace("-", " ").split())
    for prefix in ("qb ", "player "):
        if key.startswith(prefix):
            key = key[len(prefix):]
    name = _ALIASES.get(key)
    if name is None:
        raise ProjectionError(
            f"{text!r} is not a stat Bookbreaker projects. Choose from: " + ", ".join(STATS) + ".")
    return STATS[name]


# ------------------------------------------------------------ the shipped settings

def load_tuned(path: Path | None = None) -> dict:
    try:
        return json.loads((path or DATA).read_text())
    except (OSError, ValueError):
        raise ProjectionError("The projection settings that ship with Bookbreaker could not be read. "
                              "Reinstall the app.") from None


# ------------------------------------------------------------ the projection pass

def block(season: int) -> str | None:
    for name, (a, b) in BLOCKS.items():
        if a <= season <= b:
            return name
    return None


def relevant(stat: Stat, row: dict) -> bool:
    return row["pos"] in stat.positions


def value(row: dict, stat: Stat) -> float:
    return sum(row[c] for c in stat.cols)


def context(games: list) -> dict:
    """(season, week, team) -> (the team's implied points, how much it is favoured),
    from the game's spread (positive: home favoured) and total, on the board before
    kickoff."""
    out = {}
    for g in games:
        if g["line"] is None or g["total"] is None:
            continue
        home_pts = g["total"] / 2 + g["line"] / 2
        out[(g["season"], g["week"], g["home"])] = (home_pts, g["line"])
        out[(g["season"], g["week"], g["away"])] = (g["total"] - home_pts, -g["line"])
    return out


class State:
    """What the pass has learned by the end of the last game it saw."""

    def __init__(self):
        self.hist = {}                                   # pid -> [weighted sum, weight, last season]
        self.pos_mean = defaultdict(lambda: [0.0, 0.0])  # position -> running mean in games played
        self.allowed = {}                                # (defence, position) -> [weighted ratio sum, weight, season]
        self.league_pts = [0.0, 0.0]
        self.games = defaultdict(int)                    # pid -> games seen
        self.last = {}                                   # pid -> (season, week, team, pos, name)


def _base(state: State, ctx: dict, r: dict, stat: Stat, p: dict):
    """The projection for player-game `r` from what `state` knows, or None."""
    lam, rho, K = p["lam"], p["rho"], p["K"]
    a, c, b, Kd = p.get("a", 0.0), p.get("c", 0.0), p.get("b", 0.0), p.get("Kd", 20.0)
    h = state.hist.get(r["pid"])
    pm = state.pos_mean[r["pos"]]
    mu = pm[0] / pm[1] if pm[1] else None
    if h is None or mu is None or h[1] <= 0:
        return None
    w = h[1] * (rho if h[2] != r["season"] else 1.0)
    own = h[0] / h[1]
    base = (w * own + K * mu) / (w + K)
    cx = ctx.get((r["season"], r["week"], r["team"]))
    if cx and a and state.league_pts[1]:
        base *= (cx[0] / (state.league_pts[0] / state.league_pts[1])) ** a
    d = state.allowed.get((r["opp"], r["pos"]))
    if d and c:
        dw = d[1] * (rho if d[2] != r["season"] else 1.0)
        base *= ((dw * (d[0] / d[1]) + Kd) / (dw + Kd)) ** c
    if cx and b and stat.script:
        base *= max(0.2, 1 + b * cx[1])
    return max(0.0, base)


def _learn(state: State, ctx: dict, r: dict, stat: Stat, p: dict) -> None:
    lam, rho = p["lam"], p["rho"]
    v = value(r, stat)
    pm = state.pos_mean[r["pos"]]
    mu = pm[0] / pm[1] if pm[1] else None
    h = state.hist.get(r["pid"])
    if h is None:
        state.hist[r["pid"]] = [v, 1.0, r["season"]]
    else:
        f = lam * (rho if h[2] != r["season"] else 1.0)
        state.hist[r["pid"]] = [h[0] * f + v, h[1] * f + 1.0, r["season"]]
    if mu:
        k = (r["opp"], r["pos"])
        d = state.allowed.get(k)
        ratio = v / mu
        if d is None:
            state.allowed[k] = [ratio, 1.0, r["season"]]
        else:
            f = lam * (rho if d[2] != r["season"] else 1.0)
            state.allowed[k] = [d[0] * f + ratio, d[1] * f + 1.0, r["season"]]
    pm[0] = pm[0] * 0.999 + v
    pm[1] = pm[1] * 0.999 + 1.0
    cx = ctx.get((r["season"], r["week"], r["team"]))
    if cx:
        state.league_pts[0] = state.league_pts[0] * 0.999 + cx[0]
        state.league_pts[1] = state.league_pts[1] * 0.999 + 1.0
    state.games[r["pid"]] += 1
    state.last[r["pid"]] = (r["season"], r["week"], r["team"], r["pos"], r["name"])


def project(rows: list, ctx: dict, stat: Stat, p: dict, state: State | None = None):
    """(row, projection made before that week) for every player game where the
    player has an earlier game, and the state at the end. The projection never
    sees its own week: a week is projected whole, then learned from."""
    state = state or State()
    out = []
    i, n = 0, len(rows)
    while i < n:
        j = i
        key = (rows[i]["season"], rows[i]["week"])
        while j < n and (rows[j]["season"], rows[j]["week"]) == key:
            j += 1
        week = rows[i:j]
        for r in week:
            pr = _base(state, ctx, r, stat, p)
            if pr is not None:
                out.append((r, pr))
        for r in week:
            _learn(state, ctx, r, stat, p)
        i = j
    return out, state


# ------------------------------------------------------------ the miss distribution

def _quantiles(sorted_values: list, m: int = QUANTILES) -> list:
    n = len(sorted_values)
    if n == 0:
        return []
    if n <= m:
        return [round(x, 4) for x in sorted_values]
    return [round(sorted_values[round(i * (n - 1) / (m - 1))], 4) for i in range(m)]


def build_spread(pairs: list, stat: Stat, blocks=("found", "validated")) -> dict:
    """The ratios of what happened to what was projected, in bands by projection size."""
    pool = sorted(((pr, value(r, stat) / pr) for r, pr in pairs
                   if block(r["season"]) in blocks and pr > 0 and relevant(stat, r)))
    if not pool:
        return {"n": 0, "edges": [], "bands": [], "counts": []}
    projections = [pr for pr, _ in pool]
    edges = [round(projections[round(len(pool) * k / BANDS)], 4) for k in range(1, BANDS)]
    groups = [[] for _ in range(BANDS)]
    for pr, ratio in pool:
        groups[bisect_right(edges, pr)].append(ratio)
    return {"n": len(pool), "edges": edges, "counts": [len(g) for g in groups],
            "bands": [_quantiles(sorted(g)) for g in groups]}


def band_of(spread: dict, projection: float) -> int:
    return min(bisect_right(spread["edges"], projection), len(spread["bands"]) - 1)


def chance_over(spread: dict, projection: float, threshold: float) -> float:
    """The chance the stat finishes above `threshold` (a half-line, so 299.5 is 300 or more),
    read off the ratios of the projection's band."""
    if projection <= 0 or not spread.get("bands"):
        return 0.0
    q = spread["bands"][band_of(spread, projection)]
    if not q:
        return 0.0
    return 1.0 - bisect_right(q, threshold / projection) / len(q)


def at_least(line: float) -> float:
    """A whole-number line asks for that many or more; a half line is already the threshold."""
    return line - 0.5 if float(line).is_integer() else line


# ------------------------------------------------------------ calibration (2022 on)

def calibration(pairs: list, stat: Stat, spread: dict) -> dict:
    """For every player game of the final seasons (2022 on), at lines set at several
    multiples of the projection, the chance this model stated against how often it
    happened. Ten buckets of stated chance; the gap in each."""
    buckets = [[0, 0.0, 0] for _ in range(BUCKETS)]        # n, sum of stated chance, hits
    for r, pr in pairs:
        if block(r["season"]) != "final" or pr < 0.5 or not relevant(stat, r):
            continue
        actual = value(r, stat)
        for m in MULTIPLES:
            thr = math.floor(m * pr) + 0.5
            p = chance_over(spread, pr, thr)
            b = buckets[min(int(p * BUCKETS), BUCKETS - 1)]
            b[0] += 1
            b[1] += p
            b[2] += 1 if actual > thr else 0
    rows = []
    gap_sum = worst = total = 0
    for k, (n, ps, hits) in enumerate(buckets):
        if not n:
            continue
        stated, seen = ps / n, hits / n
        rows.append({"bucket": f"{k * 100 // BUCKETS}-{(k + 1) * 100 // BUCKETS}%", "n": n,
                     "stated": round(stated, 4), "happened": round(seen, 4), "gap": round(seen - stated, 4)})
        gap_sum += abs(seen - stated) * n
        total += n
        if n >= 200:
            worst = max(worst, abs(seen - stated))
    return {"seasons": "2022 on", "lines": f"{len(MULTIPLES)} lines per player game, at {MULTIPLES[0]} to {MULTIPLES[-1]} times the projection",
            "n": total, "mean_gap": round(gap_sum / total, 4) if total else None,
            "worst_gap": round(worst, 4), "buckets": rows}


def miss(pairs: list, stat: Stat, which: str) -> float | None:
    xs = [abs(value(r, stat) - pr) for r, pr in pairs if block(r["season"]) == which and relevant(stat, r)]
    return sum(xs) / len(xs) if xs else None


# ------------------------------------------------------------ tuning (done once, offline)

GRID = {"lam": (0.80, 0.85, 0.9, 0.94, 0.97), "rho": (0.3, 0.5, 0.7, 0.9), "K": (0.5, 1.0, 2.0, 4.0, 8.0),
        "a": (0.0, 0.5, 1.0, 1.5), "c": (0.0, 0.25, 0.5, 0.75), "b": (0.0, 0.005, 0.01, 0.02, 0.03)}
VARIANTS = {"own level": ("lam", "rho", "K"), "+ team": ("lam", "rho", "K", "a"),
            "+ team, opponent": ("lam", "rho", "K", "a", "c"),
            "+ team, opponent, script": ("lam", "rho", "K", "a", "c", "b")}


def tune(rows: list, ctx: dict, stat: Stat, log=None) -> dict:
    """Each variant's settings tuned on 2012-2017 by the average miss (two passes of
    coordinate descent over `GRID`); the variant with the smallest miss on 2018-2021
    is kept. Nothing from 2022 on is looked at."""
    upto = [r for r in rows if r["season"] <= BLOCKS["validated"][1] and relevant(stat, r)]
    table = {}
    for name, names in VARIANTS.items():
        if "b" in names and not stat.script:
            continue
        p = {"lam": 0.9, "rho": 0.6, "K": 2.0, "a": 0.0, "c": 0.0, "b": 0.0, "Kd": 20.0}
        best = miss(project(upto, ctx, stat, p)[0], stat, "found")
        for _ in range(2):
            for k in names:
                for v in GRID[k]:
                    q = dict(p, **{k: v})
                    m = miss(project(upto, ctx, stat, q)[0], stat, "found")
                    if m is not None and m < best - 1e-9:
                        best, p = m, q
        pairs, _ = project(upto, ctx, stat, p)
        table[name] = {"params": p, "found_miss": round(best, 3),
                       "validated_miss": round(miss(pairs, stat, "validated"), 3)}
        if log:
            log(f"{stat.name} {name} {table[name]}")
    chosen = min(table, key=lambda n: table[n]["validated_miss"])
    return {"variants": table, "chosen": chosen}


# ------------------------------------------------------------ this week

def this_week(games: list, today: date | None = None) -> tuple:
    """(season, week) of the first game with no result yet that is not already in
    the past. A game stays "this week" until the day after it, so Monday night's
    game does not push Monday to next week before nflverse has its result."""
    today = today or date.today()
    cutoff = (today - timedelta(days=1)).isoformat()
    ahead = [g for g in games if g["result"] is None and g["day"] >= cutoff]
    if not ahead:
        raise ProjectionError("The schedule has no upcoming NFL games. The season may be over, or the games "
                              "file is out of date: run players --update.")
    first = min(ahead, key=lambda g: (g["season"], g["week"], g["day"]))
    return first["season"], first["week"]


def resolve_week(games: list, week, today: date | None = None) -> tuple:
    """`this`, `next` or a week number in this season."""
    season, current = this_week(games, today)
    text = str(week or "this").strip().lower()
    if text in ("this", "current", ""):
        return season, current
    weeks = sorted({g["week"] for g in games if g["season"] == season and g["week"] > current and g["result"] is None})
    if text == "next":
        if not weeks:
            raise ProjectionError("There is no later week on the schedule.")
        return season, weeks[0]
    try:
        n = int(text)
    except ValueError:
        raise ProjectionError(f"{week!r} is not a week. Use this, next, or a week number.") from None
    if not any(g["season"] == season and g["week"] == n for g in games):
        raise ProjectionError(f"There is no week {n} in the {season} schedule.")
    return season, n


# ------------------------------------------------------------ who, and against whom

def candidates(rows: list, stat: Stat, teams: set, state: State) -> list:
    """Players expected to take the role the stat needs, for the teams in `teams`.

    The team's last three games are the evidence of role: a quarterback is the top
    passer of the team's most recent game; anyone else must have touched the ball
    (the stat's usage column) in one of them, and must still be on that team in his
    latest game."""
    by_team = defaultdict(set)
    for r in rows:
        by_team[r["team"]].add((r["season"], r["week"]))
    recent = {t: sorted(w)[-3:] for t, w in by_team.items() if t in teams}
    out = {}
    if stat.positions == ("QB",):
        best = {}
        for r in rows:
            if r["team"] in recent and (r["season"], r["week"]) == recent[r["team"]][-1] and r["pos"] == "QB":
                if r["attempts"] > best.get(r["team"], (-1, None))[0]:
                    best[r["team"]] = (r["attempts"], r)
        for team, (att, r) in best.items():
            if att >= 5:
                out[r["pid"]] = r
        return list(out.values())
    col, minimum = stat.usage
    last = {}
    for r in rows:
        if r["team"] in recent and (r["season"], r["week"]) in recent[r["team"]] and r["pos"] in stat.positions:
            if r[col] >= minimum:
                last[r["pid"]] = r
    for pid, r in last.items():
        seen = state.last.get(pid)
        if seen and seen[2] == r["team"] and (seen[0], seen[1]) >= recent[r["team"]][0]:
            out[pid] = r
    return list(out.values())


def week_games(games: list, season: int, week: int) -> list:
    return [g for g in games if g["season"] == season and g["week"] == week]


# ------------------------------------------------------------ the answer

@dataclass
class Answer:
    stat: Stat
    line: float | None
    season: int
    week: int
    rows: list
    games: list
    sample: dict
    calibration: dict
    miss_final: float | None
    notes: list

    def as_dict(self) -> dict:
        return {"stat": self.stat.name, "unit": self.stat.unit, "line": self.line,
                "threshold": None if self.line is None else at_least(self.line),
                "meaning": None if self.line is None else (
                    f"reach {math.ceil(at_least(self.line))} {self.stat.unit} or more"),
                "season": self.season, "week": self.week, "games": self.games, "rows": self.rows,
                "sample": self.sample, "calibration": self.calibration,
                "average_miss_2022_on": None if self.miss_final is None else round(self.miss_final, 2),
                "notes": self.notes, "edge": False, "not_an_edge": EDGE_NOTE}


def answer(stat_name: str, line: float | None = None, week="this", *, team: str | None = None,
           player: str | None = None, limit: int = 15, folder: Path | None = None,
           tuned: dict | None = None, today: date | None = None) -> Answer:
    """Players ranked by the chance of clearing `line` (or by projection with no line)."""
    stat = stat_for(stat_name)
    folder = folder or nflverse.cache_dir()
    if not nflverse.have_data(folder):
        raise ProjectionError(
            "NFL player data has not been downloaded yet. Run players --update, which downloads "
            f"public nflverse files from GitHub (about {nflverse.ESTIMATE_MB} MB).")
    tuned = tuned or load_tuned()
    setting = tuned["stats"].get(stat.name)
    if not setting:
        raise ProjectionError(f"There are no tuned settings for {stat.name}.")
    p, spread = setting["params"], setting["spread"]

    games = nflverse.read_games(folder)
    season, wk = resolve_week(games, week, today)
    ctx = context(games)
    rows = [r for r in nflverse.read_weekly(folder) if relevant(stat, r)]
    pairs, state = project(rows, ctx, stat, p)
    now_games = week_games(games, season, wk)
    # A team that has already played this week (Thursday night) is left out: its
    # game is in the files, and a projection is for a game still to come.
    played = {r["team"] for r in rows if r["season"] == season and r["week"] == wk}
    teams = {t for g in now_games for t in (g["home"], g["away"])} - played
    notes = []
    if played:
        notes.append(f"{len(played)} team(s) have already played week {wk} and are left out: "
                     + ", ".join(sorted(played)) + ".")
    if any(r["season"] == season and r["week"] > wk for r in rows):
        raise ProjectionError(f"Week {wk} has been played already; projections are for weeks still to come.")

    out = []
    for r in candidates(rows, stat, teams, state):
        game = next((g for g in now_games if r["team"] in (g["home"], g["away"])), None)
        if game is None:
            continue
        home = r["team"] == game["home"]
        opp = game["away"] if home else game["home"]
        virtual = {"pid": r["pid"], "name": r["name"], "pos": r["pos"], "team": r["team"], "opp": opp,
                   "season": season, "week": wk}
        pr = _base(state, ctx, virtual, stat, p)
        if pr is None:
            continue
        # The way a sportsbook prints it: the favourite carries the minus sign.
        spread_for_team = None if game["line"] is None else -(game["line"] if home else -game["line"])
        band = band_of(spread, pr)
        row = {"player": r["name"], "pid": r["pid"], "position": r["pos"], "team": r["team"], "opponent": opp,
               "home": home, "kickoff": game["day"], "spread": spread_for_team, "total": game["total"],
               "projection": round(pr, 2), "games": state.games[r["pid"]], "thin_history": state.games[r["pid"]] < 5,
               "last_played": f"{state.last[r['pid']][0]} week {state.last[r['pid']][1]}",
               "band": band + 1, "miss_sample": spread["counts"][band]}
        if line is not None:
            thr = at_least(line)
            row["chance"] = round(chance_over(spread, pr, thr), 4)
        out.append(row)
    if team:
        out = [o for o in out if o["team"].lower() == team.lower()]
    if player:
        out = [o for o in out if player.lower() in o["player"].lower()]
    key = (lambda o: -o["chance"]) if line is not None else (lambda o: -o["projection"])
    out.sort(key=key)
    out = out[:max(1, int(limit))]

    missing = [g for g in now_games if g["line"] is None or g["total"] is None]
    if missing:
        notes.append(f"{len(missing)} game(s) this week have no spread or total in the schedule yet, so those teams' "
                     "projections do not use the game's expected score.")
    notes.append("Who plays is not in these files: injuries and inactives are not published in them. "
                 "Check the inactive list before kickoff.")
    stored = stored_calibration(folder)
    cal = None
    if stored and stat.name in stored["stats"]:
        c = stored["stats"][stat.name]
        cal = {"seasons": c["seasons"], "n": c["n"], "mean_gap": c["mean_gap"], "worst_gap": c["worst_gap"],
               "buckets": c["buckets"]}
    else:
        notes.append("The out-of-sample calibration table has not been built yet: run players --calibration.")
    sample = {"seasons": "2012-2021", "n": spread["n"], "bands": spread["counts"],
              "edges": spread["edges"], "variant": setting["variant"],
              "found_average_miss": setting.get("found_miss"), "validated_average_miss": setting.get("validated_miss")}
    return Answer(stat, line, season, wk, out, [
        {"home": g["home"], "away": g["away"], "day": g["day"],
         "home_spread": None if g["line"] is None else -g["line"], "total": g["total"]}
        for g in now_games], sample, cal, miss(pairs, stat, "final"), notes)


def calibration_table(folder: Path | None = None, tuned: dict | None = None, stats=None) -> dict:
    """The out-of-sample table for every stat (or `stats`), computed from the
    downloaded files with the shipped settings and stored beside them."""
    folder = folder or nflverse.cache_dir()
    if not nflverse.have_data(folder):
        raise ProjectionError(f"NFL player data has not been downloaded yet. Run players --update "
                              f"(about {nflverse.ESTIMATE_MB} MB of public files from GitHub).")
    tuned = tuned or load_tuned()
    games = nflverse.read_games(folder)
    ctx = context(games)
    everything = nflverse.read_weekly(folder)
    out = {}
    for name in (stats or STATS):
        stat = STATS[name]
        setting = tuned["stats"][name]
        pairs, _ = project([r for r in everything if relevant(stat, r)], ctx, stat, setting["params"])
        cal = calibration(pairs, stat, setting["spread"])
        cal["average_miss_2022_on"] = None if miss(pairs, stat, "final") is None else round(miss(pairs, stat, "final"), 2)
        out[name] = cal
    result = {"built_at": time.time(), "fingerprint": nflverse.fingerprint(folder), "stats": out,
              "reference_at_tuning": {n: tuned["stats"][n].get("reference_calibration") for n in out},
              "note": ("Stated chance against how often it happened, for every player game from 2022 on, at "
                       "several lines per game. The settings and miss ratios come from 2012-2021 only. " + EDGE_NOTE)}
    try:
        (folder / "calibration.json").write_text(json.dumps(result, indent=1))
    except OSError:
        pass
    return result


def stored_calibration(folder: Path | None = None):
    folder = folder or nflverse.cache_dir()
    try:
        data = json.loads((folder / "calibration.json").read_text())
    except (OSError, ValueError):
        return None
    return data if data.get("fingerprint") == nflverse.fingerprint(folder) else None
