"""A tool's result as a small table and, for the built-in answerer, one honest sentence.

Every answer in the window shows its numbers as a table beside the sentence. The table
is drawn here, from the tool's own result, by code: no model writes a cell. Whoever
wrote the sentence (Claude, a local model, or `sentence()` below), the figures a person
can check are the table's.

`sentence()` is what Ask says when no AI is available. It reads fields out of the result
and names them; it never computes a figure. A figure it prints is a figure the tool
returned, formatted.
"""

from __future__ import annotations

from datetime import datetime, timezone


def pct(x, dp: int = 0) -> str:
    return "n/a" if x is None else f"{x * 100:.{dp}f}%"


def usd(x, dp: int = 2) -> str:
    return "n/a" if x is None else f"${x:,.{dp}f}"


def _american(x) -> str:
    return "n/a" if x is None else f"{x:+d}"


def _num(x, dp: int = 1) -> str:
    if x is None:
        return "n/a"
    return f"{x:.{dp}f}".rstrip("0").rstrip(".") if dp else f"{x:.0f}"


def _table(title: str, columns: list, rows: list, note: str = "") -> dict:
    return {"title": title, "columns": columns, "rows": rows, "note": note}


# ------------------------------------------------------------ tables

def tables(name: str, args: dict, r) -> list:
    if not isinstance(r, dict):
        return []
    fn = _TABLES.get(name)
    try:
        return fn(args, r) if fn else []
    except (KeyError, TypeError, ValueError):
        return []


def _players(args, r):
    if r.get("needs_download"):
        return []
    has_line = r.get("line") is not None
    cols = ["Player", "Team", "Opponent", "Spread", "Total", "Projection"] + (["Chance"] if has_line else []) + ["Games"]
    rows = []
    for x in r["rows"]:
        spread = "n/a" if x["spread"] is None else f"{x['team']} {x['spread']:+g}"
        row = [x["player"], x["team"], ("vs " if x["home"] else "@ ") + x["opponent"], spread,
               _num(x["total"]), _num(x["projection"])]
        if has_line:
            row.append(pct(x["chance"]))
        row.append(str(x["games"]))
        rows.append(row)
    unit = r["unit"]
    title = f"{r['stat'].capitalize()}, week {r['week']} of {r['season']}" + (f": chance to {r['meaning']}" if r.get("meaning") else "")
    s = r["sample"]
    note = (f"A projection from game logs, not an edge. Miss distribution from {s['n']:,} player games, {s['seasons']}"
            + (f"; checked on 2022 on: stated chances were off by {pct(r['calibration']['mean_gap'], 1)} on average"
               if r.get("calibration") and r["calibration"].get("mean_gap") is not None else "") + f". Unit: {unit}.")
    return [_table(title, cols, rows, note)]


def _goal(args, r):
    rows = []
    for t in r["parlays"]:
        labels = [leg["label"].split(" #")[0] for leg in t["legs"]]
        text = (f"{len(labels)} × {labels[0]}" if len(set(labels)) == 1 and len(labels) > 1
                else "; ".join(leg["label"] for leg in t["legs"]))
        rows.append([str(t["n"]), text, _american(t["american"]), usd(t["payout"]), pct(t["chance"], 3)])
    out = [_table(f"The {len(r['parlays'])} parlays (${r['stake_each']:g} each)", ["#", "Legs", "Price", "Pays if it hits", "Chance"], rows,
                  r.get("legs_from", ""))] if rows else []
    strat = [[s["strategy"], pct(s["chance_to_reach"], 2), pct(s["chance_something_back"], 1), usd(s["expected_return"])]
             for s in r["strategies"]]
    out.append(_table(f"Ways to stake ${r['bankroll']:g} toward ${r['target']:g}",
                      ["Plan", "Reaches the target", "Gets something back", "Average return"], strat,
                      f"With no edge nothing can beat {pct(r['ceiling'], 1)} (bankroll divided by target)." if r.get("ceiling_applies") else ""))
    return out


def _board(args, r):
    if not r.get("has_odds"):
        return []
    rows = []
    for x in r["rows"]:
        play = " vs ".join(f"{leg.get('book_name', leg['book'])} {leg['outcome']} {_american(leg.get('american'))} for {usd(leg['stake'], 0)}"
                           for leg in x["legs"])
        rows.append([x["kind"], x["event"], play, usd(x["profit"]), pct(x["margin"], 2), pct(x["p_fill"])])
    return [_table("Board from the last read of live odds", ["Kind", "Game", "Play", "Return", "Edge", "Fill"], rows, r.get("note", ""))]


def _devig(args, r):
    rows = [[_american(o.get("american")), pct(o["consensus"], 1), _american(o.get("fair_american"))] for o in r["outcomes"]]
    return [_table("Fair odds", ["Price", "Fair chance", "Fair price"], rows, f"The book's margin is {pct(r['hold'], 2)}.")]


def _parlay(args, r):
    return [_table("Parlay", ["Legs", "Pays $100 →", "Should pay", "Margin", "Expected on $100"],
                   [[str(r["legs"]), usd(r["per_100"]["wins"]), usd(r["per_100"]["fair_wins"]), pct(r["hold"], 1),
                     usd(r["per_100"]["expected"])]], r.get("correlation_note", ""))]


def _kelly(args, r):
    return [_table("Bet size", ["Stake", "Share of bankroll", "Full Kelly"], [[usd(r["stake"]), pct(r["stake_fraction"], 2),
                                                                           pct(r["full_kelly"], 2)]])]


def _welcome(args, r):
    rows = [[o.get("name") or o.get("book"), o.get("headline", ""), usd(o.get("locked_if_every_bet_stands")) if o.get("locked_if_every_bet_stands")
             else usd(o.get("expected"))] for o in r.get("offers", [])]
    return [_table("Sign-up offers", ["Book", "Offer", "Converts to"], rows, "Locked only if every bet is accepted and stands.")] if rows else []


def _performance(args, r):
    if not r.get("settled"):
        return []
    return [_table("Your record", ["Settled", "Won–lost", "Profit", "Return", "Win rate"],
                   [[str(r["settled"]), f"{r['won']}–{r['lost']}", usd(r["profit"]), pct(r["roi"], 2), pct(r["win_rate"], 1)]])]


def _live(args, r):
    rows = []
    for p in r.get("pairs", []):
        rows.append([p.get("league", "").upper(), p.get("game", ""), usd(p.get("profit")), pct(p.get("margin"), 2)])
    return [_table("Kalshi / Polymarket US pairs", ["League", "Game", "Return", "Margin"], rows, "Locked only if both bets are accepted and stand.")] if rows else []


_TABLES = {"players": _players, "goal": _goal, "board": _board, "devig": _devig, "parlay": _parlay,
           "kelly": _kelly, "welcome": _welcome, "performance": _performance, "live_prices": _live}


# ------------------------------------------------------------ the sentence without an AI

def sentence(name: str, args: dict, r) -> str:
    fn = _SENTENCES.get(name)
    if not isinstance(r, dict) or fn is None:
        return ""
    try:
        return fn(args, r)
    except (KeyError, TypeError, ValueError, IndexError):
        return ""


def _s_players(args, r):
    if r.get("needs_download"):
        return r["message"]
    rows = r["rows"]
    if not rows:
        return f"No player with a recent role in week {r['week']} matched that."
    top = rows[:3]
    if r.get("line") is not None:
        who = "; ".join(f"{x['player']} ({x['team']} {'vs' if x['home'] else '@'} {x['opponent']}) {pct(x['chance'])}, projected {_num(x['projection'])}"
                        for x in top)
        lead = f"Most likely to {r['meaning']} in week {r['week']}: {who}."
    else:
        who = "; ".join(f"{x['player']} ({x['team']}) {_num(x['projection'])}" for x in top)
        lead = f"Highest projected {r['stat']} in week {r['week']}: {who}."
    return lead + f" These are projections from game logs, not recommendations. {r['notes'][-1] if r.get('notes') else ''}".rstrip()


def _s_goal(args, r):
    lead = r["legs_from"][:1].upper() + r["legs_from"][1:]
    return f"{lead}. " + r["read_this"]


def _s_board(args, r):
    if not r.get("has_odds"):
        return r["message"]
    c = r["counts"]
    if not r["rows"]:
        return f"None of the games in the last read ({round(r['age_seconds'] / 60)} minutes ago) has an arb, a +EV bet or a middle right now. " + r["note"]
    return (f"The last read of live odds ({round(r['age_seconds'] / 60)} minutes ago) has {c['arb']} arb(s), {c['ev']} +EV bet(s) and "
            f"{c['middle']} middle(s). The table lists the best first. " + r["note"])


def _s_devig(args, r):
    return ("Fair chances with the book's margin taken out: "
            + ", ".join(f"{_american(o['american'])} is {pct(o['consensus'], 1)} (fair {_american(o['fair_american'])})" for o in r["outcomes"])
            + f". The book's margin is {pct(r['hold'], 2)}.")


def _s_parlay(args, r):
    return (f"A {r['legs']}-leg parlay pays {usd(r['per_100']['wins'])} on $100 where {usd(r['per_100']['fair_wins'])} would be fair: "
            f"its hold is {pct(r['hold'], 1)}, and its expected profit on $100 is {usd(r['per_100']['expected'])}. {r['correlation_note']}")


def _s_kelly(args, r):
    return (f"Full Kelly says {pct(r['full_kelly'], 1)} of the bankroll; the stake this sets is {usd(r['stake'])} "
            f"({pct(r['stake_fraction'], 2)}). It assumes your win chance is right.")


def _s_welcome(args, r):
    offers = r.get("offers", [])
    if not offers:
        return "No current offer was found" + (f" for {r['state']}." if r.get("state") else ". Give your state.")
    top = offers[0]
    return (f"The best current offer{' in ' + r['state'] if r.get('state') else ''} is {top.get('name') or top.get('book')}: "
            f"{top.get('headline', '')}, worth {usd(top.get('locked_if_every_bet_stands') or top.get('expected'))} converted, "
            "locked only if every bet is accepted and stands.")


def _s_performance(args, r):
    if not r.get("settled"):
        return "You have no settled bets yet. Paste a betslip or import your book's CSV on My bets."
    return (f"{r['settled']} settled bets: {r['won']} won, {r['lost']} lost, {usd(r['profit'])} profit on {usd(r['turnover'])} bet "
            f"({pct(r['roi'], 2)}). {r['verdict']}")


def _s_live(args, r):
    pairs = r.get("pairs", [])
    if not pairs:
        return r.get("state_note") or "No pair pays right now at the size on offer."
    return f"{len(pairs)} pair(s) pay after both venues' fees, locked only if both bets are accepted and stand."


_SENTENCES = {"players": _s_players, "goal": _s_goal, "board": _s_board, "devig": _s_devig,
              "parlay": _s_parlay, "kelly": _s_kelly, "welcome": _s_welcome, "performance": _s_performance, "live_prices": _s_live}


def when(epoch) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
