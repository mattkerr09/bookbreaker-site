"""nflverse's public files, downloaded only when the person asks.

NFL player projections (`playerproj.py`) rest on two public data sets that the
nflverse project publishes as release assets on GitHub:

    player weekly stats   https://github.com/nflverse/nflverse-data/releases/download/stats_player/stats_player_week_{season}.csv
    schedules and games   https://github.com/nflverse/nflverse-data/releases/download/schedules/games.csv

(both read 2026-10-09; the games file carries each game's `spread_line` and
`total_line`, which is how a projection knows what the team is expected to
score). Nothing else is read from anywhere.

**Only on a press.** Nothing here runs unless `players --update` was asked for,
and the window asks only when the person presses Download. A query that finds no
data says so and what the download is; it does not start one. The files are
public and need no key; the only thing GitHub sees is this Mac's internet
address and which files were asked for.

**Every file is dated.** The manifest beside the files records, for each one, the
source address, the file's own date (the `Last-Modified` GitHub serves it with),
the moment it was downloaded, its size and a SHA-256, and `players --status`
prints them. A projection from last week's file says so.

**Only GitHub.** The address is built here and checked: it must be on github.com,
and the one redirect GitHub makes (to its release-asset host) is followed only to
a GitHub-owned host. A file that does not look like the CSV it should be (an HTML
error page, a rate-limit notice) is refused and the old file is kept.

**About 50 MB.** Six seasons of player stats (2021 to now) is the warm-up the
projections need; older seasons are read once and kept. Re-running an update
fetches only the current season's file and the games file again.

The fetch is a parameter (`get`), so every one of these is tested against recorded
bytes with no network.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

from .ledger import home

RELEASE = "https://github.com/nflverse/nflverse-data/releases/download"
PLAYER_URL = RELEASE + "/stats_player/stats_player_week_{season}.csv"
GAMES_URL = RELEASE + "/schedules/games.csv"

#: The first season downloaded. The projection state needs about a season to warm
#: up before the 2022 on seasons it is judged on; earlier seasons were used only
#: to tune the shipped settings (`data/nfl_tuned.json`) and are not downloaded.
FIRST_SEASON = 2021

#: What the whole download weighs, said before it starts. Player files run
#: 7.8 to 8.7 MB a season (read 2026-10-09 from the files' own Content-Length), the
#: games file 2.2 MB, so this is an upper estimate for a season or two on.
ESTIMATE_MB = 55

#: Hosts a download may be served from. github.com answers with a redirect to
#: its release-asset host; both are GitHub's.
_HOSTS = ("github.com", "githubusercontent.com")

#: Columns a file must carry to be the file it claims to be.
PLAYER_COLUMNS = ("player_id", "season", "week", "team", "opponent_team", "position")
GAMES_COLUMNS = ("game_id", "season", "week", "home_team", "away_team", "spread_line", "total_line")

TIMEOUT = 120


class NflverseError(RuntimeError):
    """The data could not be downloaded or read. A sentence for a person."""


class NotFound(NflverseError):
    """GitHub has no such file (a season that has not started)."""


def cache_dir() -> Path:
    return home() / "nfl"


def manifest_path() -> Path:
    return cache_dir() / "manifest.json"


def _allowed(url: str) -> bool:
    parts = urlparse(url)
    host = (parts.hostname or "").lower()
    return parts.scheme == "https" and any(host == h or host.endswith("." + h) for h in _HOSTS)


class _GitHubOnly(HTTPRedirectHandler):
    """Follow a redirect only to a GitHub-owned host."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not _allowed(newurl):
            raise NflverseError("GitHub sent Bookbreaker somewhere other than GitHub, so the download was stopped.")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def urllib_get(url: str):
    """`url -> (bytes, headers)`, the only code here that opens a socket."""
    if not _allowed(url):
        raise NflverseError("Bookbreaker only downloads from GitHub.")
    request = Request(url, headers={"User-Agent": "bookbreaker"})
    try:
        with build_opener(_GitHubOnly).open(request, timeout=TIMEOUT) as response:
            return response.read(), dict(response.headers.items())
    except HTTPError as exc:
        if exc.code == 404:
            raise NotFound("that file is not published yet") from None
        raise NflverseError(f"GitHub answered {exc.code}. Try again in a few minutes.") from None
    except (URLError, OSError, ValueError):
        raise NflverseError("Bookbreaker could not reach GitHub. Check your internet connection and try again.") from None


# ------------------------------------------------------------ the manifest

def read_manifest(folder: Path | None = None) -> dict:
    path = (folder or cache_dir()) / "manifest.json"
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, dict) and isinstance(data.get("files"), dict) else {"files": {}}
    except (OSError, ValueError):
        return {"files": {}}


def _write_manifest(folder: Path, manifest: dict) -> None:
    tmp = folder / "manifest.json.tmp"
    tmp.write_text(json.dumps(manifest, indent=1, sort_keys=True))
    os.replace(tmp, folder / "manifest.json")


def _header_ok(data: bytes, needed) -> bool:
    try:
        head = data[:20000].decode("utf-8", "replace").splitlines()[0]
        cols = next(csv.reader([head]))
    except (IndexError, StopIteration, csv.Error):
        return False
    return all(c in cols for c in needed)


@dataclass
class UpdateReport:
    fetched: list = field(default_factory=list)       # file names downloaded now
    kept: list = field(default_factory=list)          # older seasons already on disk
    bytes: int = 0
    current_season: int | None = None
    errors: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return {"fetched": self.fetched, "kept": self.kept, "bytes": self.bytes,
                "megabytes": round(self.bytes / 1e6, 1), "current_season": self.current_season,
                "errors": self.errors}


def _store(folder: Path, name: str, url: str, data: bytes, headers: dict, now: float, manifest: dict) -> None:
    lower = {str(k).lower(): v for k, v in headers.items()}
    tmp = folder / (name + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, folder / name)
    manifest["files"][name] = {
        "url": url, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
        "file_date": lower.get("last-modified"), "etag": lower.get("etag"),
        "downloaded_at": now,
    }
    # Written after every file, so a connection that drops on the fifth does not lose the four that arrived.
    _write_manifest(folder, manifest)


def update(get=None, *, today=None, now: float | None = None, folder: Path | None = None,
           first_season: int = FIRST_SEASON, force: bool = False) -> UpdateReport:
    """Download what is missing or has moved on. `get(url) -> (bytes, headers)`.

    The games file and the current season's stats are always fetched again; an
    earlier season is fetched once and kept. The current season is the newest one
    GitHub has a file for: this year's, or last year's before the new one starts.
    """
    get = get or urllib_get
    now = time.time() if now is None else now
    folder = folder or cache_dir()
    folder.mkdir(parents=True, exist_ok=True)
    os.chmod(folder, 0o700)
    year = today.year if today is not None else time.gmtime(now).tm_year
    manifest = read_manifest(folder)
    report = UpdateReport()

    # The newest season that has a file.
    current = None
    for season in (year, year - 1):
        name = f"stats_player_week_{season}.csv"
        url = PLAYER_URL.format(season=season)
        try:
            data, headers = get(url)
        except NotFound:
            continue
        if not _header_ok(data, PLAYER_COLUMNS):
            raise NflverseError(f"The {season} player file did not look like nflverse's CSV, so nothing was changed.")
        _store(folder, name, url, data, headers, now, manifest)
        report.fetched.append(name)
        report.bytes += len(data)
        current = season
        break
    if current is None:
        raise NflverseError("nflverse has no player stats for this season or the last one yet.")
    report.current_season = current

    for season in range(first_season, current):
        name = f"stats_player_week_{season}.csv"
        if not force and name in manifest["files"] and (folder / name).exists():
            report.kept.append(name)
            continue
        url = PLAYER_URL.format(season=season)
        data, headers = get(url)
        if not _header_ok(data, PLAYER_COLUMNS):
            raise NflverseError(f"The {season} player file did not look like nflverse's CSV, so it was not kept.")
        _store(folder, name, url, data, headers, now, manifest)
        report.fetched.append(name)
        report.bytes += len(data)

    data, headers = get(GAMES_URL)
    if not _header_ok(data, GAMES_COLUMNS):
        raise NflverseError("The games file did not look like nflverse's CSV, so it was not kept.")
    _store(folder, "games.csv", GAMES_URL, data, headers, now, manifest)
    report.fetched.append("games.csv")
    report.bytes += len(data)

    manifest["updated_at"] = now
    manifest["current_season"] = current
    manifest["first_season"] = first_season
    _write_manifest(folder, manifest)
    return report


# ------------------------------------------------------------ what is on disk

def have_data(folder: Path | None = None) -> bool:
    folder = folder or cache_dir()
    man = read_manifest(folder)["files"]
    return "games.csv" in man and any(n.startswith("stats_player_week_") for n in man) \
        and all((folder / n).exists() for n in man)


def fingerprint(folder: Path | None = None) -> str:
    """Changes whenever any downloaded file does."""
    files = read_manifest(folder or cache_dir())["files"]
    return hashlib.sha256(json.dumps({n: f.get("sha256") for n, f in sorted(files.items())}).encode()).hexdigest()[:16]


def describe(folder: Path | None = None) -> dict:
    """Where the data came from and how old it is: what `players` shows beside any answer."""
    folder = folder or cache_dir()
    man = read_manifest(folder)
    files = []
    for name, f in sorted(man["files"].items()):
        files.append({"file": name, "url": f.get("url"), "bytes": f.get("bytes"),
                      "file_date": f.get("file_date"), "downloaded_at": f.get("downloaded_at"),
                      "sha256": f.get("sha256")})
    return {"downloaded": have_data(folder), "files": files,
            "downloaded_at": man.get("updated_at"), "current_season": man.get("current_season"),
            "estimate_megabytes": ESTIMATE_MB, "folder": str(folder),
            "sources": {"player_stats": PLAYER_URL, "games": GAMES_URL}}


def _num(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def read_games(folder: Path | None = None) -> list:
    """Every game, with the lines the teams were priced at."""
    folder = folder or cache_dir()
    out = []
    with (folder / "games.csv").open(newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            try:
                out.append({
                    "gid": r["game_id"], "season": int(r["season"]), "week": int(r["week"]),
                    "type": r.get("game_type") or "REG", "day": r.get("gameday") or "",
                    "home": r["home_team"], "away": r["away_team"],
                    "result": None if r.get("result") in (None, "", "NA") else float(r["result"]),
                    "line": None if r.get("spread_line") in (None, "", "NA") else float(r["spread_line"]),
                    "total": None if r.get("total_line") in (None, "", "NA") else float(r["total_line"]),
                })
            except (KeyError, ValueError):
                continue
    out.sort(key=lambda g: (g["season"], g["week"], g["day"], g["gid"]))
    return out


STAT_COLUMNS = ("completions", "attempts", "passing_yards", "passing_tds", "passing_interceptions",
                "carries", "rushing_yards", "receptions", "receiving_yards")


def read_weekly(folder: Path | None = None) -> list:
    """Every player game, oldest first: who, where, against whom, and the stats."""
    folder = folder or cache_dir()
    out = []
    for name in sorted(read_manifest(folder)["files"]):
        if not name.startswith("stats_player_week_"):
            continue
        with (folder / name).open(newline="", encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                try:
                    row = {"pid": r["player_id"],
                           "name": r.get("player_display_name") or r.get("player_name") or r["player_id"],
                           "pos": r.get("position") or "", "season": int(r["season"]), "week": int(r["week"]),
                           "team": r["team"], "opp": r["opponent_team"]}
                    for c in STAT_COLUMNS:
                        row[c] = _num(r.get(c))
                except (KeyError, ValueError):
                    continue
                if row["team"] and row["opp"]:
                    out.append(row)
    out.sort(key=lambda r: (r["season"], r["week"]))
    return out
