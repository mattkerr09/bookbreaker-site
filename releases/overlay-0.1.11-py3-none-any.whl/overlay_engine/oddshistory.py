"""What the live odds looked like at every refresh, kept on this Mac.

A line move needs an earlier price. The Odds API sends the price as it stands, so
the only earlier price this app can have is one it saw itself: each refresh of
live sportsbook odds (`board --feed oddsapi`) is written, as it was read, to
`~/.overlay/oddsapi/history/YYYY-MM-DD.jsonl`, one line per league read, and
`edges.py` measures a move from the first price the app saw.

That first price is not necessarily the opener. If the app first saw a game
on Wednesday, a move on Monday is not in it, and every answer that rests on a
move says "first seen" and when. Nothing here guesses an opening number.

**Same minute, same line.** A refresh answered from the 60-second cache was
recorded when it was fetched, so only freshly fetched leagues are written; the
same league fetched at the same instant is never written twice.

**Kept 30 days, readable by its owner only, deleted with the key.** Games are a
week long at most; a month is more than any rule here needs. `key clear` removes
the odds the key fetched, and this is those odds.

Quotes are stored as the engine reads them (decimal prices, the book's own
`last_update`), not as American prices, so nothing is converted twice.
"""

from __future__ import annotations

import json
import os
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path

from .ledger import home
from .models import Market, Outcome, Quote

KEEP_DAYS = 30
VERSION = 1


def _day(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).strftime("%Y-%m-%d")


def _private(path: Path) -> None:
    try:
        os.chmod(path, 0o700 if path.is_dir() else 0o600)
    except OSError:
        pass


def record(refresh, folder: Path) -> int:
    """Write what this refresh freshly fetched. Returns the number of lines written.

    Never raises: a history that cannot be written costs the moves measured from
    it, and must not cost the person the board they asked for.
    """
    written = 0
    try:
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        _private(folder.parent)
        _private(folder)
        for read in refresh.reads:
            if read.from_cache:
                continue
            league = read.league
            events = {}
            markets = []
            for m in refresh.markets:
                if m.sport != league.key:
                    continue
                info = refresh.event_info.get(str(m.event_id), {})
                events[str(m.event_id)] = {"label": info.get("label", ""), "starts": info.get("starts")}
                markets.append({
                    "event": str(m.event_id), "type": m.market_type, "starts": m.starts_at,
                    "q": [[q.book, q.outcome.name, q.outcome.line, round(q.decimal, 4), q.seen_at]
                          for q in m.quotes]})
            if not markets:
                continue
            path = folder / f"{_day(read.fetched_at)}.jsonl"
            tag = [league.key, read.fetched_at]
            if path.exists():
                try:
                    tail = path.read_text().splitlines()[-6:]
                    if any([json.loads(x).get("league"), json.loads(x).get("fetched_at")] == tag for x in tail if x):
                        continue
                except (OSError, ValueError):
                    pass
            line = json.dumps({"v": VERSION, "league": league.key, "alias": league.alias,
                               "fetched_at": read.fetched_at, "events": events, "markets": markets},
                              separators=(",", ":"))
            with path.open("a") as fh:
                fh.write(line + "\n")
            _private(path)
            written += 1
        _prune(folder, refresh.now or time.time())
    except OSError:
        pass
    return written


def _prune(folder: Path, now: float) -> None:
    cutoff = _day(now - KEEP_DAYS * 86400)
    for f in folder.glob("*.jsonl"):
        if f.stem < cutoff:
            try:
                f.unlink()
            except OSError:
                pass


def snapshots(folder: Path, since: float | None = None) -> list:
    """Every recorded league read, oldest first."""
    out = []
    try:
        files = sorted(Path(folder).glob("*.jsonl"))
    except OSError:
        return out
    for f in files:
        try:
            lines = f.read_text().splitlines()
        except OSError:
            continue
        for x in lines:
            try:
                snap = json.loads(x)
            except ValueError:
                continue
            if snap.get("v") != VERSION or "markets" not in snap:
                continue
            if since is not None and snap["fetched_at"] < since:
                continue
            out.append(snap)
    out.sort(key=lambda s: s["fetched_at"])
    return out


def to_markets(snap: dict) -> list:
    """The engine's own Market objects for one recorded league read."""
    out = []
    for m in snap["markets"]:
        quotes = [Quote(book=b, outcome=Outcome(name=n, line=None if line is None else float(line)),
                        decimal=float(d), seen_at=float(s), fetched_at=snap["fetched_at"])
                  for b, n, line, d, s in m["q"]]
        out.append(Market(event_id=m["event"], sport=snap["league"], market_type=m["type"],
                          quotes=quotes, starts_at=m.get("starts")))
    return out


def clear(folder: Path) -> int:
    n = 0
    try:
        for f in Path(folder).glob("*.jsonl"):
            f.unlink()
            n += 1
        shutil.rmtree(folder, ignore_errors=True)
    except OSError:
        pass
    return n


def latest(folder: Path, now: float | None = None, max_age: float | None = None) -> list:
    """The newest recorded read of each league, optionally no older than `max_age` seconds."""
    now = time.time() if now is None else now
    newest = {}
    for s in snapshots(folder):
        newest[s["league"]] = s
    out = [s for s in newest.values() if max_age is None or now - s["fetched_at"] <= max_age]
    out.sort(key=lambda s: s["alias"])
    return out


def history_folder() -> Path:
    """Where each refresh of live sportsbook odds is recorded."""
    return home() / "oddsapi" / "history"
