"""The My bets dashboard: a sentence, actual against expected profit, profit by book and
by market, and a month calendar of daily profit.

Every figure on the page is made here, from the ledger, and the window prints them. The
window does no arithmetic, so the length of a bar, the tone of a calendar day, which month
comes before which and the sentence at the top are all fields of this payload.

**Expected profit is only for bets that were priced.** A bet carries a fair price when the
engine priced it at the time (`Ledger.record_bet`). A bet read in from a book's export or a
pasted slip has none: its row holds the break-even price as a stand-in, with the source
`import`, and comparing a result against that is comparing it against nothing. So expected
profit is worked out only over the bets that have a real fair price, the sentence says how
many of the settled bets that is, and with none it says there is nothing to compare. Pushes
and refunds are left out of both sides of the comparison, because the fair price is the
chance of winning and says nothing about the chance of a push.

**A gap is not a finding.** The spread a record this size could show by luck is worked out
from the same fair prices (a bet that wins with chance p and pays d has a variance of
(stake x d)^2 p (1 - p)) and the verdict says whether the gap sits inside it. Below thirty
compared bets it declines, the floor the rest of the record uses.

**Live and upcoming need a start time, and the ledger has none.** A bet knows its event's
id, not when the event starts. Where the recorded reads of live odds on this Mac name the
event, its start time is used; where they do not, the bet is "waiting for a result", and
nothing is guessed. A game that started more than `LIVE_HOURS` ago and is still unsettled is
waiting for a result, not live.
"""

from __future__ import annotations

import calendar
import math
from datetime import datetime

from .performance import MIN_BETS, Z

#: A started game counts as live for this long. After that it is over and the bet is
#: waiting for someone to settle it.
LIVE_HOURS = 6.0

#: The calendar covers at most this many months, newest last.
MAX_MONTHS = 24

MARKET_WORDS = {"h2h": "Moneyline", "spreads": "Spread", "totals": "Total"}


# ------------------------------------------------------------ words

def money(x: float) -> str:
    """$1,234.50, without a sign."""
    return f"${abs(x):,.2f}"


def _signed(x: float) -> str:
    return ("-" if x < 0 else "+" if x > 0 else "") + money(x)


def short_money(x: float) -> str:
    """+$12, -$4.50, +$1.2k: the amount as a calendar cell can hold it."""
    sign = "-" if x < 0 else "+" if x > 0 else ""
    a = abs(x)
    if a >= 10000:
        return f"{sign}${a / 1000:.0f}k"
    if a >= 1000:
        return f"{sign}${a / 1000:.1f}k"
    if round(a, 2) == round(a):
        return f"{sign}${a:.0f}"
    return f"{sign}${a:.2f}"


def market_label(key: str) -> str:
    if key in MARKET_WORDS:
        return MARKET_WORDS[key]
    text = str(key).replace("_", " ").strip()
    return text[:1].upper() + text[1:] if text else "Other"


def book_label(key: str) -> str:
    """The name a person knows the book by, where the engine knows it."""
    try:
        from .oddsapi import books_table
        book = books_table().get(key)
        if book is not None and book.name:
            return book.name
    except Exception:            # a name is cosmetic; never the reason a record does not draw
        pass
    text = str(key).replace("_", " ").strip()
    return text[:1].upper() + text[1:] if text else "Other"


# ------------------------------------------------------------ the sentence

def _matches(bet: dict, filters: dict) -> bool:
    for field, key in (("sport", "sport"), ("market_type", "market_type"), ("book", "book")):
        if filters.get(field) and bet.get(key) != filters[field]:
            return False
    if filters.get("min_decimal") and bet["decimal_odds"] < filters["min_decimal"]:
        return False
    if filters.get("max_decimal") and bet["decimal_odds"] > filters["max_decimal"]:
        return False
    return True


def starts_by_event(folder, event_ids) -> dict:
    """When each event starts, from the recorded reads of live odds on this Mac.

    Only the events asked about, and only where a read named a start time. Empty when
    nothing has been read."""
    wanted = {str(e) for e in event_ids}
    found: dict = {}
    if not wanted:
        return found
    try:
        from . import oddshistory
        from .oddsapi import parse_time
        for snap in oddshistory.snapshots(folder):
            for event, info in (snap.get("events") or {}).items():
                if event in wanted and info.get("starts") is not None:
                    try:
                        raw = info["starts"]
                        found[event] = float(raw) if isinstance(raw, (int, float)) else float(parse_time(raw))
                    except (TypeError, ValueError):
                        continue
    except Exception:            # a missing history is the usual case, not a failure
        return found
    return found


def counts(open_bets: list, settled: list, starts: dict, now: float) -> dict:
    live = upcoming = waiting = 0
    for bet in open_bets:
        start = starts.get(str(bet["event_id"]))
        if start is None:
            waiting += 1
        elif start > now:
            upcoming += 1
        elif now - start <= LIVE_HOURS * 3600:
            live += 1
        else:
            waiting += 1
    profit = sum(b["profit"] or 0.0 for b in settled if b.get("result") != "void")
    return {"live": live, "upcoming": upcoming, "waiting": waiting, "settled": len(settled),
            "profit": round(profit, 2)}


def sentence(c: dict) -> str:
    parts = [f"{c['live']} live", f"{c['upcoming']} upcoming"]
    if c["waiting"]:
        parts.append(f"{c['waiting']} waiting for a result")
    parts.append(f"{c['settled']} settled")
    last = c["settled"]
    noun = "bet" if last == 1 else "bets"
    have = ", ".join(parts[:-1]) + f" and {parts[-1]} {noun}"
    p = round(c["profit"], 2)
    if p > 0:
        outcome = f"you are up {money(p)}"
    elif p < 0:
        outcome = f"you are down {money(p)}"
    else:
        outcome = "you are even"
    return f"You have {have}, and {outcome}."


# ------------------------------------------------------------ actual against expected

def _priced(bet: dict) -> bool:
    """Whether the engine priced this bet when it was placed."""
    return bet.get("source") != "import" and bet.get("devig_json") not in (None, "", "{}")


def actual_vs_expected(settled: list) -> dict:
    """What the bets that were priced made, against what their fair prices expected."""
    decided = [b for b in settled if b.get("result") in ("won", "lost")
               or (b.get("result") in (None, "") and (b["profit"] or 0.0) != 0.0)]
    counted = [b for b in settled if b.get("result") != "void"]
    priced = [b for b in decided if _priced(b)]
    base = {"settled": len(counted), "priced": len(priced)}
    if not priced:
        return {**base, "available": False,
                "text": ("None of your settled bets has a fair price saved with it, so there is no expected profit "
                         "to set the result against. Bets read in from a book's export or a pasted slip carry only "
                         "the price you got.") if counted else
                        "No settled bets yet, so there is nothing to set against what was expected."}
    actual = sum(b["profit"] or 0.0 for b in priced)
    expected = low = high = variance = 0.0
    for b in priced:
        d, stake = b["decimal_odds"], b["stake"]
        expected += stake * (b["fair_prob"] * d - 1.0)
        low += stake * (b["fair_low"] * d - 1.0)
        high += stake * (b["fair_high"] * d - 1.0)
        variance += (stake * d) ** 2 * b["fair_prob"] * (1.0 - b["fair_prob"])
    swing = Z * math.sqrt(variance)
    gap = actual - expected
    n = len(priced)
    have = (f"{n} of your {len(counted)} settled bets had a fair price saved with them"
            if n != len(counted) else f"All {n} of your settled bets had a fair price saved with them")
    text = (f"{have}. On those, you made {_signed(actual)} where the fair prices expected {_signed(expected)} "
            f"(between {_signed(low)} and {_signed(high)}).")
    if n < MIN_BETS:
        verdict = (f"With {n} bets compared (the least that says anything is {MIN_BETS}), the gap is luck as far as "
                   "anyone can tell.")
    elif abs(gap) <= swing:
        verdict = (f"Luck alone moves a record this size by about {money(swing)} up or down, so a gap of "
                   f"{money(gap)} {'above' if gap > 0 else 'below'} what was expected is inside the normal swing.")
    else:
        verdict = (f"Luck alone moves a record this size by about {money(swing)} up or down, and this is "
                   f"{money(gap)} {'above' if gap > 0 else 'below'} what was expected: outside the normal swing.")
    return {**base, "available": True, "actual": round(actual, 2), "expected": round(expected, 2),
            "low": round(low, 2), "high": round(high, 2), "gap": round(gap, 2), "swing": round(swing, 2),
            "enough": n >= MIN_BETS, "text": text, "verdict": verdict,
            "note": "Pushes and refunds are left out of both numbers."}


# ------------------------------------------------------------ profit by book and by market

def bars(slices: list, label) -> list:
    """One bar per slice, longest at 1. `scale` is the engine's, so the window never measures a bar."""
    top = max((abs(s.profit) for s in slices), default=0.0)
    return [{"key": s.label, "label": label(s.label), "n": s.n, "won": s.won, "lost": s.lost,
             "profit": round(s.profit, 2), "turnover": round(s.turnover, 2),
             "roi": (s.profit / s.turnover) if s.turnover else 0.0,
             "scale": round(abs(s.profit) / top, 3) if top else 0.0,
             "tone": "pos" if s.profit > 0 else "neg" if s.profit < 0 else "flat"}
            for s in slices]


# ------------------------------------------------------------ the month calendar

def _when(bet: dict, tz) -> datetime:
    stamp = bet.get("settled_at") or bet["placed_at"]
    return datetime.fromtimestamp(float(stamp), tz)


def _month_id(year: int, month: int) -> str:
    return f"{year:04d}-{month:02d}"


def _step(year: int, month: int, by: int) -> tuple:
    index = year * 12 + (month - 1) + by
    return index // 12, index % 12 + 1


def calendar_months(settled: list, tz=None, months: int = MAX_MONTHS) -> dict:
    """Daily profit, a grid per month, Sunday first, from the first month with a settled bet to the last.

    A day is the local day the bet settled (the day it was placed, where no settle time was kept).
    Voids are not bets and are not on it."""
    live = [b for b in settled if b.get("result") != "void"]
    if not live:
        return {"shown": None, "months": []}
    days: dict = {}
    for b in live:
        d = _when(b, tz)
        cell = days.setdefault((d.year, d.month, d.day), [0.0, 0])
        cell[0] += b["profit"] or 0.0
        cell[1] += 1
    first = min(days)[:2]
    last = max(days)[:2]
    span = []
    y, m = first
    while (y, m) <= last:
        span.append((y, m))
        y, m = _step(y, m, 1)
    span = span[-months:]
    cal = calendar.Calendar(firstweekday=6)
    out = []
    for i, (y, m) in enumerate(span):
        scale_top = max((abs(v[0]) for k, v in days.items() if k[:2] == (y, m)), default=0.0)
        weeks = []
        for week in cal.monthdatescalendar(y, m):
            row = []
            for day in week:
                if day.month != m:
                    row.append(None)
                    continue
                got = days.get((y, m, day.day))
                if got is None:
                    row.append({"day": day.day, "n": 0, "profit": None, "short": "", "tone": "none", "scale": 0.0})
                    continue
                profit = round(got[0], 2)
                row.append({"day": day.day, "n": got[1], "profit": profit, "short": short_money(profit),
                            "tone": "pos" if profit > 0 else "neg" if profit < 0 else "flat",
                            "scale": round(abs(profit) / scale_top, 3) if scale_top else 0.0})
            weeks.append(row)
        total = sum(v[0] for k, v in days.items() if k[:2] == (y, m))
        n = sum(v[1] for k, v in days.items() if k[:2] == (y, m))
        out.append({"id": _month_id(y, m), "label": f"{calendar.month_name[m]} {y}",
                    "profit": round(total, 2), "bets": n,
                    "prev": _month_id(*span[i - 1]) if i > 0 else None,
                    "next": _month_id(*span[i + 1]) if i + 1 < len(span) else None,
                    "weeks": weeks})
    return {"weekdays": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], "shown": out[-1]["id"], "months": out,
            "note": "Each day is the day the bet settled, on this Mac's clock."}


# ------------------------------------------------------------ the whole dashboard

def dashboard(ledger, rep, filters: dict, now: float, history_folder=None, tz=None) -> dict:
    """The My bets dashboard for the ledger as filtered. `rep` is the `performance.Performance`
    already worked out for the same bets, so a figure here and the same figure there cannot differ."""
    settled = ledger.settled_bets(**filters)
    open_bets = [b for b in ledger.open_positions() if _matches(b, filters)]
    starts = starts_by_event(history_folder, [b["event_id"] for b in open_bets]) if (
        history_folder is not None and open_bets) else {}
    c = counts(open_bets, settled, starts, now)
    return {
        "summary": {**c, "text": sentence(c), "empty": not (settled or open_bets)},
        "expected": actual_vs_expected(settled),
        "by_book": bars(rep.by_book, book_label),
        "by_market": bars(rep.by_market, market_label),
        "calendar": calendar_months(settled, tz),
    }


__all__ = ["dashboard", "sentence", "counts", "actual_vs_expected", "calendar_months", "bars", "LIVE_HOURS"]
