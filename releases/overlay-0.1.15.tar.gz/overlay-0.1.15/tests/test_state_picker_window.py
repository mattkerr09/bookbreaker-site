"""One state picker, in the top bar, that every page reads.

The window used to keep a state on the Promos page alone, and the live pairs and
Ask borrowed it from there: a person on Arbitrage who wanted to change where they
bet had to leave the page, and nothing on screen said which state a board had
been checked for. AVO and OddsJam put the state in the top bar and let it drive
every tool. This window does the same, and holds three things a screenshot
cannot show:

  * there is exactly one picker, it is in the bar every page shares, and it is
    kept in this window's storage on this Mac and nowhere else;
  * every page that depends on a state reads that one: Promos, Live prices and
    Ask (the deposit plan has no page here yet, and the day it gets one this
    file fails until it reads the picker too);
  * changing it re-draws from what is already on this Mac. It reads no prices.
    A live board that was checked for another state is taken down, because a
    pair that was never checked for this state is exactly the thing the state
    gate exists to keep off the screen.
"""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()
RUST = (UI / "src-tauri" / "src" / "main.rs").read_text()


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


TOP = HTML[HTML.index('<header class="top">'):HTML.index("</header>")]
CHANGED = _braced(JS, "function stateChanged()")


# ================================================================ one picker, in the top bar

def test_there_is_one_picker_and_it_is_in_the_top_bar():
    assert HTML.count('id="w-state"') == 1 and TOP.count('id="w-state"') == 1
    assert 'class="fld statepick"' in TOP and "Your state" in TOP
    promos = HTML[HTML.index('id="panel-welcome"'):HTML.index('id="panel-convert"')]
    assert "w-state" not in promos and "<select" not in promos, "Promos has no picker of its own any more"
    assert HTML.count("<select id=\"w-state\"") == 1


def test_the_picker_lists_every_state_and_starts_on_none():
    options = re.findall(r'<option value="([A-Z]{0,2})">([^<]*)</option>', TOP[TOP.index('id="w-state"'):])
    assert options[0] == ("", "Pick your state"), "no state is chosen until the person chooses one"
    states = [v for v, _ in options if v]
    assert len(set(states)) == 51 == len(states), "the 50 states and DC, once each"
    assert "DC" in states


def test_the_picker_is_styled_and_still_fits_a_narrow_window():
    assert re.search(r"\.top \.statepick\{[^}]*margin-left:auto", CSS), "it sits at the right of the bar"
    assert re.search(r"\.statepick select\{", CSS)
    narrow = CSS[CSS.index("@media (max-width:900px){\n  .statepick-l"):]
    assert "position:absolute" in narrow[:200], "below 900px the label is hidden and the select stays"


# ================================================================ kept on this Mac, sent nowhere

def test_the_state_is_kept_in_this_windows_storage_under_one_key_and_nowhere_else():
    assert JS.count('store.set("bb.state"') == 1 and JS.count('store.get("bb.state"') == 1
    assert 'store.set("bb.state", val("w-state"));' in CHANGED
    assert "sessionStorage" not in JS and "document.cookie" not in JS and "indexedDB" not in JS


def test_the_state_is_never_in_a_url_a_log_a_message_or_a_request_of_the_windows_own():
    for line in JS.splitlines():
        if "w-state" in line or "currentState" in line:
            assert not re.search(r"\b(fetch|XMLHttpRequest|sendBeacon|location\.|history\.)\b|https?://|console\.", line), line
    assert not re.search(r'invoke\("open_[a-z_]+",[^)]*w-state', JS)
    # The state goes to the engine, a program on this Mac, as an argument, is shown back to the person, and is
    # stored under the one key. Those are the only places it is read: every line that reads it is one of these.
    reads = [l.strip() for l in JS.splitlines() if 'val("w-state")' in l and not l.strip().startswith("*")]
    assert len(reads) == 9, reads
    allowed = (r'if \(kind === "welcome" && !val\("w-state"\)\) \{',                      # Promos asks for one
               r'\.\.\.\(val\("w-state"\) && !OFFERS_IGNORE_STATE \? \["--state", val\("w-state"\)\] : \[\]\)\],',
               r'\.\.\.\(liveOn\(\) && val\("w-state"\) \? \["--state", val\("w-state"\)\] : \[\]\)\],',
               r'const now = val\("w-state"\);',                                       # the two lines that say it
               r'store\.set\("bb\.state", val\("w-state"\)\);',
               r'\? ` This build cannot sort offers by state yet.*\$\{esc\(val\("w-state"\)\)\}\.`',
               r': ` Showing offers for \$\{esc\(val\("w-state"\)\)\}\.`;',
               r'ask: \(\) => \["ask", "--stdin", "--model", askModel\(\), \.\.\.\(val\("w-state"\) \? \["--state", val\("w-state"\)\] : \[\]\),')
    for line in reads:
        assert any(re.fullmatch(a, line) for a in allowed), f"the state is read somewhere new: {line}"


# ================================================================ every page reads it

def test_promos_read_the_state_in_the_top_bar():
    assert 'if (kind === "welcome" && !val("w-state"))' in JS, "with none chosen, Promos asks for one"
    assert re.search(r'welcome: \(\) => \["welcome",[^\]]*\.\.\.\(val\("w-state"\) && !OFFERS_IGNORE_STATE \? \["--state", val\("w-state"\)\]', JS, re.S)
    assert "in the bar at the top" in JS[JS.index("const PICK_STATE"):JS.index("const PICK_STATE") + 300]


def test_live_pairs_read_it_only_while_the_live_switch_is_on():
    board = re.search(r"\n    board: \(\) => \[(.*?)\],\n    results:", JS, re.S).group(1)
    assert '...(liveOn() && val("w-state") ? ["--state", val("w-state")] : [])' in board


def test_ask_reads_it_and_says_which_state_it_is_using():
    assert '...(val("w-state") ? ["--state", val("w-state")] : [])' in JS[JS.index("  ask: () =>"):JS.index("  askkeystatus:")]
    hint = _braced(JS, "function drawStateHints()")
    assert "Ask uses your state" in hint and "It stays on this Mac" in hint and "Ask has no state yet" in hint
    assert 'id="ask-state"' in HTML[HTML.index('id="panel-ask"'):HTML.index('id="panel-board"')]
    assert "drawStateHints();" in CHANGED, "the line under Ask follows the picker"


def test_the_board_points_at_the_picker_and_not_at_a_page():
    needs = JS[JS.index("if (xv.needs_state)"):JS.index("if (!xv.read_anything)")]
    assert 'data-focus="w-state"' in needs and 'data-panel="welcome"' not in needs
    assert 'ev.target.closest("[data-focus]")' in JS and "target.focus()" in JS


def test_the_deposit_plan_has_no_page_here_and_will_read_the_picker_the_day_it_does():
    """`deposit` is an engine command (deposit.py) with no page in this window. When one is added it must take
    the state from the one picker; this fails until it does, instead of a third place keeping a state."""
    allowed = set(re.search(r'const ALLOWED: \[&str; \d+\] = \[([^\]]+)\]', RUST).group(1).replace('"', "").replace(" ", "").split(","))
    if "deposit" in allowed:
        builder = re.search(r'\n\s+deposit: \(\) => \[(.*?)\],', JS, re.S)
        assert builder and 'val("w-state")' in builder.group(1), "the deposit page must read the one state picker"
        assert HTML.count('id="w-state"') == 1
    else:
        assert 'id="panel-deposit"' not in HTML


# ================================================================ changing it reads nothing

def test_changing_it_runs_only_the_local_offers_list_and_takes_down_a_stale_live_board():
    assert 'sel.addEventListener("change", stateChanged);' in JS
    assert 'run("welcome");' in CHANGED
    for other in ('run("board")', 'run("oddsboard")', 'run("screen")', 'run("oddsestimate")', 'run("keystatus")',
                  "invoke(", "fetch(", "await"):
        assert other not in CHANGED, other
    assert 'if (liveOn()) primed.delete("board");' in CHANGED, "the next time Arbitrage is opened it reads, as for any person asking"
    assert "if (BOARD && BOARD.live && BOARD.xv) {" in CHANGED, "a board checked for another state is not left up"
    assert "BOARD = null;" in CHANGED and "PLAYS = [];" in CHANGED


def test_a_board_taken_down_for_a_new_state_says_what_happened_and_reads_nothing():
    said = _braced(JS, "function liveBoardForNewState()")
    assert "were checked for" in said and "BOARD.xv.state" in said
    assert "Pairs are read when you press, never" in said and 'data-run="board"' in said
    assert "invoke(" not in said and "run(" not in said


def test_the_demo_and_the_sportsbook_board_do_not_depend_on_the_state_and_are_left_alone():
    assert "BOARD.live && BOARD.xv" in CHANGED, "only a cross-venue board carries a state in its answer"
    assert "xv, preset: xv.preset" in _braced(JS, "function showBoard(")
    assert "xv" not in JS[JS.index("function showOddsboard("):JS.index("// The line above the board")]


def test_no_page_asks_for_a_state_in_words_that_point_at_the_old_place():
    for stale in ("the one picked on Promos", "Choose where you bet, above", "The state is the one on the Promos page"):
        assert stale not in HTML and stale not in JS, stale
    assert "the one in the bar at the top" in HTML
