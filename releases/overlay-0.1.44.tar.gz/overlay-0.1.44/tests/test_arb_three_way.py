"""Three-way arbitrage in the window's Arb calculator (the AVO bar's item 16): a third price for a game that can draw
reaches the engine, which already sizes any number of legs, and the answer names every leg."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JS = (ROOT / "ui" / "src" / "app.js").read_text()


def test_the_third_price_is_sent_only_when_there_is_one():
    assert '...(val("arb-c") ? [val("arb-c")] : [])' in JS
    assert 'id="arb-c"' in (ROOT / "ui" / "src" / "index.html").read_text()


def test_the_engine_sizes_three_legs_so_every_result_pays_the_same():
    out = json.loads(subprocess.run([sys.executable, "-m", "overlay_engine.cli", "arb", "2.6", "3.6", "3.4", "--stake",
                                     "100", "--round", "exact", "--json"], cwd=ROOT / "backend", capture_output=True,
                                    text=True, check=True).stdout)
    assert out["arbitrage"] and len(out["legs"]) == 3
    pays = [l["stake"] * d for l, d in zip(out["legs"], (2.6, 3.6, 3.4))]
    assert max(pays) - min(pays) < 0.05


def test_the_answer_names_every_leg_and_says_every_bet_past_two():
    body = JS[JS.index("function showArb"):JS.index("function showArb") + 2500]
    assert "out.legs.map((l, i) => `<b>$${cash(l.stake)}</b> on side ${i + 1}`)" in body
    assert '"every bet is"' in body and '"both bets are"' in body
