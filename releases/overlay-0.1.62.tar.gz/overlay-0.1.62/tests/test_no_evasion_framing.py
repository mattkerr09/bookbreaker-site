"""Round stakes are a convenience, never a way past a sportsbook (CEO decision on audit C13, 2026-11-04). No
user-facing text, and no engine docstring that ships in the source download, says stakes "look human", that books
"spot software", that anything hides from a "risk desk", or how a book reads or flags a bet."""
import re
from pathlib import Path

from overlay_engine import welcome

ROOT = Path(__file__).resolve().parents[1]
PHRASES = re.compile(r"look(s|ed|ing)? human|human-looking|spot(s|ting)? software|risk desk|risk team|fly under|"
                     r"avoid detection|under the radar|edge to hide|like a bot|fingerprint risk", re.I)
FILES = ["ui/src/app.js", "ui/src/index.html", "ui/src/whatsnew.js", "README.md",
         *[str(p.relative_to(ROOT)) for p in (ROOT / "backend" / "overlay_engine").rglob("*.py")]]


def test_no_shipped_text_frames_round_stakes_as_evasion():
    hits = [(name, m.group(0)) for name in FILES
            for m in PHRASES.finditer((ROOT / name).read_text())]
    assert not hits, hits


def test_the_promos_advice_is_about_terms_not_hiding():
    assert "nothing here gets around that" in welcome.KEEP_THE_ACCOUNT
    assert not re.search(r"ordinary bets|bets an hour|minutes after", welcome.KEEP_THE_ACCOUNT)
