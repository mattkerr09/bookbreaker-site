"""Nothing in the engine changes a stake or the timing of a bet to make an account last longer (CEO decision,
2026-11-04: never help anyone hide from a sportsbook's risk desk). Rounding to an amount a bet slip takes is a
convenience and stays; choosing an amount for how it looks, delays, spacing, edge floors raised for a "hot" account,
deferrals and per-hour caps at a book are gone, and this fails if any of them returns."""
import importlib.util
import re
from pathlib import Path

import pytest

from overlay_engine import welcome

ENGINE = Path(__file__).resolve().parents[1] / "backend" / "overlay_engine"
SHAPING = re.compile(r"\bcooldown\b|bets_last_hour|HEAT_BUDGET|def shape\(|class Shaping|account_heat|"
                     r"stake_precision_heat|reaction_heat|velocity_heat|market_heat|delay before bet|"
                     r"stay under|hot account|anti-limit", re.I)


def test_there_is_no_heat_model():
    assert importlib.util.find_spec("overlay_engine.heat") is None


def test_no_engine_source_shapes_stakes_or_timing_for_longevity():
    hits = [(p.name, m.group(0)) for p in ENGINE.rglob("*.py") for m in SHAPING.finditer(p.read_text())]
    assert not hits, hits


@pytest.mark.parametrize("amount,free,hedge", [(200.0, 4.0, 1.2857), (100.0, 3.5, 1.4), (500.0, 6.0, 1.18),
                                               (75.0, 2.6, 1.6), (1000.0, 2.2, 1.9)])
def test_a_hedge_is_rounded_to_the_round_amount_that_keeps_the_most(amount, free, hedge):
    """Plain rounding: among the multiples of five near the exact hedge, the one with the best worst case. Never the
    one that 'looks' least computed."""
    stake, floor = welcome.round_hedge(amount, free, hedge)
    exact = amount * (free - 1.0) / hedge

    def worst(h):
        return min(amount * (free - 1.0) - h, h * (hedge - 1.0))

    candidates = [5.0 * k for k in range(max(1, int(exact * 0.9 / 5)), int(exact * 1.1 / 5) + 2)]
    assert stake % 5 == 0 and floor == pytest.approx(worst(stake))
    assert worst(stake) == pytest.approx(max(worst(h) for h in candidates))
