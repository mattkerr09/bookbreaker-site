"""Fill probability: how likely a price is still there when you bet it."""

import pytest

from overlay_engine.models import Book, BookTier
from overlay_engine.staleness import (
    PRIOR_TAU,
    FillModel,
    Observation,
    market_class,
)

DK = Book(key="dk", name="DraftKings", tier=BookTier.RETAIL)
PIN = Book(key="pinnacle", name="Pinnacle", tier=BookTier.SHARP, limits_winners=False)
KALSHI = Book(key="kalshi", name="Kalshi", tier=BookTier.EXCHANGE, limits_winners=False)
BOOKS = {b.key: b for b in (DK, PIN, KALSHI)}


@pytest.mark.parametrize(
    "market_type,expected",
    [
        ("h2h", "moneyline"),
        ("spreads", "spread"),
        ("totals", "total"),
        ("player_points", "player_prop"),
        ("alternate_spreads", "alt_line"),
        ("live_h2h", "live"),
        ("outrights", "futures"),
        ("something_else", "default"),
    ],
)
def test_market_class_buckets(market_type, expected):
    assert market_class(market_type) == expected


def test_fill_starts_at_the_prior():
    model = FillModel()
    assert model.tau("dk", "h2h") == PRIOR_TAU["moneyline"]
    assert not model.is_fitted("dk", "h2h")


def test_live_markets_are_priced_as_faster_than_pregame():
    model = FillModel()
    assert model.p_fill("dk", "live_h2h", 20.0) < model.p_fill("dk", "h2h", 20.0)


def test_fill_decays_with_age():
    model = FillModel()
    fresh = model.p_fill("dk", "h2h", 1.0)
    stale = model.p_fill("dk", "h2h", 120.0)
    assert 0.0 < stale < fresh <= 1.0


def test_a_zero_age_quote_is_certain():
    assert FillModel().p_fill("dk", "h2h", 0.0) == 1.0


def test_fill_has_a_floor_so_stale_and_unknown_stay_distinguishable():
    assert FillModel().p_fill("dk", "live_h2h", 10_000.0) == pytest.approx(0.01)


def test_rejections_shorten_the_estimated_lifetime():
    model = FillModel()
    before = model.tau("dk", "h2h")
    for _ in range(40):
        model.observe(Observation(book="dk", market="h2h", age=5.0, accepted=False))
    assert model.tau("dk", "h2h") < before
    assert model.is_fitted("dk", "h2h")


def test_accepts_lengthen_it():
    model = FillModel()
    before = model.tau("dk", "h2h")
    for _ in range(40):
        model.observe(Observation(book="dk", market="h2h", age=80.0, accepted=True))
    assert model.tau("dk", "h2h") > before


def test_an_accept_dates_survival_not_death():
    """An accept at 40s says the quote lived at least 40s; only a reject
    dates its death. The estimator has to treat them differently."""
    accepts = FillModel()
    rejects = FillModel()
    for _ in range(30):
        accepts.observe(Observation(book="dk", market="h2h", age=30.0, accepted=True))
        rejects.observe(Observation(book="dk", market="h2h", age=30.0, accepted=False))
    assert accepts.tau("dk", "h2h") > rejects.tau("dk", "h2h")


def test_the_prior_dominates_a_tiny_sample():
    """Five bets must not overturn a shipped default."""
    model = FillModel()
    prior = model.tau("dk", "h2h")
    for _ in range(3):
        model.observe(Observation(book="dk", market="h2h", age=1.0, accepted=False))
    assert abs(model.tau("dk", "h2h") - prior) < prior * 0.35


def test_the_estimate_is_capped_when_nothing_has_been_rejected():
    """'Nothing rejected yet' is not evidence that nothing ever will be."""
    model = FillModel()
    for _ in range(200):
        model.observe(Observation(book="dk", market="h2h", age=600.0, accepted=True))
    assert model.tau("dk", "h2h") <= model.max_tau


def test_books_are_modelled_separately():
    model = FillModel()
    for _ in range(40):
        model.observe(Observation(book="dk", market="h2h", age=2.0, accepted=False))
    assert model.tau("dk", "h2h") < model.tau("fd", "h2h")


def test_half_life_is_the_human_number():
    model = FillModel()
    hl = model.half_life("dk", "h2h")
    assert model.p_fill("dk", "h2h", hl) == pytest.approx(0.5, abs=1e-9)


def test_fill_model_round_trips_through_a_dict():
    model = FillModel()
    for _ in range(20):
        model.observe(Observation(book="dk", market="player_points", age=9.0, accepted=False))
    restored = FillModel.from_dict(model.to_dict())
    assert restored.tau("dk", "player_points") == pytest.approx(
        model.tau("dk", "player_points")
    )
