"""`overlay mcp`: the engine as an MCP server on stdio, for AI assistants. Four tools, the engine's own numbers, the
RG line on every answer, the lock condition wherever anything is locked, and a scan that reads files only."""
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

import test_lowhold_view as lv  # noqa: E402
from overlay_engine import mcpserver, oddsapi  # noqa: E402
from overlay_engine.ask import RG  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
home = lv.home
BANNED = re.compile(r"guarantee|risk.free|either way|free bet|sure thing|whichever side wins|can't lose", re.I)


def call(name, **arguments):
    reply = mcpserver.handle({"jsonrpc": "2.0", "id": 9, "method": "tools/call",
                              "params": {"name": name, "arguments": arguments}})
    result = reply["result"]
    return result["isError"], result["content"][0]["text"], json.loads(result["content"][1]["text"])


def test_it_introduces_itself_and_lists_four_tools():
    init = mcpserver.handle({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})["result"]
    assert init["serverInfo"]["name"] == "bookbreaker" and init["capabilities"]["tools"]
    tools = mcpserver.handle({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})["result"]["tools"]
    assert [t["name"] for t in tools] == ["fair_odds", "arb_stakes", "bonus_bet_conversion", "scan"]
    assert all(t["inputSchema"]["type"] == "object" for t in tools)


def test_the_numbers_are_the_engines():
    _, text, body = call("fair_odds", first="-145", second="+125")
    assert body["fair_chance_first"] == pytest.approx(0.5734, abs=1e-4) and "57.34%" in text
    _, text, body = call("arb_stakes", prices=["2.10", "2.05"], total=1000, round_to=10)
    assert body["stakes"] == [490.0, 500.0] and body["profit"] == pytest.approx(35.0)
    _, text, body = call("bonus_bet_conversion", bonus=100, bonus_price="+300", hedge_price="-350")
    assert body["hedge_stake"] == pytest.approx(233.33) and body["locked"] == pytest.approx(66.67)


@pytest.mark.parametrize("name,args", [
    ("fair_odds", {"first": "-145", "second": "+125"}),
    ("arb_stakes", {"prices": ["2.10", "2.05"], "total": 1000}),
    ("arb_stakes", {"prices": ["-110", "-110"], "total": 1000}),
    ("bonus_bet_conversion", {"bonus": 100, "bonus_price": "+300", "hedge_price": "-350"}),
    ("fair_odds", {"first": "abc", "second": "+125"}),
])
def test_every_answer_carries_the_rg_line_and_never_promises(name, args):
    _, text, body = call(name, **args)
    assert text.endswith(RG) and body["responsible_gambling"] == RG
    assert not BANNED.search(text), text


def test_anything_locked_says_it_holds_only_if_every_bet_stands():
    for name, args in (("arb_stakes", {"prices": ["2.10", "2.05"], "total": 1000}),
                       ("bonus_bet_conversion", {"bonus": 100, "bonus_price": "+300", "hedge_price": "-350"})):
        assert "only if every bet is accepted at these prices and stands" in call(name, **args)[1]


def test_prices_that_do_not_cross_say_so_and_bad_input_is_a_sentence():
    _, text, body = call("arb_stakes", prices=["-110", "-110"], total=1000)
    assert body["arbitrage"] is False and "do not cross" in text
    error, text, _ = call("fair_odds", first="abc", second="+125")
    assert error and "is not a price I can read" in text


def test_scan_reads_the_files_on_this_mac_and_never_the_network(home, monkeypatch):
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: (_ for _ in ()).throw(AssertionError("fetch")))
    error, text, body = call("scan")
    assert not error and body["plays"] == [] and "never fetches" in text
    crossing = dict(lv.ML, fanduel=(2.10, 1.80), betmgm=(1.80, 2.05))   # 1/2.10 + 1/2.05 is 96.4%: an arb
    lv.read(payload=lv.tp.only(lv.world(ml=crossing), "h2h"))
    monkeypatch.setattr(mcpserver.time, "time", lambda: lv.NOW + 30)
    error, text, body = call("scan", state="NJ", limit=3)
    assert not error and 0 < len(body["plays"]) <= 3
    assert all(leg["book"] in oddsapi.bettable_in("NJ") for p in body["plays"] for leg in p["legs"])


def test_protocol_edges():
    assert mcpserver.handle({"jsonrpc": "2.0", "method": "notifications/initialized"}) is None
    assert mcpserver.handle({"jsonrpc": "2.0", "id": 3, "method": "nope"})["error"]["code"] == -32601
    bad = mcpserver.handle({"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "nope"}})
    assert bad["error"]["code"] == -32602


def test_the_cli_serves_it_on_stdio(tmp_path):
    lines = "\n".join(json.dumps(m) for m in (
        {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}},
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
         "params": {"name": "fair_odds", "arguments": {"first": "-110", "second": "-110"}}})) + "\n"
    done = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "mcp"], cwd=ROOT / "backend", input=lines,
                          capture_output=True, text=True, timeout=60, env={"OVERLAY_HOME": str(tmp_path),
                                                                           "PATH": "/usr/bin:/bin"})
    replies = [json.loads(l) for l in done.stdout.splitlines()]
    assert [r["id"] for r in replies] == [1, 2] and "50.00%" in replies[1]["result"]["content"][0]["text"]
