"""Convert my own promo: the answer the Promos page gives for a promotion the person holds.

What must not go wrong, in the order it would cost most:

  - calling an average a locked amount (a refund, a boost no pair locks, a deposit match);
  - showing a pair that cannot be placed: the hedge at the same book as the promo, a
    three-way market, a game that has started, a +960 longshot, a read from last week;
  - a figure that is not the engine's own: the converter must agree with the functions the
    Promos cards are priced with;
  - a fetch. The converter reads the odds already recorded on this Mac and nothing else.
"""

import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import promo, promoconv, welcome
from promo_fixtures import HOUR, NOW, h2h, history

ROOT = Path(__file__).resolve().parent.parent
_history = history
_h2h = h2h


def _convert(kind="bonus_bet", book="dk", amount=100.0, history=None, **kw):
    return promoconv.convert(kind, book, amount, history=history, now=NOW, **kw)


# ------------------------------------------------------------ a bonus bet

def test_a_bonus_bet_is_paired_with_the_best_hedge_in_the_recorded_odds(tmp_path):
    hist = _history(tmp_path, [
        _h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30)),
        _h2h("e2", dk=(2.5, 1.55), fd=(2.4, 1.60), names=("Lakers", "Suns")),
    ])
    out = _convert(history=hist)
    pair = out["pair"]
    assert pair["source"] == "feed" and pair["example"] is False
    # The +300 on Chiefs against FanDuel's 1.30 on Bills converts more than the even-money game.
    assert (pair["promo"]["book"], pair["promo"]["side"], pair["promo"]["decimal"]) == ("dk", "Chiefs", 4.0)
    assert (pair["hedge"]["book"], pair["hedge"]["side"], pair["hedge"]["decimal"]) == ("fd", "Bills", 1.3)
    assert pair["promo"]["stake"] == 100.0 and pair["promo"]["bonus"] is True
    assert pair["considered"] >= 3


def test_a_bonus_bet_is_locked_at_the_worse_of_its_two_outcomes_on_the_stake_shown(tmp_path):
    hist = _history(tmp_path, [_h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30))])
    out = _convert(history=hist)
    won, lost = out["outcomes"]
    assert won["name"] == "If the bonus bet wins" and lost["name"] == "If the hedge wins"
    h = out["pair"]["hedge"]["stake"]
    assert won["kept"] == round(100 * 3.0 - h, 2)
    assert lost["kept"] == round(h * 0.30, 2)
    assert out["worth"]["locked"] is True and out["worth"]["amount"] == min(won["kept"], lost["kept"])
    # The hedge is a stake a risk desk reads as ordinary, and costs under 2% of the exact plan.
    assert h % 5 == 0
    exact = promo.bonus_bet_conversion(4.0, 1.30, 100.0)
    assert out["worth"]["amount"] >= exact.guaranteed * (1 - welcome.ROUNDING_COST_LIMIT) - 0.01
    assert out["worth"]["amount"] <= exact.guaranteed + 0.01


def test_a_bonus_bet_is_labelled_the_way_the_promos_cards_label_it(tmp_path):
    hist = _history(tmp_path, [_h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30))])
    w = _convert(history=hist)["worth"]
    assert w["caption"] == "locked from $100.00 in bonus if both bets are accepted and stand"
    assert w["face"] == 100.0 and 0.5 < w["rate"] < 0.8


def test_the_hedge_is_never_at_the_book_the_promo_is_at(tmp_path):
    # DraftKings has the best price on both sides. Hedging a DraftKings bonus bet at DraftKings
    # is the one pair that cannot be placed, so it is not offered.
    hist = _history(tmp_path, [("e1", "h2h", NOW + HOUR, [
        ("dk", "Chiefs", None, 4.0), ("dk", "Bills", None, 1.40),
        ("fd", "Chiefs", None, 3.0), ("fd", "Bills", None, 1.20)])])
    out = _convert(history=hist)
    assert out["pair"]["hedge"]["book"] == "fd" and out["pair"]["hedge"]["decimal"] == 1.2


def test_hard_rock_in_two_states_is_one_book(tmp_path):
    hist = _history(tmp_path, [("e1", "h2h", NOW + HOUR, [
        ("hardrockbet", "Chiefs", None, 4.0), ("hardrockbet_fl", "Bills", None, 1.40),
        ("fd", "Chiefs", None, 3.0), ("fd", "Bills", None, 1.20)])])
    out = _convert(book="hardrockbet", history=hist)
    assert out["pair"]["hedge"]["book"] == "fd"


def test_a_three_way_market_is_not_a_pair(tmp_path):
    hist = _history(tmp_path, [("e1", "h2h", NOW + HOUR, [
        ("dk", "Arsenal", None, 2.2), ("dk", "Chelsea", None, 3.4), ("dk", "Draw", None, 3.5),
        ("fd", "Arsenal", None, 2.1), ("fd", "Chelsea", None, 3.6), ("fd", "Draw", None, 3.4)])])
    assert _convert(history=hist)["pair"]["source"] == "example"


def test_a_game_that_has_started_is_not_a_pair(tmp_path):
    hist = _history(tmp_path, [_h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30), starts=NOW - 60)])
    assert _convert(history=hist)["pair"]["source"] == "example"


def test_a_longshot_past_plus_500_is_not_offered(tmp_path):
    hist = _history(tmp_path, [_h2h("e1", dk=(10.6, 1.05), fd=(9.0, 1.12))])
    out = _convert(history=hist)
    assert out["pair"]["source"] == "example"
    assert "between -200 and +500" in out["pair"]["why"]


def test_a_hedge_bigger_than_you_can_place_drops_the_pair(tmp_path):
    hist = _history(tmp_path, [_h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30))])
    assert _convert(history=hist, max_hedge=1000.0)["pair"]["source"] == "feed"
    out = _convert(history=hist, max_hedge=50.0)
    assert out["pair"]["source"] == "example"
    assert "$50.00" in out["pair"]["why"]


def test_spreads_pair_on_one_line_and_never_across_lines(tmp_path):
    hist = _history(tmp_path, [("e1", "spreads", NOW + HOUR, [
        ("dk", "Chiefs", -3.5, 2.5), ("dk", "Bills", 3.5, 1.5),
        ("fd", "Chiefs", -2.5, 2.1), ("fd", "Bills", 2.5, 1.75),
        ("fd", "Bills", 3.5, 1.55)])])
    out = _convert(history=hist)
    # Chiefs -3.5 at DraftKings meets Bills +3.5 at FanDuel, not Bills +2.5.
    assert out["pair"]["promo"]["side"] == "Chiefs -3.5" and out["pair"]["hedge"]["side"] == "Bills +3.5"
    assert out["pair"]["market"] == "Spread"


def test_a_book_the_read_has_no_price_for_falls_back_to_the_example(tmp_path):
    hist = _history(tmp_path, [_h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30))])
    out = _convert(book="betrivers", history=hist)
    assert out["pair"]["example"] is True and "BetRivers" in out["pair"]["why"]


# ------------------------------------------------------------ no read, or an old one

def test_with_no_read_the_stakes_are_at_a_stated_example_price_and_it_says_so(tmp_path):
    out = _convert(history=tmp_path / "none")
    pair = out["pair"]
    assert pair["example"] is True and pair["source"] == "example"
    assert pair["promo"]["decimal"] == welcome.PRIOR_BONUS_DECIMAL
    assert pair["promo"]["american"] == 300
    hedge = welcome.hedge_decimal(welcome.PRIOR_BONUS_DECIMAL, welcome.PRIOR_TWO_BOOK_HOLD)
    assert pair["hedge"]["decimal"] == round(hedge, 4)
    assert "Odds API key" in pair["why"] and "never spends your credits" in pair["why"]
    assert "Example price" in out["assumptions"] and "prior" in out["assumptions"]


def test_the_example_agrees_with_the_conversion_the_promos_cards_use(tmp_path):
    out = _convert(history=tmp_path / "none", amount=200.0)
    hedge = welcome.hedge_decimal(welcome.PRIOR_BONUS_DECIMAL, welcome.PRIOR_TWO_BOOK_HOLD)
    exact = promo.bonus_bet_conversion(welcome.PRIOR_BONUS_DECIMAL, hedge, 200.0)
    stake, floor = welcome.round_hedge(200.0, welcome.PRIOR_BONUS_DECIMAL, hedge)
    assert out["pair"]["hedge"]["stake"] == stake
    assert out["worth"]["amount"] == round(floor, 2)
    assert abs(out["worth"]["amount"] - exact.guaranteed) < 0.02 * exact.guaranteed


def test_a_read_older_than_twelve_hours_is_not_paired_from(tmp_path):
    hist = _history(tmp_path, [_h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30))], read_at=NOW - 20 * HOUR)
    out = _convert(history=hist)
    assert out["pair"]["example"] is True
    assert "20 hours ago" in out["pair"]["why"] and "too old" in out["pair"]["why"]


def test_a_read_over_six_hours_old_is_used_and_says_how_old(tmp_path):
    hist = _history(tmp_path, [_h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30))], read_at=NOW - 8 * HOUR)
    out = _convert(history=hist)
    assert out["pair"]["source"] == "feed" and "8.0 hours ago" in out["assumptions"]
    assert "a while ago" in out["assumptions"]


# ------------------------------------------------------------ a refund is an average

def test_a_refund_is_an_average_priced_by_the_function_the_cards_use():
    out = _convert("refund", "mgm", 200.0, history=Path("/nonexistent"))
    q, conv = promoconv._prior_chance(), promoconv._prior_conversion()
    expected = promo.safety_net_value(200.0, welcome.PRIOR_BONUS_DECIMAL, q, conv).expected
    assert out["worth"]["amount"] == round(expected, 2)
    assert out["worth"]["locked"] is False
    assert out["worth"]["caption"] == "expected on average. It only pays if your first bet loses, so it cannot be locked in."


def test_a_refunds_two_outcomes_average_to_its_worth():
    out = _convert("refund", "mgm", 200.0, history=Path("/nonexistent"))
    q = out["chance"]
    won, lost = out["outcomes"]
    assert won["name"] == "If the promo bet wins" and lost["name"] == "If it loses"
    assert abs(q * won["kept"] + (1 - q) * lost["kept"] - out["worth"]["amount"]) < 0.02
    # Losing leaves the cash stake gone and a refund in bonus bets worth part of its face.
    assert lost["from_promo"] == -200.0 and 0 < lost["from_refund"] < 200.0


def test_a_refund_takes_the_price_worth_most_at_the_book_and_the_chance_from_the_books(tmp_path):
    hist = _history(tmp_path, [
        _h2h("e1", dk=(4.0, 1.25), fd=(3.9, 1.27)),
        _h2h("e2", dk=(2.0, 1.90), fd=(2.0, 1.90), names=("Lakers", "Suns")),
    ])
    out = _convert("refund", "dk", 100.0, history=hist)
    pair = out["pair"]
    assert pair["source"] == "feed" and pair["promo"]["side"] == "Chiefs" and pair["hedge"] is None
    assert out["worth"]["locked"] is False
    # The chance is the middle of each book's own no-vig share, never one book against another.
    shares = [(1 / 4.0) / (1 / 4.0 + 1 / 1.25), (1 / 3.9) / (1 / 3.9 + 1 / 1.27)]
    assert abs(out["chance"] - sum(shares) / 2) < 1e-3


# ------------------------------------------------------------ a profit boost

def test_a_boost_a_pair_can_lock_is_locked_and_the_outcomes_are_the_boosted_ones():
    out = _convert("boost", "fd", 50.0, boost_pct=50.0, history=Path("/nonexistent"))
    assert out["worth"]["locked"] is True
    won, lost = out["outcomes"]
    assert won["name"] == "If the boosted bet wins" and lost["name"] == "If the hedge wins"
    # +300 boosted 50% pays 4.5 to 1 on the profit.
    assert won["from_promo"] == round(50 * 3.0 * 1.5, 2)
    assert lost["from_promo"] == -50.0
    assert out["worth"]["amount"] == min(won["kept"], lost["kept"]) > 0


def test_a_boost_no_pair_can_lock_is_an_average_and_is_never_called_locked():
    out = _convert("boost", "fd", 50.0, boost_pct=5.0, history=Path("/nonexistent"))
    assert out["worth"]["locked"] is False
    assert out["worth"]["caption"] == "expected on average. A boost cannot be hedged to a fixed amount."
    assert out["pair"]["hedge"] is None
    q = out["chance"]
    won, lost = out["outcomes"]
    assert abs(q * won["kept"] + (1 - q) * lost["kept"] - out["worth"]["amount"]) < 0.02


def test_max_winnings_caps_what_the_boost_adds():
    big = _convert("boost", "fd", 50.0, boost_pct=50.0, history=Path("/nonexistent"))
    capped = _convert("boost", "fd", 50.0, boost_pct=50.0, max_win=160.0, history=Path("/nonexistent"))
    assert big["outcomes"][0]["from_promo"] == 225.0
    assert capped["outcomes"][0]["from_promo"] == 160.0
    assert capped["worth"]["amount"] < big["worth"]["amount"]


def test_a_boost_that_cannot_be_hedged_in_the_recorded_odds_is_the_boosted_bet_on_its_own(tmp_path):
    # A 5% boost against a 6% two-book margin: no pair keeps a profit.
    hist = _history(tmp_path, [_h2h("e1", dk=(4.0, 1.20), fd=(3.8, 1.22))])
    out = _convert("boost", "dk", 50.0, boost_pct=5.0, history=hist)
    assert out["worth"]["locked"] is False and out["pair"]["source"] == "feed"
    assert out["pair"]["promo"]["side"] == "Chiefs"
    assert "on its own" in out["pair"]["why"]


# ------------------------------------------------------------ a deposit match

def test_a_deposit_match_is_the_engines_own_number_and_never_locked():
    out = _convert("deposit_match", "", 500.0, match_pct=100.0, rollover=10.0)
    v = promo.deposit_match_value(500.0, 500.0, 10.0, hold_per_bet=promoconv.PRIOR_PLAYTHROUGH_HOLD)
    assert out["worth"]["amount"] == round(v.expected, 2) and out["worth"]["locked"] is False
    assert out["worth"]["caption"] == "expected on average. This kind of offer cannot be locked in."
    assert out["outcomes"] == [] and out["pair"] is None
    assert out["turnover"] == 10000.0 and out["breakeven_hold"] == 0.05
    assert "prior" in out["assumptions"]


def test_a_deposit_match_that_costs_more_than_it_pays_is_negative_and_says_so():
    out = _convert("deposit_match", "", 500.0, match_pct=100.0, rollover=25.0)
    assert out["worth"]["amount"] < 0
    assert "Negative" in out["notes"][0]


def test_a_deposit_match_needs_its_playthrough_and_its_match():
    with pytest.raises(promoconv.PromoError, match="playthrough"):
        _convert("deposit_match", "", 500.0, match_pct=100.0)
    with pytest.raises(promoconv.PromoError, match="match"):
        _convert("deposit_match", "", 500.0, rollover=10.0)


# ------------------------------------------------------------ refusals

@pytest.mark.parametrize("kwargs,words", [
    (dict(kind="nope"), "Pick a promo type"),
    (dict(book="nowhere"), "Pick the sportsbook"),
    (dict(book=""), "Pick the sportsbook"),
    (dict(amount=0), "the amount"),
    (dict(amount=float("nan")), "the amount"),
    (dict(amount="abc"), "the amount"),
    (dict(kind="boost"), "boost as a percentage"),
    (dict(kind="boost", boost_pct=0), "boost percentage"),
    (dict(max_hedge=0.5), "the most you can hedge"),
])
def test_a_promo_that_cannot_be_priced_is_refused_in_a_sentence(kwargs, words, tmp_path):
    args = dict(kind="bonus_bet", book="dk", amount=100.0)
    args.update(kwargs)
    with pytest.raises(promoconv.PromoError, match=words):
        promoconv.convert(args.pop("kind"), args.pop("book"), args.pop("amount"),
                          history=tmp_path / "none", now=NOW, **args)


def test_a_refusal_is_not_filed_as_a_crash():
    from overlay_engine import crash
    assert crash.is_expected(promoconv.PromoError)


# ------------------------------------------------------------ what it may say, and what it may not do

def _every_answer(tmp_path):
    hist = _history(tmp_path, [_h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30))])
    nothing = tmp_path / "none"
    for h in (hist, nothing):
        yield _convert("bonus_bet", "dk", 100.0, history=h)
        yield _convert("refund", "dk", 100.0, history=h)
        yield _convert("boost", "dk", 100.0, boost_pct=50.0, history=h)
        yield _convert("boost", "dk", 100.0, boost_pct=2.0, history=h)
        yield _convert("deposit_match", "", 100.0, match_pct=100.0, rollover=10.0, history=h)


def test_no_answer_says_guaranteed_risk_free_free_bets_or_either_way(tmp_path):
    for out in _every_answer(tmp_path):
        text = json.dumps(out).lower()
        for banned in ("guarantee", "risk-free", "risk free", "free bet", "free money", "sure thing", "either way"):
            assert banned not in text, banned


def test_only_a_pair_that_locks_is_called_locked(tmp_path):
    for out in _every_answer(tmp_path):
        locked = out["worth"]["locked"]
        assert ("locked from" in out["worth"]["caption"] or "locked on" in out["worth"]["caption"]) == locked
        if locked:
            assert out["pair"]["hedge"] is not None and len(out["outcomes"]) == 2
            assert out["worth"]["amount"] > 0
            assert "if both bets are accepted and stand" in out["worth"]["caption"]
        else:
            assert out["worth"]["caption"].startswith("expected on average")


def test_every_answer_carries_a_stated_basis_for_its_prices(tmp_path):
    for out in _every_answer(tmp_path):
        assert out["assumptions"] and ("prior" in out["assumptions"] or "last read" in out["assumptions"])


def test_the_converter_fetches_nothing(tmp_path, monkeypatch):
    import socket
    import urllib.request

    def refuse(*a, **k):
        raise AssertionError("the converter opened a connection")

    monkeypatch.setattr(socket.socket, "connect", refuse)
    monkeypatch.setattr(urllib.request, "urlopen", refuse)
    for out in _every_answer(tmp_path):
        assert out["worth"]
    src = (ROOT / "backend/overlay_engine/promoconv.py").read_text()
    for reach in ("urllib", "requests", "httpx", "socket", "urlopen", "fetcher", "refresh("):
        assert reach not in src, reach


def test_it_holds_no_research_lab_code():
    src = (ROOT / "backend/overlay_engine/promoconv.py").read_text()
    assert "edgelab" not in src and not re.search(r"\bH0\d\d\b", src)


# ------------------------------------------------------------ the verb

def _cli(*argv, home):
    return subprocess.run([sys.executable, "-m", "overlay_engine", "promo", *argv],
                          capture_output=True, text=True, timeout=120,
                          env={"PYTHONPATH": str(ROOT / "backend"), "OVERLAY_HOME": str(home),
                               "HOME": str(home), "PATH": "/usr/bin:/bin"})


def test_the_promo_verb_answers_in_json_for_the_window(tmp_path):
    got = _cli("--type", "bonus_bet", "--book", "dk", "--amount", "100", "--json", home=tmp_path)
    assert got.returncode == 0, got.stderr
    out = json.loads(got.stdout)
    assert out["command"] == "promo" and out["worth"]["locked"] is True and len(out["outcomes"]) == 2


def test_the_promo_verb_reads_the_recorded_odds_in_the_overlay_home(tmp_path):
    import time
    folder = tmp_path / "oddsapi" / "history"
    folder.mkdir(parents=True)
    now = time.time()
    snap = {"v": 1, "league": "americanfootball_nfl", "alias": "nfl", "fetched_at": now - 120,
            "events": {"e1": {"label": "Chiefs vs Bills", "starts": None}},
            "markets": [{"event": "e1", "type": "h2h", "starts": now + 7200,
                         "q": [["dk", "Chiefs", None, 4.0, now - 120], ["dk", "Bills", None, 1.25, now - 120],
                               ["fd", "Chiefs", None, 3.6, now - 120], ["fd", "Bills", None, 1.30, now - 120]]}]}
    (folder / "2027-01-15.jsonl").write_text(json.dumps(snap) + "\n")
    got = _cli("--type", "bonus_bet", "--book", "dk", "--amount", "100", "--json", home=tmp_path)
    out = json.loads(got.stdout)
    assert out["pair"]["source"] == "feed" and out["pair"]["game"] == "Chiefs vs Bills"


def test_the_promo_verb_refuses_in_a_sentence_with_exit_2(tmp_path):
    got = _cli("--type", "boost", "--book", "dk", "--amount", "100", "--json", home=tmp_path)
    assert got.returncode == 2 and "boost as a percentage" in got.stderr
    assert "Traceback" not in got.stderr
    assert not list((tmp_path / "crashes").glob("crash-*.json")), "a refusal was filed as a crash"


def test_the_promo_verb_without_a_type_is_still_the_welcome_offers_page(tmp_path):
    got = _cli("--bonus", "1000", home=tmp_path)
    assert got.returncode == 0 and "WELCOME OFFERS" in got.stdout


def test_the_promo_verb_prints_for_a_person_too(tmp_path):
    got = _cli("--type", "refund", "--book", "mgm", "--amount", "100", home=tmp_path)
    assert got.returncode == 0
    assert "expected on average" in got.stdout and "If it loses: you lose" in got.stdout
