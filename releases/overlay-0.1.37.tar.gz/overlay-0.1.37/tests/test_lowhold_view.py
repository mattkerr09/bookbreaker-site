"""The low hold view: two-way markets on this Mac, cheapest to cover first.

It works from prices a read of live sportsbook odds already left on this Mac, so
these tests give it a fetcher and a Keychain that raise, and count the requests.
What they pin is what a screenshot cannot show:

  * the cheapest pair is the cheapest pair, checked against a brute force written
    here, and it crosses books;
  * a reference book (Pinnacle) is never a leg, even when it would be the cheapest;
  * with a credit book every row has a leg there, sized to the amount;
  * a cost is a cost, a loss is never drawn as a gain, and an arbitrage is marked as
    one with the condition every locked amount carries;
  * a market that is not really two-way (a draw, two lines that only look alike) is
    left out rather than paired;
  * a game that has started, or a read too old, is not listed.
"""

import itertools
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

import test_oddsapi as to  # noqa: E402
import test_parity_grid as tp  # noqa: E402
from overlay_engine import cli, keystore, lowhold, lowholdview, oddsapi, oddshistory, screen  # noqa: E402

NOW = to.NOW
HOME, AWAY = tp.HOME, tp.AWAY
BETTABLE = set(oddsapi.BETTABLE)
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way", "free bet", "free money", "sure thing")


@pytest.fixture
def home(monkeypatch, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


#: Decimal prices on the Chiefs (home) and the Bills (away). Pinnacle prices both at 2.10, which
#: would be an arbitrage against anyone and the cheapest pair of all, if it could be bet at.
ML = {
    "draftkings": (1.91, 1.91), "fanduel": (1.98, 1.80), "betmgm": (1.80, 1.97),
    "caesars": (1.87, 1.95), "pinnacle": (2.10, 2.10),
}
KEY = {"draftkings": "dk", "fanduel": "fd", "betmgm": "mgm", "caesars": "caesars", "pinnacle": "pinnacle"}


def world(ml=ML, start=NOW + 3600, spread=None, total=None):
    books = []
    for key, prices in ml.items():
        books.append(tp.full_book(key, ml=prices, spread=spread, total=total))
    return [to.event("g1", start=start, books=books)]


def read(payload=None, markets=("h2h",), clock=None):
    return tp.read(markets=list(markets), payload=payload or tp.only(world(), *markets), clock=clock)


def view(now=NOW + 30, **kw):
    return lowholdview.from_history(oddshistory.history_folder(), BETTABLE, now, **kw)


def brute(ml=ML, credit=None, books=None):
    """The cheapest cross-book pair among the books you can bet at, by plain enumeration."""
    books = books or [b for b in ml if KEY[b] in BETTABLE]
    best = None
    for home_at, away_at in itertools.permutations(books, 2):
        if credit and credit not in (KEY[home_at], KEY[away_at]):
            continue
        hold = 1 / ml[home_at][0] + 1 / ml[away_at][1] - 1
        if best is None or hold < best[0] - 1e-12:
            best = (hold, KEY[home_at], KEY[away_at])
    return best


def strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for v in value.values():
            yield from strings(v)
    elif isinstance(value, list):
        for v in value:
            yield from strings(v)


# ================================================================ the cheapest pair

def test_the_cheapest_pair_is_the_cheapest_cross_book_pair_and_a_reference_book_is_never_a_leg(home):
    read()
    v = view()
    assert v["has_odds"] and v["shown"] == 1
    row = v["rows"][0]
    hold, home_book, away_book = brute()
    assert row["hold"] == pytest.approx(hold, abs=1e-6)
    assert {l["label"]: l["book"] for l in row["legs"]} == {HOME: home_book, AWAY: away_book}
    assert [l["label"] for l in row["legs"]] == [AWAY, HOME], "in the order the game's name gives them"
    assert len({l["book"] for l in row["legs"]}) == 2, "the pair crosses books"
    assert "pinnacle" not in {l["book"] for l in row["legs"]}, "Pinnacle prices the market; nobody here can bet there"
    assert "pinnacle" not in {b["key"] for b in v["books"]}, "and it is not offered as a credit book"


def test_the_hold_is_the_sum_of_the_two_implied_chances_less_one(home):
    read()
    row = view()["rows"][0]
    implied = sum(1 / l["decimal"] for l in row["legs"])
    assert row["hold"] == pytest.approx(implied - 1, abs=1e-4)
    assert row["hold_text"] == f"{round((implied - 1) * 100, 2):.2f}%"


def test_with_a_credit_book_every_row_has_a_leg_there_and_the_amount_is_bet_there(home):
    read()
    v = view(credit_book="dk", amount=500)
    assert v["credit_book"] == "dk" and v["credit_name"] == "DraftKings" and v["amount"] == 500
    assert v["shown"] == 1
    row = v["rows"][0]
    hold, _, _ = brute(credit="dk")
    assert row["hold"] == pytest.approx(hold, abs=1e-6)
    credit_legs = [l for l in row["legs"] if l["credit"]]
    assert [l["book"] for l in credit_legs] == ["dk"], "exactly one leg is at the credit book"
    assert credit_legs[0]["stake"] == 500.0, "the amount is what is bet at the credit book"
    other = [l for l in row["legs"] if not l["credit"]][0]
    assert other["book"] != "dk"
    assert "500" in v["amount_text"] and "DraftKings" in v["amount_text"] and "counts toward playing the credit" in v["amount_text"]


def test_without_a_credit_book_the_amount_is_the_total_across_both_bets(home):
    read()
    v = view(amount=1000)
    row = v["rows"][0]
    assert sum(l["stake"] for l in row["legs"]) == pytest.approx(1000, abs=0.02)
    assert row["total"] == 1000.0 and "total across both bets" in v["amount_text"]
    assert not any(l["credit"] for l in row["legs"])


def test_the_stakes_return_the_same_whichever_side_lands(home):
    read()
    for kw in ({}, {"credit_book": "dk", "amount": 500}):
        legs = view(**kw)["rows"][0]["legs"]
        assert max(l["returns"] for l in legs) - min(l["returns"] for l in legs) < 0.05


# ================================================================ the cost is a cost

def test_the_cost_is_what_went_in_less_what_comes_back(home):
    read()
    for kw in ({}, {"credit_book": "dk", "amount": 500}, {"credit_book": "fd", "amount": 2500}):
        row = view(**kw)["rows"][0]
        back = min(l["returns"] for l in row["legs"])
        assert row["cost"] == pytest.approx(row["total"] - back, abs=0.03), kw
        assert row["cost"] == pytest.approx(row["total"] * row["hold"] / (1 + row["hold"]), abs=0.03)
        assert row["cost"] > 0 and row["cost_line"].startswith("Costs about $")
        assert "Keeps" not in row["cost_line"]


def test_a_cost_is_never_called_a_gain_and_an_arbitrage_says_what_it_depends_on(home):
    arb = dict(ML)
    arb["fanduel"] = (2.10, 1.80)
    arb["betmgm"] = (1.80, 2.10)
    read(payload=tp.only(world(arb), "h2h"))
    row = view()["rows"][0]
    assert row["is_arb"] is True and row["hold"] < 0 and row["cost"] < 0
    assert row["cost_line"].startswith("Keeps about $") and "if both bets are accepted and stand" in row["cost_line"]
    assert "This is an arbitrage." in row["cost_line"]
    assert row["cost_text"].startswith("$") and "-" not in row["cost_text"], "the figure is a size, the sentence says which way"


def test_the_obvious_way_is_priced_for_the_same_amount_and_says_when_it_is_cheaper(home):
    read()
    v = view(amount=1000)
    one = v["rows"][0]["one_book"]
    # The cheapest single book among those that price both sides, by enumeration.
    singles = {KEY[b]: 1 / p[0] + 1 / p[1] - 1 for b, p in ML.items() if KEY[b] in BETTABLE}
    book = min(singles, key=singles.get)
    assert one["book"] == book and one["hold"] == pytest.approx(singles[book], abs=1e-6)
    assert one["cost"] == pytest.approx(1000 * singles[book] / (1 + singles[book]), abs=0.02)
    assert one["cheaper"] is False and "That is less than this pair" not in one["line"]
    assert "with both bets there" in one["line"] and "$1,000" in one["line"]
    # With a credit book it is that book's own two sides, and all of the amount is bet there.
    credit = view(credit_book="dk", amount=500)["rows"][0]["one_book"]
    assert credit["book"] == "dk" and credit["hold"] == pytest.approx(2 / 1.91 - 1, abs=1e-6)
    assert credit["cost"] == pytest.approx(500 * credit["hold"] / (1 + credit["hold"]), abs=0.02)
    # Here splitting costs more per dollar bet at DraftKings (only that leg counts toward the playthrough), and
    # the row says so rather than hiding it.
    pair = view(credit_book="dk", amount=500)["rows"][0]
    assert credit["cost"] < pair["cost"] and credit["cheaper"] is True
    assert credit["line"].endswith("That is less than this pair.")


def test_a_pair_that_beats_both_sides_at_the_credit_book_is_not_marked_as_beaten(home):
    """DraftKings prices both sides at even money (no hold at all), so a split pair can only cost more
    there, and the row says so; at a book with an ordinary hold the split is cheaper and nothing is said."""
    free = {"draftkings": (2.00, 2.00), "fanduel": (1.98, 1.50), "betmgm": (1.50, 1.99)}
    read(payload=tp.only(world(free), "h2h"))
    row = view(credit_book="dk", amount=500)["rows"][0]
    assert row["one_book"]["hold"] == 0 and row["one_book"]["cost"] == 0
    assert len({l["book"] for l in row["legs"]}) == 2, "the pair is split across two books, never both bets at one"
    assert row["cost"] > 0 and row["one_book"]["cheaper"] is True
    assert row["one_book"]["line"].endswith("That is less than this pair.")
    tight = {"draftkings": (1.91, 1.91), "fanduel": (2.05, 1.60), "betmgm": (1.60, 2.05)}
    to_clock = to.Clock(NOW + 200)
    read(payload=tp.only(world(tight), "h2h"), clock=to_clock)
    row = view(credit_book="dk", amount=500, now=NOW + 230)["rows"][0]
    assert row["one_book"]["cheaper"] is False and "less than this pair" not in row["one_book"]["line"]


# ================================================================ ranking and the limit

def _many_games(n):
    out = []
    for i in range(n):
        ml = {"draftkings": (1.91, 1.91), "fanduel": (1.98 - 0.03 * i, 1.80), "betmgm": (1.80, 1.97 - 0.03 * i)}
        out.append(to.event(f"g{i}", start=NOW + 3600 + i, books=[tp.full_book(k, ml=p, spread=None, total=None)
                                                             for k, p in ml.items()]))
    return out


def test_rows_are_ranked_cheapest_first_and_the_list_is_capped_with_the_count_that_qualified(home):
    read(payload=tp.only(_many_games(6), "h2h"))
    reads, _ = screen.history_reads(oddshistory.history_folder(), NOW + 30)
    v = lowholdview.view(reads, BETTABLE, NOW + 30, limit=4, max_hold=1.0)
    holds = [r["hold"] for r in v["rows"]]
    assert holds == sorted(holds) and len(set(holds)) > 1
    assert v["shown"] == 4 and v["qualifying"] == 6 and v["limit"] == 4


def test_pairs_costing_more_than_the_ceiling_are_not_listed(home):
    read(payload=tp.only(_many_games(3), "h2h"))
    reads, _ = screen.history_reads(oddshistory.history_folder(), NOW + 30)
    everything = lowholdview.view(reads, BETTABLE, NOW + 30, max_hold=1.0)
    cheap = lowholdview.view(reads, BETTABLE, NOW + 30, max_hold=0.02)
    assert everything["shown"] == 3
    assert all(r["hold"] <= 0.02 for r in cheap["rows"]) and cheap["shown"] < everything["shown"]
    default = view()
    assert lowholdview.MAX_HOLD == 0.03 and default["max_hold_text"] == "3.00%"
    assert 0 < default["shown"] < 3 and all(r["hold"] <= 0.03 for r in default["rows"])
    nothing = lowholdview.view(reads, BETTABLE, NOW + 30, max_hold=0.0001)
    assert nothing["rows"] == [] and "can be covered for 0.01% or less" in nothing["message"]


# ================================================================ only real two-way markets

def test_a_three_way_market_is_not_paired(home):
    ev = world()
    for b in ev[0]["bookmakers"]:
        b["markets"][0]["outcomes"].append({"name": "Draw", "price": 3.4})
    read(payload=ev)
    v = view()
    assert v["has_odds"] and v["rows"] == []
    assert "None of the games" in v["message"]


def test_spreads_pair_one_teams_line_with_the_others_opposite_line_and_never_two_lines_that_only_look_alike(home):
    ev = world(spread=(-3.5, 1.95, 1.95))
    read(payload=tp.only(ev, "spreads"), markets=("spreads",))
    v = view()
    assert v["shown"] == 1 and v["rows"][0]["market"] == "spreads"
    labels = [l["label"] for l in v["rows"][0]["legs"]]
    assert sorted(labels) == ["Buffalo Bills +3.5", "Kansas City Chiefs -3.5"]
    # A feed that gave both teams the same sign on one number is not an opposite pair.
    bad = tp.only(ev, "spreads")
    for b in bad[0]["bookmakers"]:
        for o in b["markets"][0]["outcomes"]:
            o["point"] = -3.5
    read(payload=bad, markets=("spreads",), clock=to.Clock(NOW + 100))
    assert view(now=NOW + 130)["rows"] == []


def test_totals_pair_the_over_with_the_under_on_one_line(home):
    ev = world(total=(47.5, 1.95, 1.95))
    read(payload=tp.only(ev, "totals"), markets=("totals",))
    row = view()["rows"][0]
    assert row["market"] == "totals" and row["line"] == 47.5
    assert [l["label"] for l in row["legs"]] == ["Over 47.5", "Under 47.5"]


def test_two_lines_in_one_market_are_two_separate_questions(home):
    ev = world(total=(47.5, 1.95, 1.95))
    for b in ev[0]["bookmakers"]:
        if b["key"] == "betmgm":
            b["markets"][-1]["outcomes"] = [{"name": "Over", "price": 1.97, "point": 48.5},
                                            {"name": "Under", "price": 1.97, "point": 48.5}]
    read(payload=tp.only(ev, "totals"), markets=("totals",))
    rows = view()["rows"]
    assert {r["line"] for r in rows} <= {47.5, 48.5}
    for r in rows:
        assert len({screen.parse_key(l["side"])[1] for l in r["legs"]}) == 1, "both legs share the line"


# ================================================================ the clock

def test_a_game_that_has_started_is_not_listed_and_is_counted(home):
    read(payload=tp.only(world(start=NOW + 3600), "h2h"))
    assert view(now=NOW + 3599)["shown"] == 1
    after = view(now=NOW + 3601)
    assert after["rows"] == [] and after["under_way"] == 1


def test_a_read_older_than_six_hours_is_not_used_and_says_why(home):
    read(payload=tp.only(world(start=NOW + 40000), "h2h"))
    assert view(now=NOW + 21599)["has_odds"] is True
    old = view(now=NOW + 21601)
    assert old["has_odds"] is False and old["rows"] == [] and "more than six hours old" in old["message"]


def test_with_nothing_read_it_says_so_and_how_to_read(home):
    v = view()
    assert v["has_odds"] is False and "Press Live sportsbook odds" in v["message"]


def test_an_old_read_is_shown_with_a_warning_and_every_leg_says_how_old_its_price_is(home):
    read()
    fresh, stale = view(now=NOW + 30), view(now=NOW + 1200)
    assert fresh["warning"] == "" and "read 20 minutes ago" in stale["warning"]
    leg = stale["rows"][0]["legs"][0]
    assert leg["age"] > 1100 and leg["age_text"].startswith("last confirmed ")


# ================================================================ refusals

@pytest.mark.parametrize("bad", [0, -5, "abc", float("nan"), float("inf"), 10 ** 9])
def test_an_amount_that_cannot_be_put_through_is_refused_in_a_sentence(home, bad):
    read()
    with pytest.raises(lowholdview.LowHoldError) as e:
        view(amount=bad)
    assert str(e.value).endswith(".") and "Traceback" not in str(e.value)


def test_a_book_that_cannot_be_bet_at_is_not_a_credit_book(home):
    read()
    for key in ("pinnacle", "nonsense"):
        with pytest.raises(lowholdview.LowHoldError, match="not a sportsbook this app reads prices for"):
            view(credit_book=key)


def test_a_credit_book_that_prices_nothing_says_so(home):
    read()
    v = view(credit_book="betrivers")
    assert v["rows"] == [] and "BetRivers prices none of the two-way markets" in v["message"]


# ================================================================ it reads files and nothing else

def test_building_it_asks_the_feed_for_nothing_and_the_command_never_reaches_the_key(home, monkeypatch, capsys):
    import time

    got, api = tp.read(markets=["h2h"], payload=tp.only(world(), "h2h"))
    spent = oddsapi.Cache().recall()

    def boom(*a, **k):
        raise AssertionError("the low hold view reached for the network or the key")

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", boom)
    monkeypatch.setattr(keystore, "get_key", boom)
    monkeypatch.setattr(oddsapi, "refresh", boom)
    monkeypatch.setattr(time, "time", lambda: NOW + 120)
    assert cli.main(["board", "--feed", "oddsapi", "--lowhold", "--credit-book", "dk", "--amount", "500", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["command"] == "board" and out["lowhold"]["has_odds"] is True and "rows" not in out
    assert out["lowhold"]["credit_book"] == "dk" and out["lowhold"]["rows"]
    assert len(api.calls) == 1 and oddsapi.Cache().recall() == spent, "no request and no credit"
    assert out["lowhold"]["age"] == 120.0, "the age is worked out when it is asked for"


def test_the_command_prints_a_list_a_person_can_read(home, monkeypatch, capsys):
    import time

    tp.read(markets=["h2h"], payload=tp.only(world(), "h2h"))
    monkeypatch.setattr(time, "time", lambda: NOW + 120)
    assert cli.main(["board", "--feed", "oddsapi", "--lowhold"]) == 0
    text = capsys.readouterr().out
    assert "Costs about" in text and "At " in text and "Showing 1 of 1" in text
    assert all(w not in text.lower() for w in BANNED)


def test_the_command_with_nothing_read_says_so(home, capsys):
    assert cli.main(["board", "--feed", "oddsapi", "--lowhold"]) == 0
    assert "No sportsbook odds have been read on this Mac yet" in capsys.readouterr().out


@pytest.mark.parametrize("argv,words", [
    (["--lowhold"], "--lowhold only works with --feed oddsapi"),
    (["--feed", "oddsapi", "--lowhold", "--sport", "nfl"], "costs nothing"),
    (["--feed", "oddsapi", "--lowhold", "--market", "h2h"], "costs nothing"),
    (["--feed", "oddsapi", "--lowhold", "--estimate"], "costs nothing"),
    (["--feed", "oddsapi", "--lowhold", "--props"], "costs nothing"),
    (["--feed", "oddsapi", "--lowhold", "--screen"], "Choose one view"),
    (["--feed", "oddsapi", "--credit-book", "dk"], "only work with --lowhold"),
    (["--feed", "oddsapi", "--amount", "100"], "only work with --lowhold"),
    (["--credit-book", "dk"], "only work with --lowhold"),
])
def test_the_flags_cannot_be_combined_into_something_that_spends_credits(home, capsys, argv, words):
    assert cli.main(["board", *argv, "--json"]) == 2
    assert words in json.loads(capsys.readouterr().out)["error"]


def test_a_bad_credit_book_or_amount_is_one_sentence_and_exit_two(home, capsys):
    for extra, words in ((["--credit-book", "pinnacle"], "not a sportsbook this app reads"),
                         (["--amount", "0"], "more than zero")):
        assert cli.main(["board", "--feed", "oddsapi", "--lowhold", "--json", *extra]) == 2
        assert words in json.loads(capsys.readouterr().out)["error"]
    assert cli.main(["board", "--feed", "oddsapi", "--lowhold", "--credit-book", "pinnacle"]) == 2
    assert "not a sportsbook this app reads" in capsys.readouterr().err


# ================================================================ words

def test_nothing_it_says_promises_more_than_a_cost(home):
    arb = dict(ML)
    arb["fanduel"] = (2.10, 1.80)
    arb["betmgm"] = (1.80, 2.10)
    for at, payload in ((NOW, world()), (NOW + 100, world(arb))):
        read(payload=tp.only(payload, "h2h"), clock=to.Clock(at))
        for kw in ({}, {"credit_book": "dk", "amount": 250}):
            v = view(now=at + 30, **kw)
            assert v["rows"], kw
            for s in strings(v):
                low = s.lower()
                for w in BANNED:
                    assert w not in low, (w, s)
                assert not re.search(r"\block(s)?\b", low), s
    assert "a price and not a risk" in lowholdview.COST_MEANS
    assert "check both prices at the books before you bet" in lowholdview.NOTE


# ================================================================ the pairing's own helpers

def test_total_for_stakes_the_named_leg_exactly_the_amount():
    pair = lowhold.Pairing([lowhold.Quote("a", "x", 2.05), lowhold.Quote("b", "y", 1.95)],
                           1 / 2.05 + 1 / 1.95 - 1)
    for index in (0, 1):
        total = pair.total_for(index, 500.0)
        assert pair.stakes(total)[index]["stake"] == pytest.approx(500.0, abs=0.01)


def test_kept_back_is_what_goes_in_less_what_comes_back_and_negative_for_an_arbitrage():
    cost = lowhold.Pairing([lowhold.Quote("a", "x", 1.95), lowhold.Quote("b", "y", 1.95)], 2 / 1.95 - 1)
    arb = lowhold.Pairing([lowhold.Quote("a", "x", 2.10), lowhold.Quote("b", "y", 2.10)], 2 / 2.10 - 1)
    assert cost.kept_back(1000) == pytest.approx(1000 - 1000 / (2 / 1.95), abs=0.01)
    assert arb.kept_back(1000) == pytest.approx(1000 - 1000 / (2 / 2.10), abs=0.01)
    assert cost.kept_back(1000) > 0 > arb.kept_back(1000)
    assert cost.kept_back(1000) < cost.cost_of(1000), "cost_of reads the hold off the stake and is a little high"
