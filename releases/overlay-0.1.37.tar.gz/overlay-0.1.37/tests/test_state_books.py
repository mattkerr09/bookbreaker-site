"""Every "bet here" is at a sportsbook licensed in the person's state.

`oddsapi.BETTABLE` is the US list: books a person can use somewhere in a regulated state. It is not the list for any
one state. Before 0.1.26 the board, the Odds screen, Low hold, the row detail, the promo converter's hedge, Ask and
alerts all drew their best prices from the US list, so a Michigan profile could be told the best price was at Bally
Bet or a Hard Rock Bet feed, neither licensed in Michigan. `oddsapi.bettable_in(state)` narrows the list with the
jurisdiction table (`catalog.VENUES[...].available_in`), and every one of those paths now takes it.
"""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

import test_oddsapi as to  # noqa: E402
import test_parity_grid as pg  # noqa: E402
from overlay_engine import board, catalog, cli, oddsapi, promoconv, screen  # noqa: E402

OFFSHORE = ("pinnacle", "betonlineag", "bovada", "mybookieag", "lowvig", "betus", "betfair", "betfair_ex_eu")
NOT_IN_MI = {"ballybet", "hardrockbet", "hardrockbet_az", "hardrockbet_fl", "hardrockbet_oh"}


@pytest.fixture
def home(monkeypatch, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def world_with_unlicensed_best():
    """The grid test's game, plus Bally Bet and Hard Rock (AZ) posting the best Chiefs and Over prices."""
    [ev] = pg.world()
    ev["bookmakers"] += [pg.full_book("ballybet", ml=(2.40, 1.70), total=(47.5, 2.05, 1.80)),
                         pg.full_book("hardrockbet_az", ml=(2.35, 1.72), total=(47.5, 2.02, 1.82))]
    return [ev]


def read(state_world=None):
    return pg.read(payload=state_world or world_with_unlicensed_best())


# ------------------------------------------------------------ the list itself

def test_michigan_gets_the_books_its_regulator_licenses_and_no_others():
    mi = oddsapi.bettable_in("MI")
    assert {"dk", "fd", "mgm", "caesars", "betrivers", "fanatics", "betparx", "espnbet"} <= mi
    assert not mi & NOT_IN_MI


def test_a_hard_rock_feed_is_a_bet_only_in_its_own_state():
    assert "hardrockbet_az" in oddsapi.bettable_in("AZ") and "hardrockbet_az" not in oddsapi.bettable_in("OH")
    assert "hardrockbet_oh" in oddsapi.bettable_in("OH") and "hardrockbet_oh" not in oddsapi.bettable_in("AZ")


def test_no_state_ever_lets_an_offshore_book_be_a_bet():
    for st in list(catalog.STATE_NAMES) + [None]:
        assert not oddsapi.bettable_in(st) & set(OFFSHORE), st
        assert oddsapi.bettable_in(st) <= set(oddsapi.BETTABLE), st


def test_a_state_without_legal_online_betting_gets_no_book():
    assert oddsapi.bettable_in("CA") == set()


def test_with_no_state_every_us_book_and_a_sentence_asking_for_one():
    assert oddsapi.bettable_in(None) == set(oddsapi.BETTABLE) == oddsapi.bettable_in("")
    assert oddsapi.books_for(None)["sentence"] == oddsapi.NO_STATE
    assert "Pick your state" in oddsapi.NO_STATE
    said = oddsapi.books_for("mi")
    assert said["state"] == "MI" and said["sentence"] == "" and set(said["books"]) == oddsapi.bettable_in("MI")


# ------------------------------------------------------------ a Michigan profile, end to end

def _best_books(grid_json):
    for g in grid_json["grids"]:
        for game in g["games"]:
            for row in game["rows"]:
                yield from (row["best"] or {}).get("books", [])
                yield from (b for b, c in row["cells"].items() if c.get("best"))


def test_the_world_is_built_so_an_unlicensed_book_would_be_best_without_a_state(home):
    got, _ = read()
    assert set(_best_books(screen.from_refresh(got, oddsapi.bettable_in(None)))) & NOT_IN_MI


def test_a_michigan_profile_never_sees_a_best_price_at_a_book_not_licensed_in_michigan(home):
    got, _ = read()
    best = set(_best_books(screen.from_refresh(got, oddsapi.bettable_in("MI"))))
    assert best and not best & NOT_IN_MI and best <= oddsapi.bettable_in("MI")


def test_a_michigan_board_never_puts_a_leg_or_a_detail_best_at_an_unlicensed_book(home):
    got, _ = read()
    mi = oddsapi.bettable_in("MI")
    rows = board.scan(oddsapi.split_by_line(got.markets), oddsapi.books_table(), now=got.now, bettable=mi,
                      detail=True, names=got.book_names)
    assert rows
    for row in rows:
        d = row.as_dict()
        for leg in d["legs"]:
            assert leg["book"] in mi, (d["kind"], leg["book"])
        detail = d.get("detail") or {}
        for side in detail.get("ev_by_book") or []:
            for line in side["rows"]:
                assert line["book"] in mi, line["book"]
        for r in (detail.get("table") or {}).get("rows", []):
            assert not (r["bettable"] and r["book"] not in mi), r["book"]
            if r["book"] in NOT_IN_MI:
                assert not any(isinstance(c, dict) and c.get("best") for c in r["prices"])


def test_the_cli_screen_and_low_hold_take_the_state_and_say_it(home, capsys):
    read()
    assert cli.main(["board", "--feed", "oddsapi", "--screen", "--state", "MI", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["books_for"]["state"] == "MI" and out["books_for"]["sentence"] == ""
    assert not set(_best_books(out["screen"])) & NOT_IN_MI
    assert cli.main(["board", "--feed", "oddsapi", "--screen", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["books_for"]["sentence"] == oddsapi.NO_STATE
    assert cli.main(["board", "--feed", "oddsapi", "--lowhold", "--state", "MI", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["books_for"]["state"] == "MI"
    for r in out["lowhold"]["rows"]:
        for leg in r["legs"]:
            assert leg["book"] not in NOT_IN_MI


def test_the_promo_hedge_is_only_at_a_book_licensed_in_the_state(home):
    got, _ = read()
    snaps = promoconv._read(None, got.now)[0]
    if not snaps:
        pytest.skip("no stored read for the converter in this fixture")
    hedges = {c["hedge_book"] for c in promoconv._candidates("dk", snaps, got.now, oddsapi.bettable_in("MI"))}
    assert hedges and not hedges & NOT_IN_MI
    anywhere = {c["hedge_book"] for c in promoconv._candidates("dk", snaps, got.now, oddsapi.bettable_in(None))}
    assert anywhere & NOT_IN_MI, "without a state the same read hedges at an unlicensed book, so the test means something"
