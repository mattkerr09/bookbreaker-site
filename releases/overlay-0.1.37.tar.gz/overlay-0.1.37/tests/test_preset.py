"""The Recommended preset: a safe default for the board.

OddsJam ships a "Recommended filters" preset that is on for everyone and warns
before it is turned off: main markets only, a minimum amount on offer, a maximum
price, a maximum market width. It stops a new bettor chasing the biggest number
on the thinnest market. This is Bookbreaker's version, with three differences
that are each held here:

  * **the engine flags and the window hides.** Every play is sent, marked
    recommended or not and why, so turning the preset off re-draws what is
    already on screen and never asks for a second read (a read of live sportsbook
    odds spends the person's credits);
  * **what the engine does not know passes.** A sportsbook's price carries no
    amount on offer, so only a number the engine has can mark a play down;
  * **the numbers are constants with a boundary**, and the window prints the
    engine's sentences and holds no threshold of its own.
"""

import datetime as dt
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine import board, cli, preset, xvenue  # noqa: E402
from overlay_engine.models import Market, Outcome, Quote  # noqa: E402
from overlay_engine.odds import american_to_decimal  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()

NOW = 1_800_000_000.0
BANNED = ("guaranteed", "risk-free", "risk free", "riskfree", "either way")


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def dec(american: float) -> float:
    return american_to_decimal(american)


def market(prices: dict, mtype: str = "totals", line: float = 220.5) -> Market:
    """One market: each book's (over, under) decimal prices, all confirmed a few seconds before NOW."""
    quotes = []
    for book, (over, under) in prices.items():
        quotes.append(Quote(book=book, outcome=Outcome("over", line), decimal=over, seen_at=NOW - 6))
        quotes.append(Quote(book=book, outcome=Outcome("under", line), decimal=under, seen_at=NOW - 6))
    return Market(event_id="e1", sport="nba", market_type=mtype, quotes=quotes)


def rows_of(m: Market, kinds=("arb", "ev")):
    from overlay_engine.cli import DEFAULT_BOOKS
    return board.scan([m], DEFAULT_BOOKS, now=NOW, kinds=kinds)


#: Pinnacle prices it evenly; DraftKings and FanDuel disagree enough to make both an arb and a +EV bet.
NORMAL = {"pinnacle": (1.95, 1.95), "dk": (2.10, 1.80), "fd": (1.80, 2.05)}


# ================================================================ the four rules and their numbers

def test_the_numbers_are_engine_constants():
    assert preset.MAIN_MARKETS == ("h2h", "spreads", "totals", "moneyline")
    assert preset.MIN_ON_OFFER == 100.0
    assert preset.MAX_AMERICAN == 300
    assert preset.MAX_WIDTH_CENTS == 40
    assert preset.NAME == "Recommended"


def test_each_rule_the_engine_states_carries_its_own_number():
    rules = " ".join(preset.RULES)
    assert f"+{preset.MAX_AMERICAN}" in rules and f"${preset.MIN_ON_OFFER:,.0f}" in rules
    assert f"{preset.MAX_WIDTH_CENTS} cents" in rules and "moneylines, spreads and totals" in rules
    assert len(preset.RULES) == 4
    for label in preset.LABELS.values():
        assert label and not any(b in label.lower() for b in BANNED)


def test_main_markets_pass_and_everything_else_does_not():
    for kind in ("h2h", "spreads", "totals", "moneyline"):
        assert not [m for m in preset.misses(kind, [1.9]) if m["code"] == "market"], kind
    # `h2h_q1` is a first quarter: a market class guessed from the name would call it a moneyline.
    for kind in ("player_pass_yds", "player_points", "player_points_alternate", "h2h_q1", "alternate_spreads",
                 "outright_winner", "a market this version has never heard of", ""):
        assert [m["code"] for m in preset.misses(kind, [1.9]) if m["code"] == "market"] == ["market"], kind


def test_a_price_longer_than_plus_300_is_a_longshot_and_plus_300_itself_is_not():
    assert preset.misses("h2h", [dec(300)]) == []
    assert [m["code"] for m in preset.misses("h2h", [dec(301)])] == ["price"]
    assert [m["code"] for m in preset.misses("h2h", [dec(150), dec(450)])] == ["price"], "any one leg is enough"
    assert preset.misses("h2h", [dec(-500)]) == [], "a short favourite is not a longshot"
    assert "+450" in preset.misses("h2h", [dec(450)])[0]["text"]
    assert preset.misses("h2h", [1.0]) == [], "a contract at 100 cents is not a price, and not a longshot"


def test_less_than_100_dollars_on_offer_is_too_thin_and_exactly_100_is_not():
    assert preset.misses("h2h", [2.0], [100.0]) == []
    got = preset.misses("h2h", [2.0], [5000.0, 99.99])
    assert [m["code"] for m in got] == ["size"] and "Only $99 is on offer, under the $100" in got[0]["text"]
    assert [m["code"] for m in preset.misses("h2h", [2.0], [10.0])] == ["size"]


def test_an_amount_the_venue_does_not_publish_passes():
    """A sportsbook's price carries no size. Marking it down for that would hide every sportsbook play."""
    assert preset.misses("h2h", [2.0], None) == []
    assert preset.misses("h2h", [2.0], [None, None]) == []
    assert [m["code"] for m in preset.misses("h2h", [2.0], [None, 40.0])] == ["size"], "a size the engine has still counts"


def test_a_market_wider_than_40_cents_is_marked_and_40_itself_is_not():
    assert preset.misses("h2h", [2.0], None, 40.0) == []
    got = preset.misses("h2h", [2.0], None, 40.1)
    assert [m["code"] for m in got] == ["width"] and "40.1 cents wide, wider than the 40" in got[0]["text"]
    assert preset.misses("h2h", [2.0], None, None) == [], "a width the engine cannot tell passes"


def test_a_play_can_miss_for_several_reasons_and_each_is_named():
    got = preset.misses("player_points", [dec(500)], [20.0], 80.0)
    assert [m["code"] for m in got] == ["market", "price", "size", "width"]
    assert all(m["text"].endswith(".") and not any(b in m["text"].lower() for b in BANNED) for m in got)


# ================================================================ the width

def test_width_is_the_dime_line_a_bettor_reads_off_the_two_prices():
    assert preset.width_cents(dec(-110), dec(-110)) == pytest.approx(20)
    assert preset.width_cents(dec(105), dec(-125)) == pytest.approx(20)
    assert preset.width_cents(dec(-120), dec(100)) == pytest.approx(20)
    assert preset.width_cents(dec(-115), dec(-105)) == pytest.approx(20)
    assert preset.width_cents(dec(-120), dec(-120)) == pytest.approx(40)
    assert preset.width_cents(dec(-140), dec(-140)) == pytest.approx(80)
    assert preset.width_cents(dec(120), dec(-182)) == pytest.approx(62)


def test_a_markets_width_is_the_middle_of_what_the_books_that_quote_both_sides_say():
    m = market({"pinnacle": (dec(-105), dec(-105)), "dk": (dec(-110), dec(-110)), "fd": (dec(-150), dec(-130))})
    assert preset.market_width(m) == pytest.approx(20, abs=0.1), "the middle book, not the widest or the mean"
    assert preset.market_width(market({"dk": (dec(-110), dec(-110))})) == pytest.approx(20, abs=0.1)


def test_a_market_with_no_book_quoting_both_sides_or_more_than_two_sides_has_no_width():
    one_sided = Market("e1", "nba", "totals", [Quote("dk", Outcome("over", 220.5), 1.9, NOW),
                                                Quote("fd", Outcome("under", 220.5), 1.9, NOW)])
    assert preset.market_width(one_sided) is None
    three_way = Market("e1", "soccer", "h2h", [Quote("dk", Outcome(n), 3.0, NOW) for n in ("home", "draw", "away")])
    assert preset.market_width(three_way) is None


# ================================================================ the rows are flagged, never dropped

def test_a_plain_main_market_play_is_recommended():
    rows = rows_of(market(NORMAL))
    assert {r.kind for r in rows} == {"arb", "ev"}
    for row in rows:
        assert row.preset_misses == [] and row.as_dict()["recommended"] is True


def test_the_same_prices_on_a_prop_are_flagged_not_main_and_still_sent():
    plain, prop = rows_of(market(NORMAL)), rows_of(market(NORMAL, mtype="player_points"))
    assert len(prop) == len(plain), "the preset hides nothing: every play is still sent"
    for row in prop:
        d = row.as_dict()
        assert d["recommended"] is False and [m["code"] for m in d["preset_misses"]] == ["market"]


def test_a_longshot_leg_flags_an_arb_and_an_ev_bet_alike():
    rows = rows_of(market({"pinnacle": (3.2, 1.35), "dk": (5.60, 1.12), "fd": (1.15, 5.00)}))
    assert rows
    for row in rows:
        longest = max(leg["decimal"] for leg in row.legs)
        assert (longest > 4.0) is any(m["code"] == "price" for m in row.preset_misses), (row.kind, row.legs)
    assert any(r.kind == "arb" and not r.as_dict()["recommended"] for r in rows)


def test_a_wide_market_flags_its_plays():
    rows = rows_of(market({"dk": (2.40, 1.50), "fd": (1.50, 2.40)}), kinds=("arb",))
    [row] = rows
    assert [m["code"] for m in row.preset_misses] == ["width"] and "wider than the 40" in row.preset_misses[0]["text"]


def test_a_middle_is_judged_on_its_market_and_its_prices_and_never_on_a_width():
    from overlay_engine.cli import DEFAULT_BOOKS
    low = market({"dk": (dec(-110), dec(-110))}, line=219.5)
    high = market({"fd": (dec(-110), dec(-110))}, line=221.5)
    joined = Market("e1", "nba", "totals", low.quotes + high.quotes)
    rows = board.scan([joined], DEFAULT_BOOKS, now=NOW, kinds=("middle",), bankroll=1000.0)
    assert rows and all(r.kind == "middle" and r.preset_misses == [] for r in rows)
    props = Market("e1", "nba", "player_points", joined.quotes)
    assert all([m["code"] for m in r.preset_misses] == ["market"]
               for r in board.scan([props], DEFAULT_BOOKS, now=NOW, kinds=("middle",), bankroll=1000.0))


def test_a_row_dict_carries_the_flag_and_the_reasons():
    d = rows_of(market(NORMAL, mtype="player_points"))[0].as_dict()
    assert {"recommended", "preset_misses"} <= set(d)
    assert json.loads(json.dumps(d))["preset_misses"][0]["code"] == "market"


# ================================================================ live pairs: the amount on offer is known

def _pairing(size_k=9999, size_p=9999, kalshi=(0.60, 0.40), pm=(0.50, 0.62)):
    when = dt.date(2026, 10, 22)
    teams = ("CHI", "PIT")
    k = xvenue.Game("kalshi", teams, when, {"CHI": kalshi[0], "PIT": kalshi[1]}, "KX", league="nhl",
                    size={t: size_k for t in teams}, read_at=NOW - 5)
    p = xvenue.Game("polymarket_us", teams, when, {"CHI": pm[0], "PIT": pm[1]}, "aec-nhl-chi-pit-2026-10-22",
                    league="nhl", size={t: size_p for t in teams}, long="CHI", fee_rate=0.0695, read_at=NOW - 5,
                    starts_at=NOW + 86400, depth_at={t: NOW - 5 for t in teams})
    return [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]


def test_a_pair_with_plenty_on_offer_at_ordinary_prices_is_recommended():
    [pair] = _pairing()
    assert pair.preset_misses == [] and pair.as_dict()["recommended"] is True


def test_a_pair_with_little_resting_at_a_price_is_flagged_thin():
    [pair] = _pairing(size_p=20)
    assert [m["code"] for m in pair.preset_misses] == ["size"]
    assert "under the $100" in pair.preset_misses[0]["text"]


def test_a_pair_leg_priced_as_a_longshot_is_flagged():
    [pair] = _pairing(kalshi=(0.10, 0.90), pm=(0.5, 0.05))
    assert "price" in [m["code"] for m in pair.preset_misses]


def test_the_live_scan_says_what_the_preset_does_to_its_pairs():
    pairs = _pairing(size_p=20)
    scan = xvenue.Scan(NOW, 1000.0, {"nhl": {"kalshi_games": 1, "polymarket_us_games": 1, "matched": 1}},
                       len(pairs), pairs, [], state="PA")
    out = scan.as_dict()
    assert out["pairs"][0]["recommended"] is False
    assert out["preset"]["hidden"] == 1 and out["preset"]["kept"] == 0 and out["preset"]["hidden_by"][0]["code"] == "size"


# ================================================================ what it says about itself

def test_the_summary_counts_in_the_engines_words():
    a, b, c = [], [{"code": "market", "text": "x"}], [{"code": "market", "text": "x"}, {"code": "price", "text": "y"}]
    s = preset.summary([a, b, c, a])
    assert (s["total"], s["kept"], s["hidden"]) == (4, 2, 2)
    assert [(x["code"], x["count"]) for x in s["hidden_by"]] == [("market", 2), ("price", 1)]
    assert s["sentence"] == ("Recommended hides 2 of 4 plays (not a main market: 2; priced longer than +300: 1). "
                             "A play can fall under more than one.")
    assert s["sentence_off"].startswith("Recommended would hide 2 of 4 plays") and "marked, with the reason" in s["sentence_off"]
    assert s["rules"] == preset.RULES and s["why"] == preset.WHY


def test_the_summary_of_nothing_hidden_and_of_nothing_at_all():
    assert preset.summary([[], []])["sentence"] == "Recommended keeps all 2 plays."
    assert preset.summary([[]])["sentence"] == "Recommended keeps all 1 play."
    assert preset.summary([])["sentence"] == "" and preset.summary([])["total"] == 0


def test_the_demo_board_carries_the_summary_with_every_row_still_in_it(capsys):
    assert cli.main(["board", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["preset"]["total"] == len(out["rows"]) and out["preset"]["kept"] + out["preset"]["hidden"] == len(out["rows"])
    assert all("recommended" in r for r in out["rows"])


def test_why_it_is_on_is_one_sentence_and_the_window_asks_with_those_words():
    assert preset.WHY.count(". ") == 0 and preset.WHY.endswith(".") and "\n" not in preset.WHY
    ask = re.search(r'<div class="presetask"[^>]*>\s*<p>(.*?)</p>', HTML, re.S).group(1)
    assert re.sub(r"\s+", " ", ask).strip() == preset.WHY, "the window's question is the engine's own sentence"
    assert not any(b in preset.WHY.lower() for b in BANNED)


# ================================================================ the window

def test_the_switch_is_on_the_arbitrage_page_and_on_by_default():
    panel = HTML[HTML.index('id="panel-board"'):HTML.index('id="panel-odds"')]
    assert re.search(r'<input id="b-preset" type="checkbox" checked>', panel) and "Recommended" in panel
    assert 'store.get("bb.preset", true) !== false' in JS, "the preset is on unless the person turned it off"
    assert 'store.set("bb.preset", on)' in _braced(JS, "function setPreset(")
    assert "Changing it reads nothing." in panel


def test_turning_it_off_asks_first_and_only_the_answer_turns_it_off():
    restore = _braced(JS, "(function restorePreset()")
    change = restore[restore.index('addEventListener("change"'):restore.index('getElementById("preset-keep")')]
    assert "setPreset(false)" not in change, "the switch itself never turns it off"
    assert "ev.target.checked = true;" in change and "askPreset();" in change
    assert 'getElementById("preset-off").addEventListener("click", () => setPreset(false))' in restore
    assert 'hidden = true' in restore, "keeping it on closes the question"
    ask = HTML[HTML.index('id="preset-ask"'):HTML.index("</div>", HTML.index('id="preset-ask"'))]
    assert "hidden" in HTML[HTML.index('id="preset-ask"') - 40:HTML.index('id="preset-ask"') + 120]
    assert 'id="preset-keep"' in ask and "Keep it on" in ask and 'id="preset-off"' in ask and "Turn it off" in ask
    assert JS.count("setPreset(false)") == 1, "one way off, and it is the answer to the question"
    assert "data-preset" in JS and 'askPreset(); else setPreset(true)' in JS, "a link to turn it off asks too"


def test_switching_it_reads_nothing_and_asks_the_engine_for_nothing():
    for fn in ("setPreset", "askPreset", "presetLine", "presetEmptyHTML", "presetHidesAll", "presetOf"):
        text = JS[JS.index(f"function {fn}(") if f"function {fn}(" in JS else JS.index(f"const {fn} "):]
        body = _braced(text, "{") if fn != "presetOf" else text[:text.index("\n\n")]
        for call in ("run(", "invoke(", "fetch(", "await", "AGAIN"):
            assert call not in body, (fn, call)
    assert "drawBoard(document.getElementById(\"out-board\"), 0)" in _braced(JS, "function setPreset(")
    assert "recommended" not in "".join(re.findall(r'^\s+[a-z]+: \(\) => \[.*$', JS, re.M)), "no engine call is told the preset"


def test_the_window_shows_or_hides_by_the_engines_flag_and_holds_no_threshold():
    assert "const shownByPreset = (p) => !PRESET.on || p.recommended;" in JS
    assert "recommended: r.recommended !== false" in JS
    block = JS[JS.index("const PRESET = {"):JS.index("function drawBoard(")]
    assert not re.search(r"\b(100|300|400|500|40)\b", block), "a threshold written in the window is a second preset"
    assert not re.search(r"american|decimal|\.margin|\.width|on_offer|market_type", block)


def test_a_play_shown_while_the_preset_is_off_says_why_it_would_have_been_hidden():
    console = _braced(JS, "function consoleHTML(")
    assert "Not recommended" in console and "p.misses.map(esc).join" in console and "Recommended is off, so it is shown." in console
    assert "misses: (r.preset_misses || []).map((m) => m.text)" in JS
    assert "not recommended" in _braced(JS, "function listCard(")


def test_a_board_the_preset_empties_says_so_rather_than_that_nothing_is_there():
    assert "presetHidesAll()" in _braced(JS, "function consoleHTML(")
    assert "Recommended is hiding every play on this board" in _braced(JS, "function presetEmptyHTML(")
    assert "BOARD.preset.sentence" in _braced(JS, "function presetEmptyHTML(")
    assert '"All hidden by Recommended"' in _braced(JS, "function drawBoard(")
    assert "presetLine()" in _braced(JS, "function drawBoard(") and "pre.sentence_off" in _braced(JS, "function presetLine(")


def test_every_board_the_window_draws_carries_the_engines_summary():
    assert "preset: xv.preset" in _braced(JS, "function showBoard(")
    assert "preset: out.preset }" in _braced(JS, "function showBoard(")
    assert "preset: out.preset, asOf: out.as_of" in _braced(JS, "function showOddsboard(")


def test_every_class_the_preset_draws_is_styled():
    for rule in (r"\.presetask", r"\.srcline \.read\.off", r"\.statepick select"):
        # A rule of its own: `.presetaskx{` is not one for `.presetask`, and neither is `.presetask p{`.
        assert re.search(r"(?:^|[},\s])" + rule + r"\s*[,{]", CSS, re.M), f"{rule} has no rule of its own in app.css"
    for cls in ("presetask", "read off", "linkish"):
        assert f'class="{cls}' in JS or f'class="{cls}' in HTML, cls


def test_the_preset_never_promises_what_it_cannot():
    text = " ".join(preset.RULES) + preset.WHY + preset.summary([[{"code": "market", "text": "x"}]])["sentence"]
    assert not any(b in text.lower() for b in BANNED)
    window = HTML[HTML.index('id="preset-ask"'):HTML.index('id="out-board"')]
    assert not any(b in window.lower() for b in BANNED)
