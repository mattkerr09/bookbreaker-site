"""The line history chart, the engine's side: one book's price on one side of a market over the reads
kept on this Mac, the fair price beside it, and the person's own bet marked.

What these pin:

  * a line needs two reads, and fewer says "No history yet" (with the count) and draws nothing;
  * the line steps: a price is held until the next read, so the path only ever goes across and then
    up or down, and a better price is higher on the chart;
  * the fair price at the last read is the fair price the row's own detail shows, not a second one;
  * the person's bet is marked only on the side and market it was placed on, at the price they got,
    and a bet outside the span of the reads is drawn at the edge and says so;
  * reads taken after the game started are not the line a person bets into;
  * it reads files and nothing else, and leaves the ledger as it found it.
"""

import contextlib
import hashlib
import io
import json
import os
import re
import socket
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ask_fixtures as fx  # noqa: E402
import test_oddsapi as to  # noqa: E402
import test_parity_grid as tp  # noqa: E402

from overlay_engine import cli, keystore, linehistory, oddsapi  # noqa: E402
from overlay_engine.ledger import Ledger  # noqa: E402
from overlay_engine.linehistory import LineHistory  # noqa: E402
from overlay_engine.models import Market  # noqa: E402

NOW = to.NOW
BANNED = ("guaranteed", "risk-free", "risk free", "riskfree", "either way")
HOME, AWAY = "Kansas City Chiefs", "Buffalo Bills"
STEP = 5400.0


def h2h(dk_home, dk_away, fd=(1.80, 2.05), pin=(1.95, 1.95)):
    return [("dk", HOME, None, dk_home), ("dk", AWAY, None, dk_away),
            ("fd", HOME, None, fd[0]), ("fd", AWAY, None, fd[1]),
            ("pinnacle", HOME, None, pin[0]), ("pinnacle", AWAY, None, pin[1])]


def reads(prices, event="g1", start=None, market="h2h", t0=None, step=STEP):
    t0 = NOW - len(prices) * step if t0 is None else t0
    return [fx.read("americanfootball_nfl", "nfl", t0 + i * step, f"{AWAY} at {HOME}", market, h2h(*p), event=event,
                    starts=start or NOW + 3600) for i, p in enumerate(prices)]


@pytest.fixture
def folder(tmp_path):
    return tmp_path / "history"


def books():
    return oddsapi.books_table()


def names(key):
    return {"dk": "DraftKings", "fd": "FanDuel", "pinnacle": "Pinnacle"}.get(key, key)


def market(event="g1", kind="h2h"):
    return Market(event_id=event, sport="americanfootball_nfl", market_type=kind, quotes=[])


def chart(folder, leg=("dk", HOME), kind="ev", ledger=None, event="g1", mkt="h2h"):
    hist = LineHistory.from_disk(folder, ledger, now=NOW)
    return hist.chart(market(event, mkt), leg[0], leg[1], kind, books(), names)


def numbers(path):
    return [float(n) for n in re.findall(r"-?\d+\.?\d*", path)]


# ------------------------------------------------------------ a line needs two reads

def test_no_reads_at_all_says_no_history_yet_and_draws_nothing(folder):
    got = chart(folder)
    assert got["available"] is False and got["reads"] == 0 and "chart" not in got
    assert got["why"].startswith("No history yet.") and "has not read DraftKings" in got["why"]


def test_one_read_is_a_point_not_a_line(folder):
    fx.write_history(folder, reads([(2.0, 1.9)]))
    got = chart(folder)
    assert got["available"] is False and got["reads"] == 1 and "chart" not in got
    assert got["why"].startswith("No history yet.") and "once" in got["why"]


def test_two_reads_are_enough_for_a_line(folder):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.85)]))
    got = chart(folder)
    assert got["available"] is True and got["reads"] == 2 and "why" not in got


def test_a_book_that_never_quoted_the_side_has_no_history_even_if_others_did(folder):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.85), (2.1, 1.85)]))
    got = chart(folder, leg=("mgm", HOME))
    assert got["available"] is False and got["reads"] == 0


def test_a_prop_market_says_no_history_yet_and_that_props_are_not_kept(folder):
    got = chart(folder, mkt="player_points")
    assert got["why"].startswith("No history yet.") and "player props are not kept" in got["why"]


# ------------------------------------------------------------ the line itself

STEP_PATH = re.compile(r"^M-?[\d.]+ -?[\d.]+( H-?[\d.]+ V-?[\d.]+)+$")


def test_the_line_steps_across_then_up_or_down_and_never_slopes(folder):
    fx.write_history(folder, reads([(2.0, 1.9), (2.0, 1.9), (2.1, 1.85), (2.05, 1.85)]))
    path = chart(folder)["chart"]["price"]["path"]
    assert STEP_PATH.match(path), path
    assert " L" not in path and "C" not in path


def test_a_better_price_is_higher_on_the_chart_and_a_price_held_is_level(folder):
    fx.write_history(folder, reads([(2.0, 1.9), (2.0, 1.9), (2.2, 1.9)]))
    c = chart(folder)["chart"]
    start_y = float(c["price"]["path"].split()[1])
    ys = [float(v) for v in re.findall(r"V(-?[\d.]+)", c["price"]["path"])]
    assert ys[0] == start_y, "an unchanged price stays on the same level"
    assert ys[1] < start_y, "a bigger price is nearer the top (y counts down from the top)"
    assert c["price"]["first"] == 100 and c["price"]["last"] == 120


def test_every_point_is_inside_the_plot(folder):
    fx.write_history(folder, reads([(2.0, 1.9), (2.4, 1.9), (1.7, 1.9), (2.0, 1.9)]))
    c = chart(folder)["chart"]
    p, path = c["plot"], c["price"]["path"]
    xs = [float(v) for v in re.findall(r"[MH](-?[\d.]+)", path)]
    assert min(xs) >= p["x"] and max(xs) <= p["x2"]
    ys = [float(path.split()[1])] + [float(v) for v in re.findall(r"V(-?[\d.]+)", path)]
    assert all(p["y"] <= y <= p["y2"] for y in ys)
    assert c["price"]["end"]["x"] == p["x2"], "the last read is at the right edge"


def test_the_axes_are_labelled_with_american_prices_that_run_from_top_to_bottom(folder):
    fx.write_history(folder, reads([(2.0, 1.9), (2.3, 1.9), (1.8, 1.9)]))
    c = chart(folder)["chart"]
    labels = [t["american"] for t in sorted(c["y_ticks"], key=lambda t: t["y"])]
    assert labels == sorted(labels, reverse=True), "the top of the chart is the biggest price"
    assert [t["anchor"] for t in c["x_ticks"]] == ["start", "middle", "end"]
    assert c["x_ticks"][0]["x"] == c["plot"]["x"] and c["x_ticks"][-1]["x"] == c["plot"]["x2"]


def test_the_words_say_the_first_price_seen_is_not_the_opener(folder):
    fx.write_history(folder, reads([(2.0, 1.9), (2.2, 1.9)]))
    got = chart(folder)
    assert "from +100 to +120 over 2 reads" in got["text"]
    assert "the first time this Mac read it" in got["text"] and "not necessarily the opener" in got["text"]
    assert "held" in chart(folder, leg=("fd", AWAY))["text"], "FanDuel's Bills price never moved"


def test_a_long_history_is_thinned_but_keeps_the_first_and_the_last(folder):
    # 150 reads a minute apart, inside the week the history draws; the price runs 100, 101, ... 106 and round again.
    prices = [(2.0 + (i % 7) * 0.01, 1.9) for i in range(150)]
    fx.write_history(folder, reads(prices, t0=NOW - 150 * 60.0, step=60.0))
    got = chart(folder)
    assert got["reads"] == 150
    assert got["chart"]["price"]["path"].count(" V") + 1 == linehistory.MAX_POINTS
    assert f"Drawn from {linehistory.MAX_POINTS} of the 150 reads" in got["text"]
    assert got["chart"]["price"]["end"]["x"] == got["chart"]["plot"]["x2"]
    assert got["chart"]["price"]["first"] == 100 and got["chart"]["price"]["last"] == 100 + 149 % 7


def test_only_the_last_seven_days_are_drawn(folder):
    old = reads([(2.0, 1.9)], t0=NOW - 9 * 86400)
    new = reads([(2.1, 1.9), (2.2, 1.9)], t0=NOW - 3 * STEP)
    fx.write_history(folder, old + new)
    assert chart(folder)["reads"] == 2


# ------------------------------------------------------------ the fair price

def test_the_fair_line_is_drawn_beside_the_price_and_a_middle_has_none(folder):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.85), (2.1, 1.85)]))
    got = chart(folder)
    assert got["chart"]["fair"]["label"] == "Fair price" and STEP_PATH.match(got["chart"]["fair"]["path"])
    mid = chart(folder, kind="middle")
    assert mid["chart"]["fair"] is None and "no one fair price" in mid["note"]


def test_the_fair_price_is_worked_out_at_each_read_from_that_reads_own_books(folder):
    # Pinnacle's price moves, DraftKings' does not: the fair price must move with the sharp book.
    fx.write_history(folder, reads([(2.0, 1.9, (1.80, 2.05), (1.95, 1.95)), (2.0, 1.9, (1.80, 2.05), (1.80, 2.15))]))
    c = chart(folder)["chart"]
    assert c["fair"]["first"] != c["fair"]["last"], "the fair price followed the market"
    assert c["price"]["first"] == c["price"]["last"] == 100


def test_the_fair_price_is_drawn_only_where_the_books_price_is(folder):
    rs = reads([(2.0, 1.9), (2.0, 1.9), (2.1, 1.9)])
    fx.write_history(folder, rs)
    c = chart(folder)["chart"]
    assert c["fair"]["end"]["x"] == c["price"]["end"]["x"]


# ------------------------------------------------------------ games that have started

def test_a_read_taken_after_the_game_started_is_not_part_of_the_line(folder):
    start = NOW - 2 * STEP - 10
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.9), (3.0, 1.2), (3.2, 1.1)], start=start,
                                   t0=NOW - 4 * STEP))
    got = chart(folder)
    assert got["reads"] == 2 and got["chart"]["price"]["last"] == 110, "the in-play prices are left out"


# ------------------------------------------------------------ the person's own bet

def make_ledger(path, bets):
    with Ledger(str(path)) as led:
        for ev, mkt, outcome, book, dec, placed in bets:
            led.import_bet(event_id=ev, sport="americanfootball_nfl", market_type=mkt, outcome=outcome, book=book,
                           decimal_odds=dec, stake=50.0, placed_at=placed)
    return path


def test_a_bet_on_this_side_and_market_is_marked_at_the_price_they_got(folder, tmp_path):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.9), (2.2, 1.9)]))
    t = NOW - 3 * STEP + STEP
    led = make_ledger(tmp_path / "overlay.db", [("g1", "h2h", HOME, "dk", 2.1, t)])
    c = chart(folder, ledger=led)["chart"]
    assert len(c["mine"]) == 1
    m = c["mine"][0]
    assert m["american"] == 110 and m["edge"] is None
    second_y = float(re.findall(r"V(-?[\d.]+)", c["price"]["path"])[0])
    assert m["y"] == second_y, "the bet sits on the line at the read it matched"
    assert "Your bet: +110 at DraftKings for $50.00" in m["label"]


def test_a_bet_on_the_other_side_another_market_or_another_game_is_not_marked(folder, tmp_path):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.9)]))
    t = NOW - STEP
    led = make_ledger(tmp_path / "overlay.db", [("g1", "h2h", AWAY, "dk", 1.9, t), ("g1", "totals", HOME, "dk", 2.1, t),
                                                 ("g2", "h2h", HOME, "dk", 2.1, t)])
    assert chart(folder, ledger=led)["chart"]["mine"] == []


def test_a_bet_outside_the_span_of_the_reads_is_drawn_at_the_edge_and_says_so(folder, tmp_path):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.9)]))
    led = make_ledger(tmp_path / "overlay.db", [("g1", "h2h", HOME, "dk", 2.05, NOW - 30 * STEP),
                                                 ("g1", "h2h", HOME, "fd", 2.15, NOW + 10 * STEP)])
    c = chart(folder, ledger=led)["chart"]
    before, after = sorted(c["mine"], key=lambda m: m["x"])
    assert before["edge"] == "before" and before["x"] == c["plot"]["x"] and "before the first read" in before["label"]
    assert after["edge"] == "after" and after["x"] == c["plot"]["x2"] and "after the last read" in after["label"]


def test_the_chart_leaves_the_ledger_as_it_found_it(folder, tmp_path):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.9)]))
    led = make_ledger(tmp_path / "overlay.db", [("g1", "h2h", HOME, "dk", 2.1, NOW - STEP)])

    def state():
        # SQLite keeps a shared-memory index (-shm) that any reader of a WAL database touches; it is not the record.
        return {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in tmp_path.iterdir()
                if f.is_file() and not f.name.endswith("-shm")}, sorted(f.name for f in tmp_path.iterdir())
    before = state()
    assert chart(folder, ledger=led)["chart"]["mine"], "the bet was read"
    assert state() == before, "reading the bets must not write the ledger or leave a file beside it"


def test_a_ledger_that_does_not_exist_is_not_created_by_looking_for_bets(folder, tmp_path):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.9)]))
    missing = tmp_path / "never.db"
    assert chart(folder, ledger=missing)["chart"]["mine"] == [] and not missing.exists()


# ------------------------------------------------------------ files and nothing else

def test_drawing_a_chart_opens_no_socket(folder, tmp_path, monkeypatch):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.9)]))
    led = make_ledger(tmp_path / "overlay.db", [("g1", "h2h", HOME, "dk", 2.1, NOW - STEP)])

    def refuse(*a, **k):
        raise AssertionError("the line history reached for the network")
    monkeypatch.setattr(socket, "socket", refuse)
    monkeypatch.setattr(socket, "create_connection", refuse)
    assert chart(folder, ledger=led)["available"] is True


def test_the_module_has_no_http_client_and_no_chart_library():
    text = (Path(linehistory.__file__)).read_text()
    for token in ("urllib", "requests", "http.client", "socket", "matplotlib", "plotly", "pygal"):
        assert token not in text, token


def test_nothing_the_chart_says_is_a_promise(folder, tmp_path):
    fx.write_history(folder, reads([(2.0, 1.9), (2.1, 1.9)]))
    led = make_ledger(tmp_path / "overlay.db", [("g1", "h2h", HOME, "dk", 2.1, NOW - STEP)])
    blob = json.dumps(chart(folder, ledger=led)).lower() + json.dumps(chart(folder, leg=("mgm", HOME))).lower()
    for word in BANNED:
        assert word not in blob, word


# ------------------------------------------------------------ on the board

@pytest.fixture
def board(tmp_path):
    """The board on a fake feed, with four earlier reads of the Chiefs-Bills game already on this Mac."""
    was = os.environ.get("OVERLAY_HOME")
    saved = (oddsapi.odds_api_fetcher, oddsapi.time, keystore.get_key)
    os.environ["OVERLAY_HOME"] = str(tmp_path)
    try:
        fx.write_history(tmp_path / "oddsapi" / "history",
                         reads([(2.0, 1.9), (2.04, 1.88), (2.08, 1.85), (2.10, 1.82)], event="g1", t0=NOW - 5 * STEP))
        make_ledger(tmp_path / "overlay.db", [("g1", "h2h", HOME, "dk", 2.04, NOW - 4 * STEP)])
        api = to.FakeApi({"americanfootball_nfl": tp.world()})
        oddsapi.odds_api_fetcher = lambda *a, **k: api
        oddsapi.time = SimpleNamespace(time=to.Clock())
        keystore.get_key = lambda runner=None: to.KEY
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            assert cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--market", "h2h", "--market", "spreads",
                             "--market", "totals", "--json"]) == 0
        yield json.loads(out.getvalue())
    finally:
        oddsapi.odds_api_fetcher, oddsapi.time, keystore.get_key = saved
        if was is None:
            os.environ.pop("OVERLAY_HOME", None)
        else:
            os.environ["OVERLAY_HOME"] = was


def test_every_row_carries_one_chart_per_leg_in_the_legs_own_order(board):
    rows = board["rows"]
    assert {"arb", "ev", "middle"} <= {r["kind"] for r in rows}
    for r in rows:
        hist = r["detail"]["history"]
        # (a middle's legs are named in lower case by the board and by the quotes' own keys in the detail)
        assert [(h["book"], h["outcome"].lower()) for h in hist] == [(leg["book"], leg["outcome"].lower()) for leg in r["legs"]]


def test_a_row_with_four_earlier_reads_and_the_one_just_taken_has_a_line_with_the_bet_marked(board):
    arb = next(r for r in board["rows"] if r["kind"] == "arb" and r["market"] == "h2h")
    chiefs = next(h for h in arb["detail"]["history"] if h["outcome"] == HOME)
    assert chiefs["available"] and chiefs["reads"] == 5
    assert [m["american"] for m in chiefs["chart"]["mine"]] == [104]
    bills = next(h for h in arb["detail"]["history"] if h["outcome"] == AWAY)
    assert bills["available"] and bills["chart"]["mine"] == []


def test_the_last_point_of_the_fair_line_is_the_fair_price_the_rows_own_detail_shows(board):
    for r in board["rows"]:
        if r["kind"] == "middle" or not r["detail"]["fair"]["available"]:
            continue
        sides = {s["outcome"]: s["american"] for s in r["detail"]["fair"]["sides"]}
        for h in r["detail"]["history"]:
            if h["available"] and h["chart"]["fair"]:
                assert h["chart"]["fair"]["last"] == sides[h["outcome"]], (r["kind"], r["market"], h["outcome"])


def test_a_market_read_only_once_says_no_history_yet(board):
    totals = [h for r in board["rows"] if r["market"] == "totals" for h in r["detail"]["history"]]
    assert totals and all(not h["available"] and h["why"].startswith("No history yet.") for h in totals)


def test_a_board_with_no_rows_reads_no_history(monkeypatch):
    from overlay_engine import board as board_mod
    called = []
    monkeypatch.setattr(linehistory.LineHistory, "_load", lambda self: called.append(1) or {})
    spy = LineHistory(lambda: [], None)
    assert board_mod.scan([], None, detail=True, history=spy) == [] and called == []
