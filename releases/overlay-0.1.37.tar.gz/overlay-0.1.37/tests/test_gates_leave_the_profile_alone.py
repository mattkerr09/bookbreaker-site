"""The gates never write into this Mac's real ~/.overlay.

The break tests run deliberately broken engines, and a crash writes a report under OVERLAY_HOME (crash.py). Before
2026-10-13 nothing set it, so 254 reports from the harness piled up in the real crash folder, mixed in with real
ones a person might send us. These hold the two places that keep it out.
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_gates_export_a_throwaway_profile_and_fail_if_the_real_crash_folder_grows():
    text = (ROOT / "scripts" / "gates.sh").read_text()
    home = text.index("export OVERLAY_HOME")
    assert "mktemp -d" in text[:home], "OVERLAY_HOME must be a fresh temporary folder"
    assert home < text.index("python3 -m pytest"), "the profile must be set before the first gate runs"
    assert re.search(r'crashes_after.*!=.*crashes_before', text), "the real crash folder must be counted after"
    after = text.index('crashes_after="$(crash_count)"')
    assert "fail=1" in text[after:text.index('echo "GATES RED"')]


def test_the_break_harness_gives_every_run_its_own_profile(tmp_path):
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import break_test
    finally:
        sys.path.pop(0)
    home = break_test._throwaway_home()
    assert Path(home).is_dir()
    assert not Path(home).resolve().is_relative_to(Path.home() / ".overlay")
    assert home == break_test._throwaway_home(), "one profile for the whole run"
    src = (ROOT / "scripts" / "break_test.py").read_text()
    run = src[src.index("def run(test: str)"):src.index("# ---------------------------------------------------------------- the lock")]
    assert '"OVERLAY_HOME": _throwaway_home()' in run


def test_a_crash_under_the_gates_profile_lands_in_it(tmp_path):
    """End to end: a crash report written with OVERLAY_HOME set goes there, not to the real folder."""
    code = ("import sys; sys.path.insert(0, 'backend'); from overlay_engine import crash; "
            "print(crash.CRASH_DIR)")
    out = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True,
                         env={**os.environ, "OVERLAY_HOME": str(tmp_path)}, check=True).stdout.strip()
    assert Path(out) == tmp_path / "crashes"
