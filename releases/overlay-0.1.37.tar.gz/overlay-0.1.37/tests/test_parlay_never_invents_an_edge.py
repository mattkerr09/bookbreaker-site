"""A parlay priced from its legs' own prices can never show an edge (the CEO's gate after 0.1.35).

Before 0.1.35 every leg was a coin flip whatever its price, so -110 -110 +150 showed +13.89% EV: a bad parlay drawn as
a good bet. With only each leg's price, all the arithmetic can know is that each leg carries a book's margin, so every
such parlay, at any prices and any number of legs, must show a positive hold and negative expected value. The goal
planner's assumed legs must hold to the same rule. Exhaustive over a grid rather than sampled, so a failure names the
exact ticket.
"""

import itertools

import pytest

from overlay_engine.goal import assumed_pool
from overlay_engine.odds import american_to_decimal as a2d
from overlay_engine.parlay import value

PRICES = [-1000, -400, -250, -200, -150, -120, -110, -105, 100, 105, 120, 150, 200, 300, 500, 1000, 2500]


@pytest.mark.parametrize("n", [2, 3, 4])
def test_no_parlay_of_priced_legs_shows_an_edge(n):
    for legs in itertools.combinations_with_replacement(PRICES, n):
        priced = value([a2d(p) for p in legs])
        assert priced.ev < 0 and priced.hold > 0, f"{legs}: ev {priced.ev:+.4f}, hold {priced.hold:+.4f}"


def test_even_money_and_shorter_legs_lose_at_least_the_standard_margin_per_leg():
    for n in range(2, 9):
        for legs in itertools.combinations_with_replacement([p for p in PRICES if p <= 100], min(n, 3)):
            priced = value([a2d(p) for p in legs])
            assert priced.ev == pytest.approx((210 / 220) ** len(legs) - 1)


@pytest.mark.parametrize("price", [str(p if p < 0 else f"+{p}") for p in PRICES])
def test_the_goal_planner_never_assumes_a_leg_with_an_edge(price):
    leg = assumed_pool(1, price)[0]
    assert leg.p * leg.decimal < 1, f"{price}: an assumed leg with an edge ({leg.p * leg.decimal:.4f})"
