"""Bet warnings, in the window.

Static, like the other window tests. What a screenshot cannot show, and these pin:

  * three switches in the board's settings, all on until turned off, kept in this window's own storage, with the same
    labels and notes the engine gives them; they start nothing (no read, no engine call, no request);
  * a switch only chooses which KINDS of warning are shown: the list of plays is never filtered by a warning, so a
    warned play stays on the board with its warning, and a play the engine could not check says why;
  * the warnings appear on the row (a small label for each kind), on the console and in the row's detail, and the
    board's line above them is the engine's sentence;
  * the window finds no bet, compares no side and counts nothing: every sentence is the engine's, drawn as text;
  * every field the window reads is one the engine really sends;
  * the stylesheet stays balanced, every class the new markup uses has a rule, and the new rules use the window's
    tokens and no colour of their own.
"""

import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine import betwarn, cli  # noqa: E402
from overlay_engine.ledger import Ledger  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
JS = (ROOT / "ui" / "src" / "app.js").read_text()
CSS = (ROOT / "ui" / "src" / "app.css").read_text()
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way")

START = "/* ------------------------------------------------------------ Bet warnings"
SECTION = JS[JS.index(START):JS.index("function drawBoard(box, pick) {")]
CSS_START = "/* ------------------------------------------------------------ bet warnings"
WARN_CSS = CSS[CSS.index(CSS_START):]


@pytest.fixture(autouse=True)
def throwaway_home(monkeypatch, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def _box() -> str:
    start = HTML.index('<details class="alerts bw" id="bw-box">')
    return HTML[start:HTML.index("</details>", start)]


def _plain(html: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)).replace("&rsquo;", "’")


# ------------------------------------------------------------ the switches

def test_there_are_three_switches_and_all_start_on():
    box = _box()
    for ident in ("bw-placed", "bw-conflict", "bw-game"):
        tag = re.search(rf'<input type="checkbox" id="{ident}"[^>]*>', box).group(0)
        assert "checked" in tag, f"{ident} must start on"
    assert 'id="bw-state">on<' in box


def test_the_switches_say_what_the_engine_says():
    """The label and the note beside each switch are the engine's, word for word."""
    box = re.sub(r"<small>", " <small>", _box())
    for sw in betwarn.SWITCHES:
        row = re.search(rf'<input type="checkbox" id="bw-{sw["code"]}".*?</label>', box, re.S).group(0)
        text = _plain(row)
        assert sw["label"] in text and sw["note"] in text, sw["code"]


def test_the_box_sits_after_the_find_arbs_button_and_adds_no_run_button():
    board = HTML[HTML.index('<section class="panel" id="panel-board"'):]
    board = board[:board.index("</section>")]
    assert board.index('data-run="board"') < board.index('id="bw-box"')
    assert "data-run" not in _box() and "<button" not in _box()


def test_the_box_says_a_warned_play_stays_and_that_nothing_is_read_or_sent():
    text = _plain(_box())
    assert "stays on the board with the warning beside it" in text
    assert "Changing them reads nothing" in text
    assert "none of this is sent anywhere" in text
    assert "when a warning could not be checked" in text
    for word in BANNED:
        assert word not in text.lower()


def test_the_choice_is_kept_in_this_windows_own_storage_and_defaults_to_on():
    assert 'store.get("bb.warnings", {})' in SECTION and 'store.set("bb.warnings", BW)' in SECTION
    assert "BW[code] = saved[code] !== false;" in SECTION
    assert "const BW = { placed: true, conflict: true, game: true };" in SECTION
    assert "localStorage" not in SECTION, "the store helper is the one place the window touches its storage"


def test_changing_a_switch_redraws_what_is_here_and_starts_nothing():
    handler = _braced(SECTION, "el.addEventListener(\"change\"")
    assert "drawBoard(" in handler and "pickedPlay()" in handler
    for call in ("run(", "invoke(", "fetch(", "XMLHttpRequest", "setTimeout", "setInterval"):
        assert call not in handler, call
    for call in ("fetch(", "XMLHttpRequest", "invoke(", "setTimeout", "setInterval", "WebSocket"):
        assert call not in SECTION, call


# ------------------------------------------------------------ a warned play is never hidden

def test_a_switch_chooses_kinds_of_warning_and_never_plays():
    assert "const bwShown = (p) => ((p && p.warn && p.warn.items) || []).filter((i) => BW[i.code]);" in SECTION
    draw = _braced(JS, "function drawBoard(")
    seen = draw[:draw.index("const good")]
    assert "shownByPreset(p)" in seen
    for word in ("bwShown", "warn", "BW[", "bwLine"):
        assert word not in seen, f"the list of plays must not depend on {word}"
    shown_by = JS[JS.index("const shownByPreset"):].split("\n", 1)[0]
    assert "warn" not in shown_by and "BW" not in shown_by


def test_the_row_the_console_and_the_detail_all_show_the_warnings():
    assert "bwPills(p, \"bw-pill\", \"bw-row\")" in _braced(JS, "function listCard(")
    assert "bwPills(p, \"c-pill warn\")" in _braced(JS, "function consoleHTML(")
    assert "bwCard(p)" in _braced(JS, "function detailHTML(")
    assert "bwLine()" in _braced(JS, "function drawBoard(")


def test_every_kind_of_board_carries_the_engines_summary_and_every_play_its_block():
    assert "bw: out.warnings" in _braced(JS, "function showBoard(")
    assert _braced(JS, "function showBoard(").count("bw: out.warnings") == 2
    assert "bw: out.warnings" in _braced(JS, "function showOddsboard(")
    assert "warn: r.warnings || null" in _braced(JS, "function boardPlay(")
    assert "warn: r.warnings || null" in _braced(JS, "function livePlay(")


def test_a_play_the_engine_could_not_check_says_why_in_the_engines_words():
    card = _braced(SECTION, "function bwCard(")
    assert "if (!w.checked)" in card and "esc(w.why)" in card
    assert card.index("if (!w.checked)") < card.index("bwShown(p)"), "an unchecked play is not subject to the switches"


def test_all_switches_off_is_said_on_the_board_and_not_left_looking_clean():
    line = _braced(SECTION, "function bwLine(")
    assert "BET WARNINGS OFF" in line and "switched off" in line
    assert "esc(bw.sentence)" in line and "esc(c.sentence)" in line and "BW[c.code]" in line


# ------------------------------------------------------------ the window computes nothing

def _leaves(code: str) -> list:
    return re.findall(r"\$\{([^{}]*)\}", code)


def test_the_window_computes_nothing_in_the_new_code():
    for banned in (".toFixed(", ".reduce(", "parseFloat", "Number(", "Math.", "toLocaleString", "toPrecision",
                   ".length >", ".length ==", "+ 1", "- 1"):
        assert banned not in SECTION, banned
    leaves = _leaves(SECTION)
    assert len(leaves) >= 8, "the extractor has drifted"
    for expr in leaves:
        bare = re.sub(r"\"[^\"]*\"|'[^']*'", "''", expr)
        assert not re.search(r"[\w)\]]\s*[*/%]\s*[\w(]|[\w)\]]\s+[+-]\s+[\w(]", bare), f"arithmetic: {expr}"


def test_the_engines_words_are_drawn_as_text_not_markup():
    for sink in ("document.write", "insertAdjacentHTML", "eval(", "new Function"):
        assert sink not in SECTION
    for field in ("i.text", "w.why", "bw.sentence", "c.sentence", "s.label", "bwLabel(c)", "bwLabel(i.code)"):
        uses = [m.start() for m in re.finditer(re.escape(field), SECTION)]
        assert uses, field
    assert "${esc(i.text)}" in SECTION and "${esc(w.why)}" in SECTION
    assert "${esc(bw.sentence)}" in SECTION and "esc(c.sentence)" in SECTION
    assert 'title="${esc(items.find((i) => i.code === c).text)}"' in SECTION
    assert "${esc(bwLabel(c))}" in SECTION and "${esc(bwLabel(i.code))}" in SECTION


def test_the_window_promises_nothing_it_is_not():
    new = SECTION + _plain(_box())
    for word in BANNED:
        assert word not in new.lower()


# ------------------------------------------------------------ the engine really sends what the window reads

def test_every_field_the_window_reads_is_one_the_engine_sends(capsys):
    assert cli.main(["board", "--json"]) == 0
    clean = json.loads(capsys.readouterr().out)
    row = clean["rows"][0]
    db = Ledger()
    db.import_bet(event_id=row["event"], sport="nba", market_type=row["market"], outcome=row["legs"][0]["outcome"],
                  book="dk", decimal_odds=1.91, stake=25.0, placed_at=1000.0, external_ref="r", source="tracked")
    db.close()
    assert cli.main(["board", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    summary = out["warnings"]
    read = set(re.findall(r"\bbw\.([a-z_]+)", SECTION))
    assert read >= {"switches", "by_code", "sentence"}, "the extractor has drifted"
    assert read <= set(summary), sorted(read - set(summary))
    assert {"code", "label"} <= set(summary["switches"][0]) and {"code", "sentence"} <= set(summary["by_code"][0])
    block = out["rows"][0]["warnings"]
    assert {"checked", "items"} <= set(block)
    item = block["items"][0]
    assert {"code", "text"} <= set(item) and item["code"] in {s["code"] for s in summary["switches"]}
    assert "why" in betwarn.unchecked()
    for name in ("checked", "why"):
        assert re.search(rf"\bw\.{name}\b", SECTION), name
    assert "p.warn.items" in SECTION


# ------------------------------------------------------------ the stylesheet

def test_every_class_the_new_markup_uses_has_a_rule_and_is_drawn():
    for cls in ("bw-row", "bw-pill", "bw-card", "bw-list", "bw-item"):
        assert re.search(rf"\.{re.escape(cls)}\b[^{{}}]*\{{", WARN_CSS), f".{cls} has no rule in app.css"
        drawn = SECTION + _braced(JS, "function listCard(")
        assert re.search(rf"\b{re.escape(cls)}\b", drawn), f".{cls} is styled and never drawn"
    assert ".c-head .c-pill.warn{" in WARN_CSS


def test_the_new_styles_use_the_windows_tokens_and_no_colour_of_their_own():
    assert WARN_CSS.count("{") >= 8, "the extractor has drifted"
    assert not re.search(r"#[0-9a-fA-F]{3,8}\b", WARN_CSS), "a hex colour in the new styles belongs in the token set"
    assert not re.search(r"\brgba?\(", WARN_CSS) and not re.search(r"\bhsla?\(", WARN_CSS)
    for token in sorted(set(re.findall(r"var\((--[\w-]+)", WARN_CSS))):
        assert re.search(rf"{re.escape(token)}\s*:", CSS), f"{token} is not defined"


def test_the_new_styles_are_a_balanced_top_level_section():
    assert WARN_CSS.count("{") == WARN_CSS.count("}")
    assert CSS.count("{") == CSS.count("}")
