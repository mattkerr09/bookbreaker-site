"""The My bets dashboard and the price history chart, in the window.

Static, like the other window tests. What a screenshot cannot show, and these pin:

  * the window computes nothing here. The sentence, the profit and expected profit, the length of a
    bar, the tone and the money of a calendar day, the order of the months, and every point, tick and
    marker of a chart are the engine's. The window writes their signs and puts them in markup;
  * the page makes no request and draws no chart with a library: the chart is inline SVG made from
    the engine's finished geometry;
  * an empty ledger keeps its honest empty state, and a row with fewer than two reads says what the
    engine says ("No history yet") and draws no line;
  * every field the page reads is one the engine really sends;
  * nothing the page says promises more than it is, in either theme (the new styles use the window's
    tokens and no colour of their own).
"""

import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_linehistory as tl  # noqa: E402
import test_tracker as tt  # noqa: E402

from overlay_engine import tracker  # noqa: E402
from overlay_engine.ledger import Ledger  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
JS = (ROOT / "ui" / "src" / "app.js").read_text()
CSS = (ROOT / "ui" / "src" / "app.css").read_text()
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way")


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


TRACKER_JS = JS[JS.index("/* The My bets dashboard:"):JS.index("// The file picker gives the window the file's contents")]
RESULTS = _braced(JS, "function showResults(")
HISTORY_JS = JS[JS.index("/* A price over time, for each bet of the row"):JS.index("function detailHTML(")]
DASH_CSS = CSS[CSS.index("/* ------------------------------------------------------------ the My bets dashboard"):]


def _leaves(code: str) -> list:
    return re.findall(r"\$\{([^`{}]*)\}", code)


def _no_arithmetic(code: str):
    for banned in (".toFixed(", ".reduce(", "parseFloat", "Number(", "Math.", "toLocaleString"):
        assert banned not in code, banned
    leaves = _leaves(code)
    assert len(leaves) >= 12, "the extractor has drifted"
    for expr in leaves:
        bare = re.sub(r"\"[^\"]*\"|'[^']*'", "''", expr)
        assert not re.search(r"[\w)\]]\s*[*/%]\s*[\w(]|[\w)\]]\s+[+-]\s+[\w(]", bare), f"arithmetic on an engine figure: {expr}"


# ------------------------------------------------------------ the dashboard

def test_the_results_page_draws_every_tile_from_the_engines_dashboard():
    for call in ("sentenceHTML(TRACKER)", "expectedHTML(TRACKER.expected)",
                 "calendarHTML(TRACKER.calendar, TRACKER.calendar.shown)",
                 'barsHTML("Profit by sportsbook", TRACKER.by_book)', 'barsHTML("Profit by market", TRACKER.by_market)'):
        assert call in RESULTS, call
    assert "TRACKER = out.tracker || null;" in RESULTS, "an engine from before the dashboard still draws the record"


def test_an_empty_ledger_keeps_its_honest_empty_state():
    empty = RESULTS[RESULTS.index("if (!out.settled) {"):RESULTS.index("const sign =")]
    assert "<h2>No settled bets yet</h2>" in empty and 'data-goto="add-bets"' in empty
    assert "return;" in empty, "the empty state must not fall through to a dashboard of zeroes"
    assert "calendarHTML" not in empty and "barsHTML" not in empty and "expectedHTML" not in empty
    sentence = _braced(TRACKER_JS, "function sentenceHTML(")
    assert "t.summary.empty" in sentence and 'return ""' in sentence, "no sentence for a ledger with no bets"


def test_the_dashboard_computes_nothing():
    _no_arithmetic(TRACKER_JS)


def test_the_length_of_a_bar_and_the_tone_and_money_of_a_day_are_the_engines():
    bars = _braced(TRACKER_JS, "function barsHTML(")
    assert 'style="--w:${g.scale}"' in bars and "${esc(g.tone)}" in bars and "usd(g.profit, true)" in bars
    cal = _braced(TRACKER_JS, "function calendarHTML(")
    assert 'style="--w:${c.scale}"' in cal and "${esc(c.tone)}" in cal and "esc(c.short)" in cal
    assert "usd(m.profit, true)" in cal


def test_the_months_are_chained_by_the_engines_ids_and_the_window_never_counts_them():
    cal = _braced(TRACKER_JS, "function calendarHTML(")
    assert 'go(m.prev, "Earlier month"' in cal and 'go(m.next, "Later month"' in cal
    assert "cal.months.find((x) => x.id === id)" in cal and "cal.shown" in cal
    handler = TRACKER_JS[TRACKER_JS.index('document.addEventListener("click"'):]
    assert "calendarHTML(TRACKER.calendar, b.dataset.calGo)" in handler
    for call in ("invoke(", "run(", "fetch(", "await", "async"):
        assert call not in handler, call
    assert "disabled" in cal, "the first and last months have nowhere to go"


def test_the_empty_cells_around_a_month_are_blanks_and_a_quiet_day_shows_no_amount():
    cal = _braced(TRACKER_JS, "function calendarHTML(")
    assert '<div class="tk-day out"></div>' in cal and "c.n ?" in cal


def test_the_dashboard_says_what_it_is_and_promises_nothing():
    low = (TRACKER_JS + HISTORY_JS).lower()
    for word in BANNED:
        assert word not in low, word
    assert "Actual vs expected profit" in TRACKER_JS and "Profit by sportsbook" in RESULTS and "Profit by market" in RESULTS
    assert "esc(e.verdict)" in TRACKER_JS and "esc(e.note)" in TRACKER_JS, "the engine's caveat travels with the number"


def test_the_engines_words_are_drawn_as_text_not_markup():
    for code in (TRACKER_JS, HISTORY_JS):
        for sink in ("document.write", "insertAdjacentHTML", "eval("):
            assert sink not in code
        leaves = _leaves(code)
        texty = [x for x in leaves if re.search(r"\.(text|verdict|note|why|label|short|anchor|path|key|id)\b", x)]
        assert len(texty) >= 10, "the extractor has drifted"
        for expr in texty:
            assert "esc(" in expr, f"engine text interpolated without esc(): {expr}"


# ------------------------------------------------------------ the chart

def test_the_chart_is_inline_svg_from_the_engines_geometry_with_no_library_and_no_request():
    svg = _braced(HISTORY_JS, "function lineSvg(")
    assert "<svg" in svg and "viewBox" in svg
    for part in ('d="${esc(c.price.path)}"', 'd="${esc(c.fair.path)}"', 'cx="${m.x}" cy="${m.y}"',
                 'cx="${c.price.end.x}" cy="${c.price.end.y}"', 'x1="${c.plot.x}" y1="${k.y}" x2="${c.plot.x2}" y2="${k.y}"'):
        assert part in svg, part
    for call in ("fetch(", "XMLHttpRequest", "WebSocket", "Image(", "new Chart", "d3.", "Plotly", "<script", "<img", "<link",
                 "http://", "https://", "invoke(", "await", "async"):
        assert call not in HISTORY_JS, call
    _no_arithmetic(HISTORY_JS)


def test_a_row_with_no_line_says_what_the_engine_says_and_draws_none():
    one = _braced(HISTORY_JS, "function lineOne(")
    assert "if (!h.available)" in one and "esc(h.why)" in one
    assert one.index("if (!h.available)") < one.index("lineSvg(h)"), "no svg is built for a row with no line"
    assert "No history yet" not in HISTORY_JS, "the sentence is the engine's, not a second copy in the window"


def test_the_chart_has_the_price_the_fair_price_and_your_bet_and_names_each():
    one = _braced(HISTORY_JS, "function lineOne(")
    assert "h.chart.price.label" in one and "h.chart.fair.label" in one and "Your bet" in one
    assert "h.chart.mine.map" in one and "esc(m.label)" in one, "your bet is described in the engine's words, not the window's"
    assert "esc(h.text)" in one and "esc(h.note)" in one


def test_the_history_sits_between_the_ev_by_book_and_the_price_table_inside_the_detail():
    detail = _braced(JS, "function detailHTML(")
    assert ("${fairHTML(d.fair)}${formulaCard(d.formula)}${evHTML(d.ev_by_book)}${historyHTML(d.history)}"
            "${pricesHTML(d.table)}") in detail
    assert "if (!list || !list.length) return \"\";" in HISTORY_JS, "a row from before the history has nothing to draw"


# ------------------------------------------------------------ styling

def test_every_class_the_dashboard_and_the_chart_use_has_a_rule_and_is_drawn():
    used = {"tk-sentence", "tk-row", "tk-bar", "tk-n", "tk-cal", "tk-calhead", "tk-go", "tk-month", "tk-grid", "tk-wd",
            "tk-day", "lh-wrap", "lh-one", "lh-t", "lh-svg", "lh-bg", "lh-grid", "lh-y", "lh-x", "lh-fair", "lh-price",
            "lh-end", "lh-me", "lh-key", "lh-k", "lh-none", "lh-bet"}
    for cls in used:
        assert re.search(rf"\.{re.escape(cls)}\b[^{{}}]*\{{", CSS), f".{cls} has no rule in app.css"
        assert re.search(rf'class="[^"]*\b{re.escape(cls)}\b', TRACKER_JS + HISTORY_JS), f".{cls} is styled and never drawn"
    for tone in ("pos", "neg", "out", "none", "flat"):
        assert re.search(rf"\.tk-day\.{tone}\b", DASH_CSS), tone


def test_the_new_styles_use_the_windows_tokens_and_no_colour_of_their_own():
    assert DASH_CSS.count("{") > 40, "the extractor has drifted"
    assert not re.search(r"#[0-9a-fA-F]{3,8}\b", DASH_CSS), "a hex colour in the dashboard styles belongs in the token set"
    assert not re.search(r"\brgba?\(", DASH_CSS) and not re.search(r"\bhsla?\(", DASH_CSS)
    # `--w` is not a colour token: it is the engine's bar length, set on each element by the page.
    for token in sorted(set(re.findall(r"var\((--[\w-]+)", DASH_CSS)) - {"--w"}):
        assert re.search(rf"{re.escape(token)}\s*:", CSS), f"{token} is not defined"


# ------------------------------------------------------------ the window reads only what the engine sends

def _read(var: str, code: str) -> set:
    return set(re.findall(rf"(?<![\w.]){var}\.([a-z_]+)", code))


def _keys(items):
    return set().union(*(set(i) for i in items if i)) if items else set()


@pytest.fixture
def dashboard(tmp_path):
    with Ledger(tmp_path / "w.db") as db:
        for i in range(34):
            tt.priced(db, i, result="won" if i % 2 else "lost", settled=tt.at(2026, 10, 1 + i % 20))
        for i in range(4):
            tt.imported(db, 100 + i, settled=tt.at(2026, 9, 1 + i))
        tt.open_bet(db, 1)
        yield tt.dash(db)


def test_every_field_the_dashboard_reads_is_one_the_engine_sends(dashboard):
    d = dashboard
    assert d["expected"]["available"] and d["calendar"]["months"] and d["by_book"] and d["by_market"]
    month = d["calendar"]["months"][-1]
    days = [c for w in month["weeks"] for c in w if c]
    shapes = {"e": _keys([d["expected"]]), "g": _keys(d["by_book"] + d["by_market"]), "m": _keys(d["calendar"]["months"]),
              "c": _keys(days), "cal": _keys([d["calendar"]]), "t": set(d), "x": set()}
    assert set(d["summary"]) >= {"text", "empty"}
    for fn, var in (("expectedHTML", "e"), ("barsHTML", "g"), ("calendarHTML", "m"), ("calendarHTML", "c"),
                    ("calendarHTML", "cal"), ("sentenceHTML", "t")):
        body = _braced(TRACKER_JS, f"function {fn}(")
        read = _read(var, body) - {"map", "find", "length", "join"}
        assert read <= shapes[var], f"{fn}: {var}: read but never sent: {sorted(read - shapes[var])}"
    assert {"profit", "n", "short", "tone", "scale", "day"} <= shapes["c"]
    assert {"label", "n", "won", "lost", "profit", "tone", "scale"} <= shapes["g"]
    assert {"actual", "expected", "gap", "swing", "text", "verdict", "note", "priced"} <= shapes["e"]
    assert {"id", "label", "profit", "prev", "next", "weeks"} <= shapes["m"]
    assert {"weekdays", "shown", "months", "note"} <= shapes["cal"]


def test_every_field_the_chart_reads_is_one_the_engine_sends(tmp_path):
    from overlay_engine.ledger import Ledger as L
    folder = tmp_path / "history"
    tl.fx.write_history(folder, tl.reads([(2.0, 1.9), (2.1, 1.85), (2.2, 1.85)]))
    led = tl.make_ledger(tmp_path / "overlay.db", [("g1", "h2h", tl.HOME, "dk", 2.1, tl.NOW - tl.STEP)])
    del L
    got = tl.chart(folder, ledger=led)
    none = tl.chart(folder, leg=("mgm", tl.HOME))
    c = got["chart"]
    shapes = {"h": _keys([got, none]), "c": _keys([c]), "k": _keys(c["y_ticks"] + c["x_ticks"]), "m": _keys(c["mine"])}
    for fn, var in (("lineOne", "h"), ("lineSvg", "h"), ("lineSvg", "c"), ("lineSvg", "k"), ("lineSvg", "m"),
                    ("lineOne", "m")):
        body = _braced(HISTORY_JS, f"function {fn}(")
        read = _read(var, body) - {"map", "join", "length"}
        assert read <= shapes[var], f"{fn}: {var}: read but never sent: {sorted(read - shapes[var])}"
    assert {"available", "why", "text", "note", "label", "book_name", "chart"} <= shapes["h"]
    assert {"plot", "price", "fair", "mine", "y_ticks", "x_ticks", "y_label_x", "x_label_y", "width", "height"} <= shapes["c"]
    assert {"x", "y", "label"} <= shapes["m"] and {"y", "american", "x", "label", "anchor"} <= shapes["k"]
    plot = _keys([c["plot"]])
    assert set(re.findall(r"c\.plot\.([a-z0-9_]+)", HISTORY_JS)) <= plot


def test_the_engines_money_words_are_the_ones_the_window_signs():
    # The window's only act on a figure is writing its sign, with the helpers it already has.
    for helper in ("usd(e.actual, true)", "usd(e.expected, true)", "usd(e.gap, true)", "usd(e.swing)"):
        assert helper in TRACKER_JS, helper
    assert tracker.short_money(1234.5) == "+$1.2k" and tracker.short_money(-4.5) == "-$4.50"
    assert tracker.short_money(70.0) == "+$70" and tracker.short_money(12500) == "+$12k"
