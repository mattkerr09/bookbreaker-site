"""The Parlays tab in the window. Static, like the other window tests.

What these pin:

  * opening the tab reads only what is on this Mac (parlays --stored); a read that spends credits runs only from the
    Read button, which stays hidden until reading is switched on and the cost has been shown;
  * the window computes nothing: every figure is a *_text field the engine wrote (propparlay.texts);
  * every ticket shows its fair price, what the legs pay, and the cost against fair, side by side;
  * the CEO's wording QC (2026-10-18): a chance is "fair chance it lands", a model estimate, never "lands X% of the
    time"; the shortest price is when a ticket beats fair, never an instruction to take it; nothing calls a parlay
    good value; and the helpline and "Set a limit before you bet" sit on the tab itself.
"""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
JS = (ROOT / "ui" / "src" / "app.js").read_text()


def _fn(name: str) -> str:
    start = JS.index(f"function {name}(")
    depth, opened = 0, JS.index("{", start)
    for i in range(opened, len(JS)):
        depth += {"{": 1, "}": -1}.get(JS[i], 0)
        if depth == 0:
            return JS[start:i + 1]
    raise AssertionError(name)


def test_opening_the_tab_reads_this_mac_only():
    assert re.search(r'parlays: \(\) => \["parlays", "--stored"', JS)
    assert 'if (panel === "parlays") { run("parlays"); if (PARLAYS.on) run("parlaysestimate"); }' in JS


def test_a_read_that_spends_credits_waits_for_the_switch_and_the_cost():
    assert re.search(r'<input type="checkbox" id="pp-on">', HTML), "the switch starts off"
    assert re.search(r'data-run="parlaysread" id="pp-read" type="button" hidden>', HTML)
    assert 'if ((kind === "parlaysestimate" || kind === "parlaysread") && !PARLAYS.on) { box.innerHTML = PARLAYS_OFF; return; }' in JS
    assert 'const PARLAYS = { on: false };' in JS
    assert 'document.getElementById("pp-read").hidden = false;' in _fn("showParlaysestimate")


def test_the_window_does_no_arithmetic_on_a_parlay():
    body = _fn("showParlays") + _fn("showParlaysestimate")
    assert not re.search(r"\* ?\d|toFixed|Math\.|parseFloat|Number\(", body)


def test_every_ticket_shows_fair_paid_and_cost_together():
    body = _fn("showParlays")
    for field in ("t.fair_text", "t.paid_text", "t.cost_text", "c.fair_text", "c.price_text", "c.cost_text"):
        assert field in body, field


def _panel() -> str:
    return re.search(r'<section class="panel" id="panel-parlays".*?</section>', HTML, re.S).group(0)


def test_the_wording_is_an_estimate_not_a_promise_or_an_instruction():
    text = " ".join((_panel() + _fn("showParlays")).split())
    assert text.count("Fair chance it lands:") == 2
    assert "It only beats the fair price at ${esc(t.take_text)} or longer. Below that it costs you money on average." in text
    for phrase in ("Lands ", "of the time", "or not at all", "take it at", "best-value", "best value"):
        assert phrase not in text, phrase


def test_the_tab_carries_the_helpline_and_a_limit():
    care = " ".join(re.search(r'<p class="note rg" id="pp-care">(.*?)</p>', _panel(), re.S).group(1).split())
    assert "Set a limit before you bet." in care
    assert "1-800-MY-RESET (1-800-697-3738), the National Problem Gambling Helpline" in care
    assert "bookbreaker.bet/responsible-gambling/" in care and care.startswith("21+.")


def test_the_privacy_note_names_parlays():
    note = " ".join(re.search(r'<div class="privacy-pop">(.*?)</div>', HTML, re.S).group(1).split())
    assert "only when you tick Read player props and press Read player props" in note
    assert "opening props already read on this Mac sends nothing" in note
