"""The Futures page keeps the promises futures make: off until ticked, the cost said before the press, only a press
reads, only the leagues ticked are asked for, and the window draws the engine's words and works out nothing.

Static, like test_odds_source_window.py: none of it needs a GUI. The last test runs the engine itself and checks that
every field the page reads is one the engine sends.
"""

import html
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()

PANEL = HTML[HTML.index('id="panel-futures"'):HTML.index("</section>", HTML.index('id="panel-futures"'))]
START = JS.index("/* ------------------------------------------------------------ futures")
CODE = JS[START:JS.index("// Local and free: whether a key is set", START)]


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def _text(markup: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", "", markup))).strip()


def _builders() -> dict:
    argv = JS[JS.index("  const argv = {"):JS.index("  }[kind]();")]
    return dict(re.findall(r"^    (futures\w*): \(\) => \[(.*?)\],?$", argv, re.M))


# ------------------------------------------------------------ the page, and where it lives

def test_futures_is_a_page_of_odds_source_with_its_own_tab_and_the_rail_is_unchanged():
    assert re.search(r'<section class="panel" id="panel-futures" data-section="odds">', HTML)
    sub = re.search(r'<nav class="subnav" data-section="odds" hidden>(.*?)</nav>', HTML, re.S).group(1)
    assert '<button class="tab" data-panel="futures">Futures</button>' in sub
    assert len(re.findall(r'<button class="nav[^"]*" data-section=', HTML)) <= 6


def test_the_page_says_what_it_is_and_what_costs_credits():
    sub = _text(re.search(r'<p class="sub">(.*?)</p>', PANEL, re.S).group(1))
    assert "Opening what is already on this Mac costs nothing" in sub
    assert "Reading new prices spends credits from your own Odds API key, so it is off until you turn it on" in sub
    assert "sportsbooks’ cut" in sub, "the hold is explained in the plainest words where it is first met"


# ------------------------------------------------------------ opt in, off by default

def test_futures_start_switched_off_and_say_why():
    box = re.search(r'<input type="checkbox" id="fu-on"[^>]*>', HTML).group(0)
    assert "checked" not in box
    assert "const FUTURES = { on: false, leagues: [], regions: null," in JS
    label = _text(re.search(r'<label class="chk"><input type="checkbox" id="fu-on">(.*?)</label>', PANEL, re.S).group(1))
    assert "Off unless you tick it" in label and "costs a credit for every region" in label
    assert 'id="fu-picks" hidden' in PANEL, "the pickers stay hidden until the switch is on"
    assert re.search(r'<button class="go" data-run="futuresread" id="fu-read" type="button" hidden>', PANEL)


def test_no_league_is_ticked_until_the_person_ticks_one():
    assert "on: FUTURES.leagues.includes(c.alias)" in CODE
    assert "leagues: []" in CODE and "FUTURES.leagues = saved.leagues" in CODE


def test_the_cost_is_on_the_page_before_any_press_from_the_engines_own_count():
    estimate = _braced(CODE, "function showFuturesestimate(")
    for part in ("e.credits", "e.text", "e.rule", "creditsLeft()"):
        assert part in estimate, part
    # on the button itself too, so the number is the last thing read before the press
    assert "button.textContent = `Read futures (up to ${e.credits} credit" in estimate
    assert "button.hidden = !(FUTURES.on && e.credits > 0);" in estimate
    assert "futuresestimate: () =>" in JS and '"--estimate"' in _builders()["futuresestimate"]


def test_switching_it_on_or_picking_a_league_asks_only_for_the_cost():
    on = _braced(CODE, 'document.getElementById("fu-on").addEventListener(')
    picks = _braced(CODE, 'document.getElementById("fu-picks").addEventListener(')
    for body in (on, picks):
        assert 'run("futuresestimate")' in body
        assert "futuresread" not in body and "oddsboard" not in body
    assert 'if (!FUTURES.on) document.getElementById("fu-read").hidden = true;' in on, "off leaves nothing to press"
    off = JS[JS.index('if (kind === "futuresestimate" && !FUTURES.on)'):]
    assert off.startswith('if (kind === "futuresestimate" && !FUTURES.on) { box.innerHTML = FUTURES_OFF; return; }')


# ------------------------------------------------------------ only a press reads, and only what was ticked

def test_only_the_read_button_reaches_the_odds_api_and_nothing_runs_it_by_itself():
    assert len(re.findall(r'data-run="futuresread"', HTML)) == 1
    assert 'run("futuresread")' not in JS and "run('futuresread')" not in JS
    built = _builders()
    assert '"--estimate"' not in built["futures"]
    assert '"--futures-stored"' in built["futures"] and '"--futures"' not in built["futures"]
    assert '"--futures"' in built["futuresread"] and '"--estimate"' not in built["futuresread"]
    assert "--futures-stored" not in built["futuresread"]
    assert '"--futures", "--estimate"' in built["futuresestimate"]
    for timer in ("setInterval", "setTimeout", "requestAnimationFrame"):
        for m in re.finditer(timer + r"\(", JS):
            assert "futures" not in JS[m.start():m.start() + 400].lower(), timer


def test_the_first_button_on_the_page_is_the_free_one_so_showing_it_spends_nothing():
    first = re.search(r'data-run="([a-z-]+)"', PANEL).group(1)
    assert first == "futures"
    assert re.findall(r'data-run="([a-z-]+)"', PANEL) == ["futures", "futuresread"]
    shown = _braced(JS, "function show(panel)")
    assert 'if (panel === "futures") { run("futures"); if (FUTURES.on) run("futuresestimate"); }' in shown
    at_load = re.findall(r'^run\("([a-z]+)"\);', JS, re.M)
    assert at_load == ["keystatus", "oddsestimate"], "futures run at load"


def test_a_press_with_nothing_ticked_reads_nothing_and_asks_the_engine_nothing():
    ready = JS[JS.index("const futuresReady = ()"):JS.index("\n", JS.index("const futuresReady = ()"))]
    assert "FUTURES.on && FUTURES.leagues.length > 0" in ready
    run_once = _braced(JS, "async function runOnce(")
    guard = 'if (kind === "futuresread" && !futuresReady()) { box.innerHTML = FUTURES_PICK; return; }'
    assert guard in run_once
    assert run_once.index(guard) < run_once.index('invoke("engine"') and run_once.index(guard) < run_once.index("const argv = {")


def test_only_the_leagues_and_regions_ticked_are_sent_and_none_is_written_into_the_page():
    flags = _braced(CODE, "function futuresFlags(")
    assert "FUTURES.leagues.flatMap" in flags and '"--futures-league"' in flags and '"--futures-region"' in flags
    from overlay_engine import futures
    for f in futures.FUTURES:
        assert f'"{f.alias}"' not in _braced(JS, "async function runOnce("), "a league name hard-coded into the call"
        assert f.key not in JS and f.key not in HTML, "the window never names a sport key"
    assert "?league=" not in JS


def test_the_feed_flag_is_one_token_so_the_other_odds_calls_keep_their_count():
    assert all('"--feed=oddsapi"' in b for b in _builders().values())
    assert JS.count('"--feed"') == 4, "tests/test_odds_source_window.py counts the older four"


def test_futures_are_remembered_in_the_windows_own_storage_and_only_the_choices():
    assert 'store.set("bb.futures", { on: FUTURES.on, leagues: FUTURES.leagues, regions: FUTURES.regions });' in JS
    assert JS.count('"bb.futures"') == 2
    assert "localStorage" not in CODE and "sessionStorage" not in CODE
    restore = _braced(CODE, "(function restoreFutures()")
    assert "FUTURES.on = saved.on === true;" in restore, "only a stored true switches it on"


def test_clearing_the_key_clears_the_futures_it_read():
    clear = _braced(JS, "function showKeyclear(")
    assert "FUTURES.data = null;" in clear and "drawFutures();" in clear


def test_the_privacy_note_names_futures():
    note = _text(re.search(r'<div class="privacy-pop">(.*?)</div>', HTML, re.S).group(1))
    assert "only when you tick them on and press Read futures" in note
    assert "opening futures already read on this Mac sends nothing" in note


# ------------------------------------------------------------ the window draws the engine's words

def test_the_grid_draws_the_engines_fair_price_best_price_marks_and_ages():
    for part in ("r.fair", "r.best", "r.cells", "c.ev", "c.best", "c.stale", "c.age_brief", "c.age_text", "b.hold_text",
                 "g.hold_sentence", "g.fair_sentence", "g.age_text", "g.read_at", "g.stale_note", "g.warning",
                 "g.plays", "s.ties_up", "s.long_shot", "s.note", "f.range_text", "r.long_shot"):
        assert part in CODE, part
    assert "if (!s.has_futures)" in CODE and "s.message" in CODE


def test_the_page_works_out_nothing_itself():
    for banned in ("toFixed", "Math.", "* 100", "/ 100", "parseFloat", "reduce(", "sort(", "decimal"):
        assert banned not in CODE, banned


def test_the_best_price_and_the_marks_are_the_engines_flags_not_a_comparison_of_cells():
    cell = _braced(CODE, "function futuresCell(")
    assert "c.best" in cell and "c.ev" in cell
    assert "c.decimal" not in CODE and "Math.max" not in CODE


def test_engine_text_is_drawn_as_text_not_markup():
    drawn = re.findall(r"\$\{(g|s|p|c|r|b|f|e)\.(hold_sentence|fair_sentence|message|ties_up|long_shot|note|text|label|"
                       r"outcome|book_name|stale_note|warning|formula_sentence|question|league_label)\}", CODE)
    assert drawn == [], f"engine words dropped into markup unescaped: {drawn}"
    for field in ("g.hold_sentence", "g.fair_sentence", "s.ties_up", "s.long_shot", "s.formula_sentence", "r.label"):
        assert f"esc({field})" in CODE, field


def test_a_reference_book_is_muted_and_labelled_and_never_marked():
    head = _braced(CODE, "function futuresTable(")
    assert 'b.bettable ? "" : " ref"' in head and "<em>reference</em>" in head
    assert "never marked best or +EV" in head


def test_the_page_says_money_is_tied_up_and_a_long_shot_is_the_least_certain_through_the_engine():
    assert "esc(s.ties_up)" in CODE and "esc(s.long_shot)" in CODE
    assert 'class="tag long"' in CODE and "its edge is the least certain" in CODE


def test_the_page_never_uses_a_word_the_house_does_not():
    for text in (_text(PANEL), CODE):
        low = text.lower()
        for bad in ("guarantee", "risk-free", "riskfree", "either way", "free bet", "—", "–", "vig"):
            assert bad not in low.replace("hold", ""), bad
    assert "devig" not in CODE.lower()


def test_every_renderer_is_dispatched():
    dispatch = re.search(r"\(\{([^}]*)\}\)\[kind\]", JS, re.S).group(1)
    for kind, fn in (("futures", "showFutures"), ("futuresestimate", "showFuturesestimate"),
                     ("futuresread", "showFuturesread")):
        assert re.search(rf"\b{kind}: {fn}\b", dispatch), kind
        assert re.search(rf"^function {fn}\(", JS, re.M), fn


def test_every_class_the_futures_page_uses_has_a_rule():
    used = {"sgrid", "sgwrap", "evm", "fu-board", "fu-fair", "fu-plays", "fu-play", "long", "costline", "pickgroup", "chk"}
    for cls in used:
        assert re.search(rf"\.{re.escape(cls)}\b", CSS), f".{cls} has no rule"
    assert re.search(r"\.sgrid td\.sg-c\.ev\{", CSS)


# ------------------------------------------------------------ every field it reads, the engine sends

def _keys(node, into: set):
    if isinstance(node, dict):
        into.update(node)
        for v in node.values():
            _keys(v, into)
    elif isinstance(node, list):
        for v in node:
            _keys(v, into)
    return into


@pytest.fixture(scope="module")
def sent(tmp_path_factory):
    """The engine's own answers for the three calls the page makes, produced the way the window gets them."""
    import contextlib
    import io
    import os

    import test_futures as tf
    from overlay_engine import cli, keystore, oddsapi
    from overlay_engine import futures as fut

    was = os.environ.get("OVERLAY_HOME")
    os.environ["OVERLAY_HOME"] = str(tmp_path_factory.mktemp("home"))
    api = tf.FuturesApi()
    real = (oddsapi.odds_api_fetcher, fut.odds_api_fetcher, keystore.get_key, fut.time)
    oddsapi.odds_api_fetcher = lambda *a, **k: api
    fut.odds_api_fetcher = lambda *a, **k: api
    keystore.get_key = lambda runner=None: tf.KEY
    fut.time = type("T", (), {"time": staticmethod(tf.Clock())})
    try:
        def call(*argv):
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                assert cli.main(["board", "--feed=oddsapi", *argv, "--json"]) == 0
            return json.loads(buf.getvalue())
        out = {"estimate": call("--futures", "--futures-league", "nfl", "--estimate"),
               "read": call("--futures", "--futures-league", "nfl"),
               "stored": call("--futures-stored"),
               "empty_estimate": call("--futures", "--estimate")}
    finally:
        oddsapi.odds_api_fetcher, fut.odds_api_fetcher, keystore.get_key, fut.time = real
        if was is None:
            os.environ.pop("OVERLAY_HOME", None)
        else:
            os.environ["OVERLAY_HOME"] = was
    return out


def test_every_field_the_page_reads_is_one_the_engine_sends(sent):
    known = _keys(sent, set())
    # fields are read off short names: g a league's grid, s the whole view, r a row, c a cell, b a book, p a play,
    # f a fair price, e the estimate, top a best price, l a league
    body = CODE[CODE.index("function showFuturesestimate("):]
    read = set(re.findall(r"\b(?:g|s|r|c|b|p|f|e|top|l|out)\.([a-z_]+)\b", body))
    read |= set(re.findall(r"\bFUTURES\.data\.([a-z_]+)", CODE)) | set(re.findall(r"\bc\.ev\.([a-z_]+)", CODE))
    # words the page's own code and the DOM have, which are not engine fields
    own = {"on", "league", "leagues", "regions", "data", "estimate", "choices", "value", "checked", "hidden", "disabled",
           "innerHTML", "textContent", "target", "length", "map", "filter", "join", "find", "includes", "indexOf",
           "push", "slice", "flatMap", "some", "src", "style", "dataset", "classList", "querySelector", "forEach",
           "key", "keys", "name", "picked"}
    missing = sorted(f for f in read - own if f not in known)
    assert not missing, f"the page reads fields the engine does not send: {missing}"
    assert {"ties_up", "long_shot", "boards", "has_futures", "hold_sentence", "fair_sentence", "plays", "rows",
            "cells", "best", "fair", "ev", "age_brief", "stale", "range_text", "hold_text", "bettable"} <= known


def test_the_empty_answer_has_what_the_page_draws_and_the_estimate_with_nothing_picked_is_zero(sent):
    empty_view = sent["stored"]["futures"]
    assert empty_view["has_futures"] is True            # the read just before it left an nfl board
    none = sent["empty_estimate"]["futures"]["estimate"]
    assert none["credits"] == 0 and "nothing would be read" in none["text"]
    est = sent["estimate"]["futures"]
    assert est["estimate"]["credits"] == 2 and est["choices"]["regions"] and est["choices"]["leagues"]
    assert sent["read"]["read"]["text"].startswith("This read used 2 credits.")
