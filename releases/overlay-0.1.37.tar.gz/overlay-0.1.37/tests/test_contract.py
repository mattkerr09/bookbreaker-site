"""A Kalshi or Polymarket US price, as the odds it really pays after the venue's taker fee (ODDSJAM_BAR #15).

Independent of the engine's arithmetic: the fees are re-derived from the venues' published formulas (read 2026-10-09).
"""

import math
import re
from decimal import ROUND_HALF_EVEN, Decimal
from pathlib import Path

import pytest

from overlay_engine.contract import price_odds
from overlay_engine.odds import OddsError

ROOT = Path(__file__).resolve().parent.parent
JS = (ROOT / "ui" / "src" / "app.js").read_text()
HTML = (ROOT / "ui" / "src" / "index.html").read_text()


def kalshi(n, p, mult=1.0):
    return math.ceil(0.07 * mult * n * p * (1 - p) * 100 - 1e-9) / 100


def polymarket(n, p):
    return float((Decimal("0.0695") * n * Decimal(str(p)) * (1 - Decimal(str(p)))).quantize(Decimal("0.01"), ROUND_HALF_EVEN))


def american(dec):
    return round((dec - 1) * 100) if dec >= 2 else round(-100 / (dec - 1))


@pytest.mark.parametrize("cents,venue,sport", [(47, "kalshi", ""), (47, "kalshi", "mlb"), (62, "polymarket", ""),
                                               (30, "kalshi", ""), (85, "polymarket", ""), (50, "kalshi", "")])
def test_the_odds_include_the_venues_fee(cents, venue, sport):
    p = cents / 100
    fee = kalshi(100, p, 0.5 if sport == "mlb" else 1.0) if venue == "kalshi" else polymarket(100, p)
    r = price_odds(cents, venue, sport=sport, contracts=100)
    assert r["fee"] == pytest.approx(fee)
    assert r["american"] == american(100 / (cents + fee))
    assert r["american"] < american(1 / p)                  # the fee always shortens the odds
    assert r["headline"] == f"{r['american']:+d}"


def test_47c_on_kalshi_is_plus_105_not_plus_113():
    r = price_odds(47, "kalshi")
    assert (r["american"], r["raw_american"], r["fee"]) == (105, 113, 1.75)
    assert "pays +105" in r["say"] and "reads +113" in r["say"]


@pytest.mark.parametrize("price,venue", [("0", "kalshi"), ("100", "kalshi"), ("abc", "kalshi"), ("47", "fanduel")])
def test_bad_input_is_a_plain_sentence(price, venue):
    with pytest.raises(OddsError):
        price_odds(price, venue)


def test_every_answer_carries_the_legal_caveat_and_the_fee_read_date():
    notes = " ".join(price_odds(47, "polymarket")["notes"])
    assert "disputed state by state" in notes and "2026-10-09" in notes


def test_the_window_asks_and_draws_without_arithmetic():
    assert 'data-run="contract"' in HTML and 'id="out-contract"' in HTML
    assert re.search(r'contract: \(\) => \["contract", val\("ct-price"\)', JS)
    start = JS.index("function showContract(")
    body = JS[start:JS.index("\n}\n", start)]
    assert not re.search(r"\* ?\d|toFixed|Math\.|parseFloat|Number\(", body)
    for field in ("out.headline", "out.say", "out.rows", "out.notes"):
        assert field in body
