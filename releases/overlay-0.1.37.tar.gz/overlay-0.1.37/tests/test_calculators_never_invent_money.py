"""No calculator shows money the arithmetic does not support (extends the CEO's parlay gate, 2026-10-19).

After the parlay check showed a bad parlay as +EV (fixed in 0.1.35), every other calculator was swept the same way and
none failed. These keep it so: exhaustive over price grids, so a failure names the exact input.
  * arbitrage: no profit unless the prices cross; never stakes more than the budget; the profit shown is the worst outcome;
  * fair odds: every method's fair chances sum to one and never exceed a side's own implied chance;
  * bet size: no stake without an edge, and never a negative one;
  * a bonus bet: what is called locked is never more than the worse of its two outcomes, and each outcome adds up.
"""

import itertools

import pytest

from overlay_engine.arb import stake_arb
from overlay_engine.devig import devig_all
from overlay_engine.kelly import size_bet
from overlay_engine.odds import american_to_decimal as a2d

PRICES = [-1000, -500, -300, -200, -150, -120, -110, -105, 100, 105, 110, 120, 150, 200, 300, 500, 1000]


@pytest.mark.parametrize("budget", [100.0, 1000.0, 2500.0])
def test_an_arb_never_shows_profit_it_cannot_lock(budget):
    for a, b in itertools.product(PRICES, repeat=2):
        da, db = a2d(a), a2d(b)
        crosses = 1 / da + 1 / db < 1
        try:
            plan = stake_arb([da, db], budget)
        except Exception:
            assert not crosses, f"{a}/{b}: a real arb was refused"
            continue
        outcomes = [leg.stake * leg.decimal - plan.total_stake for leg in plan.legs]
        assert crosses or plan.profit <= 1e-9, f"{a}/{b}: profit {plan.profit} without an arb"
        assert plan.total_stake <= budget + 1e-6, f"{a}/{b}: staked {plan.total_stake} of {budget}"
        assert plan.profit <= min(outcomes) + 0.011, f"{a}/{b}: profit {plan.profit} above the worst outcome"


def test_fair_odds_sum_to_one_and_never_exceed_the_price():
    for a, b in itertools.product(PRICES, repeat=2):
        da, db = a2d(a), a2d(b)
        if 1 / da + 1 / db < 1:
            continue
        for method, fair in devig_all([da, db]).by_method.items():
            assert sum(fair) == pytest.approx(1) and all(0 < x < 1 for x in fair), f"{method} {a}/{b}: {fair}"
            assert fair[0] <= 1 / da + 1e-9 and fair[1] <= 1 / db + 1e-9, f"{method} {a}/{b}: fair above implied"


def test_no_stake_without_an_edge():
    for p in PRICES:
        d = a2d(p)
        for q in (0.05, 0.2, 0.35, 0.5, 0.65, 0.8, 0.95):
            stake = size_bet(d, q, 1000.0, fraction=0.25).stake
            assert stake >= 0
            assert q * d > 1 or stake == 0, f"{p} at {q}: staked {stake} with no edge"


@pytest.mark.parametrize("amount", [5, 25, 100, 500, 2000])
def test_a_bonus_bet_never_locks_more_than_its_worse_outcome(amount):
    import json, subprocess, sys
    from pathlib import Path
    out = subprocess.run([sys.executable, "-m", "overlay_engine", "promo", "--type", "bonus_bet", "--book", "dk",
                          "--amount", str(amount), "--json"], capture_output=True, text=True, check=True,
                         cwd=Path(__file__).resolve().parent.parent / "backend")
    d = json.loads(out.stdout)
    kept = [o["kept"] for o in d["outcomes"]]
    for o in d["outcomes"]:
        assert o["from_promo"] + o["from_hedge"] == pytest.approx(o["kept"], abs=0.011)
    assert d["worth"]["locked"] and d["worth"]["amount"] <= min(kept) + 0.011
    assert d["worth"]["amount"] <= amount
