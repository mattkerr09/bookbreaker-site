"""Alerts: which plays on a read the person pressed are new, and meet what they asked to hear about.

An alert here is a setting in the window and a sentence from the engine. These pin what makes it honest:

  * it fires only after a read: the module reads no price, starts no timer and opens no connection, and the
    demonstration market never alerts;
  * new means not in the previous read on this Mac, per source, and a price that drifts is not a new play;
  * the first read has nothing to compare with and announces nothing;
  * a read that missed part of the board does not forget the part it missed;
  * the setting is checked before anything is read, and a bad one is refused in a sentence;
  * the sentence is the engine's and never promises more than an arb is.
"""

import json
import os
import re
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine import alerts, cli, pubfeed  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
ALERTS_SRC = (ROOT / "backend" / "overlay_engine" / "alerts.py").read_text()

SETTING = {"min_ev": 2.0, "min_arb": 5.0, "kinds": ["arb", "ev", "middle"], "recommended_only": True}


@pytest.fixture(autouse=True)
def throwaway_home(monkeypatch, tmp_path):
    """Never the real ~/.overlay."""
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def arb(event="g1", profit=12.0, books=("dk", "fd"), recommended=True, price=-105):
    return {"kind": "arb", "event": event, "event_id": event, "market": "h2h", "profit": profit, "margin": 0.012,
            "recommended": recommended,
            "legs": [{"book": b, "book_name": b.upper(), "outcome": f"side{i}", "american": price}
                     for i, b in enumerate(books)]}


def ev(event="g1", edge=0.04, book="dk", recommended=True, price=110):
    return {"kind": "ev", "event": event, "event_id": event, "market": "h2h", "profit": 1.0, "margin": edge,
            "recommended": recommended,
            "legs": [{"book": book, "book_name": book.upper(), "outcome": "home", "american": price}]}


def middle(event="g1"):
    return {"kind": "middle", "event": event, "event_id": event, "market": "totals", "profit": 0.0, "margin": 0.1,
            "recommended": True,
            "legs": [{"book": "dk", "book_name": "DK", "outcome": "over@45.5", "american": -110},
                     {"book": "fd", "book_name": "FD", "outcome": "under@47.5", "american": -110}]}


# ------------------------------------------------------------ the setting is checked, not repaired

def test_a_good_setting_is_read_and_missing_parts_take_their_defaults():
    assert alerts.parse(json.dumps(SETTING)) == SETTING
    assert alerts.parse("{}") == {"min_ev": 0.0, "min_arb": 0.0, "kinds": ["arb", "ev", "middle"],
                                  "recommended_only": True}
    assert alerts.parse('{"kinds": ["ev", "arb"]}')["kinds"] == ["arb", "ev"]


def test_a_field_typed_in_the_window_is_read_as_typed():
    typed = alerts.parse('{"min_ev": " 3% ", "min_arb": "$1,250.50", "kinds": ["ev"]}')
    assert typed["min_ev"] == 3.0 and typed["min_arb"] == 1250.5
    assert alerts.parse('{"min_ev": "", "min_arb": " "}')["min_ev"] == 0.0, "an empty field is no minimum"


@pytest.mark.parametrize("text", [
    "", "not json", "[]", "3", '{"min_ev": "three"}', '{"min_ev": "3 4"}', '{"min_ev": true}', '{"min_ev": "nan"}', '{"min_ev": -1}', '{"min_ev": 5000}',
    '{"min_arb": -0.01}', '{"min_arb": 1e12}', '{"kinds": []}', '{"kinds": ["lab"]}', '{"kinds": "arb"}',
    '{"recommended_only": "yes"}', '{"surprise": 1}', '{"min_ev": NaN}'])
def test_a_setting_that_makes_no_sense_is_refused_in_a_sentence(text):
    with pytest.raises(alerts.AlertError) as raised:
        alerts.parse(text)
    said = str(raised.value)
    assert said.endswith(".") and "Traceback" not in said and "\n" not in said


# ------------------------------------------------------------ what meets the setting

def test_an_ev_play_must_reach_the_edge_asked_for_and_an_arb_the_return_asked_for():
    assert alerts.meets(ev(edge=0.02), SETTING) and not alerts.meets(ev(edge=0.0199), SETTING)
    assert alerts.meets(arb(profit=5.0), SETTING) and not alerts.meets(arb(profit=4.99), SETTING)
    assert alerts.meets(middle(), SETTING), "a middle has no minimum"


def test_only_the_kinds_asked_for_are_alerted():
    only_ev = {**SETTING, "kinds": ["ev"]}
    assert alerts.meets(ev(), only_ev) and not alerts.meets(arb(), only_ev) and not alerts.meets(middle(), only_ev)


def test_recommended_only_leaves_out_what_recommended_would_hide_and_all_does_not():
    hidden = ev(recommended=False)
    assert not alerts.meets(hidden, SETTING)
    assert alerts.meets(hidden, {**SETTING, "recommended_only": False})


def test_a_play_is_the_same_play_when_only_its_price_moves():
    a, b = arb(price=-105), arb(price=-112, profit=9.0)
    assert alerts.play_key(a) == alerts.play_key(b)
    assert alerts.play_key(arb(books=("dk", "mgm"))) != alerts.play_key(a), "another book is another play"
    assert alerts.play_key(arb(event="g2")) != alerts.play_key(a)
    assert alerts.play_key(ev()) != alerts.play_key(arb())


# ------------------------------------------------------------ new since the previous read

def test_the_first_read_records_the_board_and_announces_nothing():
    rows = [arb(), ev()]
    out = alerts.check(rows, SETTING, "oddsapi", 1000.0)
    assert out["first_read"] is True and out["matched"] == 0 and out["message"] == ""
    assert "first refresh" in out["status"] and not any(r.get("alert") for r in rows)
    assert alerts.recall("oddsapi") == {alerts.play_key(r) for r in rows}


def test_a_play_that_was_not_in_the_previous_read_and_meets_the_setting_is_marked_and_worded():
    alerts.check([arb()], SETTING, "oddsapi", 1000.0)
    fresh = ev("g2", edge=0.05)
    rows = [fresh, arb(price=-108)]
    out = alerts.check(rows, SETTING, "oddsapi", 2000.0)
    assert out["first_read"] is False and out["new"] == 1 and out["matched"] == 1
    assert fresh["alert"] is True and "alert" not in rows[1]
    assert out["message"] == out["status"]
    assert out["message"].startswith("New play meets your alert: g2, +110 at DK for a +5.0% edge")


def test_a_new_play_under_the_setting_is_counted_but_not_announced():
    alerts.check([], SETTING, "oddsapi", 1000.0)
    rows = [ev(edge=0.01), arb(profit=2.0, event="g9")]
    out = alerts.check(rows, SETTING, "oddsapi", 2000.0)
    assert out["new"] == 2 and out["matched"] == 0 and out["message"] == ""
    assert "No new play meets your alert" in out["status"] and not any(r.get("alert") for r in rows)


def test_the_same_board_twice_announces_nothing_the_second_time():
    rows = [arb(), ev()]
    alerts.check([], SETTING, "oddsapi", 1000.0)
    assert alerts.check(rows, SETTING, "oddsapi", 2000.0)["matched"] == 2
    again = alerts.check([dict(r) for r in rows], SETTING, "oddsapi", 3000.0)
    assert again["matched"] == 0 and again["new"] == 0 and again["status"] == "No new play since the last refresh."


def test_a_play_that_left_the_board_and_came_back_is_new_again():
    alerts.check([arb()], SETTING, "oddsapi", 1000.0)
    alerts.check([], SETTING, "oddsapi", 2000.0)
    assert alerts.check([arb()], SETTING, "oddsapi", 3000.0)["matched"] == 1


def test_a_play_below_the_setting_last_time_is_not_new_when_it_crosses_it():
    """New is about the board, not about the threshold: the rule the setting's own sentence states."""
    alerts.check([ev(edge=0.01)], SETTING, "oddsapi", 1000.0)
    assert alerts.check([ev(edge=0.09)], SETTING, "oddsapi", 2000.0)["matched"] == 0


def test_each_source_keeps_its_own_previous_read():
    alerts.check([arb()], SETTING, "oddsapi", 1000.0)
    other = alerts.check([arb()], SETTING, "live", 1000.0)
    assert other["first_read"] is True, "Live prices never read before, whatever the sportsbook board held"
    assert alerts.recall("live") == alerts.recall("oddsapi")


def test_a_read_that_missed_part_of_the_board_does_not_forget_the_part_it_missed():
    alerts.check([arb("g1"), arb("g2")], SETTING, "oddsapi", 1000.0)
    alerts.check([arb("g1")], SETTING, "oddsapi", 2000.0, complete=False)
    back = alerts.check([arb("g1"), arb("g2")], SETTING, "oddsapi", 3000.0)
    assert back["new"] == 0, "g2 was missing from a read that failed, not gone"


def test_a_complete_read_replaces_the_record():
    alerts.check([arb("g1"), arb("g2")], SETTING, "oddsapi", 1000.0)
    alerts.check([arb("g1")], SETTING, "oddsapi", 2000.0)
    assert alerts.recall("oddsapi") == {alerts.play_key(arb("g1"))}


def test_a_record_this_version_cannot_read_announces_nothing_rather_than_everything(throwaway_home):
    path = throwaway_home / "alerts" / "seen-oddsapi.json"
    path.parent.mkdir()
    for junk in ("", "{", '{"plays": 3}', '{"plays": [1]}', '[]'):
        path.write_text(junk)
        out = alerts.check([arb()], SETTING, "oddsapi", 1000.0)
        assert out["first_read"] is True and out["message"] == "", junk


def test_the_demonstration_market_and_unknown_sources_cannot_alert():
    with pytest.raises(alerts.AlertError):
        alerts.check([arb()], SETTING, "demo", 1000.0)


def test_a_read_that_gave_nothing_to_compare_leaves_the_record_as_it_was():
    alerts.check([arb()], SETTING, "live", 1000.0)
    before = alerts.recall("live")
    out = alerts.skipped(SETTING, "pick your state to see pairs you can place.")
    assert out["message"] == "" and out["status"].startswith("Alerts were not checked") and alerts.recall("live") == before


# ------------------------------------------------------------ the sentence

def test_the_sentence_is_one_line_in_the_engines_words_and_never_promises_more_than_an_arb_is():
    rows = [arb(profit=12.5), ev(edge=0.06, recommended=False), middle()]
    for r in rows:
        r["alert"] = True
    one = alerts.message(rows[:1])
    many = alerts.message(rows)
    assert one == ("New play meets your alert: g1, $12.50 locked at DK and FD if both bets are accepted and stand.")
    assert many.startswith("3 new plays meet your alert. First: g1, $12.50 locked")
    assert "(not Recommended)" in alerts.describe(rows[1]) and "a middle at DK and FD" in alerts.describe(rows[2])
    for text in (one, many, alerts.NOTE, alerts.WHEN, alerts.describe(rows[1])):
        low = text.lower()
        assert "\n" not in text
        assert "guaranteed" not in low and "risk-free" not in low and "risk free" not in low and "either way" not in low
    assert alerts.message([]) == ""


def test_the_message_is_short_enough_for_a_notification_for_a_real_board():
    long_event = "The University of Southern Mississippi Golden Eagles vs The Ohio State Buckeyes"
    assert len(alerts.message([arb(event=long_event)] * 9)) < 300


# ------------------------------------------------------------ the module reads nothing and runs nothing

def test_alerts_fetches_nothing_and_starts_nothing():
    """By what it imports: it can neither read a price nor start a timer, because it cannot reach the code that
    would. (Its own words mention the sources by name, so the source text is not what is searched.)"""
    import ast
    tree = ast.parse(ALERTS_SRC)
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported |= {a.name for a in node.names}
        elif isinstance(node, ast.ImportFrom):
            imported.add(("." * node.level) + (node.module or ""))
    assert imported <= {"__future__", "json", "os", "tempfile", "pathlib", ".ledger", ".catalog"}, imported
    calls = {getattr(n.func, "attr", getattr(n.func, "id", "")) for n in ast.walk(tree) if isinstance(n, ast.Call)}
    assert not calls & {"sleep", "Timer", "Thread", "urlopen", "connect", "system", "Popen", "run"}, calls


def test_the_only_thing_alerts_writes_is_its_own_small_record(throwaway_home):
    alerts.check([arb()], SETTING, "oddsapi", 1000.0)
    written = sorted(str(p.relative_to(throwaway_home)) for p in throwaway_home.rglob("*") if p.is_file())
    assert written == [os.path.join("alerts", "seen-oddsapi.json")]


# ------------------------------------------------------------ through the command line, as the window calls it

def _run(*argv):
    import contextlib
    import io
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        code = cli.main(["board", *argv, "--json"])
    return code, json.loads(out.getvalue())


def test_alerts_without_a_read_you_start_are_refused_and_read_nothing(monkeypatch, throwaway_home):
    import socket

    def refuse(*a, **k):
        raise AssertionError("the board touched the network")
    monkeypatch.setattr(pubfeed, "urllib_fetcher", refuse)
    monkeypatch.setattr(socket.socket, "connect", refuse)
    setting = json.dumps(SETTING)
    for argv in (["--alerts", setting], ["--alerts", setting, "--state", "PA"],
                 ["--feed", "oddsapi", "--alerts", setting, "--screen"],
                 ["--feed", "oddsapi", "--alerts", setting, "--lowhold"],
                 ["--feed", "oddsapi", "--alerts", setting, "--estimate"]):
        code, out = _run(*argv)
        assert code == 2 and "--alerts" in out["error"], argv
    assert not (throwaway_home / "alerts").exists(), "a refused alert wrote a record"


def test_a_bad_setting_never_takes_the_board_away_and_is_said_in_the_answer(monkeypatch, throwaway_home):
    from test_xvenue import Venues
    for bad in ('{"min_ev": -3}', '{"min_ev": "lots"}', '{"kinds": []}', "nonsense"):
        v = Venues()
        monkeypatch.setattr(pubfeed, "urllib_fetcher", v)
        code, out = _run("--live", "--state", "PA", "--alerts", bad)
        block = out["alerts"]
        assert code == 0 and v.requests, "the person pressed the read, so it happens"
        assert block["enabled"] is False and block["message"] == "" and block["matched"] == 0
        assert block["status"].endswith("Alerts were not checked on this refresh.") and "\n" not in block["status"]
        assert out["cross_venue"]["matched"] == 19, "the board is still there"
    assert not (throwaway_home / "alerts").exists(), "a setting that could not be used recorded a read"


def test_the_demonstration_board_without_alerts_sends_no_alerts_block(throwaway_home):
    code, out = _run()
    assert code == 0 and "alerts" not in out and not (throwaway_home / "alerts").exists()


def test_live_prices_announce_a_new_pair_once_and_say_so_when_the_first_read_had_nothing_to_compare(monkeypatch):
    from test_xvenue import Venues, arb_world
    # The Titans at 15c are a longshot Recommended would hide, so this asks to hear about all plays.
    setting = json.dumps({**SETTING, "min_arb": 1.0, "recommended_only": False})
    argv = ["--live", "--state", "PA", "--alerts", setting]

    monkeypatch.setattr(pubfeed, "urllib_fetcher", Venues())
    code, first = _run(*argv)
    assert code == 0 and first["alerts"]["first_read"] is True and first["alerts"]["message"] == ""

    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    code, second = _run(*argv)
    [pair] = second["cross_venue"]["pairs"]
    block = second["alerts"]
    assert pair["alert"] is True and block["matched"] == 1 and block["first_read"] is False
    assert block["message"].startswith("New play meets your alert: ") and "Kalshi and Polymarket US" in block["message"]
    assert f"${pair['profit']:,.2f} locked" in block["message"] and "if both bets are accepted and stand" in block["message"]
    assert pair["recommended"] is False and "(not Recommended)" in block["message"]

    assert alerts.recall("live") and alerts.recall("oddsapi") is None, "Live prices have their own record"

    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    code, third = _run(*argv)
    assert third["alerts"]["matched"] == 0 and "alert" not in third["cross_venue"]["pairs"][0]


def test_live_prices_with_no_state_or_in_a_closed_state_do_not_touch_the_record(monkeypatch):
    from test_xvenue import arb_world
    setting = json.dumps({**SETTING, "min_arb": 1.0, "recommended_only": False})
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _run("--live", "--state", "PA", "--alerts", setting)
    before = alerts.recall("live")
    assert before
    _, no_state = _run("--live", "--alerts", setting)
    assert no_state["alerts"]["status"].startswith("Alerts were not checked") and alerts.recall("live") == before
    _, closed = _run("--live", "--state", "MI", "--alerts", setting)
    assert closed["alerts"]["message"] == "" and alerts.recall("live") == before


def test_sportsbook_odds_announce_new_plays_after_a_refresh_you_pressed_and_not_before(monkeypatch):
    import test_oddsapi as to
    import test_parity_grid as tp
    from overlay_engine import keystore, oddsapi

    clock = to.Clock()
    api = to.FakeApi({"americanfootball_nfl": []})
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=clock))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: to.KEY)
    argv = ["--feed", "oddsapi", "--sport", "nfl", "--market", "h2h", "--market", "spreads", "--market", "totals",
            "--alerts", json.dumps({"min_ev": 0, "min_arb": 0, "kinds": ["arb", "ev", "middle"],
                                    "recommended_only": False})]

    code, first = _run(*argv)
    assert code == 0 and first["rows"] == [] and first["alerts"]["first_read"] is True
    assert len(api.calls) > 0
    calls = len(api.calls)

    api.payloads = {"americanfootball_nfl": tp.world()}
    clock.now += 600
    code, second = _run(*argv)
    assert len(api.calls) > calls, "the second read is one the person pressed"
    marked = [r for r in second["rows"] if r.get("alert")]
    block = second["alerts"]
    assert marked and block["matched"] == len(marked) == block["new"] and block["message"]
    assert {r["kind"] for r in second["rows"]} >= {"arb", "ev", "middle"}

    assert alerts.recall("oddsapi") and alerts.recall("live") is None, "the sportsbook board has its own record"

    clock.now += 600
    code, third = _run(*argv)
    assert third["alerts"]["matched"] == 0 and not any(r.get("alert") for r in third["rows"])


def test_without_alerts_the_sportsbook_board_is_exactly_what_it_was(monkeypatch, throwaway_home):
    import test_oddsapi as to
    import test_parity_grid as tp
    from overlay_engine import keystore, oddsapi

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: to.FakeApi({"americanfootball_nfl": tp.world()}))
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=to.Clock()))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: to.KEY)
    code, out = _run("--feed", "oddsapi", "--sport", "nfl", "--market", "h2h")
    assert code == 0 and "alerts" not in out and not any("alert" in r for r in out["rows"])
    assert not (throwaway_home / "alerts").exists()


def test_the_cli_says_what_alerts_is_for():
    import contextlib
    import io
    out = io.StringIO()
    with contextlib.redirect_stdout(out), pytest.raises(SystemExit):
        cli.main(["board", "--help"])
    text = re.sub(r"\s+", " ", out.getvalue())
    assert "--alerts" in text and "never runs by itself" in text
