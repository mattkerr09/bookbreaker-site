"""Ask's built-in answers, word for word where a reader could be misled.

Found while putting real answers on bookbreaker.bet/ask/ (2026-10-18): a loss read "$-13.03", and the bet-size answer
gave "$20.83" without saying it assumed a $1,000 bankroll at a quarter of full Kelly.
"""

from overlay_engine import asktables


def test_a_loss_puts_the_minus_before_the_dollar_sign():
    assert asktables.usd(-13.03) == "-$13.03" and asktables.usd(1234.5) == "$1,234.50" and asktables.usd(None) == "n/a"


def test_the_bet_size_answer_says_what_bankroll_and_fraction_it_used():
    r = {"full_kelly": 0.0833, "fraction": 0.25, "bankroll": 1000.0, "stake": 20.83, "stake_fraction": 0.02083}
    said = asktables._s_kelly({}, r)
    assert "25% of that on a $1,000 bankroll" in said and "tell me your bankroll" in said


def test_the_parlay_answer_says_what_it_assumed_about_each_leg():
    r = {"legs": 3, "per_100": {"wins": 811.16, "fair_wins": 947.62, "expected": -13.03}, "hold": 0.13,
         "assumption": "Only each leg's own price was given", "correlation_note": "Legs in different games."}
    said = asktables._s_parlay({}, r)
    assert "-$13.03" in said and "Only each leg's own price was given" in said
