"""Track this bet, in the window.

Static, like the other window tests. What a screenshot cannot show, and these pin:

  * every leg of a play that came with the engine's block has a Track this bet button, and so does the
    row detail; a live prediction-market pair has no block and so no button;
  * the form says that Bookbreaker never places a bet and that nothing is sent anywhere, and it is filled from
    the engine's block: the window writes none of the figures on it;
  * Save hands the engine's own block back to it, as one token, with the price and the stake as the person
    typed them, and the window works out nothing and asks nothing of any network;
  * the bets still open on My bets show only what the engine sends, and a bet is never settled without the
    person confirming first;
  * every field the window reads is one the engine really sends, and nothing it says promises more than it is;
  * the stylesheet is balanced (an unclosed `@media` once swallowed everything after it), every class the new
    markup uses has a rule, and the new rules use the window's tokens and no colour of their own.
"""

import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_track as tk  # noqa: E402

from overlay_engine import tracker, tracking  # noqa: E402
from overlay_engine.ledger import Ledger  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
JS = (ROOT / "ui" / "src" / "app.js").read_text()
CSS = (ROOT / "ui" / "src" / "app.css").read_text()
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way")


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


TRACK_JS = JS[JS.index("/* ------------------------------------------------------------ Track this bet"):]
TRACK_CSS = CSS[CSS.index("/* ------------------------------------------------------------ Track this bet"):]
CONSOLE = _braced(JS, "function consoleHTML(")
DIALOG = HTML[HTML.index('<dialog class="trk-dlg"'):HTML.index("</dialog>")]
RESULTS = _braced(JS, "function showResults(")


def _leaves(code: str) -> list:
    return re.findall(r"\$\{([^`{}]*)\}", code)


# ------------------------------------------------------------ where the button is

def test_each_leg_of_a_play_has_a_button_and_the_row_detail_has_a_card():
    assert '${l.track ? trackButton(p, i) : ""}' in CONSOLE, "a Track this bet button under every leg that has a block"
    detail = _braced(JS, "function detailHTML(")
    assert "${trackCard(p)}${fairHTML(d.fair)}" in detail, "the card leads the row detail"
    card = _braced(TRACK_JS, "function trackCard(")
    assert "p.legs.map" in card and "trackButton(p, i)" in card and "Track this bet" in card
    button = _braced(TRACK_JS, "function trackButton(")
    assert 'data-track="${esc(key)}"' in button and ">Track this bet</button>" in button


def test_the_engines_block_travels_with_each_leg_and_a_live_pair_has_none():
    play = _braced(JS, "function boardPlay(")
    assert "track: l.track" in play
    live = _braced(JS, "function livePlay(")
    assert "track" not in live, "a prediction-market pair has no fair price to save, and so no button"


def test_a_card_for_a_leg_without_a_block_is_empty():
    card = _braced(TRACK_JS, "function trackCard(")
    assert "l.track ?" in card and 'if (!rows) return "";' in card


# ------------------------------------------------------------ the form

def test_the_form_says_it_never_places_a_bet_and_that_nothing_is_sent_anywhere():
    text = re.sub(r"<[^>]+>", " ", DIALOG)
    text = re.sub(r"\s+", " ", text)
    assert "Bookbreaker never places a bet." in text
    assert "only records it, here on this Mac" in text and "Nothing is sent anywhere." in text
    assert 'type="button"' in DIALOG and "<form" in DIALOG
    assert 'id="trk-save"' in DIALOG and "Save to My bets" in DIALOG and 'id="trk-cancel"' in DIALOG


def test_the_form_has_the_two_things_the_person_can_change_and_nothing_else_to_type():
    inputs = re.findall(r"<input[^>]*>", DIALOG)
    assert [re.search(r'id="([^"]+)"', i).group(1) for i in inputs] == ["tk-price", "tk-stake"]
    assert "The price you got" in DIALOG and "What you bet" in DIALOG


def test_the_form_is_filled_from_the_engines_block_and_says_what_was_suggested():
    form = _braced(TRACK_JS, "function openTrack(")
    for part in ("plainPrice(t.american)", "String(t.stake)", "esc(t.selection)", "esc(t.book_name)", "trackFair(t)",
                 "Suggested by Bookbreaker: $${cash(t.stake)}"):
        assert part in form, part
    fair = _braced(TRACK_JS, "function trackFair(")
    assert "if (!t.fair) return" in fair and "esc(t.no_fair)" in fair
    assert "amer(f.american)" in fair and "esc(f.text)" in fair
    assert "The fair price stays what it was whatever price you got." in fair


def test_a_second_press_cannot_save_twice_because_every_form_opened_has_its_own_token():
    form = _braced(TRACK_JS, "function openTrack(")
    assert "ref: `trk-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`" in form
    assert "--ref=${TRACKING.ref}" in JS


def test_the_dialog_sits_in_the_arbitrage_panel_after_the_find_arbs_button():
    board = HTML[HTML.index('<section class="panel" id="panel-board"'):]
    board = board[:board.index("</section>")]
    assert board.index('data-run="board"') < board.index("<dialog")
    assert board.index("</dialog>") < len(board)
    assert re.findall(r'data-run="([a-z-]+)"', board) == ["board", "oddsboard"], "the form adds no data-run button"


def test_enter_saves_the_form_and_never_runs_the_page_behind_it():
    handler = TRACK_JS[TRACK_JS.index('document.getElementById("track-form").addEventListener("keydown"'):]
    handler = handler[:handler.index("});") + 3]
    assert 'ev.key !== "Enter"' in handler and "ev.stopPropagation();" in handler and 'run("track");' in handler


# ------------------------------------------------------------ what Save sends

def test_save_hands_the_engines_block_back_as_one_token_with_the_price_and_stake_as_typed():
    builder = JS[JS.index("    track: () => [\"track\""):JS.index("    // Say how a tracked bet ended")]
    for part in ("`--pick=${JSON.stringify(TRACKING.pick)}`", '`--price=${val("tk-price")}`',
                 '`--stake=${val("tk-stake")}`', "`--game=${TRACKING.game}`", "`--league=${TRACKING.league}`"):
        assert part in builder, part
    assert "TRACKING.pick.american" not in builder and "TRACKING.pick.stake" not in builder, (
        "the price and the stake are what the person typed, not what the engine suggested")
    assert re.search(r"^\s*track: \(\) => \[\"track\"", JS, re.M)
    assert "track: showTrack" in JS and "settle: showSettle" in JS


def test_a_saved_bet_marks_its_button_and_brings_my_bets_up_to_date():
    saved = _braced(TRACK_JS, "function showTrack(")
    assert "esc(out.text)" in saved and 'classList.add("is-saved")' in saved
    assert 'b.textContent = "Tracked"' in saved and 'run("results");' in saved


def test_the_window_computes_nothing_in_the_new_code():
    code = TRACK_JS.replace("Math.random().toString(36).slice(2, 8)", "TOKEN")
    for banned in (".toFixed(", ".reduce(", "parseFloat", "Number(", "Math.", "toLocaleString", "toPrecision"):
        assert banned not in code, banned
    leaves = _leaves(code)
    assert len(leaves) >= 40, "the extractor has drifted"
    for expr in leaves:
        bare = re.sub(r"\"[^\"]*\"|'[^']*'", "''", expr)
        assert not re.search(r"[\w)\]]\s*[*/%]\s*[\w(]|[\w)\]]\s+[+-]\s+[\w(]", bare), f"arithmetic on an engine figure: {expr}"


def test_the_engines_words_are_drawn_as_text_not_markup():
    for sink in ("document.write", "insertAdjacentHTML", "eval(", "new Function"):
        assert sink not in TRACK_JS
    texty = [x for x in _leaves(TRACK_JS)
             if re.search(r"\.(text|selection|book_name|no_fair|game|league|market|note|state|state_text|placed_text|fair_text|id)\b", x)]
    assert len(texty) >= 12, "the extractor has drifted"
    for expr in texty:
        if re.fullmatch(r"[\w.]+ \? \"[^\"]*\" : \"\"", expr):
            continue        # a separator printed only when a name is there: no engine text in it
        assert "esc(" in expr, f"engine text interpolated without esc(): {expr}"


def test_there_is_no_request_of_any_kind_in_the_new_code():
    for call in ("fetch(", "XMLHttpRequest", "WebSocket", "sendBeacon", "EventSource", "<script", "<img", "<link", "http://",
                 "https://", "navigator."):
        assert call not in TRACK_JS and call not in DIALOG, call
    assert "invoke(" not in TRACK_JS, "the window asks the engine through run(), like every other page"


# ------------------------------------------------------------ settling

def test_a_bet_is_never_settled_without_the_person_confirming_first():
    handler = TRACK_JS[TRACK_JS.index("document.addEventListener(\"click\", (ev) => {\n  const ask"):]
    handler = handler[:handler.index("function showSettle(")]
    ask = handler[:handler.index("const no = ")]
    assert "run(" not in ask, "pressing Won, Lost, A push or Void only asks"
    assert "data-settle-do" in ask and "Yes, settle it" in ask and "Not yet" in ask
    assert handler.count("run(") == 1 and 'run("settle");' in handler
    assert handler.index('run("settle");') > handler.index("data-settle-do]")


def test_the_four_results_and_what_each_one_means_are_said_before_it_is_confirmed():
    words = _braced(TRACK_JS, "function settleWords(")
    assert "usd(o.if_won, true)" in words and "usd(o.if_lost, true)" in words, "the money is the engine's"
    assert "The stake comes back" in words and "The book cancelled it" in words
    rows = _braced(TRACK_JS, "function openBetsHTML(")
    assert '["won", "lost", "push", "void"]' in rows and "It ended:" in rows


def test_settling_asks_the_engine_to_work_out_the_profit_and_then_refreshes_the_record():
    builder = JS[JS.index("    settle: () => ["):JS.index("    // Convert my own promo.")]
    assert '["track", `--settle=${SETTLE.id}`, `--result=${SETTLE.result}`]' in builder
    assert 'run("results");' in _braced(TRACK_JS, "function showSettle(")
    assert 'id="out-settle"' in HTML


def test_the_open_bets_are_listed_even_when_nothing_is_settled_yet():
    assert 0 <= RESULTS.index("TRACKER = out.tracker || null;") < RESULTS.index("if (!out.settled) {"), (
        "the open bets' buttons read the dashboard, so it is kept before the empty state returns")
    empty = RESULTS[RESULTS.index("if (!out.settled) {"):RESULTS.index("const sign =")]
    assert "${openBetsHTML(out.tracker)}" in empty and "return;" in empty
    assert "${openBetsHTML(TRACKER)}" in RESULTS
    assert "<h2>No settled bets yet</h2>" in empty, "the honest empty state is unchanged"


# ------------------------------------------------------------ every field the window reads is one the engine sends

def _read(var: str, code: str) -> set:
    return set(re.findall(rf"(?<![\w.]){var}\.([a-z_]+)", code))


def _engine_payloads(tmp_path):
    rows = tk._rows(("arb", "ev", "middle"), tk._middle_market())
    blocks = [leg["track"] for r in rows for leg in r.legs]
    bare = tracking.leg_pick("ev", tk.Market(event_id="e", sport="nfl", market_type="h2h", starts_at=None, quotes=[
        tk.Quote(book="dk", outcome=tk.Outcome("home"), decimal=2.0, seen_at=1.0),
        tk.Quote(book="fd", outcome=tk.Outcome("away"), decimal=2.0, seen_at=1.0)]), tk.DEFAULT_BOOKS,
        {"book": "dk", "outcome": "home", "decimal": 2.0, "american": 100, "stake": 10.0}, tracking.FairCache())
    with Ledger(tmp_path / "w.db") as db:
        for i in range(2):
            tk._save(db, ref=f"r{i}", now=tk.NOW + i)
        tk._save(db, tk._pick(fair=None, no_fair="x"), ref="n", now=tk.NOW + 5)
        dash = tracker.dashboard(db, __import__("overlay_engine.performance", fromlist=["x"]).report([]), {}, tk.NOW + 60)
    return blocks + [bare], dash


def test_every_field_the_window_reads_is_one_the_engine_sends(tmp_path):
    blocks, dash = _engine_payloads(tmp_path)
    sent = set().union(*(set(b) for b in blocks))
    fair = set().union(*(set(b["fair"]) for b in blocks if b["fair"]))
    opened = set().union(*(set(o) for o in dash["open"]))
    assert any(b["fair"] is None for b in blocks) and any(b["fair"] for b in blocks)

    card = _braced(TRACK_JS, "function trackCard(")
    form = _braced(TRACK_JS, "function openTrack(")
    fair_fn = _braced(TRACK_JS, "function trackFair(")
    open_fn = _braced(TRACK_JS, "function openBetsHTML(")
    words = _braced(TRACK_JS, "function settleWords(")
    play = _braced(JS, "function boardPlay(")

    assert _read("l.track", card) <= sent and _read("l.track", card), _read("l.track", card) - sent
    assert (_read("t", form) | _read("t", fair_fn)) <= sent, (_read("t", form) | _read("t", fair_fn)) - sent
    assert _read("f", fair_fn) <= fair and _read("f", fair_fn), _read("f", fair_fn) - fair
    assert _read("o", open_fn) <= opened and len(_read("o", open_fn)) >= 12, _read("o", open_fn) - opened
    assert _read("o", words) <= opened
    assert _read("t", open_fn) <= set(dash) and {"open", "open_note"} <= _read("t", open_fn)
    assert re.findall(r"\bl\.(track)\b", play) == ["track"]
    assert {"id", "game", "league", "selection", "market", "book", "book_name", "american", "stake", "priced",
            "fair_american", "fair_text", "state", "state_text", "placed_text", "if_won", "if_lost"} <= opened
    saved = _read("out", _braced(TRACK_JS, "function showTrack(")) | _read("out", _braced(TRACK_JS, "function showSettle("))
    assert saved == {"text"}


def test_the_engines_saved_and_settled_answers_carry_the_words_the_window_prints(tmp_path):
    with Ledger(tmp_path / "s.db") as db:
        saved = tk._save(db)
        settled = tracking.settle(db, saved["bet_id"], "won")
    assert isinstance(saved["text"], str) and isinstance(settled["text"], str)


# ------------------------------------------------------------ what it says

def test_nothing_in_the_new_window_code_promises_more_than_it_is():
    low = (TRACK_JS + DIALOG).lower()
    for word in BANNED:
        assert word not in low, word
    assert "never places a bet" in low and "counts in actual against expected profit" in low
    assert "average" in json.dumps(tk._save(Ledger(":memory:"))["text"]), "the engine's caveat travels with the number"


# ------------------------------------------------------------ the stylesheet

def _strip_comments(css: str) -> str:
    return re.sub(r"/\*.*?\*/", lambda m: re.sub(r"[^\n]", " ", m.group(0)), css, flags=re.S)


def test_the_stylesheet_is_balanced_and_every_section_starts_at_the_top_level():
    """An unclosed `@media` (twice, in 0.1.15) made every rule after it a rule of that media query: the deposit
    plan, the low-hold view, the state picker and the price ages were styled only in a narrow window."""
    bare = _strip_comments(CSS)
    assert bare.count("{") == bare.count("}"), "an unclosed or extra brace in app.css"
    depth = 0
    for n, line in enumerate(bare.split("\n"), 1):
        if depth and line.strip() and not line[0].isspace() and not line.lstrip().startswith("}"):
            raise AssertionError(f"app.css line {n} starts a rule at depth {depth}, inside a block nothing closed: {line[:60]}")
        depth += line.count("{") - line.count("}")
        assert depth >= 0, f"app.css line {n} closes more than was opened"
    assert depth == 0


def test_every_class_the_new_markup_uses_has_a_rule_and_is_drawn():
    used = {"trk-btn", "trk-row", "trk-w", "trk-p", "trk-s", "trk-dlg", "trk-form", "trk-line", "trk-inputs", "trk-fair",
            "trk-sub", "trk-never", "trk-after", "trk-openbets", "trk-open", "trk-o-main", "trk-o-what", "trk-o-price",
            "trk-o-meta", "trk-o-state", "trk-o-act", "trk-set", "trk-confirm", "is-saved", "done"}
    drawn = TRACK_JS + DIALOG
    for cls in used:
        if cls in ("is-saved", "done"):
            assert re.search(rf"\.{re.escape(cls)}\b", TRACK_CSS), f".{cls} has no rule in app.css"
        else:       # the class's own rule, not only a rule for something inside it
            assert re.search(rf"(?m)^\.{re.escape(cls)}\{{", TRACK_CSS), f".{cls} has no rule of its own in app.css"
        assert re.search(rf"\b{re.escape(cls)}\b", drawn), f".{cls} is styled and never drawn"
    for state in ("live", "upcoming", "waiting"):
        assert re.search(rf"\.trk-o-state\.{state}\b", TRACK_CSS), state
    for cls in ("trk-fair", "trk-never", "trk-confirm", "trk-o-state"):
        assert re.search(rf'class="[^"]*\b{cls}\b', drawn), cls


def test_the_new_styles_use_the_windows_tokens_and_no_colour_of_their_own():
    assert TRACK_CSS.count("{") > 40, "the extractor has drifted"
    assert not re.search(r"#[0-9a-fA-F]{3,8}\b", TRACK_CSS), "a hex colour in the new styles belongs in the token set"
    assert not re.search(r"\brgba?\(", TRACK_CSS) and not re.search(r"\bhsla?\(", TRACK_CSS)
    for token in sorted(set(re.findall(r"var\((--[\w-]+)", TRACK_CSS))):
        assert re.search(rf"{re.escape(token)}\s*:", CSS), f"{token} is not defined"


def test_the_form_is_styled_for_both_themes_by_the_same_tokens():
    assert "background:var(--panel)" in TRACK_CSS and "color:var(--ink)" in TRACK_CSS
    assert "::backdrop" in TRACK_CSS and "color-mix(in srgb,var(--ink)" in TRACK_CSS
