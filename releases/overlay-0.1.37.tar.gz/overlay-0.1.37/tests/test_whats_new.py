"""What's new: the releases, newest first, in plain words, bundled with the app.

The page is a data file (ui/src/whatsnew.js) the window reads and draws. These pin:

  * a release cannot ship without its entry: the newest entry is the version the app is built as, and
    scripts/check_whatsnew.py (run first by build_app.sh and release.sh) refuses one that is not;
  * the history has no holes and no entry out of order, and the words keep the house style;
  * the window fetches nothing, draws the file's text as text, and shows "Updated to X" once, on the first launch after
    an update, never on a fresh install, remembered in its own storage on this Mac.
"""

import importlib.util
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))
CHECK_PATH = ROOT / "scripts" / "check_whatsnew.py"
_spec = importlib.util.spec_from_file_location("check_whatsnew", CHECK_PATH)
check = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(check)

DATA = ROOT / "ui" / "src" / "whatsnew.js"
DATA_TEXT = DATA.read_text()
ENTRIES = check.load(DATA)
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
JS = (ROOT / "ui" / "src" / "app.js").read_text()
CSS = (ROOT / "ui" / "src" / "app.css").read_text()
BUILD = (ROOT / "scripts" / "build_app.sh").read_text()
RELEASE = (ROOT / "scripts" / "release.sh").read_text()
APP_VERSION = json.loads((ROOT / "ui" / "src-tauri" / "tauri.conf.json").read_text())["version"]

SURFACES = {"Ask", "Arbitrage", "Promos", "My bets", "Tools", "Odds source", "Alerts", "Window"}
#: Built and never published (no download exists), so no person was ever on them.
NEVER_PUBLISHED = {"0.1.13", "0.1.16"}
FIRST = "0.1.9"
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way", "free bet")


def _v(version):
    return tuple(int(p) for p in version.split("."))


def _braced(text, anchor):
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        depth += {"{": 1, "}": -1}.get(text[i], 0)
        if depth == 0:
            return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


# ------------------------------------------------------------------ the data

def test_the_newest_entry_is_the_version_the_app_is_built_as():
    """The reason the file exists as a gate: a release with no entry would show the release before it as the news."""
    assert ENTRIES[0]["version"] == APP_VERSION, (
        f"tauri.conf.json is {APP_VERSION} and What's new starts at {ENTRIES[0]['version']}: add the entry to "
        "ui/src/whatsnew.js")
    import overlay_engine
    assert ENTRIES[0]["version"] == overlay_engine.__version__


def test_every_entry_has_the_shape_the_window_draws():
    for e in ENTRIES:
        assert set(e) == {"version", "date", "title", "notes"}, e.get("version")
        assert re.fullmatch(r"\d+\.\d+\.\d+", e["version"])
        assert re.fullmatch(r"20\d\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])", e["date"]), e["date"]
        assert e["title"].strip() and e["notes"], e["version"]
        for n in e["notes"]:
            assert set(n) == {"where", "text"}, e["version"]
            assert n["where"] in SURFACES, f"{e['version']}: {n['where']!r} is not one of {sorted(SURFACES)}"
            assert n["text"].strip().endswith("."), f"{e['version']}: a note is a sentence"


def test_the_history_runs_newest_first_with_no_holes():
    versions = [e["version"] for e in ENTRIES]
    assert versions == sorted(versions, key=_v, reverse=True), "newest first, each version once"
    assert len(set(versions)) == len(versions)
    dates = [e["date"] for e in ENTRIES]
    assert dates == sorted(dates, reverse=True), "a later version is never dated before an earlier one"
    assert versions[-1] == FIRST
    newest = _v(versions[0])
    expected = {f"{newest[0]}.{newest[1]}.{p}" for p in range(_v(FIRST)[2], newest[2] + 1)} - NEVER_PUBLISHED
    assert set(versions) == expected, f"missing {sorted(expected - set(versions))}, extra {sorted(set(versions) - expected)}"


def test_the_words_keep_the_house_style():
    for e in ENTRIES:
        text = json.dumps([e["title"]] + [n["text"] for n in e["notes"]], ensure_ascii=False)
        low = text.lower()
        for word in BANNED:
            assert word not in low, f"{e['version']} says {word!r}"
        assert "—" not in text and "&mdash;" not in low, f"{e['version']} has an em-dash"
        assert "http" not in low, f"{e['version']} names a web address"
        assert not re.search(r"\bH0\d\d\b", text), f"{e['version']} names a research finding"
        assert "edge lab" not in low and "edgelab" not in low


def test_the_data_file_is_plain_data():
    """Read by a JSON parser and loaded by a script tag: no code, no request."""
    code = "\n".join(l for l in DATA_TEXT.splitlines() if not l.lstrip().startswith("//"))
    assert code.strip().startswith("window.WHATS_NEW = [") and code.strip().endswith("];")
    for call in ("fetch(", "import(", "XMLHttpRequest", "eval(", "document.", "function"):
        assert call not in code, call


# ------------------------------------------------------------------ the gate on a build

def test_the_check_refuses_a_version_with_no_entry(tmp_path, capsys):
    data = tmp_path / "whatsnew.js"
    data.write_text(DATA_TEXT)
    assert check.main([APP_VERSION, "--data", str(data)]) == 0
    assert check.main(["99.0.0", "--data", str(data)]) == 1
    assert "no entry for 99.0.0" in capsys.readouterr().err


def test_the_check_refuses_an_entry_that_is_not_the_newest(tmp_path, capsys):
    older = ENTRIES[1]["version"]
    assert check.main([older]) == 1
    assert "not the newest" in capsys.readouterr().err


def test_the_check_refuses_data_it_cannot_read(tmp_path, capsys):
    broken = tmp_path / "whatsnew.js"
    broken.write_text("window.WHATS_NEW = [ {oops} ];")
    assert check.main([APP_VERSION, "--data", str(broken)]) == 2
    assert check.main([APP_VERSION, "--data", str(tmp_path / "missing.js")]) == 2


def test_the_check_runs_as_a_script_and_reads_the_apps_version():
    out = subprocess.run([sys.executable, str(CHECK_PATH)], capture_output=True, text=True, cwd=ROOT)
    assert out.returncode == 0 and APP_VERSION in out.stdout


def test_both_build_scripts_run_the_check_before_they_build_anything():
    assert "scripts/check_whatsnew.py" in BUILD and "scripts/check_whatsnew.py" in RELEASE
    assert BUILD.index("check_whatsnew.py") < BUILD.index("building the engine sidecar")
    assert RELEASE.index("check_whatsnew.py") < RELEASE.index('echo "── clean')
    # A failure stops the script rather than being reported and passed over.
    for script in (BUILD, RELEASE):
        line = script[script.index("check_whatsnew.py"):].split("\n\n")[0]
        assert "|| {" in line and "exit 1" in line, line


def test_the_app_hash_list_and_the_previews_carry_the_file():
    assert "app.js whatsnew.js" in BUILD, "the recorded frontend hashes leave the data file out"
    assert "whatsnew.js" in (ROOT / "scripts" / "preview_ui.sh").read_text()
    assert "whatsnew.js" in (ROOT / "scripts" / "preview_live.py").read_text()


# ------------------------------------------------------------------ the window

def test_the_page_has_a_link_a_dialog_and_a_note_and_loads_the_data_first():
    assert re.search(r'<footer>.*<button[^>]*id="whats-new"[^>]*>', HTML, re.S), "no link in the footer"
    for needle in ('id="wn-dlg"', 'id="wn-list"', 'id="wn-close"', 'id="wn-note"', 'id="wn-see"', 'id="wn-x"'):
        assert needle in HTML, needle
    data = HTML.index('<script src="whatsnew.js"></script>')
    assert data < HTML.index('<script src="app.js"></script>'), "the window runs before its data is there"


SECTION = JS[JS.index("/* ------------------------------------------------------------ What's new"):
             JS.index("/* ------------------------------------------------------------ Track this bet")]


def test_the_window_draws_the_files_text_as_text_and_requests_nothing():
    html = _braced(SECTION, "function whatsNewHTML()")
    for field in ("r.version", "r.title", "n.where", "n.text", "wnDate(r.date)"):
        assert f"esc({field})" in html, f"{field} reaches the page unescaped"
    assert not re.search(r"\$\{(?!esc\(|wnList\(\)\.map|r\.notes\.map)", html), "an unescaped value in the markup"
    for call in ("fetch(", "XMLHttpRequest", "WebSocket", "invoke(", "__TAURI__", "setTimeout", "setInterval",
                 "sendBeacon", "eval("):
        assert call not in SECTION, call
    assert re.findall(r"localStorage", SECTION) == [], "storage goes through the window's store, nothing else"


def test_the_note_is_shown_once_after_an_update_and_never_on_a_fresh_install():
    launch = _braced(SECTION, "function whatsNewOnLaunch()")
    # What was on this Mac is read before the window runs any code of its own (a launch writes its own settings).
    assert 0 < JS.index("keys() {") < JS.index("const KEPT_BEFORE_LAUNCH") < JS.index("keys() {") + 600, "snapshot taken right after the store"
    assert "KEPT_BEFORE_LAUNCH.length" in launch and "before === now" in launch
    # Written before the note is shown, so it is shown once; and only a version that has an entry is announced.
    assert launch.index("store.set(WN_KEY, now)") < launch.index("note.hidden = false")
    assert "wnList().some((r) => r.version === now)" in launch
    assert 'const WN_KEY = "bb.seenVersion"' in SECTION
    assert SECTION.count("whatsNewOnLaunch()") == 2, "defined once and called once, at load"


NODE = shutil.which("node")


@pytest.mark.skipif(NODE is None, reason="node is not installed")
@pytest.mark.parametrize("stored, kept, shown", [
    (None, [], False),                      # a fresh install
    (None, ["bb.state"], True),             # an update from a copy that never wrote the key
    ('"0.1.1"', ["bb.state"], True),        # an update from a copy that did
    ('"%s"' % APP_VERSION, ["bb.state"], False),   # the second launch of the same version
])
def test_the_note_logic_runs_as_described(stored, kept, shown):
    """The real functions, run against a stand-in for the page and its storage."""
    start = JS.index("const WN_KEY")
    code = JS[start:JS.index('document.getElementById("whats-new").addEventListener')]
    script = f"""
const mem = {{}}; if ({json.dumps(stored)} !== null) mem["bb.seenVersion"] = {json.dumps(stored)};
const store = {{ get: (k, d) => (k in mem ? JSON.parse(mem[k]) : d), set: (k, v) => {{ mem[k] = JSON.stringify(v); }} }};
const KEPT_BEFORE_LAUNCH = {json.dumps(kept)};
const esc = (t) => String(t);
const note = {{ hidden: true, querySelector: () => ({{}}) }};
global.window = {{ WHATS_NEW: {json.dumps([{"version": APP_VERSION}])} }};
global.document = {{
  querySelector: () => ({{ textContent: "You are running {APP_VERSION}. Check for updates" }}),
  getElementById: () => note }};
{code}
whatsNewOnLaunch();
const first = note.hidden === false; note.hidden = true;
whatsNewOnLaunch();                         // a second launch of the same version, same storage
console.log(JSON.stringify({{ first, second: note.hidden === false, seen: mem["bb.seenVersion"] }}));
"""
    out = subprocess.run([NODE, "-e", script], capture_output=True, text=True, timeout=30)
    assert out.returncode == 0, out.stderr
    got = json.loads(out.stdout)
    assert got == {"first": shown, "second": False, "seen": json.dumps(APP_VERSION)}


def test_the_new_markup_is_styled_in_the_windows_own_colours():
    start = CSS.index("/* ------------------------------------------------------------ what's new")
    mine = CSS[start:CSS.index("/* ------------------------------------------------------------ ", start + 10)]
    used = set(re.findall(r'class="(wn-[a-z-]+)"', HTML + SECTION))
    assert {"wn-link", "wn-dlg", "wn-note", "wn-rel", "wn-items", "wn-tag"} <= used, "the extractor has drifted"
    for cls in used:
        assert re.search(rf"\.{cls}(?![a-z-])", mine), f".{cls} has no rule"
    assert not re.search(r"#[0-9a-fA-F]{3,8}\b", mine), "a colour of its own in the new styles"
