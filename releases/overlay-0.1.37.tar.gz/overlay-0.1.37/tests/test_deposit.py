"""The deposit plan: which books to fund in a state, in what order, and how much.

The failures that matter here are the quiet ones. A book that is not licensed in the
state, listed because its offer was big. An expectation ranked above a locked amount, or
added to one. A deposit larger than the bankroll, or a fraction of a deposit that unlocks
nothing. A book that limits winning accounts presented as if it did not. A word that
promises more than a locked pair is: "guaranteed", "risk-free", "either way".

The synthetic feed below is built so the rules can be told apart: its largest expectation
is worth more than its largest locked amount, so an ordering by value and an ordering by
kind disagree, and a test that cannot tell them apart would pass on either.
"""

import csv
import datetime as dt
import json
import math
import re
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import catalog, crash, deposit, welcome

ROOT = Path(__file__).resolve().parent.parent
CLI = ROOT / "backend" / "cli.py"
TODAY = dt.date(2026, 10, 12)
FIELDS = ["book", "offer_type", "headline", "states", "qualifying_stake", "bonus",
          "installments", "boost", "max_stake", "expires_days", "ends", "read",
          "source", "note"]

#: Words that promise more than a locked pair is, anywhere a person could read them.
BANNED = (r"guarantee", r"risk-free", r"risk free", r"either way", r"free money",
          r"sure thing", r"\block\b")


def _write(tmp_path, rows, name="offers.csv"):
    path = tmp_path / name
    with path.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in FIELDS})
    return path


def _row(book, offer_type="bet_and_get", **kw):
    base = dict(book=book, offer_type=offer_type, headline=f"{book} offer", states="NJ",
                qualifying_stake="10", bonus="100", installments="1", expires_days="7",
                read=str(TODAY), source=f"https://example.com/{book}")
    base.update(kw)
    return base


def _world(tmp_path, rows):
    return welcome.load(_write(tmp_path, rows), today=TODAY)


#: Two locked offers, three expectations. The biggest expectation is worth more than the
#: biggest locked amount, so ordering by value and ordering by kind disagree.
MIXED = [
    _row("dk", bonus="150", qualifying_stake="5", installments="3"),
    _row("fd", bonus="250", qualifying_stake="25", installments="5"),
    _row("mgm", "bet_and_get_on_win", bonus="1000", qualifying_stake="10", installments="1"),
    _row("hardrock", "safety_net", qualifying_stake="5", max_stake="50", installments="10"),
    _row("caesars", "profit_boost", qualifying_stake="1", boost="1.0", max_stake="25",
         installments="10"),
]


def _plan(tmp_path, bankroll, rows=MIXED, state="NJ", **kw):
    return deposit.plan(state, bankroll, rows=_world(tmp_path, rows), none_rows=[],
                        today=TODAY, **kw)


def _strings(node):
    if isinstance(node, str):
        yield node
    elif isinstance(node, dict):
        for k, v in node.items():
            yield from _strings(k)
            yield from _strings(v)
    elif isinstance(node, (list, tuple)):
        for v in node:
            yield from _strings(v)


def _cli(*argv):
    return subprocess.run([sys.executable, str(CLI), *argv], capture_output=True, text=True,
                          timeout=120)


def _keys(out):
    return {i["book"] for part in ("fund", "left", "no_offer") for i in out[part]}


# ------------------------------------------------------------ the fixture is honest

def test_the_fixture_makes_value_order_and_kind_order_disagree(tmp_path):
    out = _plan(tmp_path, 100_000)
    locked = [i["value"] for i in out["fund"] if i["kind"] == "locked"]
    expected = [i["value"] for i in out["fund"] if i["kind"] == "expected"]
    assert locked and expected
    assert max(expected) > max(locked), "the fixture must disagree, or the order test proves nothing"


# ---------------------------------------------------------- only licensed books

def test_a_book_not_licensed_in_the_state_never_appears_whatever_its_offer_is_worth(tmp_path):
    """Borgata is licensed in New Jersey alone. A row that put it in Michigan could not
    be loaded, so this builds one by hand: the plan must still not list it."""
    assert not catalog.VENUES["borgata"].available_in("MI")
    rows = _world(tmp_path, [_row("dk", states="MI"), _row("borgata", bonus="5000", states="NJ")])
    rows[1]["_states"] = frozenset({"MI"})
    out = deposit.plan("MI", 10_000, rows=rows, none_rows=[], today=TODAY)
    assert "borgata" not in _keys(out)
    assert any(i["book"] == "dk" for i in out["fund"])


@pytest.mark.parametrize("state", ["MI", "NJ", "PA", "OH", "AZ", "IL", "NY", "CO", "VA", "TN"])
def test_every_book_in_the_plan_is_licensed_in_that_state(state):
    out = deposit.plan(state, 5_000, today=TODAY)
    licensed = {v.key for v in catalog.for_state(state)}
    assert _keys(out) <= licensed, sorted(_keys(out) - licensed)
    # Every licensed book is placed somewhere: funded, left, or said to have no offer.
    assert _keys(out) == licensed


def test_an_offer_written_for_another_state_is_not_used_in_this_one(tmp_path):
    out = _plan(tmp_path, 5_000, rows=[_row("dk", states="NJ")], state="PA")
    assert out["fund"] == [] and out["left"] == []
    [dk] = [i for i in out["no_offer"] if i["book"] == "dk"]
    assert "No welcome offer is on file" in dk["reason"]


def test_a_book_the_person_already_has_gets_no_offer(tmp_path):
    out = _plan(tmp_path, 5_000, have="dk, FanDuel")
    assert {"dk", "fd"}.isdisjoint({i["book"] for i in out["fund"] + out["left"]})
    reasons = {i["book"]: i["reason"] for i in out["no_offer"]}
    assert "already have an account" in reasons["dk"] and "already have an account" in reasons["fd"]


def test_a_book_the_app_does_not_know_is_refused_not_ignored(tmp_path):
    with pytest.raises(deposit.DepositError, match="dkk"):
        _plan(tmp_path, 1_000, have="dkk")


def test_a_stale_offer_is_not_funded(tmp_path):
    old = str(TODAY - dt.timedelta(days=welcome.MAX_AGE_DAYS + 1))
    out = _plan(tmp_path, 5_000, rows=[_row("dk", read=old)])
    assert out["fund"] == [] and out["left"] == []
    [dk] = [i for i in out["no_offer"] if i["book"] == "dk"]
    assert "last read" in dk["reason"] and "not priced" in dk["reason"]


# ---------------------------------------------------------------- the ordering rule

def test_locked_amounts_come_first_then_expectations_never_ranked_together(tmp_path):
    out = _plan(tmp_path, 100_000)
    kinds = [i["kind"] for i in out["fund"]]
    assert kinds == sorted(kinds, key=lambda k: k != "locked"), kinds
    assert kinds.count("locked") == 2 and kinds.count("expected") == 3
    # The biggest expectation is worth more than any locked amount and still comes after it.
    first_expected = next(i for i in out["fund"] if i["kind"] == "expected")
    assert first_expected["value"] > max(i["value"] for i in out["fund"] if i["kind"] == "locked")
    assert first_expected["order"] > kinds.count("locked")


def test_each_kind_is_ordered_by_its_own_value(tmp_path):
    out = _plan(tmp_path, 100_000)
    for kind in ("locked", "expected"):
        values = [i["value"] for i in out["fund"] if i["kind"] == kind]
        assert values == sorted(values, reverse=True), (kind, values)
    assert [i["order"] for i in out["fund"]] == list(range(1, len(out["fund"]) + 1))


def test_the_two_totals_are_never_added(tmp_path):
    out = _plan(tmp_path, 100_000)
    locked = sum(i["value"] for i in out["fund"] if i["kind"] == "locked")
    expected = sum(i["value"] for i in out["fund"] if i["kind"] == "expected")
    assert out["totals"]["locked"] == pytest.approx(locked)
    assert out["totals"]["expected"] == pytest.approx(expected)
    assert set(out["totals"]) == {"deposit", "locked", "expected"}
    assert out["totals"]["locked"] != pytest.approx(locked + expected)


def test_a_locked_amount_is_the_one_the_promos_panel_shows(tmp_path):
    """One implementation: the value in the plan is the Promos panel's, to the cent."""
    world = _world(tmp_path, MIXED)
    shown = {p.book: p for p in welcome.best_per_book(
        welcome.for_you(welcome.price(world), state="NJ"), "NJ")}
    out = deposit.plan("NJ", 100_000, rows=world, none_rows=[], today=TODAY)
    for i in out["fund"]:
        p = shown[i["book"]]
        assert i["value"] == pytest.approx(p.guaranteed if i["kind"] == "locked" else p.expected, abs=0.005)


def test_an_offer_worth_nothing_is_not_funded(tmp_path):
    out = _plan(tmp_path, 5_000, rows=[_row("dk", bonus="10", qualifying_stake="5000")])
    assert out["fund"] == [] and out["left"] == []
    [dk] = [i for i in out["no_offer"] if i["book"] == "dk"]
    assert "worth nothing" in dk["reason"]


# ------------------------------------------------------------------ what a deposit is

def test_a_bet_and_get_needs_the_qualifying_bet_plus_the_cash_a_hedge_needs(tmp_path):
    world = _world(tmp_path, [_row("dk", bonus="150", qualifying_stake="5", installments="3")])
    [p] = welcome.price(world)
    out = deposit.plan("NJ", 5_000, rows=world, none_rows=[], today=TODAY)
    [dk] = out["fund"]
    assert dk["qualify_cash"] == 5
    assert dk["hedge_cash"] == max(5, p.hedge_stake) == p.hedge_stake > 5, "the hedge is the bigger of the two"
    assert dk["deposit"] == dk["needs"] == dk["qualify_cash"] + dk["hedge_cash"]


def test_a_safety_net_needs_the_cash_bet_as_well_as_the_hedge(tmp_path):
    out = _plan(tmp_path, 100_000)
    [hr] = [i for i in out["fund"] if i["book"] == "hardrock"]
    assert hr["qualify_cash"] == 5 + 50                       # the unlock bet, and one token's cash bet
    assert hr["hedge_cash"] >= 5
    assert hr["deposit"] == hr["qualify_cash"] + hr["hedge_cash"]


def test_a_boost_is_not_hedged_so_it_needs_no_hedge_cash(tmp_path):
    out = _plan(tmp_path, 100_000)
    [cz] = [i for i in out["fund"] if i["book"] == "caesars"]
    assert cz["hedge_cash"] == 0 and cz["qualify_cash"] == 1 + 25 == cz["deposit"]


# ------------------------------------------------------------------- the bankroll cap

@pytest.mark.parametrize("bankroll", [0.5, 5, 26, 60, 100, 140, 250, 500, 999.99, 1_000, 2_500, 100_000])
def test_deposits_never_add_up_to_more_than_the_bankroll(tmp_path, bankroll):
    out = _plan(tmp_path, bankroll)
    total = sum(i["deposit"] for i in out["fund"])
    assert total <= bankroll + 1e-9
    assert out["totals"]["deposit"] == pytest.approx(total)
    assert out["unallocated"] == pytest.approx(bankroll - total, abs=0.005)


@pytest.mark.parametrize("bankroll", [60, 140, 250, 500, 1_000])
def test_a_book_is_funded_in_full_or_not_at_all(tmp_path, bankroll):
    out = _plan(tmp_path, bankroll)
    for i in out["fund"]:
        assert i["deposit"] == i["needs"]
    for i in out["left"]:
        assert "deposit" not in i
        assert i["short_by"] > 0 and i["needs"] > i["left_when"]


def test_when_the_bankroll_runs_out_it_says_so_and_names_the_books_left(tmp_path):
    out = _plan(tmp_path, 250)
    assert out["bankroll_ran_out"] and out["left"]
    for i in out["left"]:
        assert i["name"] in out["message"]
    assert "runs out" in out["message"]
    # What is left is everything funded in value order could not reach, each with its need.
    assert all(f"{i['name']} (needs {deposit.money(i['needs'])})" in out["message"] for i in out["left"])


def test_a_book_that_does_not_fit_is_passed_over_and_a_cheaper_one_behind_it_is_still_funded(tmp_path):
    rows = [_row("fd", bonus="250", qualifying_stake="1000", installments="5"),   # locked, dear
            _row("dk", bonus="150", qualifying_stake="5", installments="3")]      # locked, cheap
    out = _plan(tmp_path, 300, rows=rows)
    assert [i["book"] for i in out["left"]] == ["fd"]
    assert [i["book"] for i in out["fund"]] == ["dk"]


def test_a_bankroll_smaller_than_every_offer_funds_nothing_and_says_what_it_would_take(tmp_path):
    out = _plan(tmp_path, 20)
    assert out["fund"] == [] and out["left"]
    smallest = min(i["needs"] for i in out["left"])
    assert deposit.money(smallest) in out["message"] and "less than the smallest" in out["message"]


def test_a_bankroll_that_covers_everything_says_so(tmp_path):
    out = _plan(tmp_path, 100_000)
    assert not out["bankroll_ran_out"] and out["left"] == []
    assert "covers every priced offer" in out["message"]


@pytest.mark.parametrize("bad", [0, -5, float("nan"), float("inf"), "lots"])
def test_a_bankroll_that_is_not_a_positive_number_is_refused(bad):
    with pytest.raises(deposit.DepositError):
        deposit.plan("NJ", bad, rows=[], none_rows=[], today=TODAY)


def test_a_state_that_is_not_a_state_is_refused():
    with pytest.raises(deposit.DepositError, match="not a state"):
        deposit.plan("ZZ", 1_000, rows=[], none_rows=[], today=TODAY)


# --------------------------------------------------------------- no legal online book

def test_a_state_with_no_legal_betting_has_no_book_to_fund():
    out = deposit.plan("TX", 1_000, today=TODAY)
    assert out["online"] is False
    assert out["fund"] == [] and out["left"] == [] and out["no_offer"] == []
    assert "no legal sports betting in Texas" in out["message"]
    assert out["unallocated"] == 1_000 and out["totals"]["deposit"] == 0


def test_a_state_where_betting_is_legal_only_in_person_has_no_online_book():
    out = deposit.plan("MS", 1_000, today=TODAY)
    assert out["online"] is False and out["fund"] == [] and out["left"] == []
    assert "in person only" in out["message"] and "Mississippi" in out["message"]


def test_the_cli_says_so_in_a_sentence_for_such_a_state():
    got = _cli("deposit", "TX", "1000")
    assert got.returncode == 0, got.stderr
    assert "no legal sports betting in Texas" in got.stdout
    assert "deposit $" not in got.stdout.lower()


def test_a_state_with_books_but_no_priced_offer_funds_nothing_and_lists_the_books(tmp_path):
    out = _plan(tmp_path, 1_000, rows=[], state="NJ")
    assert out["online"] is True and out["fund"] == [] and out["left"] == []
    assert "No book licensed in New Jersey has a priced welcome offer" in out["message"]
    assert _keys(out) == {v.key for v in catalog.for_state("NJ")}


# -------------------------------------------------------------- books that limit winners

def test_a_book_that_limits_winners_is_marked_in_one_plain_sentence(tmp_path):
    out = _plan(tmp_path, 100_000)
    assert out["fund"]
    for i in out["fund"]:
        venue = catalog.VENUES[i["book"]]
        assert i["limits_winners"] is venue.limits_winners is True
        note = i["limit_note"]
        assert venue.name in note and note.endswith(".") and note.count(".") == 1
        assert "one-time" in note


def test_a_book_that_does_not_limit_winners_is_not_marked():
    out = deposit.plan("NJ", 5_000, today=TODAY)
    kalshi = [i for i in out["no_offer"] if i["book"] == "kalshi"]
    assert kalshi and kalshi[0]["limits_winners"] is False and kalshi[0]["limit_note"] == ""


def test_the_mark_is_on_the_books_left_too(tmp_path):
    out = _plan(tmp_path, 100)
    assert out["left"]
    assert all(i["limit_note"] for i in out["left"])


def test_the_limit_sentence_is_about_the_book_never_the_person():
    for venue in catalog.VENUES.values():
        s = deposit.limit_sentence(venue)
        assert not re.search(r"identity|kyc|device|location|vpn|spoof|multiple accounts", s, re.I)


# -------------------------------------------------------------------------- the words

@pytest.mark.parametrize("state,bankroll", [("MI", 1_000), ("MI", 100), ("NJ", 5_000), ("PA", 300),
                                            ("OH", 100_000), ("TX", 1_000), ("MS", 50)])
def test_no_word_promises_more_than_a_locked_pair_is(state, bankroll):
    out = deposit.plan(state, bankroll, today=TODAY)
    for text in list(_strings(out)) + [deposit.describe(out)]:
        for banned in BANNED:
            assert not re.search(banned, text, re.I), (banned, text)


def test_every_locked_amount_carries_its_condition(tmp_path):
    out = _plan(tmp_path, 100_000)
    for i in out["fund"] + out["left"]:
        if i["kind"] == "locked":
            assert i["value_text"].endswith(deposit.LOCKED_CONDITION)
        else:
            assert "not locked" in i["value_text"]
    human = deposit.describe(out)
    for line in human.splitlines():
        if re.search(r"\$[\d,.]+ locked", line):
            assert deposit.LOCKED_CONDITION in line, line


def test_the_plan_states_its_priors_and_what_a_deposit_counts():
    out = deposit.plan("MI", 1_000, today=TODAY)
    joined = " ".join(out["assumptions"])
    assert "PRIORS" in joined and "4.00" in joined and "2.0%" in joined
    assert "hedge" in joined and "not partly funded" in joined


def test_moving_the_priors_moves_the_hedge_cash(tmp_path):
    base = _plan(tmp_path, 100_000)
    longer = _plan(tmp_path, 100_000, bonus_decimal=6.0)
    a = {i["book"]: i["hedge_cash"] for i in base["fund"]}
    b = {i["book"]: i["hedge_cash"] for i in longer["fund"]}
    assert b["dk"] > a["dk"], "a longer price converts more of the bonus and needs a bigger hedge"
    assert "6.00" in " ".join(longer["assumptions"])


# --------------------------------------------------------------------------- the shape

ITEM_KEYS = {"book", "name", "kind", "value", "value_text", "offer", "offer_type", "installments",
             "needs", "qualify_cash", "hedge_cash", "breakdown", "limits_winners", "limit_note",
             "ends", "days_left", "ends_soon", "ends_note", "staged_note", "source", "read"}
TOP_KEYS = {"command", "state", "state_name", "bankroll", "online", "message", "locked_means",
            "assumptions", "fund", "left", "no_offer", "totals", "unallocated", "bankroll_ran_out",
            "table_read", "max_age_days", "have", "labels", "totals_text", "freshness"}


def _check_shape(out):
    assert set(out) == TOP_KEYS
    for i in out["fund"]:
        assert set(i) == ITEM_KEYS | {"deposit", "order"}
        assert i["kind"] in ("locked", "expected")
    for i in out["left"]:
        assert set(i) == ITEM_KEYS | {"short_by", "left_when", "left_text"}
    for i in out["no_offer"]:
        assert set(i) == {"book", "name", "reason", "limits_winners", "limit_note", "source", "read"}
    assert set(out["totals"]) == {"deposit", "locked", "expected"}
    json.dumps(out)


def test_the_json_has_the_documented_shape():
    # Dated, because the shipped feed ages: a test that needed Michigan to have a live
    # offer today would go red on the day the rows go stale, whatever the code did.
    out = deposit.plan("MI", 1_000, today=TODAY)
    assert out["command"] == "deposit" and out["state"] == "MI" and out["bankroll"] == 1000
    assert out["fund"] and out["left"] and out["no_offer"], "every part of the shape is exercised"
    _check_shape(json.loads(json.dumps(out)))


def test_the_cli_prints_that_same_shape_as_json():
    got = _cli("deposit", "MI", "1000", "--json")
    assert got.returncode == 0, got.stderr
    out = json.loads(got.stdout)
    assert out["command"] == "deposit" and out["state"] == "MI" and out["bankroll"] == 1000
    _check_shape(out)


def test_the_json_and_the_human_output_say_the_same_numbers():
    out = json.loads(_cli("deposit", "MI", "1000", "--json").stdout)
    human = _cli("deposit", "MI", "1000").stdout
    assert out["message"] in human
    for i in out["fund"]:
        assert f"{i['order']}. {i['name']}: deposit {deposit.money(i['deposit'])}" in human
        assert i["value_text"] in human


def test_the_json_for_a_state_with_nothing_to_fund_has_the_same_top_level_shape():
    out = json.loads(_cli("deposit", "TX", "1000", "--json").stdout)
    assert set(out) == TOP_KEYS and out["online"] is False


def test_a_typo_in_the_input_is_a_plain_refusal_not_a_crash():
    assert crash.is_expected(deposit.DepositError)
    for argv in (("deposit", "MI", "0"), ("deposit", "MI", "1000", "--have", "dkk")):
        got = _cli(*argv)
        assert got.returncode == 2, (argv, got.stdout, got.stderr)
        assert "Traceback" not in got.stderr and got.stderr.strip()
    got = _cli("deposit", "ZZ", "1000", "--json")
    assert got.returncode == 2 and "not a state" in json.loads(got.stdout)["error"]


def test_the_bankroll_must_be_a_number_in_the_windows_words():
    got = _cli("deposit", "MI", "lots", "--json")
    assert got.returncode == 2
    assert "not a number" in json.loads(got.stdout)["error"]


def test_the_cost_of_a_hedge_is_not_invented_for_an_offer_the_engine_cannot_size(tmp_path):
    """Every shape `welcome.load` accepts is one `cash_needed` can size."""
    for shape in welcome.OFFER_TYPES:
        assert shape in ("bet_and_get", "bet_and_get_on_win", "profit_boost", "safety_net")
    out = deposit.plan("MI", 100_000, today=TODAY)
    for i in out["fund"] + out["left"]:
        assert i["needs"] > 0 and math.isfinite(i["needs"])
