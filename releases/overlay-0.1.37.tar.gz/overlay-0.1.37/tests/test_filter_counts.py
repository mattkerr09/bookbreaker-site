"""Live result counts on the board's filters: how many plays each would leave, said before it is changed.

OddsJam's filter drawer prints "Show N results" as you tick. Ours is counted by the engine from the plays it already
sent (`filtercounts.py`), so the number is there before a switch is touched, and changing a filter reads nothing and
spends no credit. These pin:

  * the counts are the real thing: every figure the engine gives for a Hide under step equals what a read at that step
    really leaves, on the demonstration market, on sportsbook odds and on Live prices;
  * only an arb is held to Hide under (a +EV bet or a middle never counts out), and a read cannot count below its own
    figure, so it says so instead of guessing;
  * Recommended says what it leaves with it on and off, and a Bet warnings switch says how many plays it marks and that
    the list stays as it is;
  * a board that Hide under emptied says so, with the count it left out and a way back to 0%;
  * the window looks the sentences up and prints them: no arithmetic, no request, no timer, no read, and every class it
    draws has a rule in the stylesheet that uses the window's tokens.
"""

import contextlib
import io
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine import board as board_mod  # noqa: E402
from overlay_engine import betwarn, cli, filtercounts, pubfeed  # noqa: E402
from overlay_engine.arb import arb_margin  # noqa: E402
from overlay_engine.models import Market, Outcome, Quote  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
JS = (ROOT / "ui" / "src" / "app.js").read_text()
CSS = (ROOT / "ui" / "src" / "app.css").read_text()
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way")

START = "/* ------------------------------------------------------------ Filter counts"
SECTION = JS[JS.index(START):JS.index("/* ------------------------------------------------------------ Hidden plays")]
CODE = SECTION[SECTION.index("*/"):]
CSS_START = "/* ------------------------------------------------------------ filter counts"
FC_CSS = CSS[CSS.index(CSS_START):]


@pytest.fixture(autouse=True)
def throwaway_home(monkeypatch, tmp_path):
    """Never the real ~/.overlay."""
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def _run(*argv):
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        code = cli.main(["board", *argv, "--json"])
    return code, json.loads(out.getvalue())


# ------------------------------------------------------------ a board with arbs of several sizes

NOW = 1_000_000.0
WHEN = [("g1", 0.004, "h2h"), ("g2", 0.012, "totals"), ("g3", 0.021, "spreads"), ("g4", 0.034, "h2h"),
        ("g5", 0.058, "player_points"), ("g6", 0.015, "h2h_q1")]


def _market(event: str, margin: float, market_type: str) -> Market:
    """Two sides, each priced best at a different book, so the pair is an arb of about `margin`."""
    over = 2.0
    under = 1.0 / (1.0 / (1.0 + margin) - 1.0 / over)
    quotes = [Quote(book=b, outcome=Outcome(name=n, line=0.0 if market_type == "h2h" else 220.5), decimal=d,
                    seen_at=NOW - 5)
              for b, n, d in (("dk", "over", over), ("fd", "under", under), ("mgm", "over", over - 0.2),
                              ("czr", "under", under - 0.2))]
    return Market(event_id=event, sport="basketball_nba", market_type=market_type, quotes=quotes, starts_at=NOW + 5400)


def _markets():
    return [_market(*w) for w in WHEN]


def _scan(floor: float, stats=None):
    return board_mod.scan(_markets(), cli.DEFAULT_BOOKS, now=NOW, kinds=("arb",), min_margin=floor / 100.0, stats=stats)


def test_the_fixture_really_has_arbs_of_several_sizes_and_some_that_are_not_recommended():
    rows = _scan(0.0)
    assert len(rows) == len(WHEN)
    assert len({round(r.margin, 3) for r in rows}) == len(WHEN)
    assert 0 < sum(1 for r in rows if r.preset_misses) < len(rows)


def test_every_count_the_engine_gives_is_what_a_read_at_that_figure_really_leaves():
    table = filtercounts.of_rows(_scan(0.0), 0.0)
    assert [u["key"] for u in table["under"]] == ["0", "0.5", "1", "2", "3", "5"]
    for u in table["under"]:
        assert u["known"] is True
        real = _scan(float(u["key"]))
        assert u["all"] == len(real), u["key"]
        assert u["rec"] == sum(1 for r in real if not r.preset_misses), u["key"]
    assert [u["all"] for u in table["under"]] != [table["total"]] * 6, "the steps must actually change the count"


def test_a_read_at_a_figure_counts_what_a_higher_one_leaves_and_says_it_cannot_count_a_lower_one():
    stats = {}
    mine = _scan(2.0, stats)
    table = filtercounts.of_rows(mine, 2.0, stats["under_margin"])
    assert stats["under_margin"] == len(_scan(0.0)) - len(mine) > 0
    for u in table["under"]:
        if float(u["key"]) >= 2.0:
            assert u["known"] and u["all"] == len(_scan(float(u["key"]))), u["key"]
        else:
            assert not u["known"] and u["all"] is None and u["rec"] is None
            assert u["left_text"] == "not counted" and "already left out plays under 2%" in u["text_all"]
    assert table["left_out"] == stats["under_margin"]
    assert table["under_said"] == f"Hide under 2% left out {stats['under_margin']} plays on this read."


def test_a_figure_that_is_not_a_step_is_counted_too():
    stats = {}
    table = filtercounts.of_rows(_scan(1.5, stats), 1.5, stats["under_margin"])
    assert "1.5" in [u["key"] for u in table["under"]]
    here = next(u for u in table["under"] if u["key"] == "1.5")
    assert here["all"] == len(_scan(1.5))


def test_only_an_arb_is_held_to_hide_under():
    plays = [(0.001, False, True), (0.001, False, True), (0.5, True, True), (0.001, True, True), (0.02, True, False)]
    table = filtercounts.build(plays, 0.0)
    five = next(u for u in table["under"] if u["key"] == "5")
    assert five["all"] == 3 and five["rec"] == 3, "a +EV bet or a middle is never counted out"
    one = next(u for u in table["under"] if u["key"] == "1")
    assert one["all"] == 4 and one["rec"] == 3


def test_recommended_says_what_it_leaves_with_it_on_and_off():
    table = filtercounts.build([(0.01, True, True), (0.02, True, False), (0.03, True, False)], 0.0)
    assert table["recommended"]["if_on"] == "Recommended on: 1 of 3 plays"
    assert table["recommended"]["if_off"] == "Recommended off: 3 of 3 plays"
    assert filtercounts.build([(0.01, True, True)], 0.0)["recommended"]["if_on"] == "Recommended on: 1 of 1 play"


def test_a_bet_warnings_switch_says_how_many_plays_it_marks_and_that_the_list_stays():
    table = filtercounts.build([(0.01, True, True)] * 3, 0.0, 0, [{"code": "placed", "count": 2},
                                                                  {"code": "game", "count": 1}])
    assert table["warn"]["placed"] == "Marks 2 plays; the list stays as it is."
    assert table["warn"]["game"] == "Marks 1 play; the list stays as it is."
    assert table["warn"]["conflict"] == "Marks no plays on this board; the list stays as it is."
    assert set(table["warn"]) == set(betwarn.CODES)


def test_a_board_that_hide_under_emptied_says_so_and_how_many_it_left_out():
    stats = {}
    rows = _scan(9.0, stats)
    table = filtercounts.of_rows(rows, 9.0, stats["under_margin"])
    assert rows == [] and table["total"] == 0 and table["empty_by_under"] is True
    assert table["left_out"] == len(WHEN)
    assert table["empty_text"] == f"Hide under 9% left out {len(WHEN)} plays, so nothing is on this board."
    assert table["undo_under"] == {"key": "0", "label": "Set Hide under to 0%"}
    # An empty board is not "emptied by Hide under" when it was empty to begin with.
    assert filtercounts.build([], 0.0)["empty_by_under"] is False
    assert filtercounts.build([], 2.0, 0)["empty_by_under"] is False


def test_every_sentence_the_engine_writes_keeps_its_promises():
    stats = {}
    table = filtercounts.of_rows(_scan(2.0, stats), 2.0, stats["under_margin"], [{"code": "placed", "count": 1}])
    text = json.dumps(table).lower()
    for word in BANNED:
        assert word not in text, word
    assert "reads nothing and spends no credit" in table["note"] and "hid yourself is still counted" in table["note"]
    assert "Nothing is read until you do" in table["apply"]


# ------------------------------------------------------------ the three boards carry it

def test_the_demonstration_board_counts_what_a_read_at_each_figure_leaves():
    code, base = _run()
    table = base["filters"]
    assert code == 0 and table["total"] == len(base["rows"]) and "min_margin" in table
    assert any(r["kind"] != "arb" for r in base["rows"]), "the demonstration market has a +EV bet that Hide under never counts out"
    for u in table["under"]:
        _, real = _run("--min-margin", u["key"])
        assert u["all"] == len(real["rows"]), u["key"]
        assert u["rec"] == sum(1 for r in real["rows"] if r["recommended"]), u["key"]
    assert table["warn"].keys() == {"placed", "conflict", "game"}


def test_the_demonstration_board_that_hide_under_emptied_names_it():
    _, base = _run()
    arbs = sum(1 for r in base["rows"] if r["kind"] == "arb")
    _, tight = _run("--min-margin", "30", "--kind", "arb")
    assert tight["rows"] == [] and tight["filters"]["empty_by_under"] is True
    assert tight["filters"]["left_out"] == arbs > 0


def test_sportsbook_odds_count_the_same_way(monkeypatch):
    import test_oddsapi as to
    import test_parity_grid as tp
    from overlay_engine import keystore, oddsapi

    api = to.FakeApi({"americanfootball_nfl": tp.world()})
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=to.Clock()))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: to.KEY)
    argv = ["--feed", "oddsapi", "--sport", "nfl", "--market", "h2h", "--market", "spreads", "--market", "totals"]

    code, base = _run(*argv)
    table = base["filters"]
    assert code == 0 and table["total"] == len(base["rows"]) and any(r["kind"] == "arb" for r in base["rows"])
    arbs = [r for r in base["rows"] if r["kind"] == "arb"]
    floor = f"{arbs[0]['margin'] * 100 + 1:.4f}"
    code, cut = _run(*argv, "--min-margin", floor)
    assert [r for r in cut["rows"] if r["kind"] == "arb"] == []
    assert cut["filters"]["left_out"] == len(arbs) > 0
    assert len(cut["rows"]) == len(base["rows"]) - len(arbs) > 0, "a +EV bet and a middle stay"
    assert cut["filters"]["total"] == len(cut["rows"])


def test_live_prices_count_and_name_hide_under_when_it_leaves_nothing(monkeypatch):
    from test_xvenue import arb_world
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _, seen = _run("--live", "--state", "PA")
    [pair] = seen["cross_venue"]["pairs"]
    table = seen["cross_venue"]["filters"]
    assert table["total"] == 1 and table["recommended"]["kept"] == (1 if pair["recommended"] else 0)
    over = f"{pair['margin'] * 100 + 1:.2f}"
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _, tight = _run("--live", "--state", "PA", "--min-margin", over)
    assert tight["cross_venue"]["pairs"] == []
    emptied = tight["cross_venue"]["filters"]
    assert emptied["empty_by_under"] is True and emptied["left_out"] == 1
    # No state chosen: nothing is listed because of the state, never because of Hide under.
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _, nostate = _run("--live", "--min-margin", over)
    assert nostate["cross_venue"]["filters"]["empty_by_under"] is False


# ------------------------------------------------------------ the window

def test_every_board_the_window_draws_carries_the_engines_counts():
    assert "filters: xv.filters" in _braced(JS, "function showBoard(")
    assert "filters: out.filters" in _braced(JS, "function showBoard(")
    assert "filters: out.filters" in _braced(JS, "function showOddsboard(")
    assert "drawFilterCounts();" in _braced(JS, "function drawBoard(")


def test_the_window_looks_the_sentences_up_and_prints_them_as_text():
    draw = _braced(CODE, "function drawFilterCounts(")
    for field in ("F.recommended.if_off", "F.recommended.if_on", "u.text_rec", "u.text_all", "u.left_text_rec",
                  "u.left_text", "u.label", "F.under_said", "F.note", "F.warn[code]"):
        assert field in draw, field
    assert "${esc(F.note)}" in draw and "${esc(F.under_said)}" in draw
    assert "${esc(F.empty_text)}" in _braced(CODE, "function underEmptyHTML(") and "F.undo_under.label" in CODE
    for sink in ("document.write", "insertAdjacentHTML", "eval(", "new Function"):
        assert sink not in CODE
    assert "textContent" in draw, "the warning notes are set as text"


def test_the_window_computes_nothing_in_the_new_code():
    for banned in (".toFixed(", ".reduce(", "parseFloat", "Math.", "toLocaleString", "toPrecision", "Date.now", "new Date",
                   ".filter(", ".length"):
        assert banned not in CODE, banned
    leaves = re.findall(r"\$\{([^{}]*)\}", CODE)
    assert len(leaves) >= 8, "the extractor has drifted"
    for expr in leaves:
        bare = re.sub(r"\"[^\"]*\"|'[^']*'", "''", expr)
        assert not re.search(r"[\w)\]]\s*[*/%]\s*[\w(]|[\w)\]]\s+[+-]\s+[\w(]", bare), f"arithmetic: {expr}"


def test_changing_a_filter_reads_nothing_and_sends_nothing():
    for call in ("run(", "invoke(", "fetch(", "XMLHttpRequest", "setTimeout", "setInterval", "WebSocket", "localStorage",
                 "store.set"):
        assert call not in CODE, call
    click = _braced(CODE, 'document.addEventListener("click"')
    assert 'getElementById("b-min").value = c.dataset.under' in click and "sayUnder(" in click
    assert "run(" not in click and "AGAIN" not in click


def test_a_picked_figure_is_only_put_in_the_box_and_the_engine_says_when_it_applies():
    say = _braced(CODE, "function sayUnder(")
    assert "F.apply" in say and "u.text_rec" in say and "u.text_all" in say
    assert 'addEventListener("input", () => sayUnder(val("b-min")))' in CODE


def test_an_empty_board_names_the_filter_that_emptied_it_and_offers_to_undo_that_one():
    assert "underEmptied()" in _braced(JS, "function consoleHTML(")
    empty = _braced(CODE, "function underEmptyHTML(")
    assert "Hide under is leaving nothing on this board" in empty and 'data-under="${esc(F.undo_under.key)}"' in empty
    assert '"All left out by Hide under"' in _braced(JS, "function drawBoard(")
    # Recommended's own empty state gives the engine's count of what turning it off shows.
    assert "BOARD.filters.recommended.if_off" in _braced(JS, "function presetEmptyHTML(")
    # The order: a filter that emptied a board that had plays is named before Hide under is considered.
    body = _braced(JS, "function consoleHTML(")
    assert body.index("presetHidesAll()") < body.index("underEmptied()") < body.index("allHiddenByYou()")


def test_the_page_has_the_block_and_a_note_beside_each_bet_warnings_switch():
    assert re.search(r'<div class="fcounts" id="fcounts" role="status" aria-live="polite" hidden></div>', HTML)
    board = HTML[HTML.index('<section class="panel" id="panel-board"'):]
    board = board[:board.index("</section>")]
    assert board.index('data-run="board"') < board.index('id="fcounts"')
    for code in betwarn.CODES:
        assert f'id="fc-bw-{code}"' in HTML
    assert "<button" not in HTML[HTML.index('id="fcounts"'):HTML.index('id="fcounts"') + 80]


def test_every_class_the_new_markup_uses_has_a_rule_and_is_drawn():
    heads = {"fcounts": ".fcounts{", "fc-row": ".fc-row{", "fc-k": ".fc-k{", "fchips": ".fchips{", "fchip": ".fchip{",
             "fcount": ".fcount{", "fc-say": ".fcounts .fc-say{"}
    drawn = CODE + HTML
    for cls, head in heads.items():
        assert head in FC_CSS, f".{cls} has no rule in app.css"
        assert re.search(rf"\b{re.escape(cls)}\b", drawn), f".{cls} is styled and never drawn"


def test_the_new_styles_use_the_windows_tokens_and_no_colour_of_their_own():
    assert FC_CSS.count("{") >= 10, "the extractor has drifted"
    assert not re.search(r"#[0-9a-fA-F]{3,8}\b", FC_CSS) and not re.search(r"\b(rgba?|hsla?)\(", FC_CSS)
    root = CSS[CSS.index(":root{"):CSS.index("}", CSS.index(":root{"))]
    for token in sorted(set(re.findall(r"var\((--[\w-]+)", FC_CSS))):
        assert f"{token}:" in root, f"{token} is not one of the window's tokens"


def test_the_engine_module_makes_no_network_call_and_reads_nothing():
    src = Path(filtercounts.__file__).read_text()
    for word in ("urllib", "socket", "requests", "http", "open(", "sqlite3", "time."):
        assert word not in src.replace("`", ""), word
