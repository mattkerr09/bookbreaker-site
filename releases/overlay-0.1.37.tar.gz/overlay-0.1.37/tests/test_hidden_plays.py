"""Hide a play, with undo: the engine's identity and the window's list.

The engine decides which play is which (the key alerts use, never a price) and which hidden entries to drop; the window
keeps the list on this Mac, leaves a hidden play off the list of plays, and does no arithmetic. These pin:

  * every play is sent with the same key alerts use, so a price that moves does not unhide it;
  * a hidden play does not alert, and showing it again does not announce it as new;
  * an entry drops off the list only when it is off the board, its game has started and the read saw everything;
  * hiding changes what is drawn and nothing else: every play is still sent, checked and warned about;
  * the window hides by the engine's key alone, shows a one-line notice with Undo, lists what is hidden with Show again
    and Clear all, keeps the list in its own storage, and starts no read and no request for any of it.
"""

import contextlib
import io
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine import alerts, cli, hidden, pubfeed  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
JS = (ROOT / "ui" / "src" / "app.js").read_text()
CSS = (ROOT / "ui" / "src" / "app.css").read_text()
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way")

SETTING = {"min_ev": 0.0, "min_arb": 0.0, "kinds": ["arb", "ev", "middle"], "recommended_only": False}
START = "/* ------------------------------------------------------------ Hidden plays"
SECTION = JS[JS.index(START):JS.index("/* What each result pays")]
CODE = SECTION[SECTION.index("*/"):]          # the section without its own comment
CSS_START = "/* ------------------------------------------------------------ hidden plays"
HIDE_CSS = CSS[CSS.index(CSS_START):]


@pytest.fixture(autouse=True)
def throwaway_home(monkeypatch, tmp_path):
    """Never the real ~/.overlay."""
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def arb(event="g1", profit=12.0, books=("dk", "fd"), price=-105, starts=None):
    row = {"kind": "arb", "event": event, "event_id": event, "market": "h2h", "profit": profit, "margin": 0.012,
           "recommended": True,
           "legs": [{"book": b, "book_name": b.upper(), "outcome": f"side{i}", "american": price}
                    for i, b in enumerate(books)]}
    if starts is not None:
        row["starts_at"] = starts
    return row


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def _plain(html: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)).replace("&rsquo;", "’")


def _run(*argv):
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        code = cli.main(["board", *argv, "--json"])
    return code, json.loads(out.getvalue())


def _entry(key, starts=None):
    return {"key": key, "starts_at": starts}


# ------------------------------------------------------------ identity: the engine's, and never a price

def test_every_play_is_sent_with_the_key_alerts_use_and_a_moving_price_keeps_it():
    rows = [arb(price=-105), arb(price=-140, profit=3.0)]
    hidden.mark(rows)
    assert rows[0]["hide"]["key"] == alerts.play_key(rows[0]) == rows[1]["hide"]["key"]
    other = [arb(books=("dk", "mgm")), arb(event="g2")]
    hidden.mark(other)
    assert len({rows[0]["hide"]["key"], other[0]["hide"]["key"], other[1]["hide"]["key"]}) == 3
    assert "-105" not in rows[0]["hide"]["label"] and "12" not in rows[0]["hide"]["label"], "a label has no price"
    assert rows[0]["hide"]["label"] == "g1, moneyline arb at DK and FD"


def test_the_start_of_a_game_is_read_from_either_source_and_never_guessed():
    assert hidden.starts_at({"starts_at": 1_800_000_000.5}) == 1_800_000_000.5
    assert hidden.starts_at({"starts_at": "2026-10-13T00:00:00Z"}) == hidden.starts_at({"starts_at": "2026-10-13T00:00:00+00:00"})
    for nothing in ({}, {"starts_at": None}, {"starts_at": ""}, {"starts_at": "soon"}, {"starts_at": True}):
        assert hidden.starts_at(nothing) is None, nothing


def test_the_demonstration_market_is_marked_and_names_its_game_as_a_person_would():
    code, out = _run()
    assert code == 0 and "hidden" not in out
    for row in out["rows"]:
        assert set(row["hide"]) == {"key", "label", "starts_at"} and row["hide"]["key"] == alerts.play_key(row)
        assert row["hide"]["label"].startswith("BOS vs LAL, total ") and row["hide"]["starts_at"] is None


# ------------------------------------------------------------ hidden plays do not alert

def test_a_hidden_play_does_not_alert_and_showing_it_again_does_not_announce_it():
    alerts.check([], SETTING, "oddsapi", 1000.0)
    quiet, loud = arb("g1"), arb("g2")
    out = alerts.check([quiet, loud], SETTING, "oddsapi", 2000.0, hidden=frozenset({alerts.play_key(quiet)}))
    assert "alert" not in quiet and loud["alert"] is True
    assert out["matched"] == 1 and out["new"] == 1 and out["hidden_matched"] == 1
    assert "hidden, so it did not alert" in out["status"] and out["message"].startswith("New play meets your alert: g2")
    # It was recorded with the rest of the board, so showing it again later is not news.
    again = alerts.check([arb("g1"), arb("g2")], SETTING, "oddsapi", 3000.0)
    assert again["new"] == 0 and again["matched"] == 0


def test_an_alert_with_nothing_hidden_is_what_it_was():
    alerts.check([], SETTING, "oddsapi", 1000.0)
    out = alerts.check([arb()], SETTING, "oddsapi", 2000.0)
    assert out["matched"] == 1 and out["hidden_matched"] == 0 and "hidden" not in out["status"]


# ------------------------------------------------------------ which entries drop off the list

NOW = 2_000.0


def _board():
    rows = [arb("on-board", starts=1_000.0)]
    hidden.mark(rows)
    return rows, rows[0]["hide"]["key"]


def test_an_entry_drops_when_it_is_off_the_board_its_game_has_started_and_the_read_was_whole():
    rows, _ = _board()
    out = hidden.apply(rows, [_entry("gone", 1_500.0)], NOW)
    assert out["drop"] == ["gone"] and out["count"] == 0 and "its game has started" in out["sentence"]


def test_a_play_still_on_the_board_is_never_dropped():
    rows, key = _board()
    out = hidden.apply(rows, [_entry(key, 1_000.0)], NOW)
    assert out["drop"] == [] and out["count"] == 1 and out["on_board"] == 1


def test_a_game_that_has_not_started_or_has_no_start_on_file_stays_on_the_list():
    rows, _ = _board()
    out = hidden.apply(rows, [_entry("later", NOW + 60), _entry("unknown", None)], NOW)
    assert out["drop"] == [] and out["count"] == 2


def test_a_read_that_missed_part_of_the_board_or_never_happened_drops_nothing():
    rows, _ = _board()
    entries = [_entry("gone", 1_500.0)]
    assert hidden.apply(rows, entries, NOW, complete=False)["drop"] == []
    assert hidden.apply(rows, entries, None)["drop"] == [], "the demonstration market has no clock"


@pytest.mark.parametrize("text", [
    "", "nope", "{}", '"x"', '[1]', '[{"key": 3}]', '[{"key": ""}]', '[{"starts_at": 1}]', '[{"key": "a", "starts_at": "soon"}]',
    '[{"key": "a", "starts_at": true}]', '[{"key": "a", "extra": 1}]', '[{"key": "a", "starts_at": NaN}]'])
def test_a_list_the_engine_cannot_read_is_refused_in_a_sentence(text):
    with pytest.raises(hidden.HiddenError) as raised:
        hidden.parse(text)
    said = str(raised.value)
    assert said.endswith(".") and "\n" not in said and "Traceback" not in said


def test_a_good_list_is_read_as_sent():
    assert hidden.parse('[{"key": "a", "starts_at": 5}, {"key": "b", "starts_at": null}]') == [
        {"key": "a", "starts_at": 5.0}, {"key": "b", "starts_at": None}]
    assert hidden.parse("[]") == []


# ------------------------------------------------------------ through the command line, as the window calls it

def test_hidden_without_a_read_you_start_is_refused_and_reads_nothing(monkeypatch):
    def refuse(*a, **k):
        raise AssertionError("the board touched the network")
    monkeypatch.setattr(pubfeed, "urllib_fetcher", refuse)
    for argv in (["--hidden", "[]"], ["--hidden", "[]", "--state", "PA"], ["--feed", "oddsapi", "--hidden", "[]", "--screen"],
                 ["--feed", "oddsapi", "--hidden", "[]", "--lowhold"], ["--feed", "oddsapi", "--hidden", "[]", "--estimate"]):
        code, out = _run(*argv)
        assert code == 2 and "--hidden" in out["error"], argv


def test_live_prices_hide_nothing_themselves_and_hold_a_hidden_pair_back_from_alerts(monkeypatch):
    from test_xvenue import Venues, arb_world
    setting = json.dumps({**SETTING, "min_arb": 1.0})

    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _, seen = _run("--live", "--state", "PA")
    [pair] = seen["cross_venue"]["pairs"]
    key = pair["hide"]["key"]
    assert key == alerts.play_key({**pair, "cross": True}) and pair["hide"]["starts_at"] == pair.get("starts_at")

    # A read, then a read where the pair is new and the person has hidden it.
    monkeypatch.setattr(pubfeed, "urllib_fetcher", Venues())
    _run("--live", "--state", "PA", "--alerts", setting)
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    code, out = _run("--live", "--state", "PA", "--alerts", setting, "--hidden", json.dumps([_entry(key)]))
    assert code == 0 and out["alerts"]["matched"] == 0 and out["alerts"]["hidden_matched"] == 1
    [still] = out["cross_venue"]["pairs"]
    assert "alert" not in still, "a hidden pair is not marked"
    # Hiding changes what is drawn and nothing else: the pair, what it is worth and what was said about it are as they were.
    for field in ("profit", "margin", "legs", "warnings", "recommended", "hide"):
        assert still[field] == pair[field], field
    assert out["warnings"] == seen["warnings"]
    assert out["hidden"]["on_board"] == 1 and out["hidden"]["drop"] == []


def test_live_prices_name_the_entries_to_drop_and_only_those(monkeypatch):
    from test_xvenue import arb_world
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _, seen = _run("--live", "--state", "PA")
    key = seen["cross_venue"]["pairs"][0]["hide"]["key"]
    listed = [_entry(key, 1.0), _entry("started", 1.0), _entry("later", 9_999_999_999.0), _entry("unknown")]
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _, out = _run("--live", "--state", "PA", "--hidden", json.dumps(listed))
    assert out["hidden"]["drop"] == ["started"] and out["hidden"]["count"] == 3


def test_a_list_the_engine_cannot_read_never_takes_the_board_away(monkeypatch):
    from test_xvenue import arb_world
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    code, out = _run("--live", "--state", "PA", "--hidden", "not a list")
    assert code == 0 and len(out["cross_venue"]["pairs"]) == 1
    assert out["hidden"]["enabled"] is False and out["hidden"]["drop"] == [] and out["hidden"]["sentence"].endswith(".")


def test_sportsbook_odds_carry_the_block_and_hold_a_hidden_play_back_from_alerts(monkeypatch):
    import test_oddsapi as to
    import test_parity_grid as tp
    from overlay_engine import keystore, oddsapi

    clock = to.Clock()
    api = to.FakeApi({"americanfootball_nfl": []})
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=clock))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: to.KEY)
    argv = ["--feed", "oddsapi", "--sport", "nfl", "--market", "h2h", "--market", "spreads", "--market", "totals",
            "--alerts", json.dumps(SETTING)]
    _run(*argv)
    api.payloads = {"americanfootball_nfl": tp.world()}
    clock.now += 600
    _, plain = _run(*argv[:-2])
    rows = plain["rows"]
    assert rows and all(set(r["hide"]) == {"key", "label", "starts_at"} for r in rows)
    assert all(r["hide"]["key"] == alerts.play_key(r) for r in rows)
    assert all(isinstance(r["hide"]["starts_at"], float) for r in rows), "the feed's start is sent as seconds"
    assert plain["hidden"]["count"] == 0

    pick = rows[0]["hide"]["key"]
    clock.now += 600
    _, out = _run(*argv, "--hidden", json.dumps([_entry(pick), _entry("gone", 1.0)]))
    assert [r["hide"]["key"] for r in out["rows"]] == [r["hide"]["key"] for r in rows], "every play is still sent"
    muted = [r for r in out["rows"] if r["hide"]["key"] == pick][0]
    assert "alert" not in muted and out["hidden"]["drop"] == ["gone"] and out["hidden"]["on_board"] == 1
    assert out["alerts"]["hidden_matched"] == 1


def test_the_cli_says_what_hidden_is_for():
    out = io.StringIO()
    with contextlib.redirect_stdout(out), pytest.raises(SystemExit):
        cli.main(["board", "--help"])
    text = re.sub(r"\s+", " ", out.getvalue())
    assert "--hidden" in text and "Hides nothing itself" in text


def test_the_engines_own_live_pair_carries_the_block_the_window_hides_it_by():
    """The pair as the engine builds it, before the command line sees it."""
    import test_xvenue as tx
    pair = tx.scan(tx.arb_world()).pairs[0].as_dict()
    assert set(pair["hide"]) == {"key", "label", "starts_at"} and pair["hide"]["key"] == alerts.play_key({**pair, "cross": True})
    assert pair["hide"]["label"].endswith("moneyline arb at Kalshi and Polymarket US")


def test_every_sentence_the_engine_writes_keeps_its_promises():
    rows, key = _board()
    block = hidden.apply(rows, [_entry(key), _entry("gone", 1.0)], NOW)
    for text in (hidden.ALERTS_NOTE, hidden.STORED, hidden.DROPS, block["sentence"], hidden.refused("x.")["note"]):
        assert "\n" not in text
        for word in BANNED:
            assert word not in text.lower()


# ------------------------------------------------------------ the window: reads the engine's fields

def test_every_field_the_window_reads_is_one_the_engine_sends(monkeypatch):
    from test_xvenue import arb_world
    code, demo = _run()
    assert set(demo["rows"][0]["hide"]) >= set(re.findall(r"\bp\.hide\.([a-z_]+)", SECTION))
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _, live = _run("--live", "--state", "PA", "--hidden", "[]")
    assert set(re.findall(r"\bsaid\.([a-z_]+)", SECTION)) <= set(live["hidden"]) and "sentence" in live["hidden"]
    assert set(re.findall(r"\bp\.hide\.([a-z_]+)", SECTION)) == {"key", "label", "starts_at"}
    assert "hide: r.hide || null" in _braced(JS, "function boardPlay(") and "hide: r.hide || null" in _braced(JS, "function livePlay(")
    assert {"sentence", "drop"} <= set(live["hidden"])


# ------------------------------------------------------------ the window: the controls

def test_each_row_and_the_console_have_a_hide_control_and_the_row_s_is_not_nested_in_its_button():
    card = _braced(JS, "function listCard(")
    assert 'class="hidebtn" data-hide="${i}"' in card
    assert card.index("</button>${p.hide ?") < card.index('class="hidebtn"'), "a button cannot sit inside a button"
    assert '<button class="go ghost" data-hide="${PLAYS.indexOf(p)}">Hide this play</button>' in _braced(JS, "function consoleHTML(")


def test_hiding_shows_one_line_with_undo_and_redraws_without_reading_anything():
    notice = _braced(JS, "function hideNotice(")
    assert "Undo" in notice and "data-unhide" in notice and "hidenote" in notice and "esc(HIDE_NOTE.label)" in notice
    assert "${hideNotice()}" in _braced(JS, "function drawBoard(")
    hide = _braced(JS, "function hidePlay(")
    assert "HIDE_NOTE.key = p.hide.key" in hide and "keepHidden()" in hide and "redrawBoard()" in hide
    for fn in ("function hidePlay(", "function showAgain(", "function clearHidden(", "function redrawBoard("):
        body = _braced(JS, fn)
        for call in ("run(", "invoke(", "fetch(", "XMLHttpRequest", "setTimeout", "setInterval"):
            assert call not in body, (fn, call)
    for call in ("fetch(", "XMLHttpRequest", "invoke(", "setTimeout", "setInterval", "WebSocket", "localStorage"):
        assert call not in SECTION, call


def test_a_hidden_play_is_hidden_by_the_engines_key_alone_and_is_left_off_the_list_only():
    assert "const isHidden = (p) => !!(p && p.hide && HIDDEN.some((h) => h.key === p.hide.key));" in SECTION
    draw = _braced(JS, "function drawBoard(")
    assert "const kept = seen.filter(([p]) => !isHidden(p));" in draw
    assert "kept.filter(([p]) => p.kind" in draw
    for mutation in ("PLAYS =", "PLAYS.splice", "PLAYS.filter", "PLAYS.push", "PLAYS.pop", "PLAYS.shift", ".sort("):
        assert mutation not in CODE, f"hiding must not change the engine's list of plays: {mutation}"
    for other in ("BW[", "bwShown", "alertOf", "PRESET.on", "warn"):
        assert other not in CODE, f"hiding must not touch {other}"


def test_a_board_that_is_all_hidden_says_so_and_does_not_look_empty_of_plays():
    assert "if (allHiddenByYou()) return hiddenEmptyHTML();" in _braced(JS, "function consoleHTML(")
    assert '"All hidden by you"' in _braced(JS, "function drawBoard(")
    assert "const allHiddenByYou = () => !!(PLAYS.length && PLAYS.every(isHidden));" in SECTION
    assert "not gone" in _plain(_braced(JS, "function hiddenEmptyHTML("))


def test_the_list_is_in_the_settings_area_with_show_again_and_clear_all_and_starts_nothing():
    start = HTML.index('<details class="alerts" id="hidden-box">')
    box = HTML[start:HTML.index("</details>", start)]
    assert 'id="hidden-sum">Hidden plays (0)</summary>' in box
    assert 'id="hidden-clear"' in box and "Clear all" in box and "data-run" not in box
    board = HTML[HTML.index('<section class="panel" id="panel-board"'):]
    board = board[:board.index("</section>")]
    assert board.index('data-run="board"') < board.index('id="hidden-box"')
    listed = _braced(JS, "function drawHiddenList(")
    assert "Show again" in listed and "data-show-again" in listed and "esc(h.label)" in listed
    assert 'sum.textContent = `Hidden plays (${HIDDEN.length})`;' in listed
    assert "textContent = HIDDEN_SAID && HIDDEN.length ? HIDDEN_SAID.sentence" in listed, "the engine's sentence, as text"
    assert 'document.getElementById("hidden-clear").addEventListener("click", clearHidden);' in SECTION
    assert "HIDDEN.splice(0, HIDDEN.length)" in _braced(JS, "function clearHidden(")


def test_the_page_says_what_hiding_does_in_the_engines_words():
    text = _plain(HTML)
    for sentence in (hidden.ALERTS_NOTE, hidden.STORED, hidden.DROPS):
        assert sentence in text, sentence
    alerts_box = HTML[HTML.index('<details class="alerts" id="alerts-box">'):]
    assert hidden.ALERTS_NOTE in _plain(alerts_box[:alerts_box.index("</details>")]), "the alerts setting says it"
    for word in BANNED:
        assert word not in (_plain(HTML[HTML.index('id="hidden-box"'):]) + SECTION).lower()


# ------------------------------------------------------------ the window: kept on this Mac, sent to the engine only

def test_the_list_is_kept_in_this_windows_own_storage_and_read_back_defensively():
    assert 'store.get("bb.hidden", [])' in SECTION and 'store.set("bb.hidden", HIDDEN)' in SECTION
    restore = _braced(SECTION, "(function restoreHidden()")
    assert "Array.isArray(saved)" in restore and 'typeof h.key === "string"' in restore
    assert 'typeof h.starts_at === "number"' in restore


def test_the_list_goes_to_the_engine_only_with_a_read_the_person_started():
    argv = _braced(JS, "const argv = {")
    board = argv[argv.index("    board: () =>"):argv.index("    results: () =>")]
    odds = argv[argv.index("    oddsboard: () =>"):argv.index("    oddsestimate: () =>")]
    assert "...(liveOn() ? hiddenFlags() : [])" in board, "the demonstration board is never read"
    assert "...hiddenFlags()" in odds
    assert argv.count("hiddenFlags()") == 2, "no other action carries the list"
    flags = _braced(JS, "function hiddenFlags()")
    assert "`--hidden=${JSON.stringify(" in flags, "one token, so a list starting with a bracket is a value"
    assert "key: h.key, starts_at: h.starts_at" in flags and "label" not in flags
    assert "HIDDEN.length ?" in flags, "an empty list is no flag at all"


def test_the_engines_drop_list_is_applied_after_every_read_that_can_carry_one():
    said = _braced(JS, "function hiddenSaid(")
    assert "HIDDEN.filter((h) => drop.includes(h.key))" in said and "keepHidden()" in said
    assert "HIDE_NOTE.key = null" in said, "a new board does not carry the last notice"
    assert "hiddenSaid(out.hidden);" in _braced(JS, "function showBoard(")
    assert "hiddenSaid(out.hidden);" in _braced(JS, "function showOddsboard(")
    assert "hiddenSaid(null);" in _braced(JS, "function showBoard("), "the demonstration board drops nothing"


# ------------------------------------------------------------ the window computes nothing

def test_the_window_computes_nothing_in_the_new_code():
    for banned in (".toFixed(", ".reduce(", "parseFloat", "Math.", "toLocaleString", "toPrecision", "Date.now", "new Date"):
        assert banned not in SECTION, banned
    leaves = re.findall(r"\$\{([^{}]*)\}", SECTION)
    assert len(leaves) >= 4, "the extractor has drifted"
    for expr in leaves:
        bare = re.sub(r"\"[^\"]*\"|'[^']*'", "''", expr)
        assert not re.search(r"[\w)\]]\s*[*/%]\s*[\w(]|[\w)\]]\s+[+-]\s+[\w(]", bare), f"arithmetic: {expr}"


def test_the_engines_words_are_drawn_as_text_not_markup():
    for sink in ("document.write", "insertAdjacentHTML", "eval(", "new Function"):
        assert sink not in SECTION
    assert "${esc(h.label)}" in SECTION and "${esc(HIDE_NOTE.label)}" in SECTION
    assert 'data-unhide="${esc(HIDE_NOTE.key)}"' in SECTION and 'data-show-again="${esc(h.key)}"' in SECTION


# ------------------------------------------------------------ the stylesheet

def test_every_class_the_new_markup_uses_has_a_rule_and_is_drawn():
    drawn = SECTION + _braced(JS, "function listCard(")
    heads = {"arow": ".arow{", "hidebtn": ".hidebtn{", "hidenote": ".hidenote .linkish{", "hidden-items": ".hidden-items{"}
    for cls, head in heads.items():
        assert head in HIDE_CSS, f".{cls} has no rule in app.css"
        assert re.search(rf"\b{re.escape(cls)}\b", drawn), f".{cls} is styled and never drawn"


def test_the_new_styles_use_the_windows_tokens_and_no_colour_of_their_own():
    assert HIDE_CSS.count("{") >= 6, "the extractor has drifted"
    assert not re.search(r"#[0-9a-fA-F]{3,8}\b", HIDE_CSS) and not re.search(r"\b(rgba?|hsla?)\(", HIDE_CSS)
    for token in sorted(set(re.findall(r"var\((--[\w-]+)", HIDE_CSS))):
        assert re.search(rf"{re.escape(token)}\s*:", CSS), f"{token} is not defined"


def test_the_new_styles_are_a_balanced_top_level_section():
    assert HIDE_CSS.count("{") == HIDE_CSS.count("}") and CSS.count("{") == CSS.count("}")
