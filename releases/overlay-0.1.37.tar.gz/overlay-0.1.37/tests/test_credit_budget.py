"""How many refreshes the credits cover, said beside the cost before anything is read (oddsapi.budget)."""

import json
from pathlib import Path

from overlay_engine import cli, oddsapi

ROOT = Path(__file__).resolve().parent.parent


def test_with_no_refresh_seen_it_is_the_free_plans_500_divided_by_the_cost():
    b = oddsapi.budget(8, None)
    assert b["refreshes"] == 62 and b["remaining"] is None and "500 credits a month cover 62 refreshes" in b["text"]


def test_with_credits_recorded_it_is_what_is_left_divided_by_the_cost():
    b = oddsapi.budget(8, {"remaining": 100, "used": 400})
    assert b["refreshes"] == 12 and "100 credits left" in b["text"] and "12 more like this one" in b["text"]


def test_fewer_left_than_one_refresh_costs_is_said_plainly():
    b = oddsapi.budget(8, {"remaining": 5})
    assert b["refreshes"] == 0 and "fewer than this one costs" in b["text"]


def test_a_refresh_that_costs_nothing_says_nothing():
    assert oddsapi.budget(0, None)["text"] == ""


def test_the_estimate_carries_it_and_the_window_draws_the_engines_sentence(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    assert cli.main(["board", "--feed", "oddsapi", "--estimate", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["budget"]["refreshes"] == oddsapi.FREE_MONTHLY // out["estimate"]["credits"]
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    card = js[js.index("function showOddsestimate("):js.index("function showOddsestimate(") + 2000]
    assert "esc(out.budget.text)" in card and "/ " not in card.split("const budget")[1].split(";")[0]


# ------------------------------------------------------------ the bad-key and slow paths, end to end (gap #5)

import socket  # noqa: E402

import pytest  # noqa: E402

from overlay_engine import altlines  # noqa: E402
from overlay_engine.oddsapi import OddsApiError, explain, odds_api_fetcher  # noqa: E402

KEY = "0123456789abcdef0123456789abcdef"
GAME = "abc123def4567890"


@pytest.mark.parametrize("exc", [socket.timeout("timed out"), TimeoutError("read timed out")])
def test_a_request_that_times_out_is_a_sentence_without_the_key(exc):
    def opener(url, timeout=None):
        assert timeout == 15.0, "every request has a deadline"
        raise exc
    with pytest.raises(OddsApiError) as caught:
        odds_api_fetcher(opener=opener)("/v4/sports/x/odds", {"apiKey": KEY})
    assert caught.value.reason == "offline" and "could not reach The Odds API" in str(caught.value)
    assert KEY not in str(caught.value)


@pytest.mark.parametrize("status, body, headers, reason", [
    (401, '{"error_code": "INVALID_KEY"}', {}, "bad_key"),
    (401, '{"error_code": "OUT_OF_USAGE_CREDITS"}', {"x-requests-remaining": "0"}, "out_of_credits"),
    (429, '{"error_code": "EXCEEDED_FREQ_LIMIT"}', {"x-requests-remaining": "300"}, "slow_down"),
])
def test_a_refused_key_on_an_alternate_lines_read_keeps_its_reason_saves_nothing_and_hides_the_key(
        status, body, headers, reason, tmp_path, monkeypatch):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))

    def fetcher(path, params):
        raise explain(status, body, headers)
    with pytest.raises(OddsApiError) as caught:
        altlines.read(altlines.estimate("nfl", GAME), KEY, clock=lambda: 1_800_000_000.0, fetcher=fetcher)
    assert caught.value.reason == reason and KEY not in str(caught.value)
    assert altlines.load("nfl", GAME, now=1_800_000_000.0) is None, "a refused read is never kept"
