"""How old every price is, said on every row and every price, and greyed past a limit.

OddsJam's own tool reports stale odds as a flag a user raises by hand, and its
lines refresh on a timer the user sets. Bookbreaker does neither. A price here
says how old it is in words the engine chose, and one past a stated limit is
greyed with the reason. Nothing refreshes by itself: a read of Odds API prices
spends the person's credits, so it happens when they press the button and at no
other time.

Three things are held here:

  * the engine's side: the limits are constants with a boundary, the wording is
    one function, and every row, leg, grid cell and detail cell carries it;
  * the window's side: it prints the engine's words and flags and does no
    arithmetic on an age;
  * that no timer, focus handler or visibility handler can read the feed.
"""

import datetime as dt
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

import test_oddsapi as to  # noqa: E402
import test_parity_grid as tp  # noqa: E402
from overlay_engine import (FillModel, LatencyModel, board, oddsapi, screen,  # noqa: E402
                            staleness, xvenue)
from overlay_engine.staleness import STALE_AFTER, ago, ago_brief, price_age, stale_after  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()

NOW = to.NOW
BANNED = ("guaranteed", "risk-free", "risk free", "riskfree", "either way")


@pytest.fixture(autouse=True)
def home(monkeypatch, tmp_path):
    """Every read leaves its prices in the person's home folder. These tests must never write into the real one."""
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


# ================================================================ the limits

def test_the_limits_are_stated_constants():
    assert STALE_AFTER == {"live": 30.0, "player_prop": 300.0, "alt_line": 300.0, "default": 600.0}
    assert screen.OLD_AFTER == STALE_AFTER["default"], "a grid and a price are held to the same ten minutes"


def test_a_limit_depends_on_how_fast_the_market_moves():
    assert stale_after("h2h") == stale_after("spreads") == stale_after("totals") == 600.0
    assert stale_after("player_pass_yds") == 300.0 and stale_after("player_points_alternate") == 300.0
    assert stale_after("h2h", in_play=True) == 30.0, "a game under way is held to the shortest limit"
    assert stale_after("some market this version has never heard of") == 600.0


def test_a_price_is_stale_only_when_older_than_the_limit():
    assert price_age(600.0, "h2h")["stale"] is False, "exactly at the limit is the oldest a price can be and not be stale"
    assert price_age(600.1, "h2h")["stale"] is True
    assert price_age(300.0, "player_points")["stale"] is False and price_age(301.0, "player_points")["stale"] is True
    assert price_age(30.0, "moneyline", in_play=True)["stale"] is False
    assert price_age(31.0, "moneyline", in_play=True)["stale"] is True
    assert price_age(-5.0, "h2h")["seconds"] == 0.0, "a clock that ran backwards is not a negative age"


def test_a_stale_price_says_why_and_a_fresh_one_says_nothing():
    fresh, old = price_age(40.0, "h2h"), price_age(1500.0, "h2h")
    assert fresh["reason"] == "" and fresh["stale"] is False
    reason = old["reason"]
    assert "last confirmed 25 minutes ago" in reason and "10 minutes" in reason
    assert "check the price there before you bet" in reason
    assert "gone" not in reason.lower() and "wrong" not in reason.lower(), (
        "a price a book has not changed may still be good: past the limit is not the same as gone")
    assert old["limit_text"] == "10 minutes" and old["limit"] == 600.0
    assert "30 seconds" in price_age(60.0, "moneyline", in_play=True)["reason"]
    assert "5 minutes" in price_age(400.0, "player_points")["reason"]
    for text in (reason, old["text"], old["label"]):
        assert not any(b in text.lower() for b in BANNED)


# ================================================================ the words

def test_ages_are_worded_once_and_the_screens_function_is_that_one():
    assert screen.ago is staleness.ago
    assert [ago(s) for s in (0, 4, 5, 59, 60, 119, 3599, 3600, 7200)] == [
        "just now", "just now", "5 seconds ago", "59 seconds ago", "1 minute ago", "1 minute ago",
        "59 minutes ago", "1 hour ago", "2 hours ago"]


def test_the_brief_form_is_for_a_cell_in_a_grid():
    assert [ago_brief(s) for s in (0, 4, 5, 59, 60, 240, 3599, 3600, 7300)] == [
        "now", "now", "5 s", "59 s", "1 min", "4 min", "59 min", "1 h", "2 h"]


def test_a_price_age_carries_the_label_the_text_and_the_brief_in_the_verb_the_source_calls_for():
    got = price_age(240.0, "h2h")
    assert (got["label"], got["text"], got["brief"]) == ("confirmed 4 min ago", "last confirmed 4 minutes ago", "4 min")
    read = price_age(240.0, "moneyline", verb="read")
    assert (read["label"], read["text"]) == ("read 4 min ago", "read 4 minutes ago")
    assert price_age(2.0, "h2h")["label"] == "confirmed just now"
    assert price_age(2.0, "moneyline", verb="read")["label"] == "read just now"


# ================================================================ every row, every leg

def _rows(ages):
    """The Chiefs-Bills moneyline with each book's price confirmed `ages[book]` seconds before the read."""
    payload = [to.event("g1", start=NOW + 3600, books=[
        tp.full_book(key, ml=ml, updated=NOW - ages[key])
        for key, ml in (("draftkings", (2.10, 1.80)), ("fanduel", (1.80, 2.05)), ("pinnacle", (1.95, 1.95)))])]
    got, _ = tp.read(markets=["h2h"], payload=payload)
    rows = board.scan(oddsapi.split_by_line(got.markets), oddsapi.books_table(), kinds=("arb", "ev"),
                      bankroll=1000.0, now=got.now, fill_model=FillModel(), latency_model=LatencyModel(),
                      bettable=set(oddsapi.BETTABLE), names=got.book_names)
    return rows


def test_every_row_and_every_leg_says_how_old_its_price_is():
    rows = _rows({"draftkings": 20, "fanduel": 40, "pinnacle": 30})
    assert {r.kind for r in rows} == {"arb", "ev"}
    for row in rows:
        d = row.as_dict()
        assert d["price_age"]["seconds"] == pytest.approx(d["age"], abs=0.1)
        assert d["price_age"]["label"].startswith("confirmed ") and d["price_age"]["stale"] is False
        for leg in d["legs"]:
            assert leg["price_age"]["seconds"] == pytest.approx(leg["age"], abs=0.1)


def test_a_row_is_as_stale_as_its_oldest_price_and_only_that_leg_is_greyed():
    rows = _rows({"draftkings": 1800, "fanduel": 40, "pinnacle": 30})
    arb = next(r for r in rows if r.kind == "arb").as_dict()
    assert arb["price_age"]["stale"] is True, "the row is held to its oldest leg"
    by_book = {leg["book"]: leg["price_age"] for leg in arb["legs"]}
    assert by_book["dk"]["stale"] is True and by_book["fd"]["stale"] is False
    assert "30 minutes" in arb["price_age"]["reason"] and "10 minutes" in arb["price_age"]["reason"]


def test_a_prop_is_held_to_the_shorter_limit():
    d = board.Row(kind="ev", event="e", sport="nfl", market="player_pass_yds", age=400.0,
                  legs=[{"book": "dk", "outcome": "over@250.5", "age": 400.0}]).as_dict()
    assert d["price_age"]["stale"] is True and d["legs"][0]["price_age"]["stale"] is True
    assert "5 minutes" in d["price_age"]["reason"]


def test_a_game_under_way_is_held_to_thirty_seconds_and_a_live_pair_says_read():
    d = _pair(age=45.0, started=True)
    assert d["price_age"]["stale"] is True and d["price_age"]["limit"] == 30.0
    assert d["price_age"]["label"] == "read 45 s ago"
    assert "30 seconds" in d["price_age"]["reason"] and "in play" in d["price_age"]["reason"]
    fresh = _pair(age=5.0, started=False)
    assert fresh["price_age"]["stale"] is False and fresh["price_age"]["limit"] == 600.0


def _pair(age, started):
    when = dt.date(2026, 10, 22)
    teams = ("CHI", "PIT")
    read_at = 1000.0
    k = xvenue.Game("kalshi", teams, when, {"CHI": 0.60, "PIT": 0.40}, "KX", league="nhl",
                    size={t: 9999 for t in teams}, read_at=read_at)
    p = xvenue.Game("polymarket_us", teams, when, {"CHI": 0.50, "PIT": 0.62}, "aec-nhl-chi-pit-2026-10-22",
                    league="nhl", size={t: 9999 for t in teams}, long="CHI", fee_rate=0.0695, read_at=read_at,
                    starts_at=read_at + age - 10 if started else read_at + 86400,
                    depth_at={t: read_at for t in teams})
    [pair] = [r for r in xvenue.price_pairs([(k, p)], now=read_at + age) if r.profit > 0]
    return pair.as_dict()


def test_the_live_sportsbook_board_names_the_moment_its_ages_are_counted_to_and_carries_the_preset(monkeypatch, capsys):
    """The window does not tick, so an age printed as '4 min' would quietly become false while it sits open. The
    board says what the ages are counted to, and a press of the button reads once and spends once."""
    import json
    from types import SimpleNamespace

    from overlay_engine import cli, keystore

    payload = [to.event("g1", start=NOW + 3600, books=[
        tp.full_book(key, ml=ml, updated=NOW - age)
        for key, ml, age in (("draftkings", (2.10, 1.80), 1800), ("fanduel", (1.80, 2.05), 40),
                             ("pinnacle", (1.95, 1.95), 30))])]
    api = to.FakeApi({"americanfootball_nfl": payload})
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=to.Clock()))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: to.KEY)
    assert cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--market", "h2h", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["as_of"] == NOW == out["read_at"]
    assert out["rows"] and all(r["price_age"]["seconds"] == pytest.approx(r["age"], abs=0.1) for r in out["rows"])
    assert any(r["price_age"]["stale"] for r in out["rows"]) and any(not r["price_age"]["stale"] for r in out["rows"])
    assert out["preset"]["total"] == len(out["rows"]), "the preset speaks of every row the board sent"
    assert len(api.calls) == 1, "one press, one read"


# ================================================================ every price on the grid and in the detail

def _screen(ages):
    payload = [to.event("g1", start=NOW + 3600, books=[
        tp.full_book(key, ml=ml, spread=None, total=None, updated=NOW - ages[key])
        for key, ml in (("draftkings", (2.10, 1.80)), ("fanduel", (1.80, 2.05)), ("pinnacle", (1.95, 1.95)))])]
    got, _ = tp.read(markets=["h2h"], payload=payload)
    return screen.from_refresh(got, set(oddsapi.BETTABLE)), got


def test_every_cell_on_the_odds_screen_says_its_age_and_whether_it_is_greyed():
    s, _ = _screen({"draftkings": 1500, "fanduel": 30, "pinnacle": 45})
    grid = tp.grid_of(s)
    cells = [(book, c) for g in grid["games"] for r in g["rows"] for book, c in r["cells"].items()]
    assert cells
    for book, c in cells:
        assert c["age_brief"] == ago_brief(c["age"]) and c["stale"] is (c["age"] > 600.0)
        assert bool(c["stale_reason"]) is c["stale"]
    assert {book for book, c in cells if c["stale"]} == {"dk"}
    assert all(c["age_brief"] == "25 min" for book, c in cells if book == "dk")


def test_the_grid_explains_its_greyed_cells_once_with_the_limit():
    s, _ = _screen({"draftkings": 1500, "fanduel": 30, "pinnacle": 45})
    grid = tp.grid_of(s)
    assert grid["stale_prices"] == 2 and grid["stale_limit_text"] == "10 minutes"
    assert grid["stale_note"].startswith("2 of 6 prices are greyed") and "10 minutes" in grid["stale_note"]


def test_a_grid_of_fresh_prices_has_nothing_to_explain():
    fresh, _ = _screen({"draftkings": 20, "fanduel": 30, "pinnacle": 45})
    assert tp.grid_of(fresh)["stale_note"] == "" and tp.grid_of(fresh)["stale_prices"] == 0


def test_every_cell_in_a_rows_price_table_carries_the_same_age_and_flag():
    # The detail is built only on request, exactly as the window's JSON asks for it.
    payload = [to.event("g1", start=NOW + 3600, books=[
        tp.full_book(key, ml=ml, updated=NOW - age)
        for key, ml, age in (("draftkings", (2.10, 1.80), 1800), ("fanduel", (1.80, 2.05), 40),
                             ("pinnacle", (1.95, 1.95), 30))])]
    got, _ = tp.read(markets=["h2h"], payload=payload)
    detailed = board.scan(oddsapi.split_by_line(got.markets), oddsapi.books_table(), kinds=("arb",), bankroll=1000.0,
                          now=got.now, bettable=set(oddsapi.BETTABLE), detail=True, names=got.book_names)
    assert detailed
    cells =[c for r in detailed[0].detail["table"]["rows"] for c in r["prices"] if c]
    assert cells and all({"age_brief", "stale", "stale_reason"} <= set(c) for c in cells)
    assert {c["age_brief"] for c in cells if c["stale"]} == {"30 min"}
    assert any(not c["stale"] for c in cells)


def test_nothing_the_engine_says_about_an_age_promises_more_than_it_knows():
    s, got = _screen({"draftkings": 1500, "fanduel": 30, "pinnacle": 45})
    words = list(tp.strings(s)) + [price_age(1500.0, "h2h")["reason"]]
    assert not any(b in w.lower() for w in words for b in BANNED)


# ================================================================ the window prints it and computes nothing

def test_the_window_prints_the_engines_age_on_every_row_and_price():
    play = _braced(JS, "function boardPlay(")
    assert "age: l.price_age" in play and "age: r.price_age" in play
    assert '[r.price_age.label, "the oldest of these prices"]' in play
    live = _braced(JS, "function livePlay(")
    assert "age: r.price_age" in live and "r.price_age.label" in live
    card = _braced(JS, "function listCard(")
    assert "p.age.label" in card and "p.age.limit_text" in card and "p.age.reason" in card
    console = _braced(JS, "function consoleHTML(")
    assert "l.age.label" in console and "p.age.reason" in console
    assert "c.age_brief" in _braced(JS, "function screenCell(") and "c.stale_reason" in _braced(JS, "function screenCell(")
    assert "c.age_brief" in _braced(JS, "function pricesHTML(") and "c.stale_reason" in _braced(JS, "function pricesHTML(")
    assert "g.stale_note" in _braced(JS, "function drawScreen(")


def test_the_window_does_no_arithmetic_on_an_age():
    for fn in ("boardPlay", "livePlay", "listCard", "consoleHTML", "screenCell", "pricesHTML", "drawScreen",
               "oddsLine", "liveLine"):
        body = _braced(JS, f"function {fn}(")
        assert not re.search(r"\bage\w*\s*[-+*/%]\s*[\w(]|[\w)]\s*[-+*/%]\s*\w*age\b", body.replace("&middot;", "")), fn
        assert not re.search(r"\bage\w*\.toFixed|Math\.(floor|round|ceil)\([^)]*age", body), fn


def test_a_price_past_the_limit_is_greyed_wherever_it_is_drawn():
    assert '${old ? " old" : ""}" data-pick' in _braced(JS, "function listCard("), "the card itself is greyed"
    assert "l.age.stale" in _braced(JS, "function consoleHTML(")
    assert 'c.stale ? " old" : ""' in _braced(JS, "function screenCell(")
    assert 'c.stale ? " old" : ""' in _braced(JS, "function pricesHTML(")
    for rule in (r"\.acard\.old", r"\.cside\.old \.odds", r"\.sgrid td\.sg-c\.old", r"\.ptable td\.old", r"td small\.pa",
                 r"\.cside \.lage", r"\.c-note\.old"):
        assert re.search(rule + r"(?![\w-])[^{]*\{", CSS), f"{rule} has no rule in app.css"


def test_a_greyed_best_price_is_not_drawn_as_the_best():
    assert re.search(r"\.sgrid td\.sg-c\.best\.old\{[^}]*background:none", CSS)
    assert re.search(r"\.ptable td\.best\.old\{[^}]*background:none", CSS)


def test_the_boards_ages_are_counted_to_a_stated_moment_because_the_window_does_not_tick():
    """A board is read once and stays on screen. Its ages are as of the read, and the line above it says so,
    rather than a '4 min' that quietly becomes false while the window sits open."""
    assert "Each price&rsquo;s age is counted to ${clockTime(BOARD.asOf)}" in _braced(JS, "function oddsLine(")
    assert "Each price&rsquo;s age is counted to that read" in _braced(JS, "function liveLine(")
    assert "asOf: out.as_of" in _braced(JS, "function showOddsboard(")


# ================================================================ nothing refreshes by itself

def test_no_timer_focus_or_visibility_handler_can_read_the_feed():
    """Bookbreaker's rule: a read happens when the person presses. A timed refresh is the thing OddsJam
    offers and Bookbreaker does not, because a read spends the person's Odds API credits."""
    assert "visibilitychange" not in JS and '"focus"' not in JS and "'focus'" not in JS
    assert "requestAnimationFrame" not in JS and "setInterval" in JS
    update = JS[JS.index("function checkForUpdates()"):]
    for m in re.finditer(r"\bsetInterval\(", JS):
        assert m.start() > JS.index("function checkForUpdates()"), "the only timer is the update download's progress"
    assert "run(" not in update[update.index("setInterval("):update.index("setInterval(") + 300]
    for m in re.finditer(r"\bsetTimeout\(", JS):
        near = JS[max(0, m.start() - 300):m.start() + 200]
        assert not re.search(r'run\("(?:board|oddsboard|screen)"\)', near), "no timer reads prices"
    assert not re.search(r'setInterval\([^)]*run\(', JS)
