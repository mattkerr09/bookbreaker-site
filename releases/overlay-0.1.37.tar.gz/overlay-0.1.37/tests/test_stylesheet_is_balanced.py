"""The window's stylesheet closes every block it opens.

A merge on 2026-10-12 joined two halves of app.css and left two `@media (max-width:...)` blocks open, so every rule
after them (the state picker, price age, Recommended, Which books to fund, Low hold) applied only to narrow windows
and those pages shipped unstyled at normal width in 0.1.15. A browser does not complain about an unclosed block;
this test does.
"""
import re
from pathlib import Path

CSS = (Path(__file__).resolve().parents[1] / "ui" / "src" / "app.css").read_text()


def _without_comments(css: str) -> str:
    return re.sub(r"/\*.*?\*/", "", css, flags=re.S)


def test_every_block_that_opens_closes_and_none_closes_twice():
    depth = 0
    for n, line in enumerate(_without_comments(CSS).splitlines(), 1):
        depth += line.count("{") - line.count("}")
        assert depth >= 0, f"app.css closes a block it never opened by line {n}"
    assert depth == 0, f"app.css leaves {depth} block(s) open at the end"


def test_no_section_of_the_stylesheet_starts_inside_a_media_block():
    # Each section opens with a "/* ----" banner at the top level. One inside an @media block is the sign of a
    # block left open above it.
    depth = 0
    for n, line in enumerate(CSS.splitlines(), 1):
        if line.startswith("/* ----"):
            assert depth == 0, f"app.css line {n} starts a section inside an unclosed block"
        depth += _without_comments(line).count("{") - _without_comments(line).count("}")
