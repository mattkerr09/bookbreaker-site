"""Bet warnings: what a play on the board runs into among the bets the person has open on this Mac.

The engine checks every play against the ledger and writes one sentence per bet it finds. What these pin:

  * the three kinds, worked out on the game, the market and the side: already placed (the same side at the same
    line, at any book), conflicting (the other side of the market) and same game (another market, the same side
    at another line, another player in the same prop market);
  * only an OPEN bet warns (no result yet), only a bet on the same game, and a bet with no game id is counted and
    said so rather than guessed at by name;
  * a play that cannot be matched (a Live prices pair) says no warning could be checked, and is not given a clean
    bill of health;
  * a warning never removes or reorders a play, and the ledger is read without being opened for writing or created;
  * every sentence is the engine's, names the bet it found, and never says guaranteed, risk-free or either way.
"""

import json
import re
import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine import betwarn, cli  # noqa: E402
from overlay_engine.ledger import Ledger  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
SRC = (ROOT / "backend" / "overlay_engine" / "betwarn.py").read_text()
BANNED = ("guarantee", "risk-free", "risk free", "riskfree", "either way")
NAMES = {"dk": "DraftKings", "fd": "FanDuel", "circa": "Circa"}


@pytest.fixture(autouse=True)
def throwaway_home(monkeypatch, tmp_path):
    """Never the real ~/.overlay."""
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def play(event="g1", market="totals", legs=(("dk", "over@219"), ("fd", "under@219")), kind="arb"):
    return {"kind": kind, "event": event, "event_id": event, "market": market,
            "legs": [{"book": b, "outcome": o} for b, o in legs]}


def ledger(tmp_path, *bets):
    """A ledger holding these bets: (event, market, outcome, book, result)."""
    db = Ledger(tmp_path / "overlay.db")
    ids = []
    for event, market, outcome, book, *rest in bets:
        done = rest[0] if rest else None
        ids.append(db.import_bet(event_id=event, sport="nba", market_type=market, outcome=outcome, book=book,
                                 decimal_odds=1.91, stake=25.0, placed_at=1000.0, external_ref=f"r{len(ids)}",
                                 result=done, profit=(0.0 if done else None), source="tracked"))
    db.close()
    return tmp_path / "overlay.db", ids


def codes(block):
    return [i["code"] for i in block["items"]]


def check(path, row, names=NAMES):
    bets, ok = betwarn.open_bets(path)
    assert ok
    return betwarn.warn_row(row, bets, names)


# ------------------------------------------------------------ the three kinds

def test_the_same_side_at_the_same_line_is_already_placed_whatever_the_book(tmp_path):
    path, (bet,) = ledger(tmp_path, ("g1", "totals", "over@219", "caesars"))
    got = check(path, play(legs=(("dk", "over@219"),), kind="ev"))
    assert codes(got) == ["placed"]
    text = got["items"][0]["text"]
    assert f"bet {bet}" in text and "Over 219" in text and "total" in text and "$25.00" in text
    assert "-110" in text and "second time" in text and "DraftKings" in text
    assert got["items"][0]["bet_id"] == bet


def test_a_middle_written_with_a_trailing_zero_is_still_the_bet_you_hold(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "totals", "over@219", "dk"))
    assert codes(check(path, play(legs=(("dk", "over@219.0"), ("fd", "under@221.0")), kind="middle")))[0] == "placed"


def test_the_other_side_of_the_market_conflicts_and_the_sentence_says_it_hedges(tmp_path):
    path, (bet,) = ledger(tmp_path, ("g1", "totals", "under@219", "dk"))
    got = check(path, play(legs=(("fd", "over@219"),), kind="ev"))
    assert codes(got) == ["conflict"]
    text = got["items"][0]["text"]
    assert f"open bet {bet}" in text and "hedge" in text and "fine if you meant that" in text


def test_an_arb_that_completes_a_bet_you_hold_is_both_placed_and_conflicting_and_is_not_blocked(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "totals", "over@219", "dk"))
    got = check(path, play())
    assert codes(got) == ["placed", "conflict"], "one leg repeats the bet, the other hedges it"


def test_a_spreads_mirrored_line_is_the_other_side_not_another_line(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "spreads", "home@-3.5", "dk"))
    assert codes(check(path, play(market="spreads", legs=(("fd", "away@3.5"),), kind="ev"))) == ["conflict"]
    assert codes(check(path, play(market="spreads", legs=(("fd", "home@-3.5"),), kind="ev"))) == ["placed"]


def test_a_moneyline_on_the_other_team_conflicts(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "h2h", "home", "dk"))
    assert codes(check(path, play(market="h2h", legs=(("fd", "away"),), kind="ev"))) == ["conflict"]


def test_another_market_in_the_same_game_is_same_game(tmp_path):
    path, (bet,) = ledger(tmp_path, ("g1", "h2h", "home", "dk"))
    got = check(path, play(legs=(("fd", "over@219"),), kind="ev"))
    assert codes(got) == ["game"]
    assert f"bet {bet}" in got["items"][0]["text"] and "another market" in got["items"][0]["text"]


def test_the_same_side_at_another_line_is_same_game_not_already_placed(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "totals", "over@219", "dk"))
    got = check(path, play(legs=(("fd", "over@221"),), kind="ev"))
    assert codes(got) == ["game"] and "another line" in got["items"][0]["text"]


def test_in_a_prop_market_another_player_is_same_game_and_the_same_player_other_side_conflicts(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "player_points", "LeBron James Over@24.5", "dk"))
    other = check(path, play(market="player_points", legs=(("fd", "Anthony Davis Under@24.5"),), kind="ev"))
    assert codes(other) == ["game"] and "another player" in other["items"][0]["text"]
    same = check(path, play(market="player_points", legs=(("fd", "LeBron James Under@24.5"),), kind="ev"))
    assert codes(same) == ["conflict"]
    again = check(path, play(market="player_points", legs=(("fd", "LeBron James Over@24.5"),), kind="ev"))
    assert codes(again) == ["placed"]


# ------------------------------------------------------------ which bets count

def test_a_settled_bet_does_not_warn(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "totals", "over@219", "dk", "won"))
    assert check(path, play())["items"] == []


def test_a_bet_on_another_game_does_not_warn(tmp_path):
    path, _ = ledger(tmp_path, ("g2", "totals", "over@219", "dk"))
    assert check(path, play())["items"] == []


def test_a_bet_the_person_labelled_is_named_as_they_saw_it(tmp_path):
    path, (bet,) = ledger(tmp_path, ("g1", "h2h", "home", "dk"))
    db = Ledger(path)
    db.label_bet(bet, game="Celtics at Lakers", selection="Lakers moneyline")
    db.close()
    assert "Lakers moneyline" in check(path, play(legs=(("fd", "over@219"),), kind="ev"))["items"][0]["text"]


def test_an_imported_bet_with_no_game_is_counted_and_said_to_be_unmatchable(tmp_path):
    path, _ = ledger(tmp_path, ("import:dk:1", "totals", "over@219", "dk"), ("g1", "h2h", "home", "dk"))
    rows = [play()]
    summary = betwarn.attach(rows, path, NAMES)
    assert summary["open_bets"] == 2
    assert "1 of them came in without a game" in summary["sentence"] and "cannot be matched" in summary["sentence"]
    assert codes(rows[0]["warnings"]) == ["game"], "the imported bet was not guessed at by name"


def test_more_than_three_of_one_kind_are_listed_three_and_then_counted(tmp_path):
    path, _ = ledger(tmp_path, *[("g1", "h2h", "home", "dk")] * 5)
    got = check(path, play(legs=(("fd", "over@219"),), kind="ev"))
    assert codes(got) == ["game"] * 4
    assert got["items"][-1]["more"] == 2 and "2 more of your open bets" in got["items"][-1]["text"]


# ------------------------------------------------------------ a play that cannot be checked

def test_a_live_prices_pair_says_no_warning_could_be_checked():
    pair = {"league": "nba", "game": "BOS vs LAL", "legs": [{"venue": "kalshi", "name": "Boston"},
                                                            {"venue": "polymarket_us", "name": "Los Angeles"}]}
    got = betwarn.warn_row(pair, [{"id": 1, "event_id": "BOS vs LAL", "market_type": "moneyline", "outcome": "home",
                                   "book": "kalshi", "decimal_odds": 2.0, "stake": 10.0, "selection": None}])
    assert got["checked"] is False and got["items"] == []
    assert "no warning could be checked" in got["why"]


def test_the_engines_own_live_pair_carries_that_block():
    assert betwarn.unchecked()["checked"] is False
    src = (ROOT / "backend" / "overlay_engine" / "xvenue.py").read_text()
    assert 'd["warnings"] = betwarn.unchecked()' in src


def test_the_board_says_how_many_plays_could_not_be_checked(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "h2h", "home", "dk"))
    pair = {"league": "nba", "game": "x", "legs": [{"venue": "kalshi"}, {"venue": "polymarket_us"}]}
    summary = betwarn.attach([pair, play()], path, NAMES)
    assert "1 play comes from a source with no game id" in summary["sentence"]


def test_a_ledger_that_cannot_be_read_says_so_and_is_not_a_clean_bill(tmp_path):
    bad = tmp_path / "overlay.db"
    bad.write_bytes(b"this is not a database" * 50)
    rows = [play()]
    summary = betwarn.attach(rows, bad, NAMES)
    assert summary["checked"] is False and "could not be read" in summary["sentence"]
    assert rows[0]["warnings"]["checked"] is False and rows[0]["warnings"]["items"] == []


# ------------------------------------------------------------ the ledger is only read

def test_no_ledger_means_no_open_bets_and_none_is_created(tmp_path):
    path = tmp_path / "overlay.db"
    rows = [play()]
    summary = betwarn.attach(rows, path, NAMES)
    assert not path.exists(), "reading a board must not create the ledger"
    assert summary["checked"] is True and summary["open_bets"] == 0
    assert "no open bets" in summary["sentence"] and rows[0]["warnings"] == {"checked": True, "items": []}


def test_the_ledger_is_opened_read_only(tmp_path, monkeypatch):
    path, _ = ledger(tmp_path, ("g1", "totals", "over@219", "dk"))
    seen = []
    real = sqlite3.connect

    def spy(target, *a, **k):
        seen.append((str(target), k))
        return real(target, *a, **k)

    monkeypatch.setattr(sqlite3, "connect", spy)
    betwarn.open_bets(path)
    assert seen and all("mode=ro" in t and k.get("uri") is True for t, k in seen)


def test_reading_a_board_leaves_the_ledger_file_as_it_was(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "totals", "over@219", "dk"))
    db = Ledger(path)
    db.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    db.close()
    before = path.read_bytes()
    betwarn.attach([play(), play(legs=(("fd", "over@221"),), kind="ev")], path, NAMES)
    assert path.read_bytes() == before


def test_the_module_reaches_for_no_network():
    for word in ("urllib", "socket", "http", "requests", "subprocess"):
        assert not re.search(rf"^\s*(import|from)\s+{word}", SRC, re.M), word


# ------------------------------------------------------------ a warning never takes a play away

def test_attach_keeps_every_play_in_its_place(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "totals", "over@219", "dk"))
    rows = [play("g0"), play("g1"), play("g2", legs=(("fd", "over@221"),), kind="ev"), play("g1", market="h2h",
                                                                                           legs=(("dk", "home"),))]
    order = [id(r) for r in rows]
    betwarn.attach(rows, path, NAMES)
    assert [id(r) for r in rows] == order
    assert [bool(r["warnings"]["items"]) for r in rows] == [False, True, False, True]


def test_the_boards_summary_counts_plays_by_kind_in_the_engines_words(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "totals", "over@219", "dk"))
    rows = [play(), play(legs=(("fd", "over@221"),), kind="ev")]
    summary = betwarn.attach(rows, path, NAMES)
    assert [c["code"] for c in summary["by_code"]] == ["placed", "conflict", "game"]
    by = {c["code"]: c for c in summary["by_code"]}
    assert by["placed"]["count"] == 1 and by["placed"]["sentence"] == "1 play would repeat a bet you already have open."
    assert by["conflict"]["sentence"] == "1 play takes the other side of a bet you have open."
    assert by["game"]["sentence"] == "1 play is on a game you have another open bet in."
    assert summary["sentence"] == "Checked against your 1 open bet saved on this Mac."


def test_the_switches_are_the_three_kinds_with_a_label_and_a_note_each():
    assert [s["code"] for s in betwarn.SWITCHES] == list(betwarn.CODES) == ["placed", "conflict", "game"]
    assert [s["label"] for s in betwarn.SWITCHES] == ["Already placed", "Conflicting", "Same game"]
    assert all(s["note"].endswith(".") for s in betwarn.SWITCHES)


def test_every_sentence_the_engine_writes_keeps_its_promises(tmp_path):
    path, _ = ledger(tmp_path, ("g1", "totals", "over@219", "dk"), ("g1", "h2h", "home", "fd"),
                     ("g1", "totals", "over@225", "dk"), ("import:x:1", "h2h", "home", "dk"))
    rows = [play(), play(legs=(("fd", "under@219"),), kind="ev"), play(market="h2h", legs=(("fd", "away"),))]
    summary = betwarn.attach(rows, path, NAMES)
    words = [summary["sentence"], *(c["sentence"] for c in summary["by_code"]),
             *(s["note"] for s in summary["switches"]), betwarn.UNCHECKED_PAIR,
             *(i["text"] for r in rows for i in r["warnings"]["items"])]
    assert len(words) > 10
    for text in words:
        assert not any(b in text.lower() for b in BANNED), text
    assert any("hedge" in t for t in words)


# ------------------------------------------------------------ the whole board, end to end

def _board(capsys, *argv):
    assert cli.main(["board", *argv, "--json"]) == 0
    return json.loads(capsys.readouterr().out)


def test_a_board_read_marks_the_play_and_still_shows_it(capsys, tmp_path):
    clean = _board(capsys)
    assert clean["warnings"]["open_bets"] == 0 and clean["rows"]
    assert all(r["warnings"] == {"checked": True, "items": []} for r in clean["rows"])
    event = clean["rows"][0]["event"]
    market, outcome = clean["rows"][0]["market"], clean["rows"][0]["legs"][0]["outcome"]
    db = Ledger()
    db.import_bet(event_id=event, sport="nba", market_type=market, outcome=outcome, book="dk", decimal_odds=1.91,
                  stake=25.0, placed_at=1000.0, external_ref="r1", source="tracked")
    db.close()
    marked = _board(capsys)
    assert [r["kind"] for r in marked["rows"]] == [r["kind"] for r in clean["rows"]], "no play was taken away"
    assert "placed" in {i["code"] for r in marked["rows"] for i in r["warnings"]["items"]}
    assert marked["warnings"]["open_bets"] == 1 and marked["warnings"]["by_code"]
    assert [s["code"] for s in marked["warnings"]["switches"]] == ["placed", "conflict", "game"]
    # The book is named as the person knows it, not by its key.
    text = next(i["text"] for r in marked["rows"] for i in r["warnings"]["items"] if i["code"] == "placed")
    assert "at DraftKings" in text


def test_a_board_read_on_a_new_install_creates_no_ledger(capsys, tmp_path):
    out = _board(capsys)
    assert not (tmp_path / "overlay.db").exists()
    assert "no open bets" in out["warnings"]["sentence"]
