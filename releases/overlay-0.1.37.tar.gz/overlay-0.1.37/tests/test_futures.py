"""Futures on live sportsbook odds: an opt-in group, the cost said before the press, only what was picked
read, the read stored so the view reopens for nothing, and a fair price from the engine's multi-way devig.

The rule (https://the-odds-api.com/liveapi/guides/v4/, "GET odds", "Usage Quota Costs", read 2026-10-13):
a futures market is the `outrights` market on its own sport key, so a key costs 1 credit per region, and the
list of sports (`GET /v4/sports`) is free. The guide gives no outrights example response, so the answers here
are written by hand from the general shape every market has (tests/fixtures/oddsapi/outrights_nfl.json and
sports.json). The real API is never called.

The fixture's world: six teams with true chances .30 .25 .20 .13 .08 .04. Pinnacle prices them at a 4% overround
(near fair), DraftKings and FanDuel at 25% and 30% with DraftKings long on Houston and Chicago, BetRivers lists
only four teams, Bovada (an offshore book, never bettable) is long on Philadelphia, and Betfair sends only lay
prices.
"""

import json
import os
import re
import stat
from pathlib import Path
from types import SimpleNamespace

import pytest

from overlay_engine import catalog, cli, futures, futurestore, keystore, oddsapi
from overlay_engine.futures import COST_RULE, FUTURES, estimate, parse_outrights, read
from overlay_engine.odds import hold as hold_of
from overlay_engine.oddsapi import Cache, OddsApiError
from overlay_engine.restfeed import parse_time

FIX = Path(__file__).parent / "fixtures" / "oddsapi"
NOW = parse_time("2026-10-13T16:00:00Z")
KEY = "0123456789abcdef0123456789abcdef"          # made up; not a real key
NFL = "americanfootball_nfl_super_bowl_winner"
NBA = "basketball_nba_championship_winner"
MLB = "baseball_mlb_world_series_winner"
NCAAF = "americanfootball_ncaaf_championship_winner"


def load(name):
    return json.loads((FIX / name).read_text())


class Clock:
    def __init__(self, now=NOW):
        self.now = now

    def __call__(self):
        return self.now


class FuturesApi:
    """The Odds API for the two paths a futures read uses. The list of sports is free; a futures key's odds
    charge the markets that CAME BACK (outrights, one) x the regions specified, and nothing when empty."""

    def __init__(self, odds=None, sports=None, remaining=500, charge=None, fail=None, reject=()):
        nfl = load("outrights_nfl.json")
        nba = json.loads(json.dumps(nfl).replace("americanfootball_nfl_super_bowl_winner", NBA)
                         .replace("nfl-sb-2026", "nba-title-2027"))
        self.odds = {NFL: nfl, NBA: nba} if odds is None else odds
        self.sports = load("sports.json") if sports is None else sports
        self.remaining, self.used = remaining, 500 - remaining
        self.charge, self.fail, self.reject = charge, fail, set(reject)
        self.calls = []

    def paths(self):
        return [c[0] for c in self.calls]

    def odds_calls(self):
        return [c for c in self.calls if c[0] != "/v4/sports"]

    def __call__(self, path, params):
        self.calls.append((path, dict(params)))
        if self.fail and self.fail[0] == path:
            raise oddsapi.explain(*self.fail[1])
        if path == "/v4/sports":
            payload, cost = self.sports, 0
        else:
            key = path.strip("/").split("/")[2]
            if key in self.reject:
                raise oddsapi.explain(404, '{"error_code":"UNKNOWN_SPORT"}', {})
            payload = self.odds.get(key, [])
            back = any(m["key"] == "outrights" for e in payload for b in e["bookmakers"] for m in b["markets"])
            cost = (1 if back else 0) * len(params["regions"].split(","))
            if self.charge is not None:
                cost = self.charge
        self.remaining -= cost
        self.used += cost
        return payload, {"x-requests-remaining": str(self.remaining), "x-requests-used": str(self.used),
                         "x-requests-last": str(cost)}


@pytest.fixture
def home(monkeypatch, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def run(*leagues, regions=("us", "eu"), api=None, clock=None, cache=None):
    api = api or FuturesApi()
    got = read(estimate(list(leagues), list(regions)), KEY, clock=clock or Clock(), fetcher=api,
               cache=cache)
    return got, api


def board(view, alias="nfl"):
    return next(b for b in view["boards"] if b["league"] == alias)


def row(b, name):
    return next(r for r in b["rows"] if r["label"] == name)


def everything(view):
    """Every string the engine would show a person, whole."""
    return json.dumps(view)


# ------------------------------------------------------------ the cost, said before the press

def test_futures_are_off_until_a_league_is_picked_and_then_cost_nothing_to_ask_about():
    off = estimate()
    assert off.markets == () and off.credits == 0
    assert "nothing would be read" in off.sentence()
    assert off.as_dict()["leagues"] == []
    assert all(c["picked"] is False for c in futures.choices(off)["leagues"])


def test_the_cost_is_one_credit_per_region_for_each_futures_key_picked():
    """Every combination, against the sum written out the long way."""
    for picked in (["nfl"], ["nfl", "nba"], ["nfl", "nba", "mlb", "nhl", "ncaaf", "ncaab"]):
        for regions in (["us"], ["us", "eu"], ["us", "us2", "eu", "us_ex"]):
            got = estimate(picked, regions)
            long_way = 0
            for _alias in picked:
                for _region in regions:
                    long_way += 1                    # one market (outrights) in one region
            assert got.credits == long_way == len(picked) * len(regions)
            assert got.as_dict()["credits"] == long_way
            assert got.as_dict()["by_league"] == {a: len(regions) for a in picked}


def test_the_default_regions_are_us_and_europe_so_pinnacle_can_price_fair_odds():
    got = estimate(["nfl"])
    assert got.regions == ("us", "eu") and got.credits == 2


def test_the_sentence_says_the_total_the_keys_and_the_regions_in_plain_words():
    text = estimate(["nfl", "nba"], ["us", "eu"]).sentence()
    assert "up to 4 of your Odds API credits" in text
    assert "2 futures markets (Super Bowl winner, NBA champion)" in text
    assert "2 regions (us, eu), at 1 credit each" in text
    assert "costs nothing" in text
    assert estimate(["nfl"], ["us"]).sentence().startswith("Reading futures uses up to 1 of your Odds API credit:")
    for bad in ("guarantee", "risk-free", "either way", "free bet", "—"):
        assert bad not in text.lower()


def test_the_rule_is_held_verbatim_and_cited():
    assert COST_RULE == ("The usage quota cost is 1 per region per market. "
                         "cost = [number of markets specified] x [number of regions specified]")
    assert COST_RULE == oddsapi.COST_RULE, "futures are priced by the rule the main odds already hold"
    source = futures.COST_RULE_SOURCE
    assert source.startswith("https://the-odds-api.com/liveapi/guides/v4/")
    assert "outrights" in source and "free" in source and "2026-10-13" in source
    assert estimate(["nfl"]).as_dict()["rule"] == COST_RULE
    assert estimate(["nfl"]).as_dict()["rule_source"] == source


def test_the_keys_are_the_fixed_dated_list_and_nothing_else_can_be_picked():
    assert {f.alias: f.key for f in FUTURES} == {
        "nfl": NFL, "ncaaf": NCAAF, "nba": NBA, "ncaab": "basketball_ncaab_championship_winner",
        "mlb": MLB, "nhl": "icehockey_nhl_championship_winner"}
    assert futures.KEYS_READ == "2026-10-13"
    assert {c["key"] for c in futures.choices(estimate())["leagues"]} == {f.key for f in FUTURES}
    for bad in (["golf"], ["americanfootball_nfl_super_bowl_winner"]):
        with pytest.raises(OddsApiError):
            estimate(bad)
    with pytest.raises(OddsApiError):
        estimate(["nfl"], ["mars"])


# ------------------------------------------------------------ reading: only what was picked

def test_a_read_asks_the_free_list_then_only_the_key_that_was_picked(home):
    got, api = run("nfl")
    assert api.paths() == ["/v4/sports", f"/v4/sports/{NFL}/odds"]
    _, params = api.odds_calls()[0]
    assert params["markets"] == "outrights" and params["regions"] == "us,eu"
    assert params["oddsFormat"] == "decimal" and params["apiKey"] == KEY
    assert got.spent == 2 and got.spent_known and got.quota.remaining == 498


def test_a_futures_key_the_person_did_not_pick_is_never_requested(home):
    _, api = run("nba")
    assert [p for p in api.paths() if NFL in p] == []
    assert [p for p in api.paths() if any(f.key in p for f in FUTURES if f.key != NBA)] == []


def test_nothing_picked_reads_nothing_and_asks_nothing(home):
    api = FuturesApi()
    with pytest.raises(OddsApiError, match="Pick at least one league"):
        read(estimate([]), KEY, clock=Clock(), fetcher=api)
    assert api.calls == []


def test_a_key_the_free_list_does_not_show_open_is_skipped_without_a_request(home):
    """mlb is listed but not active, ncaaf is not listed at all: neither is asked for, neither costs."""
    got, api = run("nfl", "mlb", "ncaaf")
    assert api.paths() == ["/v4/sports", f"/v4/sports/{NFL}/odds"]
    said = [why for _, why in got.skipped]
    assert any("World Series winner" in w and "not listed" in w and "cost nothing" in w for w in said)
    assert any("College football champion" in w for w in said)
    assert got.spent == 2


def test_the_cost_read_back_is_what_the_estimate_said_when_every_market_has_prices(home):
    est = estimate(["nfl", "nba"], ["us", "eu"])
    got, api = run("nfl", "nba")
    assert got.spent == est.credits == 4 and len(api.odds_calls()) == 2
    assert "This read used 4 credits." in got.credits_line() and "496 left this month" in got.credits_line()


def test_a_market_with_no_prices_costs_nothing_and_keeps_the_earlier_read(home):
    api = FuturesApi(odds={NFL: []})
    got, _ = run("nfl", api=api)
    assert got.spent == 0 and futurestore.load(futurestore.folder()) == []
    assert any("No book had" in w for _, w in got.skipped)


def test_a_second_press_inside_a_minute_spends_nothing_on_the_odds(home):
    api = FuturesApi()
    run("nfl", api=api)
    got, _ = run("nfl", api=api)
    assert len(api.odds_calls()) == 1, "the second press went back to the API for the odds"
    assert got.all_cached and got.spent == 0
    assert "No credits were spent" in got.credits_line()


def test_a_failure_before_anything_is_read_raises_and_the_key_is_in_no_message(home):
    api = FuturesApi(fail=(f"/v4/sports/{NFL}/odds", (401, '{"error_code":"INVALID_KEY"}', {})))
    with pytest.raises(OddsApiError, match="did not accept your key") as caught:
        run("nfl", api=api)
    assert KEY not in str(caught.value)
    sports_down = FuturesApi(fail=("/v4/sports", (500, "", {})))
    with pytest.raises(OddsApiError, match="problem on its side"):
        run("nfl", api=sports_down)
    assert sports_down.odds_calls() == [], "nothing was asked for after the free list failed"


def test_a_failure_after_something_was_read_keeps_it(home):
    api = FuturesApi(fail=(f"/v4/sports/{NBA}/odds", (429, '{"error_code":"EXCEEDED_FREQ_LIMIT"}', {})))
    got, _ = run("nfl", "nba", api=api)
    assert [r.market.alias for r in got.reads] == ["nfl"]
    assert any("slow down" in e for e in got.errors)
    assert futurestore.load(futurestore.folder())[0]["alias"] == "nfl"


def test_one_market_the_api_will_not_answer_is_skipped_and_the_next_is_read(home):
    api = FuturesApi(reject={NFL})
    got, _ = run("nfl", "nba", api=api)
    assert [r.market.alias for r in got.reads] == ["nba"]
    assert any("did not understand" in e for e in got.errors)


def test_a_request_charged_more_than_the_rule_allows_stops_the_run(home):
    api = FuturesApi(charge=9)
    got, _ = run("nfl", "nba", api=api)
    assert len(api.odds_calls()) == 1
    assert any("charged 9 credits" in e and "allows 2" in e for e in got.errors)


def test_credits_too_few_for_the_next_market_stops_before_asking(home):
    api = FuturesApi(remaining=3)          # the first read leaves 1, and the next needs up to 2
    got, _ = run("nfl", "nba", api=api)
    assert len(api.odds_calls()) == 1
    assert any("needs up to 2 credits and you have 1 left" in e for e in got.errors)


def test_the_key_is_in_nothing_the_read_returns(home):
    got, _ = run("nfl", "nba")
    view = futures.from_store(now=NOW + 5)
    for text in (json.dumps(got.as_dict()), everything(view), got.credits_line(),
                 "".join(open(f).read() for f in Path(home).rglob("*") if f.is_file())):
        assert KEY not in text


# ------------------------------------------------------------ what a futures answer says

def test_the_answer_becomes_one_market_with_a_quote_per_book_and_name():
    markets, skipped = parse_outrights(load("outrights_nfl.json"), NFL, NOW)
    assert len(markets) == 1 and markets[0].market_type == "outrights" and skipped == 0
    by_book = {}
    for q in markets[0].quotes:
        by_book.setdefault(q.book, set()).add(q.outcome.name)
    assert set(by_book) == {"pinnacle", "dk", "fd", "betrivers", "bovada"}
    assert len(by_book["pinnacle"]) == 6 and len(by_book["betrivers"]) == 4
    assert all(q.outcome.line is None for q in markets[0].quotes), "a name has no line to pair on"


def test_lay_prices_are_not_prices_you_can_back_and_are_ignored():
    markets, _ = parse_outrights(load("outrights_nfl.json"), NFL, NOW)
    assert "betfair" not in {q.book for q in markets[0].quotes}
    assert all(q.decimal != 1.5 for q in markets[0].quotes)


def test_a_title_market_whose_start_time_has_passed_is_not_dropped_as_under_way(home):
    """The fixture's commence_time is September; the clock is October. A title market is open all season."""
    assert parse_time(load("outrights_nfl.json")[0]["commence_time"]) < NOW
    run("nfl")
    assert futures.from_store(now=NOW + 1)["has_futures"] is True


def test_a_name_a_book_lists_twice_keeps_the_first_and_is_counted():
    payload = load("outrights_nfl.json")
    pin = payload[0]["bookmakers"][0]["markets"][0]["outcomes"]
    pin.append({"name": pin[0]["name"], "price": 99.0})
    markets, skipped = parse_outrights(payload, NFL, NOW)
    assert skipped == 1
    assert [q.decimal for q in markets[0].quotes if q.book == "pinnacle" and q.outcome.name == pin[0]["name"]] \
        == [pin[0]["price"]]


def test_a_price_that_is_not_decimal_odds_refuses_the_whole_answer():
    payload = load("outrights_nfl.json")
    payload[0]["bookmakers"][0]["markets"][0]["outcomes"][0]["price"] = 1.0
    with pytest.raises(futures.FeedError):
        parse_outrights(payload, NFL, NOW)
    with pytest.raises(futures.FeedError):
        parse_outrights({"not": "a list"}, NFL, NOW)


def test_prices_are_dated_by_the_book_not_by_us(home):
    run("nfl")
    b = board(futures.from_store(now=NOW + 60))
    assert row(b, "Houston Texans")["cells"]["pinnacle"]["age"] == 90.0         # 15:59:30 to 16:01:00
    assert row(b, "Houston Texans")["cells"]["fd"]["age"] == 1860.0             # 15:30:00 to 16:01:00


# ------------------------------------------------------------ the grid

@pytest.fixture
def view(home):
    run("nfl")
    return futures.from_store(now=NOW + 60)


def test_every_name_is_a_row_with_every_books_price_side_by_side(view):
    b = board(view)
    assert {r["label"] for r in b["rows"]} == {
        "Kansas City Chiefs", "Buffalo Bills", "Philadelphia Eagles", "Detroit Lions", "Houston Texans",
        "Chicago Bears"}
    assert {c["key"] for c in b["books"]} == {"pinnacle", "dk", "fd", "betrivers", "bovada"}
    houston = row(b, "Houston Texans")
    assert houston["cells"]["dk"]["american"] == 1400 and houston["cells"]["dk"]["decimal"] == 15.0
    assert set(row(b, "Chicago Bears")["cells"]) == {"pinnacle", "dk", "fd", "bovada"}, "BetRivers did not list him"


def test_the_best_price_is_the_best_one_you_can_bet_and_a_reference_book_is_never_it(view):
    b = board(view)
    eagles = row(b, "Philadelphia Eagles")
    assert eagles["cells"]["bovada"]["decimal"] == 7.0 > eagles["cells"]["dk"]["decimal"]
    assert eagles["best"]["books"] == ["dk"] and eagles["best"]["decimal"] == 4.0
    assert eagles["cells"]["dk"].get("best") is True
    assert "best" not in eagles["cells"]["bovada"] and "best" not in eagles["cells"]["pinnacle"]
    cols = {c["key"]: c for c in b["books"]}
    assert cols["pinnacle"]["bettable"] is False and cols["bovada"]["bettable"] is False
    assert cols["dk"]["bettable"] is True
    assert [c["bettable"] for c in b["books"]] == sorted((c["bettable"] for c in b["books"]), reverse=True), \
        "the books you can bet at come first"


def test_a_tie_for_the_best_price_marks_every_book_that_has_it():
    rec = {"v": 1, "alias": "nfl", "key": NFL, "fetched_at": NOW, "regions": ["us"], "question": "Super Bowl winner",
           "names": {}, "markets": [{"event": "e", "q": [
               ["dk", "A", 2.0, NOW], ["fd", "A", 2.0, NOW], ["mgm", "A", 1.9, NOW],
               ["dk", "B", 2.0, NOW], ["fd", "B", 1.8, NOW], ["mgm", "B", 1.9, NOW]]}]}
    b = board(futures.build([rec], NOW + 1))
    assert row(b, "A")["best"]["books"] == ["dk", "fd"]
    assert [k for k, c in row(b, "A")["cells"].items() if c.get("best")] == ["dk", "fd"]
    assert row(b, "B")["best"]["books"] == ["dk"]


def test_the_rows_run_from_the_favourite_down(view):
    labels = [r["label"] for r in board(view)["rows"]]
    assert labels == ["Kansas City Chiefs", "Buffalo Bills", "Philadelphia Eagles", "Detroit Lions",
                      "Houston Texans", "Chicago Bears"]


def test_every_price_carries_its_age_in_the_engines_words(view):
    c = row(board(view), "Buffalo Bills")["cells"]
    assert c["fd"]["age_text"] == "last confirmed 31 minutes ago" and c["fd"]["age_brief"] == "31 min"
    assert c["pinnacle"]["age_brief"] == "1 min" and c["pinnacle"]["stale"] is False
    # the same limit the Odds screen holds a price to: ten minutes
    assert c["fd"]["stale"] is True and "longer than the 10 minutes" in c["fd"]["stale_reason"]
    b = board(view)
    assert b["stale_prices"] == 6 and "6 of 28 prices are greyed" in b["stale_note"]
    assert b["age_text"] == "1 minute ago" and b["read_at"] == NOW


def test_reopened_later_the_age_is_counted_from_the_book_not_from_the_read(home):
    run("nfl")
    later = board(futures.from_store(now=NOW + 3 * 3600))
    pin = row(later, "Houston Texans")["cells"]["pinnacle"]
    assert pin["age"] == 3 * 3600 + 30 and pin["age_brief"] == "3 h" and pin["stale"] is True
    assert later["age_text"] == "3 hours ago" and "read 3 hours ago" in later["warning"]


def test_a_read_a_week_old_is_not_drawn_and_says_why(home):
    run("nfl")
    gone = futures.from_store(now=NOW + 8 * 86400)
    assert gone["has_futures"] is False and gone["boards"] == [] and gone["message"] == futures.TOO_OLD
    assert futures.from_store(now=NOW + 6 * 86400)["has_futures"] is True


def test_an_empty_store_says_nothing_has_been_read(home):
    empty = futures.from_store(now=NOW)
    assert empty["has_futures"] is False and empty["message"] == futures.NONE_YET
    assert "Turn futures on" in empty["message"]


# ------------------------------------------------------------ the hold, and the fair price

def test_the_hold_is_one_plain_sentence_with_the_books_own_numbers(view):
    b = board(view)
    pin = hold_of([3.21, 3.85, 4.81, 7.40, 12.02, 24.04])
    assert b["hold_sentence"].startswith("The books that price the whole list keep between 3.8% (Pinnacle) and ")
    assert "(FanDuel)" in b["hold_sentence"] and "(the hold)" in b["hold_sentence"]
    assert len(re.split(r"(?<=[.!?])\s+", b["hold_sentence"])) == 1
    cols = {c["key"]: c for c in b["books"]}
    assert cols["pinnacle"]["hold"] == pytest.approx(pin, abs=0.002)
    assert cols["betrivers"]["hold"] is None and cols["betrivers"]["whole_list"] is False
    assert 0.0 < cols["dk"]["hold"] < cols["fd"]["hold"]


def test_with_no_book_pricing_the_whole_list_there_is_no_hold_and_no_fair_price():
    rec = {"v": 1, "alias": "nfl", "key": NFL, "fetched_at": NOW, "regions": ["us"], "question": "x", "names": {},
           "markets": [{"event": "e", "q": [
               ["dk", "A", 2.0, NOW], ["dk", "B", 3.0, NOW], ["fd", "B", 3.1, NOW], ["fd", "C", 4.0, NOW],
               ["mgm", "A", 2.1, NOW], ["mgm", "C", 4.1, NOW]]}]}
    b = board(futures.build([rec], NOW + 1))
    assert "No sportsbook priced every name on the list" in b["hold_sentence"]
    assert b["fair"] is False and all(r["fair"] is None for r in b["rows"]) and b["plays"] == []
    assert "no fair price" in b["fair_sentence"]


def test_the_fair_price_is_the_multiway_devig_and_sums_to_one(view):
    b = board(view)
    probs = {r["label"]: r["fair"]["prob"] for r in b["rows"]}
    # each book's devig sums to 1; the blend across books is in log-odds (fair.py), so the sum is near 1, not exact
    assert sum(probs.values()) == pytest.approx(1.0, abs=0.005)
    true = {"Kansas City Chiefs": .30, "Buffalo Bills": .25, "Philadelphia Eagles": .20, "Detroit Lions": .13,
            "Houston Texans": .08, "Chicago Bears": .04}
    for name, p in true.items():
        assert probs[name] == pytest.approx(p, abs=0.012), name
    chiefs = row(b, "Kansas City Chiefs")["fair"]
    assert chiefs["american"] == 228 and chiefs["prob_text"] == "30.5%"
    lo, hi = chiefs["range_text"].split(" to ")
    assert int(lo) <= chiefs["american"] <= int(hi), "the range brackets the fair price"
    assert chiefs["anchored"] is True


def test_only_books_that_price_the_whole_list_set_the_fair_price(view):
    b = board(view)
    # Bovada priced the whole list too, but the engine has no tier for it, so it sets no price (fair.py)
    assert b["fair_books"] == ["DraftKings", "FanDuel", "Pinnacle"]
    assert "BetRivers priced only part of the list, so it is shown but does not help set the fair price" \
        in b["fair_sentence"]
    assert "Bookbreaker's own weights" in b["fair_sentence"]


def test_a_name_only_one_book_lists_is_shown_and_given_no_fair_price():
    rec = {"v": 1, "alias": "nfl", "key": NFL, "fetched_at": NOW, "regions": ["eu"], "question": "x", "names": {},
           "markets": [{"event": "e", "q": [
               ["pinnacle", "A", 1.8, NOW], ["pinnacle", "B", 3.0, NOW], ["pinnacle", "C", 6.0, NOW],
               ["dk", "A", 1.7, NOW], ["dk", "B", 2.9, NOW], ["dk", "C", 5.5, NOW], ["dk", "Z", 80.0, NOW]]}]}
    b = board(futures.build([rec], NOW + 1))
    z = row(b, "Z")
    assert z["fair"] is None and z["in_list"] is False and z["priced_by"] == 1
    assert row(b, "A")["fair"] is not None
    assert b["rows"][-1]["label"] == "Z", "unpriced-by-fair names sort after the rest"


def test_the_engines_blend_is_the_default_and_a_formula_replaces_it(home):
    run("nfl")
    plain = board(futures.from_store(now=NOW + 60))
    from overlay_engine import formula as formula_mod
    setting = formula_mod.parse(json.dumps({"weights": {"pinnacle": 10}, "threshold": 100}))
    mine = board(futures.from_store(now=NOW + 60, formula=setting.formula))
    assert mine["formula_used"] is True and plain["formula_used"] is False
    assert mine["fair_books"] == ["Pinnacle"]
    assert "your EV formula's weights" in mine["fair_sentence"]
    # Pinnacle alone is nearly fair: its own devig, not the blend, sets the price
    from overlay_engine.devig import devig_all
    pin = devig_all([3.21, 3.85, 4.81, 7.40, 12.02, 24.04])
    assert row(mine, "Kansas City Chiefs")["fair"]["prob"] == pytest.approx(pin.consensus(0), abs=1e-9)
    assert row(mine, "Kansas City Chiefs")["fair"]["prob"] != row(plain, "Kansas City Chiefs")["fair"]["prob"]


def test_a_formula_whose_books_did_not_price_the_list_shows_no_fair_price_and_says_why(home):
    run("nfl")
    from overlay_engine import formula as formula_mod
    setting = formula_mod.parse(json.dumps({"weights": {"pinnacle": 1, "kalshi": 1}, "threshold": 100}))
    b = board(futures.from_store(now=NOW + 60, formula=setting.formula))
    assert b["fair"] is False and b["plays"] == []
    assert "Your EV formula: only 50% of its weight priced this whole list" in b["fair_sentence"]
    assert "threshold of All books" in b["fair_sentence"]


def test_the_formula_sentence_says_whether_it_is_used_held_or_not_set():
    from overlay_engine import formula as formula_mod
    assert futures.formula_sentence(None) == ""
    assert futures.formula_sentence(formula_mod.parse(None)) == ""
    on = formula_mod.parse(json.dumps({"weights": {"pinnacle": 1}}))
    assert futures.formula_sentence(on) == "Futures are priced with your EV formula, the same way +EV bets are."
    held = formula_mod.parse(json.dumps({"weights": {"pinnacle": 1}}), paused=True)
    assert "held because Recommended is on" in futures.formula_sentence(held)


# ------------------------------------------------------------ +EV, only where it can be bet

def test_a_future_is_marked_only_at_a_book_you_can_bet_at_and_above_the_minimum(view):
    b = board(view)
    marked = {(p["outcome"], p["book"]) for p in b["plays"]}
    assert marked == {("Houston Texans", "dk"), ("Chicago Bears", "dk")}
    # Bovada is far long on Philadelphia (7.0 against a fair 5.0) and is a reference book: never marked
    assert "ev" not in row(b, "Philadelphia Eagles")["cells"]["bovada"]
    assert all(p["book"] in oddsapi.BETTABLE for p in b["plays"])
    # Pinnacle prices the market and is never a bet
    assert all("ev" not in c for r in b["rows"] for k, c in r["cells"].items() if k == "pinnacle")


def test_the_board_s_own_minimum_decides_what_is_marked(home):
    run("nfl")
    for min_ev, expect in ((0.0, 2), (0.20, 1), (0.50, 0)):
        got = board(futures.from_store(now=NOW + 60, min_ev=min_ev))
        assert len(got["plays"]) == expect, min_ev
    top = board(futures.from_store(now=NOW + 60))["plays"][0]
    assert top["outcome"] == "Chicago Bears" and top["ev"] > 0.30
    assert futures.from_store(now=NOW + 60, min_ev=0.2)["min_ev_text"] == "20%"


def test_a_mark_is_an_edge_that_holds_up_under_the_least_favourable_fair_price(view):
    for p in board(view)["plays"]:
        assert float(p["low_text"].rstrip("%")) > 0, "the worst case must still be +EV"


def test_a_long_shot_is_flagged_and_says_its_edge_is_the_least_certain(view):
    b = board(view)
    chicago, houston = row(b, "Chicago Bears"), row(b, "Houston Texans")
    assert chicago["long_shot"] is True and houston["long_shot"] is False
    assert chicago["cells"]["dk"]["ev"]["long_shot"] is True
    assert "A long shot: the least certain kind of edge." in chicago["cells"]["dk"]["ev"]["text"]
    assert "long shot" not in houston["cells"]["dk"]["ev"]["text"]
    # the least certain edge has the widest fair range
    spread = lambda r: r["fair"]["high_american"] - r["fair"]["low_american"]
    assert spread(chicago) > spread(houston) > spread(row(b, "Kansas City Chiefs"))


def test_without_pinnacle_or_an_exchange_nothing_is_marked_and_the_page_says_so(home):
    payload = load("outrights_nfl.json")
    payload[0]["bookmakers"] = [b for b in payload[0]["bookmakers"] if b["key"] != "pinnacle"]
    run("nfl", api=FuturesApi(odds={NFL: payload}))
    b = board(futures.from_store(now=NOW + 60))
    assert b["plays"] == [] and b["anchored"] is False and b["fair"] is True
    assert any("No Pinnacle or exchange price priced this whole list, so no +EV future is marked" in n
               for n in b["notes"])


def test_a_stale_price_is_still_marked_but_says_how_old_it_is(home):
    run("nfl")
    later = board(futures.from_store(now=NOW + 4 * 3600))
    assert later["plays"] and all(p["stale"] for p in later["plays"])
    assert all(p["age_brief"] == "4 h" for p in later["plays"])


def test_the_view_says_money_is_tied_up_and_a_long_shots_edge_is_the_least_certain(view):
    assert "ties your money up until the season ends" in view["ties_up"]
    assert "A long shot's edge is the least certain" in view["long_shot"]
    assert "never marked best or +EV" in view["note"]


def test_nothing_the_engine_says_uses_a_word_the_house_does_not(view, home):
    texts = [everything(view), estimate(["nfl"]).sentence(), futures.TIES_UP, futures.LONG_SHOT_NOTE,
             futures.NONE_YET, futures.TOO_OLD, json.dumps(futures.choices(estimate(["nfl"])))]
    for text in texts:
        low = text.lower()
        for bad in ("guarantee", "risk-free", "riskfree", "either way", "free bet", "—", "–"):
            assert bad not in low, bad
        assert " vig" not in low and "devig" not in low, "jargon without an explainer"


# ------------------------------------------------------------ stored, like the other reads

def test_a_read_is_stored_privately_and_opens_again_with_no_key_and_no_fetch(home, monkeypatch):
    run("nfl", "nba")
    folder = futurestore.folder()
    assert {p.name for p in folder.glob("*.json")} == {"nfl.json", "nba.json"}
    assert stat.S_IMODE(os.stat(folder / "nfl.json").st_mode) == 0o600
    assert stat.S_IMODE(os.stat(folder).st_mode) == 0o700
    monkeypatch.setattr(keystore, "get_key", lambda *a, **k: pytest.fail("the stored view asked for the key"))
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: pytest.fail("the stored view built a fetcher"))
    again = futures.from_store(now=NOW + 120)
    assert [b["league"] for b in again["boards"]] == ["nfl", "nba"]
    assert board(again, "nba")["question"] == "NBA champion"


def test_the_newest_read_replaces_the_older_and_an_older_never_replaces_a_newer(home):
    api = FuturesApi()
    run("nfl", api=api, clock=Clock(NOW))
    run("nfl", api=api, clock=Clock(NOW + 3600))                       # past the minute: fetched again
    assert futurestore.load(futurestore.folder())[0]["fetched_at"] == NOW + 3600
    markets, _ = parse_outrights(load("outrights_nfl.json"), NFL, NOW)
    assert futurestore.record(futurestore.folder(), alias="nfl", key=NFL, fetched_at=NOW, regions=["us"],
                              question="x", markets=markets, names={}) is False
    assert futurestore.load(futurestore.folder())[0]["fetched_at"] == NOW + 3600


def test_a_read_is_kept_for_thirty_days_and_no_longer(home):
    markets, _ = parse_outrights(load("outrights_nfl.json"), NFL, NOW)
    folder = futurestore.folder()
    futurestore.record(folder, alias="nba", key=NBA, fetched_at=NOW - 31 * 86400, regions=["us"], question="x",
                       markets=markets, names={})
    futurestore.record(folder, alias="nfl", key=NFL, fetched_at=NOW, regions=["us"], question="x",
                       markets=markets, names={})
    assert [p.name for p in folder.glob("*.json")] == ["nfl.json"]


def test_clearing_the_key_deletes_the_futures_it_read(home):
    run("nfl")
    assert list(futurestore.folder().glob("*.json"))
    Cache().clear()
    assert futurestore.load(futurestore.folder()) == [] and not futurestore.folder().exists()


def test_a_futures_read_is_kept_out_of_the_history_the_odds_screen_and_low_hold_read(home):
    from overlay_engine import oddshistory
    run("nfl")
    assert oddshistory.snapshots(oddshistory.history_folder()) == []


def test_a_damaged_store_file_is_skipped_not_fatal(home):
    run("nfl")
    (futurestore.folder() / "nba.json").write_text("{not json")
    (futurestore.folder() / "mlb.json").write_text(json.dumps({"v": 99, "markets": []}))
    assert [b["league"] for b in futures.from_store(now=NOW + 1)["boards"]] == ["nfl"]


# ------------------------------------------------------------ the CLI

@pytest.fixture
def board_cli(monkeypatch, home):
    api, clock = FuturesApi(), Clock()
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(futures, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(futures, "time", SimpleNamespace(time=clock))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: KEY)
    return SimpleNamespace(api=api, clock=clock)


def fut(capsys, *extra, code=0):
    got = cli.main(["board", "--feed", "oddsapi", "--json", *extra])
    out = capsys.readouterr()
    assert got == code, out.err + out.out
    return json.loads(out.out)


def test_the_estimate_is_free_says_the_cost_and_cites_the_rule(board_cli, capsys):
    got = fut(capsys, "--futures", "--futures-league", "nfl", "--futures-league", "nba", "--estimate")
    assert board_cli.api.calls == []
    e = got["futures"]["estimate"]
    assert e["credits"] == 4 and e["leagues"] == ["nfl", "nba"] and e["rule"] == COST_RULE
    assert e["rule_source"] == futures.COST_RULE_SOURCE and "up to 4 of your Odds API credits" in e["text"]
    assert [c["alias"] for c in got["futures"]["choices"]["leagues"] if c["picked"]] == ["nfl", "nba"]


def test_the_estimate_with_nothing_picked_is_zero_credits(board_cli, capsys):
    got = fut(capsys, "--futures", "--estimate")
    assert got["futures"]["estimate"]["credits"] == 0 and board_cli.api.calls == []


def test_the_estimate_in_text_cites_the_rule_and_spends_nothing(board_cli, capsys):
    assert cli.main(["board", "--feed", "oddsapi", "--futures", "--futures-league", "nfl", "--estimate"]) == 0
    text = capsys.readouterr().out
    assert "up to 2 of your Odds API credits" in text and COST_RULE in text
    assert futures.COST_RULE_SOURCE in text and "no credits were spent" in text
    assert board_cli.api.calls == []


def test_futures_never_run_without_the_switch(board_cli, capsys):
    for extra in (["--futures-league", "nfl"], ["--futures-region", "us"]):
        out = fut(capsys, *extra, code=2)
        assert "Futures are off unless you ask for them" in out["error"]
    fut(capsys, "--sport", "nfl", "--estimate")
    plain = cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--json"])
    capsys.readouterr()
    assert plain == 0
    assert all("outrights" not in json.dumps(c[1]) and "winner" not in c[0] for c in board_cli.api.calls)


def test_the_main_board_is_unchanged_with_futures_off(board_cli, capsys):
    """Nothing about futures is asked for, priced or fetched unless it was switched on."""
    est = fut(capsys, "--sport", "nfl", "--estimate")
    assert "futures" not in est and est["estimate"]["credits"] == 2


def test_the_read_says_its_cost_before_the_first_request_and_reads_only_what_was_picked(
        monkeypatch, board_cli, capsys):
    seen = []
    real = board_cli.api.__call__

    class Spy:
        def __call__(self, path, params):
            seen.append(capsys.readouterr().out)
            return real(path, params)
    monkeypatch.setattr(futures, "odds_api_fetcher", lambda *a, **k: Spy())
    assert cli.main(["board", "--feed", "oddsapi", "--futures", "--futures-league", "nfl",
                     "--futures-region", "us"]) == 0
    assert "Reading futures uses up to 1 of your Odds API credit" in seen[0]
    out = capsys.readouterr().out
    assert "Super Bowl winner" in out and "ties your money up" in out and "least certain" in out
    assert "+EV: Chicago Bears at DraftKings" in out


def test_the_json_read_carries_the_view_what_it_cost_and_the_estimate(board_cli, capsys):
    got = fut(capsys, "--futures", "--futures-league", "nfl")
    assert [p for p in board_cli.api.paths()] == ["/v4/sports", f"/v4/sports/{NFL}/odds"]
    assert got["read"]["spent"] == 2 and got["read"]["remaining"] == 498 and got["read"]["stored"] == 1
    assert "This read used 2 credits" in got["read"]["text"]
    assert got["estimate"]["credits"] == 2 and got["futures"]["has_futures"] is True
    b = got["futures"]["boards"][0]
    assert b["league"] == "nfl" and len(b["rows"]) == 6 and b["plays"]
    assert KEY not in json.dumps(got)


def test_a_second_read_inside_a_minute_costs_nothing(board_cli, capsys):
    fut(capsys, "--futures", "--futures-league", "nfl")
    again = fut(capsys, "--futures", "--futures-league", "nfl")
    assert again["read"]["cached"] is True and again["read"]["spent"] == 0
    assert len(board_cli.api.odds_calls()) == 1


def test_the_stored_view_makes_no_request_and_never_touches_the_key(monkeypatch, board_cli, capsys):
    fut(capsys, "--futures", "--futures-league", "nfl")
    monkeypatch.setattr(keystore, "get_key", lambda *a, **k: pytest.fail("the stored view asked for the key"))
    monkeypatch.setattr(futures, "odds_api_fetcher", lambda *a, **k: pytest.fail("the stored view built a fetcher"))
    monkeypatch.setattr(futures, "read", lambda *a, **k: pytest.fail("the stored view read"))
    calls = len(board_cli.api.calls)
    board_cli.clock.now = NOW + 600
    got = fut(capsys, "--futures-stored")
    assert len(board_cli.api.calls) == calls
    assert got["futures"]["has_futures"] is True and "read" not in got


def test_the_stored_view_with_nothing_read_says_so(board_cli, capsys):
    got = fut(capsys, "--futures-stored")
    assert got["futures"]["has_futures"] is False and got["futures"]["message"] == futures.NONE_YET
    assert cli.main(["board", "--feed", "oddsapi", "--futures-stored"]) == 0
    assert futures.NONE_YET in capsys.readouterr().out


def test_an_ev_formula_prices_futures_and_a_held_one_does_not(board_cli, capsys):
    mine = json.dumps({"weights": {"pinnacle": 10}, "threshold": 100})
    got = fut(capsys, "--futures", "--futures-league", "nfl", f"--formula={mine}")
    assert got["futures"]["formula_sentence"] == "Futures are priced with your EV formula, the same way +EV bets are."
    assert got["futures"]["boards"][0]["formula_used"] is True
    held = fut(capsys, "--futures-stored", f"--formula={mine}", "--formula-paused")
    assert "held because Recommended is on" in held["futures"]["formula_sentence"]
    assert held["futures"]["boards"][0]["formula_used"] is False
    none = fut(capsys, "--futures-stored")
    assert none["futures"]["formula_sentence"] == ""


def test_the_minimum_edge_is_the_boards_own_flag(board_cli, capsys):
    fut(capsys, "--futures", "--futures-league", "nfl")
    assert len(fut(capsys, "--futures-stored")["futures"]["boards"][0]["plays"]) == 2
    assert len(fut(capsys, "--futures-stored", "--min-ev", "20")["futures"]["boards"][0]["plays"]) == 1


def test_a_missing_key_is_a_sentence_and_nothing_is_asked(monkeypatch, board_cli, capsys):
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: None)
    out = fut(capsys, "--futures", "--futures-league", "nfl", code=2)
    assert out["reason"] == "no_key" and board_cli.api.calls == []


def test_a_read_that_fails_is_a_sentence_without_the_key(board_cli, capsys):
    board_cli.api.fail = (f"/v4/sports/{NFL}/odds", (401, '{"error_code":"INVALID_KEY"}', {}))
    out = fut(capsys, "--futures", "--futures-league", "nfl", code=2)
    assert out["reason"] == "bad_key" and KEY not in json.dumps(out)


def test_the_choices_that_do_not_go_together_are_refused_in_a_sentence(board_cli, capsys):
    cases = [
        (["--futures", "--sport", "nfl"], "Futures are read on their own"),
        (["--futures", "--props"], "Futures are read on their own"),
        (["--futures", "--market", "totals"], "Futures are read on their own"),
        (["--futures", "--screen"], "Futures are read on their own"),
        (["--futures-stored", "--lowhold"], "Futures are read on their own"),
        (["--futures", "--futures-stored"], "Choose one"),
        (["--futures-stored", "--estimate"], "no cost to estimate"),
        (["--futures-stored", "--alerts", "{}"], "not for futures"),
        (["--futures", "--hidden", "[]"], "not for futures"),
    ]
    for extra, said in cases:
        out = fut(capsys, *extra, code=2)
        assert said in out["error"], extra
    assert board_cli.api.calls == []
    assert cli.main(["board", "--futures", "--json"]) == 2
    assert "only work with --feed oddsapi" in json.loads(capsys.readouterr().out)["error"]


def test_the_help_names_the_flags_and_says_the_cost():
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), pytest.raises(SystemExit):
        cli.main(["board", "--help"])
    text = re.sub(r"\s+", " ", buf.getvalue())
    for flag in ("--futures ", "--futures-league", "--futures-region", "--futures-stored"):
        assert flag in text, flag
    assert "Off unless you add this" in text and "a credit per region" in text


# ------------------------------------------------------------ the board's +EV search, made quicker for long lists

def test_the_fair_prices_without_a_book_are_worked_out_once_per_book_not_once_per_quote(monkeypatch):
    """A futures market has dozens of names at every book. `find_edges` used to recompute the whole market's fair
    values for every quote; a 120-name field took thirteen seconds. The answer cannot depend on which name is asked."""
    from overlay_engine import ev
    markets, _ = parse_outrights(load("outrights_nfl.json"), NFL, NOW)
    seen = []
    real = ev.fair_without

    def spy(market, books, book_key, *a, **k):
        seen.append(book_key)
        return real(market, books, book_key, *a, **k)
    monkeypatch.setattr(ev, "fair_without", spy)
    edges = ev.find_edges(markets[0], oddsapi.books_table(), NOW)
    assert len(seen) == len(set(seen)) == len({q.book for q in markets[0].quotes})
    assert edges == ev.find_edges(markets[0], oddsapi.books_table(), NOW), "the same edges, run twice"


def test_with_a_state_picked_no_best_price_or_ev_mark_is_at_a_book_not_licensed_there(home):
    """0.1.26's rule on futures too: a book licensed somewhere in the US but not in the person's state is a reference.
    DraftKings has every best price in this read, so the state is one where it is not licensed and others are."""
    run("nfl")
    state = next(s for s in sorted(catalog.STATE_NAMES)
                 if "dk" not in oddsapi.bettable_in(s) and {"fd", "betrivers"} & oddsapi.bettable_in(s))
    anywhere = futures.from_store(now=NOW + 60)
    assert all((r["best"] or {}).get("books") == ["dk"] for b in anywhere["boards"] for r in b["rows"])
    there = futures.from_store(now=NOW + 60, state=state)
    assert there["books_for"]["state"] == state and there["books_for"]["sentence"] == ""
    for b in there["boards"]:
        assert {c["key"]: c["bettable"] for c in b["books"]}["dk"] is False
        for r in b["rows"]:
            assert "dk" not in (r["best"] or {}).get("books", [])
            assert not r["cells"]["dk"].get("best") and not r["cells"]["dk"].get("ev")
    assert futures.from_store(now=NOW + 60)["books_for"]["sentence"] == oddsapi.NO_STATE
