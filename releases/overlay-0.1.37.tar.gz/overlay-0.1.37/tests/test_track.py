"""Track this bet, the engine's side: a bet placed from the board, saved to this Mac with the fair price it
was found against, and settled by the person when the game is over.

What these pin is what the button cannot show:

  * every leg of every kind of play carries the engine's block for it (an arb's two legs, a +EV bet, both
    legs of a middle), and the fair price in it is the very one the row's own EV is judged by;
  * saving writes the fair price, the spread and the calibration inputs the ledger learns from, the price and
    the stake the person actually typed, and the commission a book takes, and says where the bet came from;
  * the fair price does not move when the price you got does, and a bet with no fair price is saved as one,
    never with a made-up price, so it counts in the record and never in actual against expected profit;
  * the same form saved twice saves once, and a refusal writes nothing;
  * the person says how it ended, the engine works out the profit, and a settled bet is never rewritten;
  * everything it says stays inside what the product says on its own, and nothing leaves the Mac.

Nothing here touches the real `~/.overlay`: every ledger is a temporary file.
"""

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import board, tracker, tracking
from overlay_engine.cli import DEFAULT_BOOKS, _demo_market
from overlay_engine.ledger import Ledger, LedgerError
from overlay_engine.models import Market, Outcome, Quote

ROOT = Path(__file__).resolve().parent.parent
BANNED = ("guaranteed", "risk-free", "risk free", "riskfree", "either way")
NOW = 1_700_000_000.0


def _now(market):
    return max(q.seen_at for q in market.quotes)


def _middle_market():
    """The demo's total, plus two sharp-priced lines on either side, so a middle sits between them."""
    base = _demo_market()
    extra = []
    for line in (219.0, 221.0):
        for book in ("pinnacle", "circa"):
            for side in ("over", "under"):
                extra.append(Quote(book=book, outcome=Outcome(name=side, line=line), decimal=1.95,
                                   seen_at=base.quotes[0].seen_at))
    extra.append(Quote(book="dk", outcome=Outcome(name="over", line=219.0), decimal=2.2,
                       seen_at=base.quotes[0].seen_at))
    extra.append(Quote(book="fd", outcome=Outcome(name="under", line=221.0), decimal=2.2,
                       seen_at=base.quotes[0].seen_at))
    return Market(event_id=base.event_id, sport=base.sport, market_type="totals",
                  quotes=base.quotes + extra, starts_at=base.starts_at)


def _rows(kinds=("arb", "ev"), market=None):
    """The way the live board does it: one two-sided market per line for arbs and +EV, the whole market for middles."""
    from overlay_engine.oddsapi import split_by_line
    market = market or _demo_market()
    common = dict(bankroll=1000.0, now=_now(market), detail=True)
    rows = []
    paired = tuple(k for k in kinds if k in ("arb", "ev"))
    if paired:
        rows += board.scan(split_by_line([market]), DEFAULT_BOOKS, kinds=paired, **common)
    if "middle" in kinds:
        rows += board.scan([market], DEFAULT_BOOKS, kinds=("middle",), **common)
    return rows


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "t.db") as ledger:
        yield ledger


def _pick(**over):
    pick = {"event_id": "g1", "sport": "basketball_nba", "market_type": "totals", "outcome": "over@220.5",
            "book": "dk", "book_name": "DraftKings", "selection": "Over 220.5", "decimal": 2.1, "american": 110,
            "commission": 0.0, "stake": 25.0, "kind": "ev", "p_fill": 0.9, "starts_at": NOW + 5400,
            "fair": {"prob": 0.5, "low": 0.49, "high": 0.51, "american": 100,
                     "devig": {"power": 0.5, "shin": 0.5, "additive": 0.5, "multiplicative": 0.5},
                     "book_probs": {"pinnacle": 0.5, "circa": 0.5}, "anchored": True, "text": "How it was made."},
            "no_fair": None}
    pick.update(over)
    return pick


def _save(db, pick=None, **over):
    args = dict(price="+110", stake="25", game="BOS vs LAL", league="NBA", ref="r1", now=NOW)
    args.update(over)
    return tracking.save(db, pick or _pick(), **args)


# ------------------------------------------------------------ the block each leg carries

def test_every_leg_of_every_kind_of_play_carries_the_engines_block():
    rows = _rows(("arb", "ev", "middle"), _middle_market())
    kinds = {r.kind for r in rows}
    assert kinds == {"arb", "ev", "middle"}, "the fixture must hold all three kinds of play"
    for row in rows:
        assert row.legs
        for leg in row.legs:
            t = leg["track"]
            assert t["kind"] == row.kind and t["book"] == leg["book"] and t["decimal"] == leg["decimal"]
            assert t["stake"] == leg["stake"], "the suggested stake is the engine's own"
            assert t["event_id"] and t["sport"] and t["market_type"] and t["outcome"] and t["selection"]
            assert t["fair"] is not None, f"{row.kind} leg {t['outcome']} has no fair price"


def test_a_row_made_without_detail_carries_no_blocks():
    market = _demo_market()
    rows = board.scan([market], DEFAULT_BOOKS, now=_now(market), kinds=("arb", "ev"))
    assert rows and all("track" not in leg for r in rows for leg in r.legs)


def test_the_fair_price_in_the_block_is_the_one_the_rows_own_edge_is_judged_by():
    for row in _rows(("ev", "arb")):
        for leg, blk in zip(row.legs, row.detail["ev_by_book"]):
            mine = next(x for x in blk["rows"] if x["mine"])
            assert leg["track"]["fair"]["prob"] == pytest.approx(mine["fair_prob"]), (
                "the saved fair price must leave the book you bet at out of it, exactly as the row's EV does")


def test_the_block_carries_what_the_ledger_learns_from_and_it_is_a_valid_spread():
    leg = _rows(("ev",))[0].legs[0]
    fair = leg["track"]["fair"]
    assert set(fair["devig"]) == {"additive", "multiplicative", "power", "shin"}
    assert fair["book_probs"] and all(0 < p < 1 for p in fair["book_probs"].values())
    assert fair["low"] <= fair["prob"] <= fair["high"]
    assert fair["anchored"] is True and "left out of it" in fair["text"]
    assert "dk" not in fair["book_probs"], "the book you bet at helps set no part of its own fair price"


def test_a_middles_legs_each_have_a_fair_price_on_their_own_line_and_the_key_is_the_markets():
    row = [r for r in _rows(("middle",), _middle_market())][0]
    keys = [leg["track"]["outcome"] for leg in row.legs]
    assert [leg["outcome"] for leg in row.legs] == ["over@219.0", "under@221.0"], "the row writes the line the way the plan did"
    assert keys == ["over@219", "under@221"], "the ledger keeps the market's key, which the grader looks up"
    assert row.legs[0]["track"]["selection"] == "Over 219" and row.legs[1]["track"]["selection"] == "Under 221"


def test_a_middles_leg_is_priced_against_its_own_two_sided_line_and_not_the_whole_market():
    """Pinnacle and Circa price every line here, so the whole market devigs, as six outcomes at a sixth each.
    The leg on the 219 line is a two-sided market at 1.95 each way: a half."""
    row = _rows(("middle",), _middle_market())[0]
    first = row.legs[0]["track"]
    assert first["outcome"] == "over@219" and first["fair"]["prob"] == pytest.approx(0.5, abs=1e-6)
    assert row.legs[1]["track"]["fair"]["prob"] == pytest.approx(0.5, abs=1e-6)


def test_a_leg_with_no_fair_price_says_so_and_says_what_saving_it_means():
    one_book = Market(event_id="e", sport="nfl", market_type="h2h", starts_at=None,
                      quotes=[Quote(book="dk", outcome=Outcome("home"), decimal=2.0, seen_at=1.0),
                              Quote(book="fd", outcome=Outcome("away"), decimal=2.0, seen_at=1.0)])
    pick = tracking.leg_pick("ev", one_book, DEFAULT_BOOKS, {"book": "dk", "outcome": "home", "decimal": 2.0,
                                                           "american": 100, "stake": 10.0}, tracking.FairCache())
    assert pick["fair"] is None and "no price to take the margin out of" in pick["no_fair"]
    assert "counts in your record, and not in actual against expected profit" in pick["no_fair"]


# ------------------------------------------------------------ saving

def test_a_saved_bet_carries_its_fair_price_its_spread_and_where_it_came_from(db):
    out = _save(db)
    assert out["saved"] and out["priced"] and out["duplicate"] is False
    bet = db.get_bet(out["bet_id"])
    assert bet["source"] == "tracked" and bet["external_ref"] == "r1"
    assert (bet["fair_prob"], bet["fair_low"], bet["fair_high"]) == (0.5, 0.49, 0.51)
    assert json.loads(bet["devig_json"]) == _pick()["fair"]["devig"]
    assert json.loads(bet["book_probs"]) == _pick()["fair"]["book_probs"]
    assert bet["p_fill"] == 0.9 and bet["placed_at"] == NOW
    assert (bet["event_id"], bet["market_type"], bet["outcome"], bet["book"]) == ("g1", "totals", "over@220.5", "dk")
    assert tracker._priced(bet), "a tracked bet with its fair price saved is one the engine priced"


def test_it_saves_the_price_and_the_stake_the_person_typed_not_the_ones_it_suggested(db):
    out = _save(db, price="+125", stake="$40.50")
    bet = db.get_bet(out["bet_id"])
    assert bet["decimal_odds"] == pytest.approx(2.25) and bet["stake"] == 40.5
    assert "+125" in out["text"] and "$40.50" in out["text"]


def test_the_fair_price_does_not_move_when_the_price_you_got_does(db):
    a = db.get_bet(_save(db, price="+110", ref="a")["bet_id"])
    b = db.get_bet(_save(db, price="+150", ref="b")["bet_id"])
    assert a["fair_prob"] == b["fair_prob"] == 0.5 and b["decimal_odds"] > a["decimal_odds"]
    worse = _save(db, price="-120", ref="c")
    better = _save(db, price="+150", ref="d")
    assert worse["expected"]["ev"] < 0 < better["expected"]["ev"], "what it is worth at the price saved is the engine's"


def test_a_book_that_takes_a_cut_is_saved_net_of_it(db):
    out = _save(db, _pick(commission=0.02), price="+200", ref="x")
    assert db.get_bet(out["bet_id"])["decimal_odds"] == pytest.approx(1.0 + 2.0 * 0.98)


def test_the_same_form_saved_twice_saves_once(db):
    first = _save(db, ref="same")
    again = _save(db, ref="same")
    assert again["duplicate"] is True and again["bet_id"] == first["bet_id"]
    assert db.stats()["bets"] == 1
    other = _save(db, ref="other")
    assert other["bet_id"] != first["bet_id"] and db.stats()["bets"] == 2, "a second bet is not a repeat"


def test_what_the_bet_was_called_is_kept_with_it(db):
    out = _save(db)
    label = db.labels()[out["bet_id"]]
    assert label == {"game": "BOS vs LAL", "league": "NBA", "selection": "Over 220.5", "starts_at": NOW + 5400}


def test_the_expected_profit_at_the_price_saved_is_the_engines_and_says_it_is_an_average(db):
    out = _save(db, price="+110", stake="100")
    assert out["expected"]["ev"] == pytest.approx(0.5 * 2.1 - 1.0)
    assert out["expected"]["money"] == pytest.approx(5.0)
    assert "average over many bets" in out["text"] and "can lose" in out["text"]


def test_a_bet_with_no_fair_price_is_saved_as_one_and_is_never_called_priced(db):
    out = _save(db, _pick(fair=None, no_fair="x"))
    assert out["saved"] and out["priced"] is False and out["expected"] is None
    bet = db.get_bet(out["bet_id"])
    assert bet["source"] == "tracked" and bet["devig_json"] == "{}"
    assert not tracker._priced(bet), "the break-even stand-in is not a fair price"
    assert "no fair price" in out["text"] and "not in actual against expected profit" in out["text"]


@pytest.mark.parametrize("kwargs, said", [
    ({"price": "oops"}, "is not a price"),
    ({"price": ""}, "empty odds"),
    ({"stake": "0"}, "more than zero"),
    ({"stake": "-5"}, "more than zero"),
    ({"stake": "lots"}, "is not an amount"),
])
def test_a_refusal_says_why_in_a_sentence_and_writes_nothing(db, kwargs, said):
    with pytest.raises(LedgerError) as exc:
        _save(db, **kwargs)
    assert said in str(exc.value)
    assert db.stats()["bets"] == 0 and db.labels() == {}


def test_a_block_the_window_garbled_is_refused_and_writes_nothing(db):
    for text in ("not json", "[]", json.dumps({"event_id": "g1"})):
        with pytest.raises(LedgerError):
            tracking.read_pick(text)
    for fair in ({"prob": 0.5, "low": 0.6, "high": 0.7, "devig": {"power": 0.5}},
                 {"prob": 0.5, "low": 0.4, "high": 0.6, "devig": {}},
                 {"prob": 1.5, "low": 1.4, "high": 1.6, "devig": {"power": 0.5}},
                 {"prob": "x"}):
        with pytest.raises(LedgerError):
            _save(db, _pick(fair=fair))
    assert db.stats()["bets"] == 0


# ------------------------------------------------------------ settling

def test_the_engine_works_out_the_profit_from_the_stake_and_the_price_saved(db):
    bet = _save(db, price="+150", stake="40")["bet_id"]
    won = tracking.settle(db, bet, "won")
    assert won["profit"] == 60.0 and won["result"] == "won"
    lost = tracking.settle(db, _save(db, price="+150", stake="40", ref="b")["bet_id"], "lost")
    assert lost["profit"] == -40.0
    for result in ("push", "void"):
        got = tracking.settle(db, _save(db, ref=result)["bet_id"], result)
        assert got["profit"] == 0.0 and "stake comes back" in got["text"]


def test_a_settled_bet_is_never_rewritten(db):
    bet = _save(db)["bet_id"]
    tracking.settle(db, bet, "won")
    with pytest.raises(LedgerError) as exc:
        tracking.settle(db, bet, "lost")
    assert "already settled" in str(exc.value)
    assert db.get_bet(bet)["result"] == "won"
    with pytest.raises(LedgerError):
        tracking.settle(db, 999, "won")
    with pytest.raises(LedgerError):
        tracking.settle(db, bet, "maybe")


def test_settling_leaves_the_closing_price_alone(db):
    bet = _save(db)["bet_id"]
    db.conn.execute("UPDATE bets SET closing_fair_prob = 0.55 WHERE id = ?", (bet,))
    tracking.settle(db, bet, "lost")
    assert db.get_bet(bet)["closing_fair_prob"] == 0.55


def _dash(db, now=NOW + 60):
    return tracker.dashboard(db, __import__("overlay_engine.performance", fromlist=["x"]).report(db.settled_bets()), {}, now)


def test_once_settled_a_priced_bet_counts_in_actual_against_expected_and_an_unpriced_one_does_not(db):
    priced = _save(db, price="+110", stake="100", ref="p")["bet_id"]
    bare = _save(db, _pick(fair=None, no_fair="x"), price="+110", stake="100", ref="n")["bet_id"]
    assert _dash(db)["expected"]["available"] is False, "nothing is settled yet"
    tracking.settle(db, priced, "won")
    tracking.settle(db, bare, "won")
    got = _dash(db)["expected"]
    assert got["available"] and got["priced"] == 1 and got["settled"] == 2
    assert got["actual"] == pytest.approx(110.0) and got["expected"] == pytest.approx(5.0)
    assert "1 of your 2 settled bets" in got["text"]


def test_a_void_tracked_bet_is_taken_out_of_the_record(db):
    bet = _save(db)["bet_id"]
    tracking.settle(db, bet, "void")
    assert _dash(db)["summary"]["settled"] == 1
    assert _dash(db)["expected"]["settled"] == 0


# ------------------------------------------------------------ the list of open bets

def test_the_open_list_names_each_bet_newest_first_and_says_what_settling_it_pays(db):
    older = _save(db, ref="a", now=NOW)["bet_id"]
    newer = _save(db, _pick(fair=None, no_fair="x", outcome="under@220.5", selection="Under 220.5"), ref="b", now=NOW + 30,
                  price="-110", stake="11")["bet_id"]
    got = _dash(db, NOW + 90)["open"]
    assert [o["id"] for o in got] == [newer, older]
    new, old = got
    assert new["priced"] is False and new["fair_american"] is None and "No fair price" in new["fair_text"]
    assert new["american"] == -110 and new["stake"] == 11.0 and new["if_won"] == 10.0 and new["if_lost"] == -11.0
    assert old["priced"] is True and old["fair_american"] == 100 and old["tracked"] is True
    assert old["game"] == "BOS vs LAL" and old["league"] == "NBA" and old["selection"] == "Over 220.5"
    assert old["book_name"] and old["market"] == "Total" and old["placed_text"] == "placed 1 minute ago"


def test_a_tracked_bet_knows_when_its_game_starts_and_one_with_no_time_is_waiting(db):
    soon = _save(db, _pick(event_id="soon", starts_at=NOW + 3600), ref="s")["bet_id"]
    none = _save(db, _pick(event_id="none", starts_at=None), ref="n")["bet_id"]
    done = _save(db, _pick(event_id="done", starts_at=NOW - 20 * 3600), ref="d")["bet_id"]
    live = _save(db, _pick(event_id="live", starts_at=NOW - 3600), ref="l")["bet_id"]
    by_id = {o["id"]: o["state"] for o in _dash(db)["open"]}
    assert by_id == {soon: "upcoming", none: "waiting", done: "waiting", live: "live"}


def test_only_the_newest_fifty_are_listed_and_the_rest_are_counted(db):
    for i in range(53):
        _save(db, ref=f"r{i}", now=NOW + i)
    dash = _dash(db, NOW + 100)
    assert len(dash["open"]) == 50 and dash["open_total"] == 53
    assert dash["open_note"] == "Showing the newest 50 of 53 open bets."
    assert _dash(Ledger(":memory:"))["open_note"] == ""


def test_a_ledger_with_nothing_open_lists_nothing(db):
    assert _dash(db)["open"] == [] and _dash(db)["open_total"] == 0


def test_an_imported_bet_is_listed_without_a_game_and_says_it_has_no_fair_price(db):
    db.import_bet(event_id="slip-1", sport="nfl", market_type="h2h", outcome="home", book="dk", decimal_odds=2.0,
                  stake=10.0, placed_at=NOW)
    (o,) = _dash(db)["open"]
    assert o["game"] == "" and o["tracked"] is False and o["priced"] is False and o["selection"] == "Home"


# ------------------------------------------------------------ the ledger

def test_the_ledger_is_one_version_on_and_an_older_one_comes_up_to_it(tmp_path):
    from overlay_engine.ledger import SCHEMA_VERSION
    assert SCHEMA_VERSION == 11
    path = tmp_path / "old.db"
    with Ledger(path) as db:
        db.conn.execute("DROP TABLE bet_labels")
        db.conn.execute("UPDATE meta SET value = '10' WHERE key = 'schema_version'")
        db.conn.commit()
    with Ledger(path) as db:
        assert db.labels() == {}
        assert int(db.conn.execute("SELECT value FROM meta WHERE key = 'schema_version'").fetchone()["value"]) == 11


def test_saving_from_the_board_leaves_an_imported_bet_counted_as_imported(db):
    _save(db)
    db.import_bet(event_id="x", sport="nfl", market_type="h2h", outcome="home", book="dk", decimal_odds=2.0, stake=5.0,
                  placed_at=NOW)
    assert db.stats()["imported"] == 1 and db.stats()["bets"] == 2


# ------------------------------------------------------------ the verb

def _verb(home, *args):
    run = subprocess.run([sys.executable, str(ROOT / "backend" / "cli.py"), "track", *args, "--json"],
                         capture_output=True, text=True, env={**os.environ, "OVERLAY_HOME": str(home)})
    return run.returncode, json.loads(run.stdout)


def test_the_verb_saves_a_bet_from_the_boards_own_block_into_the_ledger_it_is_pointed_at(tmp_path):
    run = subprocess.run([sys.executable, str(ROOT / "backend" / "cli.py"), "board", "--json"], capture_output=True,
                         text=True, env={**os.environ, "OVERLAY_HOME": str(tmp_path / "board-home")})
    assert run.returncode == 0, run.stderr
    leg = json.loads(run.stdout)["rows"][0]["legs"][0]
    assert leg["track"]["fair"]
    path = tmp_path / "t.db"
    code, out = _verb(tmp_path, f"--pick={json.dumps(leg['track'])}", "--price=+105", "--stake=25", "--game=BOS vs LAL",
                      "--league=NBA", "--ref=once", "--db", str(path))
    assert code == 0 and out["command"] == "track" and out["saved"] and out["priced"], out
    with Ledger(path) as db:
        bet = db.get_bet(out["bet_id"])
        assert bet["source"] == "tracked" and bet["decimal_odds"] == pytest.approx(2.05)
        assert bet["fair_prob"] == pytest.approx(leg["track"]["fair"]["prob"])
    code, again = _verb(tmp_path, f"--pick={json.dumps(leg['track'])}", "--price=+105", "--stake=25", "--ref=once",
                        "--db", str(path))
    assert code == 0 and again["duplicate"] is True


def test_the_verb_settles_and_refuses_in_a_sentence_with_a_failing_exit_and_no_traceback(tmp_path):
    path = tmp_path / "t.db"
    pick = json.dumps({"event_id": "g", "sport": "nba", "market_type": "h2h", "outcome": "home", "book": "dk"})
    code, out = _verb(tmp_path, f"--pick={pick}", "--price=+110", "--stake=10", "--db", str(path))
    assert code == 0 and out["priced"] is False
    code, won = _verb(tmp_path, f"--settle={out['bet_id']}", "--result=won", "--db", str(path))
    assert code == 0 and won["settled"] and won["profit"] == 11.0
    code, bad = _verb(tmp_path, f"--settle={out['bet_id']}", "--result=lost", "--db", str(path))
    assert code == 2 and "already settled" in bad["error"] and "Traceback" not in json.dumps(bad)
    code, bad = _verb(tmp_path, f"--pick={pick}", "--price=oops", "--stake=10", "--db", str(path))
    assert code == 2 and "is not a price" in bad["error"]
    code, bad = _verb(tmp_path, "--db", str(path))
    assert code == 2 and "no bet to save" in bad["error"].lower()
    code, bad = _verb(tmp_path, f"--settle={out['bet_id']}", "--db", str(path))
    assert code == 2 and "how it ended" in bad["error"]


def test_the_performance_verb_carries_the_open_list(tmp_path):
    path = tmp_path / "t.db"
    pick = json.dumps({"event_id": "g", "sport": "nba", "market_type": "h2h", "outcome": "home", "book": "dk"})
    _verb(tmp_path, f"--pick={pick}", "--price=+110", "--stake=10", "--db", str(path))
    run = subprocess.run([sys.executable, str(ROOT / "backend" / "cli.py"), "performance", "--db", str(path), "--json"],
                         capture_output=True, text=True, env={**os.environ, "OVERLAY_HOME": str(tmp_path)})
    assert run.returncode == 0, run.stderr
    out = json.loads(run.stdout)["tracker"]
    assert len(out["open"]) == 1 and out["open_total"] == 1 and out["summary"]["empty"] is False


# ------------------------------------------------------------ what it says, and where it goes

def _strings(node):
    if isinstance(node, str):
        yield node
    elif isinstance(node, dict):
        for k, v in node.items():
            yield from _strings(k)
            yield from _strings(v)
    elif isinstance(node, (list, tuple)):
        for v in node:
            yield from _strings(v)


def test_nothing_it_says_promises_more_than_it_is(db):
    saved = _save(db)
    bare = _save(db, _pick(fair=None, no_fair="x"), ref="n")
    won = tracking.settle(db, saved["bet_id"], "won")
    pushed = tracking.settle(db, bare["bet_id"], "push")
    texts = list(_strings([saved, bare, won, pushed, _dash(db), _rows(("arb", "ev", "middle"), _middle_market())[0].legs[0]["track"],
                           tracking.NEVER_PLACES, tracking.NO_FAIR_SAVED]))
    assert len(texts) > 20
    for text in texts:
        for word in BANNED:
            assert word not in text.lower(), (word, text)


def test_it_never_reaches_a_book_or_a_network():
    source = (ROOT / "backend" / "overlay_engine" / "tracking.py").read_text()
    for name in ("socket", "urllib", "http", "requests", "subprocess", "webbrowser", "smtplib", "ssl"):
        assert f"import {name}" not in source and f"from {name}" not in source, name
    assert tracking.NEVER_PLACES.startswith("Bookbreaker never places a bet")
