"""The odds screen, the row detail, and the outcomes with a bet order: the engine's side.

Three things a bettor expects from a board that shows plays, each built from
numbers the engine already has and checked here against the engine's own other
calls rather than against a second copy of the arithmetic:

  * **The odds screen** lays out the prices the user's own Odds API feed has
    already read: one row per game and side, one column per book, the best price
    in each row marked. It fetches nothing and spends no credit, so these tests
    give it a fetcher that raises and a Keychain that raises, and a call count.
  * **The row detail** (fair price and how it was made, EV by book, the two-sided
    table) is the same fair value and the same `evaluate` the row was found with.
    The row's own EV is held to its own line in the table.
  * **Outcomes and bet order** copy the staking code's own per-leg figures, and
    number the legs by a rule that is checked on fixtures built so that the rule
    and its opposite give different answers.
"""

import json
import re
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

import test_oddsapi as to  # noqa: E402
import test_xvenue as tx  # noqa: E402
from overlay_engine import (FillModel, LatencyModel, betorder, board, cli, detail,  # noqa: E402
                            keystore, oddsapi, oddshistory, screen, xvenue)
from overlay_engine.ev import evaluate, fair_without  # noqa: E402
from overlay_engine.models import Market, Outcome, Quote  # noqa: E402

NOW = to.NOW
BANNED = ("guaranteed", "risk-free", "risk free", "riskfree", "either way")


# ------------------------------------------------------------ a world with three bet types

HOME, AWAY = "Kansas City Chiefs", "Buffalo Bills"


def full_book(key, ml=(2.0, 1.9), spread=(-3.5, 1.91, 1.91), total=(47.5, 1.91, 1.91), updated=NOW - 6):
    """One book's three markets for the Chiefs-Bills game, shaped as the API sends them."""
    stamp = to.iso(updated)
    markets = []
    if ml:
        markets.append({"key": "h2h", "last_update": stamp, "outcomes": [
            {"name": HOME, "price": ml[0]}, {"name": AWAY, "price": ml[1]}]})
    if spread:
        line, home_price, away_price = spread
        markets.append({"key": "spreads", "last_update": stamp, "outcomes": [
            {"name": HOME, "price": home_price, "point": line},
            {"name": AWAY, "price": away_price, "point": -line}]})
    if total:
        line, over, under = total
        markets.append({"key": "totals", "last_update": stamp, "outcomes": [
            {"name": "Over", "price": over, "point": line}, {"name": "Under", "price": under, "point": line}]})
    return {"key": key, "title": key.title(), "last_update": stamp, "markets": markets}


def world(start=NOW + 3600):
    return [to.event("g1", start=start, books=[
        full_book("draftkings", ml=(2.10, 1.80), total=(47.5, 1.95, 1.87)),
        full_book("fanduel", ml=(1.80, 2.05), spread=(-3.5, 1.95, 1.87), total=(48.5, 1.91, 1.91)),
        full_book("betmgm", ml=(1.95, 1.90), spread=(-2.5, 1.91, 1.91), total=(47.5, 1.91, 1.91)),
        full_book("pinnacle", ml=(1.95, 1.95), spread=(-3.5, 1.95, 1.95), total=(47.5, 2.30, 1.65)),
    ])]


ALL = ["h2h", "spreads", "totals"]


def only(payload, *kinds):
    """The payload as the API sends it when only these bet types were asked for."""
    out = json.loads(json.dumps(payload))
    for ev in out:
        for b in ev["bookmakers"]:
            b["markets"] = [m for m in b["markets"] if m["key"] in kinds]
    return out


def read(markets=ALL, payload=None, clock=None, sport="nfl", api=None):
    api = api or to.FakeApi({"americanfootball_nfl": payload or world()})
    got = oddsapi.refresh(to.est(sport, markets=markets), to.KEY, clock=clock or to.Clock(), fetcher=api)
    return got, api


@pytest.fixture
def home(monkeypatch, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


BETTABLE = set(oddsapi.BETTABLE)


def grid_of(screen_json, league="nfl", market="h2h"):
    return next(g for g in screen_json["grids"] if g["league"] == league and g["market"] == market)


def strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for v in value.values():
            yield from strings(v)
    elif isinstance(value, list):
        for v in value:
            yield from strings(v)


# ================================================================ 1. the odds screen

def test_the_grid_is_a_row_per_game_and_side_and_a_column_per_book(home):
    got, _ = read()
    s = screen.from_refresh(got, BETTABLE)
    g = grid_of(s)
    assert [x["key"] for x in g["books"]] == ["dk", "fd", "mgm", "pinnacle"]
    [game] = g["games"]
    assert game["game"] == "Buffalo Bills at Kansas City Chiefs" and game["event_id"] == "g1"
    assert [r["label"] for r in game["rows"]] == [AWAY, HOME], "the sides read in the order of the title"
    for row in game["rows"]:
        assert set(row["cells"]) == {"dk", "fd", "mgm", "pinnacle"}


def test_each_cell_is_the_price_the_book_posted_in_american(home):
    got, _ = read()
    g = grid_of(screen.from_refresh(got, BETTABLE))
    chiefs = next(r for r in g["games"][0]["rows"] if r["label"] == HOME)
    assert chiefs["cells"]["dk"]["american"] == 110          # 2.10
    assert chiefs["cells"]["fd"]["american"] == -125         # 1.80
    assert chiefs["cells"]["dk"]["decimal"] == 2.1
    assert chiefs["cells"]["dk"]["age"] == 6.0, "aged by the book's own last update"


def test_the_best_price_is_marked_and_only_among_books_you_can_bet_at(home):
    """Pinnacle posts +130 on the Over; it prices the market and is not a bet."""
    got, _ = read()
    over = next(r for r in grid_of(screen.from_refresh(got, BETTABLE), market="totals")["games"][0]["rows"]
                if r["label"] == "Over 47.5")
    assert over["cells"]["pinnacle"]["american"] == 130
    assert "best" not in over["cells"]["pinnacle"], "a reference book is never the highlighted price"
    assert over["best"]["books"] == ["dk"] and over["best"]["american"] == -105
    assert [b for b, c in over["cells"].items() if c.get("best")] == ["dk"]


def test_a_tie_marks_every_book_that_shares_the_best_price(home):
    got, _ = read()
    over = next(r for r in grid_of(screen.from_refresh(got, BETTABLE), market="spreads")["games"][0]["rows"]
                if r["label"] == f"{HOME} -3.5")
    # DraftKings has no spread in this world; FanDuel 1.95 is alone at the top of -3.5.
    assert over["best"]["books"] == ["fd"]
    flat = {"draftkings": full_book("draftkings", spread=(-3.5, 1.91, 1.91)),
            "fanduel": full_book("fanduel", spread=(-3.5, 1.91, 1.91))}
    got, _ = read(payload=[to.event("g1", list(flat.values()))], clock=to.Clock(NOW + 100))   # past the cache
    row = next(r for r in grid_of(screen.from_refresh(got, BETTABLE), market="spreads")["games"][0]["rows"]
               if r["label"] == f"{HOME} -3.5")
    assert row["best"]["books"] == ["dk", "fd"] and all(row["cells"][b]["best"] for b in ("dk", "fd"))


def test_reference_books_have_their_own_columns_after_the_books_you_can_bet_at(home):
    got, _ = read()
    books = grid_of(screen.from_refresh(got, BETTABLE))["books"]
    assert [(b["key"], b["bettable"]) for b in books] == [
        ("dk", True), ("fd", True), ("mgm", True), ("pinnacle", False)]
    assert books[-1]["name"] == "Pinnacle"


def test_spreads_and_totals_list_each_line_with_both_sides(home):
    got, _ = read()
    s = screen.from_refresh(got, BETTABLE)
    labels = [r["label"] for r in grid_of(s, market="totals")["games"][0]["rows"]]
    # Three books agree on 47.5 and one is on 48.5: the line most books post comes first.
    assert labels == ["Over 47.5", "Under 47.5", "Over 48.5", "Under 48.5"]
    spreads = [r["label"] for r in grid_of(s, market="spreads")["games"][0]["rows"]]
    assert spreads[:2] == [f"{AWAY} +3.5", f"{HOME} -3.5"], spreads
    assert set(spreads) == {f"{AWAY} +3.5", f"{HOME} -3.5", f"{AWAY} +2.5", f"{HOME} -2.5"}
    # A line is compared only with the same line: Over 48.5 is priced by FanDuel alone.
    assert list(grid_of(s, market="totals")["games"][0]["rows"][2]["cells"]) == ["fd"]


def test_the_time_the_prices_were_read_is_on_every_grid(home):
    clock = to.Clock()
    got, _ = read(clock=clock)
    clock.now = NOW + 90
    s = screen.from_refresh(got, BETTABLE, now=NOW + 90)
    for g in s["grids"]:
        assert g["read_at"] == NOW and g["age"] == 90.0
    assert s["read_at"] == NOW and s["oldest"] == NOW


def test_ages_are_worded_by_the_engine_so_the_window_never_converts_seconds():
    words = [screen.ago(s) for s in (0, 4, 6, 59, 60, 119, 600, 3599, 3600, 7199, 7200, -3)]
    assert words == ["just now", "just now", "6 seconds ago", "59 seconds ago", "1 minute ago", "1 minute ago",
                     "10 minutes ago", "59 minutes ago", "1 hour ago", "1 hour ago", "2 hours ago", "just now"]


def test_every_cell_says_how_long_ago_its_book_confirmed_the_price(home):
    got, _ = read()
    g = grid_of(screen.from_refresh(got, BETTABLE, now=NOW + 60))
    cell = g["games"][0]["rows"][0]["cells"]["dk"]
    assert cell["age"] == 66.0 and cell["age_text"] == "last confirmed 1 minute ago"
    assert g["age_text"] == "1 minute ago"


def test_a_grid_read_more_than_ten_minutes_ago_carries_a_warning_and_a_fresh_one_does_not(home):
    got, _ = read(payload=world(start=NOW + 40000))
    fresh = grid_of(screen.from_refresh(got, BETTABLE, now=NOW + 600))
    old = grid_of(screen.from_refresh(got, BETTABLE, now=NOW + 601))
    assert screen.OLD_AFTER == 600.0 and fresh["warning"] == ""
    assert "read 10 minutes ago" in old["warning"] and "check each price at the book before you bet" in old["warning"]


def test_the_switches_need_nothing_more_than_the_screen_already_holds(home):
    """Two leagues, three bet types: a grid for each pair, every one complete, so the
    window moves between them without asking the engine for anything."""
    nba = [{"id": "n1", "sport_key": "basketball_nba", "sport_title": "NBA", "commence_time": to.iso(NOW + 7200),
            "home_team": "Boston Celtics", "away_team": "Miami Heat", "bookmakers": [
                {"key": "draftkings", "title": "DraftKings", "last_update": to.iso(NOW - 3), "markets": [
                    {"key": "h2h", "last_update": to.iso(NOW - 3), "outcomes": [
                        {"name": "Boston Celtics", "price": 1.5}, {"name": "Miami Heat", "price": 2.7}]}]}]}]
    api = to.FakeApi({"americanfootball_nfl": world(), "basketball_nba": nba})
    got = oddsapi.refresh(to.est("nfl", "nba", markets=ALL), to.KEY, clock=to.Clock(), fetcher=api)
    s = screen.from_refresh(got, BETTABLE)
    assert [x["alias"] for x in s["leagues"]] == ["nfl", "nba"]
    assert [x["key"] for x in s["markets"]] == ["h2h", "spreads", "totals"]
    assert {(g["league"], g["market"]) for g in s["grids"]} == {
        ("nfl", "h2h"), ("nfl", "spreads"), ("nfl", "totals"), ("nba", "h2h")}
    assert len(api.calls) == 2, "one request per league, as the refresh made them, and none for the screen"
    for g in s["grids"]:
        assert g["books"] and g["games"] and all(r["cells"] for gm in g["games"] for r in gm["rows"])


def test_building_the_screen_asks_the_feed_for_nothing(home):
    got, api = read()
    before = len(api.calls)
    screen.from_refresh(got, BETTABLE)
    screen.from_history(oddshistory.history_folder(), BETTABLE, NOW + 5)
    assert len(api.calls) == before == 1


# ---- from what the last refreshes left on this Mac

def test_the_screen_command_reads_files_only_and_spends_nothing(home, monkeypatch, capsys):
    """After a refresh, the window can open the grid again with no key and no fetcher:
    the Keychain and the fetcher are rigged to fail if they are touched."""
    got, api = read()
    spent_before = oddsapi.Cache().recall()

    def boom(*a, **k):
        raise AssertionError("the screen reached for the network or the key")

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", boom)
    monkeypatch.setattr(keystore, "get_key", boom)
    monkeypatch.setattr(oddsapi, "refresh", boom)
    monkeypatch.setattr(time, "time", lambda: NOW + 120)
    assert cli.main(["board", "--feed", "oddsapi", "--screen", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["command"] == "board" and out["screen"]["has_odds"] is True
    assert "rows" not in out, "no plays are found: only the grid is laid out"
    assert len(api.calls) == 1 and oddsapi.Cache().recall() == spent_before, "no credit was spent"
    g = grid_of(out["screen"])
    assert g["age"] == 120.0, "the age is worked out when the screen is opened, not when it was read"
    assert g["books"] and g["games"][0]["rows"][0]["cells"]["dk"]["age"] == 126.0


def test_the_screen_from_disk_is_the_screen_the_refresh_drew(home):
    got, _ = read()
    live = screen.from_refresh(got, BETTABLE)
    again = screen.from_history(oddshistory.history_folder(), BETTABLE, NOW)
    assert again["grids"] == live["grids"]
    assert again["leagues"] == live["leagues"] and again["markets"] == live["markets"]


def test_with_nothing_read_it_says_so_and_how_to_read(home, capsys):
    assert cli.main(["board", "--feed", "oddsapi", "--screen", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)["screen"]
    assert out["has_odds"] is False and out["grids"] == []
    assert "Press Live sportsbook odds" in out["message"]


def test_a_read_older_than_six_hours_is_not_drawn(home):
    read(payload=world(start=NOW + 40000))
    assert screen.SHOW_FOR == 6 * 3600
    fresh = screen.from_history(oddshistory.history_folder(), BETTABLE, NOW + 21599)
    old = screen.from_history(oddshistory.history_folder(), BETTABLE, NOW + 21601)
    assert fresh["has_odds"] is True
    assert old["has_odds"] is False and "more than six hours old" in old["message"]


def test_each_league_and_bet_type_keeps_its_own_read_time(home):
    """The moneyline was read at lunch and the totals at dinner: both are on the screen, each with its time."""
    clock = to.Clock()
    late = NOW + 30000          # a game that is still ahead at dinner
    read(markets=["h2h"], payload=only(world(late), "h2h"), clock=clock)
    clock.now = NOW + 4000
    payload = only(world(late), "totals")
    for b in payload[0]["bookmakers"]:
        for m in b["markets"]:
            m["last_update"] = to.iso(NOW + 3990)
    read(markets=["totals"], payload=payload, clock=clock)
    s = screen.from_history(oddshistory.history_folder(), BETTABLE, NOW + 4100)
    assert grid_of(s, market="h2h")["read_at"] == NOW
    assert grid_of(s, market="totals")["read_at"] == NOW + 4000
    assert grid_of(s, market="totals")["age"] == 100.0 and grid_of(s, market="h2h")["age"] == 4100.0
    assert {g["market"] for g in s["grids"]} == {"h2h", "totals"}


def test_a_newer_read_replaces_an_older_one_of_the_same_league_and_bet_type(home):
    clock = to.Clock()
    read(markets=["h2h"], payload=only(world(), "h2h"), clock=clock)
    clock.now = NOW + 600
    newer = only(world(), "h2h")
    newer[0]["bookmakers"][0]["markets"][0]["outcomes"][0]["price"] = 2.50
    read(markets=["h2h"], payload=newer, clock=clock)
    g = grid_of(screen.from_history(oddshistory.history_folder(), BETTABLE, NOW + 700))
    chiefs = next(r for r in g["games"][0]["rows"] if r["label"] == HOME)
    assert chiefs["cells"]["dk"]["decimal"] == 2.5 and g["read_at"] == NOW + 600


def test_a_game_that_has_started_since_the_read_is_dropped(home):
    read()
    start = NOW + 3600
    before = screen.from_history(oddshistory.history_folder(), BETTABLE, start - 1)
    after = screen.from_history(oddshistory.history_folder(), BETTABLE, start + 1)
    assert before["has_odds"] and grid_of(before)["games"]
    assert not after["has_odds"] or all(not g["games"] for g in after["grids"])
    assert after.get("under_way", 1) >= 1 or not after["has_odds"]


def test_books_are_named_as_the_read_named_them_and_old_lines_still_load(home):
    read()
    folder = oddshistory.history_folder()
    s = screen.from_history(folder, BETTABLE, NOW)
    assert {b["key"]: b["name"] for b in grid_of(s)["books"]} == {
        "dk": "DraftKings", "fd": "FanDuel", "mgm": "BetMGM", "pinnacle": "Pinnacle"}
    # A line written before names were kept has no "names": it is read, and the books are named from the table.
    for f in folder.glob("*.jsonl"):
        lines = [json.loads(x) for x in f.read_text().splitlines()]
        for line in lines:
            line.pop("names")
        f.write_text("\n".join(json.dumps(x) for x in lines) + "\n")
    old = screen.from_history(folder, BETTABLE, NOW)
    assert {b["key"]: b["name"] for b in grid_of(old)["books"]}["dk"] == "DraftKings"
    assert [b["key"] for b in grid_of(old)["books"]] == ["dk", "fd", "mgm", "pinnacle"]


def test_a_book_is_named_as_the_feed_titled_it_even_when_the_engine_has_never_heard_of_it(home):
    odd = full_book("betonlineag", ml=(1.9, 2.0))
    odd["title"] = "BetOnline.ag"
    payload = [to.event("g1", [full_book("draftkings", ml=(2.10, 1.80)), odd])]
    got, _ = read(markets=["h2h"], payload=only(payload, "h2h"))
    assert {b["key"]: b["name"] for b in grid_of(screen.from_refresh(got, BETTABLE))["books"]}["betonlineag"] == "BetOnline.ag"
    from_disk = screen.from_history(oddshistory.history_folder(), BETTABLE, NOW)
    assert {b["key"]: b["name"] for b in grid_of(from_disk)["books"]}["betonlineag"] == "BetOnline.ag", (
        "the title the read brought is kept with the read")


def test_clearing_the_key_takes_the_grid_with_it(home):
    read()
    assert screen.from_history(oddshistory.history_folder(), BETTABLE, NOW)["has_odds"]
    oddsapi.Cache().clear()
    assert screen.from_history(oddshistory.history_folder(), BETTABLE, NOW)["has_odds"] is False


def test_the_board_carries_the_same_screen_in_its_own_answer(home, monkeypatch, capsys):
    api, clock = to.FakeApi({"americanfootball_nfl": only(world(), "h2h", "totals")}), to.Clock()
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=clock))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: to.KEY)
    assert cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--market", "h2h", "--market", "totals",
                     "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert {g["market"] for g in out["screen"]["grids"]} == {"h2h", "totals"}
    assert len(api.calls) == 1, "the grid came out of the one request the board made"


def test_screen_takes_no_choices_and_needs_the_feed(home, capsys):
    for extra in (["--sport", "nfl"], ["--region", "us"], ["--market", "h2h"], ["--estimate"]):
        assert cli.main(["board", "--feed", "oddsapi", "--screen", "--json", *extra]) == 2
        assert "costs nothing" in json.loads(capsys.readouterr().out)["error"]
    assert cli.main(["board", "--screen", "--json"]) == 2
    assert "only work with --feed oddsapi" in json.loads(capsys.readouterr().out)["error"]


# ================================================================ 2. the row detail

def feed_rows(home_dir=None, **kw):
    got, _ = read()
    rows = []
    split = oddsapi.split_by_line(got.markets)
    common = dict(bankroll=1000.0, now=got.now, fill_model=FillModel(), latency_model=LatencyModel(),
                  bettable=BETTABLE, detail=True, names=got.book_names, **kw)
    rows += board.scan(split, oddsapi.books_table(), kinds=("arb", "ev"), **common)
    rows += board.scan(got.markets, oddsapi.books_table(), kinds=("middle",), **common)
    return got, board._rank(rows)


def test_a_plus_ev_rows_own_ev_is_its_own_line_in_the_ev_by_book_table(home):
    got, rows = feed_rows()
    evs = [r for r in rows if r.kind == "ev"]
    assert evs, "the world has +EV prices"
    for row in evs:
        d = row.detail
        [block] = d["ev_by_book"]
        mine = [x for x in block["rows"] if x["mine"]]
        assert len(mine) == 1 and mine[0]["book"] == row.legs[0]["book"]
        assert mine[0]["ev"] == pytest.approx(row.margin, abs=1e-12), "the row and its detail are one calculation"


def test_every_books_ev_is_the_engines_own_evaluate_against_the_fair_price_without_that_book(home):
    got, rows = feed_rows()
    row = next(r for r in rows if r.kind == "ev")
    split = oddsapi.split_by_line(got.markets)
    market = next(m for m in split if m.event_id == row.event and m.market_type == row.market
                  and row.legs[0]["outcome"] in m.outcomes())
    books = oddsapi.books_table()
    [block] = row.detail["ev_by_book"]
    assert block["rows"], "some book is listed"
    for x in block["rows"]:
        q = next(q for q in market.quotes if q.book == x["book"] and q.outcome.key == row.legs[0]["outcome"])
        fv = fair_without(market, books, x["book"])[row.legs[0]["outcome"]]
        res = evaluate(books[x["book"]].net_decimal(q.decimal), fv)
        assert x["ev"] == pytest.approx(res.ev) and x["ev_low"] == pytest.approx(res.ev_low)
        assert x["ev_high"] == pytest.approx(res.ev_high) and x["fair_prob"] == pytest.approx(fv.prob)
    evs = [x["ev"] for x in block["rows"]]
    assert evs == sorted(evs, reverse=True), "best first"


def test_each_books_bar_is_scaled_against_the_longest(home):
    _, rows = feed_rows()
    for row in rows:
        for block in row.detail["ev_by_book"]:
            scales = [x["scale"] for x in block["rows"]]
            assert scales and max(scales) == 1.0 and all(0.0 <= s <= 1.0 for s in scales)
            top = max(block["rows"], key=lambda x: abs(x["ev"]))
            assert top["scale"] == 1.0
            for x in block["rows"]:
                assert x["scale"] == pytest.approx(abs(x["ev"]) / abs(top["ev"]), abs=0.0006)


def test_ev_by_book_lists_only_books_you_can_bet_at(home):
    _, rows = feed_rows()
    for row in rows:
        for block in row.detail["ev_by_book"]:
            assert all(x["book"] in BETTABLE for x in block["rows"]), block["label"]


def test_the_fair_price_says_how_it_was_made(home):
    _, rows = feed_rows()
    row = next(r for r in rows if r.kind == "ev")
    fair = row.detail["fair"]
    assert fair["available"] is True and fair["anchored"] is True
    assert sum(s["prob"] for s in fair["sides"]) == pytest.approx(1.0, abs=1e-9)
    for s in fair["sides"]:
        assert s["low"] <= s["prob"] <= s["high"]
        assert s["american"] == screen.american(1.0 / s["prob"])
    assert sum(b["share"] for b in fair["blend"]) == pytest.approx(1.0, abs=0.01)
    assert fair["blend"][0]["name"] == "Pinnacle" and fair["blend"][0]["tier"] == "sharp"
    assert fair["devig"] == ["additive", "multiplicative", "power", "shin"]
    assert "margin taken out 4 ways" in fair["text"] and "Pinnacle counts for" in fair["text"]


def test_a_market_no_sharp_book_priced_says_its_fair_price_is_not_anchored(home):
    payload = [to.event("g1", [full_book("draftkings", ml=(2.10, 1.80)), full_book("fanduel", ml=(1.80, 2.05))])]
    got, _ = read(markets=["h2h"], payload=payload)
    rows = board.scan(oddsapi.split_by_line(got.markets), oddsapi.books_table(), now=got.now,
                      kinds=("arb",), bettable=BETTABLE, detail=True)
    [arb] = rows
    assert arb.detail["fair"]["anchored"] is False
    assert "not anchored" in arb.detail["fair"]["text"]


def test_the_table_has_every_book_quoting_both_sides_with_best_and_average(home):
    _, rows = feed_rows()
    row = next(r for r in rows if r.kind == "arb")
    t = row.detail["table"]
    assert [s["label"] for s in t["sides"]] == [HOME, AWAY]
    assert [r["book"] for r in t["rows"]] == ["dk", "fd", "mgm", "pinnacle"]
    assert [r["bettable"] for r in t["rows"]] == [True, True, True, False]
    top = [max(r["prices"][i]["decimal"] for r in t["rows"] if r["bettable"]) for i in (0, 1)]
    assert [b["decimal"] for b in t["best"]] == top
    assert t["best"][0]["books"] == ["DraftKings"] and t["best"][1]["books"] == ["FanDuel"]
    flagged = [(r["book"], i) for r in t["rows"] for i, p in enumerate(r["prices"]) if p and p.get("best")]
    assert flagged == [("dk", 0), ("fd", 1)]
    assert all("best" not in p for p in t["rows"][-1]["prices"]), "Pinnacle is never marked best"


def test_no_table_ever_calls_a_reference_books_price_the_best(home):
    """Pinnacle's +130 on the Over is the highest price in the market and it is not a bet."""
    _, rows = feed_rows()
    seen_outlier = False
    for row in rows:
        t = row.detail["table"]
        for i in range(len(t["sides"])):
            can = [r["prices"][i]["decimal"] for r in t["rows"] if r["bettable"] and r["prices"][i]]
            every = [r["prices"][i]["decimal"] for r in t["rows"] if r["prices"][i]]
            seen_outlier = seen_outlier or max(every) > max(can)
            assert t["best"][i]["decimal"] == max(can)
        for r in t["rows"]:
            assert all("best" not in p for p in r["prices"] if not r["bettable"] and p)
    assert seen_outlier, "the fixture has a reference price above every bet, or this proves nothing"


def test_the_average_price_is_the_average_of_the_books_chances(home):
    quotes = [Quote("dk", Outcome("Home"), 3.0, NOW - 5), Quote("dk", Outcome("Away"), 1.40, NOW - 5),
              Quote("fd", Outcome("Home"), 2.0, NOW - 5), Quote("fd", Outcome("Away"), 1.80, NOW - 5)]
    market = Market("g", "nfl", "h2h", quotes, NOW + 3600)
    t = detail.row_detail(market, oddsapi.books_table(), [{"book": "dk", "outcome": "Home"}], "ev",
                          bettable={"dk", "fd"}, now=NOW)["table"]
    # Chances 1/3 and 1/2 average to 5/12, which pays 2.4 (+140); a plain average of 3.0 and 2.0 would say +150.
    assert t["average"][0] == {"american": 140, "books": 2}


def test_a_middle_says_it_has_no_single_fair_price_and_shows_the_two_lines(home):
    _, rows = feed_rows()
    middles = [r for r in rows if r.kind == "middle"]
    assert middles, "the world has a 47.5 / 48.5 total"
    d = middles[0].detail
    assert d["fair"]["available"] is False and "two different lines" in d["fair"]["why"]
    assert d["ev_by_book"] == []
    assert [s["label"] for s in d["table"]["sides"]] == ["Over 47.5", "Under 48.5"]
    over = {r["book"] for r in d["table"]["rows"] if r["prices"][0]}
    under = {r["book"] for r in d["table"]["rows"] if r["prices"][1]}
    assert over == {"dk", "mgm", "pinnacle"} and under == {"fd"}


def test_detail_is_off_unless_asked_for_so_ask_and_the_old_callers_are_unchanged(home):
    got, _ = read()
    rows = board.scan(oddsapi.split_by_line(got.markets), oddsapi.books_table(), now=got.now,
                      bettable=BETTABLE)
    assert rows and all(r.detail is None for r in rows)
    assert all(r.as_dict()["detail"] is None for r in rows)


def test_the_demo_board_has_the_detail_too(capsys):
    assert cli.main(["board", "--json"]) == 0
    rows = json.loads(capsys.readouterr().out)["rows"]
    assert rows and all(r["detail"]["table"]["rows"] for r in rows)


# ================================================================ 3. outcomes and the order to place the bets

def pair(age_home=6, age_away=6, home_price=2.10, away_price=2.05, fill=True):
    quotes = [Quote("dk", Outcome("Home"), home_price, NOW - age_home), Quote("dk", Outcome("Away"), 1.70, NOW - age_home),
              Quote("fd", Outcome("Home"), 1.70, NOW - age_away), Quote("fd", Outcome("Away"), away_price, NOW - age_away)]
    market = Market("g", "nfl", "h2h", quotes, NOW + 3600)
    [row] = board.scan([market], oddsapi.books_table(), now=NOW, kinds=("arb",),
                       fill_model=FillModel() if fill else None)
    return row


def test_an_arbs_results_are_the_legs_own_figures_and_the_locked_profit_is_the_smaller(home):
    row = pair()
    assert [o["net"] for o in row.outcomes] == [leg["if_wins"] for leg in row.legs]
    assert min(o["net"] for o in row.outcomes) == row.profit
    assert [o["label"] for o in row.outcomes] == ["Home wins", "Away wins"]
    assert [o["legs"] for o in row.outcomes] == [[0], [1]]
    assert max(o["scale"] for o in row.outcomes) == 1.0 and all(0 <= o["scale"] <= 1 for o in row.outcomes)


def middle_row(**kw):
    quotes = [Quote("dk", Outcome("Over", 220.5), 1.95, NOW - 5), Quote("fd", Outcome("Under", 223.5), 1.95, NOW - 5)]
    market = Market("g", "nba", "totals", quotes, NOW + 3600)
    [row] = board.scan([market], oddsapi.books_table(), now=NOW, kinds=("middle",), detail=True, **kw)
    return row


def test_a_middles_three_results_are_the_plans_own_numbers(home):
    from overlay_engine.middles import find_middles

    row = middle_row()
    [plan] = find_middles(Market("g", "nba", "totals", [
        Quote("dk", Outcome("Over", 220.5), 1.95, NOW - 5), Quote("fd", Outcome("Under", 223.5), 1.95, NOW - 5)]),
        oddsapi.books_table(), total=1000.0, now=NOW)
    o = row.outcomes
    assert [x["label"] for x in o] == ["Only Over 220.5 wins", "Both win (the total lands between 220.5 and 223.5)",
                                       "Only Under 223.5 wins"]
    assert [x["net"] for x in o] == [round(plan.low_only_profit, 2), round(plan.middle_profit, 2),
                                     round(plan.high_only_profit, 2)]
    assert [x["legs"] for x in o] == [[0], [0, 1], [1]]
    assert o[1]["net"] > o[0]["net"] and o[1]["net"] > o[2]["net"], "landing in the window beats either single win"
    assert min(o[0]["net"], o[2]["net"]) == round(plan.one_side_profit, 2)


def test_the_less_likely_to_still_be_there_goes_first(home):
    row = pair(age_home=80, age_away=2)             # the Home price is old, the Away price is fresh
    assert [leg["order"] for leg in row.legs] == [1, 2]
    assert row.legs[0]["p_fill"] < row.legs[1]["p_fill"]
    flipped = pair(age_home=2, age_away=80)
    assert [leg["order"] for leg in flipped.legs] == [2, 1], "the same prices the other way round give the other order"
    assert flipped.legs[1]["p_fill"] < flipped.legs[0]["p_fill"]


def test_on_equal_chances_the_bigger_bet_goes_first(home):
    row = pair(age_home=6, age_away=6, home_price=2.10, away_price=2.05)
    big = max(range(2), key=lambda i: row.legs[i]["stake"])
    assert row.legs[big]["order"] == 1 and row.legs[1 - big]["order"] == 2
    assert row.legs[0]["p_fill"] == row.legs[1]["p_fill"]


def test_with_no_price_ages_the_bigger_bet_goes_first_and_the_rule_says_so(home):
    row = pair(fill=False)
    big = max(range(2), key=lambda i: row.legs[i]["stake"])
    assert row.legs[big]["order"] == 1
    assert row.order_rule == betorder.RULE_STAKE and "no price ages" in row.order_rule
    assert all(leg["p_fill"] is None for leg in row.legs)


def test_the_places_are_one_and_two_with_no_repeats_and_the_rule_is_one_sentence(home):
    for row in (pair(), pair(age_home=70), middle_row(fill_model=FillModel())):
        assert sorted(leg["order"] for leg in row.legs) == [1, 2]
        assert len(re.findall(r"[.!?](?:\s|$)", row.order_rule)) == 1, row.order_rule
        assert row.order_rule in (betorder.RULE_FILL, betorder.RULE_STAKE)


def test_a_middles_legs_are_numbered_by_the_same_rule(home):
    quotes = [Quote("dk", Outcome("Over", 220.5), 1.95, NOW - 85), Quote("fd", Outcome("Under", 223.5), 1.95, NOW - 1)]
    market = Market("g", "nba", "totals", quotes, NOW + 3600)
    [row] = board.scan([market], oddsapi.books_table(), now=NOW, kinds=("middle",), fill_model=FillModel())
    assert [leg["order"] for leg in row.legs] == [1, 2], "the stale Over goes first"
    quotes = [Quote("dk", Outcome("Over", 220.5), 1.95, NOW - 1), Quote("fd", Outcome("Under", 223.5), 1.95, NOW - 85)]
    [row] = board.scan([Market("g", "nba", "totals", quotes, NOW + 3600)], oddsapi.books_table(), now=NOW,
                       kinds=("middle",), fill_model=FillModel())
    assert [leg["order"] for leg in row.legs] == [2, 1]


def test_a_middles_legs_carry_the_age_and_the_chance_of_their_own_prices(home):
    """A middle used to read 0s old and 100% still there, which no price is."""
    quotes = [Quote("dk", Outcome("Over", 220.5), 1.95, NOW - 40), Quote("fd", Outcome("Under", 223.5), 1.95, NOW - 10)]
    market = Market("g", "nba", "totals", quotes, NOW + 3600)
    [row] = board.scan([market], oddsapi.books_table(), now=NOW, kinds=("middle",), fill_model=FillModel())
    assert [leg["age"] for leg in row.legs] == [40.0, 10.0] and row.age == 40.0
    fm = FillModel()
    assert row.p_fill == pytest.approx(fm.p_fill("dk", "totals", 40) * fm.p_fill("fd", "totals", 10))
    assert 0 < row.p_fill < 1
    # Without a fill model the ages are still the quotes' own, and no chance is invented.
    [bare] = board.scan([market], oddsapi.books_table(), now=NOW, kinds=("middle",))
    assert [leg["age"] for leg in bare.legs] == [40.0, 10.0] and bare.p_fill == 1.0
    assert row.realised == bare.realised, "the ranking of a middle is its window chance, as it was"


def test_a_single_plus_ev_bet_has_no_pair_to_order_or_compare(home):
    _, rows = feed_rows()
    ev = next(r for r in rows if r.kind == "ev")
    assert ev.outcomes == [] and ev.order_rule == "" and "order" not in ev.legs[0]


def test_live_pairs_place_the_thinner_side_first_and_show_what_each_team_winning_pays():
    k, p = tx._pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62}, k_size=300, p_size=10_000)
    [row] = [r for r in xvenue.price_pairs([(k, p)], now=tx.NOW) if r.profit > 0]
    thin = max(range(2), key=lambda i: row.legs[i]["contracts"] / row.legs[i]["on_offer"])
    assert row.legs[thin]["on_offer"] == 300 and row.legs[thin]["order"] == 1 and row.legs[1 - thin]["order"] == 2
    assert row.order_rule == betorder.RULE_THIN
    assert [o["net"] for o in row.outcomes] == [leg["if_wins"] for leg in row.legs] == [row.profit, row.profit]
    assert [o["label"] for o in row.outcomes] == [f"{leg['name']} wins" for leg in row.legs]
    # The other way round: the thin side is the Polymarket US book.
    k, p = tx._pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62}, k_size=10_000, p_size=300)
    [row] = [r for r in xvenue.price_pairs([(k, p)], now=tx.NOW) if r.profit > 0]
    assert row.legs[1]["on_offer"] == 300 and row.legs[1]["order"] == 1 and row.legs[0]["order"] == 2


def test_live_pairs_carry_the_order_through_the_json():
    k, p = tx._pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    [row] = [r for r in xvenue.price_pairs([(k, p)], now=tx.NOW) if r.profit > 0]
    d = row.as_dict()
    assert d["order_rule"] and len(d["outcomes"]) == 2 and {leg["order"] for leg in d["legs"]} == {1, 2}


def test_no_word_the_engine_writes_for_these_is_guaranteed_or_risk_free(home, capsys):
    got, rows = feed_rows()
    text = list(strings([r.as_dict() for r in rows])) + list(strings(screen.from_refresh(got, BETTABLE)))
    text += [betorder.RULE_FILL, betorder.RULE_STAKE, betorder.RULE_THIN, screen.NONE_YET, screen.TOO_OLD,
             detail.NO_FAIR, detail.NO_MIDDLE_FAIR]
    for t in text:
        low = t.lower()
        for word in BANNED:
            assert word not in low, (word, t)
