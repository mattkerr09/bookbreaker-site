"""A new person, before any key: what the first page says works (firstrun.py, and `key status`)."""

import json
import re
from pathlib import Path

from overlay_engine import cli, firstrun, keystore

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "ui" / "src" / "index.html").read_text()


def test_with_no_key_there_are_three_steps_and_the_key_comes_last():
    s = firstrun.start(False)
    assert s["title"] == "Start here" and len(s["steps"]) == 3
    assert [x["panel"] for x in s["steps"]] == ["welcome", "convert", "odds"]
    assert "No key needed." in s["steps"][0]["text"] and "No key needed." in s["steps"][1]["text"]


def test_once_a_key_is_saved_there_is_no_start_block():
    assert firstrun.start(True) is None


def test_the_key_steps_name_only_the_odds_api_and_the_keychain():
    text = firstrun.start(False)["steps"][2]["text"]
    assert "the-odds-api.com" in text and "Keychain" in text and "500 credits a month" in text
    assert set(re.findall(r"[a-z0-9-]+\.(?:com|net|org|io|bet)", text)) == {"the-odds-api.com"}


def test_the_questions_said_to_need_a_key_are_ones_the_ask_page_shows():
    for q in firstrun.NEEDS_KEY:
        assert f'data-ask="{q}"' in HTML.replace("&rsquo;", "’"), q


def test_the_words_keep_the_house_rules():
    words = json.dumps(firstrun.start(False), ensure_ascii=False).lower()
    for banned in ("—", "free bet", "guarantee", "risk-free", "either way"):
        assert banned not in words, banned


def test_key_status_carries_the_block_only_without_a_key(monkeypatch, capsys, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(keystore, "status", lambda name="oddsapi", **k: type("S", (), {
        "is_set": False, "as_dict": lambda self: {"set": False}, "describe": lambda self: "No key is set."})())
    assert cli.main(["key", "status", "--json"]) == 0
    assert json.loads(capsys.readouterr().out)["start"]["title"] == "Start here"
    monkeypatch.setattr(keystore, "status", lambda name="oddsapi", **k: type("S", (), {
        "is_set": True, "as_dict": lambda self: {"set": True}, "describe": lambda self: "A key is set."})())
    assert cli.main(["key", "status", "--json"]) == 0
    assert "start" not in json.loads(capsys.readouterr().out)


def test_every_step_opens_a_page_the_window_has():
    for step in firstrun.start(False)["steps"]:
        assert f'id="panel-{step["panel"]}"' in HTML, step["panel"]


def test_clearing_the_key_brings_the_start_card_back_without_hiding_the_cleared_message(monkeypatch, capsys, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(keystore, "clear_key", lambda name="oddsapi", **k: True)
    assert cli.main(["key", "clear", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["start"]["title"] == "Start here" and "removed" in out["text"]
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    clear = js[js.index("function showKeyclear("):js.index("function showKeyclear(") + 400]
    assert "drawStart(out.start || null);" in clear and 'run("keystatus")' not in clear
