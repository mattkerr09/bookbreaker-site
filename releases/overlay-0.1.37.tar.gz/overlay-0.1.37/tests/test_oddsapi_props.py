"""Player props on live sportsbook odds: an opt-in group that costs far more, so
its cost is said before the press, to the credit, by the documented rule.

The rule (https://the-odds-api.com/liveapi/guides/v4/, "GET event odds", read
2026-10-12; docs/odds-api-player-props.md): a prop is read one game at a time,
and a request costs [unique markets returned] x [regions specified]. So a
refresh with props costs, over the main odds, games x markets x regions per
league. The estimate counts markets asked, which is the most a request can cost.

The answers here are written by hand from the documented shape
(tests/fixtures/oddsapi/): a list of games, and one game's odds with
`description` carrying the player and `last_update` on the market. The real API
is never called.
"""

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from overlay_engine import board, cli, keystore, oddsapi
from overlay_engine.arb import find_arbs
from overlay_engine.models import Market, Outcome, Quote
from overlay_engine.oddsapi import (
    DEFAULT_PROPS,
    OddsApiError,
    PROP_MARKETS,
    estimate,
    parse_prop_event,
    props_plan,
    refresh,
)
from overlay_engine.restfeed import parse_time

FIX = Path(__file__).parent / "fixtures" / "oddsapi"
NOW = parse_time("2026-10-18T16:00:00Z")
KEY = "0123456789abcdef0123456789abcdef"          # made up; not a real key
ASKED = {"player_pass_yds", "player_rush_yds"}


def load(name):
    return json.loads((FIX / name).read_text())


def props(*keys, games=None, regions=None):
    return props_plan(list(keys) or None, regions, games)


def est(*sports, p=None, regions=("us", "eu")):
    return estimate(list(sports) or ["nfl"], list(regions), None, props=p)


class Clock:
    def __init__(self, now=NOW):
        self.now = now

    def __call__(self):
        return self.now


class PropsApi:
    """The Odds API for the three paths a props refresh uses. The credits header
    follows the documented rules: the bulk endpoint charges markets x regions
    (nothing when empty), the games list is free, and a game's odds charge the
    unique markets that CAME BACK x regions."""

    def __init__(self, odds=None, events=None, remaining=500, charge=None, reject=()):
        self.events = load("events_nfl.json") if events is None else events
        self.odds = {"evt-kc-buf": load("event_odds_props.json")} if odds is None else odds
        self.remaining, self.used = remaining, 500 - remaining
        self.charge, self.reject = charge, set(reject)
        self.calls = []

    def paths(self):
        return [c[0] for c in self.calls]

    def __call__(self, path, params):
        self.calls.append((path, dict(params)))
        parts = path.strip("/").split("/")
        regions = len(params.get("regions", "x").split(","))
        if parts[-1] == "events":
            payload, cost = self.events, 0
        elif parts[-1] == "odds" and "events" not in parts:
            payload = [{"id": "evt-kc-buf", "sport_key": "americanfootball_nfl",
                        "commence_time": "2026-10-18T17:00:00Z", "home_team": "Kansas City Chiefs",
                        "away_team": "Buffalo Bills", "bookmakers": [
                            {"key": "draftkings", "title": "DraftKings", "last_update": "2026-10-18T15:59:50Z",
                             "markets": [{"key": "h2h", "last_update": "2026-10-18T15:59:50Z", "outcomes": [
                                 {"name": "Kansas City Chiefs", "price": 1.50},
                                 {"name": "Buffalo Bills", "price": 2.70}]}]}]}]
            cost = len(params["markets"].split(",")) * regions
        else:
            event_id = parts[-2]
            if event_id in self.reject:
                raise oddsapi.explain(404, '{"error_code":"EVENT_NOT_FOUND"}', {})
            payload = self.odds.get(event_id) or {"id": event_id, "bookmakers": [],
                                                  "commence_time": "2026-10-19T00:00:00Z"}
            asked = set(params["markets"].split(","))
            back = {m["key"] for b in payload.get("bookmakers", []) for m in b["markets"]} & asked
            cost = len(back) * regions
        if self.charge is not None and parts[-1] == "odds" and "events" in parts:
            cost = self.charge
        self.remaining -= cost
        self.used += cost
        return payload, {"x-requests-remaining": str(self.remaining),
                         "x-requests-used": str(self.used), "x-requests-last": str(cost)}


@pytest.fixture
def home(monkeypatch, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def run(p=None, api=None, **kw):
    api = api or PropsApi()
    got = refresh(est("nfl", p=p or props()), KEY, clock=kw.pop("clock", Clock()), fetcher=api, **kw)
    return got, api


# ------------------------------------------------------------ the cost, said before the press

def test_props_are_off_unless_asked_for_and_then_the_estimate_is_the_old_one():
    off = estimate(["nfl"], ["us", "eu"], None)
    assert off.props is None and off.props_total == 0
    assert off.total == off.main_total == 2
    assert off.as_dict()["props"] is None and off.as_dict()["credits"] == 2
    assert "player prop" not in off.sentence().lower()
    assert oddsapi.choices(off)["props"]["on"] is False


def test_the_props_cost_is_games_x_markets_x_regions_for_every_league():
    """Every combination, against the sum written out the long way."""
    for sports in (["nfl"], ["nfl", "nba"], ["nfl", "nba", "mlb", "nhl"]):
        for games in (1, 3, 10):
            for regions in (["us"], ["us", "us2"], ["us", "us2", "eu", "us_ex"]):
                got = estimate(sports, ["us"], None, props=props_plan(None, regions, games))
                long_way = 0
                for alias in sports:
                    for _ in range(games):                       # one request per game
                        long_way += len(DEFAULT_PROPS[alias]) * len(regions)
                assert got.props_total == long_way
                assert got.total == got.main_total + long_way
                assert got.as_dict()["credits"] == got.total
                assert got.as_dict()["props"]["credits"] == long_way


def test_the_estimate_counts_every_game_not_one_request_per_league():
    """The bulk endpoint charges markets x regions per LEAGUE. Props are one
    request per GAME, so counting them that way undercounts by the number of
    games. nfl (2 of the picked markets) + nba (1) at 3 games and 2 regions:
    nfl 3x2x2 = 12, nba 3x1x2 = 6."""
    got = estimate(["nfl", "nba"], ["us"], None, props=props_plan(
        ["player_pass_yds", "player_rush_yds", "player_points"], ["us", "us2"], 3))
    assert got.props_total == 18
    per_league_rule = len(got.leagues) * 2 * 3        # leagues x regions x markets
    assert got.props_total > per_league_rule, "props were priced like the bulk endpoint"
    assert got.props_by_league() == {"nfl": 12, "nba": 6}
    assert got.props_games == 6 and got.props_game_markets == 9
    assert got.total == got.main_total + 18 == 20


def test_the_sentence_says_how_many_games_and_markets_it_counts_and_the_total():
    got = estimate(["nfl"], ["us", "eu"], None, props=props_plan(None, None, 3))
    text = got.sentence()
    assert "up to 11 of your Odds API credits: 2 for the main odds and 9 for player props" in text
    assert "3 games and 9 game-markets counted" in text
    assert "Passing yards, Rushing yards, Receiving yards" in text
    assert "1 region (us)" in text
    assert "guarantee" not in text.lower() and "risk-free" not in text.lower()
    block = got.as_dict()["props"]
    assert (block["games"], block["game_markets"], block["games_per_league"]) == (3, 9, 3)
    assert block["rule"] == oddsapi.PROPS_COST_RULE


def test_the_props_rule_is_held_verbatim():
    assert "cost = [number of unique markets returned] x [number of regions specified]" in oddsapi.PROPS_COST_RULE
    assert oddsapi.PROPS_COST_RULE_SOURCE.startswith("https://the-odds-api.com/liveapi/guides/v4/")


def test_a_prop_the_league_does_not_offer_is_never_asked_of_it(home):
    got = estimate(["nfl", "nba"], ["us"], None, props=props_plan(["player_pass_yds"], None, 2))
    assert [lg.alias for lg, _ in got.prop_plan()] == ["nfl"]
    assert got.props_total == 2 * 1 * 1
    with pytest.raises(OddsApiError, match="None of the player props"):
        estimate(["nba"], ["us"], None, props=props_plan(["player_pass_yds"], None, 2))


def test_the_choices_are_checked():
    for bad in (0, 11, -1, 2.5, True):
        with pytest.raises(OddsApiError):
            props_plan(None, None, bad)
    with pytest.raises(OddsApiError):
        props_plan(["player_anytime_td"], None, 3)          # not a two-way over/under
    with pytest.raises(OddsApiError):
        props_plan(["player_pass_yds_alternate"], None, 3)  # milestone lines are left out


def test_every_prop_market_is_a_documented_over_under_key_and_has_a_default():
    assert set(DEFAULT_PROPS) == set(PROP_MARKETS)
    for alias, keys in DEFAULT_PROPS.items():
        assert keys and set(keys) <= set(PROP_MARKETS[alias])
    for table in PROP_MARKETS.values():
        for key in table:
            assert key.startswith(("player_", "pitcher_", "batter_"))
            assert not key.endswith("_alternate") and "anytime" not in key and "first" not in key


def test_the_main_market_pickers_and_their_cost_are_untouched_by_props():
    """Battery row R10 reads these: the estimate for the main endpoint is
    leagues x regions x markets, and the markets offered are still the three."""
    for p in (None, props()):
        got = estimate(["nfl", "nba"], ["us", "eu"], ["h2h", "totals"], props=p)
        assert got.main_total == 2 * 2 * 2
        assert got.as_dict()["main_credits"] == 8
        c = oddsapi.choices(got)
        assert [m["key"] for m in c["markets"]] == ["h2h", "spreads", "totals"]
    assert estimate(["nfl"], None, None).as_dict()["credits"] == 2


# ------------------------------------------------------------ a recorded answer, parsed

def parsed():
    return parse_prop_event(load("event_odds_props.json"), "americanfootball_nfl", NOW, ASKED)


def test_one_market_per_game_market_player_and_line():
    markets, skipped = parsed()
    keyed = sorted((m.market_type, m.quotes[0].outcome.name.rsplit(" ", 1)[0], m.quotes[0].outcome.line)
                   for m in markets)
    assert keyed == [("player_pass_yds", "Josh Allen", 249.5),
                     ("player_pass_yds", "Patrick Mahomes", 274.5),
                     ("player_pass_yds", "Patrick Mahomes", 279.5),
                     ("player_rush_yds", "Josh Allen", 24.5),
                     ("player_rush_yds", "Patrick Mahomes", 24.5)]
    assert skipped == 1, "Josh Allen's BetMGM over has no line"
    for m in markets:
        assert len({q.outcome.name.rsplit(" ", 1)[0] for q in m.quotes}) == 1, "two players in one market"
        assert len({q.outcome.line for q in m.quotes}) == 1, "two lines in one market"
        assert m.event_id == "evt-kc-buf" and m.starts_at == parse_time("2026-10-18T17:00:00Z")


def test_a_pass_yards_market_holds_both_books_and_both_sides():
    markets, _ = parsed()
    m = next(m for m in markets if m.market_type == "player_pass_yds" and m.quotes[0].outcome.line == 274.5)
    got = {(q.book, q.outcome.name): q.decimal for q in m.quotes}  # engine keys: dk, fd
    assert got == {("dk", "Patrick Mahomes Over"): 2.10, ("dk", "Patrick Mahomes Under"): 1.72,
                   ("fd", "Patrick Mahomes Over"): 1.80, ("fd", "Patrick Mahomes Under"): 2.02}
    assert m.outcomes() == ["Patrick Mahomes Over@274.5", "Patrick Mahomes Under@274.5"]


def test_a_price_is_dated_by_the_markets_own_last_update():
    markets, _ = parsed()
    m = next(m for m in markets if m.market_type == "player_pass_yds" and m.quotes[0].outcome.line == 274.5)
    seen = {q.book: q.seen_at for q in m.quotes}
    assert seen["dk"] == parse_time("2026-10-18T15:59:50Z")
    assert seen["fd"] == parse_time("2026-10-18T15:59:40Z")


def test_a_market_not_asked_for_is_ignored_and_a_yes_no_outcome_is_not_a_pair():
    event = load("event_odds_props.json")
    markets, skipped = parse_prop_event(event, "x", NOW, {"player_anytime_td"})
    assert markets == [] and skipped == 1, "Yes/No is not an over/under, whatever was asked"
    # Even with a line on it (some books print one), a Yes is not an Over.
    event["bookmakers"][0]["markets"][2]["outcomes"][0]["point"] = 0.5
    markets, skipped = parse_prop_event(event, "x", NOW, {"player_anytime_td"})
    assert markets == [] and skipped == 1
    markets, _ = parsed()
    assert "player_anytime_td" not in {m.market_type for m in markets}


def test_spelling_that_differs_only_in_case_or_spacing_is_one_player_and_a_suffix_is_not():
    event = load("event_odds_props.json")
    extra = lambda who: {"key": "caesars", "title": "Caesars", "markets": [{
        "key": "player_pass_yds", "last_update": "2026-10-18T15:59:50Z", "outcomes": [
            {"name": "Under", "description": who, "price": 2.20, "point": 274.5}]}]}
    event["bookmakers"].append(extra("patrick  MAHOMES"))
    markets, _ = parse_prop_event(event, "x", NOW, ASKED)
    m = next(m for m in markets if m.market_type == "player_pass_yds" and m.quotes[0].outcome.line == 274.5)
    assert len(m.quotes) == 5 and len(m.outcomes()) == 2, "one player, spelled two ways, pooled"
    event["bookmakers"][-1] = extra("Patrick Mahomes Jr.")
    markets, _ = parse_prop_event(event, "x", NOW, ASKED)
    assert len([m for m in markets if m.market_type == "player_pass_yds"]) == 4, "a different name is a different player"


def test_a_malformed_answer_is_refused_whole_not_half_read():
    from overlay_engine.feed import FeedError
    with pytest.raises(FeedError):
        parse_prop_event([], "x", NOW, ASKED)
    with pytest.raises(FeedError):
        parse_prop_event({"bookmakers": []}, "x", NOW, ASKED)
    bad = load("event_odds_props.json")
    bad["bookmakers"][0]["markets"][0]["outcomes"][0]["price"] = -110      # American, not decimal
    with pytest.raises(FeedError, match="not decimal"):
        parse_prop_event(bad, "x", NOW, ASKED)


# ------------------------------------------------------------ only the same player, market and line meet

def scan(markets, kinds=("arb",), books=None):
    return board.scan(markets, books or oddsapi.books_table(), now=NOW, kinds=kinds,
                      bettable=set(oddsapi.BETTABLE))


def test_the_only_arb_is_one_players_over_against_his_under_at_one_line():
    markets, _ = parsed()
    rows = scan(markets)
    assert len(rows) == 1
    arb = rows[0]
    assert arb.market == "player_pass_yds"
    assert {leg["book"] for leg in arb.legs} == {"dk", "fd"}
    assert sorted(leg["outcome"] for leg in arb.legs) == ["Patrick Mahomes Over@274.5",
                                                          "Patrick Mahomes Under@274.5"]
    assert arb.margin == pytest.approx(1 - (1 / 2.10 + 1 / 2.02), abs=1e-3)
    assert arb.profit > 0


def test_one_players_over_never_meets_another_players_under():
    """Mahomes over 24.5 rushing at 2.30 and Allen under 24.5 at 2.30 are an arb
    only if the two men are one player. They are in the same game, market and
    line; only the player keeps them apart."""
    markets, _ = parsed()
    assert [r for r in scan(markets) if r.market == "player_rush_yds"] == []

    # The control: the trap is real. Pool the two men's prices under bare Over/Under
    # and the engine finds the arb, so the empty result above is the grouping's doing.
    pooled = Market("evt-kc-buf", "x", "player_rush_yds", [], NOW + 3600)
    for m in markets:
        if m.market_type == "player_rush_yds":
            for q in m.quotes:
                side = q.outcome.name.rsplit(" ", 1)[1]
                pooled.quotes.append(Quote(q.book, Outcome(side, q.outcome.line), q.decimal, q.seen_at))
    assert find_arbs(pooled, oddsapi.books_table(), NOW), "the fixture no longer sets the trap"


def test_a_different_line_is_a_different_bet_and_never_pairs():
    """Mahomes over 279.5 at BetMGM 2.40 against his under 274.5 at FanDuel 2.02
    would be an arb of 2.4 and 2.02 if the line did not matter."""
    markets, _ = parsed()
    for row in scan(markets):
        assert len({leg["outcome"].split("@")[1] for leg in row.legs}) == 1
    lonely = [m for m in markets if m.quotes[0].outcome.line == 279.5]
    assert len(lonely) == 1 and {q.book for q in lonely[0].quotes} == {"mgm"}
    assert scan(lonely) == []


def test_different_players_in_one_market_key_do_not_share_a_fair_price():
    """+EV is priced inside one player's market too. Pinnacle prices Mahomes 274.5
    at even money; DraftKings' over at 2.10 is the +EV bet, and Josh Allen's
    markets, with no sharp price, produce none."""
    event = load("event_odds_props.json")
    event["bookmakers"].append({"key": "pinnacle", "title": "Pinnacle", "markets": [{
        "key": "player_pass_yds", "last_update": "2026-10-18T15:59:55Z", "outcomes": [
            {"name": "Over", "description": "Patrick Mahomes", "price": 1.95, "point": 274.5},
            {"name": "Under", "description": "Patrick Mahomes", "price": 1.95, "point": 274.5}]}]})
    markets, _ = parse_prop_event(event, "x", NOW, ASKED)
    rows = scan(markets, kinds=("ev", "arb"))
    ev = [r for r in rows if r.kind == "ev"]
    assert ev, "a prop priced by a sharp book should be able to be +EV"
    assert all("Patrick Mahomes" in r.legs[0]["outcome"] and r.legs[0]["book"] in ("dk", "fd") for r in ev)
    assert all(leg["book"] != "pinnacle" for r in rows for leg in r.legs)


# ------------------------------------------------------------ one refresh

def test_the_soonest_upcoming_games_are_read_one_request_each_and_nothing_else(home):
    got, api = run(props(games=3))
    paths = api.paths()
    assert paths[0] == "/v4/sports/americanfootball_nfl/odds"
    assert paths[1] == "/v4/sports/americanfootball_nfl/events"
    assert paths[2:] == [f"/v4/sports/americanfootball_nfl/events/{e}/odds"
                         for e in ("evt-kc-buf", "evt-late", "evt-mnf")], (
        "the game under way is skipped, the rest are soonest first, three of them")
    p = api.calls[2][1]
    assert p["markets"] == "player_pass_yds,player_rush_yds,player_reception_yds"
    assert p["regions"] == "us" and p["oddsFormat"] == "decimal"
    assert "apiKey" in p
    assert len(api.calls) == 5


def test_the_games_list_is_asked_without_markets_or_regions(home):
    _, api = run()
    listing = next(c for c in api.calls if c[0].endswith("/events"))
    assert set(listing[1]) == {"apiKey", "dateFormat"}


def test_what_it_really_cost_is_the_header_and_never_more_than_the_estimate(home):
    got, api = run(props(games=3))
    e = got.estimate
    assert e.total == 2 * 1 + 9 == 11
    # Only one game came back with prices, and only two of the three asked markets did.
    assert got.prop_reads[0].credits == 2
    assert got.spent == 2 + 2, "the main read (1 market x 2 regions) plus the props that came back"
    assert got.spent < e.total, "markets that came back empty are not charged, so the estimate is an upper bound"
    assert got.prop_reads[0].games == 3 and got.prop_reads[0].bound == 9


def test_props_are_kept_apart_from_the_main_markets_and_the_line_history(home):
    got, _ = run()
    assert {m.market_type for m in got.markets} == {"h2h"}
    assert {m.market_type for m in got.props} == {"player_pass_yds", "player_rush_yds"}
    from overlay_engine import oddshistory
    recorded = {mk["type"] for s in oddshistory.snapshots(home / "oddsapi" / "history") for mk in s["markets"]}
    assert recorded == {"h2h"}, "a prop in the line history would be read as a main market"


def test_a_second_press_inside_a_minute_spends_nothing_on_props_either(home):
    clock, api = Clock(), PropsApi()
    refresh(est("nfl", p=props()), KEY, clock=clock, fetcher=api)
    calls = len(api.calls)
    clock.now = NOW + 30
    again = refresh(est("nfl", p=props()), KEY, clock=clock, fetcher=api)
    assert len(api.calls) == calls, "a cached answer was fetched again"
    assert again.spent == 0 and again.all_cached
    assert len(again.props) == 5
    assert all(q.age(clock.now) >= 30 for m in again.props for q in m.quotes), "aged from the first fetch"


def test_the_cache_is_per_markets_and_regions_for_props(home):
    clock, api = Clock(), PropsApi()
    refresh(est("nfl", p=props()), KEY, clock=clock, fetcher=api)
    n = len(api.calls)
    refresh(est("nfl", p=props("player_pass_yds")), KEY, clock=clock, fetcher=api)
    assert len(api.calls) > n, "a different choice is a different cost, not a cache hit"


def test_the_key_is_in_no_cache_file(home):
    run()
    for f in home.rglob("*"):
        if f.is_file():
            assert KEY not in f.read_text(errors="ignore"), f


def test_credits_too_few_for_the_next_game_stops_before_asking(home):
    api = PropsApi(remaining=3)         # the main read leaves 2; a game here needs up to 3
    got, _ = run(props(games=3), api=api)
    assert [p for p in api.paths() if "/events/" in p] == []
    assert any("Player props stopped" in e and "you have" in e for e in got.errors)
    assert got.props == []


def test_a_request_charged_more_than_the_rule_allows_stops_the_run(home):
    """If the API ever bills a game above markets x regions, the documented rule
    is wrong or has moved. The first such charge is reported and nothing more is
    spent at that rate."""
    api = PropsApi(charge=7)
    got, _ = run(props(games=3), api=api)
    assert len([p for p in api.paths() if "/events/" in p]) == 1
    assert any("charged 7 credits" in e and "allows 3" in e for e in got.errors)


def test_a_game_the_api_rejects_is_skipped_and_the_next_is_read(home):
    api = PropsApi(reject={"evt-kc-buf"})
    got, _ = run(props(games=3), api=api)
    assert len([p for p in api.paths() if "/events/" in p]) == 3
    assert got.prop_reads[0].games == 2
    assert any("did not understand" in e for e in got.errors)


def test_a_failure_that_is_not_about_one_game_ends_the_props_and_keeps_the_board(home):
    class Down(PropsApi):
        def __call__(self, path, params):
            if "/events/" in path:
                self.calls.append((path, params))
                raise oddsapi.explain(401, '{"error_code":"INVALID_KEY"}', {})
            return super().__call__(path, params)
    got, api = run(props(games=3), api=Down())
    assert len([p for p in api.paths() if "/events/" in p]) == 1
    assert got.markets and any("did not accept your key" in e for e in got.errors)


def test_props_off_makes_no_event_calls_at_all(home):
    api = PropsApi()
    refresh(estimate(["nfl"], ["us", "eu"], None), KEY, clock=Clock(), fetcher=api)
    assert api.paths() == ["/v4/sports/americanfootball_nfl/odds"]


# ------------------------------------------------------------ the board

@pytest.fixture
def board_cli(monkeypatch, home):
    api, clock = PropsApi(), Clock()
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=clock))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: KEY)
    return SimpleNamespace(api=api, clock=clock)


def board_json(capsys, *extra):
    code = cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--json", *extra])
    out = capsys.readouterr()
    assert code == 0, out.err + out.out
    return json.loads(out.out), out


def test_the_estimate_with_props_fetches_nothing_and_says_the_split(board_cli, capsys):
    got, _ = board_json(capsys, "--estimate", "--props", "--prop-games", "2")
    assert board_cli.api.calls == []
    e = got["estimate"]
    assert e["credits"] == e["main_credits"] + e["props"]["credits"] == 2 + 6
    assert e["props"]["games"] == 2 and e["props"]["game_markets"] == 6
    assert got["choices"]["props"]["on"] is True and got["choices"]["props"]["games"] == 2


def test_the_board_shows_a_prop_arb_with_the_player_and_the_cost(board_cli, capsys):
    got, out = board_json(capsys, "--props")
    arbs = [r for r in got["rows"] if r["kind"] == "arb" and r["market"] == "player_pass_yds"]
    assert len(arbs) == 1
    arb = arbs[0]
    assert arb["market_label"] == "Passing yards" and arb["prop"] is True
    assert arb["event"] == "Buffalo Bills at Kansas City Chiefs" and arb["league"] == "NFL"
    assert {leg["book_name"] for leg in arb["legs"]} == {"DraftKings", "FanDuel"}
    assert {leg["outcome"] for leg in arb["legs"]} == {"Patrick Mahomes Over@274.5", "Patrick Mahomes Under@274.5"}
    assert got["markets_scanned"] == 1 + 5
    p = got["odds"]["props"]
    assert p["games"] == 3 and p["markets_priced"] == 5 and p["skipped"] == 1
    assert p["estimate"] == 9 and p["spent"] == 2
    cost = got["odds"]["cost"]
    assert cost["estimate"] == 11 and cost["spent"] == 4
    assert "player props from 3 games" in got["source"]
    assert any("No Pinnacle or exchange price was on any player prop" in n for n in got["odds"]["notes"])
    assert KEY not in out.out + out.err


def test_a_prop_row_is_never_called_guaranteed(board_cli, capsys):
    code = cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--props"])
    out = capsys.readouterr().out
    assert code == 0
    assert "Patrick Mahomes" in out and "locked if both bets stand" in out
    low = out.lower()
    assert "guarantee" not in low and "risk-free" not in low and "either way" not in low


def test_the_cost_with_props_is_on_screen_before_the_first_request(monkeypatch, home, capsys):
    api, seen = PropsApi(), []

    def spy(path, params):
        seen.append(capsys.readouterr().out)
        return api(path, params)

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: spy)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=Clock()))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: KEY)
    assert cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--props"]) == 0
    assert "up to 11 of your Odds API credits" in seen[0] and "player props" in seen[0]
    assert "3 games and 9 game-markets counted" in seen[0]


def test_props_never_run_without_the_switch(board_cli, capsys):
    got, _ = board_json(capsys)
    assert board_cli.api.paths() == ["/v4/sports/americanfootball_nfl/odds"]
    assert got["odds"]["props"] is None and got["markets_scanned"] == 1


def test_a_prop_choice_without_the_switch_is_refused_not_quietly_ignored(board_cli, capsys):
    for extra in (["--prop", "player_pass_yds"], ["--prop-games", "5"], ["--prop-region", "us"]):
        code = cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--json", *extra])
        out = json.loads(capsys.readouterr().out)
        assert code == 2 and "add --props" in out["error"], extra
    assert board_cli.api.calls == []


def test_prop_choices_mean_nothing_without_the_feed(board_cli, capsys):
    code = cli.main(["board", "--props", "--json"])
    assert code == 2
    assert "only work with --feed oddsapi" in json.loads(capsys.readouterr().out)["error"]


def test_a_bad_games_number_is_a_sentence(board_cli, capsys):
    code = cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--props", "--prop-games", "99", "--json"])
    assert code == 2
    assert "from 1 to 10" in json.loads(capsys.readouterr().out)["error"]
    assert board_cli.api.calls == []
