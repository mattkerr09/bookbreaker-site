"""The words the deposit plan hands the window, written once in the engine.

The window prints the engine's sentences and does no arithmetic on its figures, so the
three totals, the two list titles and the notes under them, a staged offer's sentence,
an ending offer's, a passed-over book's and the freshness line all have to arrive
finished. These hold what is in them, and that no two kinds of number are ever one.
"""

import datetime as dt
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine import deposit  # noqa: E402
from test_deposit import BANNED, TODAY, _plan, _row, _strings  # noqa: E402


def test_the_totals_come_with_their_own_sentence_one_per_kind_and_none_is_a_sum(tmp_path):
    out = _plan(tmp_path, 100_000)
    t, words = out["totals"], out["totals_text"]
    assert set(words) == {"deposit", "locked", "expected"}
    assert deposit.money(t["locked"]) in words["locked"] and deposit.LOCKED_CONDITION in words["locked"]
    assert deposit.money(t["expected"]) in words["expected"] and "on average" in words["expected"]
    assert not re.search(r"\blocked\b", words["expected"]), "an expectation is never described as locked"
    assert not re.search(r"\bexpected\b", words["locked"])
    assert deposit.money(t["locked"] + t["expected"]) not in " ".join(words.values()), "the two are never added"
    assert deposit.money(t["deposit"]) in words["deposit"] and deposit.money(out["bankroll"]) in words["deposit"]


def test_the_two_lists_are_titled_once_and_the_cli_prints_the_same_titles(tmp_path):
    out = _plan(tmp_path, 100_000)
    assert set(out["labels"]) == {"locked", "expected"}
    text = deposit.describe(out)
    for kind in ("locked", "expected"):
        assert out["labels"][kind]["title"] + ":" in text and out["labels"][kind]["note"] in text
        assert out["totals_text"][kind] in text
    assert "never added to a locked amount" in out["labels"]["expected"]["note"]
    assert out["labels"]["locked"]["note"] == f"Locked means kept {deposit.LOCKED_CONDITION}."


def test_a_staged_offer_an_ending_offer_and_a_passed_over_book_each_say_so_in_a_sentence(tmp_path):
    ends = TODAY + dt.timedelta(days=3)
    rows = [_row("dk", bonus="150", qualifying_stake="5", installments="3", expires_days="3", ends=str(ends)),
            _row("fd", bonus="250", qualifying_stake="25", installments="1"),
            _row("mgm", bonus="100", qualifying_stake="400", installments="1")]
    out = _plan(tmp_path, 800, rows=rows)
    dk = next(i for i in out["fund"] if i["book"] == "dk")
    assert dk["staged_note"].startswith("Spread over 3 installments.") and "you may need less" in dk["staged_note"]
    assert dk["ends_note"] == f"Ends {ends} (3 days), by its source."
    fd = next(i for i in out["fund"] if i["book"] == "fd")
    assert fd["staged_note"] == "" and fd["ends_note"] == ""
    mgm = next(i for i in out["left"] if i["book"] == "mgm")
    assert mgm["left_text"] == f"Needs {deposit.money(mgm['needs'])}, {deposit.money(mgm['short_by'])} more than was left."
    assert out["freshness"].startswith("Offers change monthly (rows older than")


def test_the_books_you_have_are_echoed_as_keys_and_move_out_of_the_plan(tmp_path):
    out = _plan(tmp_path, 5_000, have="DraftKings, fd")
    assert out["have"] == ["dk", "fd"]
    assert {"dk", "fd"}.isdisjoint({i["book"] for i in out["fund"] + out["left"]})
    assert _plan(tmp_path, 5_000)["have"] == []


def test_every_sentence_the_plan_adds_for_the_window_keeps_to_the_rules(tmp_path):
    for out in (_plan(tmp_path, 100_000), _plan(tmp_path, 300), deposit.plan("TX", 1000, today=TODAY)):
        for s in _strings(out):
            low = s.lower()
            for banned in BANNED:
                assert not re.search(banned, low), (banned, s)
            assert "free bet" not in low, s
