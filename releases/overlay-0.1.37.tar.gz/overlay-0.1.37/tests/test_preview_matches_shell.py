"""The browser preview answers the window the way the shell does.

The shell reads the engine's JSON whatever its exit status (ui/src-tauri/src/main.rs engine_answer), so a refusal
such as "no player props read yet" (exit 2, with JSON) is drawn as the empty state. The preview used to turn any
non-zero exit into a 500, so the same tab showed "could not run that" in the preview and the recorded hero video
would have shown an error the app never shows.
"""

import importlib.util
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _preview():
    os.environ["OVERLAY_PREVIEW_ENGINE"] = "source"
    spec = importlib.util.spec_from_file_location("preview_live", ROOT / "scripts" / "preview_live.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_a_refusal_with_json_reaches_the_window_like_the_shell():
    got = _preview().engine_answer('{"command": "parlays", "reason": "not_read", "error": "No player props"}')
    assert got == {"command": "parlays", "reason": "not_read", "error": "No player props"}


def test_output_that_is_not_json_is_still_an_error():
    assert _preview().engine_answer("usage: overlay ...") is None


def test_the_shell_still_reads_json_before_the_exit_status():
    rust = (ROOT / "ui" / "src-tauri" / "src" / "main.rs").read_text()
    body = rust[rust.index("fn engine_answer("):]
    assert "serde_json::from_str::<serde_json::Value>(&stdout)" in body[:400] and "status" not in body[:400]
