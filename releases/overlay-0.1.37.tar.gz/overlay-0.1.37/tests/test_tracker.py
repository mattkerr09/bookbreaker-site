"""The My bets dashboard, the engine's side: a sentence, actual against expected profit, profit by
sportsbook and by market, and a month calendar of daily profit.

What these pin is what a glance at the page cannot show:

  * the sentence's counts are the ledger's, and a bet whose game has no start time on file is
    "waiting for a result", never "upcoming" (nothing is guessed);
  * expected profit is worked out only over bets that were priced, says how many that was, and
    never counts an imported bet's stand-in price as a fair one;
  * the calendar puts a bet on the day it settled, leaves voids off, and its months chain;
  * an empty ledger stays empty: no zeroes dressed as a record.

Every payload here is also read for the words the product never says on their own.
"""

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ask_fixtures as fx  # noqa: E402

from overlay_engine import performance, tracker  # noqa: E402
from overlay_engine.ledger import AtBet, Ledger  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
UTC = timezone.utc
BANNED = ("guaranteed", "risk-free", "risk free", "riskfree", "either way")


def at(year, month, day, hour=12):
    return datetime(year, month, day, hour, tzinfo=UTC).timestamp()


DEVIG = {"power": 0.5, "shin": 0.5, "additive": 0.5, "multiplicative": 0.5}


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "t.db") as ledger:
        yield ledger


def imported(db, i, *, result="won", profit=None, stake=100.0, decimal=2.0, book="dk", market="h2h", sport="nfl",
             settled=None, placed=None):
    placed = placed or at(2026, 10, 1)
    if profit is None:
        profit = stake * (decimal - 1) if result == "won" else -stake if result == "lost" else 0.0
    return db.import_bet(event_id=f"i{i}", sport=sport, market_type=market, outcome="home", book=book,
                         decimal_odds=decimal, stake=stake, placed_at=placed, result=result, profit=profit,
                         settled_at=settled if settled is not None else placed + 7200)


def priced(db, i, *, result="won", fair=0.55, stake=100.0, decimal=2.0, book="dk", settled=None, low=None, high=None):
    placed = at(2026, 10, 1)
    bet = db.record_bet(event_id=f"p{i}", sport="nfl", market_type="h2h", outcome="home", book=book,
                        decimal_odds=decimal, stake=stake, placed_at=placed,
                        at_bet=AtBet(fair_prob=fair, fair_low=low if low is not None else fair - 0.02,
                                     fair_high=high if high is not None else fair + 0.02, devig=dict(DEVIG)))
    profit = stake * (decimal - 1) if result == "won" else -stake if result == "lost" else 0.0
    db.settle(bet, closing_fair_prob=0.5, result=result, profit=profit,
              settled_at=settled if settled is not None else placed + 7200)
    return bet


def open_bet(db, i, event="open"):
    return db.import_bet(event_id=f"{event}{i}", sport="nfl", market_type="h2h", outcome="home", book="dk",
                         decimal_odds=2.0, stake=25.0, placed_at=at(2026, 10, 1))


def dash(db, now=at(2026, 10, 12), history=None, filters=None):
    filters = filters or {}
    rep = performance.report(db.settled_bets(**filters))
    return tracker.dashboard(db, rep, filters, now, history, tz=UTC)


def every_string(node):
    if isinstance(node, str):
        yield node
    elif isinstance(node, dict):
        for k, v in node.items():
            yield from every_string(k)
            yield from every_string(v)
    elif isinstance(node, (list, tuple)):
        for v in node:
            yield from every_string(v)


# ------------------------------------------------------------ the sentence

def test_the_sentence_counts_the_ledger_and_says_the_profit_in_plain_words(db):
    for i in range(3):
        imported(db, i, result="won", stake=100.0, decimal=2.0)
    imported(db, 9, result="lost", stake=100.0)
    d = dash(db)
    assert d["summary"]["settled"] == 4 and d["summary"]["profit"] == 200.0
    assert d["summary"]["text"] == "You have 0 live, 0 upcoming and 4 settled bets, and you are up $200.00."


def test_one_settled_bet_is_singular_and_a_loss_is_down_and_a_wash_is_even(db):
    imported(db, 1, result="lost", stake=40.0)
    assert dash(db)["summary"]["text"] == "You have 0 live, 0 upcoming and 1 settled bet, and you are down $40.00."
    imported(db, 2, result="won", stake=40.0, decimal=2.0)
    assert dash(db)["summary"]["text"].endswith("and you are even.")


def test_a_bet_whose_game_has_no_start_time_on_file_is_waiting_never_upcoming(db):
    open_bet(db, 1)
    open_bet(db, 2)
    s = dash(db)["summary"]
    assert (s["live"], s["upcoming"], s["waiting"]) == (0, 0, 2)
    assert "2 waiting for a result" in s["text"] and "0 upcoming" in s["text"]


def test_live_and_upcoming_come_from_the_start_times_the_recorded_reads_name(db, tmp_path):
    now = at(2026, 10, 12, 18)
    folder = tmp_path / "history"
    fx.write_history(folder, [
        fx.read("americanfootball_nfl", "nfl", now - 3600, "A at B", "h2h", fx.spread_quotes(-2.5), event="soon",
                starts=now + 7200),
        fx.read("americanfootball_nfl", "nfl", now - 3600, "C at D", "h2h", fx.spread_quotes(-2.5), event="on",
                starts=now - 3600),
        fx.read("americanfootball_nfl", "nfl", now - 3600, "E at F", "h2h", fx.spread_quotes(-2.5), event="over",
                starts=now - 8 * 3600)])
    for ev in ("soon", "on", "over", "unknown"):
        db.import_bet(event_id=ev, sport="nfl", market_type="h2h", outcome="home", book="dk", decimal_odds=2.0,
                      stake=10.0, placed_at=now - 86400)
    s = dash(db, now=now, history=folder)["summary"]
    assert (s["upcoming"], s["live"], s["waiting"]) == (1, 1, 2), "a game over for hours, or unknown, is waiting"
    assert s["text"].startswith("You have 1 live, 1 upcoming, 2 waiting for a result and 0 settled bets")


def test_an_empty_ledger_is_empty_and_draws_no_calendar_or_bars(db):
    d = dash(db)
    assert d["summary"]["empty"] is True
    assert d["calendar"]["months"] == [] and d["by_book"] == [] and d["by_market"] == []
    assert d["expected"]["available"] is False and "No settled bets yet" in d["expected"]["text"]


# ------------------------------------------------------------ actual against expected

def test_expected_profit_is_the_fair_price_times_the_payout_over_the_priced_bets_only(db):
    # fair 0.55 at 2.00: expected 100 * (0.55 * 2 - 1) = +10 a bet; band 0.53 to 0.57: +6 to +14.
    priced(db, 1, result="won")
    priced(db, 2, result="lost")
    priced(db, 3, result="lost")
    e = dash(db)["expected"]
    assert e["available"] and e["priced"] == 3 and e["settled"] == 3
    assert e["expected"] == pytest.approx(30.0) and e["low"] == pytest.approx(18.0) and e["high"] == pytest.approx(42.0)
    assert e["actual"] == pytest.approx(-100.0) and e["gap"] == pytest.approx(-130.0)


def test_an_imported_bets_stand_in_price_is_not_a_fair_price(db):
    priced(db, 1, result="won")
    for i in range(10):
        imported(db, i, result="lost")
    e = dash(db)["expected"]
    assert e["priced"] == 1 and e["settled"] == 11
    assert "1 of your 11 settled bets had a fair price saved" in e["text"]
    assert e["actual"] == pytest.approx(100.0), "the comparison is over the priced bets alone"


def test_with_no_priced_bet_it_says_so_instead_of_comparing_against_nothing(db):
    imported(db, 1)
    e = dash(db)["expected"]
    assert e["available"] is False and e["priced"] == 0 and e["settled"] == 1
    assert "None of your settled bets has a fair price" in e["text"]
    assert "expected" not in e and "gap" not in e, "no number is offered where nothing was compared"


def test_pushes_and_voids_are_left_out_of_both_numbers(db):
    priced(db, 1, result="won")
    priced(db, 2, result="push")
    imported(db, 3, result="void", profit=0.0)
    e = dash(db)["expected"]
    assert e["priced"] == 1
    assert e["settled"] == 2, "a void is not a bet; a push is settled but cannot be compared"


def test_below_thirty_compared_bets_the_gap_is_not_read_and_above_it_the_swing_decides(db):
    for i in range(5):
        priced(db, i, result="won")
    few = dash(db)["expected"]
    assert not few["enough"] and "the gap is luck as far as anyone can tell" in few["verdict"]

    lucky = Ledger(db.path.parent / "lucky.db")
    for i in range(40):
        priced(lucky, i, result="won" if i % 2 == 0 else "lost")          # 20 wins at fair 0.55: close to expected
    got = dash(lucky)["expected"]
    assert got["enough"] and abs(got["gap"]) < got["swing"] and "inside the normal swing" in got["verdict"]
    lucky.close()

    hot = Ledger(db.path.parent / "hot.db")
    for i in range(40):
        priced(hot, i, result="won", fair=0.45)                          # all wins at a fair 0.45: far above
    got = dash(hot)["expected"]
    assert got["enough"] and got["gap"] > got["swing"] and "outside the normal swing" in got["verdict"]
    hot.close()


def test_the_swing_is_the_two_standard_deviation_spread_of_the_fair_prices(db):
    for i in range(30):
        priced(db, i, result="won")
    e = dash(db)["expected"]
    assert e["swing"] == pytest.approx(1.96 * (30 * (100 * 2.0) ** 2 * 0.55 * 0.45) ** 0.5, abs=0.01)


# ------------------------------------------------------------ profit by book and by market

def test_the_bars_are_scaled_to_the_longest_and_toned_by_the_sign(db):
    imported(db, 1, book="dk", result="won", stake=100.0, decimal=3.0)          # +200
    imported(db, 2, book="fd", result="lost", stake=100.0)                       # -100
    imported(db, 3, book="mgm", result="won", stake=50.0, decimal=2.0)           # +50
    rows = {r["key"]: r for r in dash(db)["by_book"]}
    assert rows["dk"]["scale"] == 1.0 and rows["fd"]["scale"] == 0.5 and rows["mgm"]["scale"] == 0.25
    assert (rows["dk"]["tone"], rows["fd"]["tone"]) == ("pos", "neg")
    assert rows["dk"]["label"] == "DraftKings" and rows["fd"]["label"] == "FanDuel"


def test_markets_are_named_the_way_a_bettor_says_them_and_reconcile_with_the_total(db):
    imported(db, 1, market="h2h")
    imported(db, 2, market="spreads", result="lost")
    imported(db, 3, market="totals")
    imported(db, 4, market="player_points", result="lost")
    d = dash(db)
    assert {r["label"] for r in d["by_market"]} == {"Moneyline", "Spread", "Total", "Player points"}
    assert sum(r["profit"] for r in d["by_market"]) == pytest.approx(d["summary"]["profit"])


def test_the_filters_that_narrow_the_record_narrow_every_tile(db):
    imported(db, 1, book="dk", result="won")
    imported(db, 2, book="fd", result="lost")
    open_bet(db, 1)
    d = dash(db, filters={"book": "fd"})
    assert d["summary"]["settled"] == 1 and d["summary"]["waiting"] == 0 and d["summary"]["profit"] == -100.0
    assert [r["key"] for r in d["by_book"]] == ["fd"]


# ------------------------------------------------------------ the calendar

def test_a_bet_is_on_the_day_it_settled_not_the_day_it_was_placed(db):
    imported(db, 1, placed=at(2026, 10, 1), settled=at(2026, 10, 3), result="won")
    cal = dash(db)["calendar"]
    cells = [c for week in cal["months"][-1]["weeks"] for c in week if c and c["n"]]
    assert [c["day"] for c in cells] == [3]


def test_a_day_adds_its_bets_and_a_month_adds_its_days_and_a_void_is_not_on_it(db):
    imported(db, 1, settled=at(2026, 10, 5), result="won", stake=100.0)           # +100
    imported(db, 2, settled=at(2026, 10, 5, 20), result="lost", stake=30.0)       # -30
    imported(db, 3, settled=at(2026, 10, 6), result="void", profit=0.0)
    month = dash(db)["calendar"]["months"][-1]
    days = {c["day"]: c for week in month["weeks"] for c in week if c and c["n"]}
    assert set(days) == {5} and days[5]["profit"] == 70.0 and days[5]["n"] == 2
    assert month["profit"] == 70.0 and month["bets"] == 2
    assert days[5]["short"] == "+$70" and days[5]["tone"] == "pos"


def test_the_grid_starts_on_sunday_and_pads_the_first_week(db):
    imported(db, 1, settled=at(2026, 10, 1))                         # 1 October 2026 is a Thursday
    cal = dash(db)["calendar"]
    first = cal["months"][-1]["weeks"][0]
    assert cal["weekdays"][0] == "Sun" and len(first) == 7
    assert first[:4] == [None] * 4 and first[4]["day"] == 1
    assert all(len(w) == 7 for w in cal["months"][-1]["weeks"])


def test_the_months_chain_by_id_so_the_window_never_counts_months(db):
    imported(db, 1, settled=at(2026, 8, 20))
    imported(db, 2, settled=at(2026, 10, 2))
    cal = dash(db)["calendar"]
    ids = [m["id"] for m in cal["months"]]
    assert ids == ["2026-08", "2026-09", "2026-10"], "an empty month in between is still a month"
    assert cal["shown"] == "2026-10"
    by = {m["id"]: m for m in cal["months"]}
    assert by["2026-08"]["prev"] is None and by["2026-08"]["next"] == "2026-09"
    assert by["2026-10"]["next"] is None and by["2026-10"]["prev"] == "2026-09"
    assert by["2026-09"]["prev"] == "2026-08" and by["2026-09"]["next"] == "2026-10"
    assert by["2026-09"]["profit"] == 0.0 and by["2026-09"]["label"] == "September 2026"


def test_a_year_boundary_chains_december_to_january(db):
    imported(db, 1, settled=at(2026, 12, 30))
    imported(db, 2, settled=at(2027, 1, 2))
    ids = [m["id"] for m in dash(db)["calendar"]["months"]]
    assert ids == ["2026-12", "2027-01"]


def test_a_loss_day_is_toned_by_its_own_size_against_the_months_biggest_day(db):
    imported(db, 1, settled=at(2026, 10, 5), result="won", stake=100.0)           # +100
    imported(db, 2, settled=at(2026, 10, 6), result="lost", stake=25.0)           # -25
    cells = {c["day"]: c for week in dash(db)["calendar"]["months"][-1]["weeks"] for c in week if c and c["n"]}
    assert cells[5]["scale"] == 1.0 and cells[6]["scale"] == 0.25 and cells[6]["tone"] == "neg"


def test_the_calendar_keeps_at_most_two_years_of_months(db):
    imported(db, 1, settled=at(2020, 1, 5))
    imported(db, 2, settled=at(2026, 10, 5))
    assert len(dash(db)["calendar"]["months"]) == tracker.MAX_MONTHS


# ------------------------------------------------------------ the verb

def _seed(path, n=6):
    with Ledger(str(path)) as led:
        for i in range(n):
            imported(led, i, book=("dk", "fd")[i % 2], result="won" if i % 3 else "lost",
                     settled=at(2026, 10, 1 + i))


def _performance(db_path, *extra):
    env = {"OVERLAY_HOME": str(db_path.parent)}
    import os
    run = subprocess.run([sys.executable, str(ROOT / "backend" / "cli.py"), "performance", "--db", str(db_path),
                          "--json", *extra], capture_output=True, text=True, env={**os.environ, **env})
    assert run.returncode == 0, run.stderr
    return json.loads(run.stdout)


def test_the_performance_verb_carries_the_dashboard_and_its_profit_is_the_headline_profit(tmp_path):
    path = tmp_path / "v.db"
    _seed(path)
    out = _performance(path)
    t = out["tracker"]
    assert t["summary"]["profit"] == pytest.approx(out["profit"]) and t["summary"]["settled"] == out["settled"]
    assert sum(r["profit"] for r in t["by_book"]) == pytest.approx(out["profit"])
    assert t["calendar"]["months"][-1]["profit"] == pytest.approx(out["profit"])


def test_an_empty_ledger_through_the_verb_is_the_honest_empty_state(tmp_path):
    with Ledger(str(tmp_path / "e.db")):
        pass
    out = _performance(tmp_path / "e.db")
    assert out["settled"] == 0 and out["tracker"]["summary"]["empty"] is True
    assert out["tracker"]["calendar"]["months"] == []


def test_the_verb_narrows_the_dashboard_with_its_filters(tmp_path):
    path = tmp_path / "f.db"
    _seed(path)
    whole, narrow = _performance(path), _performance(path, "--book", "fd")
    assert narrow["tracker"]["summary"]["settled"] < whole["tracker"]["summary"]["settled"]
    assert [r["key"] for r in narrow["tracker"]["by_book"]] == ["fd"]


def test_nothing_in_the_dashboard_says_what_the_product_never_says_on_its_own(tmp_path, db):
    for i in range(35):
        priced(db, i, result="won" if i % 2 else "lost")
    for i in range(5):
        imported(db, 100 + i, settled=at(2026, 10, 1 + i))
    open_bet(db, 1)
    for text in every_string(dash(db)):
        low = text.lower()
        for word in BANNED:
            assert word not in low, (word, text)
