"""A recorded read of live sportsbook odds, written the way oddshistory.record writes one.

Shared by the converter's engine tests and the window's tests, so both look at the same shape
of file the app itself leaves in ~/.overlay/oddsapi/history.
"""

import json

NOW = 1_800_000_000.0
HOUR = 3600.0


def history(tmp_path, markets, *, read_at=NOW - 600, league="americanfootball_nfl", alias="nfl"):
    """Write one recorded read and return its folder. `markets` is
    [(event_id, type, starts, [(book, outcome, line, decimal), ...]), ...]."""
    folder = tmp_path / "history"
    folder.mkdir(exist_ok=True)
    events = {e: {"label": f"Game {e}", "starts": None} for e, *_ in markets}
    body = [{"event": e, "type": t, "starts": starts,
             "q": [[b, o, line, d, read_at] for b, o, line, d in quotes]}
            for e, t, starts, quotes in markets]
    line = json.dumps({"v": 1, "league": league, "alias": alias, "fetched_at": read_at,
                       "events": events, "markets": body}, separators=(",", ":"))
    (folder / "2027-01-15.jsonl").write_text(line + "\n")
    return folder


def h2h(event, dk, fd, *, starts=NOW + 6 * HOUR, names=("Chiefs", "Bills")):
    """Two sides, DraftKings (the promo book) and FanDuel (the hedge book)."""
    a, b = names
    return (event, "h2h", starts, [("dk", a, None, dk[0]), ("dk", b, None, dk[1]),
                                   ("fd", a, None, fd[0]), ("fd", b, None, fd[1])])
