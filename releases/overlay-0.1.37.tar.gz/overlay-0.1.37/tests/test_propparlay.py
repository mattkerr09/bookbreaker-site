"""The parlay builder: legs priced from the books' own main lines, licensed books only, one ticket per game and no leg
on two tickets, and the cost said before any read. Nothing here touches the network."""
import pytest

from overlay_engine import propparlay as pp
from overlay_engine.oddsapi import OddsApiError

EVENT = "abcdef1234567890"


def o(name, who, price, pt):
    return {"name": name, "description": who, "price": price, "point": pt}


def game(event=EVENT, home="Kansas City Chiefs", away="Las Vegas Raiders", qb="Patrick Mahomes", te="Travis Kelce",
         rb="Isiah Pacheco", wr="Jakobi Meyers", extra_book=None):
    fd = {"key": "fanduel", "markets": [
        {"key": "player_pass_yds", "outcomes": [o("Over", qb, 1.91, 249.5), o("Under", qb, 1.91, 249.5)]},
        {"key": "player_pass_yds_alternate", "outcomes": [o("Over", qb, 1.45, 199.5), o("Over", qb, 1.20, 174.5)]},
        {"key": "player_reception_yds", "outcomes": [o("Over", te, 1.87, 59.5), o("Under", te, 1.95, 59.5)]},
        {"key": "player_reception_yds_alternate", "outcomes": [o("Over", te, 1.55, 39.5)]},
        {"key": "player_rush_yds", "outcomes": [o("Over", rb, 1.9, 54.5), o("Under", rb, 1.9, 54.5)]},
        {"key": "player_rush_yds_alternate", "outcomes": [o("Over", rb, 1.6, 39.5)]},
        {"key": "player_receptions", "outcomes": [o("Over", wr, 1.8, 4.5), o("Under", wr, 2.0, 4.5)]},
        {"key": "player_receptions_alternate", "outcomes": [o("Over", wr, 1.5, 3.5)]}]}
    books = [fd]
    if extra_book:
        books.append(extra_book)
    return {"id": event, "home_team": home, "away_team": away, "bookmakers": books}


def read_of(*games):
    return pp.Read(pp.Estimate(tuple(g["id"] for g in games), pp.DEFAULT_MARKETS, ("us",)), list(games), 0.0)


TEAMS = {"patrick mahomes": ("KC", "QB"), "travis kelce": ("KC", "TE"), "isiah pacheco": ("KC", "RB"),
         "jakobi meyers": ("LV", "WR")}


def test_cost_is_said_before_anything_is_read_and_follows_the_rule():
    est = pp.estimate([EVENT, "bbbbbbbb12345678"])
    assert est.credits == 2 * len(pp.DEFAULT_MARKETS) * 1
    assert "costs up to 16 credits" in est.sentence() and "Nothing is read until you press Read" in est.sentence()
    with pytest.raises(OddsApiError):
        pp.estimate([])
    with pytest.raises(OddsApiError):
        pp.estimate(["not an id!"])


def test_a_read_that_could_cost_more_than_is_left_is_refused_before_any_request():
    calls = []
    with pytest.raises(OddsApiError) as exc:
        pp.read(pp.estimate([EVENT]), "k", remaining=3, fetcher=lambda *a: calls.append(a))
    assert exc.value.reason == "credits" and calls == []


def test_a_fair_price_comes_from_the_main_line_and_rises_down_the_ladder():
    legs = {(x.player, x.point): x for x in pp.legs(read_of(game()), "MI", TEAMS)}
    main = legs[("Patrick Mahomes", 249.5)].fair
    assert 0.45 < main < 0.55                         # the main line at even money is about a coin flip
    assert legs[("Patrick Mahomes", 199.5)].fair > main
    assert legs[("Patrick Mahomes", 174.5)].fair > legs[("Patrick Mahomes", 199.5)].fair


def test_only_books_licensed_in_the_state_are_priced():
    offshore = {"key": "bovada", "markets": [{"key": "player_pass_yds_alternate",
                                               "outcomes": [o("Over", "Patrick Mahomes", 9.0, 199.5)]}]}
    for x in pp.legs(read_of(game(extra_book=offshore)), "MI", TEAMS):
        assert "bovada" not in x.prices and x.best < 9.0


def test_a_player_with_no_two_way_main_line_gets_no_fair_price():
    g = game()
    g["bookmakers"][0]["markets"] = [m for m in g["bookmakers"][0]["markets"] if m["key"] != "player_pass_yds"]
    assert not [x for x in pp.legs(read_of(g), "MI", TEAMS) if x.player == "Patrick Mahomes"]


def test_a_same_game_ticket_is_one_game_one_leg_per_player_and_says_the_shortest_price_to_take():
    tickets = pp.same_game(pp.legs(read_of(game()), "MI", TEAMS))
    assert tickets
    t = tickets[0]
    assert len({x["game"] for x in t["legs"]}) == 1
    assert len({x["player"] for x in t["legs"]}) == len(t["legs"])
    assert 3 <= len(t["legs"]) <= 6
    assert t["take_at_or_longer"] == pp.american(1 / t["chance"])


def test_a_qb_stacked_with_his_own_pass_catcher_is_credited_and_an_opponent_is_not():
    ls = pp.legs(read_of(game()), "MI", TEAMS)
    qb = next(x for x in ls if x.player == "Patrick Mahomes" and x.point == 199.5)
    te = next(x for x in ls if x.player == "Travis Kelce" and x.point == 39.5)
    wr = next(x for x in ls if x.player == "Jakobi Meyers" and x.point == 3.5)
    lift = pp.shapes()["lift"]
    assert lift > 1
    assert pp._joint([qb, te], lift) == pytest.approx(qb.fair * te.fair * lift)
    assert pp._joint([qb, wr], lift) == pytest.approx(qb.fair * wr.fair)


def test_the_day_plan_never_puts_a_leg_on_two_tickets_or_two_tickets_on_one_game():
    g2 = game("bbbbbbbb12345678", "Detroit Lions", "Chicago Bears", "Jared Goff", "Sam LaPorta", "Jahmyr Gibbs",
              "DJ Moore")
    teams = dict(TEAMS, **{"jared goff": ("DET", "QB"), "sam laporta": ("DET", "TE"), "jahmyr gibbs": ("DET", "RB"),
                           "dj moore": ("CHI", "WR")})
    out = pp.build(read_of(game(), g2), state="MI", tickets=5, stake=50, teams=teams)
    plan = out["plan"]["tickets"]
    assert plan and len({t["game"] for t in plan}) == len(plan)
    seen = set()
    for t in plan:
        keys = {tuple(k) for k in t["keys"]}
        assert not keys & seen
        seen |= keys
    assert sum(t["stake"] for t in plan) == pytest.approx(50)
    assert max(plan, key=lambda t: t["chance"])["role"] == "anchor"


def test_shapes_carry_their_source():
    s = pp.shapes()
    assert "nflverse" in s["source"] and set(s["shapes"]) == {"passing_yards", "rushing_yards", "receiving_yards",
                                                              "receptions"}


def test_the_day_plan_skips_a_ticket_that_shares_a_leg_or_a_game_with_one_already_chosen():
    def t(game, keys, chance):
        return {"game": game, "keys": keys, "chance": chance, "legs": []}
    a = t("G1", [("A", "passing_yards", 199.5), ("B", "receptions", 3.5)], 0.30)
    shares_a_leg = t("G2", [("A", "passing_yards", 199.5), ("C", "rushing_yards", 39.5)], 0.25)
    same_game = t("G1", [("D", "receiving_yards", 39.5)], 0.20)
    clean = t("G3", [("E", "receiving_yards", 49.5)], 0.22)
    plan = pp.day_plan([a, shares_a_leg, same_game, clean], n=5, stake=50)["tickets"]
    assert [x["game"] for x in plan] == ["G1", "G3"]


def _info(**kw):
    base = {"team": "KC", "pos": "WR", "status": "", "avg": {"receiving_yards": 70.0, "receptions": 6.0,
            "passing_yards": 0, "rushing_yards": 0}, "last_season": {"receiving_yards": 72.0, "receptions": 6.0,
            "passing_yards": None, "rushing_yards": None}, "use": {"targets": 8.0}, "use_last2": {"targets": 8.0},
            "mate_out": ""}
    base.update(kw)
    return base


def _leg(point=49.5, stat="receiving_yards"):
    return pp.Leg("G", EVENT, "Some Receiver", stat, point, 0.7, 1.6, ["fd"], {"fd": 1.6}, "KC", "WR")


def test_an_injury_tag_or_falling_usage_is_a_red_flag_and_a_deep_cushion_or_a_teammate_out_is_green():
    red, green = pp.flag(_leg(), _info(status="Questionable"))
    assert any("Questionable" in r for r in red)
    red, green = pp.flag(_leg(), _info(use_last2={"targets": 5.0}))
    assert any("usage fell" in r for r in red)
    red, green = pp.flag(_leg(49.5), _info(mate_out="Big Teammate"))
    assert not red and any("20%+" in g for g in green) and any("Big Teammate" in g for g in green)
    assert pp.flag(_leg(), None) == ([], [])


def test_a_red_flagged_leg_is_never_put_on_a_ticket():
    ctx = {"patrick mahomes": _info(team="KC", pos="QB", status="Questionable",
                                    avg={"passing_yards": 260.0, "rushing_yards": 0, "receiving_yards": 0,
                                         "receptions": 0}, use={"attempts": 35.0}, use_last2={"attempts": 35.0}),
           "travis kelce": _info(team="KC", pos="TE"), "isiah pacheco": _info(team="KC", pos="RB"),
           "jakobi meyers": _info(team="LV", pos="WR")}
    out = pp.build(read_of(game()), state="MI", context=ctx)
    assert out["kept_off"] >= 1
    for t in out["same_game"]:
        assert all(x["player"] != "Patrick Mahomes" for x in t["legs"])


def test_every_ticket_says_what_it_costs_against_its_fair_price_and_names_legs_that_move_together():
    out = pp.build(read_of(game()), state="MI", book="fd", teams=TEAMS)
    t = out["same_game"][0]
    paid = 1.0
    for x in t["legs"]:
        paid *= x["best"]
    assert t["cost_vs_fair"] == pytest.approx(1 - t["chance"] * paid, abs=1e-3)
    assert t["fair_american"] == pp.american(1 / t["chance"])
    for x in t["legs"]:
        assert x["margin"] == pytest.approx(1 - x["fair"] * x["best"], abs=1e-3)
    stacked = [x for x in t["legs"] if x["player"] in ("Patrick Mahomes", "Travis Kelce")]
    if len(stacked) == 2:
        assert t["correlated"] and "same-game parlay prices that in" in t["correlation_note"]


def test_the_wording_never_sells_parlays_as_a_strategy():
    import inspect
    from overlay_engine import cli
    text = inspect.getsource(pp) + inspect.getsource(cli.cmd_parlays) + inspect.getsource(cli._print_parlays)
    for phrase in ("best parlays", "guaranteed", "can't lose", "sure thing", "lock of", "free money", "best-value",
                   "or not at all", "take it at", "% of the time"):
        assert phrase not in text.lower()
    note = pp.day_plan([{"game": "G", "keys": [], "chance": .3, "legs": []}])["note"]
    assert "costs more than the same legs bet singly" in note and "costs you money on average" in note


def test_the_engine_writes_every_figure_the_window_shows():
    out = pp.build(read_of(game()), state="MI", book="fd", teams=TEAMS)
    for x in out["legs"]:
        assert x["chance_text"].endswith("%") and x["value_text"][0] in "+-" and " at " in x["best_text"]
    t = out["same_game"][0]
    assert t["cost_text"] == f"{t['cost_vs_fair'] * 100:+.1f}%"
    assert t["fair_text"] == f"{t['fair_american']:+d}"
    for k in ("chance_text", "paid_text", "take_text"):
        assert t[k]
