#!/bin/bash
# Every gate, in one command. Nothing is done until this exits 0.
#
# Three, because each catches what the others cannot:
#   pytest        the engine's arithmetic
#   break_test    that the arithmetic tests can actually fail
#   smoke_cli     that the CLI wires the engine up at all — a subcommand can
#                 pass every unit test underneath it and still crash on an
#                 f-string, and the CLI is the only part a user touches
#   check_catalog that the jurisdiction table is fresh and self-consistent.
#                 Nothing about a stale table looks wrong: it answers every
#                 question confidently, in the same shape, and thirty pages of
#                 the live site are generated from it
#
# Prints the real counts. A gate whose number you cannot read is a gate you
# are trusting rather than checking.
set -uo pipefail
cd "$(dirname "$0")/.." || exit 2

# Nothing a gate runs may touch this Mac's real profile. The break tests run
# deliberately broken engines, and each crash used to write a report into
# ~/.overlay/crashes (254 of them by 2026-10-13, mixed in with real ones). Every
# gate gets a throwaway OVERLAY_HOME, and the run fails if the real crash folder
# grows anyway.
REAL_CRASHES="${OVERLAY_HOME:-$HOME/.overlay}/crashes"
crash_count() { find "$REAL_CRASHES" -maxdepth 1 -type f 2>/dev/null | wc -l | tr -d ' '; }
crashes_before="$(crash_count)"
OVERLAY_HOME="$(mktemp -d "${TMPDIR:-/tmp}/bb-gates-home-XXXXXX")" || exit 2
export OVERLAY_HOME
trap 'rm -rf "$OVERLAY_HOME"' EXIT

fail=0
echo "── pytest ─────────────────────────────────────────"
# No `-q` here: pytest.ini already sets it, and a second one means
# `-qq`, which suppresses the summary line entirely — the run went
# green with the count invisible, which is the one thing this
# script exists to print.
python3 -m pytest 2>&1 | grep -Ei "passed|failed|error" | tail -2 || fail=1
echo
echo "── break tests ────────────────────────────────────"
# The last three lines, plus, when it fails, the lines that say why: a stop (an anchor gone, a restore that failed)
# goes to stderr before the buffered "caught" lines, so a plain tail showed a red gate with no reason in it.
breaks_log="$(mktemp "${TMPDIR:-/tmp}/bb-breaks-XXXXXX")"
if ! PYTHONUNBUFFERED=1 python3 scripts/break_test.py > "$breaks_log" 2>&1; then
  fail=1
  grep -E "MISSED|ANCHOR GONE|RESTORE FAILED|undetected|^  - |want:|have:|Traceback|Error" "$breaks_log" | head -20
fi
tail -3 "$breaks_log"
rm -f "$breaks_log"
echo
echo "── catalog ────────────────────────────────────────"
python3 scripts/check_catalog.py 2>&1 | tail -2 || fail=1
echo
echo "── cli smoke ──────────────────────────────────────"
python3 scripts/smoke_cli.py 2>&1 | tail -3 || fail=1
echo
echo "── real profile ───────────────────────────────────"
crashes_after="$(crash_count)"
if [ "$crashes_after" != "$crashes_before" ]; then
  echo "  the gates wrote to $REAL_CRASHES ($crashes_before files before, $crashes_after after)"
  fail=1
else
  echo "  untouched ($crashes_after files in the real crash folder before and after)"
fi
echo
if [ "$fail" -ne 0 ]; then
  echo "GATES RED"
  exit 1
fi
echo "GATES GREEN"
