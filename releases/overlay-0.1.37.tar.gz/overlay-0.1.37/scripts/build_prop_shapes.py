#!/usr/bin/env python3
"""Build backend/overlay_engine/data/prop_shapes.json: how an NFL starter's game lands around his projection.

For every regular-season game 2019-2025 of a starter with three or more games behind him that season (QB 20+ pass
attempts, RB 8+ carries, WR/TE 4+ targets a game so far), the ratio of what he did to his season-to-date average, as
101 quantiles per market. Yards cannot go below zero and have a long right tail, which a normal curve around a line
gets wrong; this is the shape the parlay builder scales to each book's main line.

Also the lift on two legs hitting together when a QB's line and his own WR/TE's line are both set below their
averages, measured on the same games.

    python3 scripts/build_prop_shapes.py <folder with nflverse stats_player_week_YYYY.csv and games.csv>

Source: nflverse-data releases (stats_player) and nflverse/nfldata games.csv, public data, read 2026-10-18.
"""
import csv, json, statistics as st, sys
from pathlib import Path

D = Path(sys.argv[1]); OUT = Path(__file__).resolve().parents[1] / "backend/overlay_engine/data/prop_shapes.json"
KEY = {"QB": [("passing_yards", "attempts", 20)], "RB": [("rushing_yards", "carries", 8)],
       "WR": [("receiving_yards", "targets", 4), ("receptions", "targets", 4)],
       "TE": [("receiving_yards", "targets", 4), ("receptions", "targets", 4)]}
games = {g["game_id"] for g in csv.DictReader(open(D / "games.csv")) if g["game_type"] == "REG"}
def f(x):
    try: return float(x)
    except (TypeError, ValueError): return 0.0
ratios = {"passing_yards": [], "rushing_yards": [], "receiving_yards": [], "receptions": []}
pairs = []   # (QB hit, own WR/TE hit) at 30% under each average
for y in range(2019, 2026):
    rows = [r for r in csv.DictReader(open(D / f"stats_player_week_{y}.csv")) if r["season_type"] == "REG" and r["game_id"] in games]
    byp = {}
    for r in rows: byp.setdefault(r["player_id"], []).append(r)
    hits = {}
    for rs in byp.values():
        rs.sort(key=lambda r: int(r["week"]))
        for i, r in enumerate(rs):
            if r["position"] not in KEY or i < 3: continue
            prior = rs[:i]
            for k, use, floor in KEY[r["position"]]:
                if st.mean(f(p[use]) for p in prior) < floor: continue
                avg = st.mean(f(p[k]) for p in prior)
                if avg <= 0: continue
                ratios[k].append(f(r[k]) / avg)
                if k in ("passing_yards", "receiving_yards"):
                    hits.setdefault((r["game_id"], r["team"]), []).append((r["position"], int(f(r[k]) > 0.7 * avg)))
    for lst in hits.values():
        q = [h for p, h in lst if p == "QB"]
        if len(q) == 1: pairs += [(q[0], h) for p, h in lst if p in ("WR", "TE")]
def quantiles(xs):
    xs = sorted(xs); n = len(xs)
    return [round(xs[min(n - 1, int(i / 100 * (n - 1) + 0.5))], 4) for i in range(101)]
a = sum(x for x, _ in pairs) / len(pairs); b = sum(y for _, y in pairs) / len(pairs); j = sum(1 for x, y in pairs if x and y) / len(pairs)
out = {"source": "nflverse stats_player_week 2019-2025 and nfldata games.csv, regular season; built by scripts/build_prop_shapes.py",
       "read": "2026-10-18", "markets": {k: {"games": len(v), "quantiles": quantiles(v)} for k, v in ratios.items()},
       "lift": {"qb_own_pass_catcher": {"pairs": len(pairs), "value": round(j / (a * b), 3)},
                "qb_own_rb": {"value": 0.98}, "other_same_game": {"value": 1.0}}}
OUT.write_text(json.dumps(out, indent=1) + "\n")
print(OUT, {k: v["games"] for k, v in out["markets"].items()}, out["lift"]["qb_own_pass_catcher"])
