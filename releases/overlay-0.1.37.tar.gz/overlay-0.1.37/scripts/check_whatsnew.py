#!/usr/bin/env python3
"""Refuse a build whose version has no What's new entry.

    python3 scripts/check_whatsnew.py [VERSION] [--data PATH]

The window's What's new page is bundled from ui/src/whatsnew.js. A release that
forgets its entry would ship a window whose newest note is the previous version,
and nobody would see anything wrong. VERSION defaults to the one in
ui/src-tauri/tauri.conf.json, which is the version the app is built as.
scripts/build_app.sh and scripts/release.sh run this before they build anything.

Exit 0 when the newest entry is the version being built, 1 (one sentence per
problem on stderr) otherwise, 2 when the data file cannot be read at all.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "ui" / "src" / "whatsnew.js"
CONF = ROOT / "ui" / "src-tauri" / "tauri.conf.json"

PREFIX = "window.WHATS_NEW ="


def load(path: Path = DATA) -> list[dict]:
    """The entries, read as JSON: everything from the array's first bracket to the last one."""
    text = path.read_text()
    start = text.index(PREFIX) + len(PREFIX)
    body = text[text.index("[", start):text.rindex("]") + 1]
    return json.loads(body)


def newest_problem(entries: list[dict], version: str) -> str | None:
    """One sentence if the newest entry is not `version`, else None."""
    if not entries:
        return "What's new has no entries."
    newest = entries[0].get("version")
    if newest == version:
        return None
    if any(e.get("version") == version for e in entries):
        return (f"What's new has an entry for {version}, but it is not the newest "
                f"(the first one is {newest}); put it at the top.")
    return (f"What's new has no entry for {version} (the newest is {newest}); "
            f"add one at the top of ui/src/whatsnew.js before building.")


def main(argv: list[str]) -> int:
    data, version = DATA, None
    args = list(argv)
    while args:
        a = args.pop(0)
        if a == "--data" and args:
            data = Path(args.pop(0))
        elif re.fullmatch(r"\d+\.\d+\.\d+", a):
            version = a
        else:
            print(__doc__, file=sys.stderr)
            return 2
    try:
        entries = load(data)
        if version is None:
            version = json.loads(CONF.read_text())["version"]
    except (OSError, ValueError, KeyError) as error:
        print(f"could not read What's new ({error})", file=sys.stderr)
        return 2
    problem = newest_problem(entries, version)
    if problem:
        print(problem, file=sys.stderr)
        return 1
    print(f"  What's new has an entry for {version}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
