"""P&L, ROI, win rate — and how much of it is noise.

Every tracker in this category reports ROI as a fact. It is not: a 2% edge over
500 even-money bets has a standard deviation of about 4.5% of turnover, so a
bettor with a real 2% edge routinely shows anywhere from -7% to +11% over a
season. Printing "ROI: 4.3%" from that sample tells the user something that
will be a different number next month for no reason they did anything about.

So every figure here carries its interval, and the verdict says plainly when
the record cannot distinguish the user from break-even. This is the same
discipline `clv.CLVReport` already applies, turned on the number people
actually look at.

Two measurement details that most trackers get quietly wrong:

**Pushes are not losses and voids are not bets.** Counting a push as a loss
deflates win rate; leaving a voided stake in turnover deflates ROI. Both errors
are invisible and neither flatters anyone, which is why `void` is excluded from
turnover entirely and `push` counts as a settled bet with zero profit but is
kept out of the win-rate denominator.

**Flat-bet ROI and money ROI are different numbers, and the gap is
informative.** Money ROI is what actually happened; flat-bet ROI is what would
have happened betting the same amount every time. When money ROI is the higher
of the two, the staking added value — bigger bets landed more often than
smaller ones. When it is lower, sizing cost money that the edge earned. No
other tracker separates them, and the difference is the only direct read on
whether the Kelly sizing is working.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

# Below this, a return figure is reported but never characterised. Matches the
# floor `clv` and `calibrate` use — the same evidence bar throughout.
MIN_BETS = 30

# Two standard errors. Not a formal test, and labelled as an interval rather
# than a p-value, because the underlying returns are heavily skewed on longshot
# prices and a normal interval there is indicative, not exact.
Z = 1.96


@dataclass(frozen=True)
class Slice:
    """Performance over one group of bets."""

    label: str
    n: int
    turnover: float
    profit: float
    won: int
    lost: int
    push: int
    void: int
    flat_return: float
    flat_stdev: float

    @property
    def roi(self) -> float:
        """Money ROI: profit over money actually risked."""
        return self.profit / self.turnover if self.turnover else 0.0

    @property
    def decided(self) -> int:
        """Bets that could be won or lost. Pushes and voids cannot."""
        return self.won + self.lost

    @property
    def win_rate(self) -> float:
        """Share of *decided* bets won.

        Pushes are excluded from the denominator rather than counted as
        losses, which is the difference between a 52.4% break-even record and
        an apparent 49% one on a book full of pushed spreads.
        """
        return self.won / self.decided if self.decided else 0.0

    @property
    def standard_error(self) -> float:
        return self.flat_stdev / math.sqrt(self.n) if self.n > 1 else float("inf")

    @property
    def roi_low(self) -> float:
        se = self.standard_error
        return self.flat_return - Z * se if math.isfinite(se) else float("-inf")

    @property
    def roi_high(self) -> float:
        se = self.standard_error
        return self.flat_return + Z * se if math.isfinite(se) else float("inf")

    @property
    def significant(self) -> bool:
        """Whether the interval clears zero on a sample big enough to mean it."""
        return self.significant_at(Z)

    def significant_at(self, z: float) -> bool:
        """Significance at an arbitrary evidence bar.

        Exists so tag slices can be judged more strictly than the overall
        record. Testing twelve hypotheses at the same threshold you would use
        for one is how a slice that means nothing acquires a green tick.
        """
        se = self.standard_error
        if self.n < MIN_BETS or not math.isfinite(se) or se <= 0:
            return False
        return abs(self.flat_return) > z * se

    def units(self, unit: float) -> float:
        """Profit in units. A unit is whatever the user says it is, and the
        figure is meaningless without that — so it is an argument, never a
        default."""
        if unit <= 0:
            raise ValueError("a unit must be a positive stake")
        return self.profit / unit

    def verdict(self) -> str:
        if self.n == 0:
            return "no settled bets"
        if self.n < MIN_BETS:
            return (
                f"{self.n} settled bets — too few to characterise; "
                f"need {MIN_BETS}+"
            )
        band = f"{self.roi_low:+.1%} to {self.roi_high:+.1%}"
        if self.roi_low > 0:
            return f"profitable: flat-bet ROI {self.flat_return:+.2%} ({band})"
        if self.roi_high < 0:
            return f"losing: flat-bet ROI {self.flat_return:+.2%} ({band})"
        return (
            f"{self.flat_return:+.2%} flat-bet ROI, but the interval spans zero "
            f"({band}) — indistinguishable from break-even"
        )


def _summarise(label: str, bets: list[dict]) -> Slice:
    """Build a slice, excluding voids from everything but the void count."""
    live = [b for b in bets if b.get("result") != "void"]
    voids = len(bets) - len(live)

    turnover = sum(b["stake"] for b in live)
    profit = sum(b["profit"] or 0.0 for b in live)

    won = sum(1 for b in live if b.get("result") == "won")
    lost = sum(1 for b in live if b.get("result") == "lost")
    push = sum(1 for b in live if b.get("result") == "push")

    # Bets recorded before schema v6 have no `result`. Fall back to the sign of
    # the profit rather than dropping them: a settled bet with a known profit
    # is real money whether or not anyone labelled the outcome.
    for b in live:
        if b.get("result") in (None, ""):
            if (b["profit"] or 0.0) > 0:
                won += 1
            elif (b["profit"] or 0.0) < 0:
                lost += 1
            else:
                push += 1

    returns = [
        (b["profit"] or 0.0) / b["stake"] for b in live if b["stake"] > 0
    ]
    n = len(returns)
    mean = sum(returns) / n if n else 0.0
    if n > 1:
        var = sum((r - mean) ** 2 for r in returns) / (n - 1)
        stdev = math.sqrt(var)
    else:
        stdev = 0.0

    return Slice(
        label=label, n=n, turnover=turnover, profit=profit,
        won=won, lost=lost, push=push, void=voids,
        flat_return=mean, flat_stdev=stdev,
    )


@dataclass
class Performance:
    """The whole record, and every way it breaks down."""

    overall: Slice
    by_sport: list[Slice] = field(default_factory=list)
    by_book: list[Slice] = field(default_factory=list)
    by_market: list[Slice] = field(default_factory=list)
    by_odds: list[Slice] = field(default_factory=list)

    @property
    def staking_effect(self) -> float:
        """Money ROI minus flat-bet ROI.

        Positive means the staking added value — larger bets landed more often
        than smaller ones. Negative means sizing gave back edge the selection
        earned. It is the only direct read on whether the Kelly sizing is
        working, and it is why both ROIs are computed rather than one.
        """
        return self.overall.roi - self.overall.flat_return

    def leaks(self, min_bets: int = MIN_BETS) -> list[Slice]:
        """Segments losing money on a sample large enough to believe.

        Deliberately gated on `min_bets`: the whole appeal of a breakdown is
        finding the one bad category, and the whole danger is that with enough
        slices something always looks bad. A screen that flags "you lose on
        Tuesday night hockey" from nine bets is manufacturing a pattern.
        """
        out = [
            s for group in (self.by_sport, self.by_book, self.by_market, self.by_odds)
            for s in group
            if s.n >= min_bets and s.roi_high < 0
        ]
        return sorted(out, key=lambda s: s.flat_return)


def _odds_bucket(decimal: float) -> str:
    """Coarse price bands, because per-price slices are all tiny."""
    if decimal < 1.5:
        return "heavy favourite (under -200)"
    if decimal < 2.0:
        return "favourite (-200 to -100)"
    if decimal < 3.0:
        return "underdog (+100 to +200)"
    if decimal < 6.0:
        return "longshot (+200 to +500)"
    return "outsider (+500 and out)"


def report(bets: list[dict], top: int = 8) -> Performance:
    """Summarise a settled-bet record and every breakdown of it."""
    def grouped(key, limit: int | None = None) -> list[Slice]:
        """The busiest buckets, plus an honest remainder.

        This used to return the top `limit` and drop the rest without a word.
        For a bettor across fourteen books that showed eight rows covering
        sixteen of twenty-eight bets — 43% of their own record absent from a
        table that looked complete. Arbitrage is played across many books by
        definition, so the users this product is for are exactly the ones it
        misled.

        The remainder keeps the breakdown reconciling with the total, which
        is the property that makes a breakdown checkable at all.
        """
        buckets: dict[str, list[dict]] = {}
        for bet in bets:
            buckets.setdefault(key(bet), []).append(bet)
        slices = [_summarise(name, rows) for name, rows in buckets.items()]
        slices.sort(key=lambda s: -s.n)
        if not limit or len(slices) <= limit:
            return slices

        kept = slices[:limit]
        rest = [row for name, rows in buckets.items() for row in rows
                if name not in {s.label for s in kept}]
        kept.append(_summarise(f"{len(slices) - limit} more", rest))
        return kept

    return Performance(
        overall=_summarise("overall", bets),
        by_sport=grouped(lambda b: b["sport"], top),
        by_book=grouped(lambda b: b["book"], top),
        by_market=grouped(lambda b: b["market_type"], top),
        by_odds=grouped(lambda b: _odds_bucket(b["decimal_odds"])),
    )


def from_ledger(ledger, **filters) -> Performance:
    """Performance over the ledger, with the usual filters."""
    return report(ledger.settled_bets(**filters))


CSV_COLUMNS = (
    "id", "placed_at", "settled_at", "sport", "market_type", "outcome",
    "book", "decimal_odds", "stake", "result", "profit",
    "fair_prob", "closing_fair_prob", "p_fill", "heat",
)


def to_csv(bets: list[dict]) -> str:
    """Export settled bets as CSV.

    Written by hand rather than through `csv` so the column order is fixed and
    reviewable: an export whose columns move between versions breaks every
    spreadsheet built on it.
    """
    lines = [",".join(CSV_COLUMNS)]
    for bet in bets:
        row = []
        for column in CSV_COLUMNS:
            value = bet.get(column)
            if value is None:
                row.append("")
            elif isinstance(value, float):
                row.append(f"{value:.6g}")
            elif isinstance(value, str) and ("," in value or '"' in value):
                row.append('"' + value.replace('"', '""') + '"')
            else:
                row.append(str(value))
        lines.append(",".join(row))
    return "\n".join(lines) + "\n"


# --------------------------------------------------------- tags

def bonferroni_z(tests: int, alpha: float = 0.05) -> float:
    """The evidence bar needed when `tests` hypotheses are checked at once.

    With one test at 5%, a false positive turns up one time in twenty. With
    twelve, the chance that *at least one* slice looks significant by luck is
    1 - 0.95^12, or about 46% — so a tag that clears the ordinary bar out of
    twelve has told you nothing. Dividing alpha by the number of tests restores
    the bar the ordinary one was supposed to be.

    This is the correction nobody in this category applies, and tag slices are
    exactly where it is needed: a user who invents labels until one looks
    profitable is running a search, not a test.
    """
    from statistics import NormalDist

    tests = max(1, tests)
    return NormalDist().inv_cdf(1.0 - (alpha / tests) / 2.0)


def family_error_rate(tests: int, alpha: float = 0.05) -> float:
    """Chance at least one of `tests` slices looks significant by luck."""
    return 1.0 - (1.0 - alpha) ** max(0, tests)


@dataclass
class TagReport:
    """Per-tag performance, judged against a bar that knows how many tags
    were tested."""

    slices: list[Slice]
    alpha: float = 0.05

    @property
    def tests(self) -> int:
        """Tags with enough bets to be tested at all."""
        return sum(1 for s in self.slices if s.n >= MIN_BETS)

    @property
    def bar(self) -> float:
        return bonferroni_z(self.tests, self.alpha)

    @property
    def naive_winners(self) -> list[Slice]:
        """Tags clearing the ordinary bar — before the correction."""
        return [s for s in self.slices if s.significant]

    @property
    def survivors(self) -> list[Slice]:
        """Tags clearing the corrected bar. The ones worth believing."""
        return [s for s in self.slices if s.significant_at(self.bar)]

    def verdict(self) -> str:
        if not self.slices:
            return "no tagged bets"
        if not self.tests:
            return (f"{len(self.slices)} tags, none with {MIN_BETS}+ settled "
                    "bets — nothing testable yet")

        naive, kept = len(self.naive_winners), len(self.survivors)
        parts = [
            f"{self.tests} tags testable; at a single-test bar {naive} look "
            f"significant, {kept} survive the correction for testing "
            f"{self.tests} at once"
        ]
        if self.tests > 1:
            parts.append(
                f"with {self.tests} slices there is a "
                f"{family_error_rate(self.tests, self.alpha):.0%} chance one "
                "clears the ordinary bar by luck alone"
            )
        return "; ".join(parts)


def tag_report(ledger, alpha: float = 0.05) -> TagReport:
    """Performance per tag, with the bar raised for how many were tried."""
    grouped = ledger.settled_by_tag()
    slices = [_summarise(tag, rows) for tag, rows in grouped.items()]
    slices.sort(key=lambda s: -s.n)
    return TagReport(slices=slices, alpha=alpha)
