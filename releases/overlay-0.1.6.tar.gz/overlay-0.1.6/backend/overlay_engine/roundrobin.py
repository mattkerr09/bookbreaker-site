"""Round robins: every parlay of a given size from one set of legs.

A round robin is sold as risk management — "you don't need all of them to
win" — and that framing is what makes it worth pricing carefully. It is
strictly worse than the same money on straight bets whenever the legs are
priced with vig, because every parlay multiplies the hold. What it buys is a
different *shape* of outcome, not a better expectation.

So this module answers the question the marketing avoids: what does the round
robin actually return, leg by leg, compared with putting the same total stake
on singles?

Two things it refuses to fake:

**Correlation.** Legs from the same game are not independent, and a round
robin built from them is mispriced by any independent model — usually in the
book's favour on the downside and the bettor's on the upside. `correlation.py`
exists for this. When the caller says the legs are correlated, the
independent numbers are labelled as a bound rather than an estimate.

**The break-even.** The interesting number is not the expected value, it is
how many legs must land before the ticket is above water. That is what a
person actually wants to know, and no calculator that prints a single EV
figure tells them.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from math import comb

from .odds import OddsError


@dataclass
class RoundRobin:
    """A round robin priced against the singles it replaces."""

    legs: list[float]                  # decimal odds
    sizes: list[int]                   # parlay sizes, e.g. [2, 3]
    stake_each: float
    probs: list[float] | None = None   # per-leg win probability, if known
    correlated: bool = False

    @property
    def tickets(self) -> int:
        return sum(comb(len(self.legs), k) for k in self.sizes)

    @property
    def total_stake(self) -> float:
        return self.tickets * self.stake_each

    def payouts(self) -> list[tuple[tuple[int, ...], float]]:
        """Every ticket, as (leg indices, decimal payout)."""
        out = []
        for size in self.sizes:
            for picks in combinations(range(len(self.legs)), size):
                price = 1.0
                for i in picks:
                    price *= self.legs[i]
                out.append((picks, price))
        return out

    def returned_if(self, winners: set[int]) -> float:
        """Total returned when exactly this set of legs wins."""
        total = 0.0
        for picks, price in self.payouts():
            if set(picks) <= winners:
                total += self.stake_each * price
        return total

    def by_leg_count(self) -> list[dict]:
        """Return and profit for each number of winning legs.

        Computed over the best and worst actual combinations rather than an
        average, because with mixed prices "3 legs won" is not one number and
        reporting the mean as if it were is the kind of tidy answer that is
        wrong exactly when it matters.
        """
        rows = []
        for count in range(len(self.legs) + 1):
            returns = [self.returned_if(set(w))
                       for w in combinations(range(len(self.legs)), count)]
            lo, hi = min(returns), max(returns)
            rows.append({
                "legs_won": count,
                "returned_low": round(lo, 2),
                "returned_high": round(hi, 2),
                "profit_low": round(lo - self.total_stake, 2),
                "profit_high": round(hi - self.total_stake, 2),
                "always_profitable": lo > self.total_stake,
                "never_profitable": hi < self.total_stake,
            })
        return rows

    def breakeven_legs(self) -> int:
        """Fewest winning legs that always clears the total stake.

        Always exists. Every ticket pays more than the stake on it, so a full
        sweep cashes all of them and necessarily beats the total — there is no
        round robin that cannot profit, only ones that need nearly everything.
        A "cannot profit" branch was written here first and then deleted: it
        was unreachable, and an unreachable branch is a claim no test can
        check.
        """
        for row in self.by_leg_count():
            if row["always_profitable"]:
                return row["legs_won"]
        raise AssertionError("a full sweep must clear the stake")

    def expected_value(self) -> dict | None:
        """EV, only if the caller supplied probabilities.

        Returns None otherwise. A round robin EV computed from the book's own
        prices is a statement about the book's margin, not about the bet, and
        printing it as though it were an edge is the single most misleading
        thing this module could do.
        """
        if not self.probs:
            return None
        ev = 0.0
        for picks, price in self.payouts():
            p = 1.0
            for i in picks:
                p *= self.probs[i]
            ev += p * self.stake_each * price
        ev -= self.total_stake
        singles = sum(self.stake_each * len(self.sizes) *
                      (self.probs[i] * self.legs[i] - 1.0)
                      for i in range(len(self.legs)))
        return {
            "expected_profit": round(ev, 2),
            "expected_roi": round(ev / self.total_stake, 6),
            "same_money_on_singles": round(singles, 2),
            "singles_are_better": singles > ev,
            "independence": "assumed" if not self.correlated else
                            "violated — treat these as a bound, not an estimate",
        }


def build(legs: list[float], sizes: list[int], stake_each: float,
          probs: list[float] | None = None,
          correlated: bool = False) -> RoundRobin:
    if len(legs) < 2:
        raise OddsError("a round robin needs at least two legs")
    for price in legs:
        if price <= 1.0:
            raise OddsError(f"decimal odds must exceed 1.0, got {price}")
    if not sizes:
        raise OddsError("a round robin needs at least one parlay size")
    for size in sizes:
        if size < 2:
            raise OddsError(f"parlay size must be at least 2, got {size}")
        if size > len(legs):
            raise OddsError(
                f"cannot make {size}-leg parlays from {len(legs)} legs")
    if stake_each <= 0:
        raise OddsError("stake must be positive")
    if probs is not None:
        if len(probs) != len(legs):
            raise OddsError(
                f"{len(probs)} probabilities for {len(legs)} legs")
        for p in probs:
            if not 0.0 < p < 1.0:
                raise OddsError(f"probability must be between 0 and 1, got {p}")
    return RoundRobin(list(legs), sorted(sizes), stake_each, probs, correlated)
