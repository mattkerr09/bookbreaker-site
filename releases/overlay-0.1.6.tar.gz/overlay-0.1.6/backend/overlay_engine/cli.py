"""Overlay CLI — drive the engine from a terminal.

Installed, every example below is spelled `overlay`; from a checkout it is
`python3 backend/cli.py`. The two are the same program — `backend/cli.py` is a
shim onto this module, so a bug can only be fixed in one place.

    overlay demo
    overlay devig -110 -110
    overlay devig +250 -300 --index 0
    overlay arb 2.10 2.05 --stake 1000
    overlay fill --book dk --market player_points --age 25
    overlay kelly --odds +150 --prob 0.45 --bankroll 5000

The demo runs a full market through the whole pipeline and prints the working,
because a screen that shows a number without its derivation cannot be checked.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from overlay_engine import (
    AccountHeat,
    Book,
    BookTier,
    FillModel,
    Market,
    Outcome,
    Quote,
    arb_margin,
    devig_all,
    fair_value,
    find_arbs,
    find_edges,
    kelly_fraction,
    parse_odds,
    shape,
    size_bet,
    stake_arb,
)
from overlay_engine.odds import decimal_to_american, hold, overround
from overlay_engine.pricing import fair_for
from overlay_engine.staleness import PRIOR_LATENCY

NOW = 1_700_000_000.0

DEFAULT_BOOKS = {
    "pinnacle": Book("pinnacle", "Pinnacle", BookTier.SHARP, limits_winners=False),
    "circa": Book("circa", "Circa", BookTier.SHARP, limits_winners=False),
    "kalshi": Book("kalshi", "Kalshi", BookTier.EXCHANGE, commission=0.0,
                   limits_winners=False),
    "betfair": Book("betfair", "Betfair", BookTier.EXCHANGE, commission=0.02,
                    limits_winners=False),
    "dk": Book("dk", "DraftKings", BookTier.RETAIL),
    "fd": Book("fd", "FanDuel", BookTier.RETAIL),
    "mgm": Book("mgm", "BetMGM", BookTier.RETAIL),
}


def _fmt_odds(decimal: float) -> str:
    a = decimal_to_american(decimal)
    return f"{a:+.0f} ({decimal:.3f})"



# --------------------------------------------------------------- machine mode

def emit(payload: dict) -> int:
    """Print a result as JSON and return 0.

    A user interface cannot parse the tables this CLI prints, and the wrong fix
    is to reimplement the arithmetic wherever the interface happens to be
    written. That would put a second copy of the devig, a second Kelly and a
    second fill model behind glass, gated by nothing, free to disagree with the
    engine the site's figures come from.

    So the engine stays the only implementation and grows a machine-readable
    mouth. Every `--json` payload carries the same numbers the human output
    prints, from the same call.
    """
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def cmd_parlay(args: argparse.Namespace) -> int:
    """Price a parlay against what it should pay.

    The engine has had this arithmetic since parlay.py landed and the site has
    two pages arguing from it, but nothing exposed it to a person or to the
    window. A parlay is the most-searched calculation in betting and the worst
    priced, so it is the obvious thing for the app to answer.
    """
    from overlay_engine.parlay import correlation_note, value

    decimals = [parse_odds(o) for o in args.odds]
    priced = value(decimals)
    note = correlation_note(same_game=args.same_game)

    if args.json:
        return emit({
            "command": "parlay",
            "legs": priced.legs,
            "decimals": decimals,
            "offered": priced.offered,
            "fair": priced.fair,
            "pays": priced.offered - 1.0,
            "fair_pays": priced.fair - 1.0,
            "hold": priced.hold,
            "leg_hold": priced.leg_hold,
            "multiple": priced.multiple,
            "ev": priced.ev,
            "same_game": args.same_game,
            "correlation_note": note,
        })

    print(f"{priced.legs} legs: {', '.join(_fmt_odds(d) for d in decimals)}")
    print(f"  pays        {priced.offered - 1:.2f} to 1")
    print(f"  fair        {priced.fair - 1:.2f} to 1")
    print(f"  hold        {priced.hold:.1%}"
          f"   ({priced.multiple:.1f}x the {priced.leg_hold:.2%} on a single)")
    print(f"  EV per unit {priced.ev:+.2%}")
    print()
    print(f"  {note}")
    return 0


def cmd_crashes(args: argparse.Namespace) -> int:
    """Show crash reports, and bundle them only if asked."""
    from overlay_engine import crash

    found = crash.reports()
    native = crash.CRASH_DIR / "native.log"

    if args.bundle:
        made = crash.bundle()
        if made is None:
            print("no crash reports to bundle")
            return 0
        print(f"bundled to {made}")
        print("Attach it to an email if you want to. Nothing was sent.")
        return 0

    # faulthandler opens native.log on every launch, so the file existing
    # means nothing; only bytes in it mean a native crash happened.
    native_bytes = native.stat().st_size if native.exists() else 0

    if not found and not native_bytes:
        print("no crash reports — nothing has crashed on this machine")
        return 0

    print(f"{len(found)} crash report(s) in {crash.CRASH_DIR}")
    for path in found[-10:]:
        try:
            data = json.loads(path.read_text())
            print(f"  {path.name}")
            print(f"    {data.get('exception')}: {data.get('message', '')[:70]}")
            print(f"    version {data.get('version')} · {data.get('kind')}")
        except Exception:                                # noqa: BLE001
            print(f"  {path.name}  (unreadable)")
    if native_bytes:
        print(f"  native.log  ({native_bytes} bytes of native stacks)")
    print()
    print("These stay on this machine. `overlay crashes --bundle` zips them")
    print("so you can send them yourself; nothing here uploads anything.")
    return 0


def cmd_roundrobin(args: argparse.Namespace) -> int:
    """Every parlay of a given size, and what each has to do to pay."""
    from overlay_engine import roundrobin

    legs = [parse_odds(x) for x in args.legs]
    probs = args.probs if args.probs else None
    rr = roundrobin.build(legs, args.by, args.stake, probs, args.correlated)
    rows = rr.by_leg_count()
    ev = rr.expected_value()
    breakeven = rr.breakeven_legs()

    if args.json:
        print(json.dumps({
            "command": "roundrobin", "legs": legs, "sizes": rr.sizes,
            "tickets": rr.tickets, "stake_each": rr.stake_each,
            "total_stake": rr.total_stake, "breakeven_legs": breakeven,
            "by_leg_count": rows, "expected_value": ev,
        }, sort_keys=True))
        return 0

    print(f"{rr.tickets} tickets at {rr.stake_each:,.2f} = "
          f"{rr.total_stake:,.2f} at risk")
    print()
    print(f"  {'legs won':>9}  {'returns':>21}  {'profit':>21}")
    for row in rows:
        rng = (f"{row['returned_low']:>9,.2f}" if
               row['returned_low'] == row['returned_high']
               else f"{row['returned_low']:>9,.2f}–{row['returned_high']:,.2f}")
        prof = (f"{row['profit_low']:>9,.2f}" if
                row['profit_low'] == row['profit_high']
                else f"{row['profit_low']:>9,.2f}–{row['profit_high']:,.2f}")
        print(f"  {row['legs_won']:>9}  {rng:>21}  {prof:>21}")
    print()
    print(f"  {breakeven} of {len(legs)} legs must land before the ticket "
          f"is above water.")
    if ev:
        print(f"  Expected profit {ev['expected_profit']:,.2f} "
              f"({ev['expected_roi']:+.2%}); the same money on singles returns "
              f"{ev['same_money_on_singles']:,.2f}.")
        if ev["singles_are_better"]:
            print("  The singles are better. A round robin buys a different "
                  "shape of outcome, not a better expectation.")
        print(f"  Independence: {ev['independence']}.")
    else:
        print("  No probabilities given, so no expected value. An EV computed "
              "from the book's own prices describes its margin, not your edge.")
    return 0


def cmd_poisson(args: argparse.Namespace) -> int:
    """Scorelines from two scoring rates, and where the model stops."""
    from overlay_engine import poisson

    model = poisson.build(args.home, args.away)
    out = model.outcomes()
    totals = model.total_over(args.line)
    tops = model.top_scorelines(6)
    against = (poisson.disagreement(totals["over"], parse_odds(args.over_odds))
               if args.over_odds else None)

    if args.json:
        print(json.dumps({
            "command": "poisson", "home_lambda": args.home,
            "away_lambda": args.away, "outcomes": out, "totals": totals,
            "top_scorelines": tops, "versus_book": against,
        }, sort_keys=True))
        return 0

    print(f"Home {args.home} vs away {args.away} expected goals\n")
    print(f"  home {out['home']:>7.2%}   draw {out['draw']:>7.2%}   "
          f"away {out['away']:>7.2%}")
    print()
    print(f"  total {args.line}:  over {totals['over']:.2%}   "
          f"under {totals['under']:.2%}"
          + (f"   push {totals['push']:.2%}" if totals["pushes"] else ""))
    print()
    print("  most likely scorelines")
    for row in tops:
        print(f"    {row['score']:<6} {row['prob']:.2%}")
    if against:
        print()
        print(f"  book implies {against['book_implied']:.2%} on the over; "
              f"this model says {against['model']:.2%}")
        print(f"  edge under this model: "
              f"{against['edge_under_this_model']:+.2%}")
    print()
    print("  Poisson assumes the two sides score independently. They do not:")
    print("  real scorelines carry more draws and more blowouts than this.")
    return 0


def cmd_lowhold(args: argparse.Namespace) -> int:
    """The cheapest way to turn money over, and what it still costs."""
    from overlay_engine import lowhold

    quotes = []
    for raw in args.quotes:
        parts = raw.split(":")
        if len(parts) != 3:
            raise LedgerError(
                f"expected book:side:price, got {raw!r}")
        quotes.append(lowhold.Quote(parts[0], parts[1], parse_odds(parts[2])))

    ranked = lowhold.best(quotes, limit=args.top)
    baseline = lowhold.single_book_baseline(quotes)
    top = ranked[0]

    if args.json:
        print(json.dumps({
            "command": "lowhold",
            "turnover": args.turnover,
            "best": {"hold": top.hold, "is_arb": top.is_arb,
                     "cost": top.cost_of(args.turnover),
                     "picks": [{"book": q.book, "side": q.side,
                                "decimal": q.decimal} for q in top.picks],
                     "stakes": top.stakes(args.turnover)},
            "single_book_baseline": (
                {"hold": baseline.hold, "cost": baseline.cost_of(args.turnover),
                 "book": baseline.picks[0].book} if baseline else None),
            "ranked": [{"hold": p.hold, "cost": p.cost_of(args.turnover),
                        "picks": [f"{q.book} {q.side} {q.decimal}"
                                  for q in p.picks]} for p in ranked],
        }, sort_keys=True))
        return 0

    cost = top.cost_of(args.turnover)
    print(f"Turning over {args.turnover:,.2f}\n")
    for rank, pairing in enumerate(ranked, 1):
        legs = "  ".join(f"{q.book} {q.side} @ {q.decimal:g}"
                         for q in pairing.picks)
        marker = "  <- arbitrage" if pairing.is_arb else ""
        print(f"  {rank}. hold {pairing.hold:+.3%}   costs "
              f"{pairing.cost_of(args.turnover):>10,.2f}   {legs}{marker}")
    print()
    if baseline:
        saved = baseline.cost_of(args.turnover) - cost
        print(f"  Cheapest without leaving one book: {baseline.hold:+.3%}, "
              f"costing {baseline.cost_of(args.turnover):,.2f}.")
        print(f"  Splitting it across books saves {saved:,.2f}.")
    else:
        print("  No single book prices every side, so there is no "
              "same-book baseline to compare against.")
    print()
    if top.is_arb:
        print(f"  This one is an arbitrage: it makes "
              f"{abs(cost):,.2f} rather than costing anything.")
    elif abs(cost) < 0.01:
        # "This still costs 0.00" is true and reads like a bug. The two
        # prices cancel; say that instead of printing a rounded zero.
        print(f"  The two prices cancel: at {args.turnover:,.2f} of turnover "
              f"this costs nothing measurable.")
        print("  That is a fair market found across two books, not an edge — "
              "there is no profit in it either.")
    else:
        print(f"  This still costs {cost:,.2f}. Low hold is cheaper than the "
              f"obvious way, not free —")
        print(f"  whether the turnover is worth {cost:,.2f} is your call, and "
              f"nothing here decides it for you.")
    print()
    print("  Stakes for that pairing:")
    for leg in top.stakes(args.turnover):
        print(f"    {leg['book']:<8} {leg['side']:<8} "
              f"stake {leg['stake']:>10,.2f}   returns {leg['returns']:>10,.2f}")
    return 0


def cmd_board(args: argparse.Namespace) -> int:
    """Every play on one board, best first.

    The screen someone who has used OddsJam or AVO expects to open to. It
    exists to answer "what should I bet right now", which is the question a
    bettor actually has, rather than "what is this price worth", which is the
    one every other command here answers.

    **Where the prices come from is printed every time.** With `--snapshot`
    they are recorded prices from that file. Without one, there is a single
    demonstration market and the board says so — because a board full of
    plausible rows is an instruction to go and stake real money on markets
    that do not exist, and that is the most expensive thing this program
    could get wrong.
    """
    from overlay_engine import board as board_mod

    if getattr(args, "live", False):
        from overlay_engine import pubfeed

        # Single-game series, not the bare market list: the latter is
        # dominated by combination contracts and long-horizon politics, where
        # no arbitrage can exist by construction.
        quotes = pubfeed.kalshi_games()
        try:
            quotes.extend(pubfeed.PolymarketProvider().fetch())
        except Exception as exc:                         # noqa: BLE001
            print(f"polymarket: {exc}", file=sys.stderr)

        arbs = pubfeed.find_public_arbs(quotes,
                                        min_margin=args.min_margin / 100.0
                                        if args.min_margin else None
                                        or pubfeed.MIN_WORTHWHILE_MARGIN)
        paired = pubfeed.complete_books(quotes)
        source = (f"LIVE — {len(quotes)} quotes, {len(paired)} paired games, "
                  f"{len(arbs)} playable")
        if args.json:
            print(json.dumps({
                "command": "board", "source": source, "live": True,
                "markets_scanned": len({q["event"] for q in quotes}),
                "bankroll": args.bankroll, "quotes": quotes, "rows": [],
                "note": ("Cross-venue arbitrage needs the same event matched "
                         "between venues, which is not built yet. These are "
                         "live prices, not plays."),
            }, indent=2, sort_keys=True))
            return 0
        print(f"source: {source}\n")
        if arbs:
            print(f"{'MARGIN':>7}  {'COST':>7}  PLAY")
            for a in arbs:
                legs = "  /  ".join(f"{l['outcome']} at {l['price']:.2f}"
                                    for l in a["legs"])
                print(f"{a['margin']:>7.2%}  {a['cost']:>7.4f}  {a['title'][:46]}")
                print(f"{'':>7}  {'':>7}  {legs}")
        else:
            print(f"No arbitrage across {len(paired)} paired games.")
            print("That is the normal state of a liquid venue — both sides of")
            print("a binary contract summing to 1.0000 is the market working,")
            print("not an opportunity. Nothing is listed rather than listing")
            print("a zero-margin play as though it were one.")
        print(f"\nPublic, keyless endpoints. Retail books need an aggregator;")
        print("cross-venue pairing needs entity matching and is not built.")
        return 0

    if args.snapshot:
        from overlay_engine.feed import ReplayProvider
        provider = ReplayProvider(args.snapshot)
        markets = [m for sport in provider.sports() for m in provider.fetch(sport)]
        source = f"recorded snapshot {args.snapshot}"
        live = False
    else:
        markets = [_demo_market()]
        source = "ONE DEMONSTRATION MARKET — no feed is connected"
        live = False

    # Recorded prices are aged against the recording, not against the wall
    # clock. Scanning a snapshot from last Tuesday with now=time.time() made
    # every quote 87,109,150 seconds old and every fill zero — an age column
    # that is nonsense is worse than no age column, because the whole product
    # argument is that age is what you are not being told.
    stamps = [q.seen_at for m in markets for q in m.quotes
              if getattr(q, "seen_at", None)]
    as_of = max(stamps) if stamps else None

    kinds = tuple(args.kind) if args.kind else board_mod.KINDS
    rows = board_mod.scan(markets, DEFAULT_BOOKS, bankroll=args.bankroll,
                          min_margin=args.min_margin / 100.0, now=as_of,
                          kinds=kinds, min_ev=args.min_ev / 100.0)

    if args.json:
        print(json.dumps({
            "command": "board", "source": source, "live": live,
            "markets_scanned": len(markets), "bankroll": args.bankroll,
            "rows": [r.as_dict() for r in rows],
        }, indent=2, sort_keys=True))
        return 0

    print(f"source: {source}")
    print(f"scanned {len(markets)} market(s) at a {args.bankroll:,.0f} bankroll\n")
    if not rows:
        asked = ", ".join(kinds)
        print(f"nothing on the board ({asked}).")
        print("That is the normal state of a small board, not a failure —")
        print("connect a feed with --snapshot to scan real markets.")
        return 0

    # An arb's profit is guaranteed; a +EV bet's is an average over many
    # bets and can lose every time; a middle's is a payoff that needs the
    # result to land in a window. Printing one PROFIT column across all
    # three would imply they are the same kind of number, which is the most
    # misleading thing a mixed board can do.
    basis = {"arb": "guaranteed", "ev": "expected", "middle": "if it lands"}
    print(f"{'KIND':<7}{'RETURN':>9}  {'EDGE':>7}  {'FILL':>5}  {'AGE':>5}  PLAY")
    for row in rows:
        legs = "  vs  ".join(
            f"{leg['book']} {leg['outcome']} @{leg['decimal']:.3f} "
            f"for {leg['stake']:,.2f}" for leg in row.legs)
        print(f"{row.kind:<7}{row.profit:>9,.2f}  {row.margin:>6.2%}  "
              f"{row.p_fill:>5.0%}  {row.age:>4.0f}s  {row.event} {row.market}")
        print(f"{'':<7}{basis[row.kind]:>9}  {legs}")

    counts = {k: sum(1 for r in rows if r.kind == k) for k in board_mod.KINDS}
    print(f"\n{len(rows)} play(s): "
          + ", ".join(f"{n} {k}" for k, n in counts.items() if n))
    print("An arb's return is guaranteed. A +EV return is an AVERAGE over many")
    print("bets and can lose every one of them. A middle pays only if the")
    print("result lands in the window. They are not the same number.")
    return 0


def cmd_welcome(args: argparse.Namespace) -> int:
    """Every welcome offer, ranked by what it converts to, with the steps."""
    from overlay_engine import welcome

    rows = welcome.load()
    priced = welcome.price(rows, bonus_decimal=args.bonus_odds, hold=args.hold / 100.0)
    assumptions = (f"PRIORS: bonus bets placed at decimal {args.bonus_odds:.2f}, "
                   f"{args.hold:.1f}% combined hold across the best two books")

    if args.json:
        print(json.dumps({"command": "welcome", "assumptions": assumptions,
                          "max_age_days": welcome.MAX_AGE_DAYS,
                          "offers": [p.as_dict() for p in priced]},
                         indent=2, sort_keys=True))
        return 0

    print(assumptions)
    print("Ranked by what you KEEP, not by the headline.\n")
    total = 0.0
    for p in priced:
        if p.stale:
            print(f"  {p.book:<9} STALE — read {p.read}, {p.age_days} days ago. Not priced.")
            continue
        worth = (f"{p.guaranteed:>8,.2f} guaranteed" if p.guaranteed
                 else f"{p.expected:>8,.2f} expected (not guaranteed)")
        print(f"  {p.book:<9} {worth}   {p.headline}")
        for step in p.steps:
            print(f"             - {step}")
        print(f"             source: {p.source}  (read {p.read})\n")
        total += p.guaranteed
    print(f"{total:,.2f} guaranteed across every offer above, if you are in a state that has them all.")
    print("Offers vary by state and change monthly. Check each source before you sign up.")
    return 0


def cmd_devig(args: argparse.Namespace) -> int:
    decimals = [parse_odds(o) for o in args.odds]
    spread = devig_all(decimals)

    if args.json:
        return emit({
            "command": "devig",
            "decimals": decimals,
            "overround": overround(decimals),
            "hold": hold(decimals),
            "methods": list(spread.methods),
            "outcomes": [
                {
                    "index": i,
                    "by_method": {m: spread.by_method[m][i]
                                  for m in spread.methods},
                    "consensus": spread.consensus(i),
                    "spread": spread.spread(i),
                }
                for i in range(len(decimals))
            ],
            "failed": dict(spread.failed),
        })

    print(f"market: {', '.join(_fmt_odds(d) for d in decimals)}")
    print(f"overround {overround(decimals):.4f}   hold {hold(decimals):.2%}")
    print()

    header = "outcome  " + "".join(f"{m:>16}" for m in spread.methods)
    print(header + f"{'consensus':>12}{'spread':>10}")
    for i in range(len(decimals)):
        row = f"{i:<9}"
        for m in spread.methods:
            row += f"{spread.by_method[m][i]:>15.2%} "
        row += f"{spread.consensus(i):>11.2%}{spread.spread(i):>10.2%}"
        print(row)

    for method, why in spread.failed.items():
        print(f"\n{method}: no solution — {why}")

    if args.index is not None:
        i = args.index
        print()
        print(f"outcome {i}: fair {spread.consensus(i):.2%}, "
              f"worst case {spread.low(i):.2%}")
        print(f"  break-even price {_fmt_odds(1 / spread.consensus(i))}")
        print(f"  bet is +EV above {_fmt_odds(1 / spread.low(i))} "
              f"under every method")
    return 0


def cmd_arb(args: argparse.Namespace) -> int:
    decimals = [parse_odds(o) for o in args.odds]
    margin = arb_margin(decimals)

    if args.json:
        # No arbitrage is a result, not an error: a UI needs to render "these
        # prices do not cross" rather than receive nothing and guess why.
        if margin <= 0:
            return emit({
                "command": "arb", "decimals": decimals, "margin": margin,
                "arbitrage": False,
                "total_implied": sum(1 / d for d in decimals),
                "loss_per_unit": abs(margin),
            })
        exact = stake_arb(decimals, total=args.stake, round_stakes=False)
        plan = stake_arb(decimals, total=args.stake)
        return emit({
            "command": "arb",
            "decimals": decimals,
            "total_implied": sum(1 / d for d in decimals),
            "margin": margin,
            "arbitrage": True,
            "exact_profit": exact.profit,
            "total_stake": plan.total_stake,
            "profit": plan.profit,
            "ideal_profit": plan.ideal_profit,
            "roi": plan.roi,
            "rounded": plan.rounded,
            "rounding_cost": plan.rounding_cost,
            "legs": [{"decimal": leg.decimal, "stake": leg.stake,
                      "returns": leg.stake * leg.decimal} for leg in plan.legs],
        })

    print(f"legs: {', '.join(_fmt_odds(d) for d in decimals)}")
    print(f"total implied {sum(1 / d for d in decimals):.4f}")
    if margin <= 0:
        print(f"no arbitrage — you would lose {abs(margin):.2%} of turnover")
        return 1
    print(f"margin {margin:.2%} guaranteed")
    print()

    exact = stake_arb(decimals, total=args.stake, round_stakes=False)
    plan = stake_arb(decimals, total=args.stake)

    print("exact stakes (the number every other calculator gives you):")
    for leg in exact.legs:
        print(f"  {leg.stake:>10.2f} at {_fmt_odds(leg.decimal)}")
    print(f"  profit {exact.profit:.2f} on {exact.total_stake:.2f}"
          f"  ({exact.roi:.2%})")
    print()

    label = "round stakes" if plan.rounded else "round stakes (none held the arb)"
    print(f"{label}:")
    for leg in plan.legs:
        print(f"  {leg.stake:>10.0f} at {_fmt_odds(leg.decimal)}")
    print(f"  profit {plan.profit:.2f} on {plan.total_stake:.2f}"
          f"  ({plan.roi:.2%})")
    if plan.rounded:
        print(f"  rounding cost {plan.rounding_cost:.2f}"
              f" — paid to not look like a bot")
    return 0


def cmd_fill(args: argparse.Namespace) -> int:
    from overlay_engine import LatencyModel
    from overlay_engine.ledger import Ledger

    model = FillModel()
    latency = LatencyModel()
    if args.db:
        with Ledger(args.db) as db:
            model = db.fill_model()
            latency = db.latency_model()

    tau = model.tau(args.book, args.market)
    fitted = model.is_fitted(args.book, args.market)
    lag = latency.typical(args.book)
    measured_lag = latency.is_measured(args.book)

    # Latency is a floor under quote age, so a fill probability quoted without
    # it is the optimistic answer to a question nobody asked.
    effective = args.age + lag
    p = model.p_fill(args.book, args.market, effective)
    naive = model.p_fill(args.book, args.market, args.age)

    if args.json:
        return emit({
            "command": "fill",
            "book": args.book,
            "market": args.market,
            "age": args.age,
            "effective_age": effective,
            "latency": lag,
            "latency_measured": measured_lag,
            "tau": tau,
            "tau_measured": fitted,
            "half_life": model.half_life(args.book, args.market),
            "fill": p,
            "fill_naive": naive,
            "edge": 0.04,
            "edge_realised": 0.04 * p,
        })

    print(f"{args.book} / {args.market}")
    print(f"  mean quote life  {tau:.0f}s"
          f"  ({'measured' if fitted else 'prior — nothing observed yet'})")
    print(f"  half life        {model.half_life(args.book, args.market):.0f}s")
    print(f"  feed latency     {lag:.1f}s"
          f"  ({'measured' if measured_lag else 'prior — no dated quotes yet'})")
    print()
    print(f"  a quote {args.age:.0f}s old is really {effective:.0f}s old once the"
          " feed's lag is counted")
    print(f"  still there: {p:.0%}   (a screen ignoring latency would say"
          f" {naive:.0%})")
    print()
    print("  a 4% edge at this age is really "
          f"{0.04 * p:.2%} after the chance of not getting on")
    return 0


def cmd_kelly(args: argparse.Namespace) -> int:
    decimal = parse_odds(args.odds)
    sizing = size_bet(
        decimal, args.prob, bankroll=args.bankroll,
        fraction=args.fraction, prob_low=args.prob_low,
    )
    if args.json:
        return emit({
            "command": "kelly",
            "decimal": decimal,
            "prob": args.prob,
            "bankroll": args.bankroll,
            "fraction": args.fraction,
            "full_kelly": sizing.full_kelly,
            "stake": sizing.stake,
            "stake_fraction": (sizing.stake / args.bankroll
                               if args.bankroll else 0.0),
            "binding": sizing.binding,
            "prob_low": args.prob_low,
        })

    print(f"price {_fmt_odds(decimal)}   fair {args.prob:.2%}"
          f"   bankroll {args.bankroll:,.0f}")
    print(f"  full kelly      {sizing.full_kelly:.2%} of bankroll")
    print(f"  at {args.fraction:.0%} kelly   {sizing.stake:,.2f}"
          f"  ({sizing.bankroll_share:.2%})")
    print(f"  binding constraint: {sizing.binding}")
    if args.prob_low is not None:
        print(f"  sized on the conservative {args.prob_low:.2%}, not {args.prob:.2%}")
    return 0


def _demo_market() -> Market:
    """An NBA total where DraftKings is a step behind the sharp market."""
    prices = [
        ("pinnacle", "over", 220.5, 1.952),
        ("pinnacle", "under", 220.5, 1.952),
        ("circa", "over", 220.5, 1.935),
        ("circa", "under", 220.5, 1.970),
        ("dk", "over", 220.5, 2.100),
        ("dk", "under", 220.5, 1.740),
        ("fd", "over", 220.5, 1.980),
        ("fd", "under", 220.5, 1.870),
        ("mgm", "over", 220.5, 1.909),
        ("mgm", "under", 220.5, 1.909),
    ]
    quotes = [
        Quote(book=b, outcome=Outcome(name=n, line=line), decimal=d, seen_at=NOW - 6)
        for b, n, line, d in prices
    ]
    return Market(
        event_id="nba_2026_bos_lal",
        sport="basketball_nba",
        market_type="totals",
        quotes=quotes,
        starts_at=NOW + 5400,
    )


def cmd_demo(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger
    from overlay_engine.pricing import PricingContext, context_for, price_market

    market = _demo_market()
    books = DEFAULT_BOOKS

    # Priced through the same entry point everything else uses. A demo that
    # assembled the learned parts by hand would drift from the product and
    # quietly stop demonstrating it.
    if args.db:
        with Ledger(args.db) as db:
            ctx = context_for(db, books, market)
    else:
        ctx = PricingContext.uncalibrated(books)
    fills = ctx.fill

    print("=" * 72)
    print("BOS @ LAL — total 220.5, quotes 6 seconds old")
    print("=" * 72)
    for q in market.quotes:
        book = books[q.book]
        print(f"  {book.name:<12} {q.outcome.name:<6} {_fmt_odds(q.decimal)}"
              f"   [{book.tier.value}]")

    print()
    print("-- fair value " + "-" * 58)
    fairs = fair_for(market, ctx)
    for key, fv in fairs.items():
        print(f"  {key:<14} {fv.prob:.2%}"
              f"   band {fv.low:.2%}–{fv.high:.2%}"
              f"   fair price {_fmt_odds(fv.fair_decimal)}")
        print(f"  {'':<14} anchored: {fv.anchored}"
              f"   contributors: {', '.join(sorted(fv.contributors))}")

    print()
    print("-- edges, ranked by the EV you can actually realise " + "-" * 20)
    print(f"  calibration: {ctx.describe()}")
    edges = price_market(market, ctx, now=NOW)
    if not edges:
        print("  none")
    for e in edges:
        print(f"  {books[e.book].name:<12} {e.outcome:<14} {_fmt_odds(e.decimal)}")
        print(f"  {'':<12} EV {e.ev:+.2%}  band {e.ev_low:+.2%}..{e.ev_high:+.2%}"
              f"  fill {e.p_fill:.0%}  ->  realised {e.realised_ev:+.2%}")
        print(f"  {'':<12} robust: {e.robust}"
              + (f"   note: {e.note}" if e.note else ""))

    print()
    print("-- arbitrage " + "-" * 59)
    arbs = find_arbs(market, books, now=NOW)
    if not arbs:
        best_over = market.best("over@220.5")
        best_under = market.best("under@220.5")
        implied = 1 / best_over.decimal + 1 / best_under.decimal
        print(f"  none — best of both sides still implies {implied:.4f}"
              f" ({(implied - 1):.2%} against you)")
    for a in arbs:
        print(f"  margin {a['margin']:.2%} gross")
        for leg in a["legs"]:
            print(f"    {books[leg['book']].name:<12} {leg['outcome']:<14}"
                  f" {_fmt_odds(leg['decimal'])}")
        decimals = [leg["net_decimal"] for leg in a["legs"]]
        exact = stake_arb(decimals, total=args.bankroll * 0.1, round_stakes=False)
        plan = stake_arb(
            decimals,
            total=args.bankroll * 0.1,
            books=[leg["book"] for leg in a["legs"]],
            outcomes=[leg["outcome"] for leg in a["legs"]],
        )
        print(f"    exact  {' / '.join(f'{l.stake:.2f}' for l in exact.legs)}"
              f"  -> {exact.profit:.2f} guaranteed")
        print(f"    round  {' / '.join(f'{l.stake:.0f}' for l in plan.legs)}"
              f"  -> {plan.profit:.2f} guaranteed"
              f"  (costs {plan.rounding_cost:.2f} to look human)")

    print()
    print("-- sizing and account heat " + "-" * 45)
    account = AccountHeat()
    for e in edges[:1]:
        sizing = size_bet(
            e.decimal, e.fair_prob, bankroll=args.bankroll,
            prob_low=e.fair_prob - (e.ev - e.ev_low) / e.decimal,
        )
        shaped = shape(e.book, sizing.stake, e.ev, account, books, now=NOW)
        print(f"  {books[e.book].name} {e.outcome} at {_fmt_odds(e.decimal)}")
        print(f"    kelly says       {sizing.stake:,.2f}  ({sizing.binding})")
        print(f"    shaped stake     {shaped.stake:,.0f}")
        print(f"    reason           {shaped.reason or 'none needed'}")
        print(f"    delay before bet {shaped.delay:.0f}s")

    print()
    print("Every number above is arithmetic on the ten prices at the top.")
    if ctx.calibrated:
        print(f"Priced with: {ctx.describe()}")
    else:
        print("Nothing here is fitted, because nothing has been observed yet —")
        print("every learned parameter is a stated prior, and says so.")
    return 0


def cmd_books(args: argparse.Namespace) -> int:
    from overlay_engine import catalog

    state = args.state.upper()
    summary = catalog.state_summary(state)

    print(f"{state} — {summary['venues']} venues"
          f"  (table read {summary['as_of']}, {summary['stale_days']} days ago)")
    if not summary["legal"]:
        print("  No legal sports betting in this state as of the table date.")
    if not summary["covered"]:
        print(f"  Coverage gap: {summary['gap_reason']}")
    if summary["retail_only"]:
        print(f"  Legal in person only — {summary['retail_only']}.")
        print("  Not a gap in this table: there is no online venue to list.")
    if summary["single_operator"]:
        print(f"  A single-operator market: {summary['single_operator']}.")
    print()

    for venue in catalog.for_state(state, include_unverified=args.unverified):
        flags = []
        if not venue.limits_winners:
            flags.append("never limits")
        if venue.commission:
            flags.append(f"{venue.commission:.1%} commission")
        if venue.jurisdiction_unknown:
            flags.append("JURISDICTION UNVERIFIED — check yourself")
        tag = f"  [{', '.join(flags)}]" if flags else ""
        print(f"  {venue.tier.value:<9} {venue.name:<20}{tag}")
        if venue.note:
            print(f"  {'':<9} {venue.note}")

    print()
    if summary["has_anchor"]:
        print(f"  {summary['anchors']} anchor venue(s) — +EV numbers here rest on"
              " a sharp or exchange price.")
    else:
        print("  No sharp or exchange venue. +EV here would be a poll of the"
              " books you intend to beat.")
    print(f"  Never limit winners: {', '.join(summary['never_limit']) or 'none'}")
    print()
    print("  Legality moves. This is a dated starting point for your own check,"
          " not advice;")
    print("  the book's own site decides whether it will accept you.")
    return 0


def cmd_promo(args: argparse.Namespace) -> int:
    from overlay_engine import promo
    from overlay_engine.catalog import for_state

    print("=" * 70)
    print("WELCOME OFFERS — what the headline is actually worth")
    print("=" * 70)

    hedge_pairs = [
        (american_to_decimal_safe(a), american_to_decimal_safe(h))
        for a, h in ((100, -110), (200, -230), (400, -450), (700, -800), (1200, -1400))
    ]
    hedge_pairs = [(a, h) for a, h in hedge_pairs if a and h]

    plan = promo.best_conversion(args.bonus, hedge_pairs, max_hedge=args.max_hedge)
    conv = plan.conversion if plan else 0.75

    print()
    print(f"-- converting a {args.bonus:,.0f} bonus bet " + "-" * 26)
    print(f"  {'free leg':>10}{'hedge at':>12}{'hedge stake':>14}"
          f"{'guaranteed':>13}{'rate':>8}")
    for free_odds, hedge_odds in hedge_pairs:
        p = promo.bonus_bet_conversion(free_odds, hedge_odds, args.bonus)
        over = args.max_hedge is not None and p.hedge_stake > args.max_hedge
        mark = "  (over your hedge limit)" if over else ""
        print(f"  {decimal_to_american(free_odds):>+10.0f}"
              f"{decimal_to_american(hedge_odds):>+12.0f}"
              f"{p.hedge_stake:>14,.0f}{p.guaranteed:>13,.0f}"
              f"{p.conversion:>8.1%}{mark}")

    print()
    if plan is None:
        print("  No hedgeable pair inside your hedge limit.")
    else:
        print(f"  best: {plan.describe()}")
        print(f"  ceiling at these odds in a no-vig market: "
              f"{promo.fair_conversion_ceiling(plan.free_leg_odds):.1%}")
        print(f"  a naive bet at even money returns about "
              f"{args.bonus * 0.5:,.0f} in expectation and nothing guaranteed")
    print()
    print("  The hedge column is the constraint the advice always omits. Longer")
    print("  odds convert better and need more cash at the second book — pass")
    print("  --max-hedge to see only the plans you can actually place.")

    print()
    print("-- offer types, at this conversion rate " + "-" * 30)

    bag = promo.bet_and_get_value(5.0, 0.045, args.bonus, conv)
    print(f"  bet-and-get {args.bonus:,.0f}")
    print(f"    guaranteed {bag.guaranteed:,.2f}"
          f"   ({bag.headline_ratio:.0%} of headline)")
    print(f"    {bag.note}")

    net = promo.safety_net_value(args.bonus, 4.0, 0.24, conv)
    print(f"  safety net {args.bonus:,.0f} at +300")
    print(f"    expected {net.expected:+,.2f}, guaranteed {net.guaranteed:,.2f}")
    print(f"    {net.note}")

    match = promo.deposit_match_value(args.bonus, args.bonus, rollover=10.0)
    print(f"  100% deposit match on {args.bonus:,.0f}, 10x rollover")
    print(f"    expected {match.expected:+,.2f} for "
          f"{10 * 2 * args.bonus:,.0f} of turnover")
    print(f"    {match.note}")

    if args.state:
        keys = [v.key for v in for_state(args.state)]
        order = promo.sequence(keys)
        print()
        print(f"-- claim order in {args.state.upper()} " + "-" * 40)
        print("  Open two bet-and-get books first: converting a bonus needs a")
        print("  hedge at a second book, so one account alone is worth little.")
        for i, (book, offer_type) in enumerate(order, 1):
            print(f"    {i:>2}. {book:<12} {offer_type.value}")
    return 0


def cmd_ledger(args: argparse.Namespace) -> int:
    from overlay_engine.clv import report as clv_report
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        stats = db.stats()
        print(f"ledger: {stats['path']}")
        print(f"  bets          {stats['bets']:>6}"
              f"   ({stats['graded']} graded, {stats['ungraded']} awaiting a close)")
        print(f"  attempts      {stats['attempts']:>6}"
              f"   ({stats['rejected']} rejected)")
        print(f"  quotes        {stats['quotes']:>6}"
              f"   ({stats['closing_quotes']} closing)")
        print(f"  books         {stats['books']:>6}")

        print()
        if stats["can_calibrate"]:
            print("  Enough graded bets to calibrate.")
        else:
            print(f"  {stats['graded_needed']} more graded bets before anything"
                  " can be calibrated.")
            print("  Until then every learned parameter is its shipped prior,"
                  " and says so.")

        graded = db.graded_bets()
        if graded:
            rep = clv_report(graded)
            print()
            print(f"  CLV: {rep.verdict()}")
            print(f"  beat the close on {rep.beat_rate:.0%} of"
                  f" {rep.n} bets, {rep.total_staked:,.0f} staked")

        from overlay_engine.calibrate import weights_for

        weights, age = weights_for(db)
        print()
        if weights is None:
            print("  devig weights — none calibrated; all four methods equal.")
        else:
            best = max(weights, key=weights.get)
            print(f"  devig weights — measured {age / 86400:.1f} days ago,"
                  f" led by {best} at {weights[best]:.3f}")

        from overlay_engine.calibrate import book_weights_for

        book_w, book_age = book_weights_for(db)
        if book_w is None:
            print("  book weights  — none calibrated; tier defaults, which are"
                  " stated priors and not measurements.")
        else:
            best = max(book_w, key=book_w.get)
            print(f"  book weights  — measured {book_age / 86400:.1f} days ago,"
                  f" led by {best} at {book_w[best]:.3f}"
                  f" ({len(book_w)} books)")

        model = db.fill_model()
        fitted = [
            (book, klass) for (book, klass), n in model.counts.items() if n >= 5
        ]
        print()
        if fitted:
            print("  fill model — measured:")
            for book, klass in sorted(fitted):
                print(f"    {book:<12} {klass:<12}"
                      f" half life {model.half_life(book, klass):>5.0f}s"
                      f"  ({model.counts[(book, klass)]} attempts)")
        else:
            print("  fill model — no cell has 5+ attempts yet; all priors.")

        latency = db.latency_model()
        measured = [b for b in latency.counts if latency.is_measured(b)]
        if measured:
            print("  feed latency — measured:")
            for book in sorted(measured):
                print(f"    {book:<12} {latency.typical(book):>5.1f}s"
                      f"  ({latency.observations(book)} dated quotes)")
        else:
            print(f"  feed latency — no dated quotes yet; assuming"
                  f" {PRIOR_LATENCY:.0f}s, which is a prior, not a measurement.")
    return 0


def cmd_calibrate(args: argparse.Namespace) -> int:
    from overlay_engine.calibrate import calibrate_all
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        results = calibrate_all(db, holdout=args.holdout, write=not args.dry_run)

        print(f"ledger: {db.path}")
        if args.dry_run:
            print("dry run — nothing will be written")
        print()

        for r in sorted(results, key=lambda r: (not r.accepted, r.scope)):
            print(f"  {r.describe()}")
            if r.accepted:
                # Only the top few: a global scope can weight twenty books and
                # the tail is all at the floor, which is noise on a screen.
                ranked = sorted(r.weights.items(), key=lambda kv: -kv[1])
                for name, weight in ranked[:6]:
                    print(f"      {name:<16} {weight:.3f}")
                if len(ranked) > 6:
                    print(f"      ... {len(ranked) - 6} more at or near the floor")

        accepted = sum(1 for r in results if r.accepted)
        print()
        print(f"  {accepted} of {len(results)} scope(s) updated.")
        if accepted == 0:
            print("  Declining is a normal result — it means the weights already")
            print("  in place predict the closing line at least as well as any")
            print("  candidate fitted on the older part of the log.")
    return 0


def cmd_grade(args: argparse.Namespace) -> int:
    from overlay_engine.calibrate import weights_for
    from overlay_engine.grade import grade_pending
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        # Grade with the same weights the engine prices with. Grading against
        # a blend nothing else computes would measure CLV on a scale no other
        # number in the product uses.
        weights, _ = weights_for(db)
        report = grade_pending(db, require_anchor=not args.allow_retail,
                               method_weights=weights)

        print(f"ledger: {db.path}")
        print(f"  {report.describe()}")

        if report.skipped:
            print()
            print("  not graded:")
            for reason, n in report.reasons().items():
                print(f"    {n:>4}  {reason}")

        stats = db.stats()
        print()
        print(f"  {stats['graded']} graded, {stats['ungraded']} still waiting"
              f" on a close")
        if not stats["can_calibrate"]:
            print(f"  {stats['graded_needed']} more before anything can be"
                  " calibrated")
    return 0


def cmd_capture(args: argparse.Namespace) -> int:
    from overlay_engine.feed import FeedError, ReplayProvider, capture
    from overlay_engine.ledger import Ledger

    try:
        provider = ReplayProvider(args.snapshot)
    except FeedError as exc:
        print(f"cannot read snapshot: {exc}")
        return 1

    with Ledger(args.db) as db:
        report = capture(db, provider, sports=args.sport or None,
                         is_closing=args.closing)
        print(f"ledger: {db.path}")
        print(f"  provider: replay ({args.snapshot})")
        print(f"  {report.describe()}")

        if report.markets and not report.dated:
            print()
            print("  This feed dates none of its quotes, so staleness is")
            print("  inferred from a prior rather than measured. Fill")
            print("  probabilities from it are the optimistic answer.")

        latency = db.latency_model()
        measured = sorted(b for b in latency.counts if latency.is_measured(b))
        if measured:
            print()
            print("  measured feed latency:")
            for book in measured:
                print(f"    {book:<12} {latency.typical(book):>5.1f}s"
                      f"  ({latency.observations(book)} dated quotes)")
    return 0


def cmd_middles(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger
    from overlay_engine.middles import (
        MIN_GAMES, MIN_PER_CELL, MIN_TOTAL_GAMES, MarginModel, TotalsModel,
        find_middles)

    low, high = sorted((args.low, args.high))
    if low == high:
        print("a middle needs two different lines")
        return 1

    is_totals = args.market == "totals"
    model = totals_model = None
    games = 0
    per_cell = 0.0
    if args.db:
        with Ledger(args.db) as db:
            if is_totals:
                totals_model = TotalsModel.from_ledger(db)
                games = totals_model.games(args.sport)
                per_cell = totals_model.per_cell(args.sport)
            else:
                model = MarginModel.from_ledger(db)
                games = model.games(args.sport)

    market = Market(
        event_id="cli", sport=args.sport, market_type=args.market,
        quotes=[
            Quote(book="book-a", outcome=Outcome("over", low),
                  decimal=parse_odds(args.low_odds), seen_at=NOW),
            Quote(book="book-b", outcome=Outcome("under", high),
                  decimal=parse_odds(args.high_odds), seen_at=NOW),
        ],
    )
    plans = find_middles(market, {}, sport=args.sport, model=model,
                         totals_model=totals_model,
                         sigma=args.sigma, total=args.stake)
    if not plans:
        print("no middle between those lines")
        return 1

    plan = plans[0]
    print(f"{args.sport}: over {low:g} / under {high:g}")
    print(f"  stakes        {plan.low_stake:,.0f} at "
          f"{_fmt_odds(plan.low_decimal)} / {plan.high_stake:,.0f} at "
          f"{_fmt_odds(plan.high_decimal)}")
    print(f"  one side wins {plan.one_side_profit:+,.2f}")
    print(f"  middle hits   {plan.middle_profit:+,.2f}")
    print()
    print(f"  window probability  {plan.p_middle:.2%}  ({plan.source})")
    print(f"  break-even          {plan.breakeven_p:.2%}"
          "   — arithmetic on the two prices, no distribution involved")
    print(f"  expected value      {plan.ev:+.2%} per unit staked")
    print()
    noun = "totals" if is_totals else "margins"
    used = totals_model if is_totals else model
    floor = MIN_TOTAL_GAMES if is_totals else MIN_GAMES

    if plan.measured:
        print(f"  Counted from {games} recorded {args.sport} games.")
        keys = used.key_numbers(args.sport, top=3) if used else []
        if keys:
            shown = ", ".join(f"{v} ({q:.1%})" for v, q in keys)
            print(f"  Most common {noun}: {shown}")
    else:
        print(f"  A normal approximation, not a count. Real {noun} cluster on"
              " key numbers")
        print(f"  and no smooth curve reproduces that. Record {floor}"
              f" {args.sport} scores")
        print(f"  ({games} so far) and this becomes a measurement.")
        print(f"  Spread used: {plan.sigma:.2f} points ({plan.sigma_source}).")
        if is_totals and games >= MIN_TOTAL_GAMES and per_cell < MIN_PER_CELL:
            print(f"  Games are there ({games}) but spread thin —"
                  f" {per_cell:.1f} per distinct total against"
                  f" {MIN_PER_CELL:.0f} needed.")
            print("  Declined rather than counted off a handful of games"
                  " per bucket.")
    return 0


def cmd_performance(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger
    from overlay_engine.performance import from_ledger, to_csv

    filters = {
        "sport": args.sport, "book": args.book, "market_type": args.market,
        "min_decimal": args.min_odds and parse_odds(args.min_odds),
        "max_decimal": args.max_odds and parse_odds(args.max_odds),
    }
    filters = {k: v for k, v in filters.items() if v}

    with Ledger(args.db) as db:
        if args.csv:
            Path(args.csv).write_text(to_csv(db.settled_bets(**filters)))
            print(f"exported to {args.csv}")
            return 0

        rep = from_ledger(db, **filters)
        o = rep.overall

        if args.json:
            # The window had no results screen for one reason: this command
            # ignored --json, so there was nothing for it to read. Everything
            # Pikkit puts on a dashboard is already computed here.
            from overlay_engine.clv import report as clv_report

            graded = db.graded_bets()
            clv = None
            if graded:
                cr = clv_report(graded)
                # Beating the close is the only measure of a bet that does
                # not need the result. A winning month on bets that all
                # closed worse is variance; a losing month on bets that all
                # closed better is the process working. Pikkit leads with
                # this and it is the number a serious bettor checks first.
                clv = {"n": cr.n, "mean_clv": cr.mean_clv,
                       "stdev": cr.stdev, "beat_rate": cr.beat_rate,
                       "total_staked": cr.total_staked,
                       "verdict": cr.verdict(),
                       "by_book": cr.by_book, "by_market": cr.by_market}
            def group(rows):
                # Slice carries `label`, not `key`, and reports flat_return
                # rather than roi. Written against the wrong shape, this
                # raised AttributeError on the first ledger that actually had
                # bets in it — an empty ledger yields empty lists, so the
                # comprehension never ran and every test passed.
                return [{"key": g.label, "n": g.n, "won": g.won,
                         "lost": g.lost, "push": g.push,
                         "turnover": g.turnover, "profit": g.profit,
                         "roi": (g.profit / g.turnover) if g.turnover else 0.0,
                         "flat_return": g.flat_return,
                         "win_rate": (g.won / (g.won + g.lost))
                                     if (g.won + g.lost) else 0.0}
                        for g in rows]

            print(json.dumps({
                "command": "performance",
                "ledger": str(db.path),
                "filters": {k: str(v) for k, v in filters.items()},
                "settled": o.n, "won": o.won, "lost": o.lost,
                "push": o.push, "void": o.void, "decided": o.decided,
                "turnover": o.turnover, "profit": o.profit,
                "win_rate": o.win_rate, "roi": o.roi,
                "flat_return": o.flat_return,
                "staking_effect": rep.staking_effect,
                "units": o.units(args.unit) if args.unit else None,
                "verdict": o.verdict(),
                "by_sport": group(rep.by_sport), "by_book": group(rep.by_book),
                "by_market": group(rep.by_market), "by_price": group(rep.by_odds),
                "clv": clv,
                "graded": len(graded), "ungraded": db.stats()["ungraded"],
            }, indent=2, sort_keys=True))
            return 0

        print(f"ledger: {db.path}")
        if filters:
            print(f"  filtered: {', '.join(f'{k}={v}' for k, v in filters.items())}")
        print()
        print(f"  settled       {o.n:>8}"
              f"   ({o.won}W {o.lost}L {o.push}P"
              + (f" {o.void} void" if o.void else "") + ")")
        print(f"  turnover      {o.turnover:>8,.0f}")
        print(f"  profit        {o.profit:>+8,.2f}")
        if args.unit:
            print(f"  units         {o.units(args.unit):>+8,.2f}"
                  f"   (at {args.unit:,.0f} a unit)")
        print(f"  win rate      {o.win_rate:>8.1%}   of {o.decided} decided")
        print()
        print(f"  money ROI     {o.roi:>+8.2%}   what actually happened")
        print(f"  flat-bet ROI  {o.flat_return:>+8.2%}"
              "   betting the same amount every time")
        effect = rep.staking_effect
        if o.n:
            direction = "added" if effect > 0 else "cost"
            print(f"  staking       {effect:>+8.2%}   sizing {direction} this much")
        print()
        print(f"  {o.verdict()}")

        for title, group in (("by sport", rep.by_sport), ("by book", rep.by_book),
                             ("by market", rep.by_market), ("by price", rep.by_odds)):
            shown = [s for s in group if s.n]
            if not shown:
                continue
            print()
            print(f"  -- {title} " + "-" * (46 - len(title)))
            for sl in shown:
                flag = "" if sl.n >= 30 else "  (thin)"
                print(f"    {sl.label:<28} {sl.n:>5} bets"
                      f" {sl.flat_return:>+8.2%}{flag}")

        leaks = rep.leaks()
        if leaks:
            print()
            print("  -- losing on a sample worth believing " + "-" * 12)
            for sl in leaks:
                print(f"    {sl.label:<28} {sl.n:>5} bets {sl.flat_return:>+8.2%}")
    return 0


def _slip_display(name: str, value) -> str:
    """How a read value should appear to a person checking it against a slip.

    Formatted here rather than in the window so the window does no betting
    arithmetic: `1.6666666666666665` is what the float is, and `-150 (1.667)`
    is what the slip said.
    """
    from overlay_engine.catalog import VENUES
    from overlay_engine.odds import decimal_to_american

    if name == "book" and value in VENUES:
        return VENUES[value].name
    if name == "decimal_odds" and isinstance(value, (int, float)):
        return f"{decimal_to_american(value):+.0f}  ({value:.3f})"
    if name in ("stake", "profit") and isinstance(value, (int, float)):
        return f"${value:,.2f}"
    if name == "market_type":
        return {"h2h": "Moneyline", "spreads": "Spread", "totals": "Total",
                "player_prop": "Player prop", "parlay": "Parlay",
                "teaser": "Teaser", "futures": "Future"}.get(value, str(value))
    return str(value)


def cmd_paste(args: argparse.Namespace) -> int:
    """Read a betslip pasted on stdin. Shows the reading; writes only on ask."""
    import pathlib

    from overlay_engine.betslip import implied, parse, to_import

    if getattr(args, "text", None) is not None:
        # The window has no stdin to hand the engine; the slip arrives as an
        # argument instead. Same parser, same refusals.
        text = args.text
    elif args.path in (None, "-"):
        text = sys.stdin.read()
    else:
        text = pathlib.Path(args.path).read_text()
    got = parse(text)

    if args.json:
        out = {
            "command": "paste",
            "usable": got.usable,
            "needs": got.needs,
            "fields": {k: {"value": f.value, "source": f.source,
                           "display": _slip_display(k, f.value)}
                       for k, f in got.fields.items()},
            "implied": implied(got) if got.usable else None,
            "written": False,
        }
        if got.usable and args.write:
            if not args.event:
                out["error"] = ("--write needs --event: a bet with no event "
                                "cannot be graded")
            else:
                from overlay_engine.ledger import Ledger
                with Ledger(args.db) as db:
                    out["bet_id"] = db.import_bet(**to_import(
                        got, event_id=args.event, sport=args.sport))
                    out["written"] = True
                    out["ledger"] = str(db.path)
        print(json.dumps(out, indent=2, sort_keys=True, default=str))
        return 0 if got.usable else 1

    print("read from the slip:")
    print(got.describe())

    if not got.usable:
        print()
        print(f"  NOT A BET: {', '.join(got.needs)} missing.")
        print("  Nothing written. A slip without a price is not a bet with an")
        print("  unknown price - it is text that did not parse.")
        return 1

    print()
    print(f"  implied      {implied(got):.2%}  (includes the vig)")

    unknown = [f for f in ("book", "market_type", "result") if got.get(f) is None]
    if unknown:
        print(f"  not found: {', '.join(unknown)}"
              "  (left blank rather than guessed)")

    print()
    print("  Check every line above against the slip before writing it. The")
    print("  source text after each arrow is what the value was read from.")

    if not args.write:
        print()
        print("  Nothing written. Re-run with --write --event EVENT_ID to record it.")
        return 0

    if not args.event:
        print()
        print("  --write needs --event EVENT_ID: a bet with no event cannot be")
        print("  graded, and an ungradeable bet never becomes evidence.")
        return 1

    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        bet_id = db.import_bet(**to_import(got, event_id=args.event,
                                           sport=args.sport))
        print()
        print(f"  written to {db.path} as bet {bet_id}")
    return 0


def cmd_offers(args: argparse.Namespace) -> int:
    """Whether a deposit match clears, given the markets its terms allow."""
    import time

    from overlay_engine.offers import (
        CLASSES,
        RolloverTerms,
        OfferError,
        evaluate,
        load_terms,
        measure_class_holds,
    )

    now = args.now if args.now is not None else time.time()

    # Holds are measured from a snapshot when one is given. Without it every
    # class falls back to a labelled prior, and the verdict says so rather than
    # quietly presenting a stated 4.5% as though it were this book's number.
    measured = {}
    if args.snapshot:
        from overlay_engine.feed import FeedError, ReplayProvider

        try:
            provider = ReplayProvider(args.snapshot)
        except FeedError as exc:
            print(f"cannot read snapshot: {exc}")
            return 1
        markets = []
        for sport in (args.sport or ["nfl"]):
            markets.extend(provider.fetch(sport))
        measured = measure_class_holds(markets, now=now)

    print("churn hold by market class:")
    for klass in CLASSES:
        got = measured.get(klass)
        if got:
            print(f"  {got.describe()}")
        else:
            print(f"  {klass}: not measured — a labelled prior will be used")
    if not measured:
        print()
        print("  Nothing measured. Pass --snapshot to price these off real")
        print("  quotes; every verdict below rests on a stated prior until you do.")

    verdicts = []

    if args.rollover is not None:
        eligible = frozenset(c.strip() for c in (args.eligible or "h2h").split(",")
                             if c.strip())
        try:
            terms = RolloverTerms(
                book=args.book, state=args.state.upper(),
                rollover=args.rollover, eligible=eligible, fetched_at=now,
                source="supplied on the command line",
                includes_deposit=not args.bonus_only)
            verdicts.append(evaluate(terms, args.deposit, args.bonus, measured, now))
        except OfferError as exc:
            print()
            print(f"  {exc}")
            return 1
    else:
        # `--terms` defaults to a path relative to the working directory, which
        # only exists in a checkout. Installed from the wheel and run from
        # anywhere else this is the common case, not the exotic one, so it gets
        # the same one-line refusal every other file-reading command here gives
        # rather than a traceback.
        try:
            report = load_terms(args.terms, now)
        except OSError as exc:
            print()
            print(f"cannot read terms feed: {exc}")
            print("  Point --terms at a dated, sourced CSV, or price one offer")
            print("  directly with --rollover:")
            print("    overlay offers --rollover 10 --eligible h2h,totals")
            return 1
        print()
        print(f"terms feed: {args.terms}")
        print(f"  {report.describe()}")
        for label, why in report.refused:
            print(f"    refused  {label}: {why}")
        for terms in report.terms:
            try:
                verdicts.append(
                    evaluate(terms, args.deposit, args.bonus, measured, now))
            except OfferError as exc:
                print(f"    refused  {terms.book}/{terms.state}: {exc}")
        if not report.terms:
            print()
            print("  Nothing to evaluate. Add a dated, sourced row to the feed,")
            print("  or pass --rollover to price one offer directly:")
            print("    overlay offers --rollover 10 --eligible h2h,totals")
            return 0

    print()
    for verdict in sorted(verdicts, key=lambda v: -v.margin):
        print(verdict.describe())
        print()
    return 0


def cmd_correlation(args: argparse.Namespace) -> int:
    """Measure the correlation Kelly sizing has been assuming."""
    from overlay_engine.correlation import KEYS, from_ledger
    from overlay_engine.kelly import DEFAULT_CORRELATION, simultaneous_scale
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        print(f"ledger: {db.path}")
        print()
        for key in (KEYS if args.all_keys else (args.key,)):
            got = from_ledger(db, key=key, sport=args.sport)
            print(f"grouped by {key}:")
            print(f"  {got.describe()}")
            if got.measured:
                assumed = simultaneous_scale(args.live, DEFAULT_CORRELATION)
                print(f"  {args.live} live bets scale to"
                      f" {got.scale(args.live):.3f}"
                      f" (the {DEFAULT_CORRELATION:.2f} prior said"
                      f" {assumed:.3f})")
            print()

    print("  Correlation is the reason twelve +EV bets are not twelve")
    print("  positions. Sizing each at its own optimum when they share a game")
    print("  script is one bet in twelve hats, at twelve times the stake.")
    return 0


def cmd_portfolio(args: argparse.Namespace) -> int:
    """Bankroll, exposure, correlation and the next stake, in one view."""
    from overlay_engine.ledger import Ledger
    from overlay_engine.portfolio import PortfolioError, build

    with Ledger(args.db) as db:
        try:
            view = build(db, bankroll=args.bankroll, key=args.key,
                         sport=args.sport, book=args.book)
        except PortfolioError as exc:
            print(f"cannot build a portfolio view: {exc}")
            return 1

        print(f"ledger: {db.path}")
        print()
        print(view.describe())

        if view.exposure.markets:
            print()
            print("  open markets:")
            for market in view.exposure.markets[:10]:
                print(f"    {market.describe()}")
            if len(view.exposure.markets) > 10:
                print(f"    ... and {len(view.exposure.markets) - 10} more")
    return 0


def cmd_event_meta(args: argparse.Namespace) -> int:
    """Record what an event shares with others, or show what is recorded."""
    from overlay_engine.correlation import META_KEYS, MIN_COVERAGE
    from overlay_engine.ledger import Ledger, LedgerError

    with Ledger(args.db) as db:
        print(f"ledger: {db.path}")
        if args.event:
            try:
                db.record_event_meta(
                    event_id=args.event, sport=args.sport,
                    starter=args.starter, venue=args.venue,
                    weather=args.weather)
            except LedgerError as exc:
                print(f"  {exc}")
                return 1
            recorded = db.event_meta().get(args.event, {})
            shown = ", ".join(f"{k}={v}" for k, v in sorted(recorded.items()))
            print(f"  {args.event}: {shown}")
            print()

        if args.weather:
            from overlay_engine.weather import buckets, describe

            print(f"  reading: {describe(args.weather)}")
            print(f"  bands are a stated choice, not a measurement"
                  f" &mdash; {len(buckets())} buckets in all".replace("&mdash;", "-"))
            print()

        print("  coverage across events holding bets:")
        for field in META_KEYS:
            covered, total = db.meta_coverage(field)
            share = covered / total if total else 0.0
            mark = "ok " if share >= MIN_COVERAGE else "   "
            print(f"    {mark} {field:<9} {covered}/{total}  ({share:.0%})")
        print()
        print(f"  A grouping needs {MIN_COVERAGE:.0%} before it is measured"
              " rather than a prior.")
        print("  Unrecorded events are excluded, never grouped under a blank —")
        print("  a blank would make every unrecorded event one correlated"
              " block.")
    return 0


def cmd_compare_feeds(args: argparse.Namespace) -> int:
    """Rank recorded feed trials on measured latency, or refuse to."""
    from overlay_engine.feedcompare import CompareError, compare

    try:
        result = compare(args.snapshots)
    except CompareError as exc:
        print(f"cannot compare: {exc}")
        return 1

    print(f"{len(result.samples)} trial(s):")
    print()
    print(result.describe())
    print()
    print("  Latency is the gap between the book's timestamp and receipt, so a")
    print("  feed that sends no timestamp records as instant. That is why an")
    print("  all-zero trial is left unranked rather than put first.")
    return 0


def cmd_schedule(args: argparse.Namespace) -> int:
    """What needs a closing capture now, and when to run next."""
    import time as _time

    from overlay_engine.feed import FeedError, ReplayProvider
    from overlay_engine.ledger import Ledger
    from overlay_engine.schedule import EARLIEST, LEAD, next_run_at, plan

    now = args.now if args.now is not None else _time.time()
    try:
        provider = ReplayProvider(args.snapshot)
    except FeedError as exc:
        print(f"cannot read snapshot: {exc}")
        return 1

    markets = []
    for sport in (args.sport or provider.sports()):
        markets.extend(provider.fetch(sport))

    with Ledger(args.db) as db:
        closed = db.closed_markets()
        result = plan(markets, now, closed=closed)
        upcoming = next_run_at(markets, now, closed=closed)

        print(f"ledger: {db.path}")
        print(f"  {len(markets)} market(s) in the snapshot,"
              f" {len(closed)} already closed")
        print()
        print(result.describe())
        for due in result.due[:10]:
            print(f"    {due.describe()}")
        if len(result.due) > 10:
            print(f"    ... and {len(result.due) - 10} more")

        print()
        if upcoming is None:
            print("  Nothing pending. No market here has a future start that"
                  " still needs a close.")
        else:
            print(f"  Next pass due in {(upcoming - now) / 60:.1f} min.")
        print(f"  Lead {LEAD / 60:.0f} min, earliest {EARLIEST / 60:.0f} min"
              " out. Both are stated choices, not measurements.")
    return 0


def cmd_import(args: argparse.Namespace) -> int:
    from overlay_engine.importer import ImportError_, detect_columns, import_csv
    from overlay_engine.ledger import Ledger

    source = args.path
    tmp = None
    if getattr(args, "text", None) is not None:
        # CSV content from the window, which cannot hand the engine a path.
        # Written to a private temp file only because import_csv reads a
        # path; removed afterwards whatever happens.
        import os
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix=".csv")
        with os.fdopen(fd, "w") as fh:
            fh.write(args.text)
        source = tmp
    if source is None:
        print("import needs a CSV path or --text", file=sys.stderr)
        return 2
    try:
        with Ledger(args.db) as db:
            report = import_csv(db, source, default_book=args.book,
                                default_sport=args.sport)
            if args.json:
                print(json.dumps({
                    "command": "import", "ledger": str(db.path),
                    "summary": report.describe(),
                    "imported": report.imported, "duplicates": report.duplicates,
                    "skipped": len(report.skipped), "reasons": report.reasons(),
                    "mapping": report.mapping, "profit_source": report.profit_source,
                }, indent=2, sort_keys=True))
                return 0
            print(f"ledger: {db.path}")
            print(f"  {report.describe()}")

            print()
            print(f"  columns matched ({len(report.mapping)}):")
            for field_name, column in sorted(report.mapping.items()):
                print(f"    {field_name:<16} <- {column}")

            unmatched = [f for f in ("sport", "market_type", "result", "book")
                         if f not in report.mapping]
            if unmatched:
                print(f"  not found: {', '.join(unmatched)}"
                      "  (defaults used where possible)")

            print()
            if report.profit_source == "payout":
                print("  Profit derived from a payout column — payout includes"
                      " the stake, so it")
                print("  is converted rather than read across. Reading it"
                      " across would inflate")
                print("  every winning bet by its own stake.")
            elif report.profit_source == "none":
                print("  No profit or payout column; profit derived from the"
                      " result and price.")

            if report.skipped:
                print()
                print("  skipped:")
                for reason, n in report.reasons().items():
                    print(f"    {n:>4}  {reason}")

            stats = db.stats()
            print()
            print(f"  {stats['bets']} bets in the ledger"
                  f" ({stats['imported']} imported, {stats['trainable']} trainable)")
            if stats["imported"] and not stats["trainable"]:
                print("  Imported bets track and grade but never train the"
                      " calibration —")
                print("  nobody recorded what each devig method said at bet time.")
    except ImportError_ as exc:
        print(f"cannot import: {exc}")
        return 1
    finally:
        if tmp:
            import os as _os
            _os.unlink(tmp)
    return 0


def cmd_promos(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger, LedgerError
    from overlay_engine.promo import URGENT_DAYS, report_holdings

    with Ledger(args.db) as db:
        if args.add:
            try:
                promo_id = db.record_promo(
                    book=args.book, kind=args.kind, amount=args.add,
                    boost=args.boost,
                    expires_at=(None if args.days is None
                                else __import__("time").time() + args.days * 86400),
                    note=args.note,
                )
            except LedgerError as exc:
                print(f"cannot record: {exc}")
                return 1
            print(f"recorded promo {promo_id}: {args.book} "
                  f"{args.add:,.0f} {args.kind}")
            return 0

        if args.used is not None:
            try:
                db.use_promo(args.used, realised=args.realised or 0.0)
            except LedgerError as exc:
                print(f"cannot mark used: {exc}")
                return 1
            print(f"promo {args.used} marked used, realised "
                  f"{args.realised or 0.0:,.2f}")
            return 0

        rep = report_holdings(db, conversion=args.conversion)
        print(f"ledger: {db.path}")
        print(f"  {rep.verdict()}")

        if rep.live:
            print()
            print("  held:")
            for h in sorted(rep.live, key=lambda h: h.expires_at or 1e18):
                mark = "  <- expiring" if h.urgent(rep.now) else ""
                print(f"    [{h.promo_id:>3}] {h.describe(rep.now)}{mark}")

        if rep.expired:
            print()
            print(f"  lost to expiry ({rep.lost_to_expiry:,.0f} face):")
            for h in rep.expired:
                print(f"    [{h.promo_id:>3}] {h.book} {h.amount:,.0f} "
                      f"{h.kind}")
            print("    Every one of these was money until the day it was not.")

        print()
        print(f"  Values assume {args.conversion:.0%} conversion, which depends"
              " on the hedge you")
        print("  can place — see `overlay promo --max-hedge` for the ladder.")
        if rep.urgent:
            print(f"  A bonus converted at 55% today beats one converted at 80%"
                  f" after it expires.")
    return 0


def cmd_exposure(args: argparse.Namespace) -> int:
    from overlay_engine.exposure import report as exposure_report
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        rep = exposure_report(db, book=args.book, sport=args.sport)
        print(f"ledger: {db.path}")
        print(f"  {rep.verdict()}")

        if not rep.markets:
            return 0

        print()
        for market in rep.markets:
            flag = "  [outcome set inferred]" if market.inferred else ""
            print(f"  {market.event_id} {market.market_type}"
                  f"  {market.at_risk:,.0f} at risk{flag}")
            for outcome, amount in market.scenarios():
                held = sum(p.stake for p in market.positions
                           if p.outcome == outcome)
                on = f"{held:,.0f} on" if held else "nothing on"
                print(f"      {outcome:<18} {amount:>+10,.2f}   ({on} it)")
            if market.locked:
                print("      locked — every result pays")
            print()

        print(f"  worst case {rep.worst_case:+,.2f}"
              f"   best case {rep.best_case:+,.2f}")
        print("  The worst case sums each market's worst result. That is a"
              " floor only if")
        print("  the markets are independent — same game or same starter and"
              " they can all")
        print("  land badly together.")

        if rep.concentrated:
            event, share = rep.concentration
            print()
            print(f"  {share:.0%} of your exposure rides on {event}.")

        if rep.inferred_markets:
            print()
            print(f"  {len(rep.inferred_markets)} market(s) have no recorded"
                  " quotes, so their outcome")
            print("  set comes from your own bets — the result you did not back"
                  " is invisible")
            print("  and their worst case is optimistic. Run `capture` to fix"
                  " that.")
    return 0


def cmd_tags(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger, LedgerError
    from overlay_engine.performance import MIN_BETS, tag_report

    with Ledger(args.db) as db:
        if args.tag is not None:
            if args.bet is None:
                print("--tag needs --bet")
                return 1
            try:
                added = (db.untag_bet(args.bet, args.tag) if args.remove
                         else db.tag_bet(args.bet, *args.tag.split(",")))
            except LedgerError as exc:
                print(f"cannot tag: {exc}")
                return 1
            verb = "removed" if args.remove else "added"
            print(f"{verb} on bet {args.bet}: {db.tags_for(args.bet) or 'none'}")
            return 0

        rep = tag_report(db, alpha=args.alpha)
        print(f"ledger: {db.path}")
        print(f"  {rep.verdict()}")

        if not rep.slices:
            return 0

        print()
        print(f"  {'tag':<20}{'bets':>6}{'flat ROI':>11}{'interval':>20}")
        survivors = {s.label for s in rep.survivors}
        naive = {s.label for s in rep.naive_winners}
        for sl in rep.slices:
            if sl.n < MIN_BETS:
                mark = "  thin"
            elif sl.label in survivors:
                mark = "  SURVIVES"
            elif sl.label in naive:
                mark = "  luck-shaped"
            else:
                mark = ""
            band = f"{sl.roi_low:+.1%} to {sl.roi_high:+.1%}"
            print(f"  {sl.label:<20}{sl.n:>6}{sl.flat_return:>+11.2%}"
                  f"{band:>20}{mark}")

        print()
        print(f"  Bar for a single test: z {1.96:.2f}. With {rep.tests} tags"
              f" tested at once: z {rep.bar:.2f}.")
        if rep.naive_winners and not rep.survivors:
            print("  Everything that looked significant is consistent with"
                  " having tried enough")
            print("  slices. That is not a bug in the tags — it is what testing"
                  " many hypotheses")
            print("  does, and no other tracker tells you.")
    return 0


def american_to_decimal_safe(value: float) -> float | None:
    try:
        return parse_odds(value)
    except Exception:
        return None


def main(argv: list[str] | None = None) -> int:
    # First thing, before anything else initialises: an import-time failure is
    # exactly the crash that produces "it doesn't open", and a handler
    # installed later cannot see it.
    from overlay_engine import crash

    crash.install()

    # Raw, because the description is a list of example invocations and the
    # default formatter reflows them into one paragraph — which is exactly the
    # part of `--help` a new user copies out of.
    parser = argparse.ArgumentParser(
        prog="overlay", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    # `--json` goes after the subcommand, and only there. It was briefly on
    # the top-level parser as well, which meant `overlay --json devig` parsed
    # fine and then printed a table: the subparser's own default overwrote the
    # flag. An unrecognised-argument error is a worse experience than working,
    # and a far better one than silently ignoring what was asked for. Argparse puts a
    # top-level flag before the subcommand only, and `overlay --json devig` is
    # not what anyone types — a parent parser gives every subcommand the same
    # flag so both forms work and no subparser has to remember to add it.
    machine = argparse.ArgumentParser(add_help=False)
    machine.add_argument("--json", action="store_true",
                         help="emit the result as JSON for a UI to read")
    sub = parser.add_subparsers(dest="command", required=True,
                                parser_class=lambda **kw: argparse.ArgumentParser(
                                    parents=[machine], **kw))

    p = sub.add_parser("devig", help="devig a market by every method")
    p.add_argument("odds", nargs="+")
    p.add_argument("--index", type=int, default=None,
                   help="report break-even prices for this outcome")
    p.set_defaults(func=cmd_devig)

    p = sub.add_parser("arb", help="check and stake an arbitrage")
    p.add_argument("odds", nargs="+")
    p.add_argument("--stake", type=float, default=1000.0)
    p.set_defaults(func=cmd_arb)

    p = sub.add_parser("fill", help="fill probability for a quote age")
    p.add_argument("--book", default="dk")
    p.add_argument("--market", default="h2h")
    p.add_argument("--age", type=float, default=10.0)
    p.add_argument("--db", default=None,
                   help="use measured quote life and latency from this ledger")
    p.set_defaults(func=cmd_fill)

    p = sub.add_parser("kelly", help="size a bet")
    p.add_argument("--odds", required=True)
    p.add_argument("--prob", type=float, required=True)
    p.add_argument("--prob-low", type=float, default=None)
    p.add_argument("--bankroll", type=float, default=10_000.0)
    p.add_argument("--fraction", type=float, default=0.25)
    p.set_defaults(func=cmd_kelly)

    p = sub.add_parser("demo", help="run a full market through the pipeline")
    p.add_argument("--bankroll", type=float, default=10_000.0)
    p.add_argument("--db", default=None,
                   help="price with the calibration in this ledger")
    p.set_defaults(func=cmd_demo)

    p = sub.add_parser("books", help="venues you can legally use in a state")
    p.add_argument("state")
    p.add_argument("--unverified", action="store_true",
                   help="also show venues whose jurisdiction is unconfirmed")
    p.set_defaults(func=cmd_books)

    p = sub.add_parser("ledger", help="what the local record holds, and what it can teach")
    p.add_argument("--db", default=None,
                   help="database path (default ~/.overlay/overlay.db, or $OVERLAY_HOME)")
    p.set_defaults(func=cmd_ledger)

    p = sub.add_parser("tags", help="per-tag performance, corrected for how many you tested")
    p.add_argument("--db", default=None)
    p.add_argument("--bet", type=int, default=None, help="bet id to tag")
    p.add_argument("--tag", default=None,
                   help="comma-separated tags to add to --bet")
    p.add_argument("--remove", action="store_true", help="remove --tag instead")
    p.add_argument("--alpha", type=float, default=0.05)
    p.set_defaults(func=cmd_tags)

    p = sub.add_parser("exposure", help="open positions and what each result pays")
    p.add_argument("--db", default=None)
    p.add_argument("--book", default=None)
    p.add_argument("--sport", default=None)
    p.set_defaults(func=cmd_exposure)

    p = sub.add_parser("promos", help="promotions held, what they are worth, what expires")
    p.add_argument("--db", default=None)
    p.add_argument("--conversion", type=float, default=0.75,
                   help="assumed bonus-bet conversion rate")
    p.add_argument("--add", type=float, default=None,
                   help="record a promo of this face value")
    p.add_argument("--book", default="unknown")
    p.add_argument("--kind", default="bonus_bet",
                   choices=("bonus_bet", "profit_boost"))
    p.add_argument("--boost", type=float, default=None,
                   help="boost fraction, for a profit boost")
    p.add_argument("--days", type=float, default=None,
                   help="days until it expires")
    p.add_argument("--note", default="")
    p.add_argument("--used", type=int, default=None, metavar="ID",
                   help="mark a promo used")
    p.add_argument("--realised", type=float, default=None,
                   help="what it actually converted to")
    p.set_defaults(func=cmd_promos)

    p = sub.add_parser("paste", help="read a bet out of a pasted betslip")
    p.add_argument("path", nargs="?", default="-",
                   help="file to read, or - for stdin (the default)")
    p.add_argument("--db", default=None)
    p.add_argument("--write", action="store_true",
                   help="record it; without this the reading is only shown")
    p.add_argument("--event", default=None, help="event id, required by --write")
    p.add_argument("--sport", default="unknown")
    p.add_argument("--text", default=None,
                   help="the slip itself, for callers with no stdin")
    p.set_defaults(func=cmd_paste)

    p = sub.add_parser(
        "offers", help="does a deposit match clear, given what it lets you churn in")
    p.add_argument("--terms", default="data/offer_terms.csv",
                   help="dated, sourced terms feed keyed by (book, state)")
    p.add_argument("--snapshot", default=None,
                   help="quote snapshot to measure class holds from")
    p.add_argument("--sport", action="append", default=None)
    p.add_argument("--deposit", type=float, default=1000.0)
    p.add_argument("--bonus", type=float, default=1000.0)
    p.add_argument("--rollover", type=float, default=None,
                   help="price one offer directly instead of reading the feed")
    p.add_argument("--eligible", default=None,
                   help="comma-separated market classes the rollover allows")
    p.add_argument("--book", default="adhoc")
    p.add_argument("--state", default="--")
    p.add_argument("--bonus-only", action="store_true",
                   help="rollover applies to the bonus alone, not deposit+bonus")
    p.add_argument("--now", type=float, default=None)
    p.set_defaults(func=cmd_offers)

    p = sub.add_parser(
        "correlation",
        help="measure how much your simultaneous bets actually co-move")
    p.add_argument("--db", default=None)
    p.add_argument("--key", default="event",
                   choices=("event", "day", "sport_day",
                            "starter", "venue", "weather"),
                   help="what counts as resolving together")
    p.add_argument("--all-keys", action="store_true",
                   help="report every grouping")
    p.add_argument("--sport", default=None)
    p.add_argument("--live", type=int, default=12,
                   help="how many simultaneous bets to size for")
    p.set_defaults(func=cmd_correlation)

    p = sub.add_parser(
        "portfolio",
        help="bankroll, exposure and correlation in one view")
    # Required, and deliberately so: nothing in the ledger knows the bankroll,
    # and a default would make every ratio here a fiction with a percent sign.
    p.add_argument("--bankroll", type=float, required=True)
    p.add_argument("--db", default=None)
    p.add_argument("--key", default="event",
                   choices=("event", "day", "sport_day",
                            "starter", "venue", "weather"),
                   help="what counts as resolving together")
    p.add_argument("--sport", default=None)
    p.add_argument("--book", default=None)
    p.set_defaults(func=cmd_portfolio)

    p = sub.add_parser(
        "event-meta",
        help="record what an event shares with others (starter, venue, weather)")
    p.add_argument("--db", default=None)
    p.add_argument("--event", default=None,
                   help="event id to record; omit to show coverage only")
    p.add_argument("--sport", default=None)
    p.add_argument("--starter", default=None)
    p.add_argument("--venue", default=None)
    p.add_argument("--weather", default=None)
    p.set_defaults(func=cmd_event_meta)

    p = sub.add_parser(
        "compare-feeds",
        help="rank recorded feed trials on measured latency")
    p.add_argument("snapshots", nargs="+",
                   help="snapshot files, one recorded trial per candidate")
    p.set_defaults(func=cmd_compare_feeds)

    p = sub.add_parser(
        "schedule", help="which markets need a closing capture, and when")
    p.add_argument("snapshot")
    p.add_argument("--db", default=None)
    p.add_argument("--sport", action="append", default=None)
    p.add_argument("--now", type=float, default=None)
    p.set_defaults(func=cmd_schedule)

    p = sub.add_parser(
        "parlay", help="what a parlay pays against what it should")
    p.add_argument("odds", nargs="+",
                   help="each leg's price, American or decimal")
    p.add_argument("--same-game", action="store_true",
                   help="legs are in one game, so they are not independent")
    p.set_defaults(func=cmd_parlay)

    p = sub.add_parser("board", help="every play on one board, best first")
    p.add_argument("--snapshot", default=None,
                   help="a recorded snapshot to scan instead of the demo market")
    p.add_argument("--bankroll", type=float, default=1000.0)
    p.add_argument("--min-margin", type=float, default=0.0,
                   help="hide anything under this margin, in percent")
    p.add_argument("--kind", action="append", choices=("arb", "ev", "middle"),
                   help="limit to one kind of play; repeatable")
    p.add_argument("--min-ev", type=float, default=0.0,
                   help="hide +EV plays under this edge, in percent")
    p.add_argument("--live", action="store_true",
                   help="fetch live prices from the public, keyless venues "
                        "(Kalshi, Polymarket). Off by default: without this "
                        "flag nothing here touches a network.")
    # --json comes from the shared `machine` parent every subparser inherits.
    p.set_defaults(func=cmd_board)

    p = sub.add_parser("welcome", help="every welcome offer, ranked by what it converts to")
    p.add_argument("--bonus-odds", type=float, default=4.0,
                   help="decimal odds you place bonus bets at (prior: 4.0, i.e. +300)")
    p.add_argument("--hold", type=float, default=2.0,
                   help="combined hold across the best two books, percent (prior: 2.0)")
    p.set_defaults(func=cmd_welcome)

    p = sub.add_parser("crashes", help="crash reports written on this machine")
    p.add_argument("--bundle", action="store_true",
                   help="zip them so you can send them yourself")
    p.set_defaults(func=cmd_crashes)

    p = sub.add_parser("roundrobin",
                       help="every parlay of a size, and what must land")
    p.add_argument("legs", nargs="+", help="decimal or american odds per leg")
    p.add_argument("--by", type=int, nargs="+", default=[2],
                   help="parlay sizes, e.g. --by 2 3")
    p.add_argument("--stake", type=float, default=10.0,
                   help="stake on each ticket")
    p.add_argument("--probs", type=float, nargs="+", default=None,
                   help="your probability for each leg, if you have one")
    p.add_argument("--correlated", action="store_true",
                   help="legs are from the same game, so independence is false")
    p.set_defaults(func=cmd_roundrobin)

    p = sub.add_parser("poisson",
                       help="scorelines and totals from two scoring rates")
    p.add_argument("home", type=float, help="home expected goals")
    p.add_argument("away", type=float, help="away expected goals")
    p.add_argument("--line", type=float, default=2.5, help="totals line")
    p.add_argument("--over-odds", default=None,
                   help="the book's price on the over, to compare against")
    p.set_defaults(func=cmd_poisson)

    p = sub.add_parser("lowhold",
                       help="cheapest way to turn money over, and its cost")
    p.add_argument("quotes", nargs="+", metavar="BOOK:SIDE:PRICE",
                   help="e.g. dk:home:-110 fd:away:+105")
    p.add_argument("--turnover", type=float, default=1000.0,
                   help="how much you intend to put through")
    p.add_argument("--top", type=int, default=5,
                   help="how many pairings to rank")
    p.set_defaults(func=cmd_lowhold)

    p = sub.add_parser("import", help="read a book's CSV bet history into the ledger")
    p.add_argument("path", nargs="?", default=None)
    p.add_argument("--text", default=None,
                   help="the CSV itself, for callers that cannot pass a path")
    p.add_argument("--db", default=None)
    p.add_argument("--book", default="unknown",
                   help="book name for files that do not carry one")
    p.add_argument("--sport", default="unknown",
                   help="sport for files that do not carry one")
    p.set_defaults(func=cmd_import)

    p = sub.add_parser("performance", help="P&L, ROI and win rate, with intervals")
    p.add_argument("--db", default=None)
    p.add_argument("--sport", default=None)
    p.add_argument("--book", default=None)
    p.add_argument("--market", default=None)
    p.add_argument("--min-odds", default=None)
    p.add_argument("--max-odds", default=None)
    p.add_argument("--unit", type=float, default=None,
                   help="stake size for reporting profit in units")
    p.add_argument("--csv", default=None, help="export to this path instead")
    p.set_defaults(func=cmd_performance)

    p = sub.add_parser("middles",
                       help="price a middle against counted margins or totals")
    p.add_argument("low", type=float, help="the lower line")
    p.add_argument("high", type=float, help="the higher line")
    p.add_argument("--low-odds", default="-110")
    p.add_argument("--high-odds", default="-110")
    p.add_argument("--sport", default="nfl")
    p.add_argument("--stake", type=float, default=1000.0)
    p.add_argument("--market", default="spreads", choices=("spreads", "totals"),
                   help="a margin middle or an over/under one")
    # No default. A default here would be an override on every run, and the
    # measured standard deviation could then never be used — the fallback
    # would silently outrank the measurement it exists to stand in for.
    p.add_argument("--sigma", type=float, default=None,
                   help="override the spread of the normal fallback")
    p.add_argument("--db", default=None,
                   help="use counted margins or totals from this ledger")
    p.set_defaults(func=cmd_middles)

    p = sub.add_parser("capture", help="store a snapshot of markets into the ledger")
    p.add_argument("snapshot", help="path to a recorded snapshot JSON file")
    p.add_argument("--db", default=None)
    p.add_argument("--sport", action="append", default=[],
                   help="limit to these sports (repeatable)")
    p.add_argument("--closing", action="store_true",
                   help="mark these quotes as the closing line")
    p.set_defaults(func=cmd_capture)

    p = sub.add_parser("grade", help="settle bets against recorded closing lines")
    p.add_argument("--db", default=None)
    p.add_argument("--allow-retail", action="store_true",
                   help="grade off a soft book's close when no sharp one exists")
    p.set_defaults(func=cmd_grade)

    p = sub.add_parser("calibrate", help="refit devig weights from the graded log")
    p.add_argument("--db", default=None)
    p.add_argument("--holdout", type=float, default=0.3,
                   help="fraction of the log, most recent first, held back to verify")
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(func=cmd_calibrate)

    p = sub.add_parser("promo", help="what a welcome offer is really worth")
    p.add_argument("--bonus", type=float, default=1000.0)
    p.add_argument("--max-hedge", type=float, default=None,
                   help="most you can stake at the hedging book")
    p.add_argument("--state", default="")
    p.set_defaults(func=cmd_promo)

    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except Exception as exc:                             # noqa: BLE001
        # The app's own refusals are answers, not stack traces. `parlay 2.10`
        # is a person making an ordinary mistake, and a traceback tells them
        # the program is broken when it is they who are being told no.
        if not crash.is_expected(type(exc)):
            raise
        print(f"{exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
