"""The screen a bettor actually wants: every play on one board, ranked.

This is the thing the product was missing, and the reason someone who has used
OddsJam or AVO opens Bookbreaker and does not recognise it. Those tools answer
"what should I bet right now" with a table you scan top to bottom. Ours
answered "what is this price worth", one price at a time, which is a
statistician's question and not a bettor's.

**A board is only as real as its prices.** Every row here comes from a market
this process was handed — a recorded snapshot, or a live provider when one is
configured. Nothing is generated to fill the screen. With no source of prices
there are no rows, and the caller is told that plainly rather than shown a
plausible table. A board that invents its own rows is the single most
expensive lie this codebase could tell, because every row is an instruction to
go and stake money.

**Ranked by what you actually collect.** Not by headline margin: an arb whose
second leg is unlikely to still be there when you get to it is worth less than
a smaller one that will be. `realised` is margin multiplied by the chance both
legs survive, and that is the sort order.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from .arb import find_arbs, stake_arb
from .ev import find_edges
from .middles import find_middles


@dataclass
class Row:
    """One play, with everything needed to place it and nothing else."""

    kind: str                      # arb | ev | middle
    event: str
    sport: str
    market: str
    legs: list[dict] = field(default_factory=list)
    margin: float = 0.0            # the headline number, before survival
    realised: float = 0.0          # margin x chance both legs are still there
    p_fill: float = 1.0
    age: float = 0.0
    stakes: list[float] = field(default_factory=list)
    profit: float = 0.0

    def as_dict(self) -> dict:
        return {
            "kind": self.kind, "event": self.event, "sport": self.sport,
            "market": self.market, "legs": self.legs,
            "margin": self.margin, "realised": self.realised,
            "p_fill": self.p_fill, "age": self.age,
            "stakes": self.stakes, "profit": self.profit,
        }


#: The three shapes of play both OddsJam and AVO put on their screens. Ours
#: was arbitrage only, which is the rarest of the three — a board that shows
#: just arbs is empty most of the time and gives the impression the tool has
#: found nothing, when what it has found is that today is a +EV day.
KINDS = ("arb", "ev", "middle")


def scan(markets, books=None, *, bankroll: float = 1000.0,
         min_margin: float = 0.0, now: float | None = None,
         fill_model=None, latency_model=None,
         kinds: tuple = KINDS, min_ev: float = 0.0) -> list[Row]:
    """Every playable arbitrage across every market handed in, best first.

    `markets` is whatever the caller has — a replay snapshot, a live provider's
    fetch, one demonstration market. This function does not go and get them,
    which is what keeps it honest: it cannot invent a row it was not given.
    """
    if books is None:
        from .cli import DEFAULT_BOOKS
        books = DEFAULT_BOOKS
    now = time.time() if now is None else now
    rows: list[Row] = []

    for market in markets:
        if "arb" not in kinds:
            break
        for found in find_arbs(market, books, now, min_margin=min_margin,
                               fill_model=fill_model,
                               latency_model=latency_model):
            # Staked through the same searcher the arb calculator uses, so a
            # row on the board and the same play typed into the calculator
            # cannot disagree. The legs come back with net decimals; stakes
            # are computed on those, because commission decides the split.
            plan = stake_arb(
                [leg["net_decimal"] for leg in found["legs"]],
                bankroll,
                books=[leg["book"] for leg in found["legs"]],
                outcomes=[leg["outcome"] for leg in found["legs"]],
            )
            legs = [
                {
                    "book": leg["book"],
                    "outcome": leg["outcome"],
                    "decimal": leg["decimal"],
                    "net_decimal": leg["net_decimal"],
                    "age": round(leg["age"], 1),
                    "stake": staked.stake,
                }
                for leg, staked in zip(found["legs"], plan.legs)
            ]
            rows.append(Row(
                kind="arb",
                event=found["event_id"],
                sport=found["sport"],
                market=found["market_type"],
                legs=legs,
                margin=found["margin"],
                realised=found["realised_margin"],
                p_fill=found["p_fill"],
                age=found["max_age"],
                stakes=[leg["stake"] for leg in legs],
                # The GUARANTEED profit — the worst outcome once stakes are
                # rounded — not margin x bankroll, which describes a position
                # nobody holds.
                profit=plan.profit,
            ))

    if "ev" in kinds:
        for market in markets:
            for edge in find_edges(market, books, now, min_ev=min_ev,
                                   fill_model=fill_model,
                                   latency_model=latency_model):
                # One leg, not two: a +EV bet is a single price you believe is
                # mispriced, so there is no second stake and no guarantee. The
                # profit shown is an EXPECTATION over the stake, and the row
                # says so — quoting it beside an arb's guaranteed figure
                # without that distinction is the most misleading thing a
                # board of mixed play types can do.
                stake = round(bankroll * 0.01, 2)
                rows.append(Row(
                    kind="ev",
                    event=edge.event_id, sport=edge.sport,
                    market=edge.market_type,
                    legs=[{"book": edge.book, "outcome": edge.outcome,
                           "decimal": edge.decimal,
                           "net_decimal": edge.decimal,
                           "age": round(edge.quote_age, 1),
                           "stake": stake}],
                    margin=edge.ev,
                    realised=edge.ev * edge.p_fill,
                    p_fill=edge.p_fill,
                    age=edge.quote_age,
                    stakes=[stake],
                    profit=round(edge.ev * stake, 2),
                ))

    if "middle" in kinds:
        for market in markets:
            for plan in find_middles(market, books, total=bankroll, now=now):
                rows.append(Row(
                    kind="middle",
                    event=getattr(market, "event_id", ""),
                    sport=getattr(market, "sport", ""),
                    market=getattr(market, "market_type", ""),
                    legs=[
                        {"book": plan.low_book, "outcome": f"over@{plan.low_line}",
                         "decimal": plan.low_decimal,
                         "net_decimal": plan.low_decimal,
                         "age": 0.0, "stake": plan.low_stake},
                        {"book": plan.high_book, "outcome": f"under@{plan.high_line}",
                         "decimal": plan.high_decimal,
                         "net_decimal": plan.high_decimal,
                         "age": 0.0, "stake": plan.high_stake},
                    ],
                    margin=plan.p_middle,
                    realised=plan.p_middle,
                    p_fill=1.0,
                    age=0.0,
                    stakes=[plan.low_stake, plan.high_stake],
                    profit=0.0,
                ))

    return _rank(rows)


def _rank(rows: list[Row]) -> list[Row]:
    """Best first, by what survives rather than by the headline.

    Its own function so a test can prove the ordering on a fixture where the
    two keys disagree. Ranking inside scan() meant the only available fixture
    was a single row, where every sort key looks identical and a break case
    that ranked by raw margin went undetected.
    """
    return sorted(rows, key=lambda r: r.realised, reverse=True)
