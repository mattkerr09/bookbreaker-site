"""Live prices from venues whose market data is public, with no key and no account.

Two of the twenty-seven venues in the catalog publish their order books to
anyone: Kalshi and Polymarket. Both are real venues people arb, both against
each other and against retail sportsbooks, and neither asks for a key, a card
or a signup. That makes them the only live prices this project can honestly
put on the board today.

**Nothing here is scraped.** These are the venues' own documented JSON
endpoints, requested once per call, unauthenticated, the same request a
browser makes. Retail sportsbooks are deliberately absent: getting DraftKings
prices without a licensed aggregator means defeating bot detection, which is
the exact thing this codebase refuses to do — and it risks the accounts the
user needs in order to place anything. That refusal is the product, not a
limitation of it.

**The fetch is a seam, exactly as in `restfeed`.** `fetcher` is a callable
returning parsed JSON, so the mapping — the part that can be wrong — is tested
exhaustively without a socket. `urllib_fetcher` is the only piece that cannot
be, and it is four lines.

**Opt-in, always.** Nothing in this module runs unless a caller passes
`--live`. The window still links no HTTP client, its CSP still permits no
external origin, and the promise that your betting record never leaves the
machine is untouched: these requests carry no identity, no ledger and no
stake — they are public market data going one way.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field

from .feed import FeedError

KALSHI = "https://api.elections.kalshi.com/trade-api/v2/markets"
POLYMARKET = "https://gamma-api.polymarket.com/markets"


def urllib_fetcher(url: str, timeout: float = 15.0):
    """The only part of this file that opens a socket."""
    from urllib.request import Request, urlopen

    request = Request(url, headers={"Accept": "application/json",
                                    "User-Agent": "bookbreaker"})
    with urlopen(request, timeout=timeout) as response:  # noqa: S310
        return json.loads(response.read().decode())


#: Below this implied probability a contract is a lottery ticket, not a
#: price. Kalshi lists 0.1c longshots on combination markets, which invert to
#: decimal 1000 and sit at the top of any board sorted by price while being
#: untradable in any size. Filtered rather than shown, because a board is a
#: list of things to do.
MIN_TRADABLE_PROB = 0.02

#: Neither venue's list endpoint carries a per-quote timestamp, so `seen_at`
#: is our receipt time and every quote says so. Named rather than repeated,
#: so it is one decision in one place — and so a break case can flip it.
DATED_BY_VENUE = False


def _prob_to_decimal(p: float) -> float:
    """A contract price IS a probability; invert it for a decimal price.

    Both venues quote what you pay for a $1 payout, so 0.45 is an implied 45%
    and a decimal price of 1/0.45. A zero or a one is not a tradable price and
    is refused rather than turned into infinity — an unbounded decimal makes
    every arb detector report a certainty.
    """
    if not MIN_TRADABLE_PROB <= p <= 1.0 - MIN_TRADABLE_PROB:
        raise FeedError(f"{p} is outside the tradable band")
    return 1.0 / p


@dataclass
class KalshiProvider:
    """Kalshi's public market list. No key, no account.

    Kalshi is a CFTC-regulated exchange, so its prices are yes/no contracts
    rather than moneylines, and both sides are quoted: `yes_ask` is what you
    pay to back it, `no_ask` what you pay to fade it. Two sides at one venue
    is not an arbitrage — it is the spread — so this reports both and lets
    the board pair them against other venues.
    """

    fetcher: callable = urllib_fetcher
    limit: int = 100
    key: str = "kalshi"
    _raw: dict = field(default_factory=dict, repr=False)

    def fetch(self) -> list[dict]:
        payload = self.fetcher(f"{KALSHI}?limit={self.limit}&status=open")
        self._raw = payload
        return self.map(payload)

    @staticmethod
    def map(payload: dict) -> list[dict]:
        """Payload to quotes. Pure, so it is tested without a socket."""
        now = time.time()
        out = []
        for m in payload.get("markets", []):
            # `yes_ask_dollars`, not `yes_ask`. The short names still exist
            # and are all None — reading them mapped every market to zero
            # quotes and looked exactly like an empty board.
            for side, price in (("yes", m.get("yes_ask_dollars")),
                                ("no", m.get("no_ask_dollars"))):
                if price in (None, ""):
                    continue
                try:
                    decimal = _prob_to_decimal(float(price))
                except (FeedError, TypeError, ValueError):
                    continue
                out.append({
                    "venue": "kalshi",
                    "outcome_count": 2,
                    "event": m.get("ticker", ""),
                    "title": (m.get("title") or "")[:120],
                    "outcome": side,
                    "cents": round(float(price) * 100, 2),
                    "decimal": round(decimal, 4),
                    # Kalshi's list endpoint carries no per-quote timestamp,
                    # so this is our receipt time and is marked as such. A
                    # quote the venue did not date is never treated as fresh.
                    "seen_at": now,
                    "dated_by_venue": DATED_BY_VENUE,
                })
        return out


@dataclass
class PolymarketProvider:
    """Polymarket's public gamma API. No key, no account."""

    fetcher: callable = urllib_fetcher
    limit: int = 100
    key: str = "polymarket"

    def fetch(self) -> list[dict]:
        return self.map(self.fetcher(
            f"{POLYMARKET}?limit={self.limit}&closed=false&order=liquidity&ascending=false"))

    @staticmethod
    def map(payload) -> list[dict]:
        now = time.time()
        out = []
        for m in payload if isinstance(payload, list) else payload.get("data", []):
            prices = m.get("outcomePrices")
            names = m.get("outcomes")
            if isinstance(prices, str):
                try:
                    prices = json.loads(prices)
                except json.JSONDecodeError:
                    continue
            if isinstance(names, str):
                try:
                    names = json.loads(names)
                except json.JSONDecodeError:
                    continue
            if not prices or not names or len(prices) != len(names):
                continue
            outcome_count = len(names)
            for name, price in zip(names, prices):
                try:
                    p = float(price)
                except (TypeError, ValueError):
                    continue
                try:
                    decimal = _prob_to_decimal(p)
                except FeedError:
                    continue
                out.append({
                    "venue": "polymarket",
                    "outcome_count": outcome_count,
                    "event": m.get("slug", ""),
                    "title": (m.get("question") or "")[:120],
                    "outcome": str(name).lower(),
                    "cents": round(p * 100, 2),
                    "decimal": round(decimal, 4),
                    "seen_at": now,
                    "dated_by_venue": DATED_BY_VENUE,
                })
        return out


#: Kalshi series that are single-game, two-sided markets. The bare
#: /markets list is dominated by combination and long-horizon contracts —
#: the first board built from it showed eight quotes, all parlays, and no
#: overlap with anything. These are the slices where an arb can exist.
GAME_SERIES = ("KXMLBGAME", "KXNFLGAME", "KXNBAGAME", "KXNHLGAME")


def kalshi_games(fetcher=urllib_fetcher, series=GAME_SERIES, limit=200):
    """Every open single-game market, keyed by the game its ticker encodes."""
    out = []
    for ticker in series:
        try:
            payload = fetcher(f"{KALSHI}?limit={limit}&status=open"
                              f"&series_ticker={ticker}")
        except Exception:                                # noqa: BLE001
            continue
        out.extend(KalshiProvider.map(payload))
    return out


def complete_books(quotes):
    """Markets where we hold EVERY outcome, keyed by market.

    This replaces a version that paired any two quotes sharing a key, and that
    version was dangerous rather than merely wrong. Polymarket football markets
    are three-way — home, draw, away — and backing two of the three is not an
    arbitrage: the third result loses both legs. The first live run reported
    ten "playable" arbs at 2.04% and every one of them was two legs of a
    three-way market. Acting on one costs the whole stake.

    So a market is only considered when the quotes in hand are the complete
    set of mutually exclusive outcomes. Kalshi single-game series are binary
    by construction and the ticker names the fixture. Polymarket states its
    own outcome count, and anything short of all of them is skipped.
    """
    books: dict[str, dict] = {}
    for q in quotes:
        if q["venue"] == "kalshi":
            ticker = q["event"]
            if q["outcome"] != "yes" or "-" not in ticker:
                continue
            key = ticker.rsplit("-", 1)[0]
            entry = books.setdefault(key, {"venue": "kalshi", "expect": 2,
                                           "legs": [], "title": q["title"]})
            entry["legs"].append(q)
        else:
            key = q["event"]
            entry = books.setdefault(key, {"venue": q["venue"],
                                           "expect": q.get("outcome_count"),
                                           "legs": [], "title": q["title"]})
            entry["legs"].append(q)

    complete = {}
    for key, entry in books.items():
        if is_complete(entry):
            complete[key] = entry
    return complete


def is_complete(entry) -> bool:
    """Do we hold every mutually exclusive outcome of this market?

    One function and one decision, so a break case can prove it. This was two
    consecutive guards, and breaking either left the other catching the
    three-way case — which made the case that was supposed to prove the guard
    prove nothing at all.

    Distinct outcomes, not leg count: two quotes for the same side is not a
    book, and counting them as one would price half a market as a whole one.
    """
    expect = entry.get("expect")
    if not expect or expect < 2:
        return False
    return len({leg["outcome"] for leg in entry["legs"]}) == expect


#: A play has to beat this to be worth listing. Two sides summing to exactly
#: 1.0000 is the market being efficient, not an opportunity — it returns the
#: stake and pays for the time it took. The first live run found four of them
#: and called them arbitrage.
MIN_WORTHWHILE_MARGIN = 0.002


def find_public_arbs(quotes, min_margin: float = MIN_WORTHWHILE_MARGIN):
    """Two sides of one game whose prices sum to less than the payout.

    On a binary contract, backing both sides costs yes(A) + yes(B) for a
    payout of 1. Under 1.00 is a guaranteed profit; the margin is what is
    left over.
    """
    found = []
    for key, entry in complete_books(quotes).items():
        legs = entry["legs"]
        cost = sum(1.0 / q["decimal"] for q in legs)
        if cost <= 0:
            continue
        margin = (1.0 / cost) - 1.0
        if margin < min_margin:
            continue
        found.append({
            "game": key,
            "venue": entry["venue"],
            "cost": round(cost, 4),
            "margin": margin,
            "title": entry["title"],
            "outcomes": len(legs),
            "legs": [{"outcome": (q["event"].rsplit("-", 1)[1]
                                  if q["venue"] == "kalshi" else q["outcome"]),
                      "price": q["cents"] / 100.0,
                      "decimal": q["decimal"]} for q in legs],
        })
    found.sort(key=lambda f: f["margin"], reverse=True)
    return found
