"""Low hold: turning money over at the smallest cost you can find.

Betting both sides of a market across two books usually loses a little. When
the combined margin goes negative it is an arbitrage and `arb.py` handles it.
This module is for the far more common case just above zero — the bet that
costs 0.4% instead of 4.6%, and exists so a person can put volume through an
account without paying retail for it.

That is a real thing people do, for real reasons: clearing a rollover, taking
a promotion that needs turnover, or simply not looking like an account that
only ever bets one side of steam. It is also the thing most likely to be sold
dishonestly, so this module is built as a **cost** calculator and not an
opportunity finder.

**The cost is certain and it is reported first.** Turning over $10,000 at
1.8% hold costs $180. That is the number. Whether the promotion or the
account longevity it buys is worth $180 is a judgement the caller makes, and
nothing here will make it for them by quietly calling the cost an
"investment".

**It never presents a loss as a profit.** A hold of 0.4% is 0.4% gone. The
comparison offered is against the *alternative* — what the same turnover
costs at one book — because that is the only honest framing: this is cheaper
than the obvious way, not free.

On the line this project does not cross: low hold is **bet shape**. It is a
statement about which prices you take, and it involves no identity, no
device, no location and no account of anyone else's. That is why it is here
and why the account-longevity work stops where it does.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product

from .odds import OddsError, decimal_to_prob


@dataclass
class Quote:
    book: str
    side: str
    decimal: float


@dataclass
class Pairing:
    """One way of covering every side, and what it costs."""

    picks: list[Quote]
    hold: float                       # positive is a cost, negative an arb

    @property
    def is_arb(self) -> bool:
        return self.hold < 0

    def stakes(self, total: float) -> list[dict]:
        """Stakes that return the same amount whichever side lands."""
        weights = [1.0 / q.decimal for q in self.picks]
        denom = sum(weights)
        out = []
        for q, w in zip(self.picks, weights):
            stake = total * w / denom
            out.append({"book": q.book, "side": q.side, "decimal": q.decimal,
                        "stake": round(stake, 2),
                        "returns": round(stake * q.decimal, 2)})
        return out

    def cost_of(self, turnover: float) -> float:
        """What this pairing costs to put `turnover` through. Signed."""
        return round(turnover * self.hold, 2)


def _hold(picks: list[Quote]) -> float:
    return sum(decimal_to_prob(q.decimal) for q in picks) - 1.0


def best(quotes: list[Quote], sides: list[str] | None = None,
         limit: int = 5) -> list[Pairing]:
    """Cheapest ways to cover every side, best first.

    One quote per side, and they may come from different books — that is the
    entire mechanism. Same-book pairings are included rather than filtered,
    because the whole point is showing how much worse the obvious way is.
    """
    if not quotes:
        raise OddsError("no quotes to work with")
    for q in quotes:
        if q.decimal <= 1.0:
            raise OddsError(
                f"{q.book} {q.side}: decimal odds must exceed 1.0, "
                f"got {q.decimal}")
    names = sides or sorted({q.side for q in quotes})
    if len(names) < 2:
        raise OddsError(
            "a market needs at least two sides to cover; got "
            f"{len(names)}")
    by_side = {s: [q for q in quotes if q.side == s] for s in names}
    for side, found in by_side.items():
        if not found:
            raise OddsError(f"no quote for side {side!r}")

    pairings = [Pairing(list(combo), _hold(list(combo)))
                for combo in product(*(by_side[s] for s in names))]
    pairings.sort(key=lambda p: p.hold)
    return pairings[:limit]


def single_book_baseline(quotes: list[Quote],
                         sides: list[str] | None = None) -> Pairing | None:
    """The cheapest pairing available without leaving one book.

    The comparison that makes the number mean something. If no single book
    prices every side, there is no baseline and this returns None rather than
    inventing one.
    """
    names = sides or sorted({q.side for q in quotes})
    best_single = None
    for book in sorted({q.book for q in quotes}):
        picks = []
        for side in names:
            here = [q for q in quotes if q.book == book and q.side == side]
            if not here:
                break
            picks.append(max(here, key=lambda q: q.decimal))
        else:
            candidate = Pairing(picks, _hold(picks))
            if best_single is None or candidate.hold < best_single.hold:
                best_single = candidate
    return best_single
