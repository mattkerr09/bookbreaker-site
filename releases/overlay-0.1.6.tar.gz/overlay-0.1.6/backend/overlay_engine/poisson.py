"""Poisson scorelines, and where the model stops being true.

Given an expected goal count for each side, a Poisson gives the probability of
every scoreline, and from those the totals, the moneyline and the correct
score. It is the standard model for low-scoring sports and it is genuinely
useful — which is exactly why the places it fails are worth naming rather
than hiding behind a clean-looking number.

**It assumes the two sides are independent.** They are not. A team that goes
two down attacks more; a team ahead defends. Real scorelines have more draws
and more blowouts than independent Poissons predict, and 0-0 in particular is
underpriced by this model in football.

**It assumes a constant rate.** Goals are not uniformly distributed across a
match; late goals are more common, and red cards break the rate entirely.

So every result here carries the model it came from, and the module reports
the totals line *and* the disagreement between a Poisson and the price the
book is offering, which is the only number a bettor can act on. A calculator
that prints "62.4%" without saying what would have to be true for that to
hold is selling confidence it has not earned.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import exp, factorial

from .odds import OddsError

#: Beyond this the probabilities are far below rounding noise, and the
#: factorial starts costing more than the answer is worth.
MAX_GOALS = 15


def pmf(lam: float, k: int) -> float:
    """Probability of exactly k events at rate lam."""
    return exp(-lam) * lam ** k / factorial(k)


def grid(home: float, away: float) -> list[list[float]]:
    """The full scoreline matrix, under independence."""
    return [[pmf(home, h) * pmf(away, a) for a in range(MAX_GOALS + 1)]
            for h in range(MAX_GOALS + 1)]


@dataclass
class Scoreline:
    home_lambda: float
    away_lambda: float

    def matrix(self) -> list[list[float]]:
        return grid(self.home_lambda, self.away_lambda)

    def outcomes(self) -> dict:
        """Home / draw / away, from the same matrix."""
        m = self.matrix()
        home = sum(m[h][a] for h in range(MAX_GOALS + 1)
                   for a in range(MAX_GOALS + 1) if h > a)
        draw = sum(m[i][i] for i in range(MAX_GOALS + 1))
        away = sum(m[h][a] for h in range(MAX_GOALS + 1)
                   for a in range(MAX_GOALS + 1) if h < a)
        total = home + draw + away
        return {"home": home / total, "draw": draw / total,
                "away": away / total, "captured": round(total, 6)}

    def total_over(self, line: float) -> dict:
        """P(total goals > line).

        The sum of two independent Poissons is Poisson at the combined rate,
        so this needs no grid — and a half-line has no push, which is the
        whole reason books quote them.
        """
        combined = self.home_lambda + self.away_lambda
        whole = abs(line - round(line)) < 1e-9
        under = sum(pmf(combined, k) for k in range(int(line) + 1))
        push = pmf(combined, int(round(line))) if whole else 0.0
        if whole:
            under -= push
        over = 1.0 - under - push
        return {"line": line, "over": over, "under": under, "push": push,
                "combined_lambda": combined,
                "pushes": whole}

    def exact(self, home_goals: int, away_goals: int) -> float:
        return pmf(self.home_lambda, home_goals) * pmf(self.away_lambda,
                                                        away_goals)

    def top_scorelines(self, n: int = 6) -> list[dict]:
        m = self.matrix()
        rows = [{"score": f"{h}-{a}", "prob": m[h][a]}
                for h in range(7) for a in range(7)]
        rows.sort(key=lambda r: -r["prob"])
        return rows[:n]


def build(home: float, away: float) -> Scoreline:
    for name, lam in (("home", home), ("away", away)):
        if lam <= 0:
            raise OddsError(f"{name} expected goals must be positive, got {lam}")
        if lam > 12:
            raise OddsError(
                f"{name} expected goals of {lam} is outside anything Poisson "
                f"models usefully — this is not a low-scoring sport")
    return Scoreline(home, away)


def disagreement(model_prob: float, book_decimal: float) -> dict:
    """What the model says against what the book is charging.

    The only actionable number here, and it is reported as an edge *under this
    model* rather than as an edge, because the model's independence assumption
    is known to be false.
    """
    if book_decimal <= 1.0:
        raise OddsError(f"decimal odds must exceed 1.0, got {book_decimal}")
    implied = 1.0 / book_decimal
    return {
        "model": model_prob,
        "book_implied": implied,
        "edge_under_this_model": model_prob * book_decimal - 1.0,
        "caveat": "Poisson assumes the two sides score independently. They do "
                  "not. Treat this as one model's opinion, not a fair price.",
    }
