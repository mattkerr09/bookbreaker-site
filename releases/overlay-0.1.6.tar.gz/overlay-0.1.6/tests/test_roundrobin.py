"""A round robin is sold as risk management. It is mostly extra vig.

These tests pin the parts a calculator gets wrong in the bettor's disfavour:
the break-even leg count, the fact that "n legs won" is a range rather than a
number when the prices differ, and the refusal to print an expected value
computed from the book's own margin.
"""

import pytest

from overlay_engine.odds import OddsError
from overlay_engine.roundrobin import build


def test_ticket_count_is_the_binomial():
    assert build([2.0] * 4, [2], 10.0).tickets == 6
    assert build([2.0] * 4, [3], 10.0).tickets == 4
    assert build([2.0] * 4, [2, 3], 10.0).tickets == 10


def test_a_fair_book_gives_exactly_zero_edge():
    """Even-money legs at true 50% must price to zero, or the model has a
    thumb on the scale somewhere."""
    rr = build([2.0, 2.0, 2.0], [2], 10.0, probs=[0.5, 0.5, 0.5])
    assert rr.expected_value()["expected_profit"] == pytest.approx(0.0, abs=1e-9)


def test_vig_makes_the_round_robin_lose_faster_than_singles():
    """The whole point. Each parlay multiplies the hold, so the same money on
    singles is less bad — and the caller is told so."""
    legs = [1.91, 1.91, 1.91]                # -110, i.e. 4.8% hold a side
    fair = [0.5, 0.5, 0.5]
    rr = build(legs, [2], 10.0, probs=fair)
    ev = rr.expected_value()
    assert ev["expected_profit"] < 0
    assert ev["singles_are_better"] is True


def test_n_legs_won_is_a_range_when_the_prices_differ():
    """With mixed prices "two legs landed" is not one payout, and reporting
    the average as if it were is wrong exactly when it matters."""
    rr = build([1.5, 2.0, 5.0], [2], 10.0)
    two = next(r for r in rr.by_leg_count() if r["legs_won"] == 2)
    assert two["returned_low"] < two["returned_high"]


def test_break_even_is_the_first_always_profitable_count():
    rr = build([2.0, 2.0, 2.0], [2], 10.0)
    assert rr.breakeven_legs() == 2
    # One leg pays nothing at all in a by-2 robin: no ticket is complete.
    one = next(r for r in rr.by_leg_count() if r["legs_won"] == 1)
    assert one["returned_high"] == 0.0


def test_a_full_sweep_always_clears_the_stake():
    """Written first as "some robins cannot profit", which is false: every
    ticket pays more than the stake on it, so cashing all of them beats the
    total however short the prices are. The unreachable branch that assumed
    otherwise is gone."""
    for price in (1.02, 1.05, 1.5, 6.0):
        rr = build([price] * 3, [2], 10.0)
        assert rr.breakeven_legs() <= 3
        sweep = rr.by_leg_count()[-1]
        assert sweep["profit_low"] > 0


def test_no_probabilities_means_no_expected_value():
    """An EV from the book's own prices describes its margin, not an edge.
    Printing it as an edge is the most misleading thing this could do."""
    assert build([2.0, 2.0], [2], 10.0).expected_value() is None


def test_correlated_legs_are_labelled_not_silently_priced():
    rr = build([2.0, 2.0], [2], 10.0, probs=[0.5, 0.5], correlated=True)
    assert "bound" in rr.expected_value()["independence"]


@pytest.mark.parametrize("legs,sizes,stake", [
    ([2.0], [2], 10.0),           # one leg is not a round robin
    ([2.0, 2.0], [1], 10.0),      # a "parlay" of one is a single
    ([2.0, 2.0], [3], 10.0),      # more legs than exist
    ([1.0, 2.0], [2], 10.0),      # a price that returns the stake
    ([2.0, 2.0], [2], 0.0),       # no money
])
def test_it_refuses_rather_than_guesses(legs, sizes, stake):
    with pytest.raises(OddsError):
        build(legs, sizes, stake)
