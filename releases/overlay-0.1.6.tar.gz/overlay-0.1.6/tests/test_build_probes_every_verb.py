"""The built app is asked every question the window can ask it.

Every test in this repo runs from source. The built app is a different
artefact — a frozen engine with only what PyInstaller was told to include —
and 0.1.6 was one build away from shipping an Offers tab that crashed on
open: its data file lived at repo/data/, the tests found it there, and the
bundle did not contain it. build_app.sh probed three verbs by hand while the
window could send ten, so nothing ever asked the built engine about offers.

These run without building anything, which is the point: they fail on the
commit that would have let it happen.
"""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUST = "\n".join(p.read_text() for p in (ROOT / "ui/src-tauri/src").glob("*.rs"))
BUILD = (ROOT / "scripts/build_app.sh").read_text()


def allowed():
    m = re.search(r"const ALLOWED: \[&str; \d+\] = \[([^\]]+)\]", RUST)
    return set(re.findall(r'"([a-z-]+)"', m.group(1)))


def test_every_verb_the_window_can_send_has_a_build_probe():
    probed = set(re.findall(r"^\s+([a-z-]+)\)\s+probe=", BUILD, re.M))
    missing = allowed() - probed
    assert not missing, f"the window can send {sorted(missing)} and the build never asks"


def test_the_probe_list_is_read_from_the_allow_list_not_typed():
    assert "const ALLOWED" in BUILD, "the probe loop must derive its verbs from main.rs"


def test_engine_data_lives_inside_the_package():
    from overlay_engine import welcome
    pkg = Path(welcome.__file__).resolve().parent
    assert welcome.FEED.is_relative_to(pkg) if hasattr(welcome.FEED, "is_relative_to") \
        else str(welcome.FEED).startswith(str(pkg))
    assert welcome.FEED.exists()


def test_the_package_data_directory_is_bundled():
    assert "backend/overlay_engine/data:overlay_engine/data" in BUILD


def test_every_packaged_data_file_is_declared_for_the_wheel():
    """The app bundle and the wheel are packaged by different tools with
    different rules. The offers feed went missing from BOTH in 0.1.6, one after
    the other, each time with every test green."""
    pyproject = (ROOT / "pyproject.toml").read_text()
    data = ROOT / "backend" / "overlay_engine" / "data"
    for f in data.iterdir():
        if f.is_file():
            assert f'"data/*{f.suffix}"' in pyproject, (
                f"{f.name} is read at runtime and not declared as package data")


def test_the_release_check_runs_the_commands_that_read_data():
    release = (ROOT / "scripts" / "release.sh").read_text()
    for verb in ("welcome", "board", "paste", "import"):
        assert f'"$OVERLAY" {verb}' in release, verb
