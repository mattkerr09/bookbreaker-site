"""Low hold is a cost calculator, and the cost is the point.

It is the feature most likely to be sold dishonestly — "free turnover" — so
these tests pin the honesty as hard as the arithmetic.
"""

import pytest

from overlay_engine.lowhold import Quote, best, single_book_baseline
from overlay_engine.odds import OddsError

MARKET = [
    Quote("dk", "home", 1.91), Quote("dk", "away", 1.91),
    Quote("fd", "home", 2.02), Quote("fd", "away", 1.83),
    Quote("mgm", "home", 1.87), Quote("mgm", "away", 1.98),
]


def test_the_best_pairing_crosses_books():
    """If the answer were ever a single book, the tool would have no reason
    to exist."""
    top = best(MARKET)[0]
    assert len({q.book for q in top.picks}) == 2


def test_pairings_are_ranked_cheapest_first():
    holds = [p.hold for p in best(MARKET, limit=6)]
    assert holds == sorted(holds)


def test_the_single_book_baseline_is_worse_than_splitting():
    """The only honest framing: cheaper than the obvious way, not free."""
    assert single_book_baseline(MARKET).hold > best(MARKET)[0].hold


def test_a_positive_hold_is_a_cost_not_a_profit():
    """The sign convention that everything else depends on. A 2% hold on
    10,000 must be -200 to the bettor, never +200."""
    pairing = best(MARKET, limit=6)[-1]
    assert pairing.hold > 0
    assert pairing.cost_of(10_000) > 0
    assert not pairing.is_arb


def test_a_negative_hold_is_flagged_as_an_arbitrage():
    market = [Quote("a", "home", 2.10), Quote("b", "away", 2.10)]
    top = best(market)[0]
    assert top.hold < 0 and top.is_arb


def test_stakes_return_the_same_whichever_side_lands():
    """A "low hold" pairing staked wrong is just two bets."""
    legs = best(MARKET)[0].stakes(1000.0)
    returns = [leg["returns"] for leg in legs]
    assert max(returns) - min(returns) < 0.05
    assert sum(leg["stake"] for leg in legs) == pytest.approx(1000.0, abs=0.02)


def test_no_baseline_is_reported_rather_than_invented():
    """When no single book prices every side there is no comparison, and
    making one up would flatter the result."""
    split = [Quote("a", "home", 2.0), Quote("b", "away", 2.0)]
    assert single_book_baseline(split) is None


def test_it_refuses_a_market_it_cannot_cover():
    with pytest.raises(OddsError):
        best([])
    with pytest.raises(OddsError):
        best([Quote("a", "home", 2.0)])                 # one side only
    with pytest.raises(OddsError):
        best([Quote("a", "home", 1.0), Quote("b", "away", 2.0)])
