"""`performance --json` against a ledger that actually has bets in it.

This file exists because of a specific failure. The Results panel was built,
wired, tested and gated entirely against an EMPTY ledger — which yields empty
lists for every breakdown, so the code that serialises a breakdown row never
ran once. It was written against the wrong dataclass (`Slice` carries `label`,
not `key`) and raised AttributeError on the first real ledger it saw.

Every assertion here needs bets to exist. A fixture that produces none would
make the whole file pass while testing nothing, so the first test refuses that.
"""

import json
import subprocess
import sys
import time
from pathlib import Path

import pytest

from overlay_engine.ledger import Ledger

ROOT = Path(__file__).resolve().parent.parent
BOOKS = ("dk", "fd", "mgm", "circa")
SPORTS = ("nba", "nfl", "mlb")


@pytest.fixture
def ledger(tmp_path):
    """A settled record across several books, sports and prices."""
    path = tmp_path / "seed.db"
    now = time.time()
    with Ledger(str(path)) as db:
        for i in range(24):
            decimal = 1.80 + (i % 5) * 0.12
            stake = float(50 * (1 + i % 4))
            won = i % 3 != 0
            db.import_bet(
                event_id=f"evt_{i:03d}", sport=SPORTS[i % len(SPORTS)],
                market_type="h2h", outcome="home", book=BOOKS[i % len(BOOKS)],
                decimal_odds=round(decimal, 3), stake=stake,
                placed_at=now - (24 - i) * 86400,
                result="won" if won else "lost",
                profit=round(stake * (decimal - 1), 2) if won else -stake,
                settled_at=now - (24 - i) * 86400 + 3600,
            )
    return path


def run(path, *extra):
    done = subprocess.run(
        [sys.executable, str(ROOT / "backend" / "cli.py"), "performance",
         "--db", str(path), "--json", *extra],
        capture_output=True, text=True, timeout=120)
    assert done.returncode == 0, done.stderr[-600:]
    return json.loads(done.stdout)


def test_the_fixture_actually_produces_bets(ledger):
    """Without this, every test below passes against an empty ledger and
    proves nothing — which is exactly how the bug they exist to catch
    survived a green suite."""
    out = run(ledger)
    assert out["settled"] >= 20
    assert out["by_book"] and out["by_sport"] and out["by_price"]


def test_every_breakdown_row_serialises(ledger):
    """The row shape is the thing that was wrong. `Slice` has `label`, not
    `key`, and `flat_return`, not `roi`."""
    out = run(ledger)
    for name in ("by_book", "by_sport", "by_market", "by_price"):
        for row in out[name]:
            for field in ("key", "n", "won", "lost", "turnover", "profit",
                          "roi", "win_rate"):
                assert field in row, f"{name} row missing {field}"
            assert isinstance(row["key"], str) and row["key"]


def test_the_breakdowns_add_up_to_the_whole(ledger):
    """A breakdown that does not reconcile with the total is a breakdown of
    something else."""
    out = run(ledger)
    for name in ("by_book", "by_sport"):
        assert sum(r["n"] for r in out[name]) == out["settled"], name
        assert sum(r["profit"] for r in out[name]) == pytest.approx(
            out["profit"], abs=0.02), name


def test_money_roi_and_flat_roi_are_both_reported(ledger):
    """The gap between them is the bettor's staking rather than their
    picking, and it is the one thing this tracker says that Pikkit does
    not."""
    out = run(ledger)
    assert "roi" in out and "flat_return" in out
    assert out["roi"] != 0.0


def test_filters_narrow_the_result(ledger):
    everything = run(ledger)
    one_book = run(ledger, "--book", "dk")
    assert 0 < one_book["settled"] < everything["settled"]
    assert {r["key"] for r in one_book["by_book"]} == {"dk"}


def test_clv_is_absent_rather_than_zero_when_nothing_is_graded(ledger):
    """None means "not measured". Zero would mean "measured, and you are
    exactly at the close", which is a completely different claim."""
    out = run(ledger)
    assert out["clv"] is None
    assert out["graded"] == 0


def test_breakdowns_reconcile_past_the_display_cap(tmp_path):
    """More books than the table shows must still add up.

    Breakdowns are capped at the busiest eight. Across fourteen books that
    used to display eight rows covering sixteen of twenty-eight bets — 43% of
    the record missing from a table that looked complete, with nothing saying
    so. Arbitrage is played across many books by definition, so this misled
    precisely the people the product is for.
    """
    path = tmp_path / "many.db"
    now = time.time()
    books = [f"book{i:02d}" for i in range(14)]
    with Ledger(str(path)) as db:
        for i, book in enumerate(books * 2):
            won = i % 2 == 1
            db.import_bet(
                event_id=f"e{i}", sport="nba", market_type="h2h",
                outcome="home", book=book, decimal_odds=1.9, stake=100.0,
                placed_at=now - 3600, result="won" if won else "lost",
                profit=90.0 if won else -100.0, settled_at=now)

    out = run(path)
    assert len(out["by_book"]) < len(books), "the cap should still apply"
    assert sum(r["n"] for r in out["by_book"]) == out["settled"], (
        "the by-book rows do not account for every settled bet")
    assert sum(r["profit"] for r in out["by_book"]) == pytest.approx(
        out["profit"], abs=0.02)
    assert any("more" in r["key"] for r in out["by_book"]), (
        "the remainder must be visible, not implied")
