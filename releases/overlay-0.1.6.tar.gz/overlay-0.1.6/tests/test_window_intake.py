"""Getting bets into the ledger from the window, without a sportsbook login.

The honest version of "connect your sportsbook": paste a slip, or hand over
the CSV the book exports. The window has no stdin and cannot pass a path, so
both arrive as `--text`. What must hold is what already held on the command
line — nothing is written until the reading is checked, and a slip with no
price is refused.
"""

import glob
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CLI = ROOT / "backend" / "cli.py"
SLIP = "DraftKings\nBoston Celtics Moneyline\nCeltics -150\nWager $30.00\nWon"


def _run(*argv):
    done = subprocess.run([sys.executable, str(CLI), *argv, "--json"],
                          capture_output=True, text=True, timeout=120)
    return done.returncode, json.loads(done.stdout) if done.stdout.strip() else {}


def _bets(db):
    if not Path(db).exists():
        return 0
    with sqlite3.connect(db) as c:
        return c.execute("select count(*) from bets").fetchone()[0]


def test_reading_a_slip_writes_nothing(tmp_path):
    """With an event supplied, so --write is the ONLY thing between reading
    and saving. Without one, the missing event blocked the write on its own
    and a break case that deleted the --write check passed straight through."""
    db = tmp_path / "l.db"
    code, out = _run("paste", f"--text={SLIP}", "--db", str(db),
                     "--event", "slip-test")
    assert code == 0 and out["usable"]
    assert out["written"] is False
    assert _bets(db) == 0


def test_saving_a_slip_writes_one_bet(tmp_path):
    db = tmp_path / "l.db"
    code, out = _run("paste", f"--text={SLIP}", "--db", str(db),
                     "--write", "--event", "slip-test")
    assert out["written"] is True
    assert _bets(db) == 1


def test_a_slip_starting_with_a_price_survives_argparse(tmp_path):
    """`-150 Celtics…` as a separate argument is read as an option. The window
    sends `--text=…` as one token so it never is."""
    code, out = _run("paste", "--text=-150 Celtics moneyline\nWager $30.00",
                     "--db", str(tmp_path / "l.db"))
    assert "decimal_odds" in out.get("fields", {}), out


def test_a_slip_with_no_price_is_refused_and_not_saved(tmp_path):
    db = tmp_path / "l.db"
    code, out = _run("paste", "--text=Celtics moneyline wager $30", "--db",
                     str(db), "--write", "--event", "e")
    assert out["usable"] is False and "decimal_odds" in out["needs"]
    assert _bets(db) == 0


def test_importing_csv_text_leaves_no_temp_file(tmp_path):
    csv = ("date,sportsbook,sport,bet_type,selection,odds,stake,result,profit\n"
           "2026-09-01,FanDuel,NFL,moneyline,Chiefs,-120,60,won,50\n")
    before = set(glob.glob(os.path.join(tempfile.gettempdir(), "tmp*.csv")))
    code, out = _run("import", f"--text={csv}", "--db", str(tmp_path / "l.db"))
    after = set(glob.glob(os.path.join(tempfile.gettempdir(), "tmp*.csv")))
    assert out["imported"] == 1
    assert after == before, f"left behind: {after - before}"
