"""Welcome offers, ranked by what converts — and never shown unsourced.

The competitor tables sort by headline. The headline is the one number on
the page that is not what the bettor keeps, so the failures that matter here
are ranking by it, pricing a stale offer as current, and loading one with no
source at all.
"""

import csv
import datetime as dt
import json
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import welcome
from overlay_engine.promo import bonus_bet_conversion

ROOT = Path(__file__).resolve().parent.parent
FIELDS = ["book", "offer_type", "headline", "qualifying_stake", "bonus",
          "installments", "boost", "max_stake", "expires_days", "read",
          "source", "note"]


def _feed(tmp_path, rows):
    path = tmp_path / "offers.csv"
    with path.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in FIELDS})
    return path


def _row(book, bonus, **kw):
    base = dict(book=book, offer_type="bet_and_get", headline=f"{book} offer",
                qualifying_stake="10", bonus=str(bonus), installments="1",
                expires_days="7", read=str(dt.date.today()),
                source=f"https://example.com/{book}")
    base.update(kw)
    return base


def test_a_row_with_no_source_does_not_load(tmp_path):
    path = _feed(tmp_path, [_row("dk", 150, source="")])
    with pytest.raises(ValueError, match="no source"):
        welcome.load(path)


def test_a_row_with_no_read_date_does_not_load(tmp_path):
    path = _feed(tmp_path, [_row("dk", 150, read="")])
    with pytest.raises(ValueError, match="no read date"):
        welcome.load(path)


def test_a_stale_offer_is_listed_and_never_priced(tmp_path):
    old = str(dt.date.today() - dt.timedelta(days=welcome.MAX_AGE_DAYS + 1))
    path = _feed(tmp_path, [_row("dk", 150, read=old)])
    [p] = welcome.price(welcome.load(path))
    assert p.stale
    assert p.guaranteed == 0.0 and p.steps == []


def test_ranked_by_what_you_keep_not_by_the_headline(tmp_path):
    """A bigger face paid in seven one-day installments must still rank by the
    guaranteed figure. The fixture makes headline order and value order
    disagree, or the test cannot tell them apart."""
    path = _feed(tmp_path, [
        _row("dk", 400, qualifying_stake="10000"),  # 2% of 10,000 = 200 lost qualifying
        _row("fd", 300, qualifying_stake="5"),
    ])
    priced = welcome.price(welcome.load(path))
    assert priced[0].face < priced[1].face, "the fixture must disagree"
    assert priced[0].book == "fd"


def test_the_value_is_the_tested_conversion_less_only_the_cost_of_rounding():
    """The exact conversion is the ceiling; rounding the hedge to a human
    stake may cost at most ROUNDING_COST_LIMIT of it, and never adds."""
    hedge = welcome.hedge_decimal(4.0, 0.02)
    exact = bonus_bet_conversion(4.0, hedge, 100.0).guaranteed
    [p] = welcome.price([dict(_row("dk", 100, qualifying_stake="0"), _age=0)])
    assert p.guaranteed <= exact + 1e-9
    assert p.guaranteed >= exact * (1 - welcome.ROUNDING_COST_LIMIT)


def test_no_recommended_hedge_reads_as_calculator_output():
    """The heat model scores cents as the loudest limiting signal. The first
    version of this screen told people to hedge $115.50 and $577.50 — every
    one of them scored 1.00, at the book whose risk desk profiles on it."""
    for p in welcome.price(welcome.load()):
        if p.guaranteed:
            assert p.hedge_stake == int(p.hedge_stake), p
            assert p.hedge_heat <= 0.3, (p.name, p.hedge_stake, p.hedge_heat)


def test_the_steps_say_how_to_keep_the_account():
    for p in welcome.price(welcome.load()):
        if p.guaranteed:
            assert welcome.KEEP_THE_ACCOUNT in p.steps


def test_a_boost_is_never_called_guaranteed():
    [p] = welcome.price([dict(_row("caesars", 0), offer_type="profit_boost",
                              boost="1.0", max_stake="25", installments="10",
                              _age=0)])
    assert p.guaranteed == 0.0
    assert p.expected > 0.0


def test_the_shipped_feed_loads_and_every_row_is_cited():
    rows = welcome.load()
    assert rows, "the shipped feed is empty"
    for r in rows:
        assert r["source"].startswith("https://")


def test_the_cli_states_its_priors():
    done = subprocess.run([sys.executable, str(ROOT / "backend" / "cli.py"),
                           "welcome", "--json"], capture_output=True, text=True,
                          timeout=120)
    assert done.returncode == 0, done.stderr[:400]
    data = json.loads(done.stdout)
    assert "PRIORS" in data["assumptions"]
    assert data["offers"]


def test_an_offer_for_a_venue_we_do_not_cover_does_not_load(tmp_path):
    """`b365` and `czr` are not catalog keys; offers written against them
    rendered as bare codes with no venue behind them."""
    path = _feed(tmp_path, [_row("b365", 200)])
    with pytest.raises(ValueError, match="not a catalog venue"):
        welcome.load(path)
