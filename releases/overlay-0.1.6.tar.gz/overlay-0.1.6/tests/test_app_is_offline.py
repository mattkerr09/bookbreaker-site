"""The window cannot phone home, and that is a product claim.

bookbreaker.bet says the ledger never leaves your machine and there is no
account to create. An update check would be the natural thing to add to a
desktop app and would quietly break that promise: it tells a server that this
person runs this app, at this version, at this moment.

So Bookbreaker has no updater, deliberately, and an installed copy stays the
version it was installed at until someone downloads a new one. That decision
is only worth anything if something enforces it — a later session adding a
"check for updates" menu item would be doing an obviously reasonable thing.
"""

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
CONF = json.loads((UI / "src-tauri" / "tauri.conf.json").read_text())


def test_the_shell_links_no_http_client():
    """A network crate in the manifest is the first step, and the easiest to
    take by accident while adding something else."""
    cargo = (UI / "src-tauri" / "Cargo.toml").read_text().lower()
    for crate in ("reqwest", "ureq", "hyper", "isahc", "curl", "surf"):
        assert f"\n{crate} " not in cargo and f'\n{crate} =' not in cargo, crate


def test_no_tauri_updater_plugin():
    cargo = (UI / "src-tauri" / "Cargo.toml").read_text()
    assert "updater" not in cargo
    assert "updater" not in json.dumps(CONF)


def test_the_frontend_makes_no_requests():
    js = (UI / "src" / "app.js").read_text()
    for call in ("fetch(", "XMLHttpRequest", "WebSocket", "EventSource",
                 "navigator.sendBeacon"):
        assert call not in js, call


def test_no_remote_origin_is_referenced_anywhere_in_the_ui():
    """An <img>, a font or a script from a CDN is a request too, and it leaks
    the same fact as an update check."""
    for name in ("index.html", "app.css", "app.js"):
        text = (UI / "src" / name).read_text()
        urls = re.findall(r"https?://[^\s\"')]+", text)
        assert urls == [], f"{name} references {urls}"


def test_the_csp_permits_no_external_origin():
    """The backstop. Even if code tried, the page cannot reach out."""
    csp = CONF["app"]["security"]["csp"]
    connect = csp["connect-src"]
    assert "'self'" in connect
    # ipc: and ipc.localhost are Tauri's own bridge, not the network.
    for token in connect.split():
        assert token in ("'self'", "ipc:", "http://ipc.localhost"), token
    for key, value in csp.items():
        assert "https://" not in value or key == "connect-src", (key, value)


def test_the_engine_the_window_runs_is_the_bundled_one():
    """A shell that could run an arbitrary binary could run one that does have
    a network. The path is resolved inside the bundle, with an environment
    override that only helps a developer who already has the source."""
    rust = (UI / "src-tauri" / "src" / "main.rs").read_text()
    assert "../Resources/engine/overlay-engine" in rust
    assert "BOOKBREAKER_ENGINE" in rust


def test_the_version_in_the_window_is_the_version_being_built():
    """The footer names the version, so it can be wrong.

    It is there because this app deliberately has no updater and never
    checks for one — a check tells a server that this person runs this app,
    at this version, at this moment, and bookbreaker.bet publishes the
    opposite claim. The cost of that decision is that a user has to know
    what they are running, which makes the string in the footer load-bearing
    rather than decorative. A stale one is worse than none: it tells someone
    on an old build that they are current.
    """
    shown = re.findall(r"You are running ([0-9]+\.[0-9]+\.[0-9]+)",
                       (UI / "src" / "index.html").read_text())
    assert shown, "the window no longer tells the user which version it is"
    assert set(shown) == {CONF["version"]}, (
        f"the window says {set(shown)} and tauri.conf.json says "
        f"{CONF['version']}"
    )


def test_the_window_still_names_no_url():
    """The footer names a domain on purpose, as text. The moment it gains a
    scheme it becomes a link, and a link in a window that promises to make no
    requests is the first step to one that does."""
    text = (UI / "src" / "index.html").read_text()
    assert "https://" not in text and "http://" not in text
    assert "bookbreaker.bet" in text
