"""The board only shows plays it was handed.

The board is the one screen in this product that is an instruction rather
than an answer. Every other command says "here is what this price is worth";
this one says "go and stake this". So the failure that matters is not a wrong
number, it is a row that should not be there at all — an arb the prices do not
support, or a row invented to make a thin board look busy.
"""

import json
import subprocess
import sys
from pathlib import Path

from overlay_engine import board
from overlay_engine.cli import DEFAULT_BOOKS, _demo_market

ROOT = Path(__file__).resolve().parent.parent


def _now(market):
    return max(q.seen_at for q in market.quotes)


def test_no_markets_means_no_rows():
    """The empty board is the honest one, and it is the normal state."""
    assert board.scan([], DEFAULT_BOOKS) == []


def test_it_cannot_invent_a_row():
    """Handed nothing playable, it returns nothing.

    Guarded explicitly because "show something" is the tempting behaviour for
    a screen that looks broken when empty, and every row here is a request for
    real money.
    """
    market = _demo_market()
    # A margin no real market clears. Scoped to arbs, because min_margin
    # filters arbitrage and a +EV offer in the same market is a different
    # question — the first version of this asserted an empty board and broke
    # the moment the board learned to carry more than one kind of play.
    rows = board.scan([market], DEFAULT_BOOKS, min_margin=0.95,
                      now=_now(market), kinds=("arb",))
    assert rows == []


def test_a_real_arb_is_found_and_staked():
    market = _demo_market()
    rows = board.scan([market], DEFAULT_BOOKS, bankroll=1000.0,
                      now=_now(market), kinds=("arb",))
    assert rows, "the demonstration market contains an arbitrage"
    row = rows[0]
    assert len(row.legs) == 2
    assert len({leg["book"] for leg in row.legs}) == 2, "two books, not one"
    assert row.margin > 0
    assert row.profit > 0
    assert sum(leg["stake"] for leg in row.legs) > 0


def test_profit_is_the_guaranteed_figure_not_the_headline():
    """`profit` must be the worst outcome once stakes are rounded.

    margin x bankroll describes a position nobody holds: the rounded legs pay
    differently, and quoting the average would overstate every row on the
    board by a little.
    """
    market = _demo_market()
    row = board.scan([market], DEFAULT_BOOKS, bankroll=1000.0,
                     now=_now(market), kinds=("arb",))[0]
    naive = row.margin * 1000.0
    assert row.profit <= naive + 1e-9, (
        f"profit {row.profit} exceeds the unrounded ideal {naive}")


def test_rows_are_ranked_by_what_survives_not_by_margin():
    """A fat arb you cannot get on is worth less than a thin one you can.

    Needs at least two rows whose two orderings DISAGREE, or the assertion
    passes under either sort key — which is exactly what happened: the first
    version of this test scanned a single market, and a break case that
    ranked by raw margin sailed through it.
    """
    fat = board.Row(kind="arb", event="a", sport="s", market="m",
                    margin=0.05, realised=0.05 * 0.15, p_fill=0.15)
    thin = board.Row(kind="arb", event="b", sport="s", market="m",
                     margin=0.01, realised=0.01 * 0.99, p_fill=0.99)
    assert fat.margin > thin.margin
    assert fat.realised < thin.realised, "the fixture must disagree, or it proves nothing"

    ranked = board._rank([fat, thin])
    assert [r.event for r in ranked] == ["b", "a"], (
        "the thin arb you can actually get on outranks the fat one you cannot")


def test_the_cli_says_where_the_prices_came_from(tmp_path):
    """A board that does not name its source is a board that can be mistaken
    for live. With no feed the demonstration market must announce itself."""
    done = subprocess.run(
        [sys.executable, str(ROOT / "backend" / "cli.py"), "board", "--json"],
        capture_output=True, text=True, timeout=120)
    assert done.returncode == 0, done.stderr[:400]
    data = json.loads(done.stdout)
    assert data["live"] is False
    assert "DEMONSTRATION" in data["source"].upper()
    assert data["markets_scanned"] >= 1


def test_ages_are_measured_against_the_recording():
    """Recorded quotes aged against the wall clock report tens of millions of
    seconds and a zero fill, which makes the one column this product exists to
    add into nonsense.

    Runs the CLI, because the decision being tested lives there. Calling
    board.scan(now=...) directly tests the caller's arithmetic and leaves the
    caller free to pass the wrong clock — which a break case proved by
    blanking it with the test still green.
    """
    done = subprocess.run(
        [sys.executable, str(ROOT / "backend" / "cli.py"), "board", "--json"],
        capture_output=True, text=True, timeout=120)
    assert done.returncode == 0, done.stderr[:400]
    rows = json.loads(done.stdout)["rows"]
    assert rows, "the demonstration market contains an arbitrage"
    assert rows[0]["age"] < 3600, (
        f"age {rows[0]['age']}s — recorded quotes aged against the wall clock")
    for leg in rows[0]["legs"]:
        assert leg["age"] < 3600, f"leg age {leg['age']}s"


# --- three kinds of play, three different promises -------------------------

def test_the_board_carries_ev_as_well_as_arbs():
    """Arbitrage is the rarest of the three. A board that shows only arbs is
    empty most days and reads as "found nothing", when what it found is that
    today is a +EV day."""
    market = _demo_market()
    rows = board.scan([market], DEFAULT_BOOKS, bankroll=1000.0, now=_now(market))
    kinds = {r.kind for r in rows}
    assert "arb" in kinds
    assert "ev" in kinds, "the demonstration market has a +EV offer in it"


def test_kinds_can_be_filtered():
    market = _demo_market()
    only = board.scan([market], DEFAULT_BOOKS, now=_now(market), kinds=("arb",))
    assert only and {r.kind for r in only} == {"arb"}


def test_an_ev_row_has_one_leg_and_an_arb_has_two():
    """The shape is the promise. An arb is two bets that cover each other; a
    +EV bet is one price you think is wrong, with nothing covering it."""
    market = _demo_market()
    rows = board.scan([market], DEFAULT_BOOKS, now=_now(market))
    for row in rows:
        if row.kind == "ev":
            assert len(row.legs) == 1
        if row.kind == "arb":
            assert len(row.legs) == 2


def test_the_cli_never_calls_an_expected_return_guaranteed():
    """The single most misleading thing a mixed board can do is print one
    PROFIT column across guaranteed and expected returns."""
    done = subprocess.run(
        [sys.executable, str(ROOT / "backend" / "cli.py"), "board"],
        capture_output=True, text=True, timeout=120)
    assert done.returncode == 0, done.stderr[:400]
    out = done.stdout
    for line in out.splitlines():
        if line.startswith("ev "):
            assert "guaranteed" not in line
    assert "expected" in out and "guaranteed" in out, (
        "both bases must appear, so the two are visibly different")
    assert "AVERAGE over many" in out
