"""Poisson is the standard model for low-scoring sports, and it is wrong in
known ways. These tests pin both halves: that the arithmetic is right, and
that the caveat travels with the number."""

import pytest

from overlay_engine.odds import OddsError
from overlay_engine.poisson import build, disagreement, pmf


def test_the_distribution_sums_to_one():
    out = build(1.6, 1.2).outcomes()
    assert out["home"] + out["draw"] + out["away"] == pytest.approx(1.0, abs=1e-9)


def test_equal_rates_give_a_symmetric_market():
    out = build(1.4, 1.4).outcomes()
    assert out["home"] == pytest.approx(out["away"], abs=1e-9)


def test_a_whole_number_line_pushes_and_a_half_line_does_not():
    """The reason books quote half-lines at all, and the thing a totals
    calculator most often gets wrong."""
    model = build(1.5, 1.5)
    whole = model.total_over(3.0)
    half = model.total_over(2.5)
    assert whole["push"] > 0 and whole["pushes"] is True
    assert half["push"] == 0.0 and half["pushes"] is False
    assert whole["over"] + whole["under"] + whole["push"] == pytest.approx(1.0)
    assert half["over"] + half["under"] == pytest.approx(1.0)


def test_totals_use_the_combined_rate():
    """The sum of two independent Poissons is Poisson at the combined rate,
    so the totals must not depend on how the goals are split."""
    a = build(2.0, 1.0).total_over(2.5)["over"]
    b = build(1.5, 1.5).total_over(2.5)["over"]
    assert a == pytest.approx(b, abs=1e-12)


def test_more_goals_means_more_overs():
    assert build(2.2, 1.8).total_over(2.5)["over"] > \
           build(1.0, 0.8).total_over(2.5)["over"]


def test_pmf_matches_the_closed_form():
    # lambda 1, k 0 -> e^-1
    assert pmf(1.0, 0) == pytest.approx(0.36787944117144233)


def test_the_caveat_travels_with_the_edge():
    """A bare percentage implies a confidence this model has not earned."""
    out = disagreement(0.53, 1.95)
    assert "independently" in out["caveat"]
    assert out["edge_under_this_model"] == pytest.approx(0.53 * 1.95 - 1.0)


def test_it_refuses_rates_it_cannot_model():
    with pytest.raises(OddsError):
        build(0.0, 1.2)
    with pytest.raises(OddsError):
        build(1.2, -1.0)
    with pytest.raises(OddsError):
        build(40.0, 1.0)     # basketball is not a Poisson sport at this scale
    with pytest.raises(OddsError):
        disagreement(0.5, 1.0)
