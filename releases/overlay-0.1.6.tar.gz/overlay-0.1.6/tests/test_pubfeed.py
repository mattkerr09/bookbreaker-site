"""Public venue mapping, tested without a socket.

The fetch is a seam and the mapping is the part that can be wrong, so every
case here injects a payload. One test does reach the network and is marked so
it can be deselected; it exists because a mapping that is perfect against a
payload shape the venue no longer sends is worth nothing — which is exactly
what happened: `yes_ask` mapped cleanly and is always None, because Kalshi
sends `yes_ask_dollars`.
"""

import pytest

from overlay_engine.pubfeed import (KalshiProvider, PolymarketProvider,
                                    MIN_TRADABLE_PROB)


def test_kalshi_reads_the_dollars_fields():
    got = KalshiProvider.map({"markets": [
        {"ticker": "T1", "title": "Will X", "yes_ask_dollars": "0.45",
         "no_ask_dollars": "0.57"}]})
    assert {q["outcome"] for q in got} == {"yes", "no"}
    yes = next(q for q in got if q["outcome"] == "yes")
    assert yes["decimal"] == pytest.approx(1 / 0.45, rel=1e-3)
    assert yes["cents"] == pytest.approx(45.0)


def test_the_short_field_names_are_not_used():
    """`yes_ask` still exists in the payload and is always None. Reading it
    mapped every market to zero quotes, which is indistinguishable from a
    venue having no markets open."""
    got = KalshiProvider.map({"markets": [
        {"ticker": "T1", "yes_ask": 45, "no_ask": 57}]})
    assert got == [], "the short names must not be trusted"


def test_a_longshot_is_not_a_price():
    """0.1c contracts invert to decimal 1000 and top any board sorted by
    price while being untradable in size."""
    got = KalshiProvider.map({"markets": [
        {"ticker": "T", "yes_ask_dollars": "0.001", "no_ask_dollars": "0.999"}]})
    assert got == []


def test_polymarket_parses_its_stringified_arrays():
    """gamma returns outcomes and prices as JSON *strings*, not arrays."""
    got = PolymarketProvider.map([{
        "slug": "s", "question": "Q?",
        "outcomes": '["Yes", "No"]', "outcomePrices": '["0.48", "0.52"]'}])
    assert [q["outcome"] for q in got] == ["yes", "no"]
    assert got[0]["decimal"] == pytest.approx(1 / 0.48, rel=1e-3)


def test_a_mismatched_payload_yields_nothing_rather_than_guessing():
    assert PolymarketProvider.map([{"slug": "s", "outcomes": '["Yes","No"]',
                                    "outcomePrices": '["0.5"]'}]) == []
    assert PolymarketProvider.map([{"slug": "s"}]) == []


def test_quotes_are_never_marked_as_dated_by_the_venue():
    """Neither list endpoint carries a per-quote timestamp, so seen_at is our
    receipt time. Claiming otherwise would make every quote look fresh and
    drive the fill model's headline number optimistic."""
    got = KalshiProvider.map({"markets": [
        {"ticker": "T", "yes_ask_dollars": "0.45"}]})
    assert got[0]["dated_by_venue"] is False


def test_nothing_fetches_unless_asked():
    """Constructing a provider must not open a socket. The board only touches
    a network when --live is passed."""
    called = []
    KalshiProvider(fetcher=lambda *a, **k: called.append(1) or {"markets": []})
    PolymarketProvider(fetcher=lambda *a, **k: called.append(1) or [])
    assert called == []


# --- the three-way trap ------------------------------------------------------

from overlay_engine.pubfeed import complete_books, find_public_arbs  # noqa: E402


def _poly(slug, title, outcomes, prices):
    return PolymarketProvider.map([{
        "slug": slug, "question": title,
        "outcomes": str(outcomes).replace("'", '"'),
        "outcomePrices": str(prices).replace("'", '"')}])


def test_two_legs_of_a_three_way_market_are_never_an_arb():
    """The most expensive bug this module can have.

    Football markets are home/draw/away. Backing home at 0.49 and away at
    0.49 sums to 0.98 and looks like a 2% arbitrage — and the draw loses BOTH
    legs. The first live run reported ten of these as playable. Anyone acting
    on one loses the entire stake, so this is the test that matters most here.
    """
    quotes = _poly("m", "Team A vs Team B",
                   ["Home", "Draw", "Away"], ["0.49", "0.10", "0.49"])
    # Drop the draw, exactly as a partial quote set would.
    partial = [q for q in quotes if q["outcome"] != "draw"]
    assert len(partial) == 2
    assert complete_books(partial) == {}, (
        "two of three outcomes is not a book, and pricing it as one tells a "
        "user a losing bet is guaranteed")
    assert find_public_arbs(partial) == []


def test_the_complete_three_way_book_is_priced_when_it_is_complete():
    quotes = _poly("m", "Team A vs Team B",
                   ["Home", "Draw", "Away"], ["0.30", "0.30", "0.30"])
    books = complete_books(quotes)
    assert len(books) == 1
    found = find_public_arbs(quotes)
    assert found, "0.30 + 0.30 + 0.30 = 0.90 is a real arbitrage"
    assert found[0]["outcomes"] == 3
    assert found[0]["cost"] == pytest.approx(0.90, rel=1e-3)


def test_an_efficient_market_is_not_listed():
    """Sides summing to 1.0000 is the market working, not an opportunity."""
    quotes = _poly("m", "A vs B", ["Yes", "No"], ["0.50", "0.50"])
    assert find_public_arbs(quotes) == []
