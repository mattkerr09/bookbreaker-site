#!/usr/bin/env python3
"""Serve the window with a LIVE bridge to the real sidecar.

`preview_ui.sh` stubs the bridge with one canned response per panel, captured
once with fixed arguments. That is enough to look at a panel and it is not
enough to *use* one: every input produces the same output, so `fill --age 4`
and `fill --age 100` render identically. Recording a demo through it produced
a frame showing 100 in the box over a number computed from 10s.

This runs the sidecar per call instead, so the window behaves as it does when
installed. Development only: it is not part of the app, the app talks to its
own Tauri bridge, and nothing here is bundled. The app still makes no network
calls — this server is a local process spawning a local binary.

    python3 scripts/preview_live.py            # serves on :8902
"""
from __future__ import annotations

import http.server
import json
import os
import pathlib
import shutil
import subprocess
import sys
import urllib.parse

ROOT = pathlib.Path(__file__).resolve().parent.parent
PORT = int(os.environ.get("PORT", "8902"))
WORK = pathlib.Path(os.environ.get("TMPDIR", "/tmp")) / "bookbreaker-ui-live"


def find_sidecar() -> list[str]:
    """The bundled sidecar by default; the source engine on request.

    Bundled is the right default because the point of this preview is that
    what renders here renders in the window. But the bundle is only rebuilt
    at release time, so a command added since the last build is missing from
    it — `board` returned an argparse usage error through the bridge, which
    looks like a broken UI and is actually a stale binary.

    OVERLAY_PREVIEW_ENGINE=source runs backend/cli.py instead, which is what
    you want while building a panel for a command that has not shipped yet.
    """
    if os.environ.get("OVERLAY_PREVIEW_ENGINE") == "source":
        return [sys.executable, str(ROOT / "backend" / "cli.py")]
    bundle = ROOT / "ui/src-tauri/target/release/bundle/macos/Bookbreaker.app"
    found = list(bundle.rglob("overlay-engine"))
    if not found:
        raise SystemExit("no bundled sidecar — run ./scripts/build_app.sh first")
    return [str(found[0])]


SIDECAR = find_sidecar()

# The bridge, live. Same shape as the Tauri one the window expects, so app.js
# is served byte-identical to what ships.
STUB = """window.__TAURI__ = { core: { invoke: async (cmd, a) => {
  const r = await fetch('/engine?' + new URLSearchParams(
      a.args.map(v => ['a', v])));
  if (!r.ok) throw new Error(await r.text());
  return r.json();
} } };
"""


def stage() -> None:
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)
    for name in ("index.html", "app.js", "app.css"):
        shutil.copy(ROOT / "ui/src" / name, WORK / name)
    (WORK / "stub.js").write_text(STUB)
    page = WORK / "index.html"
    html = page.read_text().replace(
        '<script src="app.js"></script>',
        '<script src="stub.js"></script>\n<script src="app.js"></script>', 1)
    if "stub.js" not in html:
        raise SystemExit("could not inject the bridge — the script tag moved")
    page.write_text(html)


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(WORK), **kw)

    def log_message(self, *a):  # quiet
        pass

    def do_GET(self):
        if not self.path.startswith("/engine?"):
            return super().do_GET()
        args = urllib.parse.parse_qs(
            urllib.parse.urlparse(self.path).query).get("a", [])
        run = subprocess.run([*SIDECAR, *args, "--json"],
                             capture_output=True, text=True, timeout=60)
        if run.returncode != 0:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(run.stderr[:400].encode())
            return
        body = json.dumps(json.loads(run.stdout)).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    stage()
    print(f"engine: {' '.join(SIDECAR)}")
    print(f"open http://localhost:{PORT}/   (live engine, ctrl-c to stop)")
    http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
