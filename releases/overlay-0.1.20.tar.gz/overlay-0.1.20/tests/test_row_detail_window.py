"""The row detail, the outcomes panel and the numbered bet order in the window.

Static, like the other window tests. What these pin is what a screenshot cannot show:

  * selecting a row asks the engine for nothing: the detail came with the board;
  * the window computes nothing here. The fair price, each book's EV, the best
    and average price, what each result pays, the length of each bar and the
    number on each bet are the engine's. The one thing the window does to an
    engine number is write its sign;
  * the bets are numbered by the engine's order, not by where they happen to sit;
  * every field the page reads is one the engine really sends;
  * nothing the page says promises more than it is: an arb's profit is locked
    only if both bets are accepted at the prices shown and both stand.
"""

import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


DETAIL_JS = JS[JS.index("/* What each result pays, and the order to place the bets in."):
               JS.index('document.addEventListener("click", (ev) => {\n  const c = ev.target.closest && ev.target.closest("[data-pick]");')]
CONSOLE = _braced(JS, "function consoleHTML(")
PICK = JS[JS.index('document.addEventListener("click", (ev) => {\n  const c = ev.target.closest && ev.target.closest("[data-pick]");'):
          JS.index("/* ------------------------------------------------------------ tools */")]


# ------------------------------------------------------------ selecting a row

def test_selecting_a_row_swaps_the_console_and_the_detail_and_asks_the_engine_for_nothing():
    assert 'box.querySelector(".consolebox .console").outerHTML = consoleHTML(PLAYS[i]);' in PICK
    assert 'box.querySelector(".consolebox .detail").outerHTML = detailHTML(PLAYS[i]);' in PICK
    for call in ("run(", "invoke(", "fetch(", "await", "async"):
        assert call not in PICK, call


def test_the_board_draws_the_detail_of_the_row_it_opens_on():
    assert "${consoleHTML(chosen)}${detailHTML(chosen)}" in _braced(JS, "function drawBoard(")


def test_a_row_with_no_detail_draws_an_empty_container_not_an_error():
    detail = _braced(DETAIL_JS, "function detailHTML(")
    assert 'const d = p && p.detail;' in detail and ': ""' in detail
    assert 'class="detail"' in detail
    assert re.search(r"\.detail:empty\{display:none\}", CSS)


def test_both_the_sportsbook_board_and_the_live_pairs_hand_the_console_the_engines_order_and_results():
    play = _braced(JS, "function boardPlay(")
    live = _braced(JS, "function livePlay(")
    for body in (play, live):
        assert "order: l.order" in body
        assert "outcomes: r.outcomes, orderRule: r.order_rule" in body
    assert "detail: r.detail" in play
    assert "detail" not in live, "a live pair has no fair price to show"


# ------------------------------------------------------------ the bet order

def test_the_legs_are_numbered_by_the_engines_order_and_not_by_where_they_sit():
    assert '<span class="num" title="Place this bet number ${l.order}">${l.order}</span>' in CONSOLE
    assert "${i + 1}" not in CONSOLE
    side = CONSOLE[CONSOLE.index("const side = (l, i)"):CONSOLE.index("const dial")]
    assert "i + 1" not in side


def test_the_sentence_that_numbered_the_bets_is_the_engines_and_is_shown_for_a_pair_only():
    order = _braced(DETAIL_JS, "function orderHTML(")
    assert "esc(p.orderRule)" in order and "p.legs.length < 2" in order
    assert "Bet order" in order
    assert "${outcomesHTML(p)}${orderHTML(p)}" in CONSOLE


def test_the_steps_say_the_bets_go_in_the_order_of_their_numbers():
    steps = JS[JS.index("const steps = BOARD.feed"):JS.index("box.innerHTML = `${BOARD.feed ? oddsLine()")]
    assert steps.count("in the order of their numbers") == 3
    assert "Numbered 1 and 2" not in JS


# ------------------------------------------------------------ the outcomes panel

def test_the_outcomes_panel_draws_the_engines_figures_labels_and_bar_lengths():
    out = _braced(DETAIL_JS, "function outcomesHTML(")
    for field in ("o.net", "o.label", "o.scale"):
        assert field in out, field
    assert "usd(o.net, true)" in out and 'o.net < 0 ? "neg" : "pos"' in out
    assert 'style="--w:${o.scale}"' in out
    assert "What each result pays" in out
    assert "if (!p.outcomes || !p.outcomes.length) return" in out, "a single +EV bet has no pair of results"


# ------------------------------------------------------------ the window computes nothing

def test_the_only_thing_done_to_an_engine_number_is_writing_its_sign():
    for banned in (".toFixed(", ".reduce(", "parseFloat", "Number(", "Math.max", "Math.min", "Math.round", "Math.floor"):
        assert banned not in DETAIL_JS, banned
    assert DETAIL_JS.count("Math.") == 1 and "const spct = (x) => `${x < 0 ? \"&minus;\" : \"+\"}${pct(Math.abs(x), 1)}`;" in DETAIL_JS
    leaves = re.findall(r"\$\{([^`{}]*)\}", DETAIL_JS)
    assert len(leaves) >= 30, "the extractor has drifted"
    for expr in leaves:
        bare = re.sub(r"\"[^\"]*\"|'[^']*'", "''", expr)
        assert not re.search(r"[\w)\]]\s*[*/%]\s*[\w(]|[\w)\]]\s+[+-]\s+[\w(]", bare), f"arithmetic on an engine figure: {expr}"


def test_the_best_and_average_prices_and_which_cells_are_best_are_the_engines():
    prices = _braced(DETAIL_JS, "function pricesHTML(")
    assert "t.best" in prices and "t.average" in prices and "c.best" in prices
    assert "t.average_basis" in prices
    for compare in ("sort(", "max(", "min(", ".filter("):
        assert compare not in prices, compare


def test_the_engines_words_are_drawn_as_text_not_markup():
    raw = re.findall(r"\$\{((?:f|s|b|x|blk|t|r|c|a|d|o)\.(?:label|name|why|text|average_basis|age_text))\}", DETAIL_JS)
    assert raw == [], f"engine text interpolated without esc(): {raw}"
    for sink in ("document.write", "outerHTML =", "insertAdjacentHTML"):
        assert sink not in DETAIL_JS


def test_a_reference_book_is_labelled_and_muted_in_the_price_table():
    prices = _braced(DETAIL_JS, "function pricesHTML(")
    assert "<em>reference</em>" in prices and "r.bettable" in prices
    assert "is not somewhere you can bet from the US" in prices
    assert re.search(r"\.ptable tr\.ref td\s*\{", CSS) and re.search(r"\.ptable td\.best\s*\{", CSS)


def test_the_ev_panel_says_a_book_never_helps_set_the_price_it_is_judged_by_and_that_an_edge_is_an_average():
    ev = _braced(DETAIL_JS, "function evHTML(")
    text = re.sub(r"\s+", " ", ev)
    assert "worked out without that book&rsquo;s own price" in text
    assert "an average over many bets, not a promise about any one" in text
    assert 'x.mine ? " mine" : ""' in ev and "x.scale" in ev


def test_nothing_on_the_detail_says_guaranteed_or_risk_free_or_either_way():
    for text in (DETAIL_JS, CONSOLE):
        low = text.lower()
        for word in ("guarantee", "risk-free", "risk free", "riskfree", "either way"):
            assert word not in low, word


# ------------------------------------------------------------ styling

def test_every_class_the_detail_and_outcomes_use_has_a_rule():
    used = {"outc", "o-row", "o-l", "o-bar", "c-order", "detail", "dcard", "dwide", "dtable", "ptable", "p-best", "p-avg",
            "e-row", "mine", "e-n", "e-p", "e-bar", "range", "pos", "neg", "ref", "best"}
    for cls in used:
        assert re.search(rf"\.{re.escape(cls)}\b[^{{}}]*\{{", CSS), f".{cls} has no rule in app.css"
        assert re.search(rf'class="[^"]*\b{re.escape(cls)}\b|\' class="{re.escape(cls)}"|" {re.escape(cls)}"|"{re.escape(cls)}"', DETAIL_JS + CONSOLE), (
            f".{cls} is styled and never drawn")


# ------------------------------------------------------------ the window reads only what the engine sends

@pytest.fixture(scope="module")
def sent(tmp_path_factory):
    import contextlib
    import io
    import os
    from types import SimpleNamespace

    import test_oddsapi as to
    import test_parity_grid as tp
    from overlay_engine import cli, keystore, oddsapi

    was = os.environ.get("OVERLAY_HOME")
    saved = (oddsapi.odds_api_fetcher, oddsapi.time, keystore.get_key)
    os.environ["OVERLAY_HOME"] = str(tmp_path_factory.mktemp("home"))
    api = to.FakeApi({"americanfootball_nfl": tp.world()})
    oddsapi.odds_api_fetcher = lambda *a, **k: api
    oddsapi.time = SimpleNamespace(time=to.Clock())
    keystore.get_key = lambda runner=None: to.KEY
    try:
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            assert cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--market", "h2h", "--market", "spreads",
                             "--market", "totals", "--json"]) == 0
        yield json.loads(out.getvalue())
    finally:
        oddsapi.odds_api_fetcher, oddsapi.time, keystore.get_key = saved
        if was is None:
            os.environ.pop("OVERLAY_HOME", None)
        else:
            os.environ["OVERLAY_HOME"] = was


def _keys(items):
    return set().union(*(set(i) for i in items if i)) if items else set()


def test_every_field_the_detail_and_outcomes_read_is_one_the_engine_sends(sent):
    rows = sent["rows"]
    kinds = {r["kind"] for r in rows}
    assert {"arb", "ev", "middle"} <= kinds, f"the fixture must carry all three kinds: {kinds}"
    details = [r["detail"] for r in rows if r["detail"]]
    fair = [d["fair"] for d in details if d["fair"]["available"]]
    sides = [s for f in fair for s in f["sides"]]
    blend = [b for f in fair for b in f["blend"]]
    blocks = [b for d in details for b in d["ev_by_book"]]
    evrows = [x for b in blocks for x in b["rows"]]
    tables = [d["table"] for d in details]
    trows = [r for t in tables for r in t["rows"]]
    cells = [p for r in trows for p in r["prices"] if p]
    best = [b for t in tables for b in t["best"] if b]
    avg = [a for t in tables for a in t["average"] if a]
    outcomes = [o for r in rows for o in r["outcomes"]]
    shapes = {
        "f": _keys([d["fair"] for d in details]) | {"why"},
        "s": _keys(sides), "b": _keys(blend) | _keys(best), "blk": _keys(blocks), "x": _keys(evrows),
        "t": _keys(tables), "r": _keys(trows), "c": _keys(cells), "a": _keys(avg), "o": _keys(outcomes),
        "d": _keys(details), "l": _keys([leg for r in rows for leg in r["legs"]]),
    }
    block = "".join(_braced(DETAIL_JS, f"function {fn}(") for fn in
                    ("outcomesHTML", "fairHTML", "evHTML", "pricesHTML", "detailHTML"))
    for var, keys in shapes.items():
        read = set(re.findall(rf"(?<![\w.]){var}\.([a-z_]+)", block))
        read -= {"length", "join", "map", "filter", "find", "some", "push", "mine"} - ({"mine"} if var == "x" else set())
        assert read <= keys, f"{var}: read but never sent: {sorted(read - keys)}"
    assert {"net", "label", "scale"} <= shapes["o"]
    assert {"available", "sides", "text", "blend"} <= shapes["f"] and {"label", "american", "prob", "low", "high"} <= shapes["s"]
    assert {"book", "name", "american", "ev", "mine", "scale"} <= shapes["x"]
    assert {"sides", "rows", "best", "average", "average_basis"} <= shapes["t"]
    assert {"book", "name", "bettable", "prices"} <= shapes["r"] and {"american", "age_text"} <= shapes["c"]
    row = rows[0]
    assert {"outcomes", "order_rule", "detail"} <= set(row)
    play = _braced(JS, "function boardPlay(")
    assert set(re.findall(r"\br\.([a-z_]+)", play)) <= set(row)
    assert "order" in shapes["l"] and set(re.findall(r"\bl\.([a-z_]+)", play)) <= shapes["l"]
