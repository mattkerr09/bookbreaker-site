"""Alerts: which plays on a read the person just started are new, and meet what they asked to hear about.

OddsJam's alert is a saved filter with a push switch, and the push goes to a phone. Bookbreaker is a Mac
app with no server, so an alert here is a saved setting in the window (a minimum edge for +EV, a minimum
locked return for arbs, which kinds, Recommended only or all) and a sentence the engine writes after a read.
The window shows the sentence as a banner and, if the person turned on "Mac notification", hands the same
text to the shell, which posts it.

**It fires only after a read the person pressed.** Nothing here reads a price, starts a timer or opens a
connection. A read of live sportsbook odds spends the person's Odds API credits, and a notification that
needed a background read would be a notification that quietly spent them. This module is handed the rows
of a read that already happened; the only thing it touches is one small file on this Mac, the plays the
previous read held.

**New means not in the previous read on this Mac.** A play is its kind, its game, its market and the book
and side of each bet: not its price, so a price that drifts a few points does not announce itself again.
The previous read is kept per source (Live prices, Live sportsbook odds), so one source's board never
makes the other's plays look old or new. The first read there is nothing to compare with, so it records
the board and says so; it does not announce everything on it as new.

**A read that did not see everything does not forget.** When part of a read failed (a league that could not
be read), the plays that were missing are not "gone": they are kept in the record, so when they come back
they are not announced as new.

**The sentence is the engine's.** The window prints it and the shell posts it; neither words an alert of its
own, and an arb is "locked if both bets are accepted and stand", never anything stronger.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

from .ledger import home

KINDS = ("arb", "ev", "middle")

#: The sources a read can come from, each with its own memory of the previous read.
SOURCES = ("live", "oddsapi")

#: Limits on what the window may ask for. Wide enough never to get in the way, narrow enough that a value
#: from a typo cannot silence every alert (an edge of 5,000%) or flood them (a negative one).
MAX_EV_PERCENT = 100.0
MAX_ARB_DOLLARS = 1_000_000.0

NOTE = "Check each price at the book before you bet. A price can move or a bet be refused."
WHEN = "Alerts fire only after a refresh you start. Nothing is read in the background."


class AlertError(ValueError):
    """The alert setting is not one the engine can use. The text is a sentence the window can print."""


def parse(text: str) -> dict:
    """The setting the window sent, checked. One JSON object:

    `min_ev` (percent), `min_arb` (dollars locked at the total to bet), `kinds` (any of arb, ev, middle),
    `recommended_only` (bool). Anything else, or a value out of range, is refused in a sentence: a quietly
    repaired setting would alert on something the person did not ask for.
    """
    try:
        raw = json.loads(text)
    except (TypeError, ValueError):
        raise AlertError("The alert setting was not readable. Open the Alerts setting and save it again.") from None
    if not isinstance(raw, dict):
        raise AlertError("The alert setting was not readable. Open the Alerts setting and save it again.")
    unknown = sorted(set(raw) - {"min_ev", "min_arb", "kinds", "recommended_only"})
    if unknown:
        raise AlertError(f"The alert setting has something Bookbreaker does not know: {', '.join(unknown)}.")

    def number(name: str, label: str, top: float) -> float:
        value = raw.get(name, 0.0)
        if isinstance(value, str):
            # A field of the window travels as typed, like every other number it sends: "3", "3%", "$5".
            # An empty one means no minimum.
            typed = value.strip().replace("$", "").replace("%", "").replace(",", "").strip()
            try:
                value = float(typed) if typed else 0.0
            except ValueError:
                raise AlertError(f"{label} must be a number.") from None
        if isinstance(value, bool) or not isinstance(value, (int, float)) or value != value:
            raise AlertError(f"{label} must be a number.")
        if not 0.0 <= value <= top:
            raise AlertError(f"{label} must be between 0 and {top:,.0f}.")
        return float(value)

    kinds = raw.get("kinds", list(KINDS))
    if (not isinstance(kinds, list) or not kinds or any(k not in KINDS for k in kinds)):
        raise AlertError("Pick at least one kind of play to be alerted about: +EV, arbs or middles.")
    scope = raw.get("recommended_only", True)
    if not isinstance(scope, bool):
        raise AlertError("Recommended plays only must be on or off.")
    return {"min_ev": number("min_ev", "The smallest +EV edge", MAX_EV_PERCENT),
            "min_arb": number("min_arb", "The smallest locked return", MAX_ARB_DOLLARS),
            "kinds": [k for k in KINDS if k in kinds], "recommended_only": scope}


# ---------------------------------------------------------------------------------------------------- identity

def play_key(row: dict) -> str:
    """What makes a play the same play on the next read: its kind, its game, its market and the book and side of
    each bet. Not its price, its stake or its age, which move on every read."""
    if row.get("cross"):
        game = row.get("game", "")
        legs = [f"{leg.get('venue', '')}:{leg.get('name', '')}" for leg in row.get("legs", [])]
        return "|".join(["arb", "cross", str(row.get("league", "")), game, *sorted(legs)])
    legs = [f"{leg.get('book', '')}:{leg.get('outcome', '')}" for leg in row.get("legs", [])]
    game = row.get("event_id") or row.get("event", "")
    return "|".join([str(row.get("kind", "")), str(game), str(row.get("market", "")), *sorted(legs)])


# ---------------------------------------------------------------------------------------------------- the rule

def meets(row: dict, setting: dict) -> bool:
    """Whether one play is what the person asked to hear about (new or not; the caller decides that)."""
    kind = row.get("kind")
    if kind not in setting["kinds"]:
        return False
    if setting["recommended_only"] and row.get("recommended") is False:
        return False
    if kind == "ev":
        return round(float(row.get("margin", 0.0)) * 100.0, 4) >= setting["min_ev"]
    if kind == "arb":
        return round(float(row.get("profit", 0.0)), 2) >= setting["min_arb"]
    return True          # a middle has no minimum: its chance is not a threshold anyone asked for


# ---------------------------------------------------------------------------------------------------- the words

def _signed(american) -> str:
    return f"+{american}" if american > 0 else f"{american}"


def _book(leg: dict) -> str:
    if leg.get("venue"):
        from .catalog import VENUES
        venue = VENUES.get(leg["venue"])
        return venue.name if venue else str(leg["venue"])
    return str(leg.get("book_name") or leg.get("book") or "")


def _view(row: dict) -> dict:
    """A Live prices pair has no `kind`: it is a pair of venues and always an arb. Everything else here reads
    the one shape, so a pair is given its kind on a copy and the original is left as the engine made it."""
    if "kind" not in row and row.get("legs") and "venue" in row["legs"][0]:
        return {**row, "kind": "arb", "cross": True}
    return row


def describe(row: dict) -> str:
    """One play, in a short phrase, in the words of the board it came from."""
    game = row.get("event") or row.get("game") or ""
    legs = row.get("legs", [])
    if row.get("kind") == "arb":
        who = " and ".join(_book(leg) for leg in legs)
        text = f"{game}, ${float(row.get('profit', 0.0)):,.2f} locked at {who} if both bets are accepted and stand"
    elif row.get("kind") == "ev" and legs:
        price = legs[0].get("american")
        at = f"{_signed(price)} " if isinstance(price, int) else ""
        text = f"{game}, {at}at {_book(legs[0])} for a +{float(row.get('margin', 0.0)) * 100:.1f}% edge"
    else:
        text = f"{game}, a middle at " + " and ".join(_book(leg) for leg in legs)
    return text + ("" if row.get("recommended") is not False else " (not Recommended)")


def message(matched: list) -> str:
    """The one line the window shows and the shell posts. Best first, as the board ranked them."""
    if not matched:
        return ""
    if len(matched) == 1:
        return f"New play meets your alert: {describe(matched[0])}."
    return f"{len(matched)} new plays meet your alert. First: {describe(matched[0])}."


# ---------------------------------------------------------------------------------------------------- the memory

def _file(source: str) -> Path:
    return home() / "alerts" / f"seen-{source}.json"


def recall(source: str) -> set | None:
    """The plays the previous read on this Mac held, or None when there was no previous read (or the record is
    not one this version can read: then nothing is announced rather than everything)."""
    try:
        data = json.loads(_file(source).read_text())
        keys = data["plays"]
        if not isinstance(keys, list) or not all(isinstance(k, str) for k in keys):
            return None
        return set(keys)
    except (OSError, ValueError, KeyError, TypeError):
        return None


def remember(source: str, keys: set, now: float) -> None:
    """Write the board of this read as the one the next read is compared with. Atomic, so a crash mid-write
    leaves the old record and not half of a new one; a record that cannot be written costs the next alert, not
    the read."""
    path = _file(source)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".seen-", suffix=".tmp")
        with os.fdopen(fd, "w") as f:
            json.dump({"read_at": now, "plays": sorted(keys)}, f)
        os.replace(tmp, path)
    except OSError:
        pass


# ---------------------------------------------------------------------------------------------------- the check

def skipped(setting: dict, why: str) -> dict:
    """The block for a read that gave nothing to compare (nothing was read, or no state was chosen). The record
    of the previous read is left exactly as it was."""
    return {"enabled": True, "first_read": False, "new": 0, "matched": 0, "message": "",
            "status": f"Alerts were not checked: {why}", "note": NOTE, "when": WHEN, "setting": setting}


def refused(why: str) -> dict:
    """The block for a setting the engine could not use. The read still happened, because the person pressed it
    and it cost what it cost: a typo in an alert never takes the board away. Nothing is compared or recorded."""
    return {"enabled": False, "first_read": False, "new": 0, "matched": 0, "message": "",
            "status": f"{why} Alerts were not checked on this refresh.", "note": NOTE, "when": WHEN, "setting": None}


def check(rows: list, setting: dict, source: str, now: float, *, complete: bool = True) -> dict:
    """Mark the rows that are new and meet the setting, record this read, and say what happened.

    `rows` are the board's rows as the window receives them (dicts), best first; a row that matches gets
    `alert: True`. `complete` is False when part of the read failed, so what the previous read held is kept.
    The result is the `alerts` block the window reads: `message` (empty when nothing matched), `status` (a
    sentence for every case), `matched`, `new`, `first_read`, `note`, `when`.
    """
    if source not in SOURCES:
        raise AlertError("Alerts work on Live prices and Live sportsbook odds.")
    before = recall(source)
    pairs = [(r, _view(r)) for r in rows]
    keys = {play_key(v) for _, v in pairs}
    new = [] if before is None else [(r, v) for r, v in pairs if play_key(v) not in before]
    matched = [v for _, v in new if meets(v, setting)]
    for r, v in new:
        if meets(v, setting):
            r["alert"] = True
    remember(source, keys if (complete or before is None) else keys | before, now)
    if before is None:
        status = ("This is the first refresh Bookbreaker has to compare with, so nothing counts as new yet. "
                  "From the next one it tells you what is new.")
    elif matched:
        status = message(matched)
    else:
        status = (f"No new play meets your alert. {len(new)} play{'s' if len(new) != 1 else ''} "
                  f"{'is' if len(new) == 1 else 'are'} new since the last refresh, none of them what you asked for."
                  if new else "No new play since the last refresh.")
    return {"enabled": True, "first_read": before is None, "new": len(new), "matched": len(matched),
            "message": message(matched), "status": status, "note": NOTE, "when": WHEN,
            "setting": setting}
