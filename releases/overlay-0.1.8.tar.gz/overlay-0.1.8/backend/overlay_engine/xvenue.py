"""Live arbitrage between Kalshi and Polymarket on the same game.

The one live, free, keyless arbitrage this product can offer. Both venues
publish order books without an account, both list NFL, MLB, NBA and NHL games
as two-sided markets, and their prices disagree now and then. What makes it
worth building carefully is that every way it can go wrong is a way of showing
a row that loses money:

**Matching is by team code and date, never by title.** Kalshi's event ticker
ends in the two teams' codes (KXNFLGAME-26OCT08TBDAL) and each market's ticker
ends in the one team it pays on; Polymarket's slug carries the same codes
(nfl-tb-dal-2026-10-09). Each code is checked against a fixed team table, each
outcome name against the team the slug names *in the same position*, and a
game that does not match on both is refused rather than guessed. The venues
date a game differently: Kalshi in Eastern time everywhere; Polymarket in UTC
for the NFL and Eastern for the rest. So an NFL game may differ by a day and
no other league's may (baseball plays the same two teams on consecutive days:
a day of slack once paired today's game with tomorrow's). A game that two
listings could both be is priced as neither.

**Prices are asks, not quotes.** Polymarket's outcomePrices is a midpoint and
cannot be bought. The first outcome's ask is bestAsk; the second's is
1 - bestBid, because on a two-outcome book buying one side is selling the
other. Those listed asks only decide which games are worth a look at the
order book; the book sets the price.

**Every price is sized to what is resting at it.** Kalshi reports the number of
contracts at its best ask. Polymarket's market list gives a quote and no size,
and its quote can be several cents off the book (a game under way moves faster
than the list does), so the order book behind every leg that could be an
arbitrage is read, and the leg is priced at the book's best ask and limited to
the shares resting at it. A leg whose book is not known is not priced: an
arbitrage not shown to be fillable is not one. The pair is sized to the
smallest of the two books and the money you said you would bet, fees included,
and says which of the three set the size.

**Fees are the venues' own published formulas, read from the venues.**
Kalshi: rate x C x p x (1 - p) rounded up to the cent, rate 0.07 times the
series' fee multiplier (read from the series: MLB is half). Polymarket: rate x
C x (p x (1 - p))^exponent, takers only, rate and exponent read from each
market's feeSchedule (the NFL's is 0.03, the other leagues' 0.05). Where a
schedule cannot be read the dearer, recorded rate is charged. A margin that
disappears after fees is not shown as an arb.

**Resolution rules were read, and they agree except in one place.** Both
venues settle on the official winner, overtime included. An NFL tie pays 50c
per side on both, so the arb survives it. A postponement does not: Kalshi
settles at a fair price if the game has not been played within 48 hours (two
days in baseball), Polymarket waits for the game. Every pairing says so.

**Nothing here is shown unless it pays.** A pairing is listed only when it
leaves a profit after both fees at the size on offer. Near misses are priced
and never listed: a list of things that do not pay, however labelled, is
padding. When nothing pays, the answer is that nothing does.

The fetch is a seam, as in `pubfeed`: `fetch` is a callable from a URL to
parsed JSON, so everything that can be wrong is tested against recorded
payloads. Nothing in this module opens a socket.
"""

from __future__ import annotations

import datetime as dt
import json
import math
import re
import time
from dataclasses import dataclass, field
from urllib.parse import quote

LEAGUES = ("nfl", "mlb", "nba", "nhl")
KALSHI_SERIES = {"nfl": "KXNFLGAME", "mlb": "KXMLBGAME", "nba": "KXNBAGAME", "nhl": "KXNHLGAME"}

KALSHI_EVENTS = ("https://api.elections.kalshi.com/trade-api/v2/events"
                 "?series_ticker={series}&status=open&with_nested_markets=true&limit=200")
KALSHI_SERIES_URL = "https://api.elections.kalshi.com/trade-api/v2/series/{series}"
POLY_SPORTS = "https://gamma-api.polymarket.com/sports"
#: The game moneylines of one league, soonest first. Not the events list: a
#: Polymarket NFL event carries three hundred prop markets, and the series'
#: events came to 51 MB. The market list, filtered to moneylines by tag and
#: date, is a few hundred KB for the whole league.
POLY_GAMES = ("https://gamma-api.polymarket.com/markets?closed=false&limit=100&sports_market_types=moneyline"
              "&tag_id={tag}&order=endDate&ascending=true&end_date_min={lo}&end_date_max={hi}&offset={offset}")
POLY_BOOK = "https://clob.polymarket.com/book?token_id={token}"

#: Read 2026-10-08. Kalshi: kalshi.com/fee-schedule (taker 0.07 x C x p(1-p)) and
#: each game series' object (fee_type quadratic_with_maker_fees; fee_multiplier
#: 1, MLB 0.5). Polymarket: docs.polymarket.com/polymarket-learn/trading/fees and
#: each game market's feeSchedule (rate 0.03 NFL, 0.05 MLB/NBA/NHL; takers only).
KALSHI_TAKER_RATE = 0.07
KALSHI_QUADRATIC = ("quadratic", "quadratic_with_maker_fees")
#: What each series charged when read; used only if the series cannot be read.
KALSHI_FEE_MULTIPLIER = {"nfl": 1.0, "mlb": 0.5, "nba": 1.0, "nhl": 1.0}
#: Charged when a market's own schedule cannot be read: the highest rate seen.
POLY_SPORTS_TAKER_RATE = 0.05
#: Polymarket will not take an order under this many shares (orderMinSize).
POLY_MIN_ORDER = 5.0
FEES_READ = "2026-10-08"
FEE_SOURCES = ("https://kalshi.com/fee-schedule",
               "https://docs.polymarket.com/polymarket-learn/trading/fees")

RESIDUAL_RISK_NFL = ("Both venues settle on the official winner, overtime included. A tie pays 50c per side on both, "
                     "so the arb survives one. They differ on a postponement: Kalshi settles at a fair price if the "
                     "game has not started within 48 hours, Polymarket waits for the game. That is the risk left.")
RESIDUAL_RISK = ("Both venues settle on the official winner, overtime included. They differ on a postponement: "
                 "Kalshi settles at a fair price if the game has not been played within 48 hours (two days in "
                 "baseball), Polymarket waits for the game. That is the risk left.")

#: Kalshi's code -> (city, nickname), so a Polymarket outcome can be checked
#: against the team its slug names. From ESPN's public team lists (2026-10-06).
LEAGUE_TEAMS = {
    "nfl": {
        "ARI": ("Arizona", "Cardinals"), "ATL": ("Atlanta", "Falcons"), "BAL": ("Baltimore", "Ravens"),
        "BUF": ("Buffalo", "Bills"), "CAR": ("Carolina", "Panthers"), "CHI": ("Chicago", "Bears"),
        "CIN": ("Cincinnati", "Bengals"), "CLE": ("Cleveland", "Browns"), "DAL": ("Dallas", "Cowboys"),
        "DEN": ("Denver", "Broncos"), "DET": ("Detroit", "Lions"), "GB": ("Green Bay", "Packers"),
        "HOU": ("Houston", "Texans"), "IND": ("Indianapolis", "Colts"), "JAX": ("Jacksonville", "Jaguars"),
        "KC": ("Kansas City", "Chiefs"), "LAC": ("Los Angeles", "Chargers"), "LAR": ("Los Angeles", "Rams"),
        "LV": ("Las Vegas", "Raiders"), "MIA": ("Miami", "Dolphins"), "MIN": ("Minnesota", "Vikings"),
        "NE": ("New England", "Patriots"), "NO": ("New Orleans", "Saints"), "NYG": ("New York", "Giants"),
        "NYJ": ("New York", "Jets"), "PHI": ("Philadelphia", "Eagles"), "PIT": ("Pittsburgh", "Steelers"),
        "SEA": ("Seattle", "Seahawks"), "SF": ("San Francisco", "49ers"), "TB": ("Tampa Bay", "Buccaneers"),
        "TEN": ("Tennessee", "Titans"), "WAS": ("Washington", "Commanders"),
    },
    "mlb": {
        "ATH": ("Athletics", "Athletics"), "ATL": ("Atlanta", "Braves"), "AZ": ("Arizona", "Diamondbacks"),
        "BAL": ("Baltimore", "Orioles"), "BOS": ("Boston", "Red Sox"), "CHC": ("Chicago", "Cubs"),
        "CIN": ("Cincinnati", "Reds"), "CLE": ("Cleveland", "Guardians"), "COL": ("Colorado", "Rockies"),
        "CWS": ("Chicago", "White Sox"), "DET": ("Detroit", "Tigers"), "HOU": ("Houston", "Astros"),
        "KC": ("Kansas City", "Royals"), "LAA": ("Los Angeles", "Angels"), "LAD": ("Los Angeles", "Dodgers"),
        "MIA": ("Miami", "Marlins"), "MIL": ("Milwaukee", "Brewers"), "MIN": ("Minnesota", "Twins"),
        "NYM": ("New York", "Mets"), "NYY": ("New York", "Yankees"), "PHI": ("Philadelphia", "Phillies"),
        "PIT": ("Pittsburgh", "Pirates"), "SD": ("San Diego", "Padres"), "SEA": ("Seattle", "Mariners"),
        "SF": ("San Francisco", "Giants"), "STL": ("St. Louis", "Cardinals"), "TB": ("Tampa Bay", "Rays"),
        "TEX": ("Texas", "Rangers"), "TOR": ("Toronto", "Blue Jays"), "WSH": ("Washington", "Nationals"),
    },
    "nba": {
        "ATL": ("Atlanta", "Hawks"), "BKN": ("Brooklyn", "Nets"), "BOS": ("Boston", "Celtics"),
        "CHA": ("Charlotte", "Hornets"), "CHI": ("Chicago", "Bulls"), "CLE": ("Cleveland", "Cavaliers"),
        "DAL": ("Dallas", "Mavericks"), "DEN": ("Denver", "Nuggets"), "DET": ("Detroit", "Pistons"),
        "GSW": ("Golden State", "Warriors"), "HOU": ("Houston", "Rockets"), "IND": ("Indiana", "Pacers"),
        "LAC": ("LA", "Clippers"), "LAL": ("Los Angeles", "Lakers"), "MEM": ("Memphis", "Grizzlies"),
        "MIA": ("Miami", "Heat"), "MIL": ("Milwaukee", "Bucks"), "MIN": ("Minnesota", "Timberwolves"),
        "NOP": ("New Orleans", "Pelicans"), "NYK": ("New York", "Knicks"), "OKC": ("Oklahoma City", "Thunder"),
        "ORL": ("Orlando", "Magic"), "PHI": ("Philadelphia", "76ers"), "PHX": ("Phoenix", "Suns"),
        "POR": ("Portland", "Trail Blazers"), "SAC": ("Sacramento", "Kings"), "SAS": ("San Antonio", "Spurs"),
        "TOR": ("Toronto", "Raptors"), "UTA": ("Utah", "Jazz"), "WAS": ("Washington", "Wizards"),
    },
    "nhl": {
        "ANA": ("Anaheim", "Ducks"), "BOS": ("Boston", "Bruins"), "BUF": ("Buffalo", "Sabres"),
        "CAR": ("Carolina", "Hurricanes"), "CBJ": ("Columbus", "Blue Jackets"), "CGY": ("Calgary", "Flames"),
        "CHI": ("Chicago", "Blackhawks"), "COL": ("Colorado", "Avalanche"), "DAL": ("Dallas", "Stars"),
        "DET": ("Detroit", "Red Wings"), "EDM": ("Edmonton", "Oilers"), "FLA": ("Florida", "Panthers"),
        "LA": ("Los Angeles", "Kings"), "MIN": ("Minnesota", "Wild"), "MTL": ("Montreal", "Canadiens"),
        "NJ": ("New Jersey", "Devils"), "NSH": ("Nashville", "Predators"), "NYI": ("New York", "Islanders"),
        "NYR": ("New York", "Rangers"), "OTT": ("Ottawa", "Senators"), "PHI": ("Philadelphia", "Flyers"),
        "PIT": ("Pittsburgh", "Penguins"), "SEA": ("Seattle", "Kraken"), "SJ": ("San Jose", "Sharks"),
        "STL": ("St. Louis", "Blues"), "TB": ("Tampa Bay", "Lightning"), "TOR": ("Toronto", "Maple Leafs"),
        "UTA": ("Utah", "Mammoth"), "VAN": ("Vancouver", "Canucks"), "VGK": ("Vegas", "Golden Knights"),
        "WPG": ("Winnipeg", "Jets"), "WSH": ("Washington", "Capitals"),
    },
}

#: Where a venue spells a team differently from the table above (checked
#: against both venues' full team lists, 2026-10-08). Kalshi spells Jacksonville
#: JAC; Polymarket spells the Rams LA and some NHL teams its own way, and not
#: always the same way twice (Vegas is both LAS and VEG).
_NFL_ALIASES = {"JAC": "JAX", "LA": "LAR", "WSH": "WAS", "LVR": "LV", "OAK": "LV"}
KALSHI_TO_TABLE = {"nfl": _NFL_ALIASES, "mlb": {}, "nba": {}, "nhl": {}}
POLY_TO_TABLE = {
    "nfl": _NFL_ALIASES,
    "mlb": {"ARI": "AZ", "OAK": "ATH"},
    "nba": {"PHO": "PHX"},
    "nhl": {"CAL": "CGY", "LAK": "LA", "LAS": "VGK", "VEG": "VGK", "MON": "MTL", "NAS": "NSH", "UTAH": "UTA",
            "WAS": "WSH"},
}

#: How many days apart Kalshi's and Polymarket's dates for one game may be. The
#: NFL keeps a day for Polymarket's UTC slugs (two NFL teams never meet on
#: consecutive days); every other league plays series on consecutive days.
DATE_SLACK = {"nfl": 1}

_MONTHS = {m: i for i, m in enumerate(
    ("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"), start=1)}


def team_key(league: str, code: str, spellings: dict) -> str | None:
    """A venue's code for a team, as the table's key, or None if it is not a team in the league."""
    c = code.strip().upper()
    c = spellings.get(league, {}).get(c, c)
    return c if c in LEAGUE_TEAMS.get(league, {}) else None


def team_name(league: str, code: str) -> str:
    """The full name: 'Buffalo Sabres'."""
    city, nick = LEAGUE_TEAMS[league][code]
    return nick if city == nick else f"{city} {nick}"


def nickname(league: str, code: str) -> str:
    return LEAGUE_TEAMS[league][code][1].lower()


def _named(league: str, code: str, outcome: str) -> bool:
    """Is `outcome` this team's name? Its nickname, its full name, or its
    city alone where no other team in the league shares the city."""
    loc, nick = LEAGUE_TEAMS[league][code]
    o = str(outcome).strip().lower()
    shared = sum(1 for lc, _ in LEAGUE_TEAMS[league].values() if lc == loc) > 1
    return o in (nick.lower(), f"{loc} {nick}".lower()) or (o == loc.lower() and not shared)


# --- fees --------------------------------------------------------------------

def kalshi_fee(contracts: int, price: float, rate: float = KALSHI_TAKER_RATE) -> float:
    """Taker fee, rounded UP to the cent on the whole order."""
    return math.ceil(rate * contracts * price * (1 - price) * 100 - 1e-9) / 100


def poly_fee(contracts: int, price: float, rate: float = POLY_SPORTS_TAKER_RATE, exponent: float = 1.0) -> float:
    return round(rate * contracts * (price * (1 - price)) ** exponent, 5)


@dataclass
class Game:
    venue: str
    teams: tuple                      # the two table keys, sorted
    date: dt.date
    ask: dict                         # team -> price of $1 if that team wins
    ref: str                          # ticker or slug, for the person to find it
    league: str = "nfl"               # codes repeat across leagues (MIN, CHI...): never paired across them
    #: team -> contracts (shares) resting at that ask. A team with no entry has
    #: no known size, and a leg with no known size is not priced.
    size: dict = field(default_factory=dict)
    tokens: dict = field(default_factory=dict)       # Polymarket: team -> CLOB token, for the book
    fee_rate: float = KALSHI_TAKER_RATE
    fee_exp: float = 1.0
    min_size: float = 1.0             # the fewest contracts the venue takes in one order
    read_at: float = 0.0              # when this game's price was read
    depth_at: dict = field(default_factory=dict)     # team -> when its book was read
    starts_at: float | None = None    # epoch seconds, where the venue says
    unread: set = field(default_factory=set)         # teams whose book could not be read

    def fee(self, contracts: int, price: float) -> float:
        if self.venue == "kalshi":
            return kalshi_fee(contracts, price, self.fee_rate)
        return poly_fee(contracts, price, self.fee_rate, self.fee_exp)


# --- reading the venues -------------------------------------------------------

def _num(value) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def kalshi_games(payload: dict, league: str, fee_rate: float | None = None, read_at: float = 0.0) -> list:
    """Kalshi's games for a league. Tickers carry the date, sometimes a start
    time, then both team codes (KXMLBGAME-26OCT081700CLECWS); each market's
    ticker ends in the one team it pays on, and the two must be exactly the
    pair the event names, in either order."""
    out = []
    rate = KALSHI_TAKER_RATE * KALSHI_FEE_MULTIPLIER[league] if fee_rate is None else fee_rate
    for ev in (payload or {}).get("events") or []:
        tick = ev.get("event_ticker", "")
        m = re.match(r"KX[A-Z]+GAME-(\d{2})([A-Z]{3})(\d{2})(?:\d{4})?([A-Z]+)$", tick)
        if not m or m.group(2) not in _MONTHS:
            continue
        yy, mon, dd, pair = m.groups()
        try:
            date = dt.date(2000 + int(yy), _MONTHS[mon], int(dd))
        except ValueError:
            continue
        ask, size, raw = {}, {}, []
        for mk in ev.get("markets") or []:
            if mk.get("status") not in (None, "active", "open"):
                continue
            code = mk.get("ticker", "").rsplit("-", 1)[-1]
            key = team_key(league, code, KALSHI_TO_TABLE)
            price = _num(mk.get("yes_ask_dollars"))
            if key is None or price is None or not 0 < price < 1:
                continue
            ask[key] = price
            raw.append(code)
            n = _num(mk.get("yes_ask_size_fp"))
            if n is not None and n >= 0:
                size[key] = math.floor(n)
        # Both teams priced, and they are the two the event ticker names. The
        # ticker's own spelling is compared with the ticker's own spelling:
        # Kalshi writes JAC where the table says JAX.
        if len(ask) != 2 or pair not in ("".join(raw), "".join(reversed(raw))):
            continue
        out.append(Game("kalshi", tuple(sorted(ask)), date, ask, tick, league=league, size=size,
                        fee_rate=rate, read_at=read_at))
    return out


def _jlist(value) -> list:
    """Polymarket sends its arrays as JSON text inside the JSON."""
    got = value if isinstance(value, list) else json.loads(value or "[]")
    if not isinstance(got, list):
        raise ValueError("not a list")
    return got


def _tokens(mk: dict, a: str, b: str) -> dict:
    """The market's two CLOB tokens, in the outcomes' order (a, then b)."""
    try:
        t = _jlist(mk.get("clobTokenIds"))
    except (TypeError, ValueError):
        return {}
    return {a: str(t[0]), b: str(t[1])} if len(t) == 2 else {}


def _fee_schedule(mk: dict) -> tuple:
    """(rate, exponent) from the market's own feeSchedule; the recorded rate
    where it is missing, switched off or implausible."""
    sched = mk.get("feeSchedule")
    if mk.get("feesEnabled") and isinstance(sched, dict):
        rate, exp = _num(sched.get("rate")), _num(sched.get("exponent"))
        if rate is not None and exp is not None and 0 < rate <= 0.25 and 0 < exp <= 4:
            return rate, exp
    return POLY_SPORTS_TAKER_RATE, 1.0


def _starts_at(mk: dict) -> float | None:
    raw = str(mk.get("gameStartTime") or "").strip()
    if not raw:
        return None
    raw = raw.replace(" ", "T", 1)
    if re.search(r"[+-]\d{2}$", raw):
        raw += ":00"
    try:
        when = dt.datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=dt.timezone.utc)
    return when.timestamp()


def poly_games(payload, league: str, read_at: float = 0.0) -> list:
    """Polymarket's games for a league. The slug's two codes become the table's;
    each outcome must name the team in the same position, or the market is
    refused; both asks must be buyable."""
    out = []
    for mk in payload if isinstance(payload, list) else []:
        m = re.match(rf"{league}-([a-z0-9]+)-([a-z0-9]+)-(\d{{4}}-\d{{2}}-\d{{2}})$", mk.get("slug", ""))
        if not m or mk.get("sportsMarketType") != "moneyline":
            continue
        if mk.get("closed") or mk.get("active") is False or mk.get("acceptingOrders") is False \
                or mk.get("enableOrderBook") is False:
            continue
        a, b = (team_key(league, c, POLY_TO_TABLE) for c in m.group(1, 2))
        if a is None or b is None or a == b:
            continue
        try:
            names = _jlist(mk.get("outcomes"))
            date = dt.date.fromisoformat(m.group(3))
        except (TypeError, ValueError):
            continue
        # The outcome names must be the two teams the slug names, in order.
        # A slug and a question that disagree are refused, not reconciled.
        if len(names) != 2 or not _named(league, a, names[0]) or not _named(league, b, names[1]):
            continue
        best_ask, best_bid = _num(mk.get("bestAsk")), _num(mk.get("bestBid"))
        if best_ask is None or best_bid is None:
            continue
        pa, pb = best_ask, round(1.0 - best_bid, 6)
        if not (0 < pa < 1 and 0 < pb < 1):
            continue
        rate, exp = _fee_schedule(mk)
        floor = _num(mk.get("orderMinSize"))
        out.append(Game("polymarket", tuple(sorted((a, b))), date, {a: pa, b: pb}, mk.get("slug", ""),
                        league=league, tokens=_tokens(mk, a, b), fee_rate=rate, fee_exp=exp,
                        min_size=floor if floor and floor > 0 else POLY_MIN_ORDER, read_at=read_at,
                        starts_at=_starts_at(mk)))
    return out


def poly_best_ask(fetch, token: str) -> tuple:
    """(price, shares) at the best ask of a token's order book: what a buyer
    really pays and how much of it can be bought at that price. (0, 0) for an
    empty ask side. The two tokens of a game are mirrors, so the second
    outcome's asks are the first's bids."""
    book = fetch(POLY_BOOK.format(token=token)) or {}
    if book.get("asset_id") not in (None, token):
        raise ValueError("the book is for another token")
    levels = []
    for a in book.get("asks") or []:
        p, n = _num(a.get("price")), _num(a.get("size"))
        if p is not None and n is not None and 0 < p < 1 and n > 0:
            levels.append((p, n))
    if not levels:
        return 0.0, 0.0
    best = min(p for p, _ in levels)
    return best, sum(n for p, n in levels if p <= best + 1e-9)


def add_poly_depth(fetch, games: list, wanted: set, clock=time.time) -> list:
    """For each (Polymarket ref, team) in `wanted`, read the order book and set
    that leg to the book's best ask and the shares resting there: size 0 when the
    book cannot be read or is empty, because an arbitrage not shown to be
    fillable is not one. Returns the sentences for the books that could not be
    read."""
    from concurrent.futures import ThreadPoolExecutor

    jobs = [(g, team, token) for g in games if g.venue == "polymarket"
            for team, token in g.tokens.items() if (g.ref, team) in wanted]

    def read(job):
        g, team, token = job
        return poly_best_ask(fetch, token), clock()

    problems = []
    with ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(lambda j: _attempt(read, j), jobs))
    for (g, team, _), (ok, got, _exc) in zip(jobs, results):
        if not ok:
            g.size[team] = 0.0
            g.unread.add(team)
            problems.append(f"Polymarket's book for {team_name(g.league, team)} could not be read ({got})")
            continue
        (price, shares), when = got
        g.depth_at[team] = when
        if shares > 0:
            g.ask[team], g.size[team] = price, shares
        else:
            g.size[team] = 0.0
    return problems


def _attempt(fn, arg):
    """(True, value, None), or (False, the plain reason, the exception)."""
    try:
        return True, fn(arg), None
    except Exception as exc:                                      # noqa: BLE001 - one read failing is not the scan failing
        return False, _why(exc), exc


def _why(exc: BaseException) -> str:
    """A plain reason for a failed read; never the raw exception text."""
    code = getattr(exc, "code", None)
    if isinstance(code, int):
        return f"HTTP {code}"
    name = type(exc).__name__
    text = f"{name} {exc}".lower()
    if "timed out" in text or "timeout" in text:
        return "timed out"
    if "certificate" in text or "[ssl" in text or "ssl" in name.lower():
        return "the secure connection failed"
    if isinstance(exc, (ValueError, KeyError, TypeError)) or "json" in text:
        return "an answer this version does not understand"
    return "no connection"


def kalshi_events(fetch, series: str, clock=time.time, max_pages: int = 5) -> tuple:
    """(payload, read_at): every open game of a series, following Kalshi's cursor."""
    events, cursor, first = [], "", None
    for _ in range(max_pages):
        url = KALSHI_EVENTS.format(series=series) + (f"&cursor={quote(cursor)}" if cursor else "")
        page = fetch(url) or {}
        first = clock() if first is None else first
        events += page.get("events") or []
        cursor = page.get("cursor") or ""
        if not cursor:
            break
    return {"events": events}, first


class UnknownFee(ValueError):
    """A fee schedule this version has no formula for."""


def kalshi_fee_rate(fetch, league: str) -> float:
    """The taker rate the series itself publishes: 0.07 times its multiplier.
    A fee type this version does not know is an error, not a guess."""
    got = fetch(KALSHI_SERIES_URL.format(series=KALSHI_SERIES[league])) or {}
    series = got.get("series", got)
    if series.get("fee_type") not in KALSHI_QUADRATIC:
        raise UnknownFee(f"fee type {series.get('fee_type')!r}")
    mult = _num(series.get("fee_multiplier"))
    mult = 1.0 if mult is None else mult
    if not 0 < mult <= 2:
        raise UnknownFee("fee multiplier")
    return KALSHI_TAKER_RATE * mult


def poly_league_tags(sports) -> dict:
    """league -> Polymarket's tag id, looked up from its /sports list on every
    run rather than written here: a hard-coded id breaks silently the day they
    renumber it."""
    out = {}
    for s in sports if isinstance(sports, list) else []:
        name = str(s.get("sport") or "").lower()
        if name in LEAGUES and s.get("primaryTagId") is not None:
            out[name] = str(s["primaryTagId"])
    return out


def poly_markets(fetch, tag: str, now: float, clock=time.time, max_pages: int = 4) -> tuple:
    """(markets, read_at): a league's game moneylines, soonest first. The window
    starts a day back so a game in progress is still there."""
    fmt = "%Y-%m-%dT%H:%M:%SZ"
    lo = time.strftime(fmt, time.gmtime(now - 86400))
    hi = time.strftime(fmt, time.gmtime(now + 30 * 86400))
    out, first = [], None
    for page in range(max_pages):
        got = fetch(POLY_GAMES.format(tag=tag, lo=lo, hi=hi, offset=page * 100))
        first = clock() if first is None else first
        got = got if isinstance(got, list) else []
        out += got
        if len(got) < 100:
            break
    return out, first


# --- matching and pricing ------------------------------------------------------

def match(kalshi: list, poly: list) -> list:
    """Same league, same two teams, and dated within the league's slack. A game
    that more than one listing could be is priced as none of them: two games on
    one date (a doubleheader) cannot be told apart by a slug."""
    pairs = [(k, p) for k in kalshi for p in poly
             if k.league == p.league and k.teams == p.teams
             and abs((k.date - p.date).days) <= DATE_SLACK.get(k.league, 0)]
    k_uses = {}
    p_uses = {}
    for k, p in pairs:
        k_uses[id(k)] = k_uses.get(id(k), 0) + 1
        p_uses[id(p)] = p_uses.get(id(p), 0) + 1
    return [(k, p) for k, p in pairs if k_uses[id(k)] == 1 and p_uses[id(p)] == 1]


#: How far under break-even, per contract, a quoted pair may sit and still be
#: worth a look at the order book. Polymarket's quote can be several cents off
#: its book in either direction, so the screen is wide and the book decides.
SCREEN_SLACK = 0.03


def worth_a_book(pairs: list) -> set:
    """The (Polymarket ref, team) legs whose quoted price is near enough to a
    profit, after both fees and before any rounding, to be worth a look at the
    order book. Only these are read: a book per leg of every game would be
    hundreds of requests."""
    out = set()
    for k, p in pairs:
        a, b = k.teams
        for k_team, p_team in ((a, b), (b, a)):
            ka, pa = k.ask[k_team], p.ask[p_team]
            if k.size.get(k_team, 0) < 1 or p_team not in p.tokens:
                continue
            unit = (k.fee_rate * ka * (1 - ka)) + (p.fee_rate * (pa * (1 - pa)) ** p.fee_exp)
            if 1.0 - ka - pa - unit > -SCREEN_SLACK:
                out.add((p.ref, p_team))
    return out


@dataclass
class Pairing:
    league: str
    teams: tuple
    game: str                         # 'Buffalo Sabres vs Dallas Stars'
    legs: list                        # [the Kalshi leg, the Polymarket leg]
    contracts: int
    cost_per_pair: float              # the two asks added
    fees: float
    profit: float                     # after both fees, on `contracts`, whichever team wins
    margin: float                     # profit / money staked
    staked: float                     # both venues' cost and fees: what the pair takes to place
    limited_by: str                   # what set the size: 'kalshi', 'polymarket' or 'bankroll'
    kalshi_ref: str
    poly_ref: str
    read_at: float
    age: float                        # seconds since the oldest price here was read
    starts_at: float | None
    in_play: bool
    note: str

    def as_dict(self) -> dict:
        d = dict(self.__dict__)
        d["teams"] = list(self.teams)
        return d


def _sized(k: Game, p: Game, k_team: str, p_team: str, bankroll: float):
    """(contracts, what set the size) for one direction, or None when it cannot
    be placed: a size unknown or empty on either side, or less than the venue's
    smallest order. Whole contracts, fees inside the bankroll."""
    ka, pa = k.ask[k_team], p.ask[p_team]
    k_cap, p_cap = int(k.size.get(k_team) or 0), int(p.size.get(p_team) or 0)
    if k_cap < 1 or p_cap < 1 or bankroll <= 0:
        return None
    per = ka + pa
    unit = per + (k.fee_rate * ka * (1 - ka)) + (p.fee_rate * (pa * (1 - pa)) ** p.fee_exp)
    afford = int(bankroll / unit)
    limits = [("polymarket", p_cap), ("kalshi", k_cap), ("bankroll", afford)]
    who, c = min(limits, key=lambda x: x[1])
    # Rounding the Kalshi fee up to the cent can push the last contract over.
    while c >= 1 and c * per + k.fee(c, ka) + p.fee(c, pa) > bankroll + 1e-9:
        c -= 1
        who = "bankroll"
    if c < 1 or c < k.min_size or c < p.min_size:
        return None
    return c, who


def price_pairs(pairs: list, bankroll: float = 1000.0, now: float | None = None) -> list:
    """Both ways round for every matched game, after both venues' fees and at
    the size actually resting. Returns every pairing that can be placed,
    profitable or not, best margin first; the caller lists only those that pay.

    Ranked by margin, not dollars: a size-limited pairing earns few dollars
    on a fat margin, and sorted by dollars a four-contract pairing losing 18
    cents outranked a thousand-contract one simply for being small.
    """
    now = time.time() if now is None else now
    out = []
    for k, p in pairs:
        a, b = k.teams
        for k_team, p_team in ((a, b), (b, a)):
            sized = _sized(k, p, k_team, p_team, bankroll)
            if sized is None:
                continue
            c, who = sized
            ka, pa = k.ask[k_team], p.ask[p_team]
            kf, pf = k.fee(c, ka), p.fee(c, pa)
            cost = c * (ka + pa)
            profit = round(c * 1.0 - cost - kf - pf, 2)
            staked = round(cost + kf + pf, 2)
            stamps = [t for t in (k.read_at, p.read_at, p.depth_at.get(p_team)) if t]
            read_at = min(stamps) if stamps else now
            # Equal contracts on each side pay the same $1 whichever team wins
            # (and $0.50 each in an NFL tie), so the pair makes `profit` either way.
            out.append(Pairing(
                league=k.league, teams=(a, b),
                game=f"{team_name(k.league, a)} vs {team_name(k.league, b)}",
                legs=[
                    {"venue": "kalshi", "team": k_team, "name": team_name(k.league, k_team), "unit": "contracts",
                     "ask": ka, "cents": round(ka * 100, 1), "contracts": c, "on_offer": int(k.size.get(k_team, 0)),
                     "cost": round(c * ka, 2), "fee": kf, "if_wins": profit, "ref": k.ref},
                    {"venue": "polymarket", "team": p_team, "name": team_name(k.league, p_team), "unit": "shares",
                     "ask": pa, "cents": round(pa * 100, 1), "contracts": c, "on_offer": int(p.size.get(p_team, 0)),
                     "cost": round(c * pa, 2), "fee": pf, "if_wins": profit, "ref": p.ref},
                ],
                contracts=c, cost_per_pair=round(ka + pa, 4), fees=round(kf + pf, 2), profit=profit,
                margin=round(profit / staked, 5) if staked else 0.0, staked=staked, limited_by=who,
                kalshi_ref=k.ref, poly_ref=p.ref, read_at=read_at, age=max(0.0, round(now - read_at, 1)),
                starts_at=p.starts_at, in_play=p.starts_at is not None and p.starts_at <= now,
                note=RESIDUAL_RISK_NFL if k.league == "nfl" else RESIDUAL_RISK))
    out.sort(key=lambda r: (r.margin, r.profit), reverse=True)
    return out


# --- the scan --------------------------------------------------------------------

@dataclass
class Scan:
    """Everything one press of Find arbs reads, and what it came to."""
    read_at: float
    bankroll: float
    leagues: dict                      # league -> {kalshi_games, polymarket_games, matched}
    priced: int                        # pairings that could be placed at a size
    pairs: list                        # the Pairings that pay, best margin first
    errors: list
    min_margin: float = 0.0

    @property
    def kalshi_games(self) -> int:
        return sum(v["kalshi_games"] for v in self.leagues.values())

    @property
    def polymarket_games(self) -> int:
        return sum(v["polymarket_games"] for v in self.leagues.values())

    @property
    def matched(self) -> int:
        return sum(v["matched"] for v in self.leagues.values())

    @property
    def read_anything(self) -> bool:
        return bool(self.kalshi_games or self.polymarket_games)

    def source(self) -> str:
        return (f"LIVE — {self.kalshi_games} Kalshi games and {self.polymarket_games} Polymarket games read, "
                f"{self.matched} on both, {len(self.pairs)} playable")

    def as_dict(self) -> dict:
        return {
            "read_at": self.read_at, "bankroll": self.bankroll, "min_margin": self.min_margin,
            "leagues": self.leagues, "kalshi_games": self.kalshi_games, "polymarket_games": self.polymarket_games,
            "matched": self.matched, "priced": self.priced, "playable": len(self.pairs),
            "pairs": [r.as_dict() for r in self.pairs], "errors": self.errors, "read_anything": self.read_anything,
            "fees_read": FEES_READ, "fee_sources": list(FEE_SOURCES),
        }


def _gather(tasks: dict) -> dict:
    """Run named reads side by side: name -> (ok, value or the plain reason, exception)."""
    from concurrent.futures import ThreadPoolExecutor

    names = list(tasks)
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(lambda n: _attempt(lambda _: tasks[n](), n), names))
    return dict(zip(names, results))


def scan(fetch, bankroll: float = 1000.0, min_margin: float = 0.0, leagues=LEAGUES, clock=time.time) -> Scan:
    """Read Kalshi and Polymarket for each league, match the games, look at the
    order book behind every Polymarket leg that could pay, and price every
    pairing at the size resting. `min_margin` is a fraction (0.01 for 1%).

    Every read is its own failure: one league or one book that cannot be read
    is named in `errors` and the rest still count."""
    errors: list[str] = []
    started = clock()

    first = {}
    for lg in leagues:
        first[f"k:{lg}"] = (lambda lg=lg: kalshi_events(fetch, KALSHI_SERIES[lg], clock))
        first[f"f:{lg}"] = (lambda lg=lg: kalshi_fee_rate(fetch, lg))
    first["sports"] = lambda: fetch(POLY_SPORTS)
    got = _gather(first)

    kalshi: dict = {}
    for lg in leagues:
        ok, ev, _ = got[f"k:{lg}"]
        if not ok:
            errors.append(f"Kalshi {lg.upper()} prices could not be read ({ev})")
            continue
        ok_fee, rate, why = got[f"f:{lg}"]
        if isinstance(why, UnknownFee):
            # A formula this version does not have: guessing one prices a fee that is not charged.
            errors.append(f"Kalshi's {lg.upper()} games are not priced: their fee schedule is one this version does not know")
            continue
        if not ok_fee:
            rate = KALSHI_TAKER_RATE * KALSHI_FEE_MULTIPLIER[lg]
            errors.append(f"Kalshi's {lg.upper()} fee schedule could not be read ({rate / KALSHI_TAKER_RATE:g}x "
                          f"the standard rate, as recorded {FEES_READ}, was charged)")
        kalshi[lg] = kalshi_games(ev[0], lg, fee_rate=rate, read_at=ev[1])

    ok, sports, _ = got["sports"]
    tags = poly_league_tags(sports) if ok else {}
    if not ok:
        errors.append(f"Polymarket's list of leagues could not be read ({sports})")
    second = {}
    for lg in leagues:
        if lg in tags:
            second[f"p:{lg}"] = (lambda lg=lg: poly_markets(fetch, tags[lg], started, clock))
        elif ok:
            errors.append(f"Polymarket lists no {lg.upper()} games")
    got2 = _gather(second)

    poly: dict = {}
    for lg in leagues:
        if f"p:{lg}" not in got2:
            continue
        ok, mk, _ = got2[f"p:{lg}"]
        if not ok:
            errors.append(f"Polymarket {lg.upper()} prices could not be read ({mk})")
            continue
        poly[lg] = poly_games(mk[0], lg, read_at=mk[1])

    pairs, counts = [], {}
    for lg in leagues:
        k, p = kalshi.get(lg, []), poly.get(lg, [])
        found = match(k, p)
        pairs += found
        counts[lg] = {"kalshi_games": len(k), "polymarket_games": len(p), "matched": len(found)}

    wanted = worth_a_book(pairs)
    if wanted:
        errors += add_poly_depth(fetch, [p for _, p in pairs], wanted, clock)

    finished = clock()
    priced = price_pairs(pairs, bankroll=bankroll, now=finished)
    playable = [r for r in priced if r.profit > 0 and r.margin >= min_margin]
    return Scan(finished, bankroll, counts, len(priced), playable, errors, min_margin)
