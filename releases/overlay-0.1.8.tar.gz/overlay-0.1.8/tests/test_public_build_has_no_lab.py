"""The public app carries none of the research lab.

The lab (`backend/edgelab` on the edge-lab branch: its findings, its packed
snapshot, its Ask assistant) is not public. Matthew has not decided whether
its findings stay private, and a release is irreversible: an installed copy
keeps whatever it shipped with. So the public window may not send a `lab` verb,
the shell may not allow one, and neither the app bundle, the wheel nor the
source tarball may pick up `edgelab` code or data, even after a merge brings
the directory into this tree.
"""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JS = (ROOT / "ui" / "src" / "app.js").read_text()
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
RUST = "\n".join(p.read_text() for p in (ROOT / "ui" / "src-tauri" / "src").glob("*.rs"))
BUILD = (ROOT / "scripts" / "build_app.sh").read_text()
PYPROJECT = (ROOT / "pyproject.toml").read_text()
MANIFEST = (ROOT / "MANIFEST.in").read_text()


def test_the_window_sends_no_lab_verb():
    """Every engine command the window can build, by its first word."""
    verbs = {m.group(1) for m in re.finditer(r'^\s*[a-z-]+:\s*\(\)\s*=>\s*\[\s*"([a-z-]+)"', JS, re.M)}
    assert verbs, "no argv builders found: the extractor has drifted"
    assert "lab" not in verbs, "the public window builds a lab command"
    assert '"lab"' not in JS


def test_the_shell_allows_no_lab_verb():
    allowed = re.search(r'const ALLOWED: \[&str; \d+\] = \[([^\]]+)\]', RUST)
    assert allowed, "the allow-list moved"
    assert '"lab"' not in allowed.group(1)


def test_the_window_has_no_lab_pages():
    """The lab's places (Today's best bets, Research, Ask, My books' feed key)
    are edge-lab's. Their engine calls are gone above; their pages go too."""
    for page in ("panel-moves", "panel-props", "panel-edges", "panel-ask", "panel-books", "ask-bar"):
        assert f'id="{page}"' not in HTML, page
    assert "anthropic" not in (JS + HTML).lower()


def test_the_app_bundle_adds_no_lab_code_or_data():
    assert "edgelab" not in BUILD, "build_app.sh names the lab"
    assert re.search(r"--hidden-import overlay_engine\.cli", BUILD), "the build's import line moved"


def test_the_wheel_packages_only_the_engine():
    find = PYPROJECT[PYPROJECT.index("[tool.setuptools.packages.find]"):]
    find = find[:find.find("\n[", 1) if "\n[" in find[1:] else len(find)]
    include = re.search(r'^include = \[([^\]]*)\]', find, re.M)
    assert include, "pyproject's package list moved"
    assert include.group(1).replace(" ", "") == '"overlay_engine*"', include.group(1)
    assert "edgelab" not in PYPROJECT


def test_the_source_tarball_leaves_the_lab_out():
    """`recursive-include backend *.py` would sweep in backend/edgelab the day
    a merge brings it here. The prune says it never ships."""
    assert re.search(r"^prune backend/edgelab$", MANIFEST, re.M)
