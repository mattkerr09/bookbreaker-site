"""The release path makes what Check for updates installs, and only signed.

`scripts/build_app.sh --ship` ends by tarring the notarised, stapled app and
signing it with the updater key; `scripts/updater_manifest.py` turns that into
updater.json. These read the script rather than run it: running a ship build
from a test would notarise with Apple, and a broken guard under test would
do exactly that for real.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = (ROOT / "scripts" / "build_app.sh").read_text()
MANIFEST = (ROOT / "scripts" / "updater_manifest.py").read_text()
CONF = json.loads((ROOT / "ui" / "src-tauri" / "tauri.conf.json").read_text())


def _at(text: str) -> int:
    i = BUILD.find(text)
    assert i >= 0, f"build_app.sh no longer contains {text!r}"
    return i


def test_a_ship_build_refuses_without_the_updater_key():
    """Before anything is built: a ship build that discovered the missing key
    after notarising would have spent Apple's time on a release no installed
    copy can take."""
    guard = re.search(
        r'if \[ "\$MODE" = "ship" \] && \[ ! -f "\$UPD_KEY" \]; then\n(.*?)\nfi', BUILD, re.S)
    assert guard, "the ship build no longer refuses when the updater key is missing"
    assert "exit 1" in guard.group(1)
    assert guard.start() < _at("python3 -m PyInstaller") < _at("xcrun notarytool")
    assert '$HOME/.bookbreaker-updater/bookbreaker_updater.key' in BUILD


def test_the_updater_download_is_made_after_stapling_and_signed():
    """Tarred after the staple, so the copy an update installs opens offline;
    signed with the updater key; and an empty or missing .sig stops the build."""
    stapled = _at('xcrun stapler staple "$APP"')
    tarred = _at("tar -czf -")
    signed = _at('tauri signer sign -f "$UPD_KEY" -p ""')
    assert stapled < tarred < signed
    assert re.search(r'\[ -s "\$UPD_TGZ\.sig" \] \|\| \{[^}]*exit 1; \}', BUILD), (
        "a missing signature no longer stops the build")


def test_the_updater_download_holds_the_app_at_its_top_level():
    """The updater drops the first path component when it unpacks, so the
    archive must be made from the app's parent: `Bookbreaker.app/...`."""
    assert ('( cd "$(dirname "$APP")" && COPYFILE_DISABLE=1 tar -czf - '
            '"$(basename "$APP")" ) > "$UPD_TGZ"') in BUILD


def test_the_build_unpacks_the_download_and_runs_its_engine():
    """"The archive was made" is not "the app inside it works"."""
    for check in ('codesign --verify --strict "$UPD_CHK/Bookbreaker.app"',
                  'xcrun stapler validate "$UPD_CHK/Bookbreaker.app"',
                  '"$UPD_CHK/Bookbreaker.app/Contents/Resources/engine/overlay-engine" devig'):
        assert check in BUILD, check


def test_the_build_and_the_manifest_agree_on_the_file_name():
    """build_app.sh writes it and updater_manifest.py reads it; the site serves
    it under the same name."""
    assert 'UPD_TGZ="dist/Bookbreaker-$VER.app.tar.gz"' in BUILD
    assert 'f"Bookbreaker-{version}.app.tar.gz"' in MANIFEST


def test_tauri_does_not_make_its_own_updater_artifacts():
    """`tauri build` would tar the app before the engine is injected and
    before Apple has seen it. The build script makes the one that ships."""
    assert CONF["bundle"].get("createUpdaterArtifacts") is False
