"""The ship build notarises the app and the disk image the same way.

From 0.1.7 the build can reach Apple's notary through a keychain profile
(BOOKBREAKER_NOTARY_PROFILE) or the APPLE_ID triple. Both submissions must go
through the one NOTARY setting: a DMG submitted with credentials the app's
submission did not use is the kind of split that fails only on release day.
"""
from pathlib import Path

BUILD = (Path(__file__).resolve().parents[1] / "scripts" / "build_app.sh").read_text()


def test_both_submissions_use_the_same_notary_settings():
    submits = [l.strip() for l in BUILD.splitlines() if "notarytool submit" in l and not l.strip().startswith("#")]
    assert len(submits) == 2, submits
    assert all('"${NOTARY[@]}" --wait' in s for s in submits), submits
    assert 'NOTARY=(--keychain-profile "$BOOKBREAKER_NOTARY_PROFILE")' in BUILD
