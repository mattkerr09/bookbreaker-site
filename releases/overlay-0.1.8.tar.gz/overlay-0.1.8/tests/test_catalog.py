

def test_a_court_ordered_block_removes_a_nationwide_venue_from_that_state():
    """Kalshi is nationwide except where a court or regulator has blocked its
    sports contracts; a user in Michigan must not be shown it as a venue."""
    from overlay_engine.catalog import EXCLUSION_SOURCES, VENUES, for_state
    kalshi = VENUES["kalshi"]
    for st in ("MA", "MI", "NV", "WA"):
        assert not kalshi.available_in(st), st
        assert "kalshi" not in {v.key for v in for_state(st)}, st
    assert kalshi.available_in("NY") and kalshi.available_in("oh")
    for key, v in VENUES.items():
        if v.excluded:
            assert key in EXCLUSION_SOURCES, f"{key} excludes states with no source"
            assert v.nationwide, f"{key} has exclusions but is not nationwide"
