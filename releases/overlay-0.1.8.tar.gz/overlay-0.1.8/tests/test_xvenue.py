"""Live arbitrage between Kalshi and Polymarket, without a socket.

Every failure here is a row that loses money: a mismatched game, a price that
cannot be bought, a fee left out, a size nobody offered, or a stale date
pairing last week's game with this week's. The payloads are recorded from the
two venues on 2026-10-08 (tests/fixtures/live/recorded.json: a few games of
each league, the Polymarket market objects with their `events` and
`description` dropped, and the order books of their tokens trimmed to the top
eight levels). Nothing here touches the network: a fetcher that answers from
the recording stands where the real one would, and refuses what it was not
taught, so a request nobody expected fails a test instead of passing quietly.

The recording holds no arbitrage, because on that day there was none. Where a
test needs one, it moves a price in the recording and says which.
"""

import copy
import datetime as dt
import json
import re
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pytest

from overlay_engine import xvenue

FIXTURE = json.loads((Path(__file__).parent / "fixtures" / "live" / "recorded.json").read_text())
NOW = 1791503231.0                          # 2026-10-08 23:47:11 UTC, when the recording was made

TB_DAL = "KXNFLGAME-26OCT08TBDAL"            # Thursday night; Polymarket dates it the 9th (UTC)
PHI_JAC = "KXNFLGAME-26OCT11PHIJAC"          # Kalshi writes JAC; Polymarket and the table say JAX
BOS_CLE = "KXNBAGAME-26OCT08BOSCLE"
LAD_MIL_11 = "KXMLBGAME-26OCT112000LADMIL"
LAD_MIL_12 = "KXMLBGAME-26OCT122000LADMIL"


class Venues:
    """Kalshi, Polymarket's list and its order books, answering from the recording."""

    def __init__(self):
        self.f = copy.deepcopy(FIXTURE)
        self.requests = []
        self.fail = {}                      # a substring of a URL -> the exception to raise for it
        self.tags = {str(s["primaryTagId"]): s["sport"] for s in self.f["polymarket_sports"]}
        self.series = {xvenue.KALSHI_SERIES[lg]: lg for lg in xvenue.LEAGUES}

    def __call__(self, url):
        self.requests.append(url)
        for part, exc in self.fail.items():
            if part in url:
                raise exc
        parsed = urlparse(url)
        query = parse_qs(parsed.query)
        if parsed.netloc == "api.elections.kalshi.com" and parsed.path.endswith("/events"):
            return self.f["kalshi_events"][self.series[query["series_ticker"][0]]]
        if parsed.netloc == "api.elections.kalshi.com" and "/series/" in parsed.path:
            return self.f["kalshi_series"][self.series[parsed.path.rsplit("/", 1)[-1]]]
        if parsed.netloc == "gamma-api.polymarket.com" and parsed.path == "/sports":
            return self.f["polymarket_sports"]
        if parsed.netloc == "gamma-api.polymarket.com" and parsed.path == "/markets":
            league = self.tags[query["tag_id"][0]]
            return self.f["polymarket_markets"][league] if query["offset"] == ["0"] else []
        if parsed.netloc == "clob.polymarket.com" and parsed.path == "/book":
            return self.f["polymarket_books"][query["token_id"][0]]       # a KeyError is an unreadable book
        raise AssertionError(f"a request nobody expected: {url}")

    # -- moving a price in the recording ------------------------------------------------
    def kalshi(self, league, ticker, team, ask=None, size=None):
        for ev in self.f["kalshi_events"][league]["events"]:
            if ev["event_ticker"] == ticker:
                for mk in ev["markets"]:
                    if mk["ticker"].endswith("-" + team):
                        if ask is not None:
                            mk["yes_ask_dollars"] = f"{ask:.4f}"
                        if size is not None:
                            mk["yes_ask_size_fp"] = f"{size:.2f}"
                        return mk
        raise KeyError((ticker, team))

    def market(self, league, slug):
        return next(m for m in self.f["polymarket_markets"][league] if m["slug"] == slug)

    def book(self, league, slug, outcome, asks):
        """Replace the ask side of one outcome's book: asks is [(price, shares)], best last."""
        mk = self.market(league, slug)
        token = json.loads(mk["clobTokenIds"])[outcome]
        self.f["polymarket_books"].setdefault(token, {"asset_id": token, "bids": [], "asks": []})["asks"] = [
            {"price": f"{p}", "size": f"{n}"} for p, n in sorted(asks, reverse=True)]


def arb_world(kalshi_size=500):
    """TB-DAL with Kalshi's Buccaneers at 15c: with Polymarket's Cowboys at 81c that is 96c a dollar."""
    v = Venues()
    v.kalshi("nfl", TB_DAL, "TB", ask=0.15, size=kalshi_size)
    return v


def scan(v, **kw):
    return xvenue.scan(v, clock=lambda: NOW, **kw)


def games(v, league):
    k = xvenue.kalshi_games(v.f["kalshi_events"][league], league)
    p = xvenue.poly_games(v.f["polymarket_markets"][league], league)
    return k, p


# --- fees, against the venues' own tables -----------------------------------

def test_polymarket_fee_matches_its_published_table():
    """docs.polymarket.com fee table, sports at the 0.05 rate, 100 shares."""
    assert xvenue.poly_fee(100, 0.30) == pytest.approx(1.05)
    assert xvenue.poly_fee(100, 0.50) == pytest.approx(1.25)
    assert xvenue.poly_fee(100, 0.90) == pytest.approx(0.45)


def test_kalshi_fee_matches_its_published_range_and_rounds_up():
    """kalshi.com/fee-schedule: $0.07-$1.75 per 100 contracts."""
    assert xvenue.kalshi_fee(100, 0.50) == pytest.approx(1.75)
    assert xvenue.kalshi_fee(100, 0.01) == pytest.approx(0.07)
    # 0.07 x 1 x 0.3 x 0.7 = 0.0147 -> an ordinary account pays a whole cent up.
    assert xvenue.kalshi_fee(1, 0.30) == pytest.approx(0.02)


def test_each_venue_publishes_its_own_rate_and_the_scan_uses_it():
    """The NFL pays Polymarket 3%, the others 5%; Kalshi's MLB multiplier is half.
    Charging one rate everywhere is how a real arb is hidden or a false one shown."""
    v = Venues()
    assert xvenue.kalshi_fee_rate(v, "nfl") == pytest.approx(0.07)
    assert xvenue.kalshi_fee_rate(v, "mlb") == pytest.approx(0.035)
    _, nfl = games(v, "nfl")
    _, nba = games(v, "nba")
    assert {p.fee_rate for p in nfl} == {0.03} and {p.fee_rate for p in nba} == {0.05}
    assert xvenue.poly_fee(100, 0.5, 0.03) == pytest.approx(0.75)


def test_a_schedule_that_cannot_be_read_is_charged_at_the_dearer_rate():
    v = Venues()
    for lost in ({"feeSchedule": None}, {"feesEnabled": False}, {"feeSchedule": {"rate": 9, "exponent": 1}},
                 {"feeSchedule": {"rate": "free", "exponent": 1}}):
        v.f = copy.deepcopy(FIXTURE)
        v.market("nfl", "nfl-tb-dal-2026-10-09").update(lost)
        got = {p.ref: p for p in xvenue.poly_games(v.f["polymarket_markets"]["nfl"], "nfl")}
        assert got["nfl-tb-dal-2026-10-09"].fee_rate == xvenue.POLY_SPORTS_TAKER_RATE, lost


def test_a_kalshi_fee_type_this_version_does_not_know_is_refused():
    v = Venues()
    v.f["kalshi_series"]["nhl"]["series"]["fee_type"] = "flat"
    with pytest.raises(ValueError):
        xvenue.kalshi_fee_rate(v, "nhl")
    got = scan(v)
    assert any("NHL" in e and "fee schedule" in e and "does not know" in e for e in got.errors)
    assert got.leagues["nhl"]["kalshi_games"] == 0 and got.leagues["nhl"]["matched"] == 0, (
        "a fee this version has no formula for is not priced at some other fee")
    assert got.leagues["nfl"]["matched"] == 4


def test_a_fee_schedule_that_cannot_be_read_is_charged_as_recorded_and_says_so():
    v = Venues()
    v.fail["/series/KXMLBGAME"] = OSError("offline")
    got = scan(v)
    assert any("MLB" in e and "fee schedule could not be read" in e and "0.5x" in e for e in got.errors)
    assert got.leagues["mlb"]["matched"] == 3, "the games are still read; only the fee is the recorded one"


# --- parsing and matching ---------------------------------------------------

def test_kalshi_game_is_read_from_its_ticker():
    k, _ = games(Venues(), "nfl")
    g = next(g for g in k if g.ref == TB_DAL)
    assert g.teams == ("DAL", "TB") and g.date == dt.date(2026, 10, 8)
    assert g.ask == {"DAL": 0.81, "TB": 0.20}
    assert g.size["DAL"] > 1_000_000 and g.size["TB"] > 1_000_000


def test_a_ticker_that_spells_jacksonville_JAC_is_still_read():
    """The first port compared Kalshi's JAC with the table's JAX and dropped the
    game in silence, so the Jaguars never appeared on the board."""
    k, p = games(Venues(), "nfl")
    g = next((g for g in k if g.ref == PHI_JAC), None)
    assert g is not None, "the Jaguars' game was dropped"
    assert g.teams == ("JAX", "PHI")
    assert len(xvenue.match(k, p)) == len(k), "every recorded Kalshi game finds its Polymarket game"


def test_a_baseball_ticker_with_a_start_time_is_read():
    k, _ = games(Venues(), "mlb")
    g = next(g for g in k if g.ref == "KXMLBGAME-26OCT081700CLECWS")
    assert g.date == dt.date(2026, 10, 8) and g.teams == ("CLE", "CWS")


def test_a_game_whose_markets_are_not_the_pair_the_ticker_names_is_refused():
    v = Venues()
    v.kalshi("nfl", TB_DAL, "TB")["ticker"] = TB_DAL + "-NE"
    k, _ = games(v, "nfl")
    assert TB_DAL not in {g.ref for g in k}


def test_a_game_with_a_side_nobody_is_selling_is_refused():
    v = Venues()
    v.kalshi("nfl", TB_DAL, "TB")["yes_ask_dollars"] = "0.0000"
    v.kalshi("nfl", PHI_JAC, "PHI")["yes_ask_dollars"] = None
    k, _ = games(v, "nfl")
    assert not {TB_DAL, PHI_JAC} & {g.ref for g in k}


def test_a_market_that_is_not_open_is_not_read():
    v = Venues()
    v.kalshi("nba", BOS_CLE, "BOS")["status"] = "closed"
    k, _ = games(v, "nba")
    assert BOS_CLE not in {g.ref for g in k}
    v = Venues()
    for field, value in (("closed", True), ("active", False), ("acceptingOrders", False), ("enableOrderBook", False)):
        v.f = copy.deepcopy(FIXTURE)
        v.market("nba", "nba-bos-cle-2026-10-08")[field] = value
        _, p = games(v, "nba")
        assert "nba-bos-cle-2026-10-08" not in {g.ref for g in p}, field


def test_polymarket_second_side_ask_is_one_minus_the_bid_not_the_midpoint():
    """outcomePrices is a midpoint and cannot be bought."""
    v = Venues()
    mk = v.market("nfl", "nfl-tb-dal-2026-10-09")
    mk.update(bestAsk=0.30, bestBid=0.29, outcomePrices='["0.295", "0.705"]')
    g = next(g for g in xvenue.poly_games(v.f["polymarket_markets"]["nfl"], "nfl") if g.ref == mk["slug"])
    assert g.ask["TB"] == pytest.approx(0.30)
    assert g.ask["DAL"] == pytest.approx(0.71)                    # not 0.705


def test_a_slug_and_outcomes_that_disagree_are_refused():
    v = Venues()
    mk = v.market("nfl", "nfl-tb-dal-2026-10-09")
    for outcomes in (["Cowboys", "Buccaneers"], ["Buccaneers", "Bears"], ["Buccaneers"], []):
        mk["outcomes"] = json.dumps(outcomes)
        assert "nfl-tb-dal-2026-10-09" not in {g.ref for g in xvenue.poly_games(v.f["polymarket_markets"]["nfl"], "nfl")}
    # In the other order than the slug is how a false arb is born: the Brewers' ask priced as the Padres'.
    mk = v.market("mlb", "mlb-lad-mil-2026-10-11")
    mk["outcomes"] = json.dumps(["Milwaukee Brewers", "Los Angeles Dodgers"])
    assert "mlb-lad-mil-2026-10-11" not in {g.ref for g in xvenue.poly_games(v.f["polymarket_markets"]["mlb"], "mlb")}


def test_polymarkets_spellings_become_the_tables_and_names_are_checked():
    _, nhl = games(Venues(), "nhl")
    by_ref = {g.ref: g for g in nhl}
    assert by_ref["nhl-tor-las-2026-10-08"].teams == ("TOR", "VGK")        # LAS is Vegas here
    assert by_ref["nhl-utah-bos-2026-10-08"].teams == ("BOS", "UTA")
    assert by_ref["nhl-lak-las-2026-10-10"].teams == ("LA", "VGK")


def test_a_city_two_teams_share_is_not_a_name():
    """'New York' could be the Mets or the Yankees; 'Utah' is one team."""
    assert not xvenue._named("mlb", "NYY", "New York")
    assert xvenue._named("mlb", "NYY", "New York Yankees") and xvenue._named("mlb", "NYY", "Yankees")
    assert xvenue._named("nhl", "UTA", "Utah")


def test_a_market_that_is_not_a_game_moneyline_is_not_read():
    v = Venues()
    base = v.market("nba", "nba-bos-cle-2026-10-08")
    spread = dict(base, slug="nba-bos-cle-2026-10-08-spread-home-2pt5", sportsMarketType="spreads")
    season = dict(base, slug="will-the-celtics-win-the-season-series", sportsMarketType="moneyline")
    typed = dict(base, sportsMarketType="spreads")
    got = xvenue.poly_games([spread, season, typed], "nba")
    assert got == []


def test_nfl_games_match_across_the_timezone_day_and_no_further():
    v = Venues()
    k, p = games(v, "nfl")
    tb_dal = [(a, b) for a, b in xvenue.match(k, p) if a.ref == TB_DAL]
    assert len(tb_dal) == 1 and (tb_dal[0][1].date - tb_dal[0][0].date).days == 1       # Oct 8 ET, Oct 9 UTC
    v.market("nfl", "nfl-tb-dal-2026-10-09")["slug"] = "nfl-tb-dal-2026-10-11"
    k, p = games(v, "nfl")
    assert not [1 for a, _ in xvenue.match(k, p) if a.ref == TB_DAL], "a game two days away is a different game"


def test_a_series_game_never_pairs_with_the_next_days_game():
    """Baseball plays the same two teams on consecutive days. On 2026-10-06 a day of
    slack paired today's game with tomorrow's, at a price that looked guaranteed."""
    k, p = games(Venues(), "mlb")
    pairs = xvenue.match(k, p)
    lad_mil = sorted((a.date, b.date) for a, b in pairs if a.teams == ("LAD", "MIL"))
    assert lad_mil == [(dt.date(2026, 10, 11), dt.date(2026, 10, 11)), (dt.date(2026, 10, 12), dt.date(2026, 10, 12))]
    # With only the 11th on Polymarket, Kalshi's 12th has no game to pair with.
    only_11 = [g for g in p if g.date != dt.date(2026, 10, 12)]
    assert sorted(a.date for a, _ in xvenue.match(k, only_11) if a.teams == ("LAD", "MIL")) == [dt.date(2026, 10, 11)]


def test_leagues_never_mix():
    """Minnesota and Dallas have NBA and NHL teams with the same codes on the same night."""
    when = dt.date(2026, 10, 22)
    nba = xvenue.Game("kalshi", ("DAL", "MIN"), when, {"DAL": 0.5, "MIN": 0.5}, "KXNBAGAME", league="nba")
    nhl = xvenue.Game("polymarket", ("DAL", "MIN"), when, {"DAL": 0.5, "MIN": 0.5}, "nhl-dal-min", league="nhl")
    assert xvenue.match([nba], [nhl]) == []


def test_a_game_two_listings_could_be_is_priced_as_neither():
    """A doubleheader: two Kalshi games with the same teams on the same date, one
    Polymarket slug. Pairing the slug with both would price one of them against
    the wrong game."""
    when = dt.date(2026, 10, 22)
    kal = [xvenue.Game("kalshi", ("CLE", "CWS"), when, {"CLE": 0.5, "CWS": 0.5}, f"KXMLBGAME-{t}", league="mlb")
           for t in ("a", "b")]
    pol = [xvenue.Game("polymarket", ("CLE", "CWS"), when, {"CLE": 0.5, "CWS": 0.5}, "mlb-cle-cws", league="mlb")]
    assert xvenue.match(kal, pol) == []
    assert len(xvenue.match(kal[:1], pol)) == 1


# --- sizing and pricing ---------------------------------------------------------------

def _pair(k_ask, p_ask, k_size=5000, p_size=5000, league="nhl", teams=("CHI", "PIT"), p_min=5.0, **kw):
    """CHI against PIT: Kalshi sells PIT at k_ask[PIT], Polymarket sells CHI at p_ask[CHI]."""
    when = dt.date(2026, 10, 22)
    k = xvenue.Game("kalshi", teams, when, dict(k_ask), "KX", league=league, size={t: k_size for t in teams},
                    fee_rate=0.07, read_at=NOW - 6)
    p = xvenue.Game("polymarket", teams, when, dict(p_ask), "nhl-chi-pit", league=league,
                    size={t: p_size for t in teams}, fee_rate=0.05, min_size=p_min, read_at=NOW - 4,
                    depth_at={t: NOW - 2 for t in teams})
    return k, p


def test_a_real_gap_is_an_arb_after_fees_at_the_size_on_offer():
    got = scan(arb_world(kalshi_size=500))
    best = next(r for r in got.pairs if r.legs[0]["team"] == "TB")
    assert best.game == "Dallas Cowboys vs Tampa Bay Buccaneers" and best.league == "nfl"
    k, p = best.legs
    assert (k["venue"], k["team"], p["venue"], p["team"]) == ("kalshi", "TB", "polymarket", "DAL")
    # 500 contracts: Kalshi shows 500 at 15c; Polymarket shows far more at 81c; $1,000 would buy ~1,000.
    assert best.contracts == 500 and best.limited_by == "kalshi"
    assert k["contracts"] == p["contracts"] == 500 and k["on_offer"] == 500 and p["on_offer"] > 100_000
    kalshi_fee = xvenue.kalshi_fee(500, 0.15)
    poly_fee = xvenue.poly_fee(500, 0.81, 0.03)
    assert kalshi_fee == pytest.approx(4.47) and poly_fee == pytest.approx(2.3085)
    # Profit is what is left after BOTH fees, on the contracts actually bought.
    assert best.profit == pytest.approx(500 - 500 * (0.15 + 0.81) - kalshi_fee - poly_fee, abs=0.01)
    assert best.profit == 13.22
    assert best.staked == pytest.approx(500 * 0.96 + kalshi_fee + poly_fee, abs=0.01)
    assert best.margin == pytest.approx(best.profit / best.staked, abs=1e-4)
    # Equal contracts on each side pay the same dollar whichever team wins.
    assert [leg["if_wins"] for leg in best.legs] == [best.profit, best.profit]
    assert k["cost"] == 75.0 and p["cost"] == 405.0
    assert got.pairs == [best], "the one pair that pays, and nothing else"


def test_the_pair_is_sized_to_the_smallest_book_or_the_money():
    assert scan(arb_world(kalshi_size=40)).pairs[0].contracts == 40
    rich = scan(arb_world(kalshi_size=5_000_000), bankroll=100.0).pairs[0]
    assert rich.limited_by == "bankroll" and rich.staked <= 100.0 + 1e-9
    assert 95 <= rich.contracts <= 104, "about $100 at 96c a pair and 1.4c of fees"


def test_the_pair_never_costs_more_than_the_money_you_said_including_fees():
    """Sized on cost alone, $1,000 bought $1,012 of bets once the fees were added."""
    for bankroll in (50.0, 100.0, 333.0, 1000.0, 7000.0):
        k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62}, k_size=10**7, p_size=10**7)
        [row] = [r for r in xvenue.price_pairs([(k, p)], bankroll=bankroll, now=NOW) if r.profit > 0]
        assert row.staked <= bankroll + 1e-9, bankroll
        assert row.contracts * row.cost_per_pair + row.fees == pytest.approx(row.staked, abs=0.011)
        # ...and is the most that fits: one more contract would not.
        more = row.contracts + 1
        assert more * 0.90 + k.fee(more, 0.40) + p.fee(more, 0.50) > bankroll - 1e-9


def test_a_bankroll_that_cannot_buy_one_pair_buys_none():
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    assert xvenue.price_pairs([(k, p)], bankroll=0.80, now=NOW) == []
    assert xvenue.price_pairs([(k, p)], bankroll=0.0, now=NOW) == []


def test_a_leg_whose_size_is_not_known_is_not_priced():
    """Kalshi's list omitting a size, or Polymarket's book never read: unknown is
    not unlimited. The first port sized an unknown Kalshi leg by the bankroll."""
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    assert [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    k.size = {}
    assert not [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    del p.size["CHI"]
    assert not [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0 and r.legs[1]["team"] == "CHI"]
    k.size["PIT"] = 0
    assert not [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.legs[0]["team"] == "PIT"]


def test_a_polymarket_leg_is_limited_to_the_shares_at_the_books_best_ask():
    v = arb_world()
    v.kalshi("nfl", TB_DAL, "TB", size=5000)
    v.book("nfl", "nfl-tb-dal-2026-10-09", 1, [(0.81, 12), (0.83, 90000)])     # only 12 shares at 81c
    [best] = scan(v).pairs
    assert best.contracts == 12 and best.limited_by == "polymarket"
    assert best.legs[1]["on_offer"] == 12 and best.legs[0]["on_offer"] == 5000


def test_polymarket_is_priced_at_what_its_book_sells_for_not_at_its_quote():
    """On 2026-10-08 the market list quoted the Knicks at 66c while the book was
    selling them at 72c. The quote said 3.5% free money; the book said none."""
    v = Venues()
    v.kalshi("nba", "KXNBAGAME-26OCT08WASNYK", "WAS", ask=0.28, size=1729)
    mk = v.market("nba", "nba-was-nyk-2026-10-08")
    mk.update(bestAsk=0.30, bestBid=0.34)                           # quotes the Knicks (second outcome) at 66c
    v.book("nba", "nba-was-nyk-2026-10-08", 1, [(0.72, 342), (0.73, 900)])
    got = scan(v)
    assert got.pairs == [], "the book decides, not the list"
    # And when the book backs the quote, the same pair pays.
    v.book("nba", "nba-was-nyk-2026-10-08", 1, [(0.66, 342), (0.67, 900)])
    [best] = scan(v).pairs
    assert best.legs[1]["ask"] == 0.66 and best.legs[1]["on_offer"] == 342 and best.contracts == 342


def test_an_unreadable_polymarket_book_is_no_arbitrage_and_is_reported():
    v = arb_world()
    v.fail["clob.polymarket.com"] = OSError("offline")
    got = scan(v)
    assert got.pairs == []
    assert any("Polymarket's book" in e and "Dallas Cowboys" in e for e in got.errors)
    v = arb_world()
    v.book("nfl", "nfl-tb-dal-2026-10-09", 1, [])
    assert scan(v).pairs == [], "an empty ask side has nothing to buy"


def test_an_order_under_polymarkets_smallest_is_not_a_play():
    v = arb_world()
    v.book("nfl", "nfl-tb-dal-2026-10-09", 1, [(0.81, 3)])                  # orderMinSize is 5 shares
    assert scan(v).pairs == []
    v.book("nfl", "nfl-tb-dal-2026-10-09", 1, [(0.81, 5)])
    assert scan(v).pairs[0].contracts == 5


def test_a_dollar_of_cost_is_a_loss_once_fees_are_paid():
    k, p = _pair({"CHI": 0.60, "PIT": 0.41}, {"CHI": 0.59, "PIT": 0.60})        # PIT 0.41 + CHI 0.59 = $1.00
    rows = xvenue.price_pairs([(k, p)], now=NOW)
    assert rows and all(r.profit < 0 for r in rows)


def test_ranked_by_margin_not_by_dollars():
    fat_small = _pair({"CHI": 0.60, "PIT": 0.30}, {"CHI": 0.60, "PIT": 0.61}, k_size=40)
    thin_big = _pair({"CHI": 0.60, "PIT": 0.42}, {"CHI": 0.53, "PIT": 0.60}, k_size=100000)
    rows = [r for r in xvenue.price_pairs([fat_small, thin_big], bankroll=5000, now=NOW) if r.profit > 0]
    assert len(rows) == 2
    assert [r.margin for r in rows] == sorted((r.margin for r in rows), reverse=True)
    assert rows[0].contracts == 40 and rows[0].profit < rows[1].profit, "the small fat one is first, by margin"


def test_every_pairing_carries_the_postponement_risk_and_the_nfl_one_the_tie():
    for r in scan(arb_world()).pairs:
        assert "postponement" in r.note and "Polymarket waits" in r.note and "tie" in r.note
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    [row] = [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    assert "postponement" in row.note and "tie" not in row.note


def test_a_game_under_way_says_so():
    v = arb_world()
    [best] = scan(v).pairs
    assert best.starts_at is not None and best.in_play is False      # kick-off was 2026-10-09 00:15 UTC
    later = xvenue.scan(v, clock=lambda: best.starts_at + 600)
    assert later.pairs and later.pairs[0].in_play is True


def test_age_is_measured_from_the_oldest_price_read():
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    [row] = [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    assert row.read_at == NOW - 6 and row.age == 6.0                # Kalshi's read is the oldest
    p.depth_at["CHI"] = NOW - 30
    [row] = [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    assert row.age == 30.0, "an old order book makes the whole pair old"


# --- the scan ---------------------------------------------------------------------------

def test_the_recorded_market_has_no_arb_and_the_scan_says_nothing_pays():
    v = Venues()
    got = scan(v)
    assert got.pairs == [] and got.errors == []
    assert got.read_anything and got.matched >= 15
    assert got.source().endswith("0 playable") and "Kalshi games" in got.source()
    assert {lg: c["matched"] for lg, c in got.leagues.items()} == {
        "nfl": 4, "mlb": 3, "nba": 4, "nhl": 5}, "every recorded game finds its other venue"


def test_only_pairs_that_pay_are_listed_never_the_nearest_misses():
    v = arb_world()
    # Another game, a few cents short: priced, close, and not a play.
    v.kalshi("nfl", PHI_JAC, "PHI", ask=0.22, size=1000)               # + Polymarket's Jaguars at 77c: 99c, less fees
    got = scan(v)
    assert [r.game for r in got.pairs] == ["Dallas Cowboys vs Tampa Bay Buccaneers"]
    assert got.priced > len(got.pairs), "the near misses were priced, and not listed"
    k, p = games(v, "nfl")
    near = [r for r in xvenue.price_pairs(xvenue.match(k, p), now=NOW) if r.game.startswith("Jacksonville")]
    assert all(r.profit <= 0 for r in near)
    assert len(json.loads(json.dumps(got.as_dict()))["pairs"]) == len(got.pairs)


def test_hide_under_applies_to_the_return():
    v = arb_world()
    [best] = scan(v).pairs
    assert scan(v, min_margin=best.margin - 0.001).pairs
    assert scan(v, min_margin=best.margin + 0.001).pairs == []


def test_one_league_failing_does_not_fail_the_scan():
    v = arb_world()
    v.fail["KXNHLGAME"] = OSError("offline")
    got = scan(v)
    assert got.pairs and got.read_anything
    assert any("NHL" in e and "no connection" in e for e in got.errors)
    assert got.leagues["nfl"]["matched"] == 4 and got.leagues["nhl"]["kalshi_games"] == 0


def test_nothing_read_is_not_nothing_to_play():
    v = Venues()
    v.fail["api.elections.kalshi.com"] = OSError("offline")
    v.fail["polymarket.com"] = OSError("offline")
    got = scan(v)
    assert got.read_anything is False and got.pairs == [] and got.errors
    assert got.as_dict()["read_anything"] is False


def test_a_failed_read_names_its_reason_in_plain_words():
    import socket
    import urllib.error
    v = Venues()
    v.fail["KXNFLGAME"] = urllib.error.HTTPError("u", 429, "Too Many", {}, None)
    v.fail["KXMLBGAME"] = socket.timeout("timed out")
    v.fail["KXNBAGAME"] = ValueError("{not json")
    got = scan(v)
    text = " | ".join(got.errors)
    assert "NFL prices could not be read (HTTP 429)" in text
    assert "MLB prices could not be read (timed out)" in text
    assert "NBA prices could not be read (an answer this version does not understand)" in text
    assert "{not json" not in text


def test_only_legs_near_a_profit_get_their_book_read():
    """A book per leg of every game would be hundreds of requests."""
    v = arb_world()
    scan(v)
    asked = {u.split("token_id=")[1] for u in v.requests if "/book" in u}
    tokens = json.loads(v.market("nfl", "nfl-tb-dal-2026-10-09")["clobTokenIds"])
    assert tokens[1] in asked, "the Cowboys' book, behind the arbitrage, was read"
    v = Venues()
    got = scan(v)
    books = [u for u in v.requests if "clob.polymarket.com/book" in u]
    assert 0 < len(books) < got.matched, (len(books), got.matched)


def test_kalshis_cursor_is_followed_and_polymarkets_pages_are_walked():
    pages = {"": {"events": [{"event_ticker": "a"}], "cursor": "next page=1"}, "next page=1": {"events": [{"event_ticker": "b"}], "cursor": ""}}
    seen = []

    def fetch(url):
        seen.append(url)
        cursor = parse_qs(urlparse(url).query).get("cursor", [""])[0]
        return pages[cursor]
    payload, _ = xvenue.kalshi_events(fetch, "KXNFLGAME")
    assert [e["event_ticker"] for e in payload["events"]] == ["a", "b"]
    assert "cursor=next%20page%3D1" in seen[1]

    full = [{"slug": f"x{i}"} for i in range(100)]
    calls = []

    def poly(url):
        calls.append(parse_qs(urlparse(url).query)["offset"][0])
        return full if len(calls) == 1 else [{"slug": "last"}]
    got, _ = xvenue.poly_markets(poly, "450", NOW)
    assert len(got) == 101 and calls == ["0", "100"]


def test_polymarkets_window_starts_a_day_back_so_a_game_under_way_is_there():
    seen = []
    xvenue.poly_markets(lambda url: seen.append(url) or [], "450", NOW)
    q = parse_qs(urlparse(seen[0]).query)
    assert q["end_date_min"] == ["2026-10-07T23:47:11Z"] and q["sports_market_types"] == ["moneyline"]
    assert q["closed"] == ["false"] and q["tag_id"] == ["450"]


def test_the_requests_carry_nothing_about_the_person():
    """Public market data, going one way: no stake, no identity, nothing but the league."""
    v = arb_world()
    scan(v, bankroll=12345.67)
    assert v.requests
    for url in v.requests:
        parsed = urlparse(url)
        assert parsed.netloc in ("api.elections.kalshi.com", "gamma-api.polymarket.com", "clob.polymarket.com"), url
        assert "12345" not in url and "bankroll" not in url.lower(), url
        assert set(parse_qs(parsed.query)) <= {"series_ticker", "status", "with_nested_markets", "limit", "cursor",
                                               "closed", "sports_market_types", "tag_id", "order", "ascending",
                                               "end_date_min", "end_date_max", "offset", "token_id"}, url


def test_the_scan_makes_all_its_requests_with_the_seam_it_was_given():
    """No fetcher means no network: the module opens no socket of its own."""
    src = (Path(xvenue.__file__)).read_text()
    for opener in ("urlopen", "urllib.request", "import socket", "import requests", "http.client"):
        assert opener not in src, opener
    assert re.search(r"def scan\(fetch,", src)


def test_the_scan_serialises():
    got = json.loads(json.dumps(scan(arb_world()).as_dict()))
    pair = got["pairs"][0]
    assert {"league", "teams", "game", "legs", "contracts", "fees", "profit", "margin", "staked", "limited_by",
            "age", "in_play", "note"} <= set(pair)
    assert {"venue", "team", "name", "unit", "ask", "cents", "contracts", "on_offer", "cost", "fee", "if_wins"} <= set(pair["legs"][0])
    assert got["fees_read"] == xvenue.FEES_READ and got["read_at"] == NOW


# --- the command line: `board` and `board --live` -----------------------------------------

from overlay_engine import cli, pubfeed  # noqa: E402


def _board(monkeypatch, capsys, v, *argv):
    monkeypatch.setattr(pubfeed, "urllib_fetcher", v)
    code = cli.main(["board", *argv])
    return code, capsys.readouterr().out


def test_board_without_live_never_touches_a_network(monkeypatch, capsys):
    """The window passes --live only while its switch is on. Without it the
    board is the demonstration market and nothing here may open a connection."""
    import socket
    touched = []

    def refuse(*a, **k):
        touched.append(a)
        raise AssertionError("the board touched the network without --live")
    monkeypatch.setattr(pubfeed, "urllib_fetcher", refuse)
    monkeypatch.setattr(socket.socket, "connect", refuse)
    monkeypatch.setattr(socket, "create_connection", refuse)
    for argv in (["board", "--json"], ["board"], ["board", "--bankroll", "5000", "--min-margin", "0"]):
        code = cli.main(argv)
        out = capsys.readouterr().out
        assert touched == [], f"{argv} touched the network without --live"
        assert code == 0 and "DEMONSTRATION" in out.upper()


def test_board_live_json_says_what_it_read_and_that_nothing_pays(monkeypatch, capsys):
    v = Venues()
    code, out = _board(monkeypatch, capsys, v, "--live", "--json")
    data = json.loads(out)
    assert code == 0 and data["live"] is True and data["command"] == "board"
    assert data["source"].startswith("LIVE") and data["source"].endswith("0 playable")
    assert data["rows"] == [], "rows is the sportsbook board; live pairs are under cross_venue"
    xv = data["cross_venue"]
    assert xv["pairs"] == [] and xv["playable"] == 0 and xv["matched"] == 16 and xv["errors"] == []
    assert xv["read_anything"] is True and xv["fees_read"] == xvenue.FEES_READ
    assert v.requests, "--live reads the venues"


def test_board_live_lists_a_pair_with_the_size_on_offer(monkeypatch, capsys):
    code, out = _board(monkeypatch, capsys, arb_world(), "--live", "--json", "--bankroll", "1000")
    data = json.loads(out)
    [pair] = data["cross_venue"]["pairs"]
    assert code == 0 and data["source"].endswith("1 playable")
    assert [leg["on_offer"] for leg in pair["legs"]][0] == 500 and pair["legs"][1]["on_offer"] > 100_000
    assert pair["contracts"] == 500 and pair["profit"] == 13.22 and pair["limited_by"] == "kalshi"
    assert pair["legs"][0]["unit"] == "contracts" and pair["legs"][1]["unit"] == "shares"
    assert "postponement" in pair["note"]


def test_board_live_human_output_says_so_plainly_when_nothing_pays(monkeypatch, capsys):
    code, out = _board(monkeypatch, capsys, Venues(), "--live")
    assert code == 0
    assert "No pair pays either way right now at the size on offer." in out
    assert "16 games are listed on both venues" in out
    assert "guaranteed" not in out.lower()


def test_board_live_human_output_for_a_pair_keeps_its_promises(monkeypatch, capsys):
    code, out = _board(monkeypatch, capsys, arb_world(), "--live")
    assert code == 0
    assert "locked if both bets are accepted and stand" in out
    assert "Check the amount on offer before you bet." in out
    assert "500 contracts of 500 on offer" in out and "500 shares of" in out
    assert "sized by kalshi" in out and "$4.47 fee" in out
    assert "guaranteed" not in out.lower()


def test_board_live_that_could_not_read_either_venue_says_so_and_exits_nonzero(monkeypatch, capsys):
    v = Venues()
    v.fail["api.elections.kalshi.com"] = OSError("offline")
    v.fail["polymarket.com"] = OSError("offline")
    code, out = _board(monkeypatch, capsys, v, "--live", "--json")
    assert code == 1 and json.loads(out)["cross_venue"]["read_anything"] is False
    v.requests.clear()
    code, out = _board(monkeypatch, capsys, v, "--live")
    assert code == 1 and "could not be read from either venue" in out
    assert "No pair pays" not in out, "not reading the venues is not the same as nothing paying"


def test_board_live_hide_under_is_a_percentage(monkeypatch, capsys):
    _, out = _board(monkeypatch, capsys, arb_world(), "--live", "--json", "--min-margin", "1")
    assert len(json.loads(out)["cross_venue"]["pairs"]) == 1          # 2.7% clears 1%
    _, out = _board(monkeypatch, capsys, arb_world(), "--live", "--json", "--min-margin", "5")
    assert json.loads(out)["cross_venue"]["pairs"] == []
