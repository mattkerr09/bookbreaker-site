"""The engine grows a machine-readable mouth rather than a second engine.

A user interface cannot parse the tables this CLI prints. The wrong fix is to
reimplement the devig, the Kelly and the fill model in whatever language the
interface happens to be written in, where nothing gates them and they are free
to drift from the numbers the site publishes. So `--json` returns the same
values the human output prints, from the same call.
"""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CLI = ROOT / "backend" / "cli.py"


def run(*argv):
    got = subprocess.run([sys.executable, str(CLI), *argv],
                         capture_output=True, text=True, timeout=60)
    return got


def payload(*argv):
    got = run(*argv)
    assert got.returncode == 0, got.stderr
    return json.loads(got.stdout)


# ------------------------------------------------------------------ devig

def test_devig_json_parses_and_names_its_command():
    out = payload("devig", "-110", "-110", "--json")
    assert out["command"] == "devig"
    assert len(out["outcomes"]) == 2


def test_devig_json_carries_every_method_the_table_prints():
    out = payload("devig", "-110", "-110", "--json")
    assert set(out["methods"]) == {"additive", "multiplicative", "power", "shin"}
    for outcome in out["outcomes"]:
        assert set(outcome["by_method"]) == set(out["methods"])


def test_devig_json_matches_the_human_output():
    """The whole point: one implementation, two mouths."""
    out = payload("devig", "-110", "-110", "--json")
    human = run("devig", "-110", "-110").stdout
    assert f"{out['hold']:.2%}" in human
    assert f"{out['overround']:.4f}" in human


def test_a_symmetric_market_has_no_spread_between_methods():
    out = payload("devig", "-110", "-110", "--json")
    assert out["outcomes"][0]["spread"] == 0.0


def test_an_asymmetric_market_does_have_a_spread():
    out = payload("devig", "-200", "+150", "--json")
    assert out["outcomes"][0]["spread"] > 0


# -------------------------------------------------------------------- arb

def test_arb_json_reports_the_round_stakes_and_their_cost():
    out = payload("arb", "2.10", "2.05", "--stake", "1000", "--json")
    assert out["arbitrage"] is True
    assert len(out["legs"]) == 2
    assert out["rounding_cost"] >= 0
    assert out["profit"] <= out["ideal_profit"]


def test_every_arb_leg_returns_at_least_the_total_staked():
    out = payload("arb", "2.10", "2.05", "--stake", "1000", "--json")
    for leg in out["legs"]:
        assert leg["returns"] >= out["total_stake"]


def test_arb_json_says_what_each_outcome_makes():
    """"Whichever wins, you make at least $35": each leg's figure is the profit
    on the whole pair if that leg wins, and the guaranteed one is the least."""
    out = payload("arb", "2.10", "2.05", "--stake", "1000", "--json")
    made = [leg["if_wins"] for leg in out["legs"]]
    assert min(made) == round(out["profit"], 2)
    assert [leg["american"] for leg in out["legs"]] == [110, 105]


def test_no_arbitrage_is_a_result_rather_than_an_error():
    """A UI needs to render "these prices do not cross", not receive nothing
    and guess why."""
    got = run("arb", "1.91", "1.91", "--json")
    assert got.returncode == 0
    out = json.loads(got.stdout)
    assert out["arbitrage"] is False
    assert out["loss_per_unit"] > 0
    assert "legs" not in out


# ------------------------------------------------------------------ kelly

def test_kelly_json_reports_the_binding_constraint():
    out = payload("kelly", "--odds", "2.5", "--prob", "0.45",
                  "--bankroll", "10000", "--json")
    assert out["command"] == "kelly"
    assert out["binding"]
    assert 0 < out["stake"] <= 10000


def test_the_fractional_stake_is_below_full_kelly():
    out = payload("kelly", "--odds", "2.5", "--prob", "0.45",
                  "--bankroll", "10000", "--fraction", "0.25", "--json")
    assert out["stake_fraction"] < out["full_kelly"]


def test_kelly_json_matches_the_human_output():
    out = payload("kelly", "--odds", "2.5", "--prob", "0.45",
                  "--bankroll", "10000", "--json")
    human = run("kelly", "--odds", "2.5", "--prob", "0.45",
                "--bankroll", "10000").stdout
    assert f"{out['full_kelly']:.2%}" in human


# ------------------------------------------------------------------ shape

def test_json_is_the_only_thing_on_stdout():
    """A UI parses stdout. One stray print and every payload is unreadable."""
    got = run("devig", "-110", "-110", "--json")
    json.loads(got.stdout)          # raises if anything else was printed
    assert got.stderr == ""


def test_the_flag_is_refused_before_the_subcommand_rather_than_ignored():
    """It was briefly accepted there and silently printed a table, because the
    subparser default overwrote it. An error beats a lie."""
    got = run("--json", "devig", "-110", "-110")
    assert got.returncode != 0
    # With --json the refusal comes back as the window's JSON error rather than on stderr; refused either way.
    assert "unrecognized arguments" in got.stderr + got.stdout and "overround" not in got.stdout


def test_the_table_still_prints_without_the_flag():
    got = run("devig", "-110", "-110")
    assert got.returncode == 0
    assert "overround" in got.stdout
    assert not got.stdout.lstrip().startswith("{")


# ----------------------------------------------------------------- parlay

def test_parlay_json_reports_the_gap_between_paid_and_fair():
    out = payload("parlay", "-110", "-110", "-110", "-110", "--json")
    assert out["command"] == "parlay"
    assert out["legs"] == 4
    assert out["pays"] < out["fair_pays"]      # the whole subject
    assert out["hold"] > out["leg_hold"]       # the margin compounds


def test_parlay_json_answers_in_dollars_on_a_hundred():
    """The window says "bet $100, it wins $1,228; a fair price wins $1,500; on
    average you lose $16.98" from these figures, so they are the engine's."""
    out = payload("parlay", "-110", "-110", "-110", "-110", "--json")
    hundred = out["per_100"]
    assert hundred["wins"] == round(100 * out["pays"], 2)
    assert hundred["fair_wins"] == round(100 * out["fair_pays"], 2)
    assert hundred["expected"] == round(100 * out["ev"], 2) < 0
    assert out["american"] == 1228 and out["fair_american"] == 1500


def test_devig_json_names_the_no_vig_price():
    out = payload("devig", "-110", "-110", "--json")
    assert [o["fair_american"] for o in out["outcomes"]] == [100, 100]
    assert [o["american"] for o in out["outcomes"]] == [-110, -110]


def test_the_hold_compounds_with_every_leg():
    two = payload("parlay", "-110", "-110", "--json")
    six = payload("parlay", *(["-110"] * 6), "--json")
    assert six["hold"] > two["hold"]
    assert six["multiple"] > two["multiple"]


def test_same_game_legs_are_flagged_as_an_upper_bound():
    """Multiplying correlated legs is the wrong sum, and a calculator that
    does it quietly is the thing this one exists not to be."""
    apart = payload("parlay", "-110", "-110", "--json")
    same = payload("parlay", "-110", "-110", "--same-game", "--json")
    assert same["same_game"] is True
    assert "upper bound" in same["correlation_note"]
    assert "upper bound" not in apart["correlation_note"]


def test_a_parlay_needs_at_least_two_legs():
    got = run("parlay", "-110", "--json")
    assert got.returncode != 0


# ------------------------------------------------------------------- fill

def test_fill_json_carries_provenance_not_just_a_number():
    """The whole differentiator. 88% from a fitted quote life and 88% from a
    stated prior are different claims, and a window that cannot tell them
    apart is the screen this engine exists to replace."""
    out = payload("fill", "--age", "10", "--json")
    assert out["command"] == "fill"
    assert out["tau_measured"] is False        # nothing observed on a bare run
    assert out["latency_measured"] is False


def test_latency_is_added_to_the_age_the_screen_showed():
    out = payload("fill", "--age", "10", "--json")
    assert out["effective_age"] == out["age"] + out["latency"]
    assert out["latency"] > 0                  # never zero, which is the point


def test_ignoring_latency_always_flatters_the_fill():
    out = payload("fill", "--age", "10", "--json")
    assert out["fill_naive"] > out["fill"]


def test_an_older_quote_is_less_likely_to_be_there():
    young = payload("fill", "--age", "2", "--json")
    old = payload("fill", "--age", "60", "--json")
    assert old["fill"] < young["fill"]


def test_the_realised_edge_is_the_screen_edge_times_the_fill():
    out = payload("fill", "--age", "10", "--json")
    assert out["edge_realised"] == out["edge"] * out["fill"]


# ------------------------------------------------------------------ what was typed wrong

def test_the_window_gets_a_plain_sentence_for_input_it_cannot_read():
    """Argparse's own complaint is a usage dump written for a terminal, and the window shows the error it is
    given. With --json a bad number or a missing field comes back as one sentence a person can act on."""
    bad = run("arb", "-110", "+120", "--stake", "abc", "--json")
    assert bad.returncode == 2
    assert json.loads(bad.stdout) == {"error": "'abc' is not a number. Type the stake like 100."}
    missing = run("kelly", "--json")
    assert json.loads(missing.stdout)["error"] == "Fill in the odds and the win chance first."
    assert "usage:" not in bad.stdout + missing.stdout


def test_the_terminal_keeps_argparse_s_own_message():
    got = run("arb", "-110", "+120", "--stake", "abc")
    assert got.returncode == 2 and "invalid float value: 'abc'" in got.stderr and not got.stdout
