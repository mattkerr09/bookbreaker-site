"""Welcome offers, ranked by what converts — and never shown unsourced.

The competitor tables sort by headline. The headline is the one number on
the page that is not what the bettor keeps, so the failures that matter here
are ranking by it, pricing a stale offer as current, loading one with no
source at all, and showing an offer in a state it is not for.
"""

import csv
import datetime as dt
import json
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import welcome
from overlay_engine.promo import bonus_bet_conversion

ROOT = Path(__file__).resolve().parent.parent
FIELDS = ["book", "offer_type", "headline", "states", "qualifying_stake", "bonus",
          "installments", "boost", "max_stake", "expires_days", "ends", "read",
          "source", "note"]


def _feed(tmp_path, rows):
    path = tmp_path / "offers.csv"
    with path.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in FIELDS})
    return path


def _row(book, bonus, **kw):
    base = dict(book=book, offer_type="bet_and_get", headline=f"{book} offer",
                qualifying_stake="10", bonus=str(bonus), installments="1",
                expires_days="7", read=str(dt.date.today()),
                source=f"https://example.com/{book}", states="NJ")
    base.update(kw)
    return base


def test_a_row_with_no_source_does_not_load(tmp_path):
    path = _feed(tmp_path, [_row("dk", 150, source="")])
    with pytest.raises(ValueError, match="no source"):
        welcome.load(path)


def test_a_row_with_no_read_date_does_not_load(tmp_path):
    path = _feed(tmp_path, [_row("dk", 150, read="")])
    with pytest.raises(ValueError, match="no read date"):
        welcome.load(path)


def test_a_stale_offer_is_listed_and_never_priced(tmp_path):
    old = str(dt.date.today() - dt.timedelta(days=welcome.MAX_AGE_DAYS + 1))
    path = _feed(tmp_path, [_row("dk", 150, read=old)])
    [p] = welcome.price(welcome.load(path))
    assert p.stale
    assert p.guaranteed == 0.0 and p.steps == []


def test_ranked_by_what_you_keep_not_by_the_headline(tmp_path):
    """A bigger face paid in seven one-day installments must still rank by the
    guaranteed figure. The fixture makes headline order and value order
    disagree, or the test cannot tell them apart."""
    path = _feed(tmp_path, [
        _row("dk", 400, qualifying_stake="10000"),  # 2% of 10,000 = 200 lost qualifying
        _row("fd", 300, qualifying_stake="5"),
    ])
    priced = welcome.price(welcome.load(path))
    assert priced[0].face < priced[1].face, "the fixture must disagree"
    assert priced[0].book == "fd"


def test_the_value_is_the_tested_conversion_less_only_the_cost_of_rounding():
    """The exact conversion is the ceiling; rounding the hedge to a human
    stake may cost at most ROUNDING_COST_LIMIT of it, and never adds."""
    hedge = welcome.hedge_decimal(4.0, 0.02)
    exact = bonus_bet_conversion(4.0, hedge, 100.0).guaranteed
    [p] = welcome.price([dict(_row("dk", 100, qualifying_stake="0"), _age=0)])
    assert p.guaranteed <= exact + 1e-9
    assert p.guaranteed >= exact * (1 - welcome.ROUNDING_COST_LIMIT)


def test_no_recommended_hedge_reads_as_calculator_output():
    """The heat model scores cents as the loudest limiting signal. The first
    version of this screen told people to hedge $115.50 and $577.50 — every
    one of them scored 1.00, at the book whose risk desk profiles on it."""
    for p in welcome.price(welcome.load()):
        if p.guaranteed:
            assert p.hedge_stake == int(p.hedge_stake), p
            assert p.hedge_heat <= 0.3, (p.name, p.hedge_stake, p.hedge_heat)


def test_the_steps_say_how_to_keep_the_account():
    for p in welcome.price(welcome.load()):
        if p.guaranteed:
            assert welcome.KEEP_THE_ACCOUNT in p.steps


def test_a_boost_is_never_called_guaranteed():
    [p] = welcome.price([dict(_row("caesars", 0), offer_type="profit_boost",
                              boost="1.0", max_stake="25", installments="10",
                              _age=0)])
    assert p.guaranteed == 0.0
    assert p.expected > 0.0


def test_the_shipped_feed_loads_and_every_row_is_cited():
    rows = welcome.load()
    assert rows, "the shipped feed is empty"
    for r in rows:
        assert r["source"].startswith("https://")


def test_the_cli_states_its_priors():
    done = subprocess.run([sys.executable, str(ROOT / "backend" / "cli.py"),
                           "welcome", "--json"], capture_output=True, text=True,
                          timeout=120)
    assert done.returncode == 0, done.stderr[:400]
    data = json.loads(done.stdout)
    assert "PRIORS" in data["assumptions"]
    assert data["offers"]


def test_an_offer_for_a_venue_we_do_not_cover_does_not_load(tmp_path):
    """`b365` and `czr` are not catalog keys; offers written against them
    rendered as bare codes with no venue behind them."""
    path = _feed(tmp_path, [_row("b365", 200)])
    with pytest.raises(ValueError, match="not a catalog venue"):
        welcome.load(path)


# ---------------------------------------------------------------- by state
# One book can pay $200 in one state, $150 in the next and nothing in a third.
# The feed holds one row per distinct offer with the states it is for, and
# every failure below is a way of showing someone an offer that is not theirs.


def _shipped():
    """The shipped feed read raw, so these checks do not lean on load()'s."""
    with welcome.FEED.open() as fh:
        return list(csv.DictReader(fh))


def _is_date(s):
    try:
        dt.date.fromisoformat(s)
        return True
    except (TypeError, ValueError):
        return False


def test_a_row_with_no_states_does_not_load(tmp_path):
    """Read as "everywhere", an empty cell would show bet365's $200 to
    someone in Illinois, where the same book pays $150."""
    path = _feed(tmp_path, [_row("dk", 150, states="")])
    with pytest.raises(ValueError, match="no states"):
        welcome.load(path)


def test_a_row_listed_where_the_book_does_not_operate_does_not_load(tmp_path):
    """New Hampshire's only online book is DraftKings."""
    path = _feed(tmp_path, [_row("fd", 250, states="NJ NH")])
    with pytest.raises(ValueError, match="NH, where the catalog does not have FanDuel"):
        welcome.load(path)


def test_a_row_with_a_code_that_is_not_a_state_does_not_load(tmp_path):
    """Ontario is not a US state. Kalshi is catalogued as nationwide, so the
    venue check would wave "ON" through; only this one stops it."""
    path = _feed(tmp_path, [_row("kalshi", 10, states="NJ ON")])
    with pytest.raises(ValueError, match="ON is not a state code"):
        welcome.load(path)


def test_an_offer_shape_this_screen_cannot_price_does_not_load(tmp_path):
    """It would reach the screen as "$0.00"."""
    path = _feed(tmp_path, [_row("mgm", 150, offer_type="bet_and_get_if_you_win")])
    with pytest.raises(ValueError, match="not one this screen can price"):
        welcome.load(path)


def test_an_offer_past_its_end_date_is_listed_and_never_priced(tmp_path):
    yesterday = str(dt.date.today() - dt.timedelta(days=1))
    path = _feed(tmp_path, [_row("dk", 150, ends=yesterday)])
    [p] = welcome.price(welcome.load(path))
    assert p.ended and p.stale
    assert p.guaranteed == 0.0 and p.steps == []


def test_an_offer_on_its_last_day_is_still_priced(tmp_path):
    path = _feed(tmp_path, [_row("dk", 150, ends=str(dt.date.today()))])
    [p] = welcome.price(welcome.load(path))
    assert not p.ended and p.guaranteed > 0


def test_a_safety_net_is_an_average_never_a_locked_amount():
    """The refund exists only if the cash bet loses, so nothing about it is
    kept whichever side wins."""
    [p] = welcome.price([dict(_row("hardrock", 0, offer_type="safety_net",
                                   max_stake="50", installments="10"), _age=0)])
    assert p.guaranteed == 0.0
    assert p.expected > 0.0
    assert p.face == 500.0


def _three_states():
    """One book, three offers by state, the way bet365's are."""
    return welcome.price([
        dict(_row("bet365", 200, states="NJ OH"), _age=0),
        dict(_row("bet365", 150, states="IL TN"), _age=0),
        dict(_row("bet365", 365, states="IN"), _age=0),
    ])


def test_in_a_state_only_that_states_offer_is_shown():
    out = welcome.for_you(_three_states(), state="IL")
    assert [(p.book, p.face) for p in out] == [("bet365", 150.0)]
    assert not out[0].ineligible and out[0].guaranteed > 0


def test_a_book_with_two_offers_in_one_state_counts_once():
    """Caesars runs two welcome offers through different codes. A new account
    takes one, so the second is labelled and carries no value."""
    priced = welcome.price([
        dict(_row("caesars", 250), _age=0),
        dict(_row("caesars", 100, headline="smaller"), _age=0),
    ])
    out = welcome.for_you(priced, state="NJ")
    assert [p.face for p in out] == [250.0, 100.0]
    assert not out[0].ineligible
    assert "alternative" in out[1].ineligible and out[1].guaranteed == 0.0


def test_with_no_state_a_book_is_never_counted_twice():
    out = welcome.for_you(_three_states())
    live = [p for p in out if not p.ineligible]
    assert [p.face for p in live] == [365.0]
    assert all("differ by state" in p.ineligible for p in out[1:])


def test_best_per_book_takes_a_state_and_never_adds_a_books_offers_together():
    offers = _three_states()
    assert [p.face for p in welcome.best_per_book(offers, state="IL")] == [150.0]
    assert [p.face for p in welcome.best_per_book(offers, state="NY")] == []
    assert [p.face for p in welcome.best_per_book(offers)] == [365.0]


def test_an_offer_at_a_book_you_already_use_is_not_yours():
    priced = welcome.price([dict(_row("dk", 150), _age=0), dict(_row("fd", 250), _age=0)])
    out = welcome.for_you(priced, have="fd")
    fd = next(p for p in out if p.book == "fd")
    assert fd.ineligible and fd.guaranteed == 0.0
    assert out[-1].book == "fd", "ineligible offers go to the end"


def test_an_offer_at_a_book_not_licensed_in_your_state_is_marked():
    """New Hampshire is a DraftKings-only market."""
    priced = welcome.price([dict(_row("dk", 150, states="NH NJ"), _age=0),
                            dict(_row("fd", 250), _age=0)])
    out = welcome.for_you(priced, state="NH")
    dk = next((p for p in out if p.book == "dk"), None)
    fd = next((p for p in out if p.book == "fd"), None)
    assert dk is not None and not dk.ineligible
    assert fd is not None and "not licensed in NH" in fd.ineligible


def test_every_shipped_row_has_a_source_a_read_date_and_states():
    rows = _shipped()
    assert rows, "the shipped feed is empty"
    for r in rows:
        where = f"{r['book']} {r['headline']!r}"
        assert (r.get("source") or "").startswith("https://"), f"{where}: no source"
        assert _is_date(r.get("read")), f"{where}: no read date"
        assert (r.get("states") or "").split(), f"{where}: no states"


def test_every_shipped_book_is_a_catalog_venue():
    from overlay_engine.catalog import VENUES
    missing = sorted({r["book"] for r in _shipped()} - set(VENUES))
    assert not missing, f"not catalog venues: {missing}"


def test_every_shipped_state_is_one_where_the_venue_operates():
    """The offer feed and the jurisdiction table are read on different days
    from different sources. This is where they are made to agree."""
    from overlay_engine.catalog import VENUES
    wrong = []
    for r in _shipped():
        v = VENUES.get(r["book"])
        outside = [s for s in (r.get("states") or "").split()
                   if v is None or not v.available_in(s)]
        if outside:
            wrong.append(f"{r['book']} {r['headline']!r}: {' '.join(outside)}")
    assert not wrong, wrong


def test_the_cli_shows_one_offer_per_book_and_only_your_states():
    done = subprocess.run([sys.executable, str(ROOT / "backend" / "cli.py"),
                           "welcome", "--state", "IN", "--json"],
                          capture_output=True, text=True, timeout=120)
    assert done.returncode == 0, done.stderr[:400]
    data = json.loads(done.stdout)
    assert data["state"] == "IN"
    live = [o for o in data["offers"] if not o["ineligible"] and not o["stale"]]
    assert live, "no live offer for Indiana"
    assert all("IN" in o["states"] for o in live)
    assert len({o["book"] for o in live}) == len(live), "a book counted twice"
