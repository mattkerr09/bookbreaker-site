"""updater.json is what every installed copy reads when someone presses Check
for updates. A wrong one does not crash anything: it either installs the wrong
build, or is refused in silence, and the person is left on the old build
believing they are current. So the writer refuses instead of writing.

The fixture is a tiny fake Bookbreaker.app, signed by the real `tauri signer`
with a throwaway key whose private half was deleted after signing; only its
public half is committed. Its signature was also checked with the independent
`minisign` tool when it was made, so the verifier below is proved against
signatures it did not produce.
"""

from __future__ import annotations

import datetime as dt
import importlib.util
import io
import json
import plistlib
import re
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "scripts" / "updater_manifest.py"
FIXTURES = ROOT / "tests" / "fixtures" / "updater"
FIXTURE_TGZ = FIXTURES / "Bookbreaker-0.0.1.app.tar.gz"
FIXTURE_PUB = (FIXTURES / "fixture.key.pub").read_text().strip()
APP_PUB = json.loads((ROOT / "ui" / "src-tauri" / "tauri.conf.json").read_text()
                     )["plugins"]["updater"]["pubkey"]

_spec = importlib.util.spec_from_file_location("updater_manifest", SCRIPT)
um = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(um)


@pytest.fixture
def dist(tmp_path):
    """A dist/ holding the signed fixture release, and a notes file."""
    d = tmp_path / "dist"
    d.mkdir()
    shutil.copy(FIXTURE_TGZ, d / FIXTURE_TGZ.name)
    shutil.copy(FIXTURE_TGZ.with_name(FIXTURE_TGZ.name + ".sig"),
                d / (FIXTURE_TGZ.name + ".sig"))
    (tmp_path / "notes.txt").write_text("Check for updates, on the version line.\n")
    return d


def _run(*args):
    return subprocess.run([sys.executable, str(SCRIPT), *map(str, args)],
                          capture_output=True, text=True, timeout=60)


def _tarball(path: Path, members: dict[str, bytes]) -> None:
    with tarfile.open(path, "w:gz") as tar:
        for name, data in members.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))


def _plist(version: str) -> bytes:
    return plistlib.dumps({"CFBundleShortVersionString": version})


# ------------------------------------------------------------ what it writes

def test_it_writes_the_manifest_the_updater_reads(dist, tmp_path):
    out = tmp_path / "updater.json"
    got = _run("0.0.1", tmp_path / "notes.txt", "--dist", dist, "--out", out,
               "--pubkey", FIXTURE_PUB)
    assert got.returncode == 0, got.stderr
    data = json.loads(out.read_text())
    assert set(data) == {"version", "notes", "pub_date", "platforms"}
    assert data["version"] == "0.0.1"
    assert re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ", data["pub_date"])
    # Apple silicon only, and named exactly as the plugin looks it up.
    assert list(data["platforms"]) == ["darwin-aarch64"]
    entry = data["platforms"]["darwin-aarch64"]
    assert entry["url"] == "https://bookbreaker.bet/releases/Bookbreaker-0.0.1.app.tar.gz"


def test_the_signature_is_read_from_the_sig_file_never_typed(dist, tmp_path):
    data = um.manifest("0.0.1", tmp_path / "notes.txt", dist, FIXTURE_PUB)
    sig = (dist / (FIXTURE_TGZ.name + ".sig")).read_text().strip()
    assert data["platforms"]["darwin-aarch64"]["signature"] == sig


def test_the_notes_are_the_files_text_not_its_path(dist, tmp_path):
    """Docket shipped "/tmp/notes-1.2.4.md" as the notes of two releases."""
    data = um.manifest("0.0.1", tmp_path / "notes.txt", dist, FIXTURE_PUB)
    assert data["notes"] == "Check for updates, on the version line."
    assert str(tmp_path) not in data["notes"]


def test_pub_date_is_utc(dist, tmp_path):
    later = dt.datetime(2026, 10, 7, 18, 30, 5, 123, tzinfo=dt.timezone(dt.timedelta(hours=-4)))
    data = um.manifest("0.0.1", tmp_path / "notes.txt", dist, FIXTURE_PUB, now=later)
    assert data["pub_date"] == "2026-10-07T22:30:05Z"


# ------------------------------------------------------------ what it refuses

def test_a_download_with_one_byte_changed_is_refused(dist, tmp_path):
    """The control a verifier needs: it has to be seen to fail."""
    tgz = dist / FIXTURE_TGZ.name
    raw = bytearray(tgz.read_bytes())
    raw[-12] ^= 0x01
    tgz.write_bytes(bytes(raw))
    out = tmp_path / "updater.json"
    got = _run("0.0.1", tmp_path / "notes.txt", "--dist", dist, "--out", out,
               "--pubkey", FIXTURE_PUB)
    assert got.returncode == 1
    assert not out.exists(), "a refused manifest must not be written"
    # Either the archive no longer opens or the signature no longer matches;
    # both are refusals, and neither may write a manifest.
    assert got.stderr.startswith("Not written:")


def test_a_download_signed_by_another_key_is_refused(dist, tmp_path):
    """Signed by the fixture key, checked against the app's real key: every
    installed copy would refuse it, so the manifest is not written."""
    with pytest.raises(um.Refused, match="not the app's key"):
        um.manifest("0.0.1", tmp_path / "notes.txt", dist, APP_PUB)


def test_the_verifier_refuses_a_signature_over_other_bytes():
    sig = FIXTURE_TGZ.with_name(FIXTURE_TGZ.name + ".sig").read_text()
    um.verify(FIXTURE_TGZ.read_bytes(), sig, FIXTURE_PUB)          # the control passes
    with pytest.raises(um.Refused, match="does not match"):
        um.verify(FIXTURE_TGZ.read_bytes() + b"\0", sig, FIXTURE_PUB)


def test_an_empty_sig_file_is_refused(dist, tmp_path):
    (dist / (FIXTURE_TGZ.name + ".sig")).write_text("\n")
    with pytest.raises(um.Refused, match="empty"):
        um.manifest("0.0.1", tmp_path / "notes.txt", dist, FIXTURE_PUB)


def test_a_missing_tarball_is_refused(tmp_path):
    (tmp_path / "notes.txt").write_text("notes")
    with pytest.raises(um.Refused, match="missing"):
        um.manifest("0.0.2", tmp_path / "notes.txt", tmp_path, FIXTURE_PUB)


def test_missing_or_empty_notes_are_refused(dist, tmp_path):
    with pytest.raises(um.Refused, match="no notes file"):
        um.manifest("0.0.1", tmp_path / "nope.md", dist, FIXTURE_PUB)
    (tmp_path / "blank.md").write_text("  \n")
    with pytest.raises(um.Refused, match="empty"):
        um.manifest("0.0.1", tmp_path / "blank.md", dist, FIXTURE_PUB)


def test_a_version_that_is_not_the_one_inside_the_tarball_is_refused(tmp_path):
    """0.1.8 offered for a tarball that is 0.1.7 installs 0.1.7, which is then
    offered 0.1.8 again, forever."""
    (tmp_path / "notes.txt").write_text("notes")
    _tarball(tmp_path / "Bookbreaker-0.0.2.app.tar.gz", {
        "Bookbreaker.app/Contents/Info.plist": _plist("0.0.1"),
        "Bookbreaker.app/Contents/Resources/engine/overlay-engine": b"x",
    })
    (tmp_path / "Bookbreaker-0.0.2.app.tar.gz.sig").write_text("unused")
    with pytest.raises(um.Refused, match="holds version 0.0.1, not 0.0.2"):
        um.manifest("0.0.2", tmp_path / "notes.txt", tmp_path, FIXTURE_PUB)


def test_a_tarball_without_the_engine_is_refused(tmp_path):
    (tmp_path / "notes.txt").write_text("notes")
    _tarball(tmp_path / "Bookbreaker-0.0.1.app.tar.gz", {
        "Bookbreaker.app/Contents/Info.plist": _plist("0.0.1"),
    })
    (tmp_path / "Bookbreaker-0.0.1.app.tar.gz.sig").write_text("unused")
    with pytest.raises(um.Refused, match="no engine"):
        um.manifest("0.0.1", tmp_path / "notes.txt", tmp_path, FIXTURE_PUB)


def test_a_tarball_without_the_app_at_its_top_level_is_refused(tmp_path):
    """The updater drops the first path component when it unpacks, so
    `dist/Bookbreaker.app/...` would install into the wrong place."""
    (tmp_path / "notes.txt").write_text("notes")
    _tarball(tmp_path / "Bookbreaker-0.0.1.app.tar.gz", {
        "dist/Bookbreaker.app/Contents/Info.plist": _plist("0.0.1"),
    })
    (tmp_path / "Bookbreaker-0.0.1.app.tar.gz.sig").write_text("unused")
    with pytest.raises(um.Refused, match="top level"):
        um.manifest("0.0.1", tmp_path / "notes.txt", tmp_path, FIXTURE_PUB)


def test_a_version_that_is_not_semver_is_refused(dist, tmp_path):
    with pytest.raises(um.Refused, match="not a version"):
        um.manifest("v0.0.1", tmp_path / "notes.txt", dist, FIXTURE_PUB)


# ------------------------------------------------------------ the app's key

def test_the_apps_public_key_is_a_minisign_ed25519_key():
    """The key compiled into every installed copy. A malformed one would make
    every update fail to verify, from the first release that carries it."""
    key_id, key = um.public_key(APP_PUB)
    assert len(key_id) == 8 and len(key) == 32


def test_the_manifest_defaults_to_the_apps_own_key(dist, tmp_path):
    """Without --pubkey it verifies against tauri.conf.json, which is what
    makes a fixture signed by another key fail here."""
    got = _run("0.0.1", tmp_path / "notes.txt", "--dist", dist,
               "--out", tmp_path / "updater.json")
    assert got.returncode == 1
    assert "not the app's key" in got.stderr
