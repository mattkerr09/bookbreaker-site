#!/usr/bin/env python3
"""Write updater.json, the file Check for updates reads, from a built release.

    python3 scripts/updater_manifest.py VERSION NOTES_FILE

Reads dist/Bookbreaker-VERSION.app.tar.gz and its .sig (made by
`scripts/build_app.sh --ship`, step 7) and writes dist/updater.json:

    {"version", "notes", "pub_date",
     "platforms": {"darwin-aarch64": {"signature", "url"}}}

with the download at https://bookbreaker.bet/releases/Bookbreaker-VERSION.app.tar.gz.
It publishes nothing. The site repo copies the tarball into releases/ and the
manifest to its root, and its own gates decide when they go live.

Nothing in the manifest is typed by hand, and it refuses rather than writes
when the release would not install:

* The signature is read from the .sig file and VERIFIED against the public key
  compiled into the app (tauri.conf.json, plugins.updater.pubkey). A signature
  made with another key, or over other bytes, does not warn anybody: every
  installed copy silently refuses the update and sits on the old build
  believing it is current. That is the worst thing this file can do, so it is
  checked here, where it is cheapest.
* The version in the manifest must be the version inside the tarball
  (Contents/Info.plist). A manifest offering 0.1.8 for a tarball that is 0.1.7
  installs 0.1.7, which then offers 0.1.8 again, forever.
* The tarball must hold Bookbreaker.app at its top level (the updater drops
  the first path component when it unpacks) and the engine inside it. An app
  without its engine opens and does nothing.
* The notes are the file's text, and the file must exist and say something.
  Docket shipped `/tmp/notes-1.2.4.md` as the release notes of two releases,
  because a path was stored where its contents should have been.

The signature check is plain Python (RFC 8032 Ed25519 over minisign's
format) so it needs nothing installed; tests/test_updater_manifest.py proves
it against signatures made by the real `tauri signer`, and proves it refuses.

Exit 0 when written, 1 when refused (one sentence on stderr), 2 on bad usage.
"""

from __future__ import annotations

import argparse
import base64
import datetime as _dt
import hashlib
import json
import plistlib
import re
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONF = ROOT / "ui" / "src-tauri" / "tauri.conf.json"
SITE = "https://bookbreaker.bet"
APP = "Bookbreaker.app"
ENGINE = f"{APP}/Contents/Resources/engine/overlay-engine"
PLIST = f"{APP}/Contents/Info.plist"
#: The one platform published. A manifest that also claimed darwin-x86_64
#: would offer an Apple silicon build to Intel Macs, which fails after the
#: download rather than before it.
PLATFORM = "darwin-aarch64"


class Refused(Exception):
    """A release that would not install. The message is one sentence."""


# ------------------------------------------------------------ Ed25519
# RFC 8032 section 6, verification only. Slow by the standards of a crypto
# library and fast enough for one signature: a few milliseconds.

_P = 2**255 - 19
_L = 2**252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_SQRT_M1 = pow(2, (_P - 1) // 4, _P)


def _add(a, b):
    A = (a[1] - a[0]) * (b[1] - b[0]) % _P
    B = (a[1] + a[0]) * (b[1] + b[0]) % _P
    C = 2 * a[3] * b[3] * _D % _P
    D = 2 * a[2] * b[2] % _P
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F, G * H, F * G, E * H)


def _mul(s, point):
    out = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            out = _add(out, point)
        point = _add(point, point)
        s >>= 1
    return out


def _equal(a, b):
    return ((a[0] * b[2] - b[0] * a[2]) % _P == 0
            and (a[1] * b[2] - b[1] * a[2]) % _P == 0)


def _recover_x(y, sign):
    if y >= _P:
        return None
    x2 = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P)
    if x2 % _P == 0:
        return None if sign else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _SQRT_M1 % _P
    if (x * x - x2) % _P != 0:
        return None
    if (x & 1) != sign:
        x = _P - x
    return x


def _decompress(raw: bytes):
    if len(raw) != 32:
        return None
    y = int.from_bytes(raw, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % _P)


_GY = 4 * pow(5, _P - 2, _P) % _P
_G = _decompress(_GY.to_bytes(32, "little"))


def ed25519_verify(public: bytes, message: bytes, signature: bytes) -> bool:
    if len(public) != 32 or len(signature) != 64:
        return False
    A = _decompress(public)
    R = _decompress(signature[:32])
    if A is None or R is None:
        return False
    s = int.from_bytes(signature[32:], "little")
    if s >= _L:
        return False
    h = int.from_bytes(hashlib.sha512(signature[:32] + public + message).digest(),
                       "little") % _L
    return _equal(_mul(s, _G), _add(R, _mul(h, A)))


# ------------------------------------------------------------ minisign


def _b64(text: str, what: str) -> bytes:
    try:
        return base64.b64decode(text.strip(), validate=True)
    except (ValueError, base64.binascii.Error) as exc:
        raise Refused(f"the {what} is not valid base64 ({exc}).") from None


def public_key(tauri_pubkey: str) -> tuple[bytes, bytes]:
    """(key id, 32-byte key) from the string Tauri keeps in its config: the
    base64 of a minisign .pub file."""
    lines = _b64(tauri_pubkey, "public key").decode("utf-8", "replace").splitlines()
    if len(lines) < 2 or not lines[0].startswith("untrusted comment:"):
        raise Refused("the public key is not a minisign public key.")
    raw = _b64(lines[1], "public key")
    if len(raw) != 42 or raw[:2] != b"Ed":
        raise Refused("the public key is not an Ed25519 minisign key.")
    return raw[2:10], raw[10:]


def verify(data: bytes, tauri_signature: str, tauri_pubkey: str) -> None:
    """Raise Refused unless the signature is the key's, over these bytes.

    The same two checks the updater makes before it installs: the signature
    over the file (prehashed with BLAKE2b-512 when the algorithm is "ED"), and
    the global signature over the signature and its trusted comment."""
    key_id, key = public_key(tauri_pubkey)
    lines = _b64(tauri_signature, "signature").decode("utf-8", "replace").splitlines()
    if len(lines) < 4 or not lines[2].startswith("trusted comment: "):
        raise Refused("the .sig file is not a minisign signature.")
    raw = _b64(lines[1], "signature")
    if len(raw) != 74 or raw[:2] not in (b"Ed", b"ED"):
        raise Refused("the .sig file is not an Ed25519 minisign signature.")
    if raw[2:10] != key_id:
        raise Refused(
            f"the download was signed by key {raw[2:10][::-1].hex().upper()}, not the app's "
            f"key {key_id[::-1].hex().upper()}, so every installed copy would refuse it.")
    signed = hashlib.blake2b(data, digest_size=64).digest() if raw[:2] == b"ED" else data
    if not ed25519_verify(key, signed, raw[10:]):
        raise Refused("the signature does not match the download's bytes, so every "
                      "installed copy would refuse it.")
    trusted = lines[2][len("trusted comment: "):].encode()
    if not ed25519_verify(key, raw[10:] + trusted, _b64(lines[3], "signature")):
        raise Refused("the signature's trusted comment does not verify, so every "
                      "installed copy would refuse it.")


# ------------------------------------------------------------ the tarball


def inspect(tarball: Path, version: str) -> None:
    """Raise Refused unless the tarball is an app the updater can install."""
    try:
        with tarfile.open(tarball, "r:gz") as tar:
            names = tar.getnames()
            stray = [n for n in names if n.rstrip("/") != APP and not n.startswith(APP + "/")]
            if not names or stray:
                raise Refused(f"{tarball.name} must hold {APP} at its top level "
                              f"(found {(stray or ['nothing'])[0]}).")
            if ENGINE not in names:
                raise Refused(f"{tarball.name} has no engine at {ENGINE}, so the "
                              f"app it installs would open and do nothing.")
            member = tar.extractfile(PLIST) if PLIST in names else None
            if member is None:
                raise Refused(f"{tarball.name} has no {PLIST}.")
            inside = plistlib.load(member).get("CFBundleShortVersionString")
    except (tarfile.TarError, OSError, plistlib.InvalidFileException) as exc:
        raise Refused(f"{tarball.name} could not be read ({exc}).") from None
    if inside != version:
        raise Refused(f"{tarball.name} holds version {inside}, not {version}, so "
                      f"installed copies would be offered it again forever.")


def notes_text(path: Path) -> str:
    if not path.is_file():
        raise Refused(f"there is no notes file at {path}.")
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise Refused(f"{path} is empty; a release needs notes that say what changed.")
    return text


def manifest(version: str, notes_file: Path, dist: Path, pubkey: str,
             now: _dt.datetime | None = None) -> dict:
    if not re.fullmatch(r"\d+\.\d+\.\d+", version):
        raise Refused(f"{version!r} is not a version like 0.1.7.")
    notes = notes_text(notes_file)
    tarball = dist / f"Bookbreaker-{version}.app.tar.gz"
    sig = tarball.with_name(tarball.name + ".sig")
    for path in (tarball, sig):
        if not path.is_file():
            raise Refused(f"{path} is missing; build the release with "
                          f"scripts/build_app.sh --ship first.")
    inspect(tarball, version)
    signature = sig.read_text(encoding="utf-8").strip()
    if not signature:
        raise Refused(f"{sig.name} is empty; a manifest without a signature rejects every update.")
    verify(tarball.read_bytes(), signature, pubkey)
    stamp = (now or _dt.datetime.now(_dt.timezone.utc)).astimezone(_dt.timezone.utc)
    return {
        "version": version,
        "notes": notes,
        "pub_date": stamp.replace(microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "platforms": {
            PLATFORM: {
                "signature": signature,
                "url": f"{SITE}/releases/{tarball.name}",
            }
        },
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Write updater.json for Check for updates from a built release.")
    ap.add_argument("version", help="the version being released, e.g. 0.1.7")
    ap.add_argument("notes_file", type=Path,
                    help="a file whose text is shown in the window as the release notes")
    ap.add_argument("--dist", type=Path, default=ROOT / "dist",
                    help="where build_app.sh --ship put the tarball (default: dist/)")
    ap.add_argument("--out", type=Path, default=None,
                    help="where to write the manifest (default: DIST/updater.json)")
    ap.add_argument("--pubkey", default=None,
                    help="the public key to verify against (default: the one in tauri.conf.json)")
    args = ap.parse_args(argv)

    pubkey = args.pubkey
    if pubkey is None:
        pubkey = json.loads(CONF.read_text())["plugins"]["updater"]["pubkey"]
    try:
        data = manifest(args.version, args.notes_file, args.dist, pubkey)
    except Refused as exc:
        print(f"Not written: {exc}", file=sys.stderr)
        return 1

    out = args.out or args.dist / "updater.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    url = data["platforms"][PLATFORM]["url"]
    print(f"wrote {out}")
    print(f"  version   {data['version']}  ({data['pub_date']})")
    print(f"  download  {url}")
    print(f"  signature verified against the app's public key")
    print(f"  next, in the site repo: copy {Path(url).name} into releases/ and "
          f"{out.name} to the site root, then run its gates")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
