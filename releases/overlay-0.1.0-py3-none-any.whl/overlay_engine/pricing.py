"""The one place a price is formed, with everything learned already loaded.

Until now the calibration loop was decorative in the live path. `calibrate`
wrote weights, `ledger` reported them, and `find_edges` went on using the
shipped defaults — because threading four learned objects through every call
site was left to the caller, and no caller did it. The measurement was right
and the price ignored it.

So there is one entry point. `PricingContext.from_ledger` loads the devig
weights, the book weights, the fill model and the latency model for a scope,
and `price_market` threads all four through. A caller cannot price a market
half-calibrated, because there is no argument they can forget.

Two things this refuses to do quietly:

**It will not present a stale calibration as current.** Weights fitted on last
season's markets are still a measurement, but an old one, and betting markets
move between seasons. They stay in use — reverting to defaults silently would
be a behaviour change nobody could see — and every surface that shows a price
says how old they are.

**It will not hide that it is uncalibrated.** A fresh install prices on stated
priors, and `describe()` says so in the same breath as the number.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .calibrate import apply_book_weights, book_weights_for, weights_for
from .ev import find_edges
from .fair import fair_value
from .models import Book, Edge, Market
from .staleness import FillModel, LatencyModel

# Beyond this, weights are reported stale. Roughly one off-season: a
# calibration fitted before a rules change, a new pace of play, or a different
# set of books is a measurement of a market that no longer exists.
MAX_WEIGHT_AGE = 90 * 86400.0


@dataclass(frozen=True)
class PricingContext:
    """Everything learned that a price depends on, resolved once.

    Immutable and loaded per scope, so the weights that priced a market are a
    single object that can be recorded alongside the bet — which is what makes
    a bad calibration diagnosable months later instead of merely suspected.
    """

    books: dict[str, Book]
    method_weights: dict[str, float] | None = None
    book_weights: dict[str, float] | None = None
    method_age: float | None = None
    book_age: float | None = None
    fill: FillModel = field(default_factory=FillModel)
    latency: LatencyModel = field(default_factory=LatencyModel)
    sport: str | None = None
    market_type: str | None = None

    @classmethod
    def from_ledger(
        cls,
        ledger,
        books: dict[str, Book],
        sport: str | None = None,
        market_type: str | None = None,
    ) -> "PricingContext":
        """Load every learned parameter for one scope.

        Book weights come back through `apply_book_weights`, never raw.
        Calibration returns weights summing to 1 across covered books while
        tier defaults run to 1.0 for a sharp book; handing `fair_value` the
        mixture would let one uncovered sharp book swamp every measured one.
        """
        methods, method_age = weights_for(ledger, sport, market_type)
        raw_books, book_age = book_weights_for(ledger, sport, market_type)

        return cls(
            books=books,
            method_weights=methods,
            book_weights=apply_book_weights(raw_books, books) if raw_books else None,
            method_age=method_age,
            book_age=book_age,
            fill=ledger.fill_model(),
            latency=ledger.latency_model(),
            sport=sport,
            market_type=market_type,
        )

    @classmethod
    def uncalibrated(cls, books: dict[str, Book]) -> "PricingContext":
        """A context on shipped priors alone, for callers with no ledger."""
        return cls(books=books)

    @property
    def calibrated(self) -> bool:
        return self.method_weights is not None or self.book_weights is not None

    @property
    def age(self) -> float | None:
        """Age of the *oldest* calibration in play.

        The oldest, not the newest: a price built from fresh devig weights and
        year-old book weights is only as current as the year-old half, and
        reporting the flattering number would be the whole point of the field
        inverted.
        """
        ages = [a for a in (self.method_age, self.book_age) if a is not None]
        return max(ages) if ages else None

    @property
    def stale(self) -> bool:
        age = self.age
        return age is not None and age > MAX_WEIGHT_AGE

    def describe(self) -> str:
        """One line, always shown next to a price."""
        if not self.calibrated:
            return "uncalibrated — devig and book weights are shipped priors"

        parts = []
        if self.method_weights:
            best = max(self.method_weights, key=self.method_weights.get)
            parts.append(f"devig led by {best}")
        if self.book_weights and self.book_age is not None:
            parts.append("book weights measured")

        age = self.age
        when = f"{age / 86400:.0f}d old" if age is not None else "age unknown"
        warning = " — STALE, recalibrate" if self.stale else ""
        return f"{', '.join(parts)}; {when}{warning}"

    def as_record(self) -> dict:
        """The weights that priced a market, in a form the ledger can store.

        Recorded onto the bet so a price can be traced back to the calibration
        that produced it. Without this a bad calibration is undiagnosable after
        the fact — the weights have since been overwritten, and nothing says
        which ones were in force when the bet looked good.
        """
        return {
            "method_weights": self.method_weights,
            "book_weights": self.book_weights,
            "method_age_days": None if self.method_age is None
            else round(self.method_age / 86400, 2),
            "book_age_days": None if self.book_age is None
            else round(self.book_age / 86400, 2),
            "scope": f"{self.sport or 'any'}/{self.market_type or 'any'}",
        }


def price_market(
    market: Market,
    ctx: PricingContext,
    now: float,
    min_ev: float = 0.0,
    require_robust: bool = True,
    require_anchor: bool = True,
) -> list[Edge]:
    """Every +EV offer in a market, priced with everything that has been learned.

    The single call site. `find_edges` still takes its parts separately —
    plumbing that other code and the tests rely on — but nothing outside this
    module should assemble them by hand, because assembling three of the four
    is indistinguishable from assembling all of them until someone reads a
    number that was quietly wrong.
    """
    return find_edges(
        market,
        ctx.books,
        now=now,
        min_ev=min_ev,
        require_robust=require_robust,
        require_anchor=require_anchor,
        fill_model=ctx.fill,
        method_weights=ctx.method_weights,
        latency_model=ctx.latency,
    )


def fair_for(market: Market, ctx: PricingContext) -> dict:
    """Fair values for a market under the loaded calibration."""
    return fair_value(
        market,
        ctx.books,
        method_weights=ctx.method_weights,
        book_weights=ctx.book_weights,
    )


def context_for(ledger, books: dict[str, Book], market: Market) -> PricingContext:
    """Load the context matching a market's own sport and type.

    Scope matters: the right devig method for an NBA total is not the right one
    for a tennis outright, which is the reason calibration is scoped at all.
    Pricing every market from the global scope would throw that away at the
    last step.
    """
    return PricingContext.from_ledger(
        ledger, books, sport=market.sport, market_type=market.market_type
    )
