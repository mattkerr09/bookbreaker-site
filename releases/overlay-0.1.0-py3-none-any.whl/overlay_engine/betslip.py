"""Reading a bet out of pasted betslip text.

CSV import covers the books with decent exports. This covers the rest: select
the slip in the app, paste it in, and get a bet.

The obvious way to build this is to guess. Grab the first number that looks
like odds, the first that looks like money, assume the rest, and write a row.
That produces a tracker full of bets nobody checked, and a P&L built on them is
worse than no P&L — it looks exactly as authoritative as a real one.

So this parser does the opposite of guessing:

**It reports what it understood, field by field, before anything is written.**
Every field carries where it came from — the literal text it was read from —
so a wrong reading is visible rather than buried in a database.

**It refuses without the essentials.** No odds or no stake means no bet. A slip
missing its price is not a bet with an unknown price; it is text that failed to
parse, and saying so is the only useful response.

**Anything it infers is labelled inferred.** A missing book name becomes a
`needs` entry, not a plausible default. The caller decides; the parser does not
quietly decide for them.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .odds import OddsError, american_to_decimal, decimal_to_prob

# Words books use around the amount risked, and around the amount returned.
# Kept apart because confusing them inflates every winning bet by its stake —
# the same trap the CSV importer has, arriving by a different route.
STAKE_WORDS = ("wager", "risk", "stake", "bet amount", "bet", "amount")
RETURN_WORDS = ("to win", "to return", "payout", "returns", "total return",
                "win", "collect")

# `win` is deliberately absent: on most slips it is the payout label
# ("To Win $45.45"), and reading it as a result turns every *unsettled* bet
# into a fabricated winner. `won`, `winner` and `cashed` are unambiguous.
RESULT_WORDS = {
    "won": "won", "winner": "won", "cashed": "won",
    "lost": "lost", "loss": "lost", "lose": "lost",
    "push": "push", "tie": "push", "void": "void", "cancelled": "void",
    "canceled": "void", "refunded": "void", "open": None, "pending": None,
}

MARKET_WORDS = {
    "moneyline": "h2h", "money line": "h2h", "ml": "h2h", "winner": "h2h",
    "spread": "spreads", "handicap": "spreads", "run line": "spreads",
    "puck line": "spreads", "point spread": "spreads",
    "total": "totals", "over/under": "totals", "o/u": "totals",
    # `Over 45.5` names a total as plainly as `total` does. Safe alongside
    # `player`, which is longer and therefore matched first, so a prop reading
    # `Player Points - Over 27.5` stays a prop.
    "over": "totals", "under": "totals",
    "parlay": "parlay", "teaser": "teaser", "prop": "player_prop",
    "player": "player_prop", "future": "futures", "outright": "futures",
}

_AMERICAN = re.compile(r"(?<![\d.])([+−-]\s?\d{3,5})(?![\d.])")
_DECIMAL = re.compile(r"(?<![\d.])(\d\.\d{2,3})(?![\d.])")
_HANDICAP = re.compile(r"(?<![\d.$])([+\u2212-]\d{1,2}(?:\.5)?)(?![\d.])")
_MONEY = re.compile(r"[$£€]\s?([\d,]+(?:\.\d{1,2})?)|(?<![\d.])([\d,]+\.\d{2})(?![\d.])")


@dataclass
class Field:
    """One parsed value, and the text it was read from."""

    value: object
    source: str

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"{self.value!r} <- {self.source!r}"


@dataclass
class Parsed:
    """What the parser understood, and what it did not.

    `usable` is the only field that decides anything. Everything else exists so
    a human can check the reading before it becomes a row in their record.
    """

    fields: dict[str, Field] = field(default_factory=dict)
    needs: list[str] = field(default_factory=list)
    text: str = ""

    def get(self, name: str, default=None):
        found = self.fields.get(name)
        return found.value if found else default

    @property
    def usable(self) -> bool:
        """Whether there is enough here to be a bet at all."""
        return not self.needs

    def describe(self) -> str:
        lines = []
        for name in ("book", "market_type", "outcome", "decimal_odds", "stake",
                     "result", "profit", "placed_at"):
            got = self.fields.get(name)
            if got is None:
                continue
            shown = got.value
            if name == "decimal_odds":
                shown = f"{shown:.3f}"
            elif isinstance(shown, float):
                shown = f"{shown:,.2f}"
            lines.append(f"  {name:<14} {shown}   <- {got.source!r}")
        for missing in self.needs:
            lines.append(f"  {missing:<14} NOT FOUND")
        return "\n".join(lines)


def _books() -> dict[str, str]:
    from .catalog import VENUES

    return {v.name.lower(): v.key for v in VENUES.values()}


def _find_odds(text: str) -> Field | None:
    """American first, decimal second.

    American is tried first because a slip containing both is showing the
    American price to the bettor and the decimal somewhere incidental. A bare
    `2.50` in a slip is far more often a stake or a line than a price.
    """
    match = _AMERICAN.search(text)
    if match:
        raw = match.group(1).replace(" ", "").replace("−", "-")
        try:
            return Field(american_to_decimal(float(raw)), match.group(1).strip())
        except OddsError:
            pass
    for match in _DECIMAL.finditer(text):
        value = float(match.group(1))
        if 1.01 <= value <= 100.0:
            return Field(value, match.group(1))
    return None


def _money_near(text: str, words: tuple[str, ...]) -> Field | None:
    """The first amount following one of these words on the same line."""
    for line in text.splitlines():
        low = line.lower()
        for word in words:
            at = low.find(word)
            if at < 0:
                continue
            tail = line[at + len(word):]
            money = _MONEY.search(tail)
            if money:
                raw = money.group(1) or money.group(2)
                return Field(float(raw.replace(",", "")), money.group(0).strip())
    return None


def _find_result(text: str) -> Field | None:
    """The settled result, or nothing.

    Nothing is the right answer far more often than it looks. A slip that has
    not settled still shows a payout, and mistaking that for a result writes a
    win that has not happened yet — the single most expensive misreading this
    module can make, because it is invisible once it is a row in the ledger.

    The defence is the table above, not a filter here: every word left in
    RESULT_WORDS is one that only ever appears as a result. Filtering payout
    phrases out afterwards was tried and removed — the break-test gate showed
    it could be deleted without a single test noticing, which is what an
    untested second layer looks like from the outside.
    """
    for line in text.splitlines():
        for word, mapped in RESULT_WORDS.items():
            found = re.search(rf"\b{re.escape(word)}\b", line, re.I)
            if not found:
                continue
            if mapped is None:
                return None  # explicitly open; not a settled bet
            return Field(mapped, found.group(0))
    return None


def _find_market(text: str, odds_source: str | None = None) -> Field | None:
    """A named market first, then the notation.

    Longest phrase first, so `run line` is not read as the bare word `line`.
    """
    low = text.lower()
    for word, mapped in sorted(MARKET_WORDS.items(), key=lambda kv: -len(kv[0])):
        found = re.search(rf"\b{re.escape(word)}\b", low)
        if found:
            return Field(mapped, text[found.start():found.end()])

    # No named market. A handicap attached to a selection is the notation every
    # book uses for a spread, so reading it is reading the slip, not guessing
    # at it — and the source records the token that decided it, so a wrong
    # reading is visible. One or two digits distinguishes a handicap from a
    # price: -3.5 is a line, -110 is a price.
    if odds_source:
        for match in _HANDICAP.finditer(text):
            if match.group(0).strip() not in odds_source:
                return Field("spreads", match.group(0).strip())
    return None


def _find_book(text: str) -> Field | None:
    """Longest catalog name first, so `bet365` is not read as `bet`.

    The source records the text as it appeared in the slip, not the catalog's
    spelling of it. A source that says `draftkings` when the slip said
    `DraftKings` is a small lie, and the point of the source field is that it
    can be checked against the slip by eye.
    """
    low = text.lower()
    for name, key in sorted(_books().items(), key=lambda kv: -len(kv[0])):
        at = low.find(name)
        if at >= 0:
            return Field(key, text[at:at + len(name)])
    return None


def _find_selection(text: str, odds_source: str | None) -> Field | None:
    """The line carrying the price, with the price removed.

    A betslip puts the selection and its price on one line far more often than
    not, which makes this reliable where a general-purpose guess would not be.
    """
    if not odds_source:
        return None
    for line in text.splitlines():
        if odds_source in line:
            cleaned = line.replace(odds_source, "")
            cleaned = re.sub(r"[()\[\]]", " ", cleaned)
            cleaned = re.sub(r"\s+", " ", cleaned).strip(" -–—:")
            if cleaned:
                return Field(cleaned, line.strip())
    return None


def parse(text: str) -> Parsed:
    """Read a pasted betslip. Reports everything; decides nothing."""
    out = Parsed(text=text)
    if not text.strip():
        out.needs = ["decimal_odds", "stake"]
        return out

    odds = _find_odds(text)
    if odds:
        out.fields["decimal_odds"] = odds
    else:
        out.needs.append("decimal_odds")

    stake = _money_near(text, STAKE_WORDS)
    if stake:
        out.fields["stake"] = stake
    else:
        out.needs.append("stake")

    for name, found in (
        ("book", _find_book(text)),
        ("market_type", _find_market(text, odds.source if odds else None)),
        ("result", _find_result(text)),
        ("outcome", _find_selection(text, odds.source if odds else None)),
    ):
        if found:
            out.fields[name] = found

    # Profit, derived rather than read. A slip's "to win" is the profit on a
    # straight bet and the total return on some books; deriving it from stake
    # and price is the reading that cannot be wrong in the expensive direction.
    if odds and stake and out.get("result") in ("won", "lost", "push", "void"):
        result = out.get("result")
        amount = {
            "won": stake.value * (odds.value - 1.0),
            "lost": -stake.value,
            "push": 0.0,
            "void": 0.0,
        }[result]
        out.fields["profit"] = Field(
            round(amount, 2), f"derived from {result} at {odds.source}"
        )

    return out


def implied(parsed: Parsed) -> float | None:
    """Vig-inclusive implied probability of the parsed price."""
    odds = parsed.get("decimal_odds")
    return decimal_to_prob(odds) if odds else None


def to_import(parsed: Parsed, event_id: str, sport: str = "unknown",
              placed_at: float | None = None) -> dict:
    """Turn a parsed slip into `Ledger.import_bet` arguments.

    Refuses unusable input rather than filling gaps. A slip missing its price
    is not a bet with an unknown price — it is text that failed to parse.
    """
    if not parsed.usable:
        raise ValueError(
            f"cannot import: {', '.join(parsed.needs)} not found in the slip"
        )
    import time

    return {
        "event_id": event_id,
        "sport": sport,
        "market_type": parsed.get("market_type", "unknown"),
        "outcome": parsed.get("outcome", "unknown"),
        "book": parsed.get("book", "unknown"),
        "decimal_odds": parsed.get("decimal_odds"),
        "stake": parsed.get("stake"),
        "placed_at": time.time() if placed_at is None else placed_at,
        "result": parsed.get("result"),
        "profit": parsed.get("profit"),
    }
