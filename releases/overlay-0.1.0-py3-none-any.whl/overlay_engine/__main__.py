"""`python3 -m overlay_engine` — the same CLI as the `overlay` console script.

A console script is a generated shim on PATH; if it is missing, shadowed, or
the wheel was installed somewhere PATH does not reach, this is the way in that
cannot go missing, because it is the package itself.
"""

from __future__ import annotations

from overlay_engine.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
