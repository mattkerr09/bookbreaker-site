"""Arbitrage detection, and staking that a risk desk cannot read.

Finding an arb is one line: if the best prices across books imply less than
1.0 in total, the market pays more than certainty costs.

Staking it correctly is where every competing tool stops one step early. They
solve the continuous optimum — $473.82 and $526.18 — and hand it over. That
number is the single most-cited fingerprint risk teams use to identify
arbitrage: a recreational bettor stakes 50, 100, 250; nobody types $473.82.
Telling a user to "round it yourself" moves the hard part onto them, and
rounding an arb naively breaks it, because the two legs are not symmetric —
rounding the wrong one turns a 2.1% lock into a one-sided position.

So the solver here optimises over *round* stakes directly: enumerate the
plausible round pairs, keep the ones still profitable on every outcome, and
return the best. The output is a bet a human would plausibly place that is
still an arbitrage. That is the product.

Nothing in this module touches identity, KYC, device or location. Account
longevity here means bet *shape* — size, timing, market mix — which is the
bettor's own choice about how to place their own bets. Anything that would
misrepresent who is betting is out of scope and stays out.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from .models import Book, Market, Quote

# Round-number ladders a recreational bettor actually uses. Below $200 people
# bet in fives; above it, tens and twenties; above $1000, fifties. Enumerating
# these instead of "round to 2 significant figures" matters because the
# ladders are what the shape has to imitate.
_LADDERS = (
    (0.0, 5.0),
    (200.0, 10.0),
    (500.0, 25.0),
    (1000.0, 50.0),
    (5000.0, 100.0),
)


def _step_for(amount: float) -> float:
    step = _LADDERS[0][1]
    for threshold, s in _LADDERS:
        if amount >= threshold:
            step = s
    return step


def arb_margin(decimals: list[float]) -> float:
    """Guaranteed return per unit of total stake, or negative if no arb.

    With total implied probability S = sum(1/d_i), staking in proportion to
    1/d_i returns exactly 1/S on every outcome, so the margin is 1/S - 1.

    This is *not* `1 - S`, which is what a surprising number of calculators
    report. At S = 0.95 the true return is 5.26%, not 5%. The error is small
    and it is always in the direction of understating profit, which is the
    less dangerous direction — but a number that is wrong by a known amount
    should be right instead.
    """
    total = sum(1.0 / d for d in decimals)
    if total <= 0:
        raise ValueError("decimal odds must be positive")
    return 1.0 / total - 1.0


@dataclass(frozen=True)
class Leg:
    """One side of an arbitrage: where, at what price, for how much."""

    book: str
    outcome: str
    decimal: float
    stake: float

    @property
    def payout(self) -> float:
        return self.stake * self.decimal


@dataclass(frozen=True)
class ArbPlan:
    """A staked arbitrage, reported by its worst outcome rather than its best.

    `profit` is the *minimum* profit across every way the event can resolve.
    Once stakes are rounded the legs pay differently, and quoting the average
    or the best leg would describe a position the bettor does not hold. The
    guaranteed number is the small one.
    """

    legs: tuple[Leg, ...]
    total_stake: float
    profit: float
    ideal_profit: float
    rounded: bool

    @property
    def roi(self) -> float:
        return self.profit / self.total_stake if self.total_stake else 0.0

    @property
    def ideal_roi(self) -> float:
        return self.ideal_profit / self.total_stake if self.total_stake else 0.0

    @property
    def rounding_cost(self) -> float:
        """Profit given up to make the stakes look human.

        Usually a few cents on a hundred dollars. Named and reported because
        it is a real cost of the anti-limiting choice, and a tool that hides
        its own trade-offs is not one you can check.
        """
        return self.ideal_profit - self.profit

    @property
    def guaranteed(self) -> bool:
        return self.profit > 0.0

    def returns(self) -> list[float]:
        """Net profit under each outcome, in leg order."""
        return [leg.payout - self.total_stake for leg in self.legs]


def ideal_stakes(decimals: list[float], total: float) -> list[float]:
    """Continuous stakes equalising the return across outcomes."""
    inv = [1.0 / d for d in decimals]
    s = sum(inv)
    return [total * i / s for i in inv]


def stake_arb(
    decimals: list[float],
    total: float,
    books: list[str] | None = None,
    outcomes: list[str] | None = None,
    round_stakes: bool = True,
    anchor: int = 0,
) -> ArbPlan:
    """Stake an arbitrage, in round numbers, without breaking it.

    Search rather than rounding. The continuous solution is the centre of a
    small neighbourhood of round-stake combinations; we walk a few ladder
    steps either side of each leg, score every combination by its *worst*
    outcome, and keep the best. Straight rounding is one point in that
    neighbourhood and frequently not the best one — with an anchor leg pinned
    to a clean number, nudging the other leg one step often recovers more than
    rounding cost.

    `anchor` is the leg pinned hardest to a round figure. It defaults to the
    first, which by convention is the leg placed at the softest book: that is
    the account whose survival the shape is protecting, and the one whose bet
    should look the most ordinary.
    """
    n = len(decimals)
    if n < 2:
        raise ValueError("an arbitrage needs at least two outcomes")
    if total <= 0:
        raise ValueError("total stake must be positive")

    books = books or [f"book{i}" for i in range(n)]
    outcomes = outcomes or [f"outcome{i}" for i in range(n)]

    ideal = ideal_stakes(decimals, total)
    ideal_profit = min(s * d for s, d in zip(ideal, decimals)) - total

    def build(stakes: list[float], rounded: bool) -> ArbPlan:
        staked = sum(stakes)
        worst = min(s * d for s, d in zip(stakes, decimals)) - staked
        legs = tuple(
            Leg(book=b, outcome=o, decimal=d, stake=s)
            for b, o, d, s in zip(books, outcomes, decimals, stakes)
        )
        return ArbPlan(
            legs=legs,
            total_stake=staked,
            profit=worst,
            ideal_profit=ideal_profit,
            rounded=rounded,
        )

    if not round_stakes:
        return build(ideal, rounded=False)

    # Candidate values per leg: a few ladder steps either side of ideal. Three
    # steps covers the neighbourhood where a better round pair can exist; a
    # wider search only finds combinations whose total drifts far enough from
    # the requested stake to be a different bet.
    candidates: list[list[float]] = []
    for i, want in enumerate(ideal):
        step = _step_for(want)
        base = round(want / step) * step
        span = 1 if i == anchor else 3
        vals = sorted(
            {
                max(step, base + k * step)
                for k in range(-span, span + 1)
            }
        )
        candidates.append(vals)

    best: ArbPlan | None = None
    for combo in _product(candidates):
        plan = build(list(combo), rounded=True)
        if plan.profit <= 0:
            continue
        if best is None or _better(plan, best, total):
            best = plan

    if best is None:
        # No round combination holds the arb. Real on thin margins — a 0.4%
        # arb has less slack than one ladder step. Return the exact stakes and
        # say so, rather than silently shipping a broken lock.
        return build(ideal, rounded=False)
    return best


def _better(a: ArbPlan, b: ArbPlan, target: float) -> bool:
    """Prefer more guaranteed profit; break ties toward the requested size.

    Profit is compared with a cent of tolerance, because two combinations
    differing by fractions of a cent are the same bet and the tie should be
    settled by which one is the size the user asked for.
    """
    if a.profit - b.profit > 0.01:
        return True
    if b.profit - a.profit > 0.01:
        return False
    return abs(a.total_stake - target) < abs(b.total_stake - target)


def _product(lists: list[list[float]]):
    """itertools.product, kept local so the search stays readable."""
    if not lists:
        yield ()
        return
    head, *rest = lists
    for value in head:
        for tail in _product(rest):
            yield (value, *tail)


def find_arbs(
    market: Market,
    books: dict[str, Book],
    now: float,
    min_margin: float = 0.0,
    fill_model=None,
    latency_model=None,
) -> list[dict]:
    """Every two-sided arbitrage in a market, using each book's net price.

    Commission is netted before comparison. On an exchange leg this routinely
    decides the question: a nominal 1.8% arb against a 2%-commission book is
    not an arb, and a screen that reports it costs its user real money on
    every one it surfaces.
    """
    keys = market.outcomes()
    if len(keys) < 2:
        return []

    best: dict[str, Quote] = {}
    net: dict[str, float] = {}
    for key in keys:
        candidates = [q for q in market.quotes if q.outcome.key == key]
        if not candidates:
            return []
        scored = []
        for q in candidates:
            book = books.get(q.book) or Book(key=q.book, name=q.book)
            scored.append((book.net_decimal(q.decimal), q))
        value, quote = max(scored, key=lambda t: t[0])
        best[key] = quote
        net[key] = value

    decimals = [net[k] for k in keys]
    margin = arb_margin(decimals)
    if margin < min_margin:
        return []

    if len({best[k].book for k in keys}) < 2:
        # One book quoting an arb against itself is nearly always a stale or
        # mispulled line rather than a gift, and betting both sides at one
        # book is the loudest possible signal to that book's risk desk.
        return []

    p_fill = 1.0
    ages = []
    for key in keys:
        q = best[key]
        floor = 0.0 if latency_model is None else latency_model.typical(q.book)
        age = q.age(now, latency_floor=floor)
        ages.append(age)
        if fill_model is not None:
            p_fill *= fill_model.p_fill(q.book, market.market_type, age)

    return [
        {
            "event_id": market.event_id,
            "sport": market.sport,
            "market_type": market.market_type,
            "margin": margin,
            "legs": [
                {
                    "book": best[k].book,
                    "outcome": k,
                    "decimal": best[k].decimal,
                    "net_decimal": net[k],
                    "age": best[k].age(
                        now,
                        latency_floor=0.0 if latency_model is None
                        else latency_model.typical(best[k].book),
                    ),
                }
                for k in keys
            ],
            "p_fill": p_fill,
            "realised_margin": margin * p_fill,
            "max_age": max(ages) if ages else 0.0,
        }
    ]


def middle_probability(low: float, high: float, sigma: float) -> float:
    """Rough chance a total or spread lands strictly inside a middle.

    `low` and `high` are the window edges *as offsets from the projected
    result*, so both are usually straddling zero: a 220.5/223.5 middle on a
    projected total of 222 is (-1.5, +1.5). Passing raw line numbers instead
    would ask for the chance of a 220-point deviation and return zero, which
    is why the convention is stated here rather than inferred.

    A normal approximation on the margin of victory. Real distributions are
    lumpy — NFL margins cluster on 3 and 7, so a 2.5/3.5 middle is worth far
    more than a smooth curve says and a 4.5/5.5 middle far less. The lump
    tables belong in a sport module; this is the fallback, and it is labelled
    as one rather than dressed up as a model.
    """
    if high <= low:
        return 0.0
    if sigma <= 0:
        raise ValueError("sigma must be positive")
    z_low = low / (sigma * math.sqrt(2.0))
    z_high = high / (sigma * math.sqrt(2.0))
    return 0.5 * (math.erf(z_high) - math.erf(z_low))
