"""One view of the whole book: what is open, how much of it is really one bet,
and what that means for the next stake.

Four modules already knew a piece of this. `exposure` knows what is open and
what each result pays. `correlation` knows how much those positions co-move.
`kelly` knows what a stake should be. `performance` knows what the record says.
A user holding four commands has to combine them in their head, and the
combination is where the arithmetic is least forgiving.

**The number this module exists for is the effective bet count.**

    n_eff = n / (1 + (n - 1) * rho)

Twelve positions at rho = 0.45 are **2.0 independent bets**, not twelve. That
is the same `1 + (n - 1) * rho` that `kelly.simultaneous_scale` divides by, so

    n_eff = n * scale^2

exactly — no separate derivation, no second parameterisation to drift from the
first. It is worth stating in this form because "twelve bets" and "two bets"
produce very different decisions from the same person, and the second one is
true.

(That figure is 12 / (1 + 11 x 0.45) = 2.02, and 0.45 is what a real ledger
measured rather than a round number picked to make the point.)

**Correlation does not move the floor; it moves how often you reach it.**
`ExposureReport.worst_case` is the sum of per-market worsts, and that is the
true floor whatever the correlation. What rho decides is whether landing near
it is a freak event or a normal Sunday. A book of independent bets almost never
resolves all-worst; a book riding one game script does it routinely, and the
bettor who sized for the first is the one who does not survive the second.

**Bankroll is an argument, never a default.** Nothing here can measure it, and
a portfolio view that invents one would report a utilisation figure that is
pure fiction dressed as a percentage.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .correlation import CorrelationEstimate, from_ledger
from .exposure import ExposureReport, report as exposure_report
from .kelly import MAX_SINGLE, simultaneous_scale

# Above this share of bankroll on the table at once, the flag fires. Not a
# rule about risk appetite — a stated threshold, and it is stated because a
# number that appears without one reads as a recommendation.
UTILISATION_FLAG = 0.25


class PortfolioError(ValueError):
    """A portfolio that cannot be described from what is on hand."""


def effective_bets(n: int, rho: float) -> float:
    """How many independent bets a correlated book is actually holding.

    `n / (1 + (n - 1) * rho)`, which is `n * simultaneous_scale(n, rho) ** 2`.
    Written the second way so it cannot drift from the sizing rule it explains.
    """
    if n <= 0:
        return 0.0
    return n * simultaneous_scale(n, rho) ** 2


@dataclass
class PortfolioView:
    """Everything open, and what the correlation between it means."""

    bankroll: float
    exposure: ExposureReport
    correlation: CorrelationEstimate
    flags: list[str] = field(default_factory=list)

    @property
    def live(self) -> int:
        return self.exposure.positions

    @property
    def at_risk(self) -> float:
        return self.exposure.at_risk

    @property
    def utilisation(self) -> float:
        """Share of bankroll on the table right now."""
        return self.at_risk / self.bankroll if self.bankroll > 0 else 0.0

    @property
    def scale(self) -> float:
        """Shrink factor the current book implies for the next stake."""
        return simultaneous_scale(self.live, self.correlation.rho)

    @property
    def effective(self) -> float:
        return effective_bets(self.live, self.correlation.rho)

    @property
    def max_next_stake(self) -> float:
        """Cap on the next bet: the single-bet cap, shrunk for what is open.

        `MAX_SINGLE` alone is the right cap for a bettor holding nothing. It is
        the wrong cap for one already holding eleven bets on the same game
        script, and the difference is exactly `scale`.
        """
        return self.bankroll * MAX_SINGLE * self.scale

    @property
    def worst_case(self) -> float:
        return self.exposure.worst_case

    @property
    def worst_case_share(self) -> float:
        """The floor as a share of bankroll."""
        if self.bankroll <= 0:
            return 0.0
        return abs(min(0.0, self.worst_case)) / self.bankroll

    def describe(self) -> str:
        lines = [
            f"bankroll        {self.bankroll:,.2f}",
            f"at risk         {self.at_risk:,.2f}"
            f"   ({self.utilisation:.1%} of bankroll)",
            f"open positions  {self.live} across"
            f" {len(self.exposure.markets)} markets",
            "",
            f"correlation     {self.correlation.describe()}",
        ]
        if self.live > 1:
            lines += [
                f"effective bets  {self.effective:.1f}"
                f"   — {self.live} positions behaving like"
                f" {self.effective:.1f} independent ones",
                f"next-stake cap  {self.max_next_stake:,.2f}"
                f"   ({MAX_SINGLE:.0%} of bankroll x {self.scale:.3f})",
            ]
        lines += [
            "",
            f"worst case      {self.worst_case:+,.2f}"
            f"   ({self.worst_case_share:.1%} of bankroll)",
            "                every market resolving the worst way it can."
            " Correlation does not",
            "                move this floor — it decides how often you land"
            " near it.",
        ]
        for flag in self.flags:
            lines.append(f"  ! {flag}")
        return "\n".join(lines)


def _flags(view: PortfolioView) -> list[str]:
    out: list[str] = []
    if not view.correlation.measured:
        out.append(
            "Correlation is a stated prior, not a measurement — every figure "
            "resting on it is provisional.")
    if view.utilisation > UTILISATION_FLAG:
        out.append(
            f"{view.utilisation:.0%} of bankroll is on the table at once, "
            f"above the {UTILISATION_FLAG:.0%} flag.")
    event, share = view.exposure.concentration
    if view.exposure.concentrated:
        out.append(f"{share:.0%} of exposure sits on one event ({event}).")
    if view.live > 1 and view.effective < view.live / 2:
        out.append(
            f"{view.live} positions are behaving like {view.effective:.1f} "
            "independent bets — this book is far less diversified than its "
            "position count suggests.")
    inferred = view.exposure.inferred_markets
    if inferred:
        out.append(
            f"{len(inferred)} market(s) have no recorded quotes, so their "
            "outcome set comes from your own bets and their worst case is "
            "optimistic.")
    return out


def build(ledger, bankroll: float, key: str = "event",
          sport: str | None = None, book: str | None = None) -> PortfolioView:
    """Assemble the portfolio view from a ledger.

    `bankroll` is required and unchecked against anything — nothing in the
    ledger knows it. A zero or negative figure is refused rather than divided
    by, because every ratio here would come back as zero and read as safety.
    """
    if bankroll <= 0:
        raise PortfolioError(
            "bankroll must be positive: every ratio in this view divides by "
            "it, and zero would report a full book as risk-free")

    view = PortfolioView(
        bankroll=bankroll,
        exposure=exposure_report(ledger, book=book, sport=sport),
        correlation=from_ledger(ledger, key=key, sport=sport),
    )
    view.flags = _flags(view)
    return view
