"""What you are currently on the hook for, and what each result pays.

The engine could say what to bet and, afterwards, how it went. In between —
which is where the money actually sits — it said nothing. A bettor running six
positions across three games cannot answer the only question that matters
before kickoff: *if this goes badly, how badly?*

Two things make this more than a sum of stakes.

**A market's worst case is not the sum of its stakes.** Bet both sides and one
leg always returns; bet the same side twice and nothing does. Payouts are
computed per outcome across every position on that market, so a hedged position
reads as hedged and a doubled-down one reads as doubled down.

**The outcome you did not bet is the one that hurts, and it is invisible in a
list built from your own slips.** A three-way market where you hold two sides
looks fully covered if the outcome set is inferred from your bets. It is not.
So the outcome set comes from recorded quotes where they exist, and where they
do not, the exposure is flagged as `inferred` — because a worst case computed
from an incomplete outcome set is not a worst case, it is a best case wearing
its clothes.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# A single event holding more than this share of total exposure is
# concentration worth naming. Not a limit — the user's bankroll rules are
# theirs — but a screen that shows six positions without mentioning that five
# of them ride on one game is hiding the only thing that matters about them.
CONCENTRATION_FLAG = 0.35


@dataclass(frozen=True)
class Position:
    """One open bet: money on the table until the event resolves."""

    bet_id: int
    event_id: str
    sport: str
    market_type: str
    outcome: str
    book: str
    decimal: float
    stake: float
    placed_at: float

    @property
    def to_return(self) -> float:
        """Gross return if this outcome wins — stake included."""
        return self.stake * self.decimal


@dataclass
class MarketExposure:
    """Every open position on one market, and what each result pays."""

    event_id: str
    sport: str
    market_type: str
    positions: list[Position] = field(default_factory=list)
    known: list[str] = field(default_factory=list)
    """Outcomes seen in recorded quotes. Empty means the outcome set is being
    inferred from the positions themselves, which understates risk."""

    @property
    def inferred(self) -> bool:
        return not self.known

    @property
    def outcomes(self) -> list[str]:
        """Every result this market can produce, as far as we can tell."""
        bet_on = sorted({p.outcome for p in self.positions})
        if not self.known:
            return bet_on
        return sorted(set(self.known) | set(bet_on))

    @property
    def at_risk(self) -> float:
        return sum(p.stake for p in self.positions)

    def payout(self, outcome: str) -> float:
        """Net profit if this outcome wins.

        Every position on the winning outcome returns; everything else is lost.
        Negative means the market costs money on that result, which is the
        normal case for anything but an arbitrage.
        """
        won = sum(p.to_return for p in self.positions if p.outcome == outcome)
        return won - self.at_risk

    def scenarios(self) -> list[tuple[str, float]]:
        """Every result and its net, worst first."""
        return sorted(
            ((o, self.payout(o)) for o in self.outcomes), key=lambda t: t[1]
        )

    @property
    def worst(self) -> tuple[str, float]:
        return self.scenarios()[0]

    @property
    def best(self) -> tuple[str, float]:
        return self.scenarios()[-1]

    @property
    def locked(self) -> bool:
        """Whether every result pays. An arbitrage, held rather than sought.

        Never true for an inferred outcome set: a market can only be locked if
        you know what it can do, and inferring the outcome set from your own
        bets guarantees that every result you can see is one you bet on.
        """
        return not self.inferred and self.worst[1] > 0

    @property
    def uncovered(self) -> list[str]:
        """Known outcomes with no position on them."""
        bet_on = {p.outcome for p in self.positions}
        return [o for o in self.outcomes if o not in bet_on]

    def describe(self) -> str:
        outcome, amount = self.worst
        state = "locked" if self.locked else f"worst {amount:+,.2f} on {outcome}"
        flag = " (outcome set inferred from your bets)" if self.inferred else ""
        return (f"{self.event_id} {self.market_type}: "
                f"{len(self.positions)} positions, {self.at_risk:,.0f} at risk, "
                f"{state}{flag}")


@dataclass
class ExposureReport:
    """Everything open, grouped and totalled."""

    markets: list[MarketExposure] = field(default_factory=list)

    @property
    def positions(self) -> int:
        return sum(len(m.positions) for m in self.markets)

    @property
    def at_risk(self) -> float:
        return sum(m.at_risk for m in self.markets)

    @property
    def worst_case(self) -> float:
        """Total if every market resolves the worst way it can.

        The sum of per-market worsts. That is the true floor only when markets
        are independent; correlated ones — same game, same starter, same
        weather — can all land on their worst outcome together, which is
        exactly what this number assumes. It is a floor, not a forecast.
        """
        return sum(m.worst[1] for m in self.markets)

    @property
    def best_case(self) -> float:
        return sum(m.best[1] for m in self.markets)

    def by(self, key) -> dict[str, float]:
        out: dict[str, float] = {}
        for market in self.markets:
            for position in market.positions:
                name = key(position)
                out[name] = out.get(name, 0.0) + position.stake
        return dict(sorted(out.items(), key=lambda kv: -kv[1]))

    @property
    def by_book(self) -> dict[str, float]:
        return self.by(lambda p: p.book)

    @property
    def by_sport(self) -> dict[str, float]:
        return self.by(lambda p: p.sport)

    @property
    def by_event(self) -> dict[str, float]:
        return self.by(lambda p: p.event_id)

    @property
    def concentration(self) -> tuple[str, float]:
        """The single event holding the largest share of exposure."""
        events = self.by_event
        if not events:
            return ("", 0.0)
        name, amount = next(iter(events.items()))
        return (name, amount / self.at_risk if self.at_risk else 0.0)

    @property
    def concentrated(self) -> bool:
        return self.concentration[1] > CONCENTRATION_FLAG

    @property
    def inferred_markets(self) -> list[MarketExposure]:
        return [m for m in self.markets if m.inferred]

    def verdict(self) -> str:
        if not self.markets:
            return "nothing open"
        parts = [
            f"{self.positions} positions across {len(self.markets)} markets, "
            f"{self.at_risk:,.0f} at risk",
            f"worst case {self.worst_case:+,.2f}",
        ]
        event, share = self.concentration
        if self.concentrated:
            parts.append(f"{share:.0%} of it on {event}")
        if self.inferred_markets:
            parts.append(
                f"{len(self.inferred_markets)} market(s) with no recorded "
                "quotes — their worst case is optimistic"
            )
        return "; ".join(parts)


def positions_from(rows: list[dict]) -> list[Position]:
    return [
        Position(
            bet_id=r["id"], event_id=r["event_id"], sport=r["sport"],
            market_type=r["market_type"], outcome=r["outcome"], book=r["book"],
            decimal=r["decimal_odds"], stake=r["stake"], placed_at=r["placed_at"],
        )
        for r in rows
    ]


def report(ledger, book: str | None = None, sport: str | None = None) -> ExposureReport:
    """Group every open position into markets and price each result."""
    grouped: dict[tuple[str, str], list[Position]] = {}
    for position in positions_from(ledger.open_positions(book=book, sport=sport)):
        grouped.setdefault((position.event_id, position.market_type), []).append(
            position
        )

    markets = []
    for (event_id, market_type), positions in grouped.items():
        markets.append(MarketExposure(
            event_id=event_id,
            sport=positions[0].sport,
            market_type=market_type,
            positions=positions,
            known=ledger.known_outcomes(event_id, market_type),
        ))

    markets.sort(key=lambda m: -m.at_risk)
    return ExposureReport(markets=markets)
