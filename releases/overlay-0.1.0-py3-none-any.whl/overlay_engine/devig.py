"""Removing the vig: five methods, and the reason we do not pick one.

A book's prices imply probabilities summing to more than 1. The surplus is the
margin. Devigging redistributes it to recover what the book actually believes.
*How* you redistribute it is a modelling choice, not arithmetic, and the choice
moves the answer by more than most edges are worth:

    Pinnacle NFL moneyline, -145 / +125.
      multiplicative -> favourite 58.0%
      additive       -> favourite 57.6%
      power          -> favourite 57.7%
      shin           -> favourite 57.8%

Half a point of probability on a 2% edge is a quarter of the edge. Every tool
in this category picks one method, hard-codes it, and prints the resulting EV
to two decimals as if it were measured. It isn't; it's one modelling opinion
rendered as a fact.

So this module computes all of them and hands back the spread. `ev.py` turns
that spread into an interval, and `calibrate.py` learns which method predicts
the closing line best *for a given sport and market* rather than asserting an
answer. Favourite-longshot bias is real but its size differs between an NBA
moneyline and a tennis outright, and no constant can be right for both.

References: Shin (1993) on insider trading in betting markets; the power method
as the standard generalisation of both additive and multiplicative.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from .odds import OddsError, decimal_to_prob

# Bisection bounds and tolerance. 1e-12 is far below the precision of any
# quoted price, so the solver's error never reaches the reported digits.
_TOL = 1e-12
_MAX_ITER = 200

METHODS = ("multiplicative", "additive", "power", "shin")


def _check(decimals: list[float]) -> list[float]:
    if len(decimals) < 2:
        raise OddsError("devigging needs at least two outcomes")
    raw = [decimal_to_prob(d) for d in decimals]
    total = sum(raw)
    if total <= 0.0:
        raise OddsError("implied probabilities must be positive")
    return raw


def multiplicative(decimals: list[float]) -> list[float]:
    """Scale every implied probability by the same factor.

    The default almost everywhere, because it is one division. It distributes
    the vig in proportion to implied probability, so the favourite absorbs the
    most — which is the opposite of the favourite-longshot bias observed in
    real markets, where the longshot carries the heavier margin. That makes it
    the method most likely to *overstate* a longshot's fair probability, and
    longshots are exactly where a naive +EV screen finds its phantom edges.
    """
    raw = _check(decimals)
    total = sum(raw)
    return [p / total for p in raw]


def additive(decimals: list[float]) -> list[float]:
    """Subtract an equal share of the surplus from every outcome.

    Corrects the favourite-longshot bias in the right direction, and can
    overshoot: on a heavy favourite in a many-outcome market it drives the
    longshots negative, which is not a probability. We raise rather than clamp
    — a clamped vector silently stops summing to 1 and every downstream EV
    built on it is wrong by an amount nobody can see.
    """
    raw = _check(decimals)
    share = (sum(raw) - 1.0) / len(raw)
    out = [p - share for p in raw]
    if any(p <= 0.0 for p in out):
        raise OddsError(
            "additive devig produced a non-positive probability; the market's "
            "margin exceeds what an equal split can absorb"
        )
    return out


def power(decimals: list[float]) -> list[float]:
    """Raise every implied probability to a common exponent k, sum to 1.

    Since the raw probabilities sum above 1 and each is below 1, raising them
    to k > 1 shrinks them all, and shrinks the small ones proportionally
    harder — a favourite-longshot correction that, unlike additive, cannot
    leave the unit interval. `p ** k` is monotone decreasing in k for p < 1,
    so the sum is monotone and bisection is exact and unconditionally stable.
    """
    raw = _check(decimals)
    if abs(sum(raw) - 1.0) < _TOL:
        return list(raw)

    def total(k: float) -> float:
        return sum(p**k for p in raw)

    lo, hi = 1.0, 2.0
    # Expand upward until the sum crosses 1 from above. A margin large enough
    # to need k > 2**40 is not a market, it is a parsing error.
    while total(hi) > 1.0:
        hi *= 2.0
        if hi > 2.0**40:
            raise OddsError("power devig failed to bracket a solution")
    if total(lo) < 1.0:
        lo = 0.0

    for _ in range(_MAX_ITER):
        mid = (lo + hi) / 2.0
        if total(mid) > 1.0:
            lo = mid
        else:
            hi = mid
        if hi - lo < _TOL:
            break
    k = (lo + hi) / 2.0
    out = [p**k for p in raw]
    s = sum(out)
    return [p / s for p in out]


def shin(decimals: list[float]) -> list[float]:
    """Shin's model: the margin is compensation for informed money.

    Shin (1993) derives the book's prices from a market containing a fraction
    z of insiders. Solving for z and inverting gives the fair probabilities.
    Unlike the others this has an economic story rather than a functional
    form, and it is the method that best reproduces observed longshot bias in
    the published literature.

        q_i = (sqrt(z^2 + 4(1-z) * p_i^2 / P) - z) / (2(1-z))

    where p_i are the raw implied probabilities and P their sum. sum(q_i) is
    monotone decreasing in z, so bisection on [0, 1) converges.
    """
    raw = _check(decimals)
    total = sum(raw)
    if abs(total - 1.0) < _TOL:
        return list(raw)
    if total < 1.0:
        # An underround — the market is itself an arb. Shin's derivation
        # assumes a positive margin and has no root here; the caller wants
        # arb.py, not a devig.
        raise OddsError(
            f"shin devig needs a positive margin; overround is {total:.6f}"
        )

    def q_of(z: float) -> list[float]:
        denom = 2.0 * (1.0 - z)
        return [
            (math.sqrt(z * z + 4.0 * (1.0 - z) * p * p / total) - z) / denom
            for p in raw
        ]

    lo, hi = 0.0, 1.0 - 1e-9
    for _ in range(_MAX_ITER):
        mid = (lo + hi) / 2.0
        if sum(q_of(mid)) > 1.0:
            lo = mid
        else:
            hi = mid
        if hi - lo < _TOL:
            break
    z = (lo + hi) / 2.0
    out = q_of(z)
    s = sum(out)
    return [p / s for p in out]


_DISPATCH = {
    "multiplicative": multiplicative,
    "additive": additive,
    "power": power,
    "shin": shin,
}


def devig(decimals: list[float], method: str = "power") -> list[float]:
    """Devig by name. `power` is the default: no constant is right for every
    market, but power is the only one of the four that cannot leave [0, 1] and
    still corrects longshot bias."""
    try:
        fn = _DISPATCH[method]
    except KeyError:
        raise OddsError(
            f"unknown devig method {method!r}; choose from {', '.join(METHODS)}"
        ) from None
    return fn(decimals)


@dataclass(frozen=True)
class DevigSpread:
    """Every method's answer for one market, plus the disagreement between them.

    `low` and `high` are the per-outcome envelope. The width is the honest
    error bar on any EV computed from this market: not sampling noise, but the
    range of answers that four defensible models give the same prices. A 3%
    edge inside a 4%-wide envelope is not a 3% edge, and this is the object
    that makes that visible instead of averaging it away.
    """

    outcomes: int
    by_method: dict[str, list[float]]
    failed: dict[str, str]

    @property
    def methods(self) -> list[str]:
        return sorted(self.by_method)

    def low(self, index: int) -> float:
        """Lowest fair probability any method assigns this outcome."""
        return min(v[index] for v in self.by_method.values())

    def high(self, index: int) -> float:
        return max(v[index] for v in self.by_method.values())

    def consensus(self, index: int, weights: dict[str, float] | None = None) -> float:
        """Weighted mean fair probability. Equal weights until calibrated.

        Weights are what `calibrate.py` learns from closing-line outcomes, so
        an uncalibrated install is explicitly an equal-weight blend rather
        than a hidden preference for whichever method the author liked.
        """
        vals = {m: v[index] for m, v in self.by_method.items()}
        if not weights:
            return sum(vals.values()) / len(vals)
        used = {m: w for m, w in weights.items() if m in vals and w > 0}
        if not used:
            return sum(vals.values()) / len(vals)
        total = sum(used.values())
        return sum(vals[m] * w for m, w in used.items()) / total

    def spread(self, index: int) -> float:
        """How far apart the methods are on this outcome, in probability."""
        return self.high(index) - self.low(index)


def devig_all(decimals: list[float]) -> DevigSpread:
    """Run every method, keeping the failures rather than hiding them.

    `additive` legitimately has no solution on wide markets and `shin` has
    none on an underround. Dropping those silently would make the envelope
    look tighter precisely where the market is most unusual — the opposite of
    what an error bar is for — so the reasons are carried in `failed`.
    """
    by_method: dict[str, list[float]] = {}
    failed: dict[str, str] = {}
    for name, fn in _DISPATCH.items():
        try:
            by_method[name] = fn(decimals)
        except OddsError as exc:
            failed[name] = str(exc)
    if not by_method:
        raise OddsError(f"every devig method failed: {failed}")
    return DevigSpread(outcomes=len(decimals), by_method=by_method, failed=failed)


def worst_case(decimals: list[float], index: int) -> float:
    """The least favourable fair probability for one outcome.

    Used when the decision is go/no-go rather than sizing: if the bet is +EV
    under the method that likes it least, the edge does not depend on a
    modelling choice. Deliberately not part of a normalised vector — it is a
    bound on one outcome, and the bounds across outcomes do not sum to 1.
    """
    return devig_all(decimals).low(index)
