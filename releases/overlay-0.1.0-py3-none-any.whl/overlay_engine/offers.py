"""What a promotion's rollover actually costs, given the markets it allows.

`promo.py` prices offer *shapes*. It takes a hold as an argument and defaults
to 4.5% — the standard -110/-110 two-way market — and says plainly in its own
docstring that this is a stated default rather than a measurement of any book.

That default is where most bonus arithmetic goes wrong, and it is not a small
error. A deposit match breaks even at a hold of `bonus / (rollover * base)`;
for a 100% match at 10x that is **5%**. The gap between 4.5% and 5% is the
entire value of the offer. So whether a match is worth taking is decided almost
entirely by which markets the book lets you churn it in — and books restrict
exactly the low-hold ones, for exactly this reason.

This module closes that gap in the only honest way available:

**The churn hold is measured, from real quotes, per market class.** Feed it
markets and it computes hold per class from the prices themselves. Nothing is
asserted.

**Where nothing has been measured, the number says so.** Every hold carries
`provenance` — `measured` or `prior` — and the count of markets behind it. A
prior propagates: a verdict resting on any unmeasured class is itself marked
prior, in the object and in the printed output. It is never silently mixed in.

**Terms carry a date and a source or they do not load.** An offer's rollover
multiple is a claim about someone else's product. Rows without a `source` and
a `fetched_at` are rejected at construction, and rows past `MAX_TERMS_AGE_DAYS`
are refused rather than shown with a warning — a stale term looks exactly like
a current one, and the reader has no way to tell.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path

from .odds import hold as market_hold
from .promo import breakeven_hold

# Offer terms rot faster than almost anything else in this codebase. A book can
# change a rollover multiple overnight and does not announce it.
MAX_TERMS_AGE_DAYS = 30.0

# The market classes books name in their playthrough rules. Kept coarse on
# purpose: a book writes "straight bets at -200 or longer", not a market_type,
# and inventing finer distinctions than the terms make would be pretending to
# a precision the source does not have.
CLASSES = ("h2h", "spreads", "totals", "player_prop", "parlay", "futures")

# Stated priors, used only when nothing has been measured for a class, and
# labelled `prior` everywhere they appear. Rough magnitudes from the standard
# two-way price and the way books shade thinner markets — not measurements of
# any book, and not to be reported as though they were.
PRIOR_HOLDS: dict[str, float] = {
    "h2h": 0.045,
    "spreads": 0.045,
    "totals": 0.045,
    "player_prop": 0.070,
    "parlay": 0.150,
    "futures": 0.150,
}


class OfferError(ValueError):
    """A term that cannot be trusted enough to compute with."""


@dataclass(frozen=True)
class ClassHold:
    """The hold of one market class, and where the number came from."""

    market_class: str
    hold: float
    provenance: str  # "measured" | "prior"
    n_markets: int = 0
    measured_at: float | None = None

    @property
    def measured(self) -> bool:
        return self.provenance == "measured"

    def describe(self) -> str:
        if self.measured:
            return (f"{self.market_class}: {self.hold:.2%} "
                    f"(measured over {self.n_markets} markets)")
        return f"{self.market_class}: {self.hold:.2%} (PRIOR — nothing measured)"


def measure_class_holds(markets: list, now: float | None = None) -> dict[str, ClassHold]:
    """Hold per market class, computed from the quotes themselves.

    A book's hold is only defined over a market it prices completely, so this
    devigs nothing and crosses nothing — it takes each book's own full set of
    prices on a market and reads the overround off it. A hold assembled from
    two books' prices is not that book's margin; it is the arbitrage between
    them wearing a margin's clothes.

    Classes with no complete market stay absent rather than defaulting, so the
    caller can tell "measured at zero markets" from "not measured".
    """
    gathered: dict[str, list[float]] = {}
    for market in markets:
        klass = market.market_type
        if klass not in CLASSES:
            continue
        for book in market.complete_books():
            prices = [q.decimal for q in market.by_book(book).values()]
            if len(prices) < 2:
                continue
            gathered.setdefault(klass, []).append(market_hold(prices))

    out: dict[str, ClassHold] = {}
    for klass, holds in gathered.items():
        out[klass] = ClassHold(
            market_class=klass,
            hold=sum(holds) / len(holds),
            provenance="measured",
            n_markets=len(holds),
            measured_at=now,
        )
    return out


def hold_for(klass: str, measured: dict[str, ClassHold]) -> ClassHold:
    """The hold to use for a class: the measurement if there is one, else the
    labelled prior. Never a silent blend of the two."""
    if klass in measured:
        return measured[klass]
    if klass not in PRIOR_HOLDS:
        raise OfferError(f"unknown market class {klass!r}")
    return ClassHold(market_class=klass, hold=PRIOR_HOLDS[klass],
                     provenance="prior")


@dataclass(frozen=True)
class RolloverTerms:
    """One book's playthrough terms in one state, dated and sourced.

    `source` and `fetched_at` are required. A rollover multiple with no date
    and no link is a number somebody remembered, and this module's whole claim
    is that it does not compute with those.
    """

    book: str
    state: str
    rollover: float
    eligible: frozenset[str]
    fetched_at: float
    source: str
    min_odds: float | None = None
    includes_deposit: bool = True
    note: str = ""

    def __post_init__(self) -> None:
        if not self.source.strip():
            raise OfferError(
                f"{self.book}/{self.state}: no source. A rollover multiple "
                "with no link is a number somebody remembered.")
        if not self.fetched_at or self.fetched_at <= 0:
            raise OfferError(f"{self.book}/{self.state}: no fetched_at date")
        if self.rollover < 0:
            raise OfferError(f"{self.book}/{self.state}: negative rollover")
        unknown = set(self.eligible) - set(CLASSES)
        if unknown:
            raise OfferError(
                f"{self.book}/{self.state}: unknown market class(es) "
                f"{sorted(unknown)}")
        if not self.eligible:
            raise OfferError(
                f"{self.book}/{self.state}: no eligible markets. An offer with "
                "nothing to churn it in cannot be cleared at any hold.")

    def age_days(self, now: float) -> float:
        return (now - self.fetched_at) / 86_400.0

    def stale(self, now: float) -> bool:
        return self.age_days(now) > MAX_TERMS_AGE_DAYS


@dataclass(frozen=True)
class Verdict:
    """Whether an offer clears, and how much of the answer was measured."""

    book: str
    state: str
    bonus: float
    deposit: float
    rollover: float
    breakeven: float
    churn: ClassHold
    terms_age_days: float
    includes_deposit: bool = True

    @property
    def clears(self) -> bool:
        return self.churn.hold < self.breakeven

    @property
    def margin(self) -> float:
        """Headroom between break-even and the real churn hold.

        Negative means the playthrough costs more than the bonus pays.
        """
        return self.breakeven - self.churn.hold

    @property
    def net(self) -> float:
        """Expected value in money, at the churn hold."""
        # The same base `breakeven_hold` uses. Branching on anything else
        # here would make `net` and `margin` disagree about the same offer.
        base = (self.deposit + self.bonus) if self.includes_deposit else self.bonus
        return self.bonus - self.rollover * base * self.churn.hold

    @property
    def measured(self) -> bool:
        return self.churn.measured

    def describe(self) -> str:
        head = "CLEARS" if self.clears else "DOES NOT CLEAR"
        lines = [
            f"{self.book}/{self.state}: {head}",
            f"  break-even hold   {self.breakeven:.2%}",
            f"  cheapest churn    {self.churn.describe()}",
            f"  margin            {self.margin:+.2%}",
            f"  net at that hold  {self.net:+,.2f}",
            f"  terms age         {self.terms_age_days:.0f} days",
        ]
        if not self.measured:
            lines.append(
                "  PRIOR: no hold measured for the eligible markets, so this "
                "verdict rests on a stated prior, not a measurement.")
        return "\n".join(lines)


def cheapest_eligible(terms: RolloverTerms,
                      measured: dict[str, ClassHold]) -> ClassHold:
    """The cheapest class the terms actually allow.

    This is the whole point of the module. A bettor churns in the cheapest
    market available to them, so the offer's real cost is set by the best
    *eligible* hold — not by the best hold on the board, which is what using a
    flat 4.5% quietly assumes.
    """
    candidates = [hold_for(k, measured) for k in sorted(terms.eligible)]
    if not candidates:  # pragma: no cover - __post_init__ forbids it
        raise OfferError(f"{terms.book}: no eligible markets")
    return min(candidates, key=lambda c: c.hold)


def evaluate(terms: RolloverTerms, deposit: float, bonus: float,
             measured: dict[str, ClassHold], now: float) -> Verdict:
    """Does this deposit match clear, given what its terms let you churn in?"""
    if terms.stale(now):
        raise OfferError(
            f"{terms.book}/{terms.state}: terms are "
            f"{terms.age_days(now):.0f} days old (limit {MAX_TERMS_AGE_DAYS:.0f}). "
            "Refusing rather than reporting — a stale term reads exactly like "
            "a current one.")
    return Verdict(
        book=terms.book,
        state=terms.state,
        bonus=bonus,
        deposit=deposit,
        rollover=terms.rollover,
        breakeven=breakeven_hold(deposit, bonus, terms.rollover,
                                 terms.includes_deposit),
        churn=cheapest_eligible(terms, measured),
        terms_age_days=terms.age_days(now),
        includes_deposit=terms.includes_deposit,
    )


@dataclass
class LoadReport:
    """What loaded, and what was refused and why."""

    terms: list[RolloverTerms] = field(default_factory=list)
    refused: list[tuple[str, str]] = field(default_factory=list)

    def describe(self) -> str:
        if not self.terms and not self.refused:
            return ("no offer terms on file — nothing has been sourced and "
                    "dated yet, and unsourced terms are not shipped")
        parts = [f"{len(self.terms)} term(s) loaded"]
        if self.refused:
            parts.append(f"{len(self.refused)} refused")
        return ", ".join(parts)


def load_terms(path: str | Path, now: float) -> LoadReport:
    """Read a dated, sourced terms feed keyed by (book, state).

    Refuses rows rather than repairing them. A row missing its source is not a
    row with an unknown source; it is a claim nobody can check.
    """
    report = LoadReport()
    text = Path(path).read_text()
    for i, row in enumerate(csv.DictReader(text.splitlines()), start=2):
        if not any((v or "").strip() for v in row.values()):
            continue
        label = f"row {i} ({row.get('book', '?')}/{row.get('state', '?')})"
        try:
            terms = RolloverTerms(
                book=(row.get("book") or "").strip(),
                state=(row.get("state") or "").strip().upper(),
                rollover=float(row.get("rollover") or 0),
                eligible=frozenset(
                    c.strip() for c in (row.get("eligible") or "").split("|")
                    if c.strip()),
                fetched_at=float(row.get("fetched_at") or 0),
                source=(row.get("source") or "").strip(),
                min_odds=float(row["min_odds"]) if (row.get("min_odds") or "").strip() else None,
                includes_deposit=(row.get("includes_deposit") or "true").strip().lower()
                not in ("false", "0", "no"),
                note=(row.get("note") or "").strip(),
            )
        except (OfferError, ValueError) as exc:
            report.refused.append((label, str(exc)))
            continue
        if terms.stale(now):
            report.refused.append(
                (label, f"{terms.age_days(now):.0f} days old, limit "
                        f"{MAX_TERMS_AGE_DAYS:.0f}"))
            continue
        report.terms.append(terms)
    return report
