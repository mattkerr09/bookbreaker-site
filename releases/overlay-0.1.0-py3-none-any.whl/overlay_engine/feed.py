"""Where quotes come from, and the timestamp discipline they arrive under.

No provider here talks to a paid feed — that needs a subscription this build
does not have. What is here is the seam a real provider drops into, plus the
capture pass that drives it, plus a replay provider that makes both testable
today against recorded snapshots.

The seam exists mainly to enforce one thing at the boundary, because it cannot
be enforced anywhere else: **every quote is stamped with when we received it,
and a quote the provider did not date is marked as undated rather than assumed
fresh.**

That is the whole reason this file is not just `requests.get`. `p_fill` decays
from `seen_at`, and if a provider without its own timestamps is allowed to set
`seen_at = now`, every quote looks brand new, latency measures as zero, and the
product's headline number is optimistic by an amount nobody can see. Stamping
happens once, here, so no provider can forget.

The rest is deliberately thin. A provider's only job is to return markets; the
timestamp discipline, the latency accounting and the ledger writes belong to
the pass, not to each integration.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

from .models import Market, Outcome, Quote

# A provider whose clock runs ahead of ours would produce quotes dated in the
# future, which read as negative age and therefore as better-than-live. Small
# skew is normal and absorbed; past this many seconds it is a broken clock and
# the quote is dropped rather than trusted.
MAX_CLOCK_SKEW = 120.0


class FeedError(RuntimeError):
    """A provider returned something that cannot be trusted as a quote."""


@dataclass
class Snapshot:
    """One fetch: the markets it returned and when it returned them."""

    markets: list[Market]
    fetched_at: float
    provider: str
    dated: int = 0
    """How many quotes carried the provider's own timestamp. The rest are
    `assumed`, and the gap between the two counts is the honest measure of how
    much this feed can tell you about staleness."""

    undated: int = 0
    skewed: int = 0
    """Quotes dropped for being dated implausibly far in the future."""

    @property
    def quotes(self) -> int:
        return sum(len(m.quotes) for m in self.markets)

    @property
    def dated_fraction(self) -> float:
        total = self.dated + self.undated
        return self.dated / total if total else 0.0

    def describe(self) -> str:
        parts = [f"{len(self.markets)} markets, {self.quotes} quotes"]
        if self.undated:
            parts.append(f"{self.undated} undated ({self.dated_fraction:.0%} dated)")
        if self.skewed:
            parts.append(f"{self.skewed} dropped for clock skew")
        return "; ".join(parts)


def stamp(markets: list[Market], fetched_at: float | None = None,
          provider: str = "unknown") -> Snapshot:
    """Stamp receipt time onto every quote and classify its provenance.

    Called once at the boundary so no provider can forget. A quote the
    provider did not date gets `seen_at = fetched_at` and `fetched_at = None`,
    which `Quote.provenance` reports as `assumed` — and that is what lets
    `Quote.age(latency_floor=...)` add the book's measured lag back on instead
    of quietly treating an unknown delay as no delay.
    """
    fetched_at = time.time() if fetched_at is None else fetched_at
    snapshot = Snapshot(markets=[], fetched_at=fetched_at, provider=provider)

    for market in markets:
        kept: list[Quote] = []
        for quote in market.quotes:
            if quote.seen_at > fetched_at + MAX_CLOCK_SKEW:
                # Dated far in the future: a broken clock, not a fresh price.
                # Keeping it would give the quote a negative age and rank it
                # above every honestly-dated quote on the screen.
                snapshot.skewed += 1
                continue

            if quote.seen_at >= fetched_at:
                # Within tolerable skew but not usefully dated — treat receipt
                # as the timestamp and leave `fetched_at` unset.
                #
                # Unset, not equal. Storing `fetched_at == seen_at` reads
                # downstream as a *measured* latency of zero, and averaging
                # those in drags every book's estimate toward "instant" — which
                # is the optimistic direction, and the exact failure the
                # provenance split exists to prevent.
                quote.seen_at = fetched_at
                quote.fetched_at = None
                snapshot.undated += 1
            else:
                quote.fetched_at = fetched_at
                snapshot.dated += 1
            kept.append(quote)

        if kept:
            market.quotes = kept
            snapshot.markets.append(market)

    return snapshot


class Provider:
    """What a feed integration has to implement. One method.

    Everything else — stamping, latency, ledger writes — belongs to the pass,
    so an integration cannot get it subtly wrong in its own way.
    """

    key = "provider"

    def fetch(self, sport: str) -> list[Market]:
        raise NotImplementedError

    def sports(self) -> list[str]:
        raise NotImplementedError


@dataclass
class ReplayProvider(Provider):
    """Serves recorded snapshots from disk. No network.

    The point of this is not testing convenience, though it is that too. It is
    that a feed decision should be made on *measured* latency rather than the
    vendor's published claims — and two of the four candidates in `docs/DATA.md`
    publish no latency figure at all. Recording a trial period from each and
    replaying it through the same engine is how that gets compared honestly.
    """

    path: Path | str
    key: str = "replay"
    _data: dict = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        self.path = Path(self.path)
        if not self.path.exists():
            raise FeedError(f"no snapshot at {self.path}")
        try:
            self._data = json.loads(self.path.read_text())
        except json.JSONDecodeError as exc:
            raise FeedError(f"{self.path} is not valid JSON: {exc}") from None

    def sports(self) -> list[str]:
        return sorted({m["sport"] for m in self._data.get("markets", [])})

    def fetch(self, sport: str) -> list[Market]:
        return [
            market_from_dict(m)
            for m in self._data.get("markets", [])
            if m.get("sport") == sport
        ]


def market_from_dict(data: dict) -> Market:
    """Rebuild a `Market` from a recorded snapshot."""
    try:
        quotes = [
            Quote(
                book=q["book"],
                outcome=Outcome(name=q["outcome"], line=q.get("line")),
                decimal=float(q["decimal"]),
                seen_at=float(q["seen_at"]),
                limit=q.get("limit"),
            )
            for q in data["quotes"]
        ]
        return Market(
            event_id=data["event_id"],
            sport=data["sport"],
            market_type=data["market_type"],
            quotes=quotes,
            starts_at=data.get("starts_at"),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise FeedError(f"malformed market in snapshot: {exc}") from None


def market_to_dict(market: Market) -> dict:
    """Serialise a `Market` for a snapshot file."""
    return {
        "event_id": market.event_id,
        "sport": market.sport,
        "market_type": market.market_type,
        "starts_at": market.starts_at,
        "quotes": [
            {
                "book": q.book,
                "outcome": q.outcome.name,
                "line": q.outcome.line,
                "decimal": q.decimal,
                "seen_at": q.seen_at,
                "limit": q.limit,
            }
            for q in market.quotes
        ],
    }


def write_snapshot(path: Path | str, markets: list[Market],
                   fetched_at: float | None = None) -> int:
    """Write markets to a replayable snapshot. Returns the quote count."""
    payload = {
        "fetched_at": time.time() if fetched_at is None else fetched_at,
        "markets": [market_to_dict(m) for m in markets],
    }
    Path(path).write_text(json.dumps(payload, indent=2, sort_keys=True))
    return sum(len(m.quotes) for m in markets)


@dataclass
class CaptureReport:
    """What one capture pass stored."""

    markets: int = 0
    quotes: int = 0
    dated: int = 0
    undated: int = 0
    skewed: int = 0
    sports: list[str] = field(default_factory=list)
    closing: bool = False

    def describe(self) -> str:
        if not self.markets:
            return "captured nothing"
        kind = "closing" if self.closing else "in-play"
        return (
            f"captured {self.quotes} {kind} quotes across {self.markets} markets"
            f" ({self.dated} dated, {self.undated} undated"
            + (f", {self.skewed} skewed" if self.skewed else "")
            + ")"
        )


def capture(
    ledger,
    provider: Provider,
    sports: list[str] | None = None,
    is_closing: bool = False,
    now: float | None = None,
) -> CaptureReport:
    """Fetch, stamp, and store every market the provider serves.

    **Every market watched, not only the ones bet.** A closing line observed
    only where a bet was placed is a biased sample of exactly the markets the
    model got wrong, and calibration fitted on that sample learns the bias
    instead of the market. That is why this takes a sport list rather than a
    list of open positions.
    """
    fetched_at = time.time() if now is None else now
    report = CaptureReport(closing=is_closing)
    report.sports = sports if sports is not None else provider.sports()

    for sport in report.sports:
        snapshot = stamp(provider.fetch(sport), fetched_at, provider.key)
        report.dated += snapshot.dated
        report.undated += snapshot.undated
        report.skewed += snapshot.skewed
        for market in snapshot.markets:
            report.quotes += ledger.record_market(market, is_closing=is_closing)
            report.markets += 1

    return report
