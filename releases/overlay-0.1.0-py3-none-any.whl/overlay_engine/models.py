"""The data model, and the book taxonomy the whole edge rests on.

One classification decision runs through every other module: books are not
interchangeable. A price at Pinnacle is *evidence about the world*; a price at
a US retail book is *a product being sold to recreational bettors*. Treating
the two as equally informative — averaging them into one "market consensus" —
is the mistake that turns a soft book's mispriced line into a phantom edge
against itself.

So `BookTier` is not cosmetic metadata. It sets which prices anchor a fair
value (`fair.py`), which ones can be bet without burning an account
(`heat.py`), and which ones are worth a limit-risk budget at all.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class BookTier(str, Enum):
    """How much a book's price tells you, and what it costs to bet there."""

    SHARP = "sharp"
    """Low margin, high limits, no limiting of winners. Pinnacle, PS3838,
    BetInAsia, Circa. Their line is the closest public thing to a fair price,
    because they price to be right rather than to be attractive."""

    EXCHANGE = "exchange"
    """Peer-to-peer with commission rather than vig — Betfair, Smarkets, and
    the prediction markets (Kalshi, Polymarket). No bookmaker exists to limit
    you. Prices need commission netted out before comparison, which is why
    `commission` lives on Book and defaults to zero everywhere else."""

    RETAIL = "retail"
    """The soft US/EU books — DraftKings, FanDuel, BetMGM, bet365, Caesars.
    Where the edge is, and where the account risk is. Their prices are weak
    evidence about outcomes and strong evidence about what recreational money
    is doing."""

    UNKNOWN = "unknown"
    """Unclassified. Anchors nothing and is never used as evidence — an
    unknown book contributing to a fair value is indistinguishable from a
    soft book doing it, so it is excluded rather than guessed at."""


# Default sharpness weights by tier, used until `calibrate.py` replaces them
# with per-sport values learned from closing lines. Weights are relative and
# only their ratios matter.
TIER_WEIGHT: dict[BookTier, float] = {
    BookTier.SHARP: 1.0,
    BookTier.EXCHANGE: 0.85,
    BookTier.RETAIL: 0.06,
    BookTier.UNKNOWN: 0.0,
}


@dataclass(frozen=True)
class Book:
    """A venue, its tier, and the two frictions that change what a price means.

    `commission` is the exchange's cut of winnings, which makes a nominal 2.10
    on Betfair worth less than 2.10 anywhere else. `limits_winners` is what
    the account-longevity model spends its budget on: a book that never limits
    costs nothing to win at, so no anti-limit tactic should waste edge there.
    """

    key: str
    name: str
    tier: BookTier = BookTier.UNKNOWN
    commission: float = 0.0
    limits_winners: bool = True

    @property
    def weight(self) -> float:
        return TIER_WEIGHT[self.tier]

    def net_decimal(self, decimal: float) -> float:
        """Decimal odds after the venue takes its cut of the winnings.

        On a 0% commission book this is the identity. On a 2% exchange, 3.00
        becomes 2.96 — small, and larger than most arbitrage margins, which is
        the entire reason it cannot be handled "later".
        """
        if self.commission <= 0.0:
            return decimal
        return 1.0 + (decimal - 1.0) * (1.0 - self.commission)


@dataclass(frozen=True)
class Outcome:
    """One side of a market: what you'd be betting on, and at what number.

    `line` is the handicap or total the price attaches to. Two prices on
    "over" are not comparable unless they share a line, and the most common
    way to fabricate an arbitrage is to compare over 220.5 with under 221.5 as
    though they were opposite sides. `key` includes the line for exactly that
    reason.
    """

    name: str
    line: float | None = None

    @property
    def key(self) -> str:
        if self.line is None:
            return self.name
        return f"{self.name}@{self.line:g}"


@dataclass
class Quote:
    """One book's price on one outcome, and when each party knew about it.

    Two timestamps, because they answer different questions and conflating
    them biases the product's headline number in the dangerous direction.

    `seen_at` is **the feed's own timestamp** — when the price was true at the
    book. `fetched_at` is when it reached us. The gap between them is feed
    latency, and during it the price may already have moved without our
    knowing.

    Fill probability decays with time since the book last confirmed the price,
    which is `now - seen_at`. Measuring from `fetched_at` instead understates
    age by exactly the latency and therefore *overstates* the chance of getting
    the bet down — on precisely the fastest-moving markets, where latency is
    largest and the error matters most. That was the behaviour before this
    field existed: `seen_at` was whatever the constructor was handed, and in
    practice that was fetch time.

    When a feed gives no timestamp of its own, `seen_at` falls back to
    `fetched_at` and `provenance` says `assumed` — which is the signal
    `age(latency_floor=...)` needs to add the book's measured typical latency
    back on rather than quietly pretending it was zero.
    """

    book: str
    outcome: Outcome
    decimal: float
    seen_at: float = field(default_factory=time.time)
    limit: float | None = None
    fetched_at: float | None = None
    """When this price reached us. None means it was never recorded, in which
    case latency is unknown rather than zero."""

    @property
    def latency(self) -> float | None:
        """Seconds between the book's timestamp and our receipt of it.

        None when unmeasurable. Never negative: a feed clock running ahead of
        ours would otherwise produce a negative latency that credits the quote
        with being fresher than live.
        """
        if self.fetched_at is None:
            return None
        return max(0.0, self.fetched_at - self.seen_at)

    @property
    def provenance(self) -> str:
        """`measured` when the feed dated the price, `assumed` otherwise.

        Exposed so no screen can show a fill probability without being able to
        say whether the age behind it was observed or inferred.
        """
        if self.fetched_at is None or self.fetched_at <= self.seen_at:
            return "assumed"
        return "measured"

    def age(self, now: float | None = None, latency_floor: float = 0.0) -> float:
        """Seconds since the book last confirmed this price.

        `latency_floor` is added only for `assumed` quotes — those whose feed
        gave no timestamp, so the true age is at least this much larger than we
        can see. For a `measured` quote the latency is already inside
        `now - seen_at` and adding it again would double-count.
        """
        base = max(0.0, (time.time() if now is None else now) - self.seen_at)
        if latency_floor > 0.0 and self.provenance == "assumed":
            return base + latency_floor
        return base


@dataclass
class Market:
    """Every book's quote on one market of one event.

    A market is the unit of comparison. Grouping is by `(event, market_type)`
    and, for handicapped markets, by line — see `Outcome.key`.
    """

    event_id: str
    sport: str
    market_type: str
    quotes: list[Quote] = field(default_factory=list)
    starts_at: float | None = None

    def outcomes(self) -> list[str]:
        """Distinct outcome keys, in first-seen order.

        Order is stable because probability vectors are positional everywhere
        downstream — a set here would silently reorder a devig result.
        """
        seen: list[str] = []
        for q in self.quotes:
            if q.outcome.key not in seen:
                seen.append(q.outcome.key)
        return seen

    def best(self, outcome_key: str) -> Quote | None:
        """Highest price offered on an outcome across all books."""
        candidates = [q for q in self.quotes if q.outcome.key == outcome_key]
        if not candidates:
            return None
        return max(candidates, key=lambda q: q.decimal)

    def by_book(self, book: str) -> dict[str, Quote]:
        """That book's quotes, keyed by outcome.

        Devigging requires a *complete* two-sided market from a single book —
        a fair probability derived from one book's over and another's under is
        not a devig, it is the arbitrage itself, laundered into a probability.
        """
        return {q.outcome.key: q for q in self.quotes if q.book == book}

    def complete_books(self) -> list[str]:
        """Books quoting every outcome, so their market can be devigged."""
        keys = set(self.outcomes())
        books: list[str] = []
        for q in self.quotes:
            if q.book in books:
                continue
            if set(self.by_book(q.book)) >= keys:
                books.append(q.book)
        return books

    def seconds_to_start(self, now: float | None = None) -> float | None:
        if self.starts_at is None:
            return None
        return self.starts_at - (time.time() if now is None else now)


@dataclass(frozen=True)
class Edge:
    """A priced opportunity, with every number that qualifies it attached.

    The critical field is `p_fill`. Competing screens report `ev` and stop;
    but an edge you cannot actually get on is worth zero, and the difference
    between a 4% edge that fills 90% of the time and a 6% edge that fills 20%
    of the time is the whole decision. `realised_ev` is the only number here
    worth sorting on.
    """

    kind: str
    event_id: str
    sport: str
    market_type: str
    outcome: str
    book: str
    decimal: float
    fair_prob: float
    ev: float
    ev_low: float
    ev_high: float
    p_fill: float = 1.0
    heat: float = 0.0
    quote_age: float = 0.0
    note: str = ""

    @property
    def realised_ev(self) -> float:
        """Expected value per unit staked, discounted by the chance of getting
        the bet down at all."""
        return self.ev * self.p_fill

    @property
    def robust(self) -> bool:
        """True when the edge survives the devig method that likes it least.

        An edge that exists under multiplicative and vanishes under shin is a
        modelling artefact, not an opportunity.
        """
        return self.ev_low > 0.0
