"""Grading bets against the closing line, without inventing one.

`settle()` takes a devigged closing probability. Somebody has to compute it,
and until now that somebody was a human with a calculator — which meant
calibration only ever ran on data that had been hand-graded, and the learning
loop was real but unfed.

This module fills that gap from recorded closing quotes. It is short, and
almost all of it is refusals, because every shortcut available here produces a
closing number that looks fine and is wrong in a way nothing downstream can
detect:

**Never mix books.** A fair probability built from one book's over and
another's under is the arbitrage between them laundered into a probability. It
grades the bet against a price no book ever offered, and — worse — the error
correlates with exactly the markets where books disagreed, which are the
markets a +EV screen sent you to. The bias would land hardest on the bets the
model was most confident about.

**Never cross a line.** A bet on over 220.5 cannot be graded against a close on
221.5. Those are different bets. Line movement is the normal case on spreads
and totals, so this rejection fires often, and it is reported rather than
papered over: an ungraded bet is a known unknown, and a bet graded at the wrong
line is a wrong number wearing a right one's clothes.

**Never grade off a soft book alone.** The closing line is used as truth, and a
retail book's close is not truth — it is the last price it was willing to
offer recreational money. Graded against it, a bet that beat a soft book scores
as beating "the market".

Everything it declines to grade is returned with a reason, because a grader
that silently skips is indistinguishable from one that has nothing to do.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .devig import devig_all
from .models import Book, BookTier

# Preference order for the book whose closing market is used as truth. Sharp
# first, exchange second, and retail only when explicitly allowed.
_TIER_RANK = {
    BookTier.SHARP: 0,
    BookTier.EXCHANGE: 1,
    BookTier.RETAIL: 2,
    BookTier.UNKNOWN: 3,
}


@dataclass(frozen=True)
class Skip:
    """A bet that could not be graded, and why."""

    bet_id: int
    reason: str


@dataclass
class GradeReport:
    """What one grading pass did, including everything it would not do."""

    graded: int = 0
    skipped: list[Skip] = field(default_factory=list)

    @property
    def attempted(self) -> int:
        return self.graded + len(self.skipped)

    def reasons(self) -> dict[str, int]:
        """Skip counts by reason, so a pattern is visible at a glance.

        Fifty bets skipped for "line moved" is a fact about totals betting;
        fifty skipped for "no closing quotes" means capture is broken. Those
        need to look different, and a flat list of fifty lines does not.
        """
        counts: dict[str, int] = {}
        for skip in self.skipped:
            head = skip.reason.split(":")[0]
            counts[head] = counts.get(head, 0) + 1
        return dict(sorted(counts.items(), key=lambda kv: -kv[1]))

    def describe(self) -> str:
        if not self.attempted:
            return "nothing to grade"
        parts = [f"graded {self.graded} of {self.attempted}"]
        for reason, n in self.reasons().items():
            parts.append(f"{n} {reason}")
        return "; ".join(parts)


def _rank(book_key: str, books: dict[str, Book]) -> int:
    book = books.get(book_key)
    return _TIER_RANK[book.tier if book else BookTier.UNKNOWN]


def closing_fair_prob(
    closing: dict[str, dict[str, float]],
    outcome: str,
    books: dict[str, Book],
    require_anchor: bool = True,
    method_weights: dict[str, float] | None = None,
) -> tuple[float | None, str]:
    """Devigged closing probability for one outcome, or a reason there isn't one.

    Returns `(prob, source_book)` on success and `(None, reason)` otherwise.
    Both halves are always meaningful, so a caller cannot accidentally treat a
    failure message as a probability.
    """
    if not closing:
        return None, "no closing quotes"

    # A book can only serve as truth if it priced the whole market. Two
    # outcomes is the minimum; one is not a market and cannot be devigged.
    complete = {
        book: prices for book, prices in closing.items() if len(prices) >= 2
    }
    if not complete:
        return None, "no book priced the full market at close"

    with_outcome = {
        book: prices for book, prices in complete.items() if outcome in prices
    }
    if not with_outcome:
        return None, f"line moved: no close on {outcome}"

    ordered = sorted(with_outcome, key=lambda b: (_rank(b, books), b))
    best = ordered[0]
    if require_anchor and _rank(best, books) > _TIER_RANK[BookTier.EXCHANGE]:
        return None, "no sharp or exchange close"

    prices = with_outcome[best]
    keys = sorted(prices)
    try:
        spread = devig_all([prices[k] for k in keys])
    except Exception as exc:
        return None, f"closing market would not devig: {exc}"

    return spread.consensus(keys.index(outcome), method_weights), best


def grade_pending(
    ledger,
    books: dict[str, Book] | None = None,
    require_anchor: bool = True,
    method_weights: dict[str, float] | None = None,
) -> GradeReport:
    """Settle every ungraded bet that has a usable closing market.

    Idempotent: `ungraded_bets` only returns bets without a closing
    probability, so re-running grades the newly-capturable ones and leaves
    settled bets alone. That matters because this is meant to run on a
    schedule, and a grader that re-settles would quietly rewrite history every
    time a later quote arrived.
    """
    if books is None:
        from .catalog import all_books

        books = all_books()

    report = GradeReport()
    for bet in ledger.ungraded_bets():
        closing = ledger.closing_market(bet["event_id"], bet["market_type"])
        prob, source = closing_fair_prob(
            closing, bet["outcome"], books, require_anchor, method_weights
        )
        if prob is None:
            report.skipped.append(Skip(bet_id=bet["id"], reason=source))
            continue
        ledger.settle(bet["id"], closing_fair_prob=prob)
        report.graded += 1
    return report
