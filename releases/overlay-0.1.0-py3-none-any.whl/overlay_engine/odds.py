"""Odds representation and conversion.

Every other module speaks decimal odds internally. American odds exist only at
the edges — what a book displays and what a user types. Converting once, at the
boundary, is the difference between one rounding error and forty.

American odds have a hole in them: no book quotes a price between -100 and +100
exclusive, and 0 is not a price at all. Accepting one silently would produce a
decimal odd below 1.0, which reads as "you lose money when you win" and would
propagate into an EV number that looks merely disappointing rather than wrong.
So the hole is a rejection, not a clamp.
"""

from __future__ import annotations

from dataclasses import dataclass


class OddsError(ValueError):
    """An odds value that cannot represent a real price."""


def american_to_decimal(american: float) -> float:
    """Convert American odds to decimal (European) odds.

    +150 -> 2.50, -200 -> 1.50.
    """
    a = float(american)
    if -100.0 < a < 100.0:
        raise OddsError(
            f"{american:g} is not a quotable American price: no book prices "
            "between -100 and +100"
        )
    if a >= 100.0:
        return 1.0 + a / 100.0
    return 1.0 + 100.0 / abs(a)


def decimal_to_american(decimal: float) -> float:
    """Convert decimal odds to American odds.

    2.50 -> +150, 1.50 -> -200. Even money (2.0) resolves to +100, matching
    every US book's display.
    """
    d = float(decimal)
    if d <= 1.0:
        raise OddsError(f"decimal odds must exceed 1.0, got {decimal:g}")
    if d >= 2.0:
        return (d - 1.0) * 100.0
    return -100.0 / (d - 1.0)


def decimal_to_prob(decimal: float) -> float:
    """Implied probability of a decimal price, vig included.

    This is *not* a fair probability. It is what the book's price asserts,
    which across a full market sums to more than 1. Devigging that surplus
    away is `devig.py`'s job, and calling this value a probability without
    that step is the single most common way to invent an edge that isn't there.
    """
    d = float(decimal)
    if d <= 1.0:
        raise OddsError(f"decimal odds must exceed 1.0, got {decimal:g}")
    return 1.0 / d


def prob_to_decimal(prob: float) -> float:
    """Decimal price that pays fairly for a probability."""
    p = float(prob)
    if not 0.0 < p < 1.0:
        raise OddsError(f"probability must lie in (0, 1), got {prob!r}")
    return 1.0 / p


def american_to_prob(american: float) -> float:
    """Implied probability of an American price, vig included."""
    return decimal_to_prob(american_to_decimal(american))


def prob_to_american(prob: float) -> float:
    """American price that pays fairly for a probability."""
    return decimal_to_american(prob_to_decimal(prob))


def parse_odds(value: str | float | int) -> float:
    """Read odds in whatever form they arrive and return decimal.

    A bare number is ambiguous exactly once: 2.5 could be decimal 2.5 or
    American +250 shorthand. We resolve it by range — anything at or above 100
    (or at or below -100) is American, anything in (1, 100) is decimal. That
    boundary is unambiguous because decimal odds of 100.0 and American +100
    both exist, and we resolve 100 as American, which is the vastly more
    common quote. Strings carrying an explicit sign are always American.
    """
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        if not text:
            raise OddsError("empty odds string")
        if text.startswith(("+", "-")):
            return american_to_decimal(float(text))
        value = float(text)

    v = float(value)
    if v >= 100.0 or v <= -100.0:
        return american_to_decimal(v)
    if v > 1.0:
        return v
    raise OddsError(f"cannot read {value!r} as odds")


def overround(decimals: list[float]) -> float:
    """Sum of implied probabilities across a market's outcomes.

    Above 1.0 for any market a book actually offers; the excess is the vig.
    Below 1.0 means the outcomes, taken together, are an arbitrage — which is
    why `arb.py` tests exactly this quantity.
    """
    if not decimals:
        raise OddsError("overround needs at least one outcome")
    return sum(decimal_to_prob(d) for d in decimals)


def hold(decimals: list[float]) -> float:
    """The book's theoretical margin on a market, as a fraction of handle.

    Hold is *not* the overround minus one. A market with a 1.05 overround
    holds 1 - 1/1.05 = 4.76%, not 5%: the book's take is measured against the
    money bet, and the money bet is the whole 1/overround-normalised pool.
    Reporting the overround excess as hold overstates every book's margin,
    which in turn understates the edge of beating it.
    """
    return 1.0 - 1.0 / overround(decimals)


@dataclass(frozen=True)
class Price:
    """A single quoted price, with the book and the moment attached.

    A price without a timestamp is not evidence of anything — by the time an
    opportunity reaches a screen the quote may already be gone, and the whole
    staleness model in `staleness.py` exists to put a number on that. Carrying
    `seen_at` on the price itself means no downstream caller has to guess.
    """

    book: str
    decimal: float
    seen_at: float
    limit: float | None = None

    def __post_init__(self) -> None:
        if self.decimal <= 1.0:
            raise OddsError(f"decimal odds must exceed 1.0, got {self.decimal:g}")

    @property
    def american(self) -> float:
        return decimal_to_american(self.decimal)

    @property
    def implied(self) -> float:
        """Vig-inclusive implied probability of this single price."""
        return decimal_to_prob(self.decimal)

    def age(self, now: float) -> float:
        """Seconds since this price was observed. Never negative."""
        return max(0.0, now - self.seen_at)
