"""Fill probability: how likely the price is still there when you tap it.

The gap this fills is the largest one in the category. Every screen reports
the edge of a quote it saw at some past instant. Between that instant and the
bet landing sit the poll interval, the network, the render, and the human — a
few seconds at best, much longer on a phone. Books do not hold prices for any
of it.

The consequence is that a screen sorted by raw EV is sorted partly by *how
stale its own data is*. The biggest numbers concentrate on the books that
moved most recently, which are the books most likely to have already moved
again. The top of a raw-EV leaderboard is enriched for prices that no longer
exist, and users experience this as "OddsJam sent me to a line that wasn't
there" without a number ever being attached to it.

So we attach one. Survival is modelled as exponential in quote age,
per (book, market class):

    P(still available at age t) = exp(-t / tau)

with tau — the mean seconds a quote survives — estimated from outcomes the
user's own betting produces. Exponential because it is memoryless, which is
close to true for a quote whose next move is triggered by external news, and
because it needs one parameter, which is all a single user's bet volume can
support. Something richer would fit the first hundred bets beautifully and
mean nothing.

The prior matters more than the fit for a long time: a new install has no
data, and the shipped defaults are the difference between a useful ranking on
day one and a coin flip. They are marked as priors and reported as priors.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

# Prior mean quote lifetimes in seconds, by market class. These are stated
# priors, not measurements — the honest form of a number nobody has yet
# measured on this install. They are deliberately pessimistic on fast markets:
# over-trusting a stale live price costs a rejected bet and an unhedged leg,
# while under-trusting one costs a missed opportunity, and only the first can
# leave a user one-sided on a settled game.
PRIOR_TAU: dict[str, float] = {
    "live": 8.0,
    "player_prop": 45.0,
    "alt_line": 60.0,
    "moneyline": 90.0,
    "spread": 90.0,
    "total": 90.0,
    "futures": 900.0,
    "default": 60.0,
}

# Weight of the prior in seconds-equivalent. With 20 observations the fitted
# value carries most of the weight; below that the prior dominates, which is
# the point — five bets should not overturn a shipped default.
PRIOR_STRENGTH = 20.0


def market_class(market_type: str) -> str:
    """Bucket a market type into a survival class.

    Buckets rather than raw types because a single user will never place
    enough bets on "player_points_alternate" to fit anything, but will place
    plenty across all alt lines.
    """
    m = market_type.lower()
    if "live" in m or "inplay" in m or "in_play" in m:
        return "live"
    if "prop" in m or "player" in m:
        return "player_prop"
    if "alt" in m:
        return "alt_line"
    if "future" in m or "outright" in m or "winner" in m:
        return "futures"
    if "spread" in m or "handicap" in m or "runline" in m or "puckline" in m:
        return "spread"
    if "total" in m or "over" in m or "under" in m:
        return "total"
    if "moneyline" in m or "h2h" in m or "ml" == m:
        return "moneyline"
    return "default"


# Assumed feed latency per book, in seconds, until measured. A stated prior,
# and deliberately not zero: every feed has some delay, and assuming none is
# the assumption that makes fill probability too optimistic. Two seconds is a
# conservative stand-in for a polling REST feed on a domestic connection —
# replaced by the measured value as soon as one quote carries both timestamps.
PRIOR_LATENCY = 2.0

# Latency is a property of the feed and the book, and it is far less variable
# than quote lifetime, so it converges much faster and needs a weaker prior.
LATENCY_PRIOR_STRENGTH = 5.0


@dataclass
class LatencyModel:
    """Measured feed latency per book: how stale a quote already is on arrival.

    This is the floor under every quote age, and therefore the ceiling on every
    fill probability. A feed running eight seconds behind DraftKings cannot
    honestly report a 94% fill on a quote it believes is six seconds old — the
    quote is fourteen seconds old and the eight were invisible.

    Kept separate from `FillModel` because they measure different things from
    different evidence: quote *lifetime* is fitted from accept/reject outcomes
    the user's betting produces, while *latency* is observed directly on every
    quote that carries both timestamps, whether or not anyone bets.
    """

    totals: dict[str, float] = field(default_factory=dict)
    counts: dict[str, int] = field(default_factory=dict)

    def observe(self, book: str, latency: float) -> None:
        if latency < 0:
            raise ValueError("latency cannot be negative")
        self.totals[book] = self.totals.get(book, 0.0) + latency
        self.counts[book] = self.counts.get(book, 0) + 1

    def observe_quote(self, quote) -> bool:
        """Record a quote's latency if it has one. True when it did."""
        latency = quote.latency
        if latency is None:
            return False
        self.observe(quote.book, latency)
        return True

    def typical(self, book: str) -> float:
        """Mean observed latency, shrunk toward the prior."""
        n = self.counts.get(book, 0)
        if n == 0:
            return PRIOR_LATENCY
        mean = self.totals[book] / n
        w = n / (n + LATENCY_PRIOR_STRENGTH)
        return w * mean + (1.0 - w) * PRIOR_LATENCY

    def is_measured(self, book: str) -> bool:
        """Whether this book's latency has been observed enough to trust.

        Exposed so the UI can label a latency as a prior rather than a
        measurement — the same rule the jurisdiction table and the calibrated
        weights already follow.
        """
        return self.counts.get(book, 0) >= 5

    def observations(self, book: str) -> int:
        return self.counts.get(book, 0)

    def to_dict(self) -> dict:
        return {"totals": dict(self.totals), "counts": dict(self.counts)}

    @classmethod
    def from_dict(cls, data: dict) -> "LatencyModel":
        model = cls()
        model.totals = dict((data or {}).get("totals", {}))
        model.counts = dict((data or {}).get("counts", {}))
        return model


@dataclass
class Observation:
    """One attempt to take a quote, and what the book did with it.

    `accepted` is the event being modelled. A price change that still leaves
    the bet +EV is not a fill for this purpose — the quote that was screened
    is gone either way, and modelling anything softer would fit a quantity
    nobody can act on.
    """

    book: str
    market: str
    age: float
    accepted: bool


@dataclass
class FillModel:
    """Per-(book, class) exponential survival, blended with a stated prior.

    tau is estimated from the accept/reject record by a closed-form that is
    exact for exponential survival: over a set of attempts at ages t_i with k
    accepted, the maximum-likelihood mean lifetime is sum(t_i) / (n - k) —
    total exposure over failures. With zero failures the estimate is
    unbounded, so it is capped rather than allowed to run away, and the cap is
    the honest statement that "nothing has been rejected yet" is not evidence
    that nothing ever will be.
    """

    taus: dict[tuple[str, str], float] = field(default_factory=dict)
    counts: dict[tuple[str, str], int] = field(default_factory=dict)
    _exposure: dict[tuple[str, str], float] = field(default_factory=dict)
    _failures: dict[tuple[str, str], int] = field(default_factory=dict)

    # No estimate is allowed above this many seconds. A book whose quotes
    # genuinely survive an hour is indistinguishable, at one user's volume,
    # from a book nobody has yet been rejected by.
    max_tau: float = 1800.0

    def tau(self, book: str, market_type: str) -> float:
        """Mean surviving lifetime for this book and market class."""
        cls = market_class(market_type)
        prior = PRIOR_TAU.get(cls, PRIOR_TAU["default"])
        key = (book, cls)

        n = self.counts.get(key, 0)
        if n == 0:
            return prior

        exposure = self._exposure.get(key, 0.0)
        failures = self._failures.get(key, 0)
        if failures == 0:
            fitted = self.max_tau
        else:
            fitted = min(self.max_tau, exposure / failures)

        # Shrink toward the prior in proportion to evidence.
        w = n / (n + PRIOR_STRENGTH)
        return w * fitted + (1.0 - w) * prior

    def p_fill(self, book: str, market_type: str, age: float) -> float:
        """Probability the quote is still takeable at this age.

        Clamped to [0.01, 1.0]. The floor exists so a very stale quote sorts
        to the bottom rather than to exactly zero: zero would make it
        indistinguishable from a market we have no model for, and those are
        different situations.
        """
        if age <= 0:
            return 1.0
        t = self.tau(book, market_type)
        return max(0.01, min(1.0, math.exp(-age / t)))

    def observe(self, obs: Observation) -> None:
        """Record one attempt.

        Exposure accumulates on every attempt and failures only on rejection,
        which is what makes the estimator a survival fit rather than a plain
        accept rate. An accept at 40s is evidence the quote lived *at least*
        40s; only a reject dates its death.
        """
        key = (obs.book, market_class(obs.market))
        self.counts[key] = self.counts.get(key, 0) + 1
        self._exposure[key] = self._exposure.get(key, 0.0) + max(0.0, obs.age)
        if not obs.accepted:
            self._failures[key] = self._failures.get(key, 0) + 1
        self.taus[key] = self.tau(obs.book, obs.market)

    def observations(self, book: str, market_type: str) -> int:
        return self.counts.get((book, market_class(market_type)), 0)

    def is_fitted(self, book: str, market_type: str) -> bool:
        """Whether this cell has enough data to have moved off the prior.

        Exposed so the UI can label a fill probability as a prior rather than
        a measurement. A number that looks fitted and isn't is worse than no
        number, because it stops the user from finding out.
        """
        return self.observations(book, market_type) >= 5

    def half_life(self, book: str, market_type: str) -> float:
        """Seconds until an even chance the quote is gone. The number to show
        a human — 'about 12 seconds' lands where 'tau = 17.3' does not."""
        return self.tau(book, market_type) * math.log(2.0)

    def to_dict(self) -> dict:
        return {
            "counts": {f"{b}|{c}": n for (b, c), n in self.counts.items()},
            "exposure": {f"{b}|{c}": v for (b, c), v in self._exposure.items()},
            "failures": {f"{b}|{c}": n for (b, c), n in self._failures.items()},
        }

    @classmethod
    def from_dict(cls, data: dict) -> "FillModel":
        def unpack(d: dict) -> dict:
            out = {}
            for k, v in (d or {}).items():
                book, _, klass = k.partition("|")
                out[(book, klass)] = v
            return out

        model = cls()
        model.counts = unpack(data.get("counts", {}))
        model._exposure = unpack(data.get("exposure", {}))
        model._failures = unpack(data.get("failures", {}))
        return model
