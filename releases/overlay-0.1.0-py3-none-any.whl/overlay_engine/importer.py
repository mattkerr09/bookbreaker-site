"""Reading a bet history out of a book's CSV export.

Pikkit and the rest solve this by linking sportsbook accounts and pulling bets
automatically. That means holding a user's sportsbook credentials, which this
project does not ask for and will not handle. Every major book exports bet
history as CSV, and that reaches the same place without them.

The work is almost entirely in the reading. No two books agree on a column
name, a date format, an odds format, or what "result" is called, and two of the
disagreements are actively dangerous:

**Payout is not profit.** Some exports give the total returned (stake included)
and some give the net. Reading a payout column as profit inflates every winning
bet by its own stake — a 200-bet record would show roughly double the real
return, and nothing downstream could tell. The two are detected separately,
never interchangeably, and a file offering only a payout has its profit derived.

**American and decimal odds overlap.** `2.5` is a decimal price; `250` is
American. The boundary is unambiguous in practice and `odds.parse_odds` already
encodes it, so odds go through there rather than through a second guess here.

Everything unreadable is skipped with a reason rather than defaulted, because a
bet imported with a guessed stake is worse than a bet not imported at all.
"""

from __future__ import annotations

import csv
import hashlib
import io
from dataclasses import dataclass, field
from pathlib import Path

from .ledger import RESULTS
from .odds import OddsError, parse_odds

# Header aliases, lowercased. Order matters only in that the first match wins,
# so the most specific alias comes first.
ALIASES: dict[str, tuple[str, ...]] = {
    "placed_at": ("date placed", "placed", "date", "placed at", "time",
                  "bet date", "wager date", "datetime"),
    "book": ("sportsbook", "book", "site", "bookmaker", "operator"),
    "sport": ("sport", "league", "competition"),
    "market_type": ("bet type", "market", "type", "wager type", "market type"),
    "outcome": ("selection", "pick", "bet", "description", "wager",
                "outcome", "event"),
    "event_id": ("event id", "event", "game", "match", "matchup"),
    "decimal_odds": ("odds", "price", "american odds", "decimal odds",
                     "line", "odds american"),
    "stake": ("stake", "wager amount", "risk", "amount", "bet amount",
              "wagered"),
    "result": ("result", "status", "settlement", "bet status"),
    "profit": ("profit", "net", "p/l", "pnl", "profit/loss", "win/loss",
               "net profit"),
    "payout": ("payout", "returned", "return", "total return", "collected",
               "to win"),
    "external_ref": ("bet id", "id", "reference", "ticket", "wager id",
                     "bet reference"),
}

# How books spell the four outcomes.
RESULT_WORDS: dict[str, str] = {
    "won": "won", "win": "won", "w": "won", "winner": "won", "cashed": "won",
    "half won": "won",
    "lost": "lost", "loss": "lost", "l": "lost", "lose": "lost",
    "half lost": "lost",
    "push": "push", "tie": "push", "tied": "push", "draw": "push",
    "void": "void", "cancelled": "void", "canceled": "void",
    "refunded": "void", "voided": "void", "returned": "void",
}

# Date formats seen in book exports, tried in order.
DATE_FORMATS = (
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
    "%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M", "%m/%d/%Y", "%m/%d/%y",
    "%d/%m/%Y %H:%M", "%d/%m/%Y", "%b %d, %Y", "%d %b %Y",
)


class ImportError_(ValueError):
    """A file that cannot be read as a bet history."""


@dataclass
class Skipped:
    """A row that was not imported, and why."""

    row: int
    reason: str


@dataclass
class ImportReport:
    """What one import did, including everything it declined."""

    imported: int = 0
    duplicates: int = 0
    skipped: list[Skipped] = field(default_factory=list)
    mapping: dict[str, str] = field(default_factory=dict)
    profit_source: str = "none"
    """`profit`, `payout` (derived), or `none`. Printed because reading a
    payout as a profit would inflate every winning bet by its own stake."""

    @property
    def rows(self) -> int:
        return self.imported + self.duplicates + len(self.skipped)

    def reasons(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for skip in self.skipped:
            head = skip.reason.split(":")[0]
            counts[head] = counts.get(head, 0) + 1
        return dict(sorted(counts.items(), key=lambda kv: -kv[1]))

    def describe(self) -> str:
        if not self.rows:
            return "nothing to import"
        parts = [f"imported {self.imported} of {self.rows}"]
        if self.duplicates:
            parts.append(f"{self.duplicates} already present")
        for reason, n in self.reasons().items():
            parts.append(f"{n} {reason}")
        return "; ".join(parts)


def detect_columns(headers: list[str]) -> dict[str, str]:
    """Map Overlay's fields onto a file's headers.

    Exact match on an alias, then a contains match — in that order, because
    "odds" is a substring of "odds american" and a contains-first pass would
    bind the wrong one on a file offering both.
    """
    lowered = {h.strip().lower(): h for h in headers if h}
    mapping: dict[str, str] = {}

    for field_name, aliases in ALIASES.items():
        for alias in aliases:
            if alias in lowered:
                mapping[field_name] = lowered[alias]
                break
        else:
            for alias in aliases:
                hit = next((orig for low, orig in lowered.items()
                            if alias in low), None)
                if hit:
                    mapping[field_name] = hit
                    break
    return mapping


def parse_date(text: str) -> float | None:
    """Read a timestamp in whatever form the book wrote it."""
    import datetime

    text = (text or "").strip()
    if not text:
        return None
    if text.replace(".", "", 1).isdigit():
        value = float(text)
        # Milliseconds if it is far beyond any plausible second-epoch date.
        return value / 1000.0 if value > 1e11 else value
    for fmt in DATE_FORMATS:
        try:
            return datetime.datetime.strptime(text, fmt).timestamp()
        except ValueError:
            continue
    return None


def parse_money(text: str) -> float | None:
    """Read an amount, tolerating currency symbols, commas and parentheses.

    Parentheses mean negative in exported ledgers — `(50.00)` is a loss of 50.
    Reading it as a positive would flip the sign of every losing bet in files
    that use the convention.
    """
    text = (text or "").strip()
    if not text:
        return None
    negative = text.startswith("(") and text.endswith(")")
    cleaned = text.strip("()").replace(",", "").replace("$", "").replace("£", "")
    cleaned = cleaned.replace("€", "").replace("+", "").strip()
    if not cleaned:
        return None
    try:
        value = float(cleaned)
    except ValueError:
        return None
    return -value if negative else value


def parse_result(text: str) -> str | None:
    """Normalise a book's word for how a bet finished."""
    word = (text or "").strip().lower()
    if not word:
        return None
    if word in RESULT_WORDS:
        return RESULT_WORDS[word]
    for key, value in RESULT_WORDS.items():
        if word.startswith(key):
            return value
    return None


def _ref(row: dict, mapping: dict, book: str, placed_at: float,
         outcome: str, stake: float, odds: float) -> str:
    """A stable reference for a row, so re-importing a file cannot duplicate it.

    Uses the book's own id where the export carries one. Otherwise a hash of
    the fields that identify a bet — a second $100 bet on the same selection at
    the same price and the same second is not a thing anyone does by accident,
    and treating it as a duplicate is the safer error.
    """
    given = (row.get(mapping.get("external_ref", ""), "") or "").strip()
    if given:
        return f"{book}:{given}"
    digest = hashlib.sha256(
        f"{book}|{placed_at:.0f}|{outcome}|{stake:.2f}|{odds:.4f}".encode()
    ).hexdigest()[:16]
    return f"{book}:auto:{digest}"


def import_rows(
    ledger,
    rows: list[dict],
    mapping: dict[str, str],
    default_book: str = "unknown",
    default_sport: str = "unknown",
) -> ImportReport:
    """Import parsed rows. Everything unreadable is skipped with a reason."""
    report = ImportReport(mapping=dict(mapping))
    has_profit = "profit" in mapping
    has_payout = "payout" in mapping
    report.profit_source = "profit" if has_profit else (
        "payout" if has_payout else "none")

    for i, row in enumerate(rows, start=2):  # row 1 is the header
        def value(field_name: str) -> str:
            column = mapping.get(field_name)
            return (row.get(column, "") or "").strip() if column else ""

        stake = parse_money(value("stake"))
        if stake is None or stake <= 0:
            report.skipped.append(Skipped(i, "no usable stake"))
            continue

        try:
            odds = parse_odds(value("decimal_odds"))
        except (OddsError, ValueError):
            report.skipped.append(Skipped(i, "no usable odds"))
            continue

        placed_at = parse_date(value("placed_at"))
        if placed_at is None:
            report.skipped.append(Skipped(i, "no usable date"))
            continue

        result = parse_result(value("result"))
        if value("result") and result is None:
            report.skipped.append(
                Skipped(i, f"unreadable result: {value('result')!r}"))
            continue

        # Payout includes the stake; profit does not. Deriving the wrong way
        # round inflates every winning bet by its own stake.
        profit = None
        if has_profit:
            profit = parse_money(value("profit"))
        elif has_payout:
            payout = parse_money(value("payout"))
            if payout is not None:
                profit = payout - stake if result != "void" else 0.0
        if profit is None and result in ("won", "lost", "push", "void"):
            profit = {"won": stake * (odds - 1.0), "lost": -stake,
                      "push": 0.0, "void": 0.0}[result]

        book = value("book") or default_book
        outcome = value("outcome") or "unknown"
        event_id = value("event_id") or f"import:{book}:{placed_at:.0f}"

        ref = _ref(row, mapping, book, placed_at, outcome, stake, odds)
        bet_id = ledger.import_bet(
            event_id=event_id,
            sport=value("sport") or default_sport,
            market_type=value("market_type") or "unknown",
            outcome=outcome,
            book=book,
            decimal_odds=odds,
            stake=stake,
            placed_at=placed_at,
            result=result,
            profit=profit,
            external_ref=ref,
            settled_at=placed_at,
        )
        if bet_id is None:
            report.duplicates += 1
        else:
            report.imported += 1

    return report


def import_csv(
    ledger,
    path: Path | str,
    mapping: dict[str, str] | None = None,
    **defaults,
) -> ImportReport:
    """Read a book's CSV export into the ledger."""
    path = Path(path)
    if not path.exists():
        raise ImportError_(f"no file at {path}")

    text = path.read_text(errors="replace")
    if not text.strip():
        raise ImportError_(f"{path} is empty")

    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        raise ImportError_(f"{path} has no header row")

    mapping = mapping or detect_columns(list(reader.fieldnames))
    missing = [f for f in ("stake", "decimal_odds", "placed_at")
               if f not in mapping]
    if missing:
        raise ImportError_(
            f"{path} is missing required column(s): {', '.join(missing)}. "
            f"Found headers: {', '.join(reader.fieldnames)}"
        )

    return import_rows(ledger, list(reader), mapping, **defaults)
