"""Account heat: how much like a bot the last few hours of betting look.

An account that gets limited stops earning. Edge you cannot place is worth
nothing, so account lifetime is not a side concern next to EV — it is the
denominator. Every competing tool optimises the numerator and leaves the
denominator to the user's judgement, which is why the standard experience is
three excellent weeks followed by a $5 maximum stake.

What this models is *bet shape*: stake sizes, timing, market mix, velocity.
These are documented, publicly discussed signals that risk desks profile on,
and they are all choices a bettor makes about their own betting.

What this deliberately does not do, and will not: anything that misrepresents
who is betting or from where. No multi-accounting, no identity or KYC
workarounds, no device or location spoofing. Those are fraud, not staking
discipline, and the line is drawn in code — the heat model consumes only bet
attributes, and has no access to identity or network state.

The model is a heat budget. Each bet adds heat by how mechanical it looks;
heat decays with time; a book over budget gets its stakes shaped, its edge
floor raised, or its bets deferred. It is spend-management for a resource
that is genuinely finite.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

from .models import Book, BookTier

# Weights per signal, summing to 1.0 at maximum. Ordered by how often each is
# named as a primary trigger in published risk-desk accounts: stake precision
# first, reaction time second.
W_STAKE_PRECISION = 0.28
W_REACTION_TIME = 0.24
W_VELOCITY = 0.18
W_MARKET_EXOTIC = 0.12
W_NO_RECREATION = 0.10
W_WIN_RATE = 0.08

# Heat halves every two hours. Fast enough that an evening's betting does not
# poison the next day, slow enough that twenty bets in ten minutes still reads
# as twenty bets in ten minutes.
HEAT_HALF_LIFE = 7200.0

# Above this, shape aggressively. A budget rather than a hard stop, because a
# hard stop would sit at zero on the books worth betting.
HEAT_BUDGET = 0.55


def stake_precision_heat(stake: float) -> float:
    """How mechanical a stake amount looks. 0 = human, 1 = calculator output.

    $473.82 is the canonical fingerprint. The ladder is: cents present at all
    is the loudest signal; a non-round whole number is next; multiples of 25,
    50 and 100 read as entirely ordinary.
    """
    cents = round(stake * 100) % 100
    if cents != 0:
        return 1.0
    whole = int(round(stake))
    for modulus, heat in ((100, 0.0), (50, 0.05), (25, 0.12), (10, 0.2), (5, 0.3)):
        if whole % modulus == 0:
            return heat
    return 0.75


def reaction_heat(seconds_since_line_move: float | None) -> float:
    """Heat from betting immediately after the market moved.

    Sub-second placement following a sharp move is the cleanest possible
    signal, because no human refreshes and decides that fast. Decays to
    nothing over about two minutes. `None` means unknown, scored at the middle
    rather than at zero — an unmeasured signal is not an absent one.
    """
    if seconds_since_line_move is None:
        return 0.5
    t = max(0.0, seconds_since_line_move)
    return math.exp(-t / 40.0)


def velocity_heat(bets_last_hour: int) -> float:
    """Heat from bet frequency at one book.

    A recreational bettor places a handful in an evening. The curve is flat
    to about three, then climbs, saturating near fifteen — beyond which more
    bets add no information because the profile is already unmistakable.
    """
    if bets_last_hour <= 3:
        return 0.0
    return min(1.0, (bets_last_hour - 3) / 12.0)


def market_heat(market_type: str) -> float:
    """Heat from betting where recreational money mostly isn't.

    Alt lines and obscure props concentrate arbitrage because they are priced
    with less attention — which is exactly why a book's risk desk reads a
    profile made of them as sharp. Main markets are ordinary; the exotics
    carry the signal.
    """
    m = market_type.lower()
    if "alt" in m:
        return 0.9
    if "prop" in m or "player" in m:
        return 0.6
    if "future" in m or "outright" in m:
        return 0.3
    return 0.05


@dataclass
class BetRecord:
    """One placed bet, in the terms the heat model reads."""

    book: str
    stake: float
    market_type: str
    placed_at: float
    seconds_since_line_move: float | None = None
    recreational: bool = False
    won: bool | None = None


@dataclass
class AccountHeat:
    """Rolling heat per book, with decay, and the shaping it implies."""

    history: list[BetRecord] = field(default_factory=list)

    def add(self, record: BetRecord) -> None:
        self.history.append(record)

    def _recent(self, book: str, now: float, window: float) -> list[BetRecord]:
        return [
            r
            for r in self.history
            if r.book == book and 0 <= now - r.placed_at <= window
        ]

    def bet_heat(self, record: BetRecord, now: float | None = None) -> float:
        """Heat contributed by a single bet, before decay."""
        now = time.time() if now is None else now
        last_hour = len(self._recent(record.book, now, 3600.0))

        heat = (
            W_STAKE_PRECISION * stake_precision_heat(record.stake)
            + W_REACTION_TIME * reaction_heat(record.seconds_since_line_move)
            + W_VELOCITY * velocity_heat(last_hour)
            + W_MARKET_EXOTIC * market_heat(record.market_type)
        )
        if record.recreational:
            # A genuinely recreational bet cools the profile rather than
            # merely not warming it — that is the whole reason to place one.
            heat *= 0.25
        return min(1.0, heat)

    def score(self, book: str, books: dict[str, Book] | None = None,
              now: float | None = None) -> float:
        """Current heat for a book, in [0, 1].

        Books that do not limit winners score zero. Spending anti-limiting
        effort at Pinnacle or on a prediction market gives up edge to buy
        protection from a risk desk that does not exist — the single most
        common way these tactics are applied wrongly.
        """
        now = time.time() if now is None else now
        if books:
            b = books.get(book)
            if b is not None and (not b.limits_winners or b.tier in (BookTier.SHARP, BookTier.EXCHANGE)):
                return 0.0

        recent = self._recent(book, now, HEAT_HALF_LIFE * 4)
        if not recent:
            return 0.0

        total = 0.0
        for r in recent:
            decay = 0.5 ** ((now - r.placed_at) / HEAT_HALF_LIFE)
            total += self.bet_heat(r, now=r.placed_at) * decay

        # Saturating rather than averaging: ten mechanical bets are worse than
        # one, and an average would rate them identically.
        base = 1.0 - math.exp(-total / 4.0)

        wins = [r.won for r in recent if r.won is not None]
        if len(wins) >= 20:
            rate = sum(1 for w in wins if w) / len(wins)
            if rate > 0.55:
                base += W_WIN_RATE * min(1.0, (rate - 0.55) / 0.15)

        recreational = sum(1 for r in recent if r.recreational)
        if len(recent) >= 10 and recreational == 0:
            base += W_NO_RECREATION

        return min(1.0, base)

    def bets_last_hour(self, book: str, now: float | None = None) -> int:
        now = time.time() if now is None else now
        return len(self._recent(book, now, 3600.0))

    def seconds_since_last(self, book: str, now: float | None = None) -> float | None:
        now = time.time() if now is None else now
        times = [r.placed_at for r in self.history if r.book == book]
        if not times:
            return None
        return now - max(times)


@dataclass(frozen=True)
class Shaping:
    """What the heat budget says to do with a bet before placing it."""

    stake: float
    delay: float
    min_edge: float
    defer: bool
    reason: str

    @property
    def acted(self) -> bool:
        return self.defer or self.delay > 0 or self.reason != ""


def shape(
    book: str,
    stake: float,
    edge: float,
    account: AccountHeat,
    books: dict[str, Book] | None = None,
    now: float | None = None,
    cooldown: float = 25.0,
) -> Shaping:
    """Decide how, whether and when to place a bet given current heat.

    Four levers, applied in order of how little edge they cost:

      1. **Round the stake.** Free. Removes the loudest signal outright.
      2. **Delay.** Costs a little fill probability, and only where the last
         bet at this book was recent enough to cluster with this one.
      3. **Raise the edge floor.** Costs marginal opportunities. A hot account
         should be spending its remaining lifetime on 4% edges, not 1.2% ones.
      4. **Defer.** Costs the whole bet, and is reserved for a hot account
         being offered an edge too small to be worth the account.

    Books that never limit get none of it — `Shaping` returns the request
    unchanged with an empty reason.
    """
    now = time.time() if now is None else now

    if books:
        b = books.get(book)
        if b is not None and (not b.limits_winners or b.tier in (BookTier.SHARP, BookTier.EXCHANGE)):
            return Shaping(stake=stake, delay=0.0, min_edge=0.0, defer=False, reason="")

    heat = account.score(book, books, now)

    from .arb import _step_for  # local: staking ladders live with the staking

    step = _step_for(stake)
    rounded = max(step, round(stake / step) * step)

    delay = 0.0
    since = account.seconds_since_last(book, now)
    if since is not None and since < cooldown:
        delay = cooldown - since

    min_edge = 0.0
    defer = False
    reasons: list[str] = []

    if abs(rounded - stake) > 0.005:
        reasons.append(f"stake rounded {stake:.2f} -> {rounded:.0f}")

    if heat >= HEAT_BUDGET:
        min_edge = 0.04
        delay = max(delay, 45.0)
        reasons.append(f"heat {heat:.0%} over budget")
        if edge < min_edge:
            defer = True
            reasons.append(f"edge {edge:.2%} below hot-account floor {min_edge:.0%}")
    elif heat >= HEAT_BUDGET * 0.6:
        min_edge = 0.02
        delay = max(delay, 15.0)
        reasons.append(f"heat {heat:.0%} elevated")

    hourly = account.bets_last_hour(book, now)
    if hourly >= 8:
        defer = True
        reasons.append(f"{hourly} bets at this book in the last hour")

    return Shaping(
        stake=rounded,
        delay=delay,
        min_edge=min_edge,
        defer=defer,
        reason="; ".join(reasons),
    )
