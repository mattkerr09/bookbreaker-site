"""Middles: two bets that can both win, and the honest odds of that happening.

Bet over 220.5 at one book and under 223.5 at another. If the game lands on
221, 222 or 223, both bets win. Outside that window one wins and one loses, so
the position costs a little — the vig on the pair — and the middle is the
payoff.

Pricing that hinges entirely on **P(the result lands in the window)**, and this
is where every tool in the category is casually wrong. Results are not smoothly
distributed. NFL margins pile up on 3 and 7 because of how the sport scores,
so a 2.5/3.5 middle is worth far more than a smooth curve says and a 4.5/5.5
middle far less. A normal approximation gets the *shape* wrong in exactly the
place the whole bet lives.

So the window probability comes from counted results when there are enough of
them, and from the normal approximation when there are not — and every
`MiddlePlan` says which, because a middle priced off a smooth curve and one
priced off two thousand real games are different claims and should not print
identically.

**Nothing here ships a margin distribution.** No published table this build
could verify covers every margin with its sample size, and inventing one would
be exactly the number-you-did-not-measure the rest of this repo refuses. The
model counts what the ledger has recorded and declines to speak below
`MIN_GAMES`.
"""

from __future__ import annotations

import math

from dataclasses import dataclass, field

from .arb import _step_for, ideal_stakes
from .models import Book, Market, Quote
from .odds import decimal_to_prob

# Recorded games needed before a counted distribution is trusted over the
# normal approximation. Below this the tail is all zeros — a margin that has
# not happened yet in 40 games is not a margin with probability zero, and
# treating it as one would price some middles at infinity and others at nothing.
MIN_GAMES = 200

# Totals need more games than margins for the same confidence, and the reason
# is structural rather than a matter of taste. A margin distribution is folded
# — |home - away| — so it piles onto a handful of small integers. A totals
# distribution is not folded and spreads across a much wider range, so the same
# 200 games buys far fewer observations per cell. Counting a totals window off
# 200 games would report a "counted" probability backed by a handful of games
# in the window, which is worse than an approximation because it does not
# announce itself.
MIN_TOTAL_GAMES = 400

# And a game count alone is not the guard. What matters is observations per
# occupied cell, which is measured from the data rather than assumed — a sport
# whose totals happen to concentrate needs fewer games than one that sprawls.
MIN_PER_CELL = 8.0

# Stated priors for the normal fallback, per market class, in points. Margin
# and total dispersion are not the same quantity and are not the same number
# for any sport. Both are replaced by the measured standard deviation as soon
# as the ledger holds enough games, and both are labelled wherever they surface.
PRIOR_SIGMA: dict[str, float] = {
    "spreads": 13.0,
    "totals": 13.0,
}


@dataclass
class _CountedOutcomes:
    """Counted integer outcomes per sport, or nothing at all.

    Built from recorded final scores. It answers `is_measured` before it
    answers anything else, so a caller cannot mistake an empty table for a
    confident zero.

    Subclasses differ only in which column they read and how many games they
    demand. That is the whole of the difference between a margin distribution
    and a totals one at this level — and the thresholds are where it stops
    being cosmetic.
    """

    counts: dict[str, dict[int, int]] = field(default_factory=dict)

    #: overridden per subclass
    _MIN_GAMES: int = MIN_GAMES

    @staticmethod
    def _column(ledger, sport: str) -> list[int]:  # pragma: no cover - abstract
        raise NotImplementedError

    @classmethod
    def from_ledger(cls, ledger, sport: str | None = None):
        model = cls()
        sports = [sport] if sport else [
            r["sport"] for r in ledger.conn.execute(
                "SELECT DISTINCT sport FROM scores")
        ]
        for s in sports:
            bucket: dict[int, int] = {}
            for value in cls._column(ledger, s):
                bucket[value] = bucket.get(value, 0) + 1
            if bucket:
                model.counts[s] = bucket
        return model

    def games(self, sport: str) -> int:
        return sum(self.counts.get(sport, {}).values())

    def cells(self, sport: str) -> int:
        """Distinct outcomes actually observed. The denominator that decides
        whether a game count is thick or thin."""
        return len(self.counts.get(sport, {}))

    def per_cell(self, sport: str) -> float:
        """Observations per occupied cell, measured rather than assumed."""
        cells = self.cells(sport)
        return self.games(sport) / cells if cells else 0.0

    def is_measured(self, sport: str) -> bool:
        return self.games(sport) >= self._MIN_GAMES

    def sigma(self, sport: str) -> float | None:
        """Standard deviation of the recorded outcomes, or None.

        Used to replace the stated prior in the normal fallback. It needs a
        game count: a dispersion estimated off thirty games is not a
        measurement, it is a rumour with a decimal point.

        It deliberately does *not* apply the observations-per-cell rule that
        governs `TotalsModel.is_measured`. That rule exists because counting a
        three-point window off thin buckets is unreliable; a standard
        deviation uses every recorded game at once and does not care how they
        are bucketed. So a sport with plenty of games spread thin is declined
        for counting and still trusted for dispersion — which is the right
        answer to two different questions, not an inconsistency.
        """
        n = self.games(sport)
        if n < self._MIN_GAMES:
            return None
        bucket = self.counts[sport]
        mean = sum(v * c for v, c in bucket.items()) / n
        var = sum(c * (v - mean) ** 2 for v, c in bucket.items()) / n
        return math.sqrt(var)

    def p_value(self, sport: str, value: int) -> float | None:
        """Share of recorded games landing on exactly this outcome.

        None below the threshold — an unmeasured cell is not a zero, and the
        distinction decides whether a middle is priced or declined.
        """
        if not self.is_measured(sport):
            return None
        return self.counts[sport].get(value, 0) / self.games(sport)

    def p_window(self, sport: str, low: float, high: float) -> float | None:
        """Share of games landing strictly inside a half-point window.

        `low` and `high` are the two lines. A middle on 2.5/3.5 wins on a
        result of exactly 3, which is why the bounds are exclusive: a result
        *on* a line is a push there, not a win, and counting it would inflate
        every middle by the frequency of its own key number.
        """
        if not self.is_measured(sport):
            return None
        if high <= low:
            return 0.0
        n = self.games(sport)
        inside = sum(
            count for value, count in self.counts[sport].items()
            if low < value < high
        )
        return inside / n

    def key_numbers(self, sport: str, top: int = 5) -> list[tuple[int, float]]:
        """The most common outcomes, largest first. The lumps a smooth curve
        cannot reproduce, and the reason this class exists."""
        if not self.is_measured(sport):
            return []
        n = self.games(sport)
        ranked = sorted(self.counts[sport].items(), key=lambda kv: -kv[1])
        return [(value, count / n) for value, count in ranked[:top]]


@dataclass
class MarginModel(_CountedOutcomes):
    """Counted margin-of-victory frequencies per sport."""

    _MIN_GAMES: int = MIN_GAMES

    @staticmethod
    def _column(ledger, sport: str) -> list[int]:
        return ledger.margins(sport)

    def p_margin(self, sport: str, margin: int) -> float | None:
        """Share of recorded games decided by exactly this margin."""
        return self.p_value(sport, margin)


@dataclass
class TotalsModel(_CountedOutcomes):
    """Counted combined-score frequencies per sport.

    The same machinery as `MarginModel` pointed at a different column, with
    one difference that is not cosmetic: totals are not folded, so they spread
    over a far wider support and the same game count buys much thinner cells.

    `is_measured` therefore checks two things — the game count *and* the
    measured observations per occupied cell. A sport whose totals concentrate
    clears the second easily; one that sprawls does not, and it is declined
    rather than counted off a handful of games per bucket.
    """

    _MIN_GAMES: int = MIN_TOTAL_GAMES

    @staticmethod
    def _column(ledger, sport: str) -> list[int]:
        return ledger.totals(sport)

    def is_measured(self, sport: str) -> bool:
        return (self.games(sport) >= self._MIN_GAMES
                and self.per_cell(sport) >= MIN_PER_CELL)

    def p_total(self, sport: str, total: int) -> float | None:
        """Share of recorded games landing on exactly this combined score."""
        return self.p_value(sport, total)


@dataclass(frozen=True)
class MiddlePlan:
    """A staked middle, with the window probability and where it came from."""

    low_line: float
    high_line: float
    low_book: str
    high_book: str
    low_decimal: float
    high_decimal: float
    low_stake: float
    high_stake: float
    p_middle: float
    source: str
    """`counted` when derived from recorded games, `approximated` when from the
    normal fallback. Printed everywhere the probability is, because the two are
    different claims."""

    event_id: str = ""
    market_type: str = ""

    sigma: float = 0.0
    """Dispersion used by the approximation. Meaningless when `source` is
    `counted`, and carried anyway so a plan can be re-derived from itself."""

    sigma_source: str = ""
    """`measured` when the standard deviation came from recorded games,
    `prior` when it is a stated constant, `override` when the caller supplied
    it. A `counted` window does not use it; an `approximated` one is only as
    good as this field says it is."""

    @property
    def total_stake(self) -> float:
        return self.low_stake + self.high_stake

    @property
    def one_side_profit(self) -> float:
        """Profit when only one leg wins — the ordinary, likely outcome.

        Usually negative and small: the cost of holding the position. Reported
        as the *worse* of the two sides, because quoting the better one
        describes a position the bettor does not hold.
        """
        low_wins = self.low_stake * self.low_decimal - self.total_stake
        high_wins = self.high_stake * self.high_decimal - self.total_stake
        return min(low_wins, high_wins)

    @property
    def middle_profit(self) -> float:
        """Profit when the result lands in the window and both legs win."""
        return (self.low_stake * self.low_decimal
                + self.high_stake * self.high_decimal
                - self.total_stake)

    @property
    def ev(self) -> float:
        """Expected profit per unit staked."""
        if self.total_stake <= 0:
            return 0.0
        expected = (self.p_middle * self.middle_profit
                    + (1.0 - self.p_middle) * self.one_side_profit)
        return expected / self.total_stake

    @property
    def breakeven_p(self) -> float:
        """Window probability at which this middle is exactly break-even.

        The number to compare against, because it does not depend on any
        distribution — it is arithmetic on the two prices. A middle whose
        break-even is 4% and whose counted window is 11% is a bet; one where
        those are reversed is a story about key numbers.
        """
        swing = self.middle_profit - self.one_side_profit
        if swing <= 0:
            return 1.0
        return -self.one_side_profit / swing

    @property
    def measured(self) -> bool:
        return self.source == "counted"

    def describe(self) -> str:
        return (
            f"{self.low_book} {self.low_line:g} / {self.high_book} "
            f"{self.high_line:g}  window {self.p_middle:.1%} ({self.source}), "
            f"break-even {self.breakeven_p:.1%}, EV {self.ev:+.2%}"
        )


def window_probability(
    sport: str,
    low: float,
    high: float,
    model: MarginModel | None,
    sigma: float,
    projection: float | None = None,
) -> tuple[float, str]:
    """Window probability and its provenance.

    Counted when the ledger has enough games for this sport, otherwise the
    normal approximation — which is a real fallback and labelled as one, not a
    silent default. `projection` centres the approximation; without it the
    midpoint of the window is used, which is the most favourable assumption
    available and therefore the one to flag.
    """
    if model is not None:
        counted = model.p_window(sport, low, high)
        if counted is not None:
            return counted, "counted"

    from .arb import middle_probability

    centre = (low + high) / 2.0 if projection is None else projection
    return middle_probability(low - centre, high - centre, sigma), "approximated"


def sigma_for(sport: str, model, market_type: str,
              override: float | None = None) -> tuple[float, str]:
    """The dispersion to approximate with, and where it came from.

    Order: an explicit override, then the measured standard deviation of the
    recorded outcomes, then the stated prior for this market class. The prior
    is returned labelled `prior` so nothing downstream can present it as a
    measurement of the sport it is standing in for.
    """
    if override is not None:
        return override, "override"
    if model is not None:
        measured = model.sigma(sport)
        if measured is not None and measured > 0:
            return measured, "measured"
    return PRIOR_SIGMA.get(market_type, PRIOR_SIGMA["spreads"]), "prior"


def stake_middle(
    low_decimal: float,
    high_decimal: float,
    total: float,
    round_stakes: bool = True,
) -> tuple[float, float]:
    """Stake a middle so either single-leg outcome pays the same.

    Same solver shape as an arbitrage, and rounded for the same reason: a
    stake of $473.82 is the loudest fingerprint a risk desk reads, and a middle
    is placed at two retail books by definition.
    """
    lo, hi = ideal_stakes([low_decimal, high_decimal], total)
    if not round_stakes:
        return lo, hi
    step = _step_for(total / 2.0)
    return max(step, round(lo / step) * step), max(step, round(hi / step) * step)


def model_for(market_type: str, margin_model=None, totals_model=None):
    """The distribution that answers this market class, or None.

    A totals middle asked against a margin distribution gets a confident wrong
    answer: both are counts of small integers, both have a `p_window`, and
    nothing about the call site would look unusual. Dispatching here rather
    than at each call site is what stops that from being possible.
    """
    if market_type == "totals":
        return totals_model
    return margin_model


def find_middles(
    market: Market,
    books: dict[str, Book],
    sport: str | None = None,
    model: MarginModel | None = None,
    sigma: float | None = None,
    total: float = 1000.0,
    min_ev: float | None = None,
    now: float | None = None,
    totals_model: "TotalsModel | None" = None,
) -> list[MiddlePlan]:
    """Every middle available in one handicapped market, best EV first.

    A middle needs two quotes on *opposite* sides at *different* lines, with
    the window opening in the bettor's favour — over the lower number and under
    the higher one. The reverse pair (over the higher, under the lower) is not
    a middle at all; it is a market where both legs can lose, and reporting it
    as a middle would invert the sign of the whole position.
    """
    sport = sport or market.sport
    chosen = model_for(market.market_type, model, totals_model)
    spread, sigma_source = sigma_for(sport, chosen, market.market_type, sigma)
    lows: list[tuple[float, Quote]] = []
    highs: list[tuple[float, Quote]] = []

    for quote in market.quotes:
        line = quote.outcome.line
        if line is None:
            continue
        name = quote.outcome.name.lower()
        if name in ("over", "home"):
            lows.append((line, quote))
        elif name in ("under", "away"):
            highs.append((line, quote))

    plans: list[MiddlePlan] = []
    for low_line, low_q in lows:
        for high_line, high_q in highs:
            if high_line <= low_line:
                continue
            if low_q.book == high_q.book:
                # One book quoting both sides of a middle against itself is a
                # stale line, and betting both sides there is the loudest
                # possible signal to that book's risk desk.
                continue

            low_book = books.get(low_q.book) or Book(low_q.book, low_q.book)
            high_book = books.get(high_q.book) or Book(high_q.book, high_q.book)
            low_d = low_book.net_decimal(low_q.decimal)
            high_d = high_book.net_decimal(high_q.decimal)

            p, source = window_probability(
                sport, low_line, high_line, chosen, spread)
            lo_stake, hi_stake = stake_middle(low_d, high_d, total)

            plan = MiddlePlan(
                low_line=low_line, high_line=high_line,
                low_book=low_q.book, high_book=high_q.book,
                low_decimal=low_d, high_decimal=high_d,
                low_stake=lo_stake, high_stake=hi_stake,
                p_middle=p, source=source, sigma=spread,
                sigma_source=sigma_source,
                event_id=market.event_id, market_type=market.market_type,
            )
            if min_ev is not None and plan.ev < min_ev:
                continue
            plans.append(plan)

    plans.sort(key=lambda m: m.ev, reverse=True)
    return plans


def hold_cost(low_decimal: float, high_decimal: float) -> float:
    """What holding the position costs when the middle misses, per unit staked.

    Positive means the pair is an arbitrage before the middle is considered —
    rare, and worth surfacing separately, because it is a guaranteed profit
    with a free lottery ticket attached rather than a bet.
    """
    return 1.0 - (decimal_to_prob(low_decimal) + decimal_to_prob(high_decimal))
