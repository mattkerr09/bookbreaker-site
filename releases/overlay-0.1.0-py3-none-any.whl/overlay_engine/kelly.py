"""Stake sizing: Kelly, and the three reasons never to bet full Kelly.

Full Kelly maximises long-run growth *given the true probability*. You do not
have the true probability; you have a devigged estimate with an error bar from
`fair.py`. Kelly's optimum is sharply asymmetric around that error — betting
twice the correct fraction has negative growth, while betting half has about
three-quarters of the growth at a quarter of the variance. Overestimating the
edge is therefore much more expensive than underestimating it, and the edge
estimates here are exactly the kind that get overestimated.

So sizing is fractional by default, and the fraction is applied to `ev_low`
rather than `ev` — the edge that survives the least favourable devig. That
combination is conservative twice over, deliberately: a bankroll that survives
a bad model is worth more than one optimally sized for a good one.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

DEFAULT_FRACTION = 0.25

# Assumed correlation between simultaneous bets when nothing better is known.
# A stated prior, not a measurement.
DEFAULT_CORRELATION = 0.15

# No single bet takes more than this share of bankroll regardless of what
# Kelly says. Kelly on a genuine 30% edge at long odds asks for a quarter of
# the roll; on an edge that is really a stale line it asks for the same, and
# the cap is what makes the difference survivable.
MAX_SINGLE = 0.05


def kelly_fraction(decimal: float, prob: float) -> float:
    """Full-Kelly stake as a fraction of bankroll.

    f* = (qd - 1) / (d - 1) — edge over net odds. Negative for a -EV bet,
    returned as 0 rather than as a short position: you cannot lay at a
    sportsbook, and returning a negative fraction invites a caller to take its
    absolute value.
    """
    if decimal <= 1.0:
        raise ValueError("decimal odds must exceed 1.0")
    if not 0.0 <= prob <= 1.0:
        raise ValueError("probability must lie in [0, 1]")
    f = (prob * decimal - 1.0) / (decimal - 1.0)
    return max(0.0, f)


@dataclass(frozen=True)
class Sizing:
    """A recommended stake and every constraint that shaped it.

    `binding` names the constraint that actually set the number. Without it a
    user sees a stake and cannot tell whether the model is confident or the
    cap is doing all the work — which are different situations calling for
    different responses.
    """

    stake: float
    full_kelly: float
    fraction_used: float
    bankroll: float
    binding: str

    @property
    def bankroll_share(self) -> float:
        return self.stake / self.bankroll if self.bankroll else 0.0


def size_bet(
    decimal: float,
    prob: float,
    bankroll: float,
    fraction: float = DEFAULT_FRACTION,
    prob_low: float | None = None,
    p_fill: float = 1.0,
    book_max: float | None = None,
    max_single: float = MAX_SINGLE,
) -> Sizing:
    """Stake for one bet, under every constraint at once.

    `prob_low` is the conservative fair probability. When given it is the one
    Kelly sees; `prob` is kept only to report what full Kelly would have been,
    so the gap between the confident and the cautious size stays visible.

    `p_fill` does *not* scale the stake. A partially-likely fill is not a
    partially-sized bet — it either lands at this price or it does not, and
    shrinking the stake for it would size correctly for a bet nobody places.
    It belongs in ranking, which is `ev.py`'s job.
    """
    if bankroll <= 0:
        raise ValueError("bankroll must be positive")

    full = kelly_fraction(decimal, prob)
    used_prob = prob if prob_low is None else prob_low
    f = kelly_fraction(decimal, used_prob) * fraction

    binding = "kelly"
    if f > max_single:
        f = max_single
        binding = "max_single"

    stake = f * bankroll
    if book_max is not None and stake > book_max:
        stake = book_max
        binding = "book_max"

    return Sizing(
        stake=stake,
        full_kelly=full,
        fraction_used=fraction,
        bankroll=bankroll,
        binding=binding if stake > 0 else "no_edge",
    )


def simultaneous_scale(n_bets: int, correlation: float = DEFAULT_CORRELATION) -> float:
    """Shrink factor when several bets are live at once.

    Kelly assumes bets resolve one at a time. For genuinely *independent*
    simultaneous bets the individual optima are still right and this returns
    exactly 1.0 — shrinking them would be superstition, and pretending
    otherwise is the easy way to look prudent while being wrong.

    Correlation is what actually bites. Twelve overs on one game script, or
    every leg riding one starting pitcher, is one undiversified bet wearing
    twelve hats:

        scale = 1 / sqrt(1 + (n - 1) * rho)

    At rho = 1 that is 1/sqrt(n), the right answer for n copies of the same
    bet. The 0.15 default is a stated prior — an evening's bets in one sport
    share weather, pace and injury news — not a measurement, and it is the
    kind of number `calibrate.py` should replace from a realised-correlation
    record rather than leave asserted forever.
    """
    if n_bets <= 1:
        return 1.0
    if not 0.0 <= correlation <= 1.0:
        raise ValueError("correlation must lie in [0, 1]")
    return 1.0 / math.sqrt(1.0 + (n_bets - 1) * correlation)


def arb_free_roll(decimals: list[float], stakes: list[float]) -> float:
    """Return per unit staked of an already-staked position, worst case."""
    total = sum(stakes)
    if total <= 0:
        return 0.0
    return (min(s * d for s, d in zip(stakes, decimals)) - total) / total
