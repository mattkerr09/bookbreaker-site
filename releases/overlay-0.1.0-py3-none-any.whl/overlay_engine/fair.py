"""Fair value: what the market believes, before anyone's margin.

The chain is fixed and each step exists because skipping it produces a
specific, named error:

  1. Devig each book's *own complete market*. Mixing books here invents an
     edge out of the disagreement you were trying to measure.
  2. Blend the devigged beliefs, weighted by how much each book knows.
  3. Compare a single offered price to that blend.

Step 2's weights are the opinionated part. A retail book carries ~6% of a
sharp book's weight by default — not zero, because a soft book that has moved
is still information, and not equal, because a soft book that hasn't moved is
mostly information about its own inertia.

The blend happens in log-odds, not probability. Averaging probabilities near
0 or 1 is biased toward the middle: 0.02 and 0.10 average to 0.06, but the
prices those imply (+4900 and +900) average to about +2100, or 0.045. On
longshots — where a naive +EV screen finds most of its phantom edges — the
difference between those two numbers is larger than any edge worth betting.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from .devig import DevigSpread, devig_all
from .models import Book, BookTier, Market

# Probabilities are clamped away from the boundaries before the logit, which
# is undefined at 0 and 1. 1e-6 corresponds to about +99999900 in American
# odds — well past any real quote, so the clamp never binds on real data.
_EPS = 1e-6

# Minimum share of total weight a book needs before its disagreement widens
# the uncertainty band. See the note in `fair_value` — below this a book is
# evidence about the price and not evidence about the error.
_ENVELOPE_WEIGHT = 0.10


def _logit(p: float) -> float:
    p = min(max(p, _EPS), 1.0 - _EPS)
    return math.log(p / (1.0 - p))


def _expit(x: float) -> float:
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


@dataclass(frozen=True)
class FairValue:
    """A fair probability, its uncertainty, and what produced it.

    `low`/`high` combine two independent disagreements: between devig methods
    on one book, and between books. Both are real and neither is noise that
    more data would remove, so they are reported rather than smoothed. A
    caller that wants a single number can have `prob`; a caller deciding
    whether to risk money should look at `low`.
    """

    outcome: str
    prob: float
    low: float
    high: float
    contributors: dict[str, float]
    weight: float
    spreads: dict[str, DevigSpread]

    @property
    def uncertainty(self) -> float:
        return self.high - self.low

    @property
    def fair_decimal(self) -> float:
        return 1.0 / max(self.prob, _EPS)

    @property
    def anchored(self) -> bool:
        """Whether any sharp or exchange price contributed.

        A fair value assembled only from retail books is a poll of the people
        you intend to beat. It is computed, because it is better than nothing
        on a market no sharp book prices, and it is flagged, because betting
        it as though it were anchored is how a screen ends up recommending a
        soft book's own error back to itself.
        """
        return self.weight >= 0.5


def fair_value(
    market: Market,
    books: dict[str, Book],
    method_weights: dict[str, float] | None = None,
    book_weights: dict[str, float] | None = None,
) -> dict[str, FairValue]:
    """Fair probability for every outcome in a market.

    `method_weights` and `book_weights` are what calibration learns. Passing
    neither gives the documented defaults — equal across devig methods, tiered
    across books — so an uncalibrated install has a stated prior rather than a
    hidden one.
    """
    outcome_keys = market.outcomes()
    if len(outcome_keys) < 2:
        return {}

    per_book: dict[str, DevigSpread] = {}
    weights: dict[str, float] = {}

    for book_key in market.complete_books():
        book = books.get(book_key) or Book(key=book_key, name=book_key)
        if book.tier is BookTier.UNKNOWN:
            continue

        quotes = market.by_book(book_key)
        decimals = [book.net_decimal(quotes[k].decimal) for k in outcome_keys]
        try:
            spread = devig_all(decimals)
        except Exception:
            # A book quoting an underround on its own market is quoting an
            # arb against itself: real, and not a source of fair value.
            continue

        w = book.weight if book_weights is None else book_weights.get(book_key, book.weight)
        if w <= 0.0:
            continue
        per_book[book_key] = spread
        weights[book_key] = w

    if not per_book:
        return {}

    total_weight = sum(weights.values())
    out: dict[str, FairValue] = {}

    for i, key in enumerate(outcome_keys):
        blended = 0.0
        lo_blend = 0.0
        hi_blend = 0.0
        for book_key, spread in per_book.items():
            w = weights[book_key] / total_weight
            blended += w * _logit(spread.consensus(i, method_weights))
            lo_blend += w * _logit(spread.low(i))
            hi_blend += w * _logit(spread.high(i))

        prob = _expit(blended)
        lo = _expit(lo_blend)
        hi = _expit(hi_blend)

        # Books disagreeing with each other widens the band beyond what any
        # single book's devig spread shows. Without this a market where
        # Pinnacle says 55% and Circa says 51% would report the same
        # confidence as one where they agreed exactly.
        #
        # Only books carrying real weight widen it. A retail book contributing
        # 6% of the belief must not contribute 100% of the uncertainty — that
        # makes the band as wide as the softest book's error, which is the
        # noise the weighting exists to suppress. Left in, it silently killed
        # every genuine soft-book overlay whenever a second soft book was
        # priced worse, because the `robust` filter reads the low end.
        if len(per_book) > 1:
            points = [
                spread.consensus(i, method_weights)
                for book_key, spread in per_book.items()
                if weights[book_key] / total_weight >= _ENVELOPE_WEIGHT
            ]
            if points:
                lo = min(lo, min(points))
                hi = max(hi, max(points))

        out[key] = FairValue(
            outcome=key,
            prob=prob,
            low=lo,
            high=hi,
            contributors=dict(weights),
            weight=total_weight,
            spreads=dict(per_book),
        )

    return out


def consensus_decimal(fv: FairValue) -> float:
    """The price at which this bet would be exactly break-even."""
    return fv.fair_decimal
