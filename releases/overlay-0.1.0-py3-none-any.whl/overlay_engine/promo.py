"""Welcome offers and promotions: what they are really worth, and how to take
them.

Sign-up offers are the largest edge available to a new bettor and the one most
often taken badly. A "$1,000 bonus" is never worth $1,000, and the gap between
the headline and the realisable value is where the whole product is:

  - A **bonus bet** does not return its stake. A $100 bonus bet at even money
    wins $100, not $200, so it is worth roughly half its face value if bet
    naively — and about 75-80% if converted correctly.
  - A **deposit match** carries a rollover, and every dollar of rollover pays
    the book its hold. A 5x rollover on $500 costs about $110 in expected
    losses before a cent is withdrawable.
  - A **first-bet safety net** only pays out when the qualifying bet *loses*,
    which inverts the usual instinct about what to bet.

Each of those is a different optimisation, and each has a closed form. This
module computes them, and — the part that matters — reports the *guaranteed*
conversion alongside the headline, so a user can see what they are actually
being given.

Two rules run through it:

**Conversion means hedged, not hoped.** A bonus bet on a 12-to-1 longshot has
a wonderful expected value and converts to nothing 92% of the time. Every plan
here is a hedge with a guaranteed floor, and where a plan cannot be hedged it
says so instead of quoting the EV as though it were money.

**The playthrough cost is subtracted, always.** A rollover requirement is not
a condition, it is a price, and it is the number offers are designed to make
you not compute.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .odds import decimal_to_american


class OfferType(str, Enum):
    """The five shapes a US welcome offer comes in."""

    BET_AND_GET = "bet_and_get"
    """Place a small qualifying bet, receive bonus bets win or lose. The most
    common 2026 format. Nearly pure value: the only cost is the hold on the
    qualifying bet."""

    SAFETY_NET = "safety_net"
    """First bet refunded in bonus bets if it loses. Higher variance, and it
    inverts the instinct — you want the qualifying bet to be a *longshot*,
    because losing is what triggers the refund."""

    DEPOSIT_MATCH = "deposit_match"
    """Bonus funds matching a deposit, released against a rollover. The only
    format where the headline can be worth less than nothing."""

    PROFIT_BOOST = "profit_boost"
    """A percentage added to the profit of one bet. Worth most on longshots,
    because the boost multiplies profit and profit grows with the price."""

    NO_SWEAT = "no_sweat"
    """Marketing name for a safety net, sometimes with a cash rather than
    bonus refund. Modelled as SAFETY_NET with conversion 1.0 when the refund
    is genuinely cash."""


@dataclass(frozen=True)
class ConversionPlan:
    """A concrete two-leg plan with a guaranteed floor.

    `guaranteed` is what you keep whichever way the game goes. It is the only
    number here worth comparing between offers, and it is the one the
    promotional copy never contains.
    """

    free_leg_odds: float
    free_leg_stake: float
    hedge_odds: float
    hedge_stake: float
    guaranteed: float
    face_value: float
    note: str = ""

    @property
    def conversion(self) -> float:
        """Fraction of face value converted to cash, guaranteed."""
        return self.guaranteed / self.face_value if self.face_value else 0.0

    def describe(self) -> str:
        return (
            f"bonus {self.free_leg_stake:,.0f} at "
            f"{decimal_to_american(self.free_leg_odds):+.0f}, hedge "
            f"{self.hedge_stake:,.2f} at "
            f"{decimal_to_american(self.hedge_odds):+.0f} "
            f"-> {self.guaranteed:,.2f} guaranteed "
            f"({self.conversion:.1%} of face)"
        )


def bonus_bet_conversion(free_odds: float, hedge_odds: float,
                         amount: float) -> ConversionPlan:
    """Hedge a stake-not-returned bonus bet into guaranteed cash.

    Bonus bet `amount` on side A at `free_odds`; cash hedge on side B at
    `hedge_odds`. A wins: you collect amount*(dA - 1) and lose the hedge.
    B wins: the hedge pays h*dB and the bonus is gone.

        amount*(dA - 1) - h = h*(dB - 1)  ->  h = amount*(dA - 1)/dB

    Guaranteed profit is then amount*(dA - 1)*(dB - 1)/dB, and the conversion
    rate does not depend on the amount at all — only on the two prices.
    """
    if amount <= 0:
        raise ValueError("bonus amount must be positive")
    if free_odds <= 1.0 or hedge_odds <= 1.0:
        raise ValueError("decimal odds must exceed 1.0")

    hedge = amount * (free_odds - 1.0) / hedge_odds
    guaranteed = hedge * (hedge_odds - 1.0)

    return ConversionPlan(
        free_leg_odds=free_odds,
        free_leg_stake=amount,
        hedge_odds=hedge_odds,
        hedge_stake=hedge,
        guaranteed=guaranteed,
        face_value=amount,
    )


def conversion_rate(free_odds: float, hedge_odds: float) -> float:
    """Guaranteed fraction of a bonus bet's face value, for these two prices."""
    return (free_odds - 1.0) * (hedge_odds - 1.0) / hedge_odds


def fair_conversion_ceiling(free_odds: float) -> float:
    """Best possible conversion at these odds in a zero-vig market.

    With a fair hedge available, conversion collapses to (dA - 1)/dA:

        even money   50.0%
        +300         75.0%
        +1000        90.9%

    This is the ceiling every real plan is measured against, and it is why the
    stock advice is "convert a bonus bet on a longshot". It is also why the
    advice has a limit — longer odds mean a larger hedge stake, and the hedge
    is real money at a real book with a real maximum.
    """
    if free_odds <= 1.0:
        raise ValueError("decimal odds must exceed 1.0")
    return (free_odds - 1.0) / free_odds


def best_conversion(
    amount: float,
    candidates: list[tuple[float, float]],
    max_hedge: float | None = None,
) -> ConversionPlan | None:
    """Pick the best hedgeable pair from `(free_odds, hedge_odds)` candidates.

    `max_hedge` is the constraint the textbook advice omits. Converting a $100
    bonus at +1200 needs about $92 of hedge at the other book — fine — but at
    a $1,000 bonus it needs $920 sitting at a book that may cap you well below
    it. A plan whose hedge cannot be placed is not a plan.
    """
    best: ConversionPlan | None = None
    for free_odds, hedge_odds in candidates:
        try:
            plan = bonus_bet_conversion(free_odds, hedge_odds, amount)
        except ValueError:
            continue
        if max_hedge is not None and plan.hedge_stake > max_hedge:
            continue
        if best is None or plan.guaranteed > best.guaranteed:
            best = plan
    return best


@dataclass(frozen=True)
class OfferValue:
    """What an offer is worth after every cost that applies to it."""

    offer_type: OfferType
    headline: float
    expected: float
    guaranteed: float
    cost: float
    note: str = ""

    @property
    def headline_ratio(self) -> float:
        """Realisable value as a fraction of the advertised number.

        The single most useful figure in the module, and the reason the module
        exists: it converts "$1,000 BONUS" into "worth about $310 guaranteed".
        """
        return self.guaranteed / self.headline if self.headline else 0.0


def bet_and_get_value(
    qualifying_stake: float,
    qualifying_hold: float,
    bonus_amount: float,
    conversion: float = 0.75,
) -> OfferValue:
    """Value of "bet $5, get $200 in bonus bets".

    The bonus arrives whatever happens, so the only cost is the hold on the
    qualifying bet — cents. This is why the format dominates 2026: it is
    close to free money, and the entire game is converting the bonus bets
    well rather than winning the qualifier.
    """
    cost = qualifying_stake * qualifying_hold
    guaranteed = bonus_amount * conversion - cost
    return OfferValue(
        offer_type=OfferType.BET_AND_GET,
        headline=bonus_amount,
        expected=guaranteed,
        guaranteed=guaranteed,
        cost=cost,
        note=(
            f"qualifier costs {cost:.2f}; bonus converts at "
            f"{conversion:.0%}. The qualifying bet should be the lowest-hold "
            "market available — it is a fee, not a bet."
        ),
    )


def safety_net_value(
    stake: float,
    decimal: float,
    win_prob: float,
    conversion: float = 0.75,
    refund_cap: float | None = None,
) -> OfferValue:
    """Value of "first bet up to $X refunded in bonus bets if it loses".

    EV = q*stake*(d-1) - (1-q)*stake*(1 - c)

    At fair odds (q = 1/d) this collapses to stake * c * (d-1)/d, which rises
    with d. **So the qualifying bet should be a longshot**, which is the
    opposite of most people's instinct and the opposite of the right play on a
    bet-and-get. Losing is the event that pays; a longshot loses more often and
    wins bigger when it doesn't.

    `guaranteed` is 0. There is no hedge that locks a safety net — you either
    win the bet or hold bonus bets that still have to be converted. Reporting
    the EV as though it were guaranteed is the mistake this field prevents.
    """
    if not 0.0 <= win_prob <= 1.0:
        raise ValueError("probability must lie in [0, 1]")

    refund = stake if refund_cap is None else min(stake, refund_cap)
    win = win_prob * stake * (decimal - 1.0)
    lose = (1.0 - win_prob) * (refund * conversion - stake)
    expected = win + lose

    return OfferValue(
        offer_type=OfferType.SAFETY_NET,
        headline=stake,
        expected=expected,
        guaranteed=0.0,
        cost=stake * (1.0 - win_prob) * (1.0 - conversion),
        note=(
            f"premium over betting without the offer: "
            f"{safety_net_premium(refund, win_prob, conversion):,.2f}. "
            "Not hedgeable — the refund only exists if the bet loses. Longer "
            "odds are better: the refund is the payoff, and a longshot "
            f"collects it more often. But you lose the {stake:,.0f} stake "
            f"{1 - win_prob:.0%} of the time and hold bonus bets instead of "
            "cash, so size it against the losing branch, not the mean."
        ),
    )


def safety_net_premium(
    refund: float, win_prob: float, conversion: float = 0.75
) -> float:
    """The offer's value on its own, separate from the bet it rides on.

    A safety net's whole worth is `(1 - q) * refund * conversion` — the refund,
    times how often you collect it, times what a bonus bet is really worth. The
    underlying bet contributes its own EV, which at fair odds is zero.

    Keeping the two apart matters because the combined number looks
    implausible: a $1,000 safety net at +300 with 80% conversion is worth about
    $600, which reads like a mistake until you see that it is 75% × $1,000 ×
    0.8 and that the bet itself contributes nothing. It also makes clear that
    a *bad* underlying bet subtracts from the premium rather than being covered
    by it.
    """
    return (1.0 - win_prob) * refund * conversion


def optimal_safety_net_odds(
    candidates: list[tuple[float, float]],
    stake: float,
    conversion: float = 0.75,
) -> tuple[float, float] | None:
    """Pick the qualifying price that maximises a safety net's EV.

    `candidates` are `(decimal, fair_win_prob)` pairs. Taking real fair
    probabilities rather than assuming q = 1/d matters: the theory says "bet
    the longest price available", but real longshots carry the heaviest vig,
    and past some point the extra margin costs more than the extra refund
    frequency earns.
    """
    best = None
    best_ev = float("-inf")
    for decimal, prob in candidates:
        ev = safety_net_value(stake, decimal, prob, conversion).expected
        if ev > best_ev:
            best_ev = ev
            best = (decimal, prob)
    return best


def deposit_match_value(
    deposit: float,
    bonus: float,
    rollover: float,
    hold_per_bet: float = 0.045,
    rollover_includes_deposit: bool = True,
) -> OfferValue:
    """Value of a deposit match after its playthrough is paid for.

    Rollover is a price, not a condition. You must wager R times the qualifying
    base, and every dollar wagered pays the book its hold in expectation:

        cost = R * base * hold

    The default hold of 4.5% is the standard -110/-110 two-sided market, which
    is the cheapest thing most playthroughs allow. It is a *stated default*,
    not a measurement of any particular book, and it should be replaced by the
    real measured hold of the markets the user can actually use for rollover —
    many books exclude the low-hold ones precisely because of this arithmetic.

    The arithmetic has a clean break-even: a match where the bonus equals the
    deposit and the rollover covers both is worth nothing at a hold of exactly
    `1 / (2 * rollover)`. At the standard 10x that is **5%** — barely above the
    4.5% of a -110/-110 market, and below the hold of the restricted markets
    many books actually allow for playthrough. So a 100% match on $1,000 at 10x
    is worth about $100 for $20,000 of turnover if you can churn it at -110,
    and is worth *less than nothing* the moment the eligible markets are
    juicier than that. It is advertised in the same typeface as the good ones.

    `breakeven_hold` computes that threshold, because the useful question is
    never "is this offer good" but "how cheap does my rollover have to be".
    """
    if rollover < 0:
        raise ValueError("rollover cannot be negative")

    base = (deposit + bonus) if rollover_includes_deposit else bonus
    turnover = rollover * base
    cost = turnover * hold_per_bet
    net = bonus - cost

    return OfferValue(
        offer_type=OfferType.DEPOSIT_MATCH,
        headline=bonus,
        expected=net,
        guaranteed=0.0,
        cost=cost,
        note=(
            f"{rollover:g}x on {base:,.0f} = {turnover:,.0f} of turnover, "
            f"costing about {cost:,.0f} at {hold_per_bet:.1%} hold. "
            f"Break-even hold is {breakeven_hold(deposit, bonus, rollover, rollover_includes_deposit):.2%}. "
            + ("Worth taking." if net > 0 else
               "Negative — this offer costs more to unlock than it pays.")
        ),
    )


def breakeven_hold(
    deposit: float,
    bonus: float,
    rollover: float,
    rollover_includes_deposit: bool = True,
) -> float:
    """The hold at which a deposit match is worth exactly zero.

    bonus = rollover * base * hold, so hold = bonus / (rollover * base).

    This is the number to decide on. If your realistic churn hold is above it,
    the offer is a loss no matter how large the headline; if well below it, the
    only remaining question is whether the turnover is worth the time and the
    account heat it generates.
    """
    base = (deposit + bonus) if rollover_includes_deposit else bonus
    if rollover <= 0 or base <= 0:
        return float("inf")
    return bonus / (rollover * base)


def profit_boost_value(
    stake: float,
    decimal: float,
    win_prob: float,
    boost: float,
) -> OfferValue:
    """Value of a percentage profit boost on one bet.

    The boost applies to profit, and profit scales with the price, so a 50%
    boost is worth 50% of `stake * (d - 1) * q` — far more on a longshot than
    on a favourite. The common instinct to "use the boost on something safe"
    gives away most of it.

    Not hedgeable to a guaranteed profit in general: hedging the boosted leg
    at fair odds locks in the boost's value only when the hedge price is
    good enough, which `bonus_bet_conversion` handles for the bonus-bet case
    but which here depends on the boost pushing the leg past the hedge's
    implied total. `expected` is therefore the honest field.
    """
    if not 0.0 <= boost <= 5.0:
        raise ValueError("boost should be a fraction, e.g. 0.5 for +50%")

    base_profit = stake * (decimal - 1.0)
    boosted = base_profit * (1.0 + boost)
    expected = win_prob * boosted - (1.0 - win_prob) * stake
    unboosted = win_prob * base_profit - (1.0 - win_prob) * stake

    return OfferValue(
        offer_type=OfferType.PROFIT_BOOST,
        headline=base_profit * boost,
        expected=expected,
        guaranteed=0.0,
        cost=0.0,
        note=(
            f"boost adds {base_profit * boost:,.2f} of potential profit; "
            f"EV moves {expected - unboosted:+,.2f}. "
            "Use it on the longest price you are willing to bet — the boost "
            "multiplies profit, and profit grows with the odds."
        ),
    )


@dataclass(frozen=True)
class Offer:
    """A book's advertised welcome offer, in computable terms.

    Deliberately carries no dollar figures scraped from anywhere. Offer terms
    change weekly and vary by state; a hard-coded "$1,000 bonus" in a source
    file is a claim about someone else's product that starts rotting the day
    it is written. The catalogue holds *shapes*; amounts come from the user or
    a dated feed, and `terms_url` is where the truth lives.
    """

    book: str
    offer_type: OfferType
    terms_url: str = ""
    min_odds: float | None = None
    """Minimum decimal odds for a qualifying bet. Most books require -200 or
    better (1.50), which is the constraint that stops the naive "bet the
    longest price" advice from working on the qualifier."""
    bonus_expiry_days: int = 7
    rollover: float = 0.0
    rollover_includes_deposit: bool = True
    note: str = ""

    def qualifies(self, decimal: float) -> bool:
        return self.min_odds is None or decimal >= self.min_odds


# Offer *shapes* by book, as observed on 2026-08-17. No amounts: those change
# weekly, differ by state, and a stale number here would be read as current.
OFFER_SHAPES: dict[str, OfferType] = {
    "dk": OfferType.BET_AND_GET,
    "fd": OfferType.BET_AND_GET,
    "mgm": OfferType.SAFETY_NET,
    "caesars": OfferType.SAFETY_NET,
    "bet365": OfferType.BET_AND_GET,
    "fanatics": OfferType.BET_AND_GET,
    "hardrock": OfferType.BET_AND_GET,
    "betrivers": OfferType.SAFETY_NET,
    "thescore": OfferType.BET_AND_GET,
    "bally": OfferType.BET_AND_GET,
    "betfred": OfferType.BET_AND_GET,
    "betparx": OfferType.DEPOSIT_MATCH,
    "prime": OfferType.DEPOSIT_MATCH,
}

# Order to work through a state's offers. Bet-and-get first: it is nearly free
# and the bonus bets it produces are the cheapest possible practice at
# conversion, before any real money is at risk on a safety net.
PRIORITY = {
    OfferType.BET_AND_GET: 0,
    OfferType.SAFETY_NET: 1,
    OfferType.PROFIT_BOOST: 2,
    OfferType.NO_SWEAT: 1,
    OfferType.DEPOSIT_MATCH: 3,
}


def sequence(books: list[str]) -> list[tuple[str, OfferType]]:
    """The order to claim a set of welcome offers.

    Sequencing matters for a reason nobody mentions: converting a bonus bet
    needs a hedge at a *second* book, so the first account is worth little on
    its own. Opening two bet-and-get books before touching anything else means
    every later bonus has somewhere to be hedged.
    """
    known = [(b, OFFER_SHAPES[b]) for b in books if b in OFFER_SHAPES]
    return sorted(known, key=lambda t: (PRIORITY[t[1]], t[0]))


# --------------------------------------------------------------- holdings

# Below this many days, a promotion is worth chasing a worse conversion for.
# A bonus bet converted at 55% today beats the same one converted at 80%
# tomorrow if tomorrow is after it expires — and "it expired" is the most
# common way this money is lost.
URGENT_DAYS = 3.0

DAY = 86400.0


@dataclass(frozen=True)
class Holding:
    """A promotion you are holding, and what it is actually worth.

    `value` is never the face amount. A bonus bet does not return its stake, so
    a $100 bonus is worth roughly $50 bet naively and $75-80 hedged well — and
    exactly $0 the day after it expires. The headline number is the one thing
    about a promotion that is never true.
    """

    promo_id: int
    book: str
    kind: str
    amount: float
    conversion: float
    expires_at: float | None = None
    boost: float | None = None
    note: str = ""

    def days_left(self, now: float) -> float | None:
        if self.expires_at is None:
            return None
        return (self.expires_at - now) / DAY

    def expired(self, now: float) -> bool:
        return self.expires_at is not None and self.expires_at <= now

    def value(self, now: float) -> float:
        """What it is worth if converted well. Zero once it has lapsed."""
        if self.expired(now):
            return 0.0
        if self.kind == "profit_boost":
            # A boost adds `boost` to the profit of a bet you were going to
            # place anyway, so its value scales with the profit at stake rather
            # than with the stake itself.
            return self.amount * (self.boost or 0.0) * self.conversion
        return self.amount * self.conversion

    def urgent(self, now: float) -> bool:
        left = self.days_left(now)
        return left is not None and 0 < left <= URGENT_DAYS

    def describe(self, now: float) -> str:
        left = self.days_left(now)
        when = (
            "no stated expiry" if left is None
            else "EXPIRED" if left <= 0
            else f"{left:.1f} days left"
        )
        return (f"{self.book} {self.amount:,.0f} {self.kind} "
                f"-> {self.value(now):,.0f} ({when})")


def holdings(rows: list[dict], conversion: float = 0.75) -> list[Holding]:
    """Turn ledger promo rows into valued holdings.

    `conversion` is an assumption and is carried on every holding rather than
    folded silently into a total, because it depends on what hedge the user can
    actually place — the 80% plan needs eleven times the bonus sitting at
    another book, which most people do not have.
    """
    return [
        Holding(
            promo_id=r["id"], book=r["book"], kind=r["kind"],
            amount=r["amount"], conversion=conversion,
            expires_at=r["expires_at"], boost=r.get("boost"),
            note=r.get("note") or "",
        )
        for r in rows
    ]


@dataclass(frozen=True)
class HoldingsReport:
    """Everything held, everything urgent, and everything already lost."""

    live: list[Holding]
    expired: list[Holding]
    now: float
    conversion: float

    @property
    def value(self) -> float:
        return sum(h.value(self.now) for h in self.live)

    @property
    def face(self) -> float:
        return sum(h.amount for h in self.live)

    @property
    def urgent(self) -> list[Holding]:
        return sorted(
            (h for h in self.live if h.urgent(self.now)),
            key=lambda h: h.expires_at or 0.0,
        )

    @property
    def lost_to_expiry(self) -> float:
        """Face value of promotions that lapsed unused.

        The number nobody else shows, and the one that changes behaviour. Every
        other figure here is a forecast; this one already happened.
        """
        return sum(h.amount for h in self.expired)

    def verdict(self) -> str:
        if not self.live and not self.expired:
            return "no promotions recorded"
        parts = [
            f"holding {self.face:,.0f} face, worth about {self.value:,.0f} "
            f"at {self.conversion:.0%} conversion"
        ]
        if self.urgent:
            soonest = min(h.days_left(self.now) or 0 for h in self.urgent)
            parts.append(
                f"{len(self.urgent)} expiring within {URGENT_DAYS:.0f} days "
                f"(soonest in {soonest:.1f})"
            )
        if self.expired:
            parts.append(
                f"{self.lost_to_expiry:,.0f} face already lost to expiry"
            )
        return "; ".join(parts)


def report_holdings(ledger, conversion: float = 0.75,
                    now: float | None = None) -> HoldingsReport:
    """Value everything held, and total what has already been let go."""
    import time as _time

    now = _time.time() if now is None else now
    return HoldingsReport(
        live=holdings(ledger.promos(state="held", now=now), conversion),
        expired=holdings(ledger.promos(state="expired", now=now), conversion),
        now=now,
        conversion=conversion,
    )
