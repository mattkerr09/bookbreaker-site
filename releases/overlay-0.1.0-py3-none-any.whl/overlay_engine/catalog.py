"""Which books exist, where they are legal, and what each one costs you.

Three facts about a book decide everything downstream, and only one of them is
usually recorded anywhere:

  **Tier** — is this price evidence, or a product being sold? Sets fair-value
  weight (`fair.py`).
  **Limits winners** — does beating this book cost you the account? Sets
  whether anti-limiting shaping applies at all (`heat.py`).
  **Jurisdiction** — can this user legally hold the account? Sets whether the
  edge is reachable.

A screen that surfaces an arbitrage between two books the user cannot both
hold is not an opportunity, it is noise with a number attached. So state
filtering is not a settings page, it is the first filter in the pipeline.

## On the state data

State-by-state legality moves constantly — markets launch, operators withdraw,
and any table like this is a snapshot with a shelf life. So every entry carries
its source and the date it was read, `coverage_gaps()` names the jurisdictions
this file knows it does not cover, and `stale_days()` exists so the UI can say
"checked 60 days ago" rather than implying currency it does not have.

**This is a starting point for the user's own check, not legal advice.** The
book's own site is authoritative about whether it will accept them.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from .models import Book, BookTier

# When the operator/state table below was read, and from where. Any consumer
# showing this data should show this date next to it.
AS_OF = "2026-08-17"
SOURCE = "actionnetwork.com/legal-online-sports-betting/sportsbooks-by-state"
AS_OF_EPOCH = 1_786_924_800.0  # 2026-08-17T00:00:00Z, checked against
# datetime rather than typed from memory — the first value here was a year out
# and made a fresh table report itself as 365 days stale.


@dataclass(frozen=True)
class Venue:
    """A book, its economics, and where it operates."""

    key: str
    name: str
    tier: BookTier
    states: frozenset[str] = frozenset()
    commission: float = 0.0
    limits_winners: bool = True
    nationwide: bool = False
    note: str = ""
    verified: bool = True
    """False when this entry was added from a weaker source than SOURCE and
    has not been confirmed. Unverified venues are excluded from `for_state`
    unless explicitly asked for — an unverified 'legal here' is the one error
    in this table that could cost a user more than a missed bet."""

    def to_book(self) -> Book:
        return Book(
            key=self.key,
            name=self.name,
            tier=self.tier,
            commission=self.commission,
            limits_winners=self.limits_winners,
        )

    def available_in(self, state: str) -> bool:
        return self.nationwide or state.upper() in self.states

    @property
    def jurisdiction_unknown(self) -> bool:
        """True when this venue's availability was never established.

        Distinct from "not available here". Pinnacle and Polymarket carry no
        state list because we do not know theirs, not because we know it is
        empty — and those are different answers to give a user. `for_state`
        hides them by default and `include_unverified=True` surfaces them as
        "check this yourself", which is the only honest thing to say.
        """
        return not self.verified and not self.states and not self.nationwide


def _s(*states: str) -> frozenset[str]:
    return frozenset(states)


# Retail operators, by the states each was listed in on AS_OF. These are the
# books where the edge is — and where the account risk is.
_RETAIL = [
    # NH and OR are exclusive lottery contracts rather than open markets, which
    # is why DraftKings is the whole list in both.
    ("dk", "DraftKings", _s("AZ", "AR", "CO", "DC", "IA", "IL", "IN", "KS", "KY",
                            "LA", "MA", "MD", "MI", "MO", "NC", "NH", "NJ", "NY",
                            "OH", "OR", "PA", "TN", "VA", "VT", "WV", "WY")),
    ("fd", "FanDuel", _s("AZ", "AR", "CO", "CT", "IA", "IL", "IN", "KS", "KY",
                         "LA", "MA", "MD", "MI", "MO", "NC", "NJ", "NY", "OH",
                         "PA", "TN", "VA", "VT", "WV", "WY")),
    ("mgm", "BetMGM", _s("AZ", "CO", "DC", "IA", "IL", "IN", "KS", "KY", "LA",
                         "MA", "MD", "MI", "MO", "NC", "NJ", "OH", "PA", "TN",
                         "VA", "WV", "WY")),
    ("caesars", "Caesars", _s("AZ", "CO", "DC", "IA", "IL", "IN", "KS", "KY",
                              "LA", "MA", "MD", "ME", "MI", "MO", "NC", "NJ",
                              "NY", "OH", "PA", "TN", "VA", "WV", "WY")),
    ("bet365", "bet365", _s("AZ", "CO", "IA", "IL", "IN", "KS", "KY", "LA",
                            "MD", "MI", "MO", "NC", "NJ", "OH", "PA", "VA")),
    ("fanatics", "Fanatics", _s("AZ", "CO", "CT", "DC", "IA", "IL", "IN", "KS",
                                "KY", "LA", "MA", "MD", "MI", "MO", "NC", "NJ",
                                "NY", "OH", "PA", "TN", "VA", "VT", "WV", "WY")),
    ("hardrock", "Hard Rock Bet", _s("AZ", "CO", "FL", "IL", "IN", "MI", "TN",
                                     "VA")),
    ("thescore", "theScore Bet", _s("AZ", "CO", "IA", "IL", "IN", "KS", "KY",
                                    "LA", "MA", "MD", "MI", "MO", "NC", "NJ",
                                    "OH", "PA", "TN", "VA", "WV")),
    ("betrivers", "BetRivers", _s("DE", "MI", "NJ", "PA", "WV")),
    ("bally", "Bally Bet", _s("AZ", "CO", "IA", "IN", "MA", "NY", "OH", "VA")),
    ("betfred", "BetFred", _s("AZ", "CO", "IA", "LA", "NV", "OH", "PA", "WA")),
    ("betparx", "betPARX", _s("MD", "NJ", "PA")),
    ("betr", "Betr", _s("OH", "VA")),
    ("betly", "Betly", _s("OH", "TN", "WV")),
    ("prime", "Prime Sportsbook", _s("NJ", "PA")),
    ("wynn", "WynnBET", _s("MI", "NY")),
    ("superbook", "SuperBook", _s("NV")),
    ("underdog", "Underdog Sports", _s("NC")),
    # Lottery-run single-operator markets, read 2026-08-17. These sat in
    # COVERAGE_GAPS until now: each state licenses exactly one online book, so
    # the operator list is one row rather than a market.
    ("sportsbook-ri", "Sportsbook Rhode Island", _s("RI")),
    ("sports-bet-mt", "Sports Bet Montana", _s("MT")),
]

# Sharp books: low margin, high limits, and they do not limit winners. Their
# prices anchor fair value; betting them costs no account lifetime.
_SHARP = [
    Venue("circa", "Circa Sports", BookTier.SHARP,
          _s("CO", "IA", "IL", "KY", "MO", "NV"),
          limits_winners=False,
          note="posts early, takes size, does not limit winners"),
    Venue("pinnacle", "Pinnacle", BookTier.SHARP, frozenset(),
          limits_winners=False, verified=False,
          note="the standard fair-value anchor; not licensed in US states — "
               "check your own jurisdiction before assuming access"),
]

# Exchanges and prediction markets: commission instead of vig, and no
# bookmaker to be limited by. Structurally the best place for a consistent
# winner, and the reason `heat.py` spends no effort protecting these accounts.
_EXCHANGE = [
    Venue("kalshi", "Kalshi", BookTier.EXCHANGE, frozenset(), nationwide=True,
          commission=0.0, limits_winners=False,
          note="CFTC-regulated event contracts; fee schedule varies by market "
               "and is not a flat commission — set per-market before relying "
               "on a net price"),
    Venue("sporttrade", "Sporttrade", BookTier.EXCHANGE,
          _s("AZ", "CO", "NJ", "VA"), commission=0.02, limits_winners=False,
          note="exchange model, commission on winnings"),
    Venue("prophetx", "ProphetX", BookTier.EXCHANGE, frozenset(),
          commission=0.02, limits_winners=False, verified=False,
          note="peer-to-peer; availability unverified in this snapshot"),
    Venue("polymarket", "Polymarket", BookTier.EXCHANGE, frozenset(),
          commission=0.0, limits_winners=False, verified=False,
          note="US availability has changed repeatedly; unverified here on "
               "purpose rather than guessed at"),
    Venue("betfair", "Betfair Exchange", BookTier.EXCHANGE, frozenset(),
          commission=0.02, limits_winners=False, verified=False,
          note="not US-licensed; listed for non-US users"),
]

VENUES: dict[str, Venue] = {}
for _key, _name, _states in _RETAIL:
    VENUES[_key] = Venue(_key, _name, BookTier.RETAIL, _states)
for _v in _SHARP + _EXCHANGE:
    VENUES[_v.key] = _v


# Jurisdictions with legal online betting this table does not describe. Empty
# is the goal, and it is empty as of 2026-08-17 — the five lottery-run markets
# that were here are now catalogued with their single operator each.
COVERAGE_GAPS: dict[str, str] = {}

# States where betting is legal but only in person. Not a gap in this table —
# there is no online venue to catalogue, which is a different answer from "we
# have not looked" and was previously conflated with it. A user here is not
# missing data; they are missing an online market.
RETAIL_ONLY: dict[str, str] = {
    "MS": "retail sportsbooks only, no online betting",
    "NM": "tribal casinos only, no state-regulated online betting",
    "ND": "tribal casinos only, no state-regulated online betting",
    "SD": "Deadwood and tribal casinos only, no online betting",
    "WI": "tribal casinos only, no state-regulated online betting",
}

# Why a one-row operator list is a fact about the state rather than a thin
# table. Read 2026-08-17.
SINGLE_OPERATOR: dict[str, str] = {
    "NH": "an exclusive lottery contract with DraftKings",
    "OR": "an exclusive lottery partnership with DraftKings",
    "DE": "a lottery market run by BetRivers",
    "RI": "a lottery market run on the IGT platform",
    "MT": "a lottery market run by Intralot, where the app only works inside "
          "authorised Sports Bet Montana locations",
}

# States with no legal sports betting at all as of AS_OF. Listed so the UI can
# tell a user in one of them that the answer is "none", which is a real answer
# and better than an empty screen that looks like a bug.
NO_LEGAL_BETTING = frozenset(
    ("AL", "AK", "CA", "GA", "HI", "ID", "MN", "OK", "SC", "TX", "UT")
)


def for_state(state: str, include_unverified: bool = False) -> list[Venue]:
    """Venues a user in this state can plausibly hold, best-anchored first.

    Sorted sharp → exchange → retail, because that is the order in which they
    matter: without at least one sharp or exchange price there is no anchored
    fair value, and the +EV screen has nothing to measure against.
    """
    order = {BookTier.SHARP: 0, BookTier.EXCHANGE: 1,
             BookTier.RETAIL: 2, BookTier.UNKNOWN: 3}
    # Case-folded so bet365 and betPARX sort among the b's, not after theScore.
    out = [
        v for v in VENUES.values()
        if (v.available_in(state) and v.verified)
        or (include_unverified and (v.jurisdiction_unknown or v.available_in(state)))
    ]
    return sorted(out, key=lambda v: (order[v.tier], v.name.lower()))


def books_for_state(state: str, include_unverified: bool = False) -> dict[str, Book]:
    """`for_state` as the `{key: Book}` mapping the engine takes."""
    return {v.key: v.to_book() for v in for_state(state, include_unverified)}


def all_books() -> dict[str, Book]:
    """Every venue, ignoring jurisdiction. For backtests and offline work."""
    return {k: v.to_book() for k, v in VENUES.items()}


def has_anchor(state: str) -> bool:
    """Whether a state has any sharp or exchange price to anchor fair value.

    False means +EV numbers in that state rest on retail books alone — a poll
    of the people you intend to beat. `fair.py` already flags this per market;
    this answers it up front, before a user pays for a screen that cannot work
    where they live.
    """
    return any(
        v.tier in (BookTier.SHARP, BookTier.EXCHANGE) for v in for_state(state)
    )


def state_summary(state: str) -> dict:
    """Everything the UI needs to explain a jurisdiction in one call."""
    st = state.upper()
    venues = for_state(st)
    return {
        "state": st,
        "legal": st not in NO_LEGAL_BETTING,
        "covered": st not in COVERAGE_GAPS,
        "gap_reason": COVERAGE_GAPS.get(st, ""),
        "online": st not in RETAIL_ONLY and st not in NO_LEGAL_BETTING,
        "retail_only": RETAIL_ONLY.get(st, ""),
        "single_operator": SINGLE_OPERATOR.get(st, ""),
        "venues": len(venues),
        "retail": sum(1 for v in venues if v.tier is BookTier.RETAIL),
        "anchors": sum(
            1 for v in venues
            if v.tier in (BookTier.SHARP, BookTier.EXCHANGE)
        ),
        "has_anchor": has_anchor(st),
        "never_limit": [v.key for v in venues if not v.limits_winners],
        "as_of": AS_OF,
        "stale_days": stale_days(),
    }


def stale_days(now: float | None = None) -> int:
    """Days since the operator table was read.

    Exists so no screen can show this data without being able to say how old
    it is. A jurisdiction table presented without its age asserts "true now",
    forever.
    """
    now = time.time() if now is None else now
    return max(0, int((now - AS_OF_EPOCH) // 86400))


def coverage_gaps() -> dict[str, str]:
    return dict(COVERAGE_GAPS)


def retail_only() -> dict[str, str]:
    return dict(RETAIL_ONLY)


def single_operator() -> dict[str, str]:
    return dict(SINGLE_OPERATOR)
