"""Closing line value: the only honest scoreboard, and the learning signal.

Profit over a few hundred bets says almost nothing. A 2% edge over 500 bets at
even money has a standard deviation of about 4.5% of turnover — losing months
are routine and winning months prove nothing. Waiting for profit to confirm a
model means waiting years, and adjusting a model on early profit means fitting
noise.

Closing line value converges far faster. The closing line is the market's best
public estimate, and beating it consistently is the standard evidence that an
edge is real. So CLV is used here twice:

  - as the user's scoreboard, in place of a profit curve that cannot yet
    say anything;
  - as the *supervision signal* for every learned parameter in the system.

That second use is what makes the product improve. `calibrate.py` reads the
CLV record and adjusts devig-method weights, book weights and fill priors
toward whatever actually predicted closing prices — per sport and per market,
because the right answer differs between an NBA total and a tennis outright.
Nothing here is tuned by opinion; it is tuned by the record, which is the
difference between a tool that ships an author's beliefs and one that learns
the user's markets.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from .devig import METHODS, devig_all
from .odds import decimal_to_prob


@dataclass
class GradedBet:
    """A settled bet with everything needed to grade the decision, not the
    result.

    `closing_fair_prob` is the devigged closing price from a sharp book, not
    the raw closing price. Grading against a vigged number would score every
    bet as worse than it was, by the size of the closing margin.
    """

    bet_id: str
    sport: str
    market_type: str
    book: str
    decimal: float
    stake: float
    fair_prob_at_bet: float
    closing_fair_prob: float
    devig_method: str = ""
    won: bool | None = None
    profit: float | None = None

    @property
    def clv(self) -> float:
        """Edge against the closing line, per unit staked.

        Positive means the price beaten was better than where the market
        settled. This is EV computed with hindsight's fair probability.
        """
        return self.closing_fair_prob * self.decimal - 1.0

    @property
    def beat_close(self) -> bool:
        return self.clv > 0.0

    @property
    def model_error(self) -> float:
        """Signed error of the fair value used when betting.

        Positive means the model was more optimistic than the close — the
        direction that manufactures phantom edges, and the one worth watching.
        """
        return self.fair_prob_at_bet - self.closing_fair_prob


def closing_fair(closing_decimals: list[float], index: int, method: str = "power") -> float:
    """Devigged fair probability of one outcome at close."""
    return devig_all(closing_decimals).by_method.get(
        method, devig_all(closing_decimals).by_method["multiplicative"]
    )[index]


@dataclass
class CLVReport:
    """Aggregate CLV, with the standard error that says whether to believe it.

    A 1.2% mean CLV over 30 bets is not evidence of anything. Reporting the
    mean without its error is how a user concludes they have an edge from a
    sample that cannot support the claim — the same failure the devig band
    exists to prevent one layer up.
    """

    n: int
    mean_clv: float
    stdev: float
    beat_rate: float
    total_staked: float
    by_book: dict[str, float] = field(default_factory=dict)
    by_market: dict[str, float] = field(default_factory=dict)

    @property
    def standard_error(self) -> float:
        return self.stdev / math.sqrt(self.n) if self.n > 1 else float("inf")

    @property
    def t_stat(self) -> float:
        se = self.standard_error
        return self.mean_clv / se if se > 0 and math.isfinite(se) else 0.0

    @property
    def significant(self) -> bool:
        """Two standard errors clear of zero, and at least 30 bets.

        Both conditions, because a t-statistic on 8 bets is arithmetic rather
        than evidence.
        """
        return self.n >= 30 and self.t_stat > 2.0

    def verdict(self) -> str:
        if self.n < 30:
            return f"{self.n} bets — too few to say anything; need 30+"
        if self.significant:
            return f"beating the close by {self.mean_clv:.2%} (t={self.t_stat:.1f})"
        if self.mean_clv > 0:
            return (
                f"{self.mean_clv:.2%} CLV but not significant "
                f"(t={self.t_stat:.1f}); consistent with no edge"
            )
        return f"losing to the close by {abs(self.mean_clv):.2%}"


def report(bets: list[GradedBet]) -> CLVReport:
    """Aggregate a set of graded bets."""
    if not bets:
        return CLVReport(n=0, mean_clv=0.0, stdev=0.0, beat_rate=0.0, total_staked=0.0)

    clvs = [b.clv for b in bets]
    n = len(clvs)
    mean = sum(clvs) / n
    if n > 1:
        var = sum((c - mean) ** 2 for c in clvs) / (n - 1)
        stdev = math.sqrt(var)
    else:
        stdev = 0.0

    def grouped(key) -> dict[str, float]:
        buckets: dict[str, list[float]] = {}
        for b in bets:
            buckets.setdefault(key(b), []).append(b.clv)
        return {k: sum(v) / len(v) for k, v in buckets.items()}

    return CLVReport(
        n=n,
        mean_clv=mean,
        stdev=stdev,
        beat_rate=sum(1 for b in bets if b.beat_close) / n,
        total_staked=sum(b.stake for b in bets),
        by_book=grouped(lambda b: b.book),
        by_market=grouped(lambda b: b.market_type),
    )


def method_scores(
    bets: list[GradedBet],
    candidate_probs: dict[str, list[float]],
) -> dict[str, float]:
    """Score each devig method by how well it predicted the closing line.

    `candidate_probs[method][i]` is what that method would have said about
    bet `i`. Scoring is mean squared error against the closing fair
    probability — a proper scoring rule, so a method cannot win by being
    systematically timid or systematically bold.

    This is the function that makes the tool improve. Run over a growing bet
    log per sport and market, it answers empirically the question every other
    tool answers by assertion: which devig method is right *here*.
    """
    scores: dict[str, float] = {}
    for method, probs in candidate_probs.items():
        if len(probs) != len(bets) or not bets:
            continue
        scores[method] = sum(
            (p - b.closing_fair_prob) ** 2 for p, b in zip(probs, bets)
        ) / len(bets)
    return scores


def weights_from_scores(scores: dict[str, float], floor: float = 0.05) -> dict[str, float]:
    """Turn squared errors into blend weights.

    Inverse-error weighting, floored. The floor matters: a method that looks
    worst over 40 bets should be demoted, not deleted, because 40 bets cannot
    distinguish a bad method from an unlucky one, and a deleted method never
    gets the chance to come back.
    """
    if not scores:
        return {m: 1.0 / len(METHODS) for m in METHODS}
    if floor * len(scores) >= 1.0:
        raise ValueError(
            f"floor {floor} leaves no room for {len(scores)} methods to differ"
        )

    inv = {m: 1.0 / max(s, 1e-9) for m, s in scores.items()}
    total = sum(inv.values())

    # Reserve the floor first, then distribute what remains by inverse error.
    # Flooring after normalising and renormalising again would push the worst
    # method back below the floor — the exact outcome the floor exists to
    # prevent, arrived at by applying it.
    room = 1.0 - floor * len(scores)
    return {m: floor + room * (v / total) for m, v in inv.items()}


def implied_clv(bet_decimal: float, closing_decimal: float) -> float:
    """CLV from raw prices when no full closing market is available.

    A fallback. It compares two vigged prices and so understates CLV by the
    closing margin — usable for ranking bets against each other, not for
    claiming an edge size. Named `implied` rather than `clv` so the two cannot
    be mixed in one average by accident.
    """
    return decimal_to_prob(closing_decimal) * bet_decimal - 1.0
