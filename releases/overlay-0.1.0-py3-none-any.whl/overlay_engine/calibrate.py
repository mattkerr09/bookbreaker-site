"""Turning the record into better numbers — and refusing to when it can't.

This is the module that makes the product improve rather than merely claim to.
It reads the graded bet log, works out which devig method actually predicted
closing lines, and writes those weights back for `fair_value` to use.

Three things make it a calibration rather than an overfit:

**The hold-out is by time, never at random.** Consecutive bets cluster — same
event, same market, same evening, often the same line moving. A random split
puts near-duplicates on both sides, so the held-out slice is partly a copy of
the training slice and *any* candidate scores well on it. Splitting on time
asks the only question worth asking: do weights fitted on what I did last
month predict what I did this week?

**A candidate has to beat the incumbent out of sample or it is thrown away.**
Calibration must be able to make things worse and be caught doing it. Without
that gate this file would be a very expensive way to fit noise, and it would
look identical from outside — weights would change, numbers would move, and
nothing would get better.

**It refuses below 30 graded bets, out loud.** The same floor
`clv.CLVReport.significant` enforces. Silently producing weights from twelve
bets would be worse than producing none, because the resulting numbers carry
the *appearance* of measurement.

One deliberate consistency: methods are scored under the same blend
`DevigSpread.consensus` actually performs — a weighted arithmetic mean in
probability space. Calibrating a blend the engine does not use is a silent
error that produces confident, wrong weights, and it is invisible unless you
go looking for it.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .clv import GradedBet, method_scores, weights_from_scores
from .models import Book
from .staleness import market_class

# Below this many graded bets, refuse. Matches the floor `clv` uses to call a
# CLV figure significant — the same evidence bar, applied to the thing that
# consumes the evidence.
MIN_GRADED = 30

# Fraction of the log held out, taken from the most recent end.
HOLDOUT = 0.3

# A candidate must beat the incumbent by more than this to be written. Two
# sets of weights differing in the seventh decimal are the same weights, and
# rewriting on noise churns the stored value and resets its age for nothing.
MIN_IMPROVEMENT = 1e-6

SETTING_PREFIX = "method_weights"


def scope_key(sport: str | None, market: str | None) -> str:
    """Settings key for a calibration scope.

    Scoped by `(sport, market class)` because the right devig method is not a
    universal fact. Favourite-longshot bias differs between an NBA moneyline
    and a tennis outright, which is exactly why `devig.py` refuses to pick one
    globally in the first place.
    """
    if sport is None and market is None:
        return f"{SETTING_PREFIX}.global"
    return f"{SETTING_PREFIX}.{sport or 'any'}.{market or 'any'}"


def blended(probs: dict[str, float], weights: dict[str, float] | None) -> float:
    """Blend per-method probabilities exactly as `DevigSpread.consensus` does.

    Kept in step with that method on purpose. If the two ever diverge, this
    file optimises a quantity the engine never computes, and the weights it
    writes are confidently wrong in a way no test of either half would catch.
    """
    if not probs:
        raise ValueError("cannot blend an empty probability set")
    if not weights:
        return sum(probs.values()) / len(probs)
    used = {m: w for m, w in weights.items() if m in probs and w > 0}
    if not used:
        return sum(probs.values()) / len(probs)
    total = sum(used.values())
    return sum(probs[m] * w for m, w in used.items()) / total


def score(
    bets: list[GradedBet],
    candidates: dict[str, list[float]],
    weights: dict[str, float] | None,
) -> float:
    """Mean squared error of a weighted blend against the closing line.

    A proper scoring rule, so a set of weights cannot win by being
    systematically timid or systematically bold — only by being closer.
    """
    if not bets:
        return float("inf")
    total = 0.0
    for i, bet in enumerate(bets):
        probs = {m: series[i] for m, series in candidates.items()}
        total += (blended(probs, weights) - bet.closing_fair_prob) ** 2
    return total / len(bets)


@dataclass
class Calibration:
    """The outcome of one calibration attempt, including the refusals.

    `accepted` is the only field that changes behaviour, and `reason` is why —
    a calibration that declined is a normal, frequent result, not an error, and
    it has to be legible or the loop looks broken every time it correctly does
    nothing.
    """

    scope: str
    n: int
    n_train: int = 0
    n_holdout: int = 0
    weights: dict[str, float] = field(default_factory=dict)
    incumbent_score: float = float("inf")
    candidate_score: float = float("inf")
    accepted: bool = False
    reason: str = ""

    @property
    def improvement(self) -> float:
        """How much the candidate beat the incumbent out of sample.

        Negative when the candidate is worse — which is the case the hold-out
        exists to find, and the case that gets thrown away.
        """
        if not (self.incumbent_score < float("inf")):
            return 0.0
        return self.incumbent_score - self.candidate_score

    def describe(self) -> str:
        if not self.accepted:
            return f"{self.scope}: not calibrated — {self.reason}"
        return (
            f"{self.scope}: calibrated on {self.n_train} bets, verified on "
            f"{self.n_holdout} — out-of-sample error "
            f"{self.incumbent_score:.6f} -> {self.candidate_score:.6f}"
        )


def split(bets: list[GradedBet], holdout: float = HOLDOUT) -> int:
    """Index where the held-out tail begins, splitting on time order.

    `graded_bets` returns in `placed_at` order, so a positional split is a
    temporal one. At least one bet on each side, always — a hold-out of zero
    would silently turn the gate off and accept every candidate.
    """
    if not 0.0 < holdout < 1.0:
        raise ValueError("holdout must lie strictly between 0 and 1")
    n = len(bets)
    cut = n - max(1, int(round(n * holdout)))
    return max(1, min(cut, n - 1))


def calibrate_methods(
    ledger,
    sport: str | None = None,
    market: str | None = None,
    holdout: float = HOLDOUT,
    min_graded: int = MIN_GRADED,
    write: bool = True,
) -> Calibration:
    """Fit devig-method weights for one scope, and write them only if they earn it.

    `market` is a raw market type; it is bucketed through
    `staleness.market_class` so that a scope has enough bets to say anything.
    One user will never place enough bets on `player_points_alternate` to fit
    four weights, but will place plenty across all alt lines.
    """
    klass = market_class(market) if market else None
    key = scope_key(sport, klass)

    bets = ledger.graded_bets(sport=sport, market_type=market)
    result = Calibration(scope=key, n=len(bets))

    if len(bets) < min_graded:
        result.reason = (
            f"{len(bets)} graded bets, need {min_graded}. "
            "Weights from a smaller sample would carry the appearance of "
            "measurement without the substance."
        )
        return result

    candidates = ledger.method_candidates(sport=sport, market_type=market)
    if len(candidates) < 2:
        result.reason = (
            f"{len(candidates)} devig method(s) present on every bet; "
            "weighting needs at least two to choose between"
        )
        return result

    cut = split(bets, holdout)
    train, test = bets[:cut], bets[cut:]
    train_c = {m: v[:cut] for m, v in candidates.items()}
    test_c = {m: v[cut:] for m, v in candidates.items()}
    result.n_train, result.n_holdout = len(train), len(test)

    # Fit on the training slice only. Touching the hold-out here would make
    # the gate below a comparison of a candidate against itself.
    proposed = weights_from_scores(method_scores(train, train_c))

    incumbent = ledger.get_setting(key)
    result.incumbent_score = score(test, test_c, incumbent)
    result.candidate_score = score(test, test_c, proposed)
    result.weights = proposed

    if result.candidate_score >= result.incumbent_score - MIN_IMPROVEMENT:
        result.reason = (
            f"candidate scored {result.candidate_score:.6f} out of sample "
            f"against the incumbent's {result.incumbent_score:.6f} — no better, "
            "so the existing weights stand"
        )
        return result

    result.accepted = True
    if write:
        ledger.set_setting(key, proposed)
    return result


def calibrate_all(ledger, scopes=None, **kwargs) -> list[Calibration]:
    """Calibrate the global scope plus every scope with enough data.

    Scopes are discovered from the log rather than declared, so a user who
    only bets NBA totals never sees an empty NFL row.
    """
    if scopes is None:
        seen: list[tuple[str | None, str | None]] = [(None, None)]
        for bet in ledger.graded_bets():
            pair = (bet.sport, bet.market_type)
            if pair not in seen:
                seen.append(pair)
        scopes = seen
    out: list[Calibration] = []
    for s, m in scopes:
        out.append(calibrate_methods(ledger, s, m, **kwargs))
        out.append(calibrate_books(ledger, s, m, **kwargs))
    return out


# ------------------------------------------------------------- book weights

BOOK_SETTING_PREFIX = "book_weights"

# A book must have priced at least this many of the graded bets before it is
# weighted at all. Below it, the book keeps its `TIER_WEIGHT` default.
#
# This exists because books are ragged in a way devig methods are not: every
# method answers every market, so a method missing anywhere is a signal, but no
# book prices everything. Scoring a book on the eight markets it happened to
# quote and then trusting that number against a book scored on two hundred is
# the "subset is not comparable" problem, and a coverage floor is the honest
# way to keep it out rather than pretending the ragged edges are data.
MIN_BOOK_COVERAGE = 20


def book_scope_key(sport: str | None, market: str | None) -> str:
    if sport is None and market is None:
        return f"{BOOK_SETTING_PREFIX}.global"
    return f"{BOOK_SETTING_PREFIX}.{sport or 'any'}.{market or 'any'}"


def book_blended(probs: dict[str, float], weights: dict[str, float] | None) -> float:
    """Blend per-book probabilities exactly as `fair.fair_value` does.

    In **log-odds**, not probability space — which is the one place this file
    differs from method calibration, because the engine differs there too.
    `DevigSpread.consensus` averages methods arithmetically; `fair_value`
    averages books in logit space, since averaging probabilities near 0 or 1
    biases toward the middle and longshots are where phantom edges live.

    `_logit` and `_expit` are imported from `fair` rather than reimplemented.
    A local copy is precisely how the two would drift apart, and a calibration
    fitted to a blend the engine does not compute writes confidently wrong
    weights that nothing downstream can detect.
    """
    from .fair import _expit, _logit

    if not probs:
        raise ValueError("cannot blend an empty book set")
    used = {b: w for b, w in (weights or {}).items() if b in probs and w > 0}
    if not used:
        used = {b: 1.0 for b in probs}
    total = sum(used.values())
    return _expit(sum(_logit(probs[b]) * w for b, w in used.items()) / total)


def book_score(
    bets: list[GradedBet],
    candidates: list[dict[str, float]],
    weights: dict[str, float] | None,
) -> float:
    """Mean squared error of a weighted book blend against the closing line.

    Bets with no recorded book probabilities are skipped rather than scored as
    zero — a pre-v2 row is missing data, not evidence of a perfect prediction.
    """
    scored = [
        (bet, probs) for bet, probs in zip(bets, candidates) if probs
    ]
    if not scored:
        return float("inf")
    return sum(
        (book_blended(probs, weights) - bet.closing_fair_prob) ** 2
        for bet, probs in scored
    ) / len(scored)


def _book_errors(
    bets: list[GradedBet], candidates: list[dict[str, float]]
) -> tuple[dict[str, float], dict[str, int]]:
    """Per-book mean squared error against the close, and how often each priced.

    Each book is scored only on the bets it actually quoted, which is why the
    coverage counts come back alongside — a score without its sample size is
    the input to a confident mistake.
    """
    totals: dict[str, float] = {}
    counts: dict[str, int] = {}
    for bet, probs in zip(bets, candidates):
        for book, prob in probs.items():
            totals[book] = totals.get(book, 0.0) + (prob - bet.closing_fair_prob) ** 2
            counts[book] = counts.get(book, 0) + 1
    return {b: totals[b] / counts[b] for b in totals}, counts


def apply_book_weights(
    calibrated: dict[str, float], books: dict[str, Book]
) -> dict[str, float]:
    """Put calibrated weights on the same scale as the tier defaults.

    Calibration returns weights summing to 1 across the books it covered.
    `fair_value` normalises by the total weight of contributing books, so
    relative scale is all that matters *within one set* — but handing it a mix
    of normalised values (~0.2) and raw tier defaults (1.0 for a sharp book)
    would let one uncovered sharp book swamp every measured one.

    So the covered books are rescaled to preserve their combined tier weight.
    An uncovered book keeps its default untouched, and the two groups stay
    comparable.
    """
    if not calibrated:
        return {k: b.weight for k, b in books.items()}

    covered = {k: w for k, w in calibrated.items() if k in books}
    if not covered:
        return {k: b.weight for k, b in books.items()}

    tier_total = sum(books[k].weight for k in covered)
    share = sum(covered.values())
    scale = (tier_total / share) if share > 0 else 1.0

    out = {k: b.weight for k, b in books.items()}
    for key, weight in covered.items():
        out[key] = weight * scale
    return out


def calibrate_books(
    ledger,
    sport: str | None = None,
    market: str | None = None,
    holdout: float = HOLDOUT,
    min_graded: int = MIN_GRADED,
    min_coverage: int = MIN_BOOK_COVERAGE,
    write: bool = True,
) -> Calibration:
    """Fit per-book weights, under exactly the gates method calibration uses.

    Same time-ordered hold-out, same refusal to write a candidate that does not
    beat the incumbent out of sample, same graded-bet floor. The only addition
    is the coverage floor, because books are ragged and methods are not.
    """
    klass = market_class(market) if market else None
    key = book_scope_key(sport, klass)

    bets = ledger.graded_bets(sport=sport, market_type=market)
    result = Calibration(scope=key, n=len(bets))

    if len(bets) < min_graded:
        result.reason = (
            f"{len(bets)} graded bets, need {min_graded}. "
            "Weights from a smaller sample would carry the appearance of "
            "measurement without the substance."
        )
        return result

    candidates = ledger.book_candidates(sport=sport, market_type=market)
    with_probs = sum(1 for c in candidates if c)
    if with_probs < min_graded:
        result.reason = (
            f"only {with_probs} of {len(bets)} graded bets recorded per-book "
            "probabilities; bets placed before schema v2 cannot say how wrong "
            "any individual book was"
        )
        return result

    cut = split(bets, holdout)
    train, test = bets[:cut], bets[cut:]
    train_c, test_c = candidates[:cut], candidates[cut:]
    result.n_train, result.n_holdout = len(train), len(test)

    errors, counts = _book_errors(train, train_c)
    eligible = {b: e for b, e in errors.items() if counts[b] >= min_coverage}
    if len(eligible) < 2:
        result.reason = (
            f"{len(eligible)} book(s) priced at least {min_coverage} of the "
            "training bets; weighting needs at least two to choose between"
        )
        return result

    # A floor of 0.05 per book stops working once there are 20 books, so it
    # scales down rather than raising. A demoted book must never become a
    # deleted one — a book that looks worst over 40 bets may simply have been
    # unlucky, and a deleted book never gets the chance to come back.
    floor = min(0.05, 0.5 / len(eligible))
    proposed = weights_from_scores(eligible, floor=floor)

    incumbent = ledger.get_setting(key)
    result.incumbent_score = book_score(test, test_c, incumbent)
    result.candidate_score = book_score(test, test_c, proposed)
    result.weights = proposed

    if result.candidate_score >= result.incumbent_score - MIN_IMPROVEMENT:
        result.reason = (
            f"candidate scored {result.candidate_score:.6f} out of sample "
            f"against the incumbent's {result.incumbent_score:.6f} — no better, "
            "so the existing weights stand"
        )
        return result

    result.accepted = True
    if write:
        ledger.set_setting(key, proposed)
    return result


def book_weights_for(
    ledger, sport: str | None = None, market: str | None = None
) -> tuple[dict[str, float] | None, float | None]:
    """Best stored book weights for a scope, with their age in seconds."""
    klass = market_class(market) if market else None
    for key in (book_scope_key(sport, klass), book_scope_key(None, None)):
        stored = ledger.get_setting(key)
        if stored:
            return stored, ledger.setting_age(key)
    return None, None


def weights_for(
    ledger, sport: str | None = None, market: str | None = None
) -> tuple[dict[str, float] | None, float | None]:
    """Best stored weights for a scope, with their age in seconds.

    Most specific first, falling back to global and then to None, which
    `fair_value` reads as equal weighting. The age travels with the weights
    because a calibrated number shown without its date asserts "true now",
    forever — the same failure the jurisdiction table was fixed for.
    """
    klass = market_class(market) if market else None
    for key in (scope_key(sport, klass), scope_key(None, None)):
        stored = ledger.get_setting(key)
        if stored:
            return stored, ledger.setting_age(key)
    return None, None
