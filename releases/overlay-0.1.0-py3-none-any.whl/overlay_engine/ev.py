"""Expected value, as an interval and after the cost of not getting filled.

Two rules, both of which the category routinely breaks:

**An EV is an interval.** It inherits the devig disagreement and the
between-book disagreement from `fair.py`. A screen printing "+3.4% EV" from a
band running -0.2% to +6.1% is reporting the midpoint of its own ignorance to
one decimal place. `ev_low` is the number that decides whether to bet.

**An EV you cannot get down is zero.** The quote that produced it may already
be gone. Multiplying by the fill probability from `staleness.py` reorders the
screen — and the reorder is the product. A 6% edge on a book that pulls its
price in four seconds is worth less than a 3% edge that is still there when
you tap it, and every tool that sorts on raw EV puts them the wrong way round.
"""

from __future__ import annotations

from dataclasses import dataclass

from .fair import FairValue, fair_value
from .models import Book, Edge, Market


def ev_per_unit(decimal: float, prob: float) -> float:
    """Expected profit per unit staked.

    Stake 1 at decimal odds d: win with probability q, returning d (profit
    d-1); lose otherwise, returning 0 (profit -1). So EV = q*d - 1.
    """
    return prob * decimal - 1.0


def breakeven_prob(decimal: float) -> float:
    """The win rate at which a price is exactly break-even.

    Identical arithmetic to implied probability, and a different claim: this
    is what *you* must hit, not what the book asserts.
    """
    return 1.0 / decimal


@dataclass(frozen=True)
class EVResult:
    """An EV point estimate and the band the modelling choices allow."""

    decimal: float
    fair: FairValue
    ev: float
    ev_low: float
    ev_high: float

    @property
    def robust(self) -> bool:
        """+EV even under the least favourable fair probability."""
        return self.ev_low > 0.0

    @property
    def edge_prob(self) -> float:
        """Probability points between the fair value and the break-even rate."""
        return self.fair.prob - breakeven_prob(self.decimal)


def evaluate(decimal: float, fair: FairValue) -> EVResult:
    """Price one offer against a fair value, keeping the band."""
    return EVResult(
        decimal=decimal,
        fair=fair,
        ev=ev_per_unit(decimal, fair.prob),
        ev_low=ev_per_unit(decimal, fair.low),
        ev_high=ev_per_unit(decimal, fair.high),
    )


def find_edges(
    market: Market,
    books: dict[str, Book],
    now: float,
    min_ev: float = 0.0,
    require_robust: bool = True,
    require_anchor: bool = True,
    fill_model=None,
    method_weights: dict[str, float] | None = None,
    latency_model=None,
) -> list[Edge]:
    """Every +EV offer in a market, sorted by the EV you can actually realise.

    A book is never priced against a fair value it helped set — its own weight
    is removed and the blend recomputed first. Skipping that step is
    self-referential: a soft book carrying even 6% of the weight pulls the
    fair value a little toward its own price, shrinking exactly the edge you
    are trying to detect, and doing so hardest on the markets where that book
    is the only outlier and the edge is largest.
    """
    edges: list[Edge] = []
    outcome_keys = market.outcomes()
    if len(outcome_keys) < 2:
        return edges

    contributors = set(market.complete_books())

    for outcome in outcome_keys:
        for quote in market.quotes:
            if quote.outcome.key != outcome:
                continue

            book = books.get(quote.book) or Book(key=quote.book, name=quote.book)

            if quote.book in contributors:
                holdout = {
                    b: (books.get(b) or Book(key=b, name=b)).weight
                    for b in contributors
                }
                holdout[quote.book] = 0.0
                fairs = fair_value(market, books, method_weights, book_weights=holdout)
            else:
                fairs = fair_value(market, books, method_weights)

            fv = fairs.get(outcome)
            if fv is None:
                continue
            if require_anchor and not fv.anchored:
                continue

            net = book.net_decimal(quote.decimal)
            res = evaluate(net, fv)
            if res.ev < min_ev:
                continue
            if require_robust and not res.robust:
                continue

            # Feed latency is a floor under quote age, so it belongs here and
            # not in a footnote: a quote that arrived eight seconds stale is
            # eight seconds older than it looks, and every fill probability
            # computed without that is too optimistic on exactly the fastest
            # markets.
            floor = 0.0 if latency_model is None else latency_model.typical(quote.book)
            age = quote.age(now, latency_floor=floor)
            p_fill = 1.0
            if fill_model is not None:
                p_fill = fill_model.p_fill(quote.book, market.market_type, age)

            edges.append(
                Edge(
                    kind="ev",
                    event_id=market.event_id,
                    sport=market.sport,
                    market_type=market.market_type,
                    outcome=outcome,
                    book=quote.book,
                    decimal=quote.decimal,
                    fair_prob=fv.prob,
                    ev=res.ev,
                    ev_low=res.ev_low,
                    ev_high=res.ev_high,
                    p_fill=p_fill,
                    quote_age=age,
                    note="" if fv.anchored else "no sharp anchor",
                )
            )

    edges.sort(key=lambda e: e.realised_ev, reverse=True)
    return edges
