"""The Odds source page, and the button that spends credits, hold their promises.

Live sportsbook odds are the third thing that can reach the internet from this
app, and the first that holds a credential. So the window is checked for the
things a screenshot cannot show:

  * the key travels by one road: the window hands it to the shell's
    `save_odds_key`, which writes it to the engine's STANDARD INPUT. It is in no
    command line, no storage, no message, and the box is emptied the moment it
    is sent;
  * only a press spends credits. Nothing runs the refresh at load, on a timer,
    or when a page is first shown, and the page's first button (the one the
    window runs by itself) is never it;
  * the window says what a refresh costs before the press, from the engine's own
    count, and says how to add a key when there is none;
  * what the privacy note says leaves this Mac is true.

Static, like test_app_ui_is_wired.py: none of it needs a GUI.
"""

import html
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()
RUST = (UI / "src-tauri" / "src" / "main.rs").read_text()


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def _text(markup: str) -> str:
    """What a person reads: tags gone, entities decoded, whitespace folded."""
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", "", markup))).strip()


PANEL = HTML[HTML.index('id="panel-odds"'):HTML.index('</section>', HTML.index('id="panel-odds"'))]
BOARD_PANEL = HTML[HTML.index('id="panel-board"'):HTML.index('id="panel-odds"')]


# ------------------------------------------------------------ the page says what it is

def test_the_odds_source_page_is_a_place_on_the_rail():
    assert re.search(r'<button class="nav" data-section="odds" data-panel="odds"', HTML)
    assert re.search(r'<section class="panel" id="panel-odds" data-section="odds">', HTML)
    assert 'odds: "Odds source"' in JS
    assert len(re.findall(r'<button class="nav[^"]*" data-section=', HTML)) <= 6


def test_the_explanation_is_the_one_the_page_was_asked_to_carry():
    sub = _text(re.search(r'<p class="sub">(.*?)</p>', PANEL, re.S).group(1))
    assert sub == ("Bookbreaker can read live odds from every major US sportsbook through The Odds API. "
                   "Get a free key (500 credits a month) at the-odds-api.com, paste it here. "
                   "It is stored in your Mac’s Keychain and only ever sent to The Odds API.")


def test_credits_are_explained_in_words_a_beginner_has_not_met_before():
    text = _text(PANEL)
    assert "A credit pays for one bet type, in one region, for one league" in text
    assert "500 a month" in text


def test_the_free_plan_gaps_and_the_pinnacle_rule_are_stated():
    text = _text(PANEL)
    assert "leaves out a few sportsbooks, including Caesars and Fanatics" in text
    assert "You cannot bet at Pinnacle from the US, so it is never shown as a bet" in text
    assert "reuses the first answer and spends nothing" in text


def test_the_page_never_says_guaranteed_or_risk_free():
    for text in (_text(HTML), JS):
        low = text.lower()
        assert "risk-free" not in low and "riskfree" not in low
    live = JS[JS.index("live sportsbook odds\n * Odds from every"):JS.index("/* ── Check for updates")]
    assert "guarantee" not in live.lower()
    assert "either way" not in live.lower()


# ------------------------------------------------------------ the key box

def test_the_key_box_is_a_password_field_that_keeps_nothing():
    tag = re.search(r'<input id="key-in"[^>]*>', HTML).group(0)
    assert 'type="password"' in tag and 'autocomplete="off"' in tag and 'spellcheck="false"' in tag
    assert re.search(r'<button class="go" id="key-save" type="button">Save key</button>', HTML)
    assert re.search(r'<button class="go ghost" id="key-clear" type="button">Clear key</button>', HTML)


def test_the_page_shows_the_key_status_the_credits_and_the_cost():
    for hook in ('id="out-keystatus"', 'id="out-oddsestimate"', 'id="odds-picks"', 'id="key-msg"'):
        assert hook in PANEL, hook
    status = _braced(JS, "function showKeystatus(")
    assert "out.text" in status and "out.last4" in status and "out.credits" in status
    estimate = _braced(JS, "function showOddsestimate(")
    assert "e.credits" in estimate and "e.text" in estimate and "e.rule" in estimate


def test_the_key_is_sent_by_one_road_and_the_box_is_emptied():
    """The window hands the key to the shell's save_odds_key, which puts it on the
    engine's standard input. It is never an argument to the engine, and the box is
    emptied whether the save worked or not."""
    save = _braced(JS, "async function saveKey(")
    assert save.count('invoke("save_odds_key", { key })') == 1
    assert JS.count('"save_odds_key"') == 1
    assert save.index('invoke("save_odds_key"') < save.index('input.value = "";') < save.index("if (out.error)")
    # No builder for the engine mentions `set`, so there is no argv that could carry a key.
    assert '"key", "set"' not in JS and "'key', 'set'" not in JS
    builders = re.findall(r'^\s*(keystatus|keyclear): \(\) => \[(.*?)\],?$', JS, re.M)
    assert dict(builders) == {"keystatus": '"key", "status"', "keyclear": '"key", "clear"'}


def test_the_key_is_in_no_storage_no_log_and_no_message():
    key_reads = [m.start() for m in re.finditer(r'getElementById\("key-in"\)', JS)]
    assert len(key_reads) == 2, "the key box is read by Save and by Enter, and nothing else"
    for sink in ("sessionStorage", "document.cookie", "indexedDB"):
        assert sink not in JS, sink
    assert not re.search(r"\bconsole\.(log|warn|error|info|debug|trace)\b", JS)
    # The one storage this window uses is its own `store` helper, for three named choices.
    helper = _braced(JS, "const store = {")
    assert JS.replace(helper, "").count("localStorage") == 0
    assert set(re.findall(r'store\.set\("([^"]+)"', JS)) == {"bb.state", "bb.live", "bb.odds"}
    save = _braced(JS, "async function saveKey(")
    for leak in ("innerHTML", "keyMessage(key", "keyMessage(`${key", "store.", "console"):
        assert leak not in save, leak
    # The status the window keeps is the engine's: set, last four, credits. Never the key.
    assert "ODDS.key = { set: !!out.set, last4: out.last4, credits: out.credits || null };" in JS


def test_the_one_link_out_goes_through_the_shell_and_names_no_address():
    assert JS.count('"open_odds_api_site"') == 1
    assert re.search(r'getElementById\("odds-site"\)\.addEventListener\("click"', JS)
    link = re.search(r'<button type="button" class="linkish" id="odds-site">([^<]*)</button>', HTML)
    assert link and link.group(1) == "the-odds-api.com"
    assert "http" not in JS.lower().replace("https?", "")
    # `invoke("open_odds_api_site")` passes nothing: the page it opens is the shell's.
    assert 'invoke("open_odds_api_site")' in JS


# ------------------------------------------------------------ the shell

def test_the_shell_takes_the_key_on_standard_input_and_nowhere_else():
    save = _braced(RUST, "fn save_key(")
    assert '.args(["key", "set", "--json"])' in save
    assert ".stdin(Stdio::piped())" in save and "write_all(key.as_bytes())" in save
    assert save.count(".args(") == 1 and ".arg(" not in save, "the key must not become an argument"
    assert "format!" not in save.split("write_all")[0], "nothing is formatted around the key before it is written"
    command = _braced(RUST, "async fn save_odds_key(")
    assert "save_key(&key, &p)" in command
    for sink in ("println!", "eprintln!", "dbg!", "log::", "tracing::"):
        assert sink not in save and sink not in command, sink


def test_the_generic_engine_call_cannot_set_a_key():
    run = _braced(RUST, "fn run_engine(")
    assert 'Some("status") | Some("clear")' in run
    assert "Odds source page" in run
    assert re.search(r'ALLOWED: \[&str; 11\] = \[[^\]]*"key"', run)


def test_the_browser_door_opens_one_fixed_page_and_takes_no_argument():
    assert 'const ODDS_API_SITE: &str = "https://the-odds-api.com/";' in RUST
    assert re.search(r"#\[tauri::command\]\s*fn open_odds_api_site\(\) ->", RUST)
    opener = _braced(RUST, "fn open_odds_api_site(")
    assert 'Command::new("/usr/bin/open").arg(ODDS_API_SITE)' in opener
    assert opener.count(".arg(") == 1


def test_both_new_shell_commands_are_registered():
    handlers = re.search(r"generate_handler!\[([^\]]*)\]", RUST).group(1)
    assert "save_odds_key" in handlers and "open_odds_api_site" in handlers


# ------------------------------------------------------------ only a press spends credits

def test_the_refresh_button_is_hidden_until_a_key_is_set_and_comes_after_find_arbs():
    button = re.search(r'<button[^>]*data-run="oddsboard"[^>]*>([^<]*)</button>', BOARD_PANEL)
    assert button and button.group(1) == "Live sportsbook odds"
    assert " hidden" in button.group(0) and 'type="button"' in button.group(0)
    runs = re.findall(r'data-run="([a-z-]+)"', BOARD_PANEL)
    assert runs == ["board", "oddsboard"], "the page's first data-run button is the one run when the page is first shown"
    assert "button.hidden = !key.set;" in _braced(JS, "function drawOddsStrip(")


def test_no_page_runs_a_spending_or_destructive_button_when_it_is_first_shown():
    """prime(panel) presses the first data-run button in a page the first time it
    is shown. For Arbitrage that must stay Find arbs; and no page may lead with
    the refresh or anything that clears a key."""
    prime = _braced(JS, "function prime(")
    assert "#panel-${kind} [data-run]" in prime
    for panel, body in re.findall(r'<section class="panel[^"]*" id="panel-([a-z-]+)"[^>]*>(.*?)</section>', HTML, re.S):
        first = re.search(r'data-run="([a-z-]+)"', body)
        assert not first or first.group(1) not in ("oddsboard", "keyclear", "keystatus", "oddsestimate"), panel
    assert not re.search(r'data-run="', PANEL), "the Odds source page has no data-run button"
    assert re.search(r'data-run="board"', BOARD_PANEL)


def test_the_refresh_runs_from_nothing_but_a_press():
    """Counted in the source: where `oddsboard` appears and what is run at load."""
    # Run at load, outside any function, at column 0: the two that cost nothing.
    at_load = re.findall(r'^run\("([a-z]+)"\);', JS, re.M)
    assert at_load == ["keystatus", "oddsestimate"], at_load
    assert 'run("oddsboard")' not in JS and "run('oddsboard')" not in JS
    # The only other ways to run a kind are data-run clicks and these two named presses.
    assert 'run("keyclear")' in JS and JS.count('run("keyclear")') == 1
    for timer in ("setInterval", "setTimeout", "requestAnimationFrame"):
        for m in re.finditer(timer + r"\(", JS):
            window = JS[m.start():m.start() + 400]
            assert "oddsboard" not in window and "oddsapi" not in window, timer
    assert "visibilitychange" not in JS and '"focus"' not in JS


def test_the_estimate_and_status_are_local_and_the_refresh_is_the_only_feed_call():
    builders = dict(re.findall(r'^\s*(oddsboard|oddsestimate): \(\) => \[(.*?)\],?$', JS, re.M | re.S))
    assert '"--estimate"' in builders["oddsestimate"] and '"--feed", "oddsapi"' in builders["oddsestimate"]
    assert '"--estimate"' not in builders["oddsboard"] and '"--feed", "oddsapi"' in builders["oddsboard"]
    assert JS.count('"--feed"') == 2


def test_a_second_board_cannot_overwrite_a_later_one():
    assert 'const BOARDS = ["board", "oddsboard"];' in JS
    assert "if (boardOutdated(kind, turn)) return;" in JS
    assert JS.index("const turn = boardTurn(kind);") < JS.index('await invoke("engine"')


def test_a_stored_pick_cannot_make_the_estimate_lie():
    """An empty group would send no flag, and the engine would answer for its
    defaults: a cost for something the person unticked. The window refuses to ask."""
    chosen = _braced(JS, "function oddsChosen(")
    assert "p.sports.length > 0 && p.regions.length > 0 && p.markets.length > 0" in chosen
    run_once = _braced(JS, "async function runOnce(")
    assert 'if (!oddsChosen()) { box.innerHTML = PICK_ODDS; return; }' in run_once
    assert run_once.index("oddsChosen()") < run_once.index('invoke("engine"')


# ------------------------------------------------------------ the Arbitrage page says what it costs

def test_with_no_key_the_page_says_how_to_add_one_with_a_link_to_the_settings():
    strip = _braced(JS, "function drawOddsStrip(")
    sentence = re.search(r"note\.innerHTML = `(.*?)`;", strip, re.S).group(1)
    text = _text(sentence)
    assert text == "To see live odds from the sportsbooks, add a free Odds API key on the Odds source page."
    assert text.count(".") == 1, "one sentence"
    assert '<button type="button" class="linkish" data-panel="odds">Odds source</button>' in sentence
    assert 'id="panel-odds"' in HTML


def test_with_a_key_the_cost_is_shown_beside_the_button_from_the_engines_own_sentence():
    strip = _braced(JS, "function drawOddsStrip(")
    assert "ODDS.estimate && ODDS.estimate.text" in strip
    assert "creditsLeft()" in strip
    assert "sends your key and the leagues you chose to The Odds API, and nothing else" in strip
    credits = _braced(JS, "function creditsLeft(")
    assert "c.remaining" in credits


def test_a_board_on_live_odds_says_where_it_came_from_and_what_it_cost():
    line = _braced(JS, "function oddsLine(")
    for field in ("o.regions", "o.fetched_at", "o.cached", "o.cost.text", "o.errors", "o.notes"):
        assert field in line, field
    how = _braced(JS, "function oddsHow(")
    for field in ("o.bet_at", "o.reference_only"):
        assert field in how, field
    assert "accepted at the prices shown and both stand" in how
    assert "Games already under way are left off" in how
    assert "guarantee" not in how.lower()


def test_an_empty_board_on_live_odds_says_nothing_pays_without_padding():
    empty = _braced(JS, "function oddsEmptyHTML(")
    assert "No plays on these prices right now" in empty
    assert "PLAYS" not in empty and "closest" not in empty.lower()
    assert "if (BOARD.feed) return oddsEmptyHTML();" in _braced(JS, "function consoleHTML(")


def test_every_odds_renderer_is_dispatched():
    dispatch = re.search(r"\(\{([^}]*)\}\)\[kind\]", JS, re.S).group(1)
    for kind, fn in (("oddsboard", "showOddsboard"), ("oddsestimate", "showOddsestimate"),
                     ("keystatus", "showKeystatus"), ("keyclear", "showKeyclear")):
        assert re.search(rf"\b{kind}: {fn}\b", dispatch), kind
        assert re.search(rf"^function {fn}\(", JS, re.M), fn


def test_clearing_a_key_does_not_leave_its_odds_on_the_page():
    clear = _braced(JS, "function showKeyclear(")
    assert "BOARD.feed" in clear and "PLAYS = [];" in clear
    assert 'run("board")' not in clear, "clearing a key must not start a read of anything"


# ------------------------------------------------------------ the window reads only what the engine sends

@pytest.fixture(scope="module")
def engine_output(tmp_path_factory):
    """The engine's own JSON for the three answers the window reads, produced the
    way the window gets them: through the CLI, on the tests' fake API and Keychain."""
    import contextlib
    import io
    import os
    from types import SimpleNamespace

    import test_keystore as tk
    import test_oddsapi as to
    from overlay_engine import cli, keystore, oddsapi

    was_home = os.environ.get("OVERLAY_HOME")
    os.environ["OVERLAY_HOME"] = str(tmp_path_factory.mktemp("home"))
    fake = tk.FakeSecurity()
    saved = (keystore._available, keystore.subprocess.run, oddsapi.odds_api_fetcher, oddsapi.time)
    keystore._available = lambda: None
    keystore.subprocess.run = fake
    oddsapi.odds_api_fetcher = lambda *a, **k: to.FakeApi()
    oddsapi.time = SimpleNamespace(time=to.Clock())

    def call(argv, stdin=""):
        out = io.StringIO()
        stream = io.StringIO(stdin)
        stream.isatty = lambda: False
        old, cli.sys.stdin = cli.sys.stdin, stream
        try:
            with contextlib.redirect_stdout(out):
                assert cli.main(argv) == 0
        finally:
            cli.sys.stdin = old
        return json.loads(out.getvalue())

    try:
        call(["key", "set", "--json"], stdin=to.KEY)
        yield {
            "estimate": call(["board", "--feed", "oddsapi", "--estimate", "--json"]),
            "board": call(["board", "--feed", "oddsapi", "--sport", "nfl", "--json"]),
            "status": call(["key", "status", "--json"]),
            "cleared": call(["key", "clear", "--json"]),
        }
    finally:
        keystore._available, keystore.subprocess.run, oddsapi.odds_api_fetcher, oddsapi.time = saved
        if was_home is None:
            os.environ.pop("OVERLAY_HOME", None)
        else:
            os.environ["OVERLAY_HOME"] = was_home


def test_every_field_the_odds_board_reads_is_one_the_engine_sends(engine_output):
    board = engine_output["board"]
    odds = board["odds"]
    line = _braced(JS, "function oddsLine(") + _braced(JS, "function oddsHow(")
    read = set(re.findall(r"\bo\.([a-z_]+)", line))
    assert read >= {"fetched_at", "regions", "cached", "cost", "errors", "notes", "bet_at", "reference_only"}
    assert read <= set(odds), f"read but never sent: {sorted(read - set(odds))}"
    assert set(re.findall(r"\bo\.cost\.([a-z_]+)", line)) <= set(odds["cost"])
    assert {"event", "league", "kind", "margin", "profit", "staked", "p_fill", "age", "legs", "market"} <= set(board["rows"][0])
    play = _braced(JS, "function boardPlay(")
    row_reads = set(re.findall(r"\br\.([a-z_]+)", play))
    assert row_reads <= set(board["rows"][0]), f"read but never sent: {sorted(row_reads - set(board['rows'][0]))}"
    show = _braced(JS, "function showOddsboard(")
    assert set(re.findall(r"\bout\.([a-z_]+)", show)) <= set(board)


def test_every_field_the_estimate_and_status_cards_read_is_one_the_engine_sends(engine_output):
    estimate, status, cleared = engine_output["estimate"], engine_output["status"], engine_output["cleared"]
    card = _braced(JS, "function showOddsestimate(")
    assert set(re.findall(r"\be\.([a-z_]+)", card)) <= set(estimate["estimate"])
    assert set(re.findall(r"\bout\.([a-z_]+)", card)) <= set(estimate)
    picks = _braced(JS, "function buildPicks(")
    assert {"alias", "label", "picked", "in_season"} <= set(estimate["choices"]["leagues"][0])
    assert {"key", "label", "picked"} <= set(estimate["choices"]["regions"][0])
    assert {"key", "label", "picked"} <= set(estimate["choices"]["markets"][0])
    for field in ("c.alias", "c.label", "c.picked", "c.in_season", "c.key"):
        assert field in picks, field
    keycard = _braced(JS, "function showKeystatus(")
    assert set(re.findall(r"\bout\.([a-z0-9_]+)", keycard)) <= set(status)
    assert status["set"] is True and len(status["last4"]) == 4
    assert set(re.findall(r"\bout\.([a-z_]+)", _braced(JS, "function showKeyclear("))) <= set(cleared)


def test_the_status_the_engine_sends_has_the_last_four_and_never_the_key(engine_output):
    import test_oddsapi as to

    flat = json.dumps(engine_output)
    assert to.KEY not in flat and to.KEY[:-4] not in flat
    assert engine_output["status"]["last4"] == to.KEY[-4:]


def test_every_book_the_board_can_bet_at_has_a_name_in_the_window():
    from overlay_engine import oddsapi

    for key in oddsapi.BETTABLE:
        assert re.search(rf"\b{key}: \[", JS), f"{key} would show as a capitalised key"


# ------------------------------------------------------------ the privacy note

def test_live_sportsbook_odds_is_the_third_named_network_path():
    note = re.search(r'<div class="privacy-pop">(.*?)</div>', HTML, re.S).group(1)
    items = re.findall(r"<li>(.*?)</li>", note, re.S)
    assert len(items) == 3 and "<b>Live sportsbook odds</b>" in items[2]
    third = _text(items[2])
    assert "when you press the button" in third and "never runs on its own" in third
    assert ("When you press it, your Odds API key and the sports, regions and bet types you chose go to "
            "api.the-odds-api.com, and nothing else does.") in third
    assert "internet address" in third and "Keychain" in third and "no bets or amounts" in third
    assert "Three things reach the internet" in _text(note) and "all three are yours to start" in _text(note)


def test_the_key_and_the_odds_have_no_other_address_in_the_window():
    for name, text in (("index.html", HTML), ("app.js", JS), ("app.css", CSS)):
        assert re.findall(r"https?://", text) == [], name
    assert set(re.findall(r"[a-z0-9.-]*the-odds-api\.com", HTML + JS)) <= {"the-odds-api.com", "api.the-odds-api.com"}


# ------------------------------------------------------------ it is styled

def test_every_class_the_odds_pages_use_has_a_rule():
    used = {"linkish", "oddsbar", "oddsline", "keycard", "keyform", "picks", "pickgroup", "chk", "costline", "plain"}
    for cls in used:
        assert re.search(rf"\.{cls}\b[^{{}}]*\{{", CSS), f".{cls} has no rule in app.css"
        assert cls in HTML or cls in JS, f".{cls} is styled and unused"
    assert '.nav[data-section="odds"]' in CSS and ".t-odds" in CSS


def test_the_rail_entry_has_its_own_colour_and_title():
    assert 'body[data-section="odds"]' in CSS
