"""The Odds API key is a credential, and it has one home: the Mac's Keychain.

Nothing here touches a Keychain. `security` is replaced by a recorded fake that
remembers every call it was handed, which is what lets these tests state the
rules as facts about what was run: the key is never in any argument, never in
anything printed, and a save is believed only after it is read back.
"""

import json
import subprocess
from types import SimpleNamespace

import pytest

from overlay_engine import cli, keystore

KEY = "0123456789abcdef0123456789abcdef"      # a made-up value, not a real key
OTHER = "fedcba9876543210fedcba9876543210"


class FakeSecurity:
    """What `/usr/bin/security` does, for the four calls the store makes."""

    def __init__(self, stored=None, fail=None):
        self.stored = stored
        self.fail = fail or {}
        self.calls = []                  # (argv, stdin)

    def __call__(self, argv, input=None, capture_output=True, text=True, timeout=None):
        self.calls.append((list(argv), input))
        verb = argv[1]
        if verb in self.fail:
            return SimpleNamespace(returncode=self.fail[verb], stdout="", stderr="boom")
        if verb == "-i":
            # `security -i` runs the command on its stdin and exits 0 whatever
            # happened inside it; this models the success case.
            for part in input.split('-w "', 1)[1:]:
                self.stored = part.split('"', 1)[0]
            return SimpleNamespace(returncode=0, stdout="", stderr="")
        if verb == "add-generic-password":
            # The spelling that puts the key on a command line. Modelled so a
            # regression to it fails on the assertion that names the problem
            # (the key is in an argument), not on a surprise.
            self.stored = argv[argv.index("-w") + 1]
            return SimpleNamespace(returncode=0, stdout="", stderr="")
        if verb == "find-generic-password":
            if self.stored is None:
                return SimpleNamespace(returncode=44, stdout="", stderr="not found")
            return SimpleNamespace(returncode=0, stdout=self.stored + "\n", stderr="")
        if verb == "delete-generic-password":
            if self.stored is None:
                return SimpleNamespace(returncode=44, stdout="", stderr="not found")
            self.stored = None
            return SimpleNamespace(returncode=0, stdout="", stderr="deleted")
        raise AssertionError(f"unexpected call {argv}")

    def argv_text(self):
        return " ".join(" ".join(argv) for argv, _ in self.calls)


# ------------------------------------------------------------ the key never rides in argv

def test_the_key_is_never_in_any_argument():
    """`ps` shows every argument of every process this user is running. The
    key goes to `security` down a pipe, and the only arguments `security` ever
    has are `-i`, or a service name and an account."""
    fake = FakeSecurity()
    keystore.set_key(KEY, runner=fake)
    keystore.status(runner=fake)
    keystore.clear_key(runner=fake)
    assert fake.calls, "nothing ran"
    for argv, _ in fake.calls:
        assert all(KEY not in part for part in argv), argv
    assert KEY not in fake.argv_text()


def test_the_key_reaches_security_on_standard_input():
    fake = FakeSecurity()
    keystore.set_key(KEY, runner=fake)
    argv, stdin = fake.calls[0]
    assert argv == [keystore.SECURITY, "-i"]
    assert stdin.startswith("add-generic-password ")
    assert f"-s {keystore.SERVICE}" in stdin and f"-a {keystore.ACCOUNT}" in stdin
    assert f'-w "{KEY}"' in stdin and stdin.rstrip().endswith("-U")
    assert stdin.count("\n") == 1, "one command, ended by one newline"


def test_the_service_and_account_are_the_documented_ones():
    assert keystore.SERVICE == "bookbreaker.oddsapi" and keystore.ACCOUNT == "default"
    assert keystore.SECURITY == "/usr/bin/security"


# ------------------------------------------------------------ what a key looks like

@pytest.mark.parametrize("bad", [
    "", "   ", "short", "has a space in the middle of it 12345",
    KEY + "\nsecurity delete-generic-password -s something",     # a second command
    'abc"def0123456789abcdef', "abc;def0123456789abcdef", "x" * 200,
    "https://api.the-odds-api.com/v4/sports?apiKey=" + KEY,
])
def test_something_that_is_not_a_key_is_refused_before_anything_runs(bad):
    fake = FakeSecurity()
    with pytest.raises(keystore.KeyStoreError) as caught:
        keystore.set_key(bad, runner=fake)
    assert fake.calls == [], "a refused key must not reach the Keychain"
    assert bad.strip() == "" or bad.strip() not in str(caught.value), "the refusal repeats what was typed"


def test_surrounding_whitespace_is_trimmed():
    fake = FakeSecurity()
    assert keystore.set_key(f"  {KEY}\n", runner=fake).last4 == KEY[-4:]


# ------------------------------------------------------------ status shows the last four and nothing else

def test_status_says_whether_a_key_is_set_and_its_last_four():
    fake = FakeSecurity(stored=KEY)
    got = keystore.status(runner=fake)
    assert got.is_set and got.last4 == KEY[-4:]
    assert got.as_dict() == {"set": True, "last4": KEY[-4:]}
    assert KEY not in got.describe() and KEY[:-4] not in got.describe()
    assert KEY[-4:] in got.describe()


def test_status_with_no_key_is_not_an_error():
    got = keystore.status(runner=FakeSecurity())
    assert not got.is_set and got.as_dict() == {"set": False, "last4": None}
    assert "No Odds API key" in got.describe()


# ------------------------------------------------------------ believed only after read back

def test_a_save_the_keychain_did_not_keep_is_not_reported_as_saved():
    """`security -i` exits 0 whatever happened inside it, so exit status proves
    nothing; the Keychain is read back."""
    class Forgetful(FakeSecurity):
        def __call__(self, argv, input=None, **kw):
            if argv[1] == "-i":
                self.calls.append((list(argv), input))
                return SimpleNamespace(returncode=0, stdout="", stderr="")
            return super().__call__(argv, input=input, **kw)

    with pytest.raises(keystore.KeyStoreError, match="did not keep the key") as caught:
        keystore.set_key(KEY, runner=Forgetful())
    assert KEY not in str(caught.value)


def test_saving_again_replaces_the_old_key():
    fake = FakeSecurity(stored=OTHER)
    keystore.set_key(KEY, runner=fake)
    assert fake.stored == KEY
    assert fake.calls[0][1].rstrip().endswith("-U"), "-U updates rather than failing on an existing item"


# ------------------------------------------------------------ clearing

def test_clearing_deletes_the_item():
    fake = FakeSecurity(stored=KEY)
    assert keystore.clear_key(runner=fake) is True
    assert fake.stored is None


def test_clearing_a_key_that_was_never_set_is_not_an_error():
    assert keystore.clear_key(runner=FakeSecurity()) is False


# ------------------------------------------------------------ failures read as sentences

@pytest.mark.parametrize("verb, call", [
    ("find-generic-password", lambda r: keystore.get_key(runner=r)),
    ("delete-generic-password", lambda r: keystore.clear_key(runner=r)),
])
def test_a_keychain_failure_is_a_sentence_without_the_key(verb, call):
    fake = FakeSecurity(stored=KEY, fail={verb: 36})
    with pytest.raises(keystore.KeyStoreError) as caught:
        call(fake)
    text = str(caught.value)
    assert KEY not in text and "boom" not in text, "the tool's own stderr is not passed through"
    assert text.endswith(".") and "36" in text


def test_a_hung_keychain_is_a_sentence():
    def hang(argv, **kw):
        raise subprocess.TimeoutExpired(argv, 20)

    with pytest.raises(keystore.KeyStoreError, match="did not answer"):
        keystore.status(runner=hang)


def test_a_missing_security_binary_is_a_sentence():
    def gone(argv, **kw):
        raise FileNotFoundError(argv[0])

    with pytest.raises(keystore.KeyStoreError, match="could not reach"):
        keystore.status(runner=gone)


# ------------------------------------------------------------ the command line

@pytest.fixture
def keychain(monkeypatch, tmp_path):
    """The real CLI, with `security` swapped for the fake and a private home."""
    fake = FakeSecurity()
    monkeypatch.setattr(keystore, "_available", lambda: None)
    monkeypatch.setattr(keystore.subprocess, "run", fake)
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return fake


def _stdin(monkeypatch, text, tty=False):
    import io

    stream = io.StringIO(text)
    stream.isatty = lambda: tty
    monkeypatch.setattr(cli.sys, "stdin", stream)


def test_key_set_reads_standard_input_and_prints_no_key(keychain, monkeypatch, capsys):
    _stdin(monkeypatch, KEY + "\n")
    assert cli.main(["key", "set"]) == 0
    out = capsys.readouterr()
    assert KEY not in out.out + out.err
    assert KEY[-4:] in out.out
    assert keychain.stored == KEY
    assert all(KEY not in part for argv, _ in keychain.calls for part in argv)


def test_key_set_json_has_no_key_in_it(keychain, monkeypatch, capsys):
    _stdin(monkeypatch, KEY)
    assert cli.main(["key", "set", "--json"]) == 0
    raw = capsys.readouterr().out
    body = json.loads(raw)
    assert body["set"] is True and body["last4"] == KEY[-4:] and body["action"] == "set"
    assert KEY not in raw and KEY[:-4] not in raw


def test_key_set_has_no_argument_that_could_carry_the_key(monkeypatch, capsys):
    """argv is visible in `ps`. `key set` takes no positional argument and no
    option, so there is nowhere on the command line to put the key."""
    _stdin(monkeypatch, "")
    with pytest.raises(SystemExit):
        cli.main(["key", "set", KEY])
    for flag in ("--key", "--value", "-k", "--api-key"):
        with pytest.raises(SystemExit):
            cli.main(["key", "set", flag, KEY])
    assert KEY not in capsys.readouterr().out


def test_key_set_with_nothing_on_stdin_says_so_in_json(keychain, monkeypatch, capsys):
    _stdin(monkeypatch, "")
    assert cli.main(["key", "set", "--json"]) == 2
    body = json.loads(capsys.readouterr().out)
    assert "No key was given" in body["error"]
    assert keychain.calls == []


def test_key_status_and_clear_through_the_cli(keychain, monkeypatch, capsys):
    _stdin(monkeypatch, KEY)
    cli.main(["key", "set", "--json"])
    capsys.readouterr()

    assert cli.main(["key", "status", "--json"]) == 0
    status = json.loads(capsys.readouterr().out)
    assert status["set"] is True and status["last4"] == KEY[-4:]

    assert cli.main(["key", "clear", "--json"]) == 0
    cleared = json.loads(capsys.readouterr().out)
    assert cleared["set"] is False and cleared["removed"] is True

    assert cli.main(["key", "status", "--json"]) == 0
    assert json.loads(capsys.readouterr().out)["set"] is False


def test_clearing_the_key_deletes_the_odds_it_fetched(keychain, monkeypatch, capsys, tmp_path):
    from overlay_engine import oddsapi

    cache = oddsapi.Cache()
    cache.put("americanfootball_nfl", ("us",), ("h2h",), [], {"x-requests-remaining": "9"}, 1.0)
    cache.remember(oddsapi.Quota(remaining=9, used=1, last=1), 1.0)
    assert list((tmp_path / "oddsapi").rglob("*.json"))
    _stdin(monkeypatch, KEY)
    cli.main(["key", "set"])
    cli.main(["key", "clear"])
    assert not list((tmp_path / "oddsapi").rglob("*.json")), "the odds outlived the key"


def test_a_refused_key_through_the_cli_exits_2_and_prints_no_key(keychain, monkeypatch, capsys):
    _stdin(monkeypatch, "not a key at all, with spaces")
    assert cli.main(["key", "set", "--json"]) == 2
    out = capsys.readouterr()
    assert "not a key at all" not in out.out + out.err
