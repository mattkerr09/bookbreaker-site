"""The window cannot phone home, and the exceptions are things you press or switch on.

bookbreaker.bet says the ledger never leaves your machine and there is no
account to create. An update check is the natural thing to add to a desktop
app, and it quietly tells a server that someone at this address runs this app
right now.

Until 0.1.7 Bookbreaker had no updater at all, deliberately. Now it has one,
and it is a button: Check for updates on the version line, and the app menu's
Check for Updates…, which presses the same button. The check runs in the Rust
shell (`check_update` in main.rs), never at launch, never on a timer, and
installs nothing without a second press. Docket and Crisp check at launch and
every thirty minutes, so a later session copying them would be doing an
obviously reasonable thing; these tests are what stops it.

The second named path is the Live prices switch on the Arbitrage page. It
starts off, and only while it is on does the window pass `--live` to the
engine, which reads Kalshi's and Polymarket US's public prices. The window itself
still makes no request: the fetch is the engine's, a program on this Mac, and
the CSP still permits no origin. Where a test below says "while the switch is
off", the engine side of it (nothing touches a network without --live) is in
tests/test_xvenue.py.
"""

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
CONF = json.loads((UI / "src-tauri" / "tauri.conf.json").read_text())
RUST = (UI / "src-tauri" / "src" / "main.rs").read_text()
JS = (UI / "src" / "app.js").read_text()
HTML = (UI / "src" / "index.html").read_text()


def _braced(text: str, anchor: str) -> str:
    """The balanced {...} block that opens at the first brace after `anchor`."""
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def _called(text: str, call: str) -> list[str]:
    """The argument text of every `call(` in `text`, to its matching paren."""
    out = []
    for m in re.finditer(re.escape(call) + r"\(", text):
        depth, i = 1, m.end()
        while depth and i < len(text):
            depth += {"(": 1, ")": -1}.get(text[i], 0)
            i += 1
        out.append(text[m.end():i - 1])
    return out


def test_the_shell_links_no_http_client():
    """A network crate in the manifest is the first step, and the easiest to
    take by accident while adding something else. The updater plugin brings
    one in underneath it, and is the exception named below; nothing else may."""
    cargo = (UI / "src-tauri" / "Cargo.toml").read_text().lower()
    for crate in ("reqwest", "ureq", "hyper", "isahc", "curl", "surf",
                  "tauri-plugin-http", "tauri-plugin-websocket", "tauri-plugin-upload"):
        assert f"\n{crate} " not in cargo and f'\n{crate} =' not in cargo, crate


def test_the_updater_is_the_one_named_exception():
    """One plugin, one endpoint, and an endpoint with no template fields, so
    the request carries no version, platform or anything else about the
    person: it is a plain GET of one file."""
    cargo = (UI / "src-tauri" / "Cargo.toml").read_text()
    assert re.search(r'^tauri-plugin-updater = ', cargo, re.M)
    updater = CONF["plugins"]["updater"]
    assert updater["endpoints"] == ["https://bookbreaker.bet/updater.json"]
    assert "{{" not in json.dumps(updater["endpoints"])
    assert updater["pubkey"], "an updater with no public key cannot verify anything"


def test_nothing_checks_for_updates_at_launch():
    """Setup builds the menu and stops. The one function that reaches the
    updater is `check_update`, and the window calls it only from a press."""
    setup = _braced(RUST, ".setup(|app|")
    for reach in (".updater(", "updater_builder", "check_update", "checkForUpdates",
                  "install_update", "eval(", "spawn"):
        assert reach not in setup, f"setup reaches for the updater: {reach}"
    check = _braced(RUST, "async fn check_update(")
    for reach in (".updater(", ".updater_builder("):
        assert RUST.count(reach) == check.count(reach), (
            f"{reach} is called outside check_update")
    assert check.count(".updater(") == 1


def test_nothing_checks_for_updates_on_a_timer():
    """Docket's thirty-minute poll is exactly what this app does not do. The
    shell starts no loop at all, and the window's one timer reports download
    progress after the person has said yes."""
    for loop in ("sleep(", "interval(", "thread::spawn", "async_runtime::spawn"):
        assert loop not in RUST, f"main.rs starts a loop: {loop}"
    for timer in ("setInterval", "setTimeout", "requestAnimationFrame"):
        for body in _called(JS, timer):
            for reach in ("check_update", "checkForUpdates", "install_update"):
                assert reach not in body, f"a {timer} reaches {reach}"


def test_the_window_checks_only_when_pressed():
    """checkForUpdates is defined, handed to the button's click, and exposed
    for the menu item. Nothing else in the window calls it, at load or later."""
    body = _braced(JS, "function checkForUpdates()")
    outside = JS.replace(body, "")
    uses = [m.start() for m in re.finditer(r"checkForUpdates", outside)]
    allowed = ("function checkForUpdates()",
               "window.checkForUpdates = checkForUpdates;",
               'document.getElementById("check-updates").addEventListener("click", checkForUpdates);')
    allowed_at = set()
    for line in allowed:
        for m in re.finditer(re.escape(line), outside):
            allowed_at.update(range(m.start(), m.end()))
    stray = [outside[max(0, u - 40):u + 40] for u in uses if u not in allowed_at]
    assert not stray, f"checkForUpdates is called from somewhere other than a press: {stray}"
    assert all(line in outside for line in allowed[1:]), "the button is no longer wired"
    # The command itself is invoked only from inside the function.
    assert "check_update" not in outside


def test_the_menu_item_presses_the_same_button():
    """One update path, not two: the menu item calls the window's own
    function, so its answer appears in the same card the button uses."""
    assert "Check for Updates\\u{2026}" in RUST
    menu = _braced(RUST, ".on_menu_event(|app, event|")
    assert "MENU_CHECK_FOR_UPDATES" in menu
    assert "window.checkForUpdates" in menu
    assert ".updater(" not in menu


def test_nothing_installs_without_a_yes():
    """install_update is reachable only from the Install and restart button,
    and the shell installs only the update a press of Check for updates found."""
    body = _braced(JS, "function checkForUpdates()")
    install = body[body.index("const install = () =>"):]
    install = _braced(install, "const install = () =>")
    assert body.count('call("install_update")') == 1
    assert 'call("install_update")' in install
    assert "install_update" not in JS.replace(body, "")
    refs = re.findall(r"\binstall\b(?! = \(\) =>)", body.replace(install, ""))
    assert refs == ["install"], f"install is reached other than by its button: {refs}"
    assert '["Install and restart", "upd-go", install]' in body
    rust_install = _braced(RUST, "async fn install_update(")
    assert "PendingUpdate" in rust_install and ".take()" in rust_install


def test_the_window_cannot_reach_the_updater_itself():
    """The plugin's own JavaScript commands need a capability. None is granted,
    so the window cannot check, download or install except through the
    shell's three commands, which are the ones these tests read."""
    caps = UI / "src-tauri" / "capabilities"
    granted = [p.read_text() for p in caps.glob("*.json")] if caps.is_dir() else []
    granted.append(json.dumps(CONF["app"]["security"].get("capabilities", [])))
    for text in granted:
        assert "updater:" not in text, "a capability lets the window drive the updater"


def test_the_release_notes_are_text_not_markup():
    """The notes come from the update details, which the signature does not
    cover; only the download is signed. Markup from there must never reach a
    window that can run the engine."""
    body = _braced(JS, "function checkForUpdates()")
    for sink in ("innerHTML", "outerHTML", "insertAdjacentHTML", "document.write"):
        assert sink not in body, sink
    assert "notes.textContent = body;" in body


def test_the_frontend_makes_no_requests():
    js = (UI / "src" / "app.js").read_text()
    for call in ("fetch(", "XMLHttpRequest", "WebSocket", "EventSource",
                 "navigator.sendBeacon"):
        assert call not in js, call


def test_no_remote_origin_is_referenced_anywhere_in_the_ui():
    """An <img>, a font or a script from a CDN is a request too, and it leaks
    the same fact as an update check."""
    for name in ("index.html", "app.css", "app.js"):
        text = (UI / "src" / name).read_text()
        urls = re.findall(r"https?://[^\s\"')]+", text)
        assert urls == [], f"{name} references {urls}"


def test_the_csp_permits_no_external_origin():
    """The backstop. Even if code tried, the page cannot reach out; the update
    check is made by the shell, not the page."""
    csp = CONF["app"]["security"]["csp"]
    connect = csp["connect-src"]
    assert "'self'" in connect
    # ipc: and ipc.localhost are Tauri's own bridge, not the network.
    for token in connect.split():
        assert token in ("'self'", "ipc:", "http://ipc.localhost"), token
    for key, value in csp.items():
        assert "https://" not in value or key == "connect-src", (key, value)


def test_the_engine_the_window_runs_is_the_bundled_one():
    """A shell that could run an arbitrary binary could run one that does have
    a network. The path is resolved inside the bundle, with an environment
    override that only helps a developer who already has the source."""
    rust = (UI / "src-tauri" / "src" / "main.rs").read_text()
    assert "../Resources/engine/overlay-engine" in rust
    assert "BOOKBREAKER_ENGINE" in rust


def test_the_version_in_the_window_is_the_version_being_built():
    """The footer names the version, so it can be wrong.

    It sits beside Check for updates, and the app checks only when that is
    pressed, so the person still has to know what they are running; the
    string in the footer is load-bearing rather than decorative. A stale one
    is worse than none: it tells someone on an old build that they are current.
    """
    shown = re.findall(r"You are running ([0-9]+\.[0-9]+\.[0-9]+)",
                       (UI / "src" / "index.html").read_text())
    assert shown, "the window no longer tells the user which version it is"
    assert set(shown) == {CONF["version"]}, (
        f"the window says {set(shown)} and tauri.conf.json says "
        f"{CONF['version']}"
    )


def test_the_footer_says_when_it_checks():
    """The sentence and the button are one thing: the version line carries the
    button, and says the app checks only when it is pressed. "This app never
    checks on its own" and "Nothing leaves this machine." stopped being true
    the day the button shipped."""
    ver = re.search(r'<span class="ver">(.*?)</span>', HTML, re.S).group(1)
    assert 'id="check-updates"' in ver, "the button is not on the version line"
    assert "only when you" in ver and "press" in ver
    assert "never checks on its own" not in HTML
    assert "Nothing leaves this machine." not in HTML


def test_the_window_still_names_no_url():
    """The footer names a domain on purpose, as text. The moment it gains a
    scheme it becomes a link, and a link in a window that promises to make no
    requests is the first step to one that does."""
    text = (UI / "src" / "index.html").read_text()
    assert "https://" not in text and "http://" not in text
    assert "bookbreaker.bet" in text


# ---------------------------------------------------------------- Live prices
# The second named path. Off by default, remembered, and the only thing that
# makes the engine read the internet.

def _live_builder() -> str:
    """The argv the window builds for the Arbitrage page."""
    return re.search(r"\n    board: \(\) => \[(.*?)\],\n    results:", JS, re.S).group(1)


def test_live_prices_is_the_second_named_network_path():
    """The note a person reads under 'What leaves this Mac' names the three
    things that reach the internet, says all three start with them, and says what
    the venues see, so a person can decide without reading code. The third,
    live sportsbook odds, is pinned in tests/test_odds_source_window.py."""
    note = re.search(r'<div class="privacy-pop">(.*?)</div>', HTML, re.S).group(1)
    assert len(re.findall(r"<li>", note)) == 3, "three named paths, not two and not four"
    assert "<b>Check for updates</b>" in note and "<b>Live prices</b>" in note
    live = note[note.index("<b>Live prices</b>"):]
    assert "starts off" in live and "when you turn it on" in live
    assert "Kalshi" in live and "Polymarket US" in live and "internet address" in live
    assert "no account" in live and "no amounts" in live and "not your state" in live
    assert "gamma" not in note and "international" not in note.lower()
    assert "with the switch off nothing is fetched" in live
    assert "yours to start" in note


def test_the_live_switch_starts_off():
    tag = re.search(r'<input id="b-live"[^>]*>', HTML).group(0)
    assert 'type="checkbox"' in tag
    assert "checked" not in tag, "Live prices must start off"
    restore = _braced(JS, "(function restoreLive()")
    assert 'sw.checked = store.get("bb.live", false) === true;' in restore, (
        "only a stored, explicit yes turns it on when the window opens")


def test_the_choice_is_remembered_in_this_windows_own_storage_and_nowhere_else():
    restore = _braced(JS, "(function restoreLive()")
    assert 'store.set("bb.live", sw.checked);' in restore
    for sink in ("document.cookie", "sendBeacon", "indexedDB"):
        assert sink not in JS, sink


def test_the_engine_is_asked_for_live_prices_only_with_the_switch_on():
    """--live is on the command line in one place, behind the switch."""
    builder = _live_builder()
    assert builder.count('"--live"') == 1
    assert '...(liveOn() ? ["--live"] : [])' in builder
    assert JS.count('"--live"') == 1, "the flag is built nowhere else"
    assert re.search(r'function liveOn\(\) \{ return document\.getElementById\("b-live"\)\.checked; \}', JS)


def test_the_switch_is_read_before_the_first_board_is_drawn():
    """A stored yes must be in place when the page first runs, and a person who
    never touched it must get the demo. Restoring after show('board') would
    draw once with the wrong answer, and a live read nobody had just asked for."""
    assert JS.index("(function restoreLive()") < JS.index('\nshow("board");')


def test_nothing_in_the_window_reads_prices_on_a_timer():
    """Prices are read when a person asks: opening the page, pressing Find arbs,
    flipping the switch. Never on a schedule."""
    for timer in ("setInterval", "setTimeout", "requestAnimationFrame"):
        for body in _called(JS, timer):
            for reach in ('run("board")', "liveOn", "--live", "showBoard", "drawBoard"):
                assert reach not in body, f"a {timer} reaches {reach}"
    restore = _braced(JS, "(function restoreLive()")
    assert JS.replace(restore, "").count('run("board")') == 0, (
        "the board is run by the switch, the button and the first page view, and nothing else")
    assert "visibilitychange" not in JS and '"focus"' not in JS, "no refresh when the window comes back"


def test_a_live_board_names_the_venues_not_a_url():
    """The window knows which venues it asks about; it knows no address."""
    region = JS[JS.index("function liveOn()"):JS.index("function drawBoard")]
    assert "Kalshi" in region and "Polymarket US" in region
    assert not re.search(r"https?:|\.com|\.bet|\.us\b", region)
