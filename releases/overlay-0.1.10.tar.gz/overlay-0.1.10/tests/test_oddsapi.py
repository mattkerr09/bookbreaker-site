"""Live sportsbook odds, read with the person's own key, without a key, a socket
or a credit.

The payloads here are built from the documented response shape of
GET /v4/sports/{sport}/odds (https://the-odds-api.com/liveapi/guides/v4/):
events with `id`, `commence_time`, `home_team`, `away_team`, and `bookmakers`,
each with its own `last_update` and `markets` of `outcomes`. The fetcher is a
fake that answers the way the API does, including the three response headers
that carry the credits. The real API is never called.

What these pin, because each is a way to cost a person money or a credential:
the credits a refresh will use are said BEFORE it runs and equal markets x
regions per league; a second press inside a minute spends nothing; the key
goes nowhere but into the fetcher; a book you cannot bet at prices the market
and is never a leg.
"""

import io
import json
from datetime import date, datetime, timezone
from email.message import Message
from types import SimpleNamespace
from urllib.error import HTTPError

import pytest

from overlay_engine import board, cli, keystore, oddsapi
from overlay_engine.oddsapi import (
    CACHE_SECONDS,
    CREDITS_GONE,
    Cache,
    OddsApiError,
    estimate,
    explain,
    odds_api_fetcher,
    refresh,
)

NOW = 1_800_000_000.0
KEY = "0123456789abcdef0123456789abcdef"          # made up; not a real key
TODAY = date(2026, 10, 9)


def iso(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def book(key, home, away, updated=NOW - 6, home_name="Kansas City Chiefs",
         away_name="Buffalo Bills", market="h2h", dated=True):
    block = {"key": market, "outcomes": [{"name": home_name, "price": home},
                                         {"name": away_name, "price": away}]}
    out = {"key": key, "title": key.title(), "markets": [block]}
    if dated:
        out["last_update"] = iso(updated)
        block["last_update"] = iso(updated)
    return out


def event(eid, books, start=NOW + 3600, home="Kansas City Chiefs", away="Buffalo Bills",
          sport="americanfootball_nfl"):
    return {"id": eid, "sport_key": sport, "sport_title": "NFL",
            "commence_time": iso(start), "home_team": home, "away_team": away,
            "bookmakers": books}


def world():
    """Four games: one with a real arb and a +EV price, one whose only arb needs
    Pinnacle's price, one already under way, and a quiet one."""
    return [
        # DraftKings 2.10 on home and FanDuel 2.05 on away cross; Pinnacle says 50/50.
        event("e-arb", [book("draftkings", 2.10, 1.80), book("fanduel", 1.80, 2.05),
                        book("pinnacle", 1.95, 1.95)]),
        # The only arb here would be DraftKings home 2.00 against PINNACLE away 2.20,
        # and Pinnacle takes no bets from a US bettor.
        event("e-ref", [book("draftkings", 2.00, 1.85, home_name="Dallas Cowboys",
                             away_name="New York Giants"),
                        book("pinnacle", 1.80, 2.20, home_name="Dallas Cowboys",
                             away_name="New York Giants")],
              home="Dallas Cowboys", away="New York Giants"),
        # Under way: an arb on paper, stale before it is read.
        event("e-live", [book("draftkings", 2.10, 1.80), book("fanduel", 1.80, 2.05)],
              start=NOW - 600, home="Miami Dolphins", away="New England Patriots"),
    ]


class FakeApi:
    """The Odds API as far as this code can tell: payloads per league, the
    credits header worked out by the documented rule, and a running allowance."""

    def __init__(self, payloads=None, remaining=500):
        self.payloads = payloads or {"americanfootball_nfl": world()}
        self.remaining = remaining
        self.used = 500 - remaining
        self.calls = []

    def __call__(self, path, params):
        self.calls.append((path, dict(params)))
        sport = path.split("/")[3]
        cost = len(params["markets"].split(",")) * len(params["regions"].split(","))
        self.remaining -= cost
        self.used += cost
        headers = {"x-requests-remaining": str(self.remaining),
                   "x-requests-used": str(self.used), "x-requests-last": str(cost)}
        return self.payloads.get(sport, []), headers


@pytest.fixture
def home(monkeypatch, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


class Clock:
    def __init__(self, now=NOW):
        self.now = now

    def __call__(self):
        return self.now


def est(*sports, regions=None, markets=None):
    return estimate(list(sports) or ["nfl"], regions, markets, today=TODAY)


# ------------------------------------------------------------ the cost, said before the fetch

def test_the_cost_is_markets_times_regions_per_league():
    """The documented rule: 'cost = [number of markets specified] x [number of
    regions specified]', one request per league."""
    for leagues in (["nfl"], ["nfl", "nba", "mlb"]):
        for regions in (["us"], ["us", "eu"], ["us", "us2", "eu", "us_ex"]):
            for markets in (["h2h"], ["h2h", "totals"], ["h2h", "spreads", "totals"]):
                got = estimate(leagues, regions, markets, today=TODAY)
                assert got.per_league == len(markets) * len(regions)
                assert got.total == len(leagues) * len(markets) * len(regions)
                assert got.as_dict()["credits"] == got.total
                assert set(got.as_dict()["by_league"].values()) == {len(markets) * len(regions)}


def test_the_default_refresh_is_moneylines_in_us_and_eu_for_the_leagues_in_season():
    got = estimate(today=date(2026, 10, 9))
    assert [lg.alias for lg in got.leagues] == ["nfl", "ncaaf", "mlb", "nhl"]
    assert got.regions == ("us", "eu") and got.markets == ("h2h",)
    assert got.total == 4 * 2 * 1 == 8


def test_some_league_is_in_season_every_day_of_the_year():
    """The default refresh is 'the leagues in season'. A day with none would turn
    the window's cost line, and the build's probe of it, into an error."""
    from datetime import timedelta

    day = date(2027, 1, 1)
    while day.year == 2027:
        assert estimate(today=day).leagues, day
        day += timedelta(days=1)
    assert estimate(today=date(2028, 2, 29)).leagues, "a leap day too"


def test_the_leagues_in_season_move_with_the_calendar():
    assert [lg.alias for lg in estimate(today=date(2027, 1, 20)).leagues] == ["nfl", "ncaaf", "nba", "ncaab", "nhl"]
    assert [lg.alias for lg in estimate(today=date(2027, 7, 4)).leagues] == ["mlb"]


def test_the_sentence_names_the_number_and_the_product():
    text = estimate(["nfl", "nhl"], ["us", "eu"], ["h2h", "totals"], today=TODAY).sentence()
    assert "up to 8 of your Odds API credits" in text
    assert "2 leagues" in text and "2 regions" in text and "2 bet types" in text
    assert "A league with no games listed costs nothing" in text
    assert "1 credit" in estimate(["nfl"], ["us"], ["h2h"], today=TODAY).sentence()


def test_the_cost_rule_is_held_verbatim():
    assert oddsapi.COST_RULE == ("The usage quota cost is 1 per region per market. "
                                 "cost = [number of markets specified] x [number of regions specified]")
    assert "liveapi/guides/v4" in oddsapi.COST_RULE_SOURCE


def test_an_unknown_choice_is_a_sentence_not_a_traceback():
    with pytest.raises(OddsApiError, match="not a league"):
        estimate(["cricket"])
    with pytest.raises(OddsApiError, match="not a region"):
        estimate(["nfl"], ["mars"])
    with pytest.raises(OddsApiError, match="not a bet type"):
        estimate(["nfl"], None, ["player_points"])


def test_the_pickers_the_window_draws_come_from_the_engine():
    got = oddsapi.choices(est("nfl", "nba"), today=TODAY)
    assert [x["alias"] for x in got["leagues"]] == ["nfl", "ncaaf", "nba", "ncaab", "mlb", "nhl"]
    assert [x["alias"] for x in got["leagues"] if x["picked"]] == ["nfl", "nba"]
    assert [x["key"] for x in got["regions"] if x["picked"]] == ["us", "eu"]
    assert {x["key"] for x in got["markets"]} == {"h2h", "spreads", "totals"}
    assert next(x for x in got["leagues"] if x["alias"] == "nba")["in_season"] is False


def test_sport_keys_are_the_documented_ones():
    assert {lg.alias: lg.key for lg in oddsapi.LEAGUES} == {
        "nfl": "americanfootball_nfl", "ncaaf": "americanfootball_ncaaf",
        "nba": "basketball_nba", "ncaab": "basketball_ncaab",
        "mlb": "baseball_mlb", "nhl": "icehockey_nhl"}


# ------------------------------------------------------------ fetching, and counting what it cost

def test_a_refresh_asks_for_decimal_odds_and_the_chosen_regions_and_markets(home):
    api = FakeApi()
    refresh(est("nfl", regions=["us", "eu"], markets=["h2h", "totals"]), KEY, clock=Clock(), fetcher=api)
    (path, params), = api.calls
    assert path == "/v4/sports/americanfootball_nfl/odds"
    assert params["regions"] == "us,eu" and params["markets"] == "h2h,totals"
    assert params["oddsFormat"] == "decimal" and params["apiKey"] == KEY


def test_one_request_per_league_and_the_credits_come_off_the_headers(home):
    api = FakeApi({"americanfootball_nfl": world(), "icehockey_nhl": []}, remaining=500)
    got = refresh(est("nfl", "nhl", regions=["us", "eu"], markets=["h2h", "totals"]),
                  KEY, clock=Clock(), fetcher=api)
    assert len(api.calls) == 2
    assert [r.credits for r in got.reads] == [4, 4]
    assert got.spent == 8
    assert (got.quota.remaining, got.quota.used, got.quota.last) == (492, 8, 4)
    text = oddsapi.credits_line(got)
    assert "used 8 credits" in text and "492 left this month (8 used so far)" in text


def test_what_a_refresh_cost_is_the_header_not_the_estimate(home):
    """The estimate is an upper bound: empty responses cost nothing. The number
    after the fetch is what the API says it charged."""
    class Cheap(FakeApi):
        def __call__(self, path, params):
            payload, headers = super().__call__(path, params)
            headers["x-requests-last"] = "1"
            return payload, headers

    got = refresh(est("nfl", regions=["us", "eu"], markets=["h2h", "totals"]),
                  KEY, clock=Clock(), fetcher=Cheap())
    assert got.estimate.total == 4 and got.spent == 1


def test_a_response_with_no_credit_headers_says_it_does_not_know(home):
    got = refresh(est("nfl"), KEY, clock=Clock(), fetcher=lambda p, q: (world(), {}))
    text = oddsapi.credits_line(got)
    assert "did not say what this refresh cost" in text and "did not say how many credits are left" in text
    assert oddsapi.summary(got)["cost"]["spent"] is None


# ------------------------------------------------------------ sixty seconds

def test_a_second_press_inside_a_minute_spends_nothing(home):
    api, clock = FakeApi(), Clock()
    first = refresh(est("nfl"), KEY, clock=clock, fetcher=api)
    clock.now = NOW + CACHE_SECONDS - 1
    second = refresh(est("nfl"), KEY, clock=clock, fetcher=api)
    assert len(api.calls) == 1, "the second press went back to the API"
    assert first.spent == 2 and second.spent == 0 and second.all_cached
    assert "No credits were spent" in oddsapi.credits_line(second)
    assert "reused for 60 seconds" in oddsapi.source_line(second)


def test_a_minute_later_it_fetches_again(home):
    api, clock = FakeApi(), Clock()
    refresh(est("nfl"), KEY, clock=clock, fetcher=api)
    clock.now = NOW + CACHE_SECONDS + 1
    again = refresh(est("nfl"), KEY, clock=clock, fetcher=api)
    assert len(api.calls) == 2 and not again.all_cached and again.spent == 2


def test_the_cache_is_per_choice_so_a_different_choice_is_a_different_cost(home):
    api, clock = FakeApi(), Clock()
    refresh(est("nfl", regions=["us"]), KEY, clock=clock, fetcher=api)
    refresh(est("nfl", regions=["us", "eu"]), KEY, clock=clock, fetcher=api)
    assert len(api.calls) == 2


def test_a_cached_read_is_aged_from_when_it_was_fetched_not_from_now(home):
    api, clock = FakeApi(), Clock()
    refresh(est("nfl"), KEY, clock=clock, fetcher=api)
    clock.now = NOW + 50
    got = refresh(est("nfl"), KEY, clock=clock, fetcher=api)
    assert got.oldest == NOW
    quote = got.markets[0].quotes[0]
    assert quote.age(got.now) == pytest.approx(50 + 6), "a minute-old answer is a minute older"


def test_a_clock_that_ran_backwards_does_not_serve_the_cache(home):
    api, clock = FakeApi(), Clock()
    refresh(est("nfl"), KEY, clock=clock, fetcher=api)
    clock.now = NOW - 30
    refresh(est("nfl"), KEY, clock=clock, fetcher=api)
    assert len(api.calls) == 2


def test_the_cache_holds_the_odds_and_never_the_key(home):
    refresh(est("nfl"), KEY, clock=Clock(), fetcher=FakeApi())
    files = [p for p in (home / "oddsapi").rglob("*") if p.is_file()]
    assert files, "nothing was cached"
    for path in files:
        assert KEY not in path.read_text(), path
        assert oct(path.stat().st_mode & 0o777) == oct(0o600), "the odds are for their owner"
    assert oct((home / "oddsapi").stat().st_mode & 0o777) == oct(0o700)


def test_a_corrupt_cache_file_is_a_miss_not_a_crash(home):
    api = FakeApi()
    refresh(est("nfl"), KEY, clock=Clock(), fetcher=api)
    for path in (home / "oddsapi" / "cache").glob("*.json"):
        path.write_text("{ not json")
    refresh(est("nfl"), KEY, clock=Clock(), fetcher=api)
    assert len(api.calls) == 2


def test_the_last_credits_reading_is_kept_for_the_window(home):
    refresh(est("nfl"), KEY, clock=Clock(), fetcher=FakeApi())
    assert Cache().recall() == {"remaining": 498, "used": 2, "last": 2, "at": NOW}


# ------------------------------------------------------------ errors in plain words

def _http(status, body, headers=None):
    msg = Message()
    for k, v in (headers or {}).items():
        msg[k] = v
    return HTTPError("https://api.the-odds-api.com/v4/x?apiKey=" + KEY, status, "x", msg,
                     io.BytesIO(json.dumps(body).encode() if isinstance(body, dict) else body))


class _Opener:
    """An opener that only ever fails, the way urllib does."""

    def __init__(self, error):
        self.error, self.urls = error, []

    def __call__(self, url, timeout=None):
        self.urls.append(url)
        raise self.error


class _Response:
    def __init__(self, body, headers):
        self._body, self.headers = body, headers

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def test_used_up_credits_are_said_in_plain_words():
    for err in (
        explain(401, json.dumps({"error_code": "OUT_OF_USAGE_CREDITS", "message": "x"}), {}),
        explain(429, "", {"x-requests-remaining": "0"}),
        explain(401, "", {"X-Requests-Remaining": "0"}),
    ):
        assert str(err) == CREDITS_GONE and err.reason == "out_of_credits"
    assert "used up" in CREDITS_GONE and "paid plan" in CREDITS_GONE and "the-odds-api.com" in CREDITS_GONE


def test_a_bad_key_is_said_in_plain_words():
    for body in ({"error_code": "INVALID_KEY"}, {"error_code": "MISSING_KEY"}, {}):
        err = explain(401, json.dumps(body), {})
        assert err.reason == "bad_key" and "did not accept your key" in str(err)
    assert "turned off" in str(explain(401, json.dumps({"error_code": "DEACTIVATED_KEY"}), {}))


def test_a_rate_limit_is_not_mistaken_for_running_out_of_credits():
    err = explain(429, json.dumps({"error_code": "EXCEEDED_FREQ_LIMIT"}), {"x-requests-remaining": "400"})
    assert err.reason == "slow_down" and "slow down" in str(err)


def test_their_outage_and_a_rejected_request_are_sentences():
    assert explain(503, "<html>", {}).reason == "their_problem"
    odd = explain(422, json.dumps({"error_code": "INVALID_REGION"}), {})
    assert odd.reason == "rejected" and "INVALID_REGION" in str(odd)


@pytest.mark.parametrize("status, body, headers", [
    (401, {"error_code": "INVALID_KEY"}, {}),
    (401, {"error_code": "OUT_OF_USAGE_CREDITS"}, {"x-requests-remaining": "0"}),
    (429, {"error_code": "EXCEEDED_FREQ_LIMIT"}, {}),
    (500, b"boom", {}),
])
def test_no_http_failure_shows_the_key_or_the_address(status, body, headers):
    opener = _Opener(_http(status, body, headers))
    with pytest.raises(OddsApiError) as caught:
        odds_api_fetcher(opener=opener)("/v4/sports/americanfootball_nfl/odds", {"apiKey": KEY, "regions": "us"})
    text = str(caught.value)
    assert KEY not in text and "apiKey" not in text and "https://" not in text and "api.the-odds-api" not in text
    assert caught.value.__cause__ is None and caught.value.__suppress_context__


def test_an_unreachable_api_is_a_sentence_without_the_address():
    from urllib.error import URLError

    opener = _Opener(URLError("nodename nor servname provided: api.the-odds-api.com " + KEY))
    with pytest.raises(OddsApiError) as caught:
        odds_api_fetcher(opener=opener)("/v4/sports/x/odds", {"apiKey": KEY})
    assert "could not reach The Odds API" in str(caught.value)
    assert KEY not in str(caught.value) and caught.value.reason == "offline"


def test_an_answer_that_is_not_json_is_a_sentence():
    class Opener:
        def __call__(self, url, timeout=None):
            return _Response(b"<html>maintenance</html>", Message())

    with pytest.raises(OddsApiError, match="could not read"):
        odds_api_fetcher(opener=Opener())("/v4/sports/x/odds", {"apiKey": KEY})


def test_a_good_answer_returns_the_payload_and_headers():
    headers = Message()
    headers["x-requests-remaining"] = "495"

    class Opener:
        urls = []

        def __call__(self, url, timeout=None):
            self.urls.append(url)
            return _Response(json.dumps(world()).encode(), headers)

    opener = Opener()
    payload, got = odds_api_fetcher(opener=opener)(
        "/v4/sports/americanfootball_nfl/odds", {"apiKey": KEY, "regions": "us,eu"})
    assert len(payload) == 3 and got["x-requests-remaining"] == "495"
    assert opener.urls[0].startswith("https://api.the-odds-api.com/v4/sports/americanfootball_nfl/odds?")


def test_the_key_and_the_odds_go_to_one_host_over_https():
    import re
    from pathlib import Path

    assert oddsapi.HOST == "api.the-odds-api.com" and oddsapi.BASE == "https://api.the-odds-api.com"
    source = Path(oddsapi.__file__).read_text()
    assert set(re.findall(r"https?://([A-Za-z0-9.-]+)", source)) <= {"api.the-odds-api.com", "the-odds-api.com"}
    assert "http://" not in source


def test_a_redirect_is_not_followed_because_the_key_is_in_the_address():
    assert oddsapi.NoRedirect().redirect_request(None, None, 302, "Found", {}, "https://elsewhere.test/") is None


def test_an_unexpected_failure_is_reported_by_type_only(home):
    """An exception out of the network layer may carry the request address,
    and the address carries the key. Its message is not passed on."""
    def broken(path, params):
        raise RuntimeError(f"boom at https://api.the-odds-api.com/v4?apiKey={KEY}")

    with pytest.raises(OddsApiError) as caught:
        refresh(est("nfl"), KEY, clock=Clock(), fetcher=broken)
    assert "RuntimeError" in str(caught.value) and KEY not in str(caught.value)


def test_a_failure_after_one_league_keeps_what_was_read(home):
    class Second(FakeApi):
        def __call__(self, path, params):
            if len(self.calls) >= 1:
                self.calls.append((path, params))
                raise explain(401, json.dumps({"error_code": "OUT_OF_USAGE_CREDITS"}), {})
            return super().__call__(path, params)

    got = refresh(est("nfl", "nhl"), KEY, clock=Clock(), fetcher=Second())
    assert [r.league.alias for r in got.reads] == ["nfl"]
    assert got.errors == [CREDITS_GONE] and got.markets


def test_a_failure_before_anything_was_read_is_raised_not_shown_as_an_empty_board(home):
    def refuse(path, params):
        raise explain(401, json.dumps({"error_code": "INVALID_KEY"}), {})

    with pytest.raises(OddsApiError, match="did not accept your key"):
        refresh(est("nfl"), KEY, clock=Clock(), fetcher=refuse)


# ------------------------------------------------------------ prices, dated by the book

def test_prices_are_aged_by_the_feeds_own_last_update(home):
    got = refresh(est("nfl"), KEY, clock=Clock(), fetcher=FakeApi())
    assert got.dated and not got.undated
    quote = got.markets[0].quotes[0]
    assert quote.seen_at == NOW - 6 and quote.provenance == "measured"
    assert quote.age(got.now) == 6


def test_a_price_the_book_did_not_date_reads_as_assumed(home):
    payload = [event("e1", [book("draftkings", 2.10, 1.80, dated=False),
                            book("fanduel", 1.80, 2.05)])]
    got = refresh(est("nfl"), KEY, clock=Clock(), fetcher=FakeApi({"americanfootball_nfl": payload}))
    assert got.undated == 2 and got.dated == 2
    undated = [q for m in got.markets for q in m.quotes if q.book == "dk"]
    assert all(q.provenance == "assumed" for q in undated)


def test_games_already_under_way_are_left_off_and_counted(home):
    got = refresh(est("nfl"), KEY, clock=Clock(), fetcher=FakeApi())
    assert {m.event_id for m in got.markets} == {"e-arb", "e-ref"}
    assert got.under_way == 1
    assert any("under way" in n for n in oddsapi.summary(got)["notes"])


def test_the_odds_apis_book_keys_become_the_engines(home):
    got = refresh(est("nfl"), KEY, clock=Clock(), fetcher=FakeApi())
    assert {q.book for m in got.markets for q in m.quotes} == {"dk", "fd", "pinnacle"}
    assert oddsapi.engine_book("williamhill_us") == "caesars"


# ------------------------------------------------------------ the board on real odds

@pytest.fixture
def board_cli(monkeypatch, home):
    """`board --feed oddsapi` end to end: the real CLI, a fake API, a fake
    Keychain, a fixed clock and a private home."""
    api, clock = FakeApi(), Clock()
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: api)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=clock))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: KEY)
    return SimpleNamespace(api=api, clock=clock)


def board_json(capsys, *extra):
    code = cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--json", *extra])
    out = capsys.readouterr()
    assert code == 0, out.err + out.out
    return json.loads(out.out), out


def test_the_board_scans_the_fetched_markets_like_a_snapshot(board_cli, capsys):
    got, _ = board_json(capsys)
    assert got["feed"] == "oddsapi" and got["live"] is True
    assert got["markets_scanned"] == 2
    kinds = {r["kind"] for r in got["rows"]}
    assert "arb" in kinds and "ev" in kinds


def test_an_arb_is_two_books_you_can_bet_at_and_names_the_game(board_cli, capsys):
    got, _ = board_json(capsys)
    arb = next(r for r in got["rows"] if r["kind"] == "arb")
    assert arb["event"] == "Buffalo Bills at Kansas City Chiefs" and arb["event_id"] == "e-arb"
    assert arb["league"] == "NFL" and arb["market"] == "h2h"
    assert {leg["book"] for leg in arb["legs"]} == {"dk", "fd"}
    assert {leg["book_name"] for leg in arb["legs"]} == {"DraftKings", "FanDuel"}
    assert arb["profit"] > 0 and arb["margin"] == pytest.approx(0.0373, abs=1e-4)
    assert all(leg["age"] == 6.0 for leg in arb["legs"]), "aged by the book's last_update"
    assert 0 < arb["p_fill"] < 1, "a six-second-old price is not a certain fill"


def test_a_book_you_cannot_bet_at_prices_the_market_and_is_never_a_leg(board_cli, capsys):
    """The Cowboys game's only arb is DraftKings against Pinnacle, and a US
    bettor cannot place the Pinnacle leg. Pinnacle still sets the fair odds, so
    DraftKings' 2.00 shows as a +EV bet; it never appears as the other side."""
    got, _ = board_json(capsys)
    legs = [leg["book"] for r in got["rows"] for leg in r["legs"]]
    assert "pinnacle" not in legs
    cowboys = [r for r in got["rows"] if r["event_id"] == "e-ref"]
    assert cowboys and all(r["kind"] == "ev" and r["legs"][0]["book"] == "dk" for r in cowboys)
    assert got["odds"]["reference_only"] == ["Pinnacle"]
    assert "DraftKings" in got["odds"]["bet_at"] and "Pinnacle" not in got["odds"]["bet_at"]


def test_the_source_names_the_feed_the_regions_and_the_fetch_time(board_cli, capsys):
    got, _ = board_json(capsys)
    assert got["source"] == ("The Odds API, regions us, eu, h2h, prices fetched "
                             f"{datetime.fromtimestamp(NOW, timezone.utc):%Y-%m-%d %H:%M:%S} UTC")
    assert got["odds"]["fetched_at"] == NOW and got["odds"]["cached"] is False


def test_the_board_json_says_what_it_cost_and_what_is_left(board_cli, capsys):
    got, _ = board_json(capsys)
    cost = got["odds"]["cost"]
    assert cost["estimate"] == 2 and cost["spent"] == 2 and cost["remaining"] == 498 and cost["used"] == 2
    assert "This refresh used 2 credits" in cost["text"] and "498 left this month" in cost["text"]
    assert [x["alias"] for x in got["odds"]["leagues"]] == ["nfl"]


def test_a_second_press_in_the_window_spends_nothing(board_cli, capsys):
    board_json(capsys)
    board_cli.clock.now = NOW + 30
    again, _ = board_json(capsys)
    assert len(board_cli.api.calls) == 1
    assert again["odds"]["cached"] is True and again["odds"]["cost"]["spent"] == 0
    assert "No credits were spent" in again["odds"]["cost"]["text"]
    arb = next(r for r in again["rows"] if r["kind"] == "arb")
    assert all(leg["age"] == 36.0 for leg in arb["legs"]), "the half-minute-old answer is a half minute older"


def test_the_human_board_says_the_cost_before_it_fetches(monkeypatch, home, capsys):
    api, seen = FakeApi(), []

    def spy(path, params):
        seen.append(capsys.readouterr().out)         # what was on screen when the fetch began
        return api(path, params)

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: spy)
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=Clock()))
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: KEY)
    assert cli.main(["board", "--feed", "oddsapi", "--sport", "nfl"]) == 0
    assert "up to 2 of your Odds API credits" in seen[0], "the cost was not on screen before the fetch"
    out = capsys.readouterr().out
    assert "source: The Odds API" in out and "This refresh used 2 credits" in out
    assert "locked if both bets stand" in out and "guarantee" not in out.lower()
    assert "Buffalo Bills at Kansas City Chiefs" in out and "DraftKings" in out
    assert KEY not in out


def test_estimate_fetches_nothing_and_needs_no_key(monkeypatch, home, capsys):
    def no(*a, **k):
        raise AssertionError("--estimate must not fetch or read the Keychain")

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", no)
    monkeypatch.setattr(keystore, "get_key", no)
    assert cli.main(["board", "--feed", "oddsapi", "--estimate", "--sport", "nfl", "--sport", "nhl",
                     "--region", "us", "--region", "eu", "--region", "us2", "--json"]) == 0
    got = json.loads(capsys.readouterr().out)
    assert got["estimate"]["credits"] == 2 * 3 * 1
    assert got["choices"]["regions"][2]["picked"] is True


def test_without_a_key_it_says_how_to_get_one_and_fetches_nothing(monkeypatch, home, capsys):
    def no(*a, **k):
        raise AssertionError("no key, no fetch")

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", no)
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: None)
    assert cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--json"]) == 2
    got = json.loads(capsys.readouterr().out)
    assert got["reason"] == "no_key" and "Get a free key at the-odds-api.com" in got["error"]


def test_out_of_credits_reaches_the_window_in_plain_words(monkeypatch, home, capsys):
    def spent(path, params):
        raise explain(401, json.dumps({"error_code": "OUT_OF_USAGE_CREDITS"}), {"x-requests-remaining": "0"})

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: spent)
    monkeypatch.setattr(keystore, "get_key", lambda runner=None: KEY)
    assert cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--json"]) == 2
    got = json.loads(capsys.readouterr().out)
    assert got["error"] == CREDITS_GONE and got["reason"] == "out_of_credits"


def test_a_bad_choice_is_refused_by_the_parser_before_any_cost_is_worked_out(home, capsys):
    with pytest.raises(SystemExit):
        cli.main(["board", "--feed", "oddsapi", "--sport", "cricket"])


def test_two_sources_of_prices_at_once_is_refused_not_quietly_resolved(monkeypatch, home, capsys, tmp_path):
    def no(*a, **k):
        raise AssertionError("a refused board must not fetch")

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", no)
    monkeypatch.setattr(keystore, "get_key", no)
    snapshot = tmp_path / "s.json"
    snapshot.write_text("{}")
    assert cli.main(["board", "--feed", "oddsapi", "--snapshot", str(snapshot)]) == 2
    assert "Choose one source of prices" in capsys.readouterr().err
    assert cli.main(["board", "--feed", "oddsapi", "--live", "--json"]) == 2
    assert "Choose one source of prices" in json.loads(capsys.readouterr().out)["error"]


def test_the_live_odds_choices_mean_nothing_without_the_feed_and_say_so(monkeypatch, home, capsys):
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: (_ for _ in ()).throw(AssertionError("no")))
    for extra in (["--sport", "nfl"], ["--region", "eu"], ["--market", "totals"], ["--estimate"]):
        assert cli.main(["board", *extra]) == 2, extra
        assert "only work with --feed oddsapi" in capsys.readouterr().err


def test_a_feed_that_is_not_asked_for_touches_no_network(monkeypatch, home, capsys):
    def no(*a, **k):
        raise AssertionError("the demo board must not fetch")

    monkeypatch.setattr(oddsapi, "odds_api_fetcher", no)
    monkeypatch.setattr(keystore, "get_key", no)
    assert cli.main(["board", "--json"]) == 0
    assert json.loads(capsys.readouterr().out)["live"] is False


def test_the_key_is_in_no_output_no_cache_no_crash_report(board_cli, capsys, home):
    """Every way the key could leave: what is printed, what is written, and
    what a failure writes."""
    code = cli.main(["board", "--feed", "oddsapi", "--sport", "nfl", "--json"])
    out = capsys.readouterr()
    assert code == 0 and KEY not in out.out and KEY not in out.err
    code = cli.main(["board", "--feed", "oddsapi", "--sport", "nfl"])
    out = capsys.readouterr()
    assert code == 0 and KEY not in out.out and KEY not in out.err
    for path in home.rglob("*"):
        if path.is_file():
            assert KEY not in path.read_text(errors="ignore"), path


def test_the_key_is_not_in_the_json_even_when_every_part_of_it_is_echoed(board_cli, capsys):
    got, out = board_json(capsys)
    flat = json.dumps(got)
    assert KEY not in flat and KEY[:12] not in flat and "apiKey" not in flat


# ------------------------------------------------------------ spreads and totals

def _line_market(book_key, line, over_price=1.91, under_price=1.91):
    return {"key": book_key, "title": book_key, "last_update": iso(NOW - 6), "markets": [{
        "key": "totals", "last_update": iso(NOW - 6),
        "outcomes": [{"name": "Over", "price": over_price, "point": line},
                     {"name": "Under", "price": under_price, "point": line}]}]}


def test_totals_are_split_one_market_per_line(home):
    payload = [event("e-t", [_line_market("draftkings", 47.5), _line_market("fanduel", 48.5),
                             _line_market("betmgm", 47.5)])]
    got = refresh(est("nfl", markets=["totals"]), KEY, clock=Clock(),
                  fetcher=FakeApi({"americanfootball_nfl": payload}))
    assert len(got.markets) == 1, "the API sends every line in one market"
    split = oddsapi.split_by_line(got.markets)
    assert sorted(len(m.quotes) for m in split) == [2, 4]
    for m in split:
        assert len({abs(q.outcome.line) for q in m.quotes}) == 1


def test_a_half_point_difference_between_lines_is_never_an_arb(home):
    """Over 47.5 at one book and Under 48.5 at another are not opposite sides
    of one bet. Split by line, they never meet."""
    payload = [event("e-t", [_line_market("draftkings", 47.5, over_price=2.30, under_price=1.60),
                             _line_market("fanduel", 48.5, over_price=1.60, under_price=2.30)])]
    got = refresh(est("nfl", markets=["totals"]), KEY, clock=Clock(),
                  fetcher=FakeApi({"americanfootball_nfl": payload}))
    rows = board.scan(oddsapi.split_by_line(got.markets), oddsapi.books_table(), now=got.now,
                      kinds=("arb",), bettable=set(oddsapi.BETTABLE))
    assert rows == []


# ------------------------------------------------------------ the books

def test_only_regulated_us_books_are_bettable_and_offshore_ones_are_not():
    for key in ("dk", "fd", "mgm", "caesars", "betrivers", "fanatics"):
        assert key in oddsapi.BETTABLE
    for key in ("pinnacle", "bovada", "betonlineag", "mybookieag", "betus", "lowvig", "kalshi",
                "polymarket", "betfair", "onexbet"):
        assert key not in oddsapi.BETTABLE, key


def test_the_scan_filter_keeps_a_reference_book_out_of_arbs_middles_and_bets():
    from overlay_engine.models import Market, Outcome, Quote

    # Two reference books that disagree with each other and with DraftKings, so each
    # one's price is +EV against the others' fair odds, and the pair is an arb.
    quotes = [Quote("dk", Outcome("Home"), 2.00, NOW - 5), Quote("dk", Outcome("Away"), 1.85, NOW - 5),
              Quote("pinnacle", Outcome("Home"), 1.80, NOW - 5), Quote("pinnacle", Outcome("Away"), 2.20, NOW - 5),
              Quote("kalshi", Outcome("Home"), 2.40, NOW - 5), Quote("kalshi", Outcome("Away"), 1.65, NOW - 5)]
    market = Market("g", "nfl", "h2h", quotes, NOW + 3600)
    reference = {"pinnacle", "kalshi"}

    # The control: with nothing filtered the reference books ARE legs, as arbs and as +EV bets.
    everyone = board.scan([market], oddsapi.books_table(), now=NOW)
    assert any(r.kind == "arb" and {leg["book"] for leg in r.legs} <= reference for r in everyone)
    assert any(r.kind == "ev" and r.legs[0]["book"] in reference for r in everyone)

    placed = board.scan([market], oddsapi.books_table(), now=NOW, bettable=set(oddsapi.BETTABLE))
    assert all(leg["book"] not in reference for r in placed for leg in r.legs), (
        "a reference book's price became a leg of a bet the person is told to place")
    # (That the filter does not just empty the board is held by
    # test_a_book_you_cannot_bet_at_prices_the_market_and_is_never_a_leg, where DraftKings' own
    # price comes out +EV against Pinnacle's fair odds.)


def test_no_sharp_price_means_the_window_is_told_why_there_are_no_bets(home):
    payload = [event("e1", [book("draftkings", 2.10, 1.80), book("fanduel", 1.80, 2.05)])]
    got = refresh(est("nfl", regions=["us"]), KEY, clock=Clock(),
                  fetcher=FakeApi({"americanfootball_nfl": payload}))
    assert any("Add the Europe region" in n for n in oddsapi.summary(got)["notes"])
