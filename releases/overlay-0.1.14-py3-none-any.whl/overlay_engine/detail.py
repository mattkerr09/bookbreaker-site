"""The detail behind one board row: what the fair price is, what each book would
pay against it, and every book's two-sided prices.

A row on the board is a headline (an edge, a return) and the two or three prices
it rests on. A bettor deciding whether to trust it wants the rest of the market:
what the no-vig price is and how it was made, how much of the edge would be left
at any other book, and the full table of who is quoting what. This is that, built
from the same market the row was found in and by the same functions that found
it, so the detail cannot disagree with its row.

**One fair price, one way.** Each book's EV here is `ev.fair_without` and
`ev.evaluate`, the calls `find_edges` makes for the row itself. A test holds the
row's own EV to its line in this table.

**Reference books are not bets.** Pinnacle and the other books a person cannot
bet at from the US price the market and appear in the price table, marked. The EV
table lists only books a person can place a bet at.

**A middle has no single fair price.** It is two different lines, so the market
holding them has no one price to take the margin out of; the detail says so and
shows the table for the two lines alone. An arb and a +EV bet are priced on one
line, and have the full detail.

The window draws these fields and computes none of them.
"""

from __future__ import annotations

from .ev import evaluate, fair_without
from .fair import fair_value
from .models import Book
from .odds import decimal_to_prob, prob_to_american
from .screen import ago, american, book_name, popular, side_label

#: Said when a middle is selected: there is no single fair price for two lines.
NO_MIDDLE_FAIR = ("A middle bets two different lines, so there is no single fair price for it. Each bet on its "
                  "own has one, and the table shows both lines at every book.")
NO_FAIR = ("No book in this market quotes both sides with a known tier, so there is no price to take the "
           "book's margin out of.")


class FairCache:
    """Fair values worked out once per market, for a board that asks for many rows."""

    def __init__(self):
        self._full: dict = {}
        self._without: dict = {}

    def full(self, market, books) -> dict:
        key = id(market)
        if key not in self._full:
            self._full[key] = fair_value(market, books)
        return self._full[key]

    def without(self, market, books, book_key: str) -> dict:
        key = (id(market), book_key)
        if key not in self._without:
            self._without[key] = fair_without(market, books, book_key)
        return self._without[key]


def _book(books, key: str) -> Book:
    return books.get(key) or Book(key=key, name=key)


def _name(books, names, key: str) -> str:
    if names and names.get(key):
        return names[key]
    b = books.get(key)
    return b.name if b is not None and b.name and b.name != key else book_name(key, {})


def _fair_block(market, books, cache: FairCache, names) -> dict:
    fvs = cache.full(market, books)
    if not fvs:
        return {"available": False, "why": NO_FAIR}
    first = next(iter(fvs.values()))
    total = sum(first.contributors.values()) or 1.0
    used = sorted(first.contributors.items(), key=lambda kv: -kv[1])
    methods = sorted({m for spread in first.spreads.values() for m in spread.by_method})
    sides = []
    for key, fv in fvs.items():
        sides.append({"outcome": key, "label": side_label(key, market.market_type),
                      "prob": fv.prob, "low": fv.low, "high": fv.high,
                      "american": american(fv.fair_decimal)})
    blend = [{"book": b, "name": _name(books, names, b), "tier": _book(books, b).tier.value,
              "share": round(w / total, 3)} for b, w in used]
    lead = blend[0]
    text = (f"Each book's own prices for both sides have its margin taken out {len(methods)} ways "
            f"({', '.join(methods)}) and averaged. The books are then blended, weighted by how sharp each is: "
            f"{lead['name']} counts for {lead['share']:.0%}.")
    if not first.anchored:
        text += (" No sharp book or exchange priced this market, so this is only the retail books' own view "
                 "and is not anchored.")
    return {"available": True, "anchored": first.anchored, "devig": methods, "blend": blend,
            "sides": sides, "text": text}


def _quotes_for(market, key: str) -> dict:
    out = {}
    for q in market.quotes:
        if q.outcome.key == key:
            out[q.book] = q
    return out


def _ev_block(market, books, cache: FairCache, bettable, names, legs: list, now: float) -> list:
    blocks = []
    for leg in legs:
        rows = []
        for book_key, q in _quotes_for(market, leg["outcome"]).items():
            if bettable is not None and book_key not in bettable:
                continue
            fv = cache.without(market, books, book_key).get(leg["outcome"])
            if fv is None:
                continue
            res = evaluate(_book(books, book_key).net_decimal(q.decimal), fv)
            rows.append({"book": book_key, "name": _name(books, names, book_key),
                         "american": american(q.decimal), "decimal": round(q.decimal, 4),
                         "ev": res.ev, "ev_low": res.ev_low, "ev_high": res.ev_high,
                         "fair_prob": fv.prob, "anchored": fv.anchored,
                         "age": round(max(0.0, now - q.seen_at), 1),
                         "mine": book_key == leg["book"]})
        rows.sort(key=lambda r: (-r["ev"], r["name"].lower()))
        top = max((abs(r["ev"]) for r in rows), default=0.0)
        for r in rows:
            # How long this book's bar is next to the longest, for the window to draw.
            r["scale"] = round(abs(r["ev"]) / top, 3) if top else 0.0
        blocks.append({"outcome": leg["outcome"], "label": side_label(leg["outcome"], market.market_type),
                       "rows": rows})
    return blocks


def _table(market, books, columns: list, bettable, names, now: float) -> dict:
    by_book: dict = {}
    for q in market.quotes:
        if q.outcome.key in columns:
            by_book.setdefault(q.book, {})[q.outcome.key] = q
    rows = []
    for book_key, quotes in by_book.items():
        can = bettable is None or book_key in bettable
        prices = []
        for key in columns:
            q = quotes.get(key)
            if q is None:
                prices.append(None)
                continue
            age = round(max(0.0, now - q.seen_at), 1)
            cell = {"american": american(q.decimal), "decimal": round(q.decimal, 4),
                    "age": age, "age_text": f"last confirmed {ago(age)}"}
            if q.limit is not None:
                cell["limit"] = q.limit
            prices.append(cell)
        rows.append({"book": book_key, "name": _name(books, names, book_key), "bettable": can,
                     "prices": prices})
    # Books a person can bet at first, then the reference books; names within each.
    rows.sort(key=lambda r: (not r["bettable"], popular(r["book"]), r["name"].lower()))

    best, average = [], []
    for i, key in enumerate(columns):
        can = [(r, r["prices"][i]) for r in rows if r["bettable"] and r["prices"][i] is not None]
        if not can:
            best.append(None)
            average.append(None)
            continue
        top = max(p["decimal"] for _, p in can)
        best.append({"american": american(top), "decimal": top,
                     "books": [r["name"] for r, p in can if p["decimal"] == top]})
        # Averaged as probabilities, the way fair.py blends: a long shot's big
        # decimal would drag a plain average of prices a long way.
        mean = sum(decimal_to_prob(p["decimal"]) for _, p in can) / len(can)
        average.append({"american": round(prob_to_american(mean)), "books": len(can)})
    for r in rows:
        for i, p in enumerate(r["prices"]):
            if p is not None and r["bettable"] and best[i] is not None and p["decimal"] == best[i]["decimal"]:
                p["best"] = True
    return {"sides": [{"outcome": k, "label": side_label(k, market.market_type)} for k in columns],
            "rows": rows, "best": best, "average": average,
            "average_basis": "the average of the books' chances, shown as a price"}


def row_detail(market, books, legs: list, kind: str, bettable=None, now: float = 0.0,
               cache: FairCache | None = None, names: dict | None = None) -> dict:
    """The detail for one row.

    `legs` is the row's own legs, as {"book", "outcome"}. For an arb or a +EV
    bet the market is the one line they were found in; for a middle it is the
    unsplit market and the table is cut down to the two lines bet.
    """
    cache = cache or FairCache()
    if kind == "middle":
        columns = [leg["outcome"] for leg in legs]
        return {"market": market.market_type,
                "fair": {"available": False, "why": NO_MIDDLE_FAIR},
                "ev_by_book": [],
                "table": _table(market, books, columns, bettable, names, now)}
    return {"market": market.market_type,
            "fair": _fair_block(market, books, cache, names),
            "ev_by_book": _ev_block(market, books, cache, bettable, names, legs, now),
            "table": _table(market, books, market.outcomes(), bettable, names, now)}


__all__ = ["FairCache", "row_detail"]
