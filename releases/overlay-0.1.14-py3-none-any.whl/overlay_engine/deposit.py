"""Which books to fund, in what order, and how much in each.

The competitor feature this answers is OddsJam's Deposit Optimizer. Theirs splits a
bankroll by a rule it does not show, steers toward the books that pay it for a
sign-up, and ignores which accounts you already hold. This one is static and says
why: it takes your state and your bankroll, keeps the books the catalog says are
licensed in that state, and orders them by what their welcome offers are worth
there, using the same priced offers the Promos panel shows.

Four rules, each one a place this could go wrong quietly.

**Only books licensed in the state.** The list starts from `catalog.for_state`. A
book that is not licensed there never appears, whatever its offer is worth: an offer
is never more legal than the book it is at.

**Locked amounts first, then expectations, never ranked against each other.** A
locked amount is what a hedged bonus bet keeps if both bets are accepted and stand.
An expectation is an average over outcomes (a bonus paid only if the first bet wins,
a refund paid only if it loses, a boost) and is not money in hand. Putting a $500
expectation above a $60 locked amount ranks a hope over a certainty, so the two are
separate lists, each ordered within itself, each totalled on its own, and never added
together. The site and the Promos panel keep them apart; so does this.

**A deposit is what the offer needs, not a share of the bankroll.** For a bet-and-get,
the qualifying bet at that book plus the cash a hedge needs at a second book, as the
engine's own steps state them. Walking down the value order, a book that fits in what
is left gets that amount in full. A book that does not is passed over and listed with
what it needs, not funded with a fraction: most welcome offers pay nothing unless the
qualifying bet is met, and a quarter of a deposit that unlocks nothing is the worst way
to spend a bankroll. The plan says plainly when the bankroll runs out and which books
that leaves.

**Books that limit winning accounts are marked.** One plain sentence each, from the
catalog's `limits_winners`, so the person knows which accounts are one-time. This
describes the book, never the person; nothing here touches identity, devices or
location, and nothing here ever will.

Nothing here is a guarantee. A locked amount is kept only if both bets are accepted
and stand, and every figure that rests on a prior says so.
"""

from __future__ import annotations

import datetime as dt
import math

from . import catalog, welcome

#: The condition every locked amount carries, word for word, wherever one is printed.
LOCKED_CONDITION = "if both bets are accepted and stand"

#: Why a figure that looks like a sum is not one.
LOCKED_MEANS = (f"A locked amount is kept only {LOCKED_CONDITION}. An expected amount is an "
                "average over the ways the first bet can go, not money in hand.")

#: An offer that ends within this many days is said to be ending.
ENDING_SOON_DAYS = 14


class DepositError(ValueError):
    """The question could not be answered as asked: a refusal, not a crash."""


# ----------------------------------------------------------------- inputs

def _state(state: str) -> str:
    code = str(state or "").strip().upper()
    if code not in catalog.STATE_NAMES:
        raise DepositError(f"{state!r} is not a state. Use its two letters, like PA.")
    return code


def _bankroll(value) -> float:
    try:
        bank = float(value)
    except (TypeError, ValueError):
        raise DepositError(f"{value!r} is not a number. Type the bankroll like 1000.")
    if not math.isfinite(bank) or bank <= 0:
        raise DepositError("The bankroll has to be more than zero.")
    return bank


def _have(have) -> list[str]:
    """Book keys from a comma list of keys or names. A typo is refused: left to read as
    a book the person does not hold, it would put an offer in the plan that they
    cannot take."""
    names = {v.name.lower(): v.key for v in catalog.VENUES.values()}
    out, bad = [], []
    for item in str(have or "").split(","):
        item = item.strip()
        if not item:
            continue
        key = item.lower() if item.lower() in catalog.VENUES else names.get(item.lower())
        (out if key else bad).append(key or item)
    if bad:
        raise DepositError(f"{', '.join(bad)}: not a book this app knows. Name the books you "
                           "already have by key, like dk, fd, mgm, or by name.")
    return out


def money(amount: float) -> str:
    """$1,234 for a whole amount, $1,234.56 for one with cents."""
    return f"${amount:,.0f}" if abs(amount - round(amount)) < 0.005 else f"${amount:,.2f}"


# ------------------------------------------------------------ what a book says

def limit_sentence(venue: catalog.Venue) -> str:
    """One plain sentence for a book that limits winning accounts; "" for one that does not."""
    if not venue.limits_winners:
        return ""
    return (f"{venue.name} limits winning accounts, so treat this one as one-time: collect the "
            "offer, and do not count on betting there at size afterward.")


# ---------------------------------------------------------- what an offer needs

def cash_needed(row: dict, priced: welcome.Priced, *, bonus_decimal: float, hold: float) -> dict:
    """The cash an offer needs, from the figures the engine's own steps use.

    `here` is cash at this book: the qualifying bet; for a safety net or a boost, the
    cash bet on one token as well (tokens come one at a time, and the engine sizes one
    at a time). `hedge` is cash at a second book: the qualifying bet is a near-even pair
    the engine prices at its hold, so its other side is about the same stake again; each
    bonus bet is then hedged with `Priced.hedge_stake`, one at a time. The larger of the
    two is what has to be there, because the qualifying pair settles before the bonus
    bets are used.

    Counted in full and on its own: the qualifying total of an offer spread over several
    installments is counted as the engine states it, and no cash is assumed to come back
    from a book funded earlier.
    """
    kind = row["offer_type"]
    stake = float(row.get("qualifying_stake") or 0)
    if kind in ("bet_and_get", "bet_and_get_on_win"):
        here = stake
        hedge = max(stake, priced.hedge_stake)
    elif kind == "profit_boost":
        # The engine does not hedge a boost to a floor, so there is no hedge cash.
        here = stake + float(row["max_stake"])
        hedge = 0.0
    elif kind == "safety_net":
        cap = float(row["max_stake"])
        # A refund is a bonus bet, converted as any other is: the hedge for a bonus bet
        # the size of the cap, by the same rounding the Promos panel uses.
        convert, _, _ = welcome.human_hedge(cap, bonus_decimal,
                                            welcome.hedge_decimal(bonus_decimal, hold))
        here = stake + cap
        hedge = max(stake, convert)
    else:  # pragma: no cover - `welcome.load` refuses any other shape
        raise DepositError(f"{priced.book}: offer type {kind!r} is not one this can size")
    total = math.ceil(here + hedge - 1e-9)
    return {"here": float(math.ceil(here - 1e-9)), "hedge": float(math.ceil(hedge - 1e-9)),
            "total": float(total)}


def _breakdown(row: dict, cash: dict) -> str:
    kind = row["offer_type"]
    if kind == "profit_boost":
        return (f"{money(cash['here'])} in cash at this book: the qualifying bet and one "
                "boosted bet at a time.")
    if kind == "safety_net":
        return (f"{money(cash['here'])} in cash at this book (the qualifying bet and one "
                f"token's bet at a time), plus {money(cash['hedge'])} at a second book to "
                "hedge the qualifying bet and convert any refund.")
    return (f"{money(cash['here'])} for the qualifying bet at this book, plus "
            f"{money(cash['hedge'])} at a second book to hedge it and the bonus bets.")


# ------------------------------------------------------------------ the plan

def _value(p: welcome.Priced) -> tuple[str, float]:
    if p.guaranteed > 0:
        return "locked", p.guaranteed
    if p.expected > 0:
        return "expected", p.expected
    return "none", 0.0


def _value_text(kind: str, value: float) -> str:
    if kind == "locked":
        return f"{money(value)} locked {LOCKED_CONDITION}"
    return f"{money(value)} expected on average, not locked"


def _item(p: welcome.Priced, row: dict, venue: catalog.Venue, kind: str, value: float,
          cash: dict, today: dt.date) -> dict:
    days_left = None
    if p.ends:
        days_left = (dt.date.fromisoformat(p.ends) - today).days
    return {
        "book": p.book, "name": p.name, "kind": kind, "value": round(value, 2),
        "value_text": _value_text(kind, value),
        "offer": p.headline, "offer_type": p.offer_type, "installments": p.installments,
        "needs": cash["total"], "qualify_cash": cash["here"], "hedge_cash": cash["hedge"],
        "breakdown": _breakdown(row, cash),
        "limits_winners": venue.limits_winners,
        "limit_note": limit_sentence(venue),
        "ends": p.ends, "days_left": days_left,
        "ends_soon": days_left is not None and 0 <= days_left <= ENDING_SOON_DAYS,
        "source": p.source, "read": p.read,
    }


def _none_item(venue: catalog.Venue, reason: str, source: str = "", read: str = "") -> dict:
    return {"book": venue.key, "name": venue.name, "reason": reason,
            "limits_winners": venue.limits_winners, "limit_note": limit_sentence(venue),
            "source": source, "read": read}


def _no_online(st: str) -> str:
    """Why there is no online book to fund in this state, or "" when there may be one."""
    name = catalog.STATE_NAMES[st]
    summary = catalog.state_summary(st)
    if not summary["legal"]:
        return (f"There is no legal sports betting in {name} as of {catalog.AS_OF}, so there is "
                "no book to fund.")
    if summary["retail_only"]:
        return (f"Betting in {name} is legal in person only ({summary['retail_only']}), so there "
                "is no online book to fund.")
    if not summary["covered"]:
        return f"This app does not cover {name} yet: {summary['gap_reason']}"
    if not catalog.for_state(st):
        return f"The catalog lists no licensed online book in {name} as of {catalog.AS_OF}."
    return ""


def plan(state: str, bankroll: float, *, have: str = "",
         bonus_decimal: float = welcome.PRIOR_BONUS_DECIMAL,
         hold: float = welcome.PRIOR_TWO_BOOK_HOLD, today: dt.date | None = None,
         rows: list[dict] | None = None, none_rows: list[dict] | None = None) -> dict:
    """Which books to fund in `state` with `bankroll`, in order, and how much in each."""
    st = _state(state)
    bank = _bankroll(bankroll)
    mine = _have(have)
    today = today or dt.date.today()
    name = catalog.STATE_NAMES[st]

    out = {
        "command": "deposit", "state": st, "state_name": name, "bankroll": bank,
        "online": True, "message": "", "locked_means": LOCKED_MEANS,
        "assumptions": [], "fund": [], "left": [], "no_offer": [],
        "totals": {"deposit": 0.0, "locked": 0.0, "expected": 0.0},
        "unallocated": bank, "bankroll_ran_out": False,
        "table_read": catalog.AS_OF, "max_age_days": welcome.MAX_AGE_DAYS,
    }

    reason = _no_online(st)
    if reason:
        out["online"] = False
        out["message"] = reason
        return out

    out["assumptions"] = [
        "A deposit is the cash an offer needs: its qualifying bet at that book plus the cash "
        "to hedge it, from the engine's own steps for that offer. The hedge cash is counted "
        "with the offer that needs it, so the deposits add up to what you need in all; it has "
        "to sit at a second book that prices the other side.",
        "An offer spread over several installments is counted for its full qualifying total. "
        "The cash comes back as each bet settles, so you may need less in the account at once.",
        "Each book is counted on its own, as if no cash came back from the one before. Taking "
        "them one at a time as bets settle can need less in total.",
        f"PRIORS: bonus bets placed at decimal {bonus_decimal:.2f}, {hold * 100:.1f}% combined "
        "hold across the best two books. They size the hedges.",
        "A book that does not fit in what is left is passed over, not partly funded: most "
        "welcome offers pay nothing unless the qualifying bet is met.",
        f"The state table was read {catalog.AS_OF}. It is a starting point for your own check, "
        "not legal advice; each book's own page decides whether it will accept you.",
    ]

    rows = welcome.load(today=today) if rows is None else rows
    none_rows = welcome.load_none(today=today) if none_rows is None else none_rows
    priced = welcome.price(rows, bonus_decimal=bonus_decimal, hold=hold)
    row_of = {(r["book"], r["headline"], tuple(sorted(r["_states"]))): r for r in rows}
    offers = welcome.for_you(priced, have=",".join(mine), state=st)

    licensed = {v.key: v for v in catalog.for_state(st)}
    live = [p for p in offers if not p.ineligible and not p.stale and p.book in licensed]
    best = welcome.best_per_book(live, st)

    locked, expected, worthless = [], [], []
    for p in best:
        kind, value = _value(p)
        {"locked": locked, "expected": expected, "none": worthless}[kind].append((p, kind, value))
    locked.sort(key=lambda t: (-t[2], t[0].name.lower()))
    expected.sort(key=lambda t: (-t[2], t[0].name.lower()))

    remaining = bank
    fund, left = [], []
    for p, kind, value in locked + expected:
        row = row_of[(p.book, p.headline, tuple(p.states))]
        cash = cash_needed(row, p, bonus_decimal=bonus_decimal, hold=hold)
        item = _item(p, row, licensed[p.book], kind, value, cash, today)
        if cash["total"] <= remaining + 1e-9:
            remaining -= cash["total"]
            item["deposit"] = cash["total"]
            item["order"] = len(fund) + 1
            fund.append(item)
        else:
            item["short_by"] = round(cash["total"] - remaining, 2)
            item["left_when"] = round(remaining, 2)
            left.append(item)

    # Books licensed here that the plan does not fund or leave: each says why.
    placed = {i["book"] for i in fund + left}
    worthless_keys = {p.book for p, _, _ in worthless}
    none_here = {n["book"]: n for n in welcome.no_offer_in(none_rows, st)}
    stale_of = {}
    for p in offers:
        if p.stale and not p.ineligible and p.book in licensed:
            stale_of.setdefault(p.book, p)
    no_offer = []
    for key, venue in licensed.items():
        if key in placed:
            continue
        if key in mine:
            no_offer.append(_none_item(venue, "You already have an account there, and welcome "
                                              "offers are for new customers."))
        elif key in worthless_keys:
            no_offer.append(_none_item(venue, "Its offer is worth nothing after the cost of "
                                              "qualifying, so it is not worth a deposit for the offer."))
        elif key in stale_of:
            p = stale_of[key]
            why = (f"Its offer ended {p.ends} by its source, so it is not priced until it is read again."
                   if p.ended else
                   f"Its offer was last read {p.age_days} days ago, so it is not priced until it is read again.")
            no_offer.append(_none_item(venue, why, p.source, p.read))
        elif key in none_here:
            n = none_here[key]
            no_offer.append(_none_item(
                venue, "Its own page lists no new-customer sports offer here."
                       + (" That page was read too long ago to rely on." if n["stale"] else ""),
                n["source"], n["read"]))
        else:
            no_offer.append(_none_item(venue, f"No welcome offer is on file for it in {st}."))
    order = {v.key: i for i, v in enumerate(licensed.values())}
    no_offer.sort(key=lambda i: order[i["book"]])

    out["fund"], out["left"], out["no_offer"] = fund, left, no_offer
    out["unallocated"] = round(remaining, 2)
    out["bankroll_ran_out"] = bool(left)
    out["totals"] = {
        "deposit": round(bank - remaining, 2),
        # Two totals, never one: they are different kinds of number.
        "locked": round(sum(i["value"] for i in fund if i["kind"] == "locked"), 2),
        "expected": round(sum(i["value"] for i in fund if i["kind"] == "expected"), 2),
    }
    out["message"] = _message(out, name)
    return out


def _message(out: dict, name: str) -> str:
    bank, fund, left = out["bankroll"], out["fund"], out["left"]
    if not fund and not left:
        return (f"No book licensed in {name} has a priced welcome offer to deposit for right now. "
                "The books that are licensed there are listed below.")
    parts = []
    if fund:
        names = ", ".join(f"{i['name']} {money(i['deposit'])}" for i in fund)
        parts.append(f"With {money(bank)} in {name}, fund {len(fund)} "
                     f"book{'s' if len(fund) != 1 else ''} in this order: {names}.")
        if out["unallocated"] > 0:
            parts.append(f"That uses {money(out['totals']['deposit'])} and leaves "
                         f"{money(out['unallocated'])}.")
    else:
        smallest = min(i["needs"] for i in left)
        parts.append(f"{money(bank)} is less than the smallest amount any offer in {name} needs "
                     f"({money(smallest)}), so there is no book to fund in full yet.")
    if left:
        names = ", ".join(f"{i['name']} (needs {money(i['needs'])})" for i in left)
        parts.append(f"The bankroll runs out before {len(left)} book{'s' if len(left) != 1 else ''}"
                     f" with a priced offer: {names}. Each is passed over, not partly funded.")
    else:
        parts.append(f"The bankroll covers every priced offer in {name}.")
    return " ".join(parts)


# ----------------------------------------------------------------- the words

def _staged(item: dict) -> bool:
    """A bet-and-get paid or qualified over several installments, whose full qualifying
    total is counted. Tokens are sized one at a time and have no such total."""
    return item["installments"] > 1 and item["offer_type"] in ("bet_and_get", "bet_and_get_on_win")


def _group(lines: list[str], title: str, items: list[dict], note: str) -> None:
    if not items:
        return
    lines.append(title)
    lines.append(f"  {note}")
    for i in items:
        lines.append(f"  {i['order']}. {i['name']}: deposit {money(i['deposit'])}")
        lines.append(f"       {i['value_text']}   {i['offer']}")
        lines.append(f"       {i['breakdown']}")
        if _staged(i):
            lines.append(f"       Spread over {i['installments']} installments; the full total is "
                         "counted, and you may need less in the account at once.")
        if i["ends_soon"]:
            lines.append(f"       Ends {i['ends']} ({i['days_left']} days), by its source.")
        if i["limit_note"]:
            lines.append(f"       {i['limit_note']}")
        lines.append(f"       source: {i['source']}  (read {i['read']})")
    lines.append("")


def describe(out: dict) -> str:
    """The plan as the CLI prints it. Every figure is read from `out`, the same dict
    `--json` prints, so the two mouths cannot disagree."""
    lines = [f"Deposit plan for {out['state_name']} ({out['state']}), bankroll "
             f"{money(out['bankroll'])}.", "", out["message"], ""]
    if not out["online"]:
        return "\n".join(lines).rstrip()

    fund = out["fund"]
    _group(lines, "Locked offers, first:", [i for i in fund if i["kind"] == "locked"],
           f"Locked means kept {LOCKED_CONDITION}.")
    _group(lines, "Expected offers, after, ranked among themselves only:",
           [i for i in fund if i["kind"] == "expected"],
           "Expected is an average over how the first bet goes. It is not money in hand and is "
           "never added to a locked amount.")
    if fund:
        t = out["totals"]
        lines.append(f"Deposits: {money(t['deposit'])} of {money(out['bankroll'])}. "
                     f"Locked across the locked offers: {money(t['locked'])}, {LOCKED_CONDITION}. "
                     f"Expected across the expected offers: {money(t['expected'])}, on average.")
        lines.append("")
    if out["left"]:
        lines.append("Left, in value order. The bankroll ran out before these:")
        for i in out["left"]:
            lines.append(f"  {i['name']}: needs {money(i['needs'])}, {money(i['short_by'])} more "
                         f"than was left; {i['value_text']}.")
            if _staged(i):
                lines.append(f"       Spread over {i['installments']} installments. The full total is "
                             "counted, and you may need less in the account at once.")
            if i["limits_winners"]:
                lines.append("       Limits winning accounts: a one-time account.")
        lines.append("")
    if out["no_offer"]:
        lines.append("Also licensed here, with no deposit suggested:")
        for i in out["no_offer"]:
            lines.append(f"  {i['name']}: {i['reason']}"
                         + ("  (Limits winning accounts: a one-time account.)" if i["limits_winners"] else ""))
        lines.append("")
    lines.append("How this was worked out:")
    lines.extend(f"  - {a}" for a in out["assumptions"])
    lines.append(f"Offers change monthly (rows older than {out['max_age_days']} days are not priced). "
                 f"`overlay welcome --state {out['state']}` has the steps for each.")
    return "\n".join(lines)
