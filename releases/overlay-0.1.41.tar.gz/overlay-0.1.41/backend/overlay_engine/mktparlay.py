"""A fair price for a parlay across games, from Kalshi's game-winner prices. No key, no account.

Pick a winner in two or more different games. Each game's two Kalshi asking prices are turned into a chance with the
spread between them removed (each price over their sum), the chances are multiplied, and the result is the parlay's
fair price: what it would pay if nobody took a margin. Put a sportsbook's parlay price beside it to see what that
book's parlay costs you.

This is a fair-price check built from prediction-market prices. It is not a sportsbook parlay, Kalshi does not sell
this parlay here, and Bookbreaker places nothing. Whether Kalshi's sports contracts are open to you depends on your
state, and the state rule is shown with every answer (CEO, 2026-10-20: never present it as a sportsbook parlay).

Everything the window shows is worded here; the window does no arithmetic.
"""
from __future__ import annotations

import time

from . import xvenue
from .odds import OddsError, decimal_to_american, parse_odds

CAVEATS = (
    "Built from Kalshi's prices, a prediction market, not a sportsbook. Kalshi does not sell this parlay here, and "
    "Bookbreaker places nothing.",
    "Each leg's chance is its Kalshi price with the spread between the two sides removed (each price over their sum).",
    "Legs are in different games, so their chances are multiplied: close to independent, not exactly.",
    "Prices move. Each leg says when it was read.",
)


def games(fetch=None, leagues=xvenue.LEAGUES, clock=time.time) -> list:
    """Every open Kalshi game in these leagues, both sides priced."""
    fetch = fetch or _fetcher()
    out = []
    for lg in leagues:
        try:
            payload, read_at = xvenue.kalshi_events(fetch, xvenue.KALSHI_SERIES[lg], clock=clock)
        except Exception:
            continue
        for g in xvenue.kalshi_games(payload, lg, read_at=read_at or clock()):
            if len(g.teams) == 2 and all(g.ask.get(t) for t in g.teams):
                out.append(g)
    out.sort(key=lambda g: (g.date, g.league, g.ref))
    return out


def _fetcher():
    from . import pubfeed
    return pubfeed.urllib_fetcher


def _amer(decimal: float) -> str:
    return f"{round(decimal_to_american(decimal)):+d}"


def _cents(x: float) -> str:
    return f"{x * 100:.0f}c"


def listing(found: list) -> list:
    """The pick list: one row per game, each side's price and its spread-free chance."""
    rows = []
    for g in found:
        a, b = g.teams
        total = g.ask[a] + g.ask[b]
        rows.append({
            "ref": g.ref, "league": g.league, "date": g.date.isoformat(),
            "sides": [{"team": t, "name": xvenue.team_name(g.league, t), "ask": g.ask[t],
                       "ask_text": _cents(g.ask[t]), "chance": g.ask[t] / total,
                       "chance_text": f"{g.ask[t] / total * 100:.1f}%", "pick": f"{g.ref}:{t}"} for t in (a, b)],
            "spread_text": f"{(total - 1) * 100:.1f} cents between the two sides",
        })
    return rows


def price(found: list, picks: list[str], book_odds: str | None = None, state: str | None = None,
          now: float | None = None) -> dict:
    """`picks` are "REF:TEAM" strings from `listing`. Raises OddsError with a plain sentence on bad input."""
    by_ref = {g.ref: g for g in found}
    legs, seen = [], set()
    for pk in picks:
        ref, _, team = str(pk).partition(":")
        g = by_ref.get(ref)
        if g is None:
            raise OddsError(f"{ref} is not an open Kalshi game right now. List the games and pick again.")
        if team not in g.teams:
            raise OddsError(f"{team} is not playing in {ref}.")
        if ref in seen:
            raise OddsError("Two picks in one game. This check is for legs in different games, where multiplying "
                            "the chances is fair; a same-game parlay's legs move together.")
        seen.add(ref)
        other = g.teams[1] if team == g.teams[0] else g.teams[0]
        chance = g.ask[team] / (g.ask[team] + g.ask[other])
        legs.append({"ref": ref, "league": g.league, "date": g.date.isoformat(), "team": team,
                     "name": xvenue.team_name(g.league, team), "opponent": xvenue.team_name(g.league, other),
                     "ask": g.ask[team], "ask_text": _cents(g.ask[team]), "chance": chance,
                     "chance_text": f"{chance * 100:.1f}%", "fair_text": _amer(1 / chance),
                     "read_at": g.read_at,
                     "age_text": _age((now or time.time()) - g.read_at) if g.read_at else "time of read unknown"})
    if len(legs) < 2:
        raise OddsError("Pick a winner in at least two different games.")
    joint = 1.0
    for leg in legs:
        joint *= leg["chance"]
    fair_dec = 1 / joint
    out = {
        "legs": legs, "chance": joint, "chance_text": f"{joint * 100:.2f}%",
        "fair_decimal": round(fair_dec, 3), "fair_text": _amer(fair_dec),
        "headline": (f"{len(legs)} legs: fair price {_amer(fair_dec)} "
                     f"({joint * 100:.2f}% to hit), from Kalshi's prices"),
        "caveats": list(CAVEATS),
    }
    if book_odds:
        try:
            book_dec = parse_odds(str(book_odds).strip())
        except (ValueError, OddsError):
            raise OddsError(f"“{book_odds}” is not a price I can read. Type American odds, like +359.") from None
        ev = book_dec * joint - 1
        out["book"] = {"text": _amer(book_dec), "decimal": round(book_dec, 3), "ev": ev,
                       "say": (f"The book's {_amer(book_dec)} against a fair "
                               f"{_amer(fair_dec)}: on average {ev * 100:+.1f}% of the stake, "
                               "if Kalshi's prices are right." + ("" if ev < 0 else
                               " A price above fair is uncommon; check the legs match exactly."))}
    gate = xvenue.state_gate(state)
    kalshi = next((u for u in gate.unavailable if u["venue"] == "kalshi"), None)
    if not gate.state:
        message = "Pick your state: Kalshi's sports contracts are not open everywhere."
    elif kalshi:
        src = "; ".join(f"{s['name']}, {s['date']}" for s in kalshi["sources"])
        message = (f"Kalshi's sports contracts are not open in {kalshi['state_name']} ({src}), so there these prices "
                   "are a reference for judging a sportsbook's parlay, nothing you can buy.")
    else:
        message = " ".join(gate.notes)
    out["state"] = {"code": gate.state, "kalshi_open": bool(gate.state) and not kalshi, "message": message}
    return out


def _age(seconds: float) -> str:
    s = max(0, int(seconds))
    if s < 90:
        return f"read {s} seconds ago"
    if s < 5400:
        return f"read {s // 60} minutes ago"
    return f"read {s // 3600} hours ago"
