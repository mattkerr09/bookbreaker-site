#!/usr/bin/env python3
"""Refuse a bundle whose code needs a newer macOS than the app tells macOS it needs.

    python3 scripts/check_min_macos.py ui/src-tauri/target/release/bundle/macos/Bookbreaker.app

0.1.39 shipped saying LSMinimumSystemVersion 10.15 while 69 of its 106 Mach-O files (the bundled Python framework,
numpy) were built for macOS 14.0 (the CEO's audit, 2026-10-25). macOS 11 to 13 would open the app and the engine would
fail when Python loads. Now every Mach-O's minimum (vtool -show-build: minos) must be at or below the Info.plist's
LSMinimumSystemVersion, or the build stops, naming the worst file.
"""
from __future__ import annotations
import plistlib, subprocess, sys
from pathlib import Path


def version(text: str) -> tuple:
    return tuple(int(p) for p in text.strip().split("."))


def minos(vtool_output: str) -> str | None:
    """The highest `minos` in vtool -show-build output (a universal file lists one per slice)."""
    found = [line.split()[1] for line in vtool_output.splitlines() if line.strip().startswith("minos")]
    return max(found, key=version) if found else None


def is_macho(path: Path) -> bool:
    try:
        with path.open("rb") as f:
            magic = f.read(4)
    except OSError:
        return False
    return magic in (b"\xcf\xfa\xed\xfe", b"\xce\xfa\xed\xfe", b"\xca\xfe\xba\xbe", b"\xfe\xed\xfa\xcf")


def check(app: Path) -> int:
    floor = plistlib.loads((app / "Contents" / "Info.plist").read_bytes()).get("LSMinimumSystemVersion")
    if not floor:
        print(f"{app}: no LSMinimumSystemVersion in Info.plist", file=sys.stderr)
        return 1
    over, n = [], 0
    for f in sorted(p for p in app.rglob("*") if p.is_file() and not p.is_symlink() and is_macho(p)):
        n += 1
        out = subprocess.run(["vtool", "-show-build", str(f)], capture_output=True, text=True).stdout
        m = minos(out)
        if m and version(m) > version(floor):
            over.append((version(m), m, f))
    if over:
        over.sort(reverse=True)
        print(f"{len(over)} of {n} Mach-O files need a newer macOS than LSMinimumSystemVersion {floor}; worst "
              f"{over[0][1]}: {over[0][2].relative_to(app)}. Raise minimumSystemVersion in tauri.conf.json, or "
              "rebuild those files for the older floor.", file=sys.stderr)
        return 1
    print(f"  {n} Mach-O files, none needs more than macOS {floor}")
    return 0


if __name__ == "__main__":
    sys.exit(check(Path(sys.argv[1])))
