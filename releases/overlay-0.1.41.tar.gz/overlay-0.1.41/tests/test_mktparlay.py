"""A cross-game parlay's fair price from Kalshi game-winner prices (overlay_engine/mktparlay.py): the arithmetic, the
refusals, and that it never reads as a sportsbook parlay or hides the state rule."""
import datetime as dt

import pytest

from overlay_engine import mktparlay
from overlay_engine.odds import OddsError
from overlay_engine.xvenue import Game

D = dt.date(2026, 10, 26)
GAMES = [
    Game("kalshi", ("ATL", "HOU"), D, {"ATL": 0.35, "HOU": 0.66}, "KXNBAGAME-26OCT26ATLHOU", "nba", read_at=1000.0),
    Game("kalshi", ("BOS", "CHI"), D, {"BOS": 0.87, "CHI": 0.15}, "KXNBAGAME-26OCT26CHIBOS", "nba", read_at=1000.0),
]
PICKS = ["KXNBAGAME-26OCT26ATLHOU:ATL", "KXNBAGAME-26OCT26CHIBOS:CHI"]


def test_each_chance_is_its_price_over_the_two_sides_and_the_parlay_multiplies_them():
    r = mktparlay.price(GAMES, PICKS, now=1060.0)
    a, b = 0.35 / 1.01, 0.15 / 1.02
    assert r["chance"] == pytest.approx(a * b)
    assert r["fair_decimal"] == pytest.approx(1 / (a * b), abs=0.001)
    assert r["fair_text"].startswith("+")
    assert r["legs"][0]["age_text"] == "read 60 seconds ago"


def test_a_book_price_is_judged_against_fair():
    r = mktparlay.price(GAMES, PICKS, book_odds="+600")
    assert r["book"]["ev"] == pytest.approx(7.0 * r["chance"] - 1)
    assert "if Kalshi's prices are right" in r["book"]["say"]


def test_it_never_reads_as_a_sportsbook_parlay():
    r = mktparlay.price(GAMES, PICKS)
    text = " ".join(r["caveats"]) + r["headline"]
    assert "not a sportsbook" in text and "places nothing" in text and "from Kalshi's prices" in r["headline"]


def test_the_state_rule_is_always_there():
    assert "Pick your state" in mktparlay.price(GAMES, PICKS)["state"]["message"]
    mi = mktparlay.price(GAMES, PICKS, state="MI")["state"]
    assert mi["kalshi_open"] is False and "not open in Michigan" in mi["message"] and "nothing you can buy" in mi["message"]


@pytest.mark.parametrize("picks, says", [
    (["KXNBAGAME-26OCT26ATLHOU:ATL", "KXNBAGAME-26OCT26ATLHOU:HOU"], "Two picks in one game"),
    (["KXNBAGAME-26OCT26ATLHOU:ATL"], "at least two"),
    (["KXNBAGAME-26OCT26ATLHOU:LAL", "KXNBAGAME-26OCT26CHIBOS:CHI"], "not playing"),
    (["NOPE:ATL", "KXNBAGAME-26OCT26CHIBOS:CHI"], "not an open Kalshi game"),
])
def test_bad_picks_are_refused_in_plain_words(picks, says):
    with pytest.raises(OddsError, match=says):
        mktparlay.price(GAMES, picks)


def test_the_listing_offers_both_sides_of_every_game():
    rows = mktparlay.listing(GAMES)
    assert [s["pick"] for s in rows[0]["sides"]] == ["KXNBAGAME-26OCT26ATLHOU:ATL", "KXNBAGAME-26OCT26ATLHOU:HOU"]
    assert sum(s["chance"] for s in rows[0]["sides"]) == pytest.approx(1.0)


def test_the_window_may_run_kparlay_and_the_build_asks_the_built_engine_offline():
    from pathlib import Path
    import re
    root = Path(__file__).resolve().parents[1]
    rust = (root / "ui" / "src-tauri" / "src" / "main.rs").read_text()
    verbs = re.findall(r'"([a-z-]+)"', re.search(r'const ALLOWED: \[&str; \d+\] = \[([^\]]+)\]', rust).group(1))
    assert "kparlay" in verbs
    build = (root / "scripts" / "build_app.sh").read_text()
    assert re.search(r"^\s+kparlay\)\s+probe=\(kparlay --list --league none\)", build, re.M)
