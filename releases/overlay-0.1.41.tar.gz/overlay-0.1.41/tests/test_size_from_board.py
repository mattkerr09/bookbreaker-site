"""Size this bet: Bet size filled from a +EV leg on the board (ODDSJAM_BAR #15, "calculators prefilled from the row").

Static, like the other window tests. What these pin:
  * only a +EV leg with a fair price gets the button; an arb's legs are staked by the arb itself;
  * the win chance used is the LOW end of the leg's fair band, never the midpoint or the high end;
  * the price and the band are the engine's (the tracking block), copied, not worked out;
  * the form says where the numbers came from and asks for the person's own bankroll, then runs.
"""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JS = (ROOT / "ui" / "src" / "app.js").read_text()
HTML = (ROOT / "ui" / "src" / "index.html").read_text()


def _fn(name):
    start = JS.index(f"function {name}(")
    return JS[start:JS.index("\n}\n", start)]


def test_only_a_plus_ev_leg_with_a_fair_price_gets_the_button():
    body = _fn("sizeButton")
    assert 'p.kind !== "ev" || !l.track || !l.track.fair' in body
    assert "${sizeButton(p, i)}" in JS


def test_the_bet_is_sized_from_the_low_end_of_the_fair_band():
    body = _fn("openSize")
    assert 'document.getElementById("k-prob").value = String(t.fair.low);' in body
    assert "t.fair.prob" not in body and 'k-prob").value = String(t.fair.high' not in body
    assert 'document.getElementById("k-odds").value = plainPrice(t.american);' in body


def test_the_form_says_where_the_numbers_came_from_and_runs():
    body = _fn("openSize")
    assert "the low end of its fair chance" in body and "Put in your own bankroll." in body
    assert 'show("kelly");' in body and 'run("kelly");' in body
    assert 'id="k-from" hidden' in HTML


def test_the_window_works_nothing_out():
    body = _fn("openSize") + _fn("sizeButton")
    assert not re.search(r"\* ?\d|toFixed|Math\.|parseFloat|Number\(", body)
