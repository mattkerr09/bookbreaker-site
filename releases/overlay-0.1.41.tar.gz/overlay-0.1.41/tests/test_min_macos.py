"""The macOS floor the app declares covers the code it bundles (scripts/check_min_macos.py runs on every build)."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import check_min_macos as cmm  # noqa: E402


def test_the_declared_floor_covers_the_bundled_python():
    # The bundled Python framework and numpy are built for macOS 14.0; 0.1.39 declared 10.15.
    conf = json.loads((ROOT / "ui" / "src-tauri" / "tauri.conf.json").read_text())
    assert cmm.version(conf["bundle"]["macOS"]["minimumSystemVersion"]) >= (14, 0)


def test_minos_reads_the_highest_slice():
    out = "Load command 9\n      cmd LC_BUILD_VERSION\n platform MACOS\n    minos 11.0\n      sdk 14.0\n" \
          "Load command 9\n      cmd LC_BUILD_VERSION\n platform MACOS\n    minos 14.0\n      sdk 14.4\n"
    assert cmm.minos(out) == "14.0"
    assert cmm.minos("no build version here") is None


def test_versions_compare_as_numbers_not_text():
    assert cmm.version("14.0") > cmm.version("10.15")
    assert cmm.version("10.15") > cmm.version("10.9")
