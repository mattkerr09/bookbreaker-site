import datetime as dt


def test_a_court_ordered_block_removes_a_nationwide_venue_from_that_state():
    """Kalshi and Polymarket US are nationwide except where a court or regulator has
    blocked their sports contracts; a user in Michigan must not be shown either as a
    venue."""
    from overlay_engine.catalog import EXCLUSION_SOURCES, VENUES, for_state
    for key in ("kalshi", "polymarket_us"):
        venue = VENUES[key]
        for st in ("MA", "MI", "NV", "WA"):
            assert not venue.available_in(st), (key, st)
            assert key not in {v.key for v in for_state(st)}, (key, st)
        for st in ("NY", "oh", "NJ", "AZ", "PA", "IL", "MD"):
            assert venue.available_in(st), (key, st)
    for key, v in VENUES.items():
        if v.excluded:
            assert key in EXCLUSION_SOURCES, f"{key} excludes states with no source"
            assert v.nationwide, f"{key} has exclusions but is not nationwide"


def test_polymarket_us_replaces_the_unverified_international_polymarket():
    """US persons may not trade the international Polymarket, so the catalog has one
    Polymarket and it is the exchange they can: nationwide, verified, with a state list."""
    from overlay_engine.catalog import VENUES, for_state
    from overlay_engine.models import BookTier
    assert "polymarket" not in VENUES
    pm = VENUES["polymarket_us"]
    assert pm.name == "Polymarket US" and pm.tier is BookTier.EXCHANGE
    assert pm.nationwide and pm.verified and not pm.jurisdiction_unknown and not pm.limits_winners
    assert pm.excluded == frozenset({"MA", "MI", "NV", "WA"})
    assert "polymarket_us" in {v.key for v in for_state("NJ")} and "polymarket_us" in {v.key for v in for_state("PA")}
    assert "polymarket_us" not in {v.key for v in for_state("NV")}


def test_every_state_row_rests_on_a_dated_source_and_the_excluded_set_is_the_restricted_rows():
    """One table decides which states a venue is hidden in and which carry a note. A row
    with no source, a source with no date, or an `excluded` set that is not exactly the
    restricted rows is a table that says something nobody can check."""
    from overlay_engine.catalog import (EXCLUSION_SOURCES, STATE_NAMES, STATE_STATUS, VENUES,
                                        restricted_states, state_status)
    assert set(STATE_STATUS) == {"kalshi", "polymarket_us"} == {k for k, v in VENUES.items() if v.excluded}
    for key, rows in STATE_STATUS.items():
        names = {s.name for s in EXCLUSION_SOURCES[key]}
        for st, row in rows.items():
            assert st in STATE_NAMES, (key, st)
            assert row.kind in ("restricted", "contested"), (key, st)
            assert row.sources and set(row.sources) <= names, (key, st)
            found = state_status(key, st.lower())
            assert found and [s.name for s in found[1]] == list(row.sources)
        assert VENUES[key].excluded == restricted_states(key) == {s for s, r in rows.items() if r.kind == "restricted"}
        for src in EXCLUSION_SOURCES[key]:
            published, read = dt.date.fromisoformat(src.published), dt.date.fromisoformat(src.read)
            assert published <= read, (key, src)
            assert src.url.startswith("https://") and src.name
    assert state_status("kalshi", "PA") is None and state_status("polymarket_us", "NJ") is None


def test_the_dated_sources_are_the_ones_the_rows_were_read_from():
    from overlay_engine.catalog import EXCLUSION_SOURCES, STATE_STATUS
    by_name = {s.name: s for s in EXCLUSION_SOURCES["polymarket_us"]}
    assert by_name["Fox Sports"].published == "2026-10-05"
    assert by_name["Fox Sports"].url == "https://www.foxsports.com/stories/betting/prediction-markets-legal-states"
    assert by_name["CBS Sports"].published == "2026-10-08"
    assert by_name["CBS Sports"].url == "https://www.cbssports.com/prediction/news/polymarket-promo-code/"
    # CBS names Nevada only; Fox's table has Nevada and the three other restricted states.
    assert STATE_STATUS["polymarket_us"]["NV"].sources == ("Fox Sports", "CBS Sports")
    assert STATE_STATUS["polymarket_us"]["MI"].sources == ("Fox Sports",)
    assert EXCLUSION_SOURCES["kalshi"][0].read == "2026-10-07", "Kalshi's rows were first read on the 7th"


def test_fox_sports_contested_states_are_shown_not_hidden_and_new_jersey_is_open():
    """Fox's table marks MA, MI, NV and WA Restricted, a list of states Contested (the platforms
    operate while a case runs) and New Jersey Available. Its separate bullet for OG, a different
    exchange, which lists NJ among restricted states, is not about Polymarket US."""
    from overlay_engine.catalog import STATE_STATUS, VENUES
    for key in ("kalshi", "polymarket_us"):
        rows = STATE_STATUS[key]
        assert {s for s, r in rows.items() if r.kind == "contested"} >= {"AZ", "IL", "MD", "NY", "OH"}
        assert "NJ" not in rows and "PA" not in rows
        for st, r in rows.items():
            if r.kind == "contested":
                assert VENUES[key].available_in(st), (key, st)
