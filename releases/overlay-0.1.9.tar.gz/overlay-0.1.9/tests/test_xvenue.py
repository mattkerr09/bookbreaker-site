"""Live arbitrage between Kalshi and Polymarket US, without a socket.

Every failure here is a row that loses money: a mismatched game, a price that
cannot be bought, the wrong side of Polymarket US's one instrument priced, a fee
left out or rounded the wrong way, a size nobody offered, a stale date pairing
last week's game with this week's, or a pair shown to someone in a state where it
cannot be placed. The payloads are recorded from the two venues on 2026-10-09
(tests/fixtures/live/recorded.json: a few games of each league; Kalshi's markets
keep the fields the engine reads; Polymarket US's markets drop prose and team art
and its order books keep their top eight levels; plus the BBO of two games, which
is the venue's own statement of what each team costs to buy). Nothing here touches
the network: a fetcher that answers from the recording stands where the real one
would, and refuses what it was not taught, so a request nobody expected fails a
test instead of passing quietly.

The recording holds no arbitrage, because on that day there was none. Where a
test needs one, it moves a price in the recording and says which.
"""

import copy
import datetime as dt
import json
import re
from decimal import Decimal
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pytest

from overlay_engine import catalog, xvenue

FIXTURE = json.loads((Path(__file__).parent / "fixtures" / "live" / "recorded.json").read_text())
NOW = FIXTURE["recorded_epoch"]            # 2026-10-09, when the recording was made
STATE = "PA"                               # open on both venues, and not contested on either

PHI_JAC = "KXNFLGAME-26OCT11PHIJAC"        # Kalshi writes JAC; the table says JAX; Polymarket US writes jax
HOU_TEN = "KXNFLGAME-26OCT11HOUTEN"
HOU_TEN_PM = "aec-nfl-hou-ten-2026-10-11"  # its one instrument pays on the Texans
PHI_JAX_PM = "aec-nfl-phi-jax-2026-10-11"  # its one instrument pays on the Eagles
BUF_LAR = "KXNFLGAME-26OCT12BUFLAR"        # Monday night: 00:15 UTC on the 13th, the 12th in Eastern time
MEM_CHI = "KXNBAGAME-26OCT09MEMCHI"
LAD_MIL_11 = "KXMLBGAME-26OCT112000LADMIL"
LAD_MIL_12 = "KXMLBGAME-26OCT122000LADMIL"


def amount(value):
    return {"value": f"{value}", "currency": "USD"}


class Venues:
    """Kalshi, and Polymarket US's sports list, market list and order books,
    answering from the recording."""

    def __init__(self):
        self.f = copy.deepcopy(FIXTURE)
        self.requests = []
        self.fail = {}                      # a substring of a URL -> the exception to raise for it
        self.tags = {s["tags"]: s["sport"] for s in self.f["polymarket_us_sports"]["sports"]}
        self.series = {xvenue.KALSHI_SERIES[lg]: lg for lg in xvenue.LEAGUES}

    def __call__(self, url):
        self.requests.append(url)
        for part, exc in self.fail.items():
            if part in url:
                raise exc
        parsed = urlparse(url)
        query = parse_qs(parsed.query)
        if parsed.netloc == "api.elections.kalshi.com" and parsed.path.endswith("/events"):
            return self.f["kalshi_events"][self.series[query["series_ticker"][0]]]
        if parsed.netloc == "api.elections.kalshi.com" and "/series/" in parsed.path:
            return self.f["kalshi_series"][self.series[parsed.path.rsplit("/", 1)[-1]]]
        if parsed.netloc == "gateway.polymarket.us" and parsed.path == "/v1/sports":
            return self.f["polymarket_us_sports"]
        if parsed.netloc == "gateway.polymarket.us" and parsed.path == "/v1/markets":
            league = self.tags[query["tagIds"][0]]
            return self.f["polymarket_us_markets"][league] if query["offset"] == ["0"] else {"markets": []}
        if parsed.netloc == "gateway.polymarket.us" and re.fullmatch(r"/v1/markets/[^/]+/book", parsed.path):
            return self.f["polymarket_us_books"][parsed.path.split("/")[-2]]     # a KeyError is an unreadable book
        raise AssertionError(f"a request nobody expected: {url}")

    # -- moving a price in the recording ------------------------------------------------
    def kalshi(self, league, ticker, team, ask=None, size=None):
        for ev in self.f["kalshi_events"][league]["events"]:
            if ev["event_ticker"] == ticker:
                for mk in ev["markets"]:
                    if mk["ticker"].endswith("-" + team):
                        if ask is not None:
                            mk["yes_ask_dollars"] = f"{ask:.4f}"
                        if size is not None:
                            mk["yes_ask_size_fp"] = f"{size:.2f}"
                        return mk
        raise KeyError((ticker, team))

    def market(self, league, slug):
        return next(m for m in self.f["polymarket_us_markets"][league]["markets"] if m["slug"] == slug)

    def quote(self, league, slug, ask, bid):
        """Move the market list's best ask and bid, and the quotes of its two sides with them."""
        mk = self.market(league, slug)
        mk["bestAskQuote"], mk["bestBidQuote"] = amount(ask), amount(bid)
        for side in mk["marketSides"]:
            side["quote"] = amount(ask if side["long"] else round(1 - bid, 6))
        return mk

    def book(self, slug, offers=None, bids=None):
        """Replace the sides of one market's book: [(price, quantity)], best first."""
        data = self.f["polymarket_us_books"][slug]["marketData"]
        if offers is not None:
            data["offers"] = [{"px": amount(p), "qty": f"{n}"} for p, n in offers]
        if bids is not None:
            data["bids"] = [{"px": amount(p), "qty": f"{n}"} for p, n in bids]
        return data


def arb_world(kalshi_size=500):
    """Kalshi's Titans at 15c. Polymarket US sells the Texans, its instrument, at 77c: 92c a dollar."""
    v = Venues()
    v.kalshi("nfl", HOU_TEN, "TEN", ask=0.15, size=kalshi_size)
    return v


def short_world(kalshi_size=500):
    """Kalshi's Texans at 70c. Polymarket US's Titans are bought by selling its instrument into a
    76.75c bid, which costs 23.25c: 93.25c a dollar."""
    v = Venues()
    v.kalshi("nfl", HOU_TEN, "HOU", ask=0.70, size=kalshi_size)
    return v


def scan(v, **kw):
    kw.setdefault("state", STATE)
    return xvenue.scan(v, clock=lambda: NOW, **kw)


def games(v, league):
    k = xvenue.kalshi_games(v.f["kalshi_events"][league], league)
    p = xvenue.pmus_games(v.f["polymarket_us_markets"][league], league)
    return k, p


def pm_game(v, league, slug):
    return next(g for g in xvenue.pmus_games(v.f["polymarket_us_markets"][league], league) if g.ref == slug)


def is_read(v, league, slug):
    return slug in {g.ref for g in xvenue.pmus_games(v.f["polymarket_us_markets"][league], league)}


# --- fees, against the venues' own tables -----------------------------------

def test_polymarket_us_fee_matches_its_published_table_and_examples():
    """docs.polymarket.us/fees, the 100-lot table and the 1,000-lot examples. Four of the
    examples are exact halves of a cent (6.255, 14.595, 17.375 and the like) and the
    published figures are the round-half-to-even ones."""
    table = {0.01: 0.07, 0.05: 0.33, 0.10: 0.63, 0.18: 1.03, 0.24: 1.27, 0.30: 1.46, 0.50: 1.74, 0.65: 1.58,
             0.77: 1.23, 0.90: 0.63, 0.99: 0.07}
    for price, fee in table.items():
        assert xvenue.pmus_fee(100, price) == pytest.approx(fee), price
    assert xvenue.pmus_fee(1000, 0.10) == 6.26      # 6.255
    assert xvenue.pmus_fee(1000, 0.65) == 15.81     # 15.81125
    assert xvenue.pmus_fee(1000, 0.30) == 14.60     # 14.595
    assert xvenue.pmus_fee(1000, 0.50) == 17.38     # 17.375


def test_the_fee_rounds_half_to_even_exactly_not_the_way_a_float_does():
    """280 contracts at 50c is exactly $4.865: banker's rounding gives $4.86. A float
    rounds it up to $4.87, and charging a cent more than the venue is how a real arb is
    hidden. 120 at 50c is exactly $2.085, which is $2.08; 440 at 50c is $7.645, $7.64."""
    assert xvenue.pmus_fee(280, 0.50) == 4.86
    assert xvenue.pmus_fee(440, 0.50) == 7.64
    assert xvenue.pmus_fee(120, 0.50) == 2.08
    assert round(0.0695 * 280 * 0.5 * 0.5, 2) == 4.87, "the float this replaced"
    # And where the half is odd the even neighbour is the one above: 6.255 is $6.26.
    assert xvenue.pmus_fee(1000, 0.10) == 6.26
    # A fraction of a cent that is not a half rounds the ordinary way.
    assert xvenue.pmus_fee(7, 0.33) == 0.11


def test_the_fee_is_the_same_for_a_price_and_its_complement():
    """Selling the instrument at a bid is buying the other team at 1 - the bid; the
    venue charges p x (1 - p), so either price gives the same fee."""
    for contracts in (1, 7, 100, 333, 2500):
        for cents in range(1, 100):
            p = cents / 100
            assert xvenue.pmus_fee(contracts, p) == xvenue.pmus_fee(contracts, round(1 - p, 6)), (contracts, cents)
    assert xvenue.pmus_fee(500, 0.2325) == xvenue.pmus_fee(500, 0.7675)


def test_kalshi_fee_matches_its_published_range_and_rounds_up():
    """kalshi.com/fee-schedule: $0.07-$1.75 per 100 contracts."""
    assert xvenue.kalshi_fee(100, 0.50) == pytest.approx(1.75)
    assert xvenue.kalshi_fee(100, 0.01) == pytest.approx(0.07)
    # 0.07 x 1 x 0.3 x 0.7 = 0.0147 -> an ordinary account pays a whole cent up.
    assert xvenue.kalshi_fee(1, 0.30) == pytest.approx(0.02)


def test_each_venue_publishes_its_own_rate_and_the_scan_uses_it():
    """Kalshi's MLB multiplier is half; Polymarket US publishes a coefficient on every
    market. Charging one rate everywhere is how a real arb is hidden or a false one shown."""
    v = Venues()
    assert xvenue.kalshi_fee_rate(v, "nfl") == pytest.approx(0.07)
    assert xvenue.kalshi_fee_rate(v, "mlb") == pytest.approx(0.035)
    for league in xvenue.LEAGUES:
        _, pm = games(v, league)
        assert {g.fee_rate for g in pm} == {0.0695}, league
    v.market("nfl", HOU_TEN_PM)["feeCoefficient"] = 0.08
    assert pm_game(v, "nfl", HOU_TEN_PM).fee_rate == 0.08, "what the market says it charges"


def test_a_coefficient_that_cannot_be_read_is_charged_at_the_dearer_rate():
    for lost in (None, 0, -1, 9, "free", True):
        v = Venues()
        v.market("nfl", HOU_TEN_PM)["feeCoefficient"] = lost
        assert pm_game(v, "nfl", HOU_TEN_PM).fee_rate == xvenue.PMUS_DEARER_COEFF, lost
    del v.market("nfl", HOU_TEN_PM)["feeCoefficient"]
    assert pm_game(v, "nfl", HOU_TEN_PM).fee_rate == xvenue.PMUS_DEARER_COEFF
    assert xvenue.PMUS_DEARER_COEFF > xvenue.PMUS_TAKER_COEFF


def test_a_kalshi_fee_type_this_version_does_not_know_is_refused():
    v = Venues()
    v.f["kalshi_series"]["nhl"]["series"]["fee_type"] = "flat"
    with pytest.raises(ValueError):
        xvenue.kalshi_fee_rate(v, "nhl")
    got = scan(v)
    assert any("NHL" in e and "fee schedule" in e and "does not know" in e for e in got.errors)
    assert got.leagues["nhl"]["kalshi_games"] == 0 and got.leagues["nhl"]["matched"] == 0, (
        "a fee this version has no formula for is not priced at some other fee")
    assert got.leagues["nfl"]["matched"] == 6


def test_a_fee_schedule_that_cannot_be_read_is_charged_as_recorded_and_says_so():
    v = Venues()
    v.fail["/series/KXMLBGAME"] = OSError("offline")
    got = scan(v)
    assert any("MLB" in e and "fee schedule could not be read" in e and "0.5x" in e for e in got.errors)
    assert got.leagues["mlb"]["matched"] == 3, "the games are still read; only the fee is the recorded one"


# --- the dates: both venues use Eastern time -------------------------------------

def test_eastern_date_follows_the_us_daylight_rule_like_the_time_zone_database():
    zoneinfo = pytest.importorskip("zoneinfo")
    try:
        ny = zoneinfo.ZoneInfo("America/New_York")
    except zoneinfo.ZoneInfoNotFoundError:
        pytest.skip("no time zone database on this machine")
    utc = dt.timezone.utc
    for start in (dt.datetime(2025, 3, 8, tzinfo=utc), dt.datetime(2026, 3, 7, tzinfo=utc),
                  dt.datetime(2026, 10, 31, tzinfo=utc), dt.datetime(2027, 3, 13, tzinfo=utc),
                  dt.datetime(2027, 11, 6, tzinfo=utc)):
        for hour in range(0, 24 * 4):
            when = start + dt.timedelta(hours=hour)
            assert xvenue.eastern_date(when.timestamp()) == when.astimezone(ny).date(), when
    # Monday night kick-off: 00:15 UTC on the 13th is 8:15pm on the 12th.
    assert xvenue.eastern_date(dt.datetime(2026, 10, 13, 0, 15, tzinfo=utc).timestamp()) == dt.date(2026, 10, 12)


def test_a_polymarket_us_game_is_dated_by_its_start_in_eastern_time_not_utc():
    v = Venues()
    _, nfl = games(v, "nfl")
    by_ref = {g.ref: g for g in nfl}
    assert by_ref["aec-nfl-buf-lar-2026-10-12"].date == dt.date(2026, 10, 12)       # 2026-10-13T00:15Z
    assert by_ref["aec-nfl-bal-atl-2026-10-11"].date == dt.date(2026, 10, 11)       # 2026-10-12T00:20Z
    _, nba = games(v, "nba")
    assert {g.ref: g for g in nba}["aec-nba-mem-chi-2026-10-09"].date == dt.date(2026, 10, 9)   # 2026-10-10T00:00Z


def test_a_game_with_no_start_time_has_no_date_and_is_refused():
    v = Venues()
    for lost in (None, "", "tomorrow"):
        v.market("nfl", HOU_TEN_PM)["gameStartTime"] = lost
        assert not is_read(v, "nfl", HOU_TEN_PM), lost


# --- parsing and matching ---------------------------------------------------

def test_kalshi_game_is_read_from_its_ticker():
    k, _ = games(Venues(), "nfl")
    g = next(g for g in k if g.ref == HOU_TEN)
    assert g.teams == ("HOU", "TEN") and g.date == dt.date(2026, 10, 11)
    assert 0 < g.ask["HOU"] < 1 and 0 < g.ask["TEN"] < 1
    assert g.size["HOU"] > 1_000_000 and g.size["TEN"] > 1_000


def test_a_ticker_that_spells_jacksonville_JAC_is_still_read():
    """The first port compared Kalshi's JAC with the table's JAX and dropped the
    game in silence, so the Jaguars never appeared on the board."""
    k, p = games(Venues(), "nfl")
    g = next((g for g in k if g.ref == PHI_JAC), None)
    assert g is not None, "the Jaguars' game was dropped"
    assert g.teams == ("JAX", "PHI")
    assert len(xvenue.match(k, p)) == len(k), "every recorded Kalshi game finds its Polymarket US game"


def test_a_baseball_ticker_with_a_start_time_is_read():
    k, _ = games(Venues(), "mlb")
    g = next(g for g in k if g.ref == "KXMLBGAME-26OCT102000CWSCLE")
    assert g.date == dt.date(2026, 10, 10) and g.teams == ("CLE", "CWS")


def test_a_game_whose_markets_are_not_the_pair_the_ticker_names_is_refused():
    v = Venues()
    v.kalshi("nfl", HOU_TEN, "TEN")["ticker"] = HOU_TEN + "-NE"
    k, _ = games(v, "nfl")
    assert HOU_TEN not in {g.ref for g in k}


def test_a_game_with_a_side_nobody_is_selling_is_refused():
    v = Venues()
    v.kalshi("nfl", HOU_TEN, "TEN")["yes_ask_dollars"] = "0.0000"
    v.kalshi("nfl", PHI_JAC, "PHI")["yes_ask_dollars"] = None
    k, _ = games(v, "nfl")
    assert not {HOU_TEN, PHI_JAC} & {g.ref for g in k}


def test_a_market_that_is_not_open_is_not_read():
    v = Venues()
    v.kalshi("nba", MEM_CHI, "MEM")["status"] = "closed"
    k, _ = games(v, "nba")
    assert MEM_CHI not in {g.ref for g in k}
    slug = "aec-nba-mem-chi-2026-10-09"
    for field, value in (("closed", True), ("active", False), ("hidden", True), ("status", "MARKET_STATUS_RESOLVING"),
                         ("status", "MARKET_STATUS_HALTED")):
        v = Venues()
        v.market("nba", slug)[field] = value
        assert not is_read(v, "nba", slug), (field, value)
    assert is_read(Venues(), "nba", slug)


def test_a_polymarket_us_side_nobody_is_selling_is_refused():
    """The Rockets-Mavericks market had a bid and no offer: the Rockets cannot be bought."""
    v = Venues()
    assert not is_read(v, "nba", "aec-nba-hou-dal-2026-10-09"), "as recorded"
    assert not is_read(v, "nba", "aec-nba-okc-hou-2026-10-15"), "as recorded: no quotes at all"
    for field in ("bestAskQuote", "bestBidQuote"):
        v = Venues()
        v.market("nfl", HOU_TEN_PM)[field] = None
        assert not is_read(v, "nfl", HOU_TEN_PM), field
        v.market("nfl", HOU_TEN_PM)[field] = amount("1.0000")
        assert not is_read(v, "nfl", HOU_TEN_PM), "a price of a dollar is not a price"


def test_polymarket_us_game_is_read_from_its_typed_fields_not_its_slug():
    v = Venues()
    g = pm_game(v, "nfl", HOU_TEN_PM)
    assert g.teams == ("HOU", "TEN") and g.long == "HOU" and g.league == "nfl"
    assert g.ask == {"HOU": pytest.approx(0.77), "TEN": pytest.approx(0.2325)}      # ask, and 1 - bid 0.7675
    assert g.size == {} and g.min_size == 0.01 and g.starts_at == pytest.approx(1791738000.0)
    # The slug is not read: a market whose slug says other teams is still the teams its sides name.
    v.market("nfl", HOU_TEN_PM)["slug"] = "aec-nfl-ne-no-2026-10-11"
    assert pm_game(v, "nfl", "aec-nfl-ne-no-2026-10-11").teams == ("HOU", "TEN")


def test_polymarket_us_spellings_become_the_tables_and_names_are_checked():
    _, nba = games(Venues(), "nba")
    by_ref = {g.ref: g for g in nba}
    assert by_ref["aec-nba-sac-gs-2026-10-10"].teams == ("GSW", "SAC")                # gs
    assert by_ref["aec-nba-sa-pho-2026-10-10"].teams == ("PHX", "SAS")                # sa, pho
    assert by_ref["aec-nba-min-ny-2026-10-12"].teams == ("MIN", "NYK")                # ny
    _, nhl = games(Venues(), "nhl")
    by_ref = {g.ref: g for g in nhl}
    assert by_ref["aec-nhl-la-veg-2026-10-10"].teams == ("LA", "VGK")                 # veg is Vegas here
    assert by_ref["aec-nhl-det-mon-2026-10-10"].teams == ("DET", "MTL")               # mon
    assert by_ref["aec-nhl-nas-ott-2026-10-10"].teams == ("NSH", "OTT")               # nas
    assert by_ref["aec-nhl-nyr-was-2026-10-09"].teams == ("NYR", "WSH")               # was


def test_every_team_in_the_table_has_exactly_one_polymarket_us_team():
    """The recorded team lists (players included) against the table: a team the
    venue spells a way the table cannot read would silently never match."""
    for league, table in xvenue.LEAGUE_TEAMS.items():
        found = {}
        for t in FIXTURE["polymarket_us_teams"][league]:
            key = xvenue.team_key(league, t["abbreviation"], xvenue.PMUS_TO_TABLE)
            if key is not None and xvenue._named(league, key, t["name"]):
                found.setdefault(key, []).append(t["abbreviation"])
        assert sorted(found) == sorted(table), (league, sorted(set(table) - set(found)))
        assert all(len(v) == 1 for v in found.values()), found


def test_a_team_whose_code_and_name_disagree_is_refused():
    """The code names one team and the name another: neither is trusted."""
    v = Venues()
    mk = v.market("nfl", HOU_TEN_PM)
    long_side = next(s for s in mk["marketSides"] if s["long"])
    long_side["team"]["abbreviation"] = "dal"                       # the Cowboys' code on the Texans
    assert not is_read(v, "nfl", HOU_TEN_PM)
    v = Venues()
    long_side = next(s for s in v.market("nfl", HOU_TEN_PM)["marketSides"] if s["long"])
    long_side["team"]["name"] = "Dallas Cowboys"                    # the Cowboys' name on the Texans' code
    assert not is_read(v, "nfl", HOU_TEN_PM)
    v = Venues()
    long_side = next(s for s in v.market("nfl", HOU_TEN_PM)["marketSides"] if s["long"])
    long_side["team"]["league"] = "nba"                             # a team of another league
    assert not is_read(v, "nfl", HOU_TEN_PM)


def test_a_city_two_teams_share_is_not_a_name():
    """'New York' could be the Mets or the Yankees; 'Utah' is one team."""
    assert not xvenue._named("mlb", "NYY", "New York")
    assert xvenue._named("mlb", "NYY", "New York Yankees") and xvenue._named("mlb", "NYY", "Yankees")
    assert xvenue._named("nhl", "UTA", "Utah")


def test_a_market_that_is_not_a_full_game_winner_is_not_read():
    v = Venues()
    for kind in ("football_team_first_half_winner", "football_team_full_game_spread", "football_team_full_game_total",
                 "baseball_team_full_game_winner", "moneyline", None):
        v.market("nfl", HOU_TEN_PM)["sportsMarketType"] = kind
        assert not is_read(v, "nfl", HOU_TEN_PM), kind


def test_games_with_the_wrong_number_of_sides_or_flags_are_refused():
    v = Venues()
    mk = v.market("nfl", HOU_TEN_PM)
    sides = copy.deepcopy(mk["marketSides"])
    for broken in (sides[:1], sides + sides[:1], [dict(sides[0]), dict(sides[0])]):
        mk["marketSides"] = broken
        assert not is_read(v, "nfl", HOU_TEN_PM)
    for flags in ((True, True), (False, False), (None, True), ("yes", False)):
        mk["marketSides"] = copy.deepcopy(sides)
        for side, flag in zip(mk["marketSides"], flags):
            side["long"] = flag
            side.pop("quote")                 # the quotes would refuse the flipped ones too: test the flags alone
        assert not is_read(v, "nfl", HOU_TEN_PM), flags


def test_nfl_games_match_across_the_utc_day_by_their_eastern_date():
    v = Venues()
    k, p = games(v, "nfl")
    pairs = {a.ref: b for a, b in xvenue.match(k, p)}
    assert pairs[BUF_LAR].ref == "aec-nfl-buf-lar-2026-10-12" and pairs[BUF_LAR].date == dt.date(2026, 10, 12)
    assert len(pairs) == 6
    # A game on another Eastern date is another game, whichever league it is in.
    mk = v.market("nfl", "aec-nfl-buf-lar-2026-10-12")
    mk["gameStartTime"] = "2026-10-14T00:15:00Z"
    k, p = games(v, "nfl")
    assert BUF_LAR not in {a.ref for a, _ in xvenue.match(k, p)}


def test_a_series_game_never_pairs_with_the_next_days_game():
    """Baseball plays the same two teams on consecutive days. On 2026-10-06 a day of
    slack paired today's game with tomorrow's, at a price that looked guaranteed."""
    k, p = games(Venues(), "mlb")
    pairs = xvenue.match(k, p)
    lad_mil = sorted((a.date, b.date) for a, b in pairs if a.teams == ("LAD", "MIL"))
    assert lad_mil == [(dt.date(2026, 10, 11), dt.date(2026, 10, 11)), (dt.date(2026, 10, 12), dt.date(2026, 10, 12))]
    # With only the 11th on Polymarket US, Kalshi's 12th has no game to pair with.
    only_11 = [g for g in p if g.date != dt.date(2026, 10, 12)]
    assert sorted(a.date for a, _ in xvenue.match(k, only_11) if a.teams == ("LAD", "MIL")) == [dt.date(2026, 10, 11)]
    # Kalshi's Brewers-Dodgers game on the 14th has no partner on the other side: it is not matched.
    assert "KXMLBGAME-26OCT142000MILLAD" in {g.ref for g in k}
    assert "KXMLBGAME-26OCT142000MILLAD" not in {a.ref for a, _ in pairs}


def test_leagues_never_mix():
    """Minnesota and Dallas have NBA and NHL teams with the same codes on the same night."""
    when = dt.date(2026, 10, 22)
    nba = xvenue.Game("kalshi", ("DAL", "MIN"), when, {"DAL": 0.5, "MIN": 0.5}, "KXNBAGAME", league="nba")
    nhl = xvenue.Game("polymarket_us", ("DAL", "MIN"), when, {"DAL": 0.5, "MIN": 0.5}, "nhl-dal-min", league="nhl")
    assert xvenue.match([nba], [nhl]) == []


def test_a_game_two_listings_could_be_is_priced_as_neither():
    """A doubleheader: two Kalshi games with the same teams on the same date, one
    Polymarket US market. Pairing it with both would price one of them against the
    wrong game."""
    when = dt.date(2026, 10, 22)
    kal = [xvenue.Game("kalshi", ("CLE", "CWS"), when, {"CLE": 0.5, "CWS": 0.5}, f"KXMLBGAME-{t}", league="mlb")
           for t in ("a", "b")]
    pol = [xvenue.Game("polymarket_us", ("CLE", "CWS"), when, {"CLE": 0.5, "CWS": 0.5}, "mlb-cle-cws", league="mlb")]
    assert xvenue.match(kal, pol) == []
    assert len(xvenue.match(kal[:1], pol)) == 1


# --- which side is which on Polymarket US ----------------------------------------------

def _priced(v, slug):
    """The recorded book for a market, applied to its game."""
    g = pm_game(v, "nfl", slug)
    assert xvenue.add_pmus_depth(v, [g], {(slug, t) for t in g.teams}, clock=lambda: NOW) == []
    return g


def test_the_instrument_is_bought_at_its_ask_and_the_other_team_by_selling_it_at_the_bid():
    """One instrument per market (buying-yes-vs-selling-no): backing the team it pays on is
    buying it, so the cost is the best offer; backing the other team is selling it, which the
    venue records as a short, so the cost of a contract that pays $1 if that team wins is 1 -
    the best bid. The BBO payload recorded beside the book says the same in the venue's own
    words: longQuote is what the long team costs, shortQuote what the other costs."""
    v = Venues()
    for slug, long_team, short_team in ((HOU_TEN_PM, "HOU", "TEN"), (PHI_JAX_PM, "PHI", "JAX")):
        book = v.f["polymarket_us_books"][slug]["marketData"]
        bbo = v.f["polymarket_us_bbo"][slug]["marketData"]
        best_offer, best_bid = Decimal(book["offers"][0]["px"]["value"]), Decimal(book["bids"][0]["px"]["value"])
        assert best_offer == Decimal(bbo["longQuote"]["value"]) == Decimal(bbo["bestAsk"]["value"])
        assert 1 - best_bid == Decimal(bbo["shortQuote"]["value"])
        g = _priced(v, slug)
        assert g.long == long_team
        assert g.ask[long_team] == float(best_offer)
        assert g.ask[short_team] == float(1 - best_bid)
        assert g.size[long_team] == float(book["offers"][0]["qty"]), "the contracts resting at the offer"
        assert g.size[short_team] == float(book["bids"][0]["qty"]), "the contracts resting at the bid"
        # Buying both teams costs a dollar plus the spread: the two costs describe one book.
        assert g.ask[long_team] + g.ask[short_team] == pytest.approx(1 + float(best_offer - best_bid))


def test_a_wrong_side_mapping_is_not_an_arbitrage_and_is_never_listed():
    """Swap the sides and Kalshi's Titans at 15c against 'Texans at 1 - bid' = 23c is a
    63% 'arbitrage'. The Texans are the instrument: they cost the 77c offer."""
    got = scan(arb_world())
    [best] = got.pairs
    k, p = best.legs
    assert (k["team"], p["team"]) == ("TEN", "HOU")
    assert p["ask"] == pytest.approx(0.77) and p["cents"] == 77.0, "the Texans cost the offer, not 1 - the bid"
    assert best.margin < 0.10, "a pair priced the wrong way round would show 60%+"
    # And the other team: Kalshi's Texans at 70c against the Titans at 1 - the 76.75c bid.
    [best] = scan(short_world()).pairs
    assert (best.legs[0]["team"], best.legs[1]["team"]) == ("HOU", "TEN")
    assert best.legs[1]["ask"] == pytest.approx(0.2325) and best.legs[1]["cents"] == 23.25
    # A pair that does not pay on the right mapping must not pay on a flipped one either: Kalshi's
    # Eagles at 22c against Polymarket US's Jaguars at 1 - the 23.25c bid = 76.75c is 98.75c, a loss.
    v = Venues()
    v.kalshi("nfl", PHI_JAC, "PHI", ask=0.22, size=1000)
    assert scan(v).pairs == []


def test_a_market_whose_sides_contradict_its_own_quotes_is_refused():
    """If the `long` flags were flipped the Texans would be priced as the Titans were. Each
    side carries the quote the venue says it costs, and the two must agree with the mapping."""
    v = Venues()
    for side in v.market("nfl", HOU_TEN_PM)["marketSides"]:
        side["long"] = not side["long"]
    assert not is_read(v, "nfl", HOU_TEN_PM)
    v = Venues()
    v.market("nfl", HOU_TEN_PM)["marketSides"][0]["quote"] = amount("0.2325")
    assert not is_read(v, "nfl", HOU_TEN_PM)
    # Where a side states no quote there is nothing to contradict, and the market is read.
    v = Venues()
    for side in v.market("nfl", HOU_TEN_PM)["marketSides"]:
        del side["quote"]
    assert is_read(v, "nfl", HOU_TEN_PM)


# --- the order book --------------------------------------------------------------------

def test_a_book_is_read_as_exact_decimals_and_summed_at_its_best_price():
    data = {"marketData": {"marketSlug": "m", "state": "MARKET_STATE_OPEN",
                           "bids": [{"px": amount("0.4000"), "qty": "10.5"}, {"px": amount("0.4000"), "qty": "2"},
                                    {"px": amount("0.3900"), "qty": "99"}],
                           "offers": [{"px": amount("0.4300"), "qty": "7"}, {"px": amount("0.4250"), "qty": "3.25"}]}}
    top = xvenue.pmus_book_top(data, "m")
    assert top["offer"] == (Decimal("0.4250"), Decimal("3.25")), "the lowest offer, whatever the order sent"
    assert top["bid"] == (Decimal("0.4000"), Decimal("12.5")), "everything resting at the best bid"
    assert isinstance(top["offer"][0], Decimal)


def test_a_price_that_is_not_a_decimal_dollar_is_not_a_level():
    """The trader guide's exchange API sends integers and a scale ("550" / 1000). This gateway
    sends decimal strings; a price that arrives as 550 must not be read as anything."""
    data = {"marketData": {"marketSlug": "m", "state": "MARKET_STATE_OPEN",
                           "bids": [{"px": {"value": "550", "currency": "USD"}, "qty": "10"},
                                    {"px": {"value": "0.5", "currency": "EUR"}, "qty": "10"},
                                    {"px": amount("0"), "qty": "10"}, {"px": amount("1"), "qty": "10"},
                                    {"px": amount("0.5"), "qty": "0"}, {"px": amount("x"), "qty": "10"}],
                           "offers": []}}
    assert xvenue.pmus_book_top(data, "m") == {"offer": None, "bid": None}


def test_a_book_for_another_market_or_not_open_or_crossed_is_an_error():
    good = {"marketData": {"marketSlug": "m", "state": "MARKET_STATE_OPEN", "bids": [], "offers": []}}
    with pytest.raises(ValueError):
        xvenue.pmus_book_top(good, "other")
    with pytest.raises(xvenue.NotOpen):
        xvenue.pmus_book_top({"marketData": {**good["marketData"], "state": "MARKET_STATE_SUSPENDED"}}, "m")
    with pytest.raises(xvenue.NotOpen):
        xvenue.pmus_book_top({"marketData": {"marketSlug": "m", "bids": [], "offers": []}}, "m")
    crossed = {"marketData": {**good["marketData"], "bids": [{"px": amount("0.6"), "qty": "1"}],
                              "offers": [{"px": amount("0.5"), "qty": "1"}]}}
    with pytest.raises(ValueError):
        xvenue.pmus_book_top(crossed, "m")
    with pytest.raises(ValueError):
        xvenue.pmus_book_top(None, "m")


def test_the_two_teams_of_a_game_are_priced_from_one_book_read_once():
    v = arb_world()
    scan(v)
    books = [u for u in v.requests if u.endswith("/book")]
    assert books.count(f"https://gateway.polymarket.us/v1/markets/{HOU_TEN_PM}/book") == 1


# --- sizing and pricing ---------------------------------------------------------------

def _pair(k_ask, p_ask, k_size=5000, p_size=5000, league="nhl", teams=("CHI", "PIT"), p_min=1.0, **kw):
    """CHI against PIT: Kalshi sells PIT at k_ask[PIT], Polymarket US sells CHI at p_ask[CHI]."""
    when = dt.date(2026, 10, 22)
    k = xvenue.Game("kalshi", teams, when, dict(k_ask), "KX", league=league, size={t: k_size for t in teams},
                    fee_rate=0.07, read_at=NOW - 6)
    p = xvenue.Game("polymarket_us", teams, when, dict(p_ask), "aec-nhl-chi-pit-2026-10-22", league=league,
                    size={t: p_size for t in teams}, long=teams[0], fee_rate=0.0695, min_size=p_min, read_at=NOW - 4,
                    depth_at={t: NOW - 2 for t in teams})
    return k, p


def test_a_real_gap_is_an_arb_after_fees_at_the_size_on_offer():
    got = scan(arb_world(kalshi_size=500))
    best = next(r for r in got.pairs if r.legs[0]["team"] == "TEN")
    assert best.game == "Houston Texans vs Tennessee Titans" and best.league == "nfl"
    k, p = best.legs
    assert (k["venue"], k["team"], p["venue"], p["team"]) == ("kalshi", "TEN", "polymarket_us", "HOU")
    # 500 contracts: Kalshi shows 500 at 15c; Polymarket US shows 552,547 at 77c; $1,000 would buy ~1,000.
    assert best.contracts == 500 and best.limited_by == "kalshi"
    assert k["contracts"] == p["contracts"] == 500 and k["on_offer"] == 500 and p["on_offer"] == 552547
    kalshi_fee, pmus_fee = xvenue.kalshi_fee(500, 0.15), xvenue.pmus_fee(500, 0.77)
    assert kalshi_fee == pytest.approx(4.47) and pmus_fee == pytest.approx(6.15)
    # Profit is what is left after BOTH fees, on the contracts actually bought.
    assert best.profit == pytest.approx(500 - 500 * (0.15 + 0.77) - kalshi_fee - pmus_fee, abs=0.01)
    assert best.profit == 29.38
    assert best.staked == pytest.approx(500 * 0.92 + kalshi_fee + pmus_fee, abs=0.01)
    assert best.margin == pytest.approx(best.profit / best.staked, abs=1e-4)
    # Equal contracts on each side pay the same dollar whichever team wins.
    assert [leg["if_wins"] for leg in best.legs] == [best.profit, best.profit]
    assert k["cost"] == 75.0 and p["cost"] == 385.0
    assert got.pairs == [best], "the one pair that pays, and nothing else"


def test_the_other_team_is_priced_the_same_way_round_through_the_bid():
    [best] = scan(short_world()).pairs
    k, p = best.legs
    assert (k["team"], p["team"]) == ("HOU", "TEN")
    assert best.contracts == 500 and best.limited_by == "kalshi" and p["on_offer"] == 381778   # resting at the bid
    kalshi_fee, pmus_fee = xvenue.kalshi_fee(500, 0.70), xvenue.pmus_fee(500, 0.2325)
    assert (kalshi_fee, pmus_fee) == (7.35, 6.20)
    assert best.profit == pytest.approx(500 - 500 * (0.70 + 0.2325) - kalshi_fee - pmus_fee, abs=0.01)
    assert best.profit == 20.20 and p["cost"] == 116.25


def test_the_pair_is_sized_to_the_smallest_book_or_the_money():
    assert scan(arb_world(kalshi_size=40)).pairs[0].contracts == 40
    rich = scan(arb_world(kalshi_size=5_000_000), bankroll=100.0).pairs[0]
    assert rich.limited_by == "bankroll" and rich.staked <= 100.0 + 1e-9
    assert 105 <= rich.contracts <= 108, "about $100 at 92c a pair and 1.5c of fees"


def test_the_pair_never_costs_more_than_the_money_you_said_including_fees():
    """Sized on cost alone, $1,000 bought $1,012 of bets once the fees were added."""
    for bankroll in (50.0, 100.0, 333.0, 1000.0, 7000.0):
        k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62}, k_size=10**7, p_size=10**7)
        [row] = [r for r in xvenue.price_pairs([(k, p)], bankroll=bankroll, now=NOW) if r.profit > 0]
        assert row.staked <= bankroll + 1e-9, bankroll
        assert row.contracts * row.cost_per_pair + row.fees == pytest.approx(row.staked, abs=0.011)
        # ...and is the most that fits: one more contract would not.
        more = row.contracts + 1
        assert more * 0.90 + k.fee(more, 0.40) + p.fee(more, 0.50) > bankroll - 1e-9


def test_a_bankroll_that_cannot_buy_one_pair_buys_none():
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    assert xvenue.price_pairs([(k, p)], bankroll=0.80, now=NOW) == []
    assert xvenue.price_pairs([(k, p)], bankroll=0.0, now=NOW) == []


def test_a_leg_whose_size_is_not_known_is_not_priced():
    """Kalshi's list omitting a size, or Polymarket US's book never read: unknown is
    not unlimited. The first port sized an unknown Kalshi leg by the bankroll."""
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    assert [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    k.size = {}
    assert not [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    del p.size["CHI"]
    assert not [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0 and r.legs[1]["team"] == "CHI"]
    k.size["PIT"] = 0
    assert not [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.legs[0]["team"] == "PIT"]


def test_a_polymarket_us_leg_is_limited_to_the_contracts_at_the_books_best_price():
    v = arb_world()
    v.kalshi("nfl", HOU_TEN, "TEN", size=5000)
    v.book(HOU_TEN_PM, offers=[(0.77, 12), (0.79, 90000)])               # only 12 contracts at 77c
    [best] = scan(v).pairs
    assert best.contracts == 12 and best.limited_by == "polymarket_us"
    assert best.legs[1]["on_offer"] == 12 and best.legs[0]["on_offer"] == 5000


def test_polymarket_us_is_priced_at_what_its_book_sells_for_not_at_its_list_quote():
    """The market list can be cents off the book (a game under way moves faster than
    the list). Here the list quotes the Texans at 77c while the book sells them at 86c."""
    v = arb_world()
    v.book(HOU_TEN_PM, offers=[(0.86, 342), (0.87, 900)])
    assert scan(v).pairs == [], "the book decides, not the list"
    # And when the book backs the quote, the same pair pays, at the book's size.
    v.book(HOU_TEN_PM, offers=[(0.77, 342), (0.78, 900)], bids=[(0.7675, 5000)])
    [best] = scan(v).pairs
    assert best.legs[1]["ask"] == 0.77 and best.legs[1]["on_offer"] == 342 and best.contracts == 342


def test_an_unreadable_polymarket_us_book_is_no_arbitrage_and_is_reported():
    v = arb_world()
    v.fail["gateway.polymarket.us/v1/markets/aec"] = OSError("offline")
    got = scan(v)
    assert got.pairs == []
    assert any("Polymarket US's book" in e and "Houston Texans" in e for e in got.errors)
    v = arb_world()
    v.book(HOU_TEN_PM, offers=[])
    assert scan(v).pairs == [], "an empty offer side has nothing to buy"
    v = arb_world()
    del v.f["polymarket_us_books"][HOU_TEN_PM]
    got = scan(v)
    assert got.pairs == [] and any("Polymarket US's book" in e for e in got.errors)


def test_a_book_that_is_not_open_or_is_another_markets_is_no_arbitrage_and_is_reported():
    v = arb_world()
    v.f["polymarket_us_books"][HOU_TEN_PM]["marketData"]["state"] = "MARKET_STATE_HALTED"
    got = scan(v)
    assert got.pairs == [] and any("not open for trading" in e and "Houston Texans" in e for e in got.errors)
    v = arb_world()
    v.f["polymarket_us_books"][HOU_TEN_PM]["marketData"]["marketSlug"] = PHI_JAX_PM
    assert scan(v).pairs == []


def test_an_order_under_the_smallest_the_market_takes_is_not_a_play():
    v = arb_world()
    v.market("nfl", HOU_TEN_PM)["minimumTradeQty"] = 5
    v.book(HOU_TEN_PM, offers=[(0.77, 3)])
    assert scan(v).pairs == []
    v.book(HOU_TEN_PM, offers=[(0.77, 5)])
    assert scan(v).pairs[0].contracts == 5
    assert pm_game(v, "nfl", HOU_TEN_PM).min_size == 5.0


def test_a_dollar_of_cost_is_a_loss_once_fees_are_paid():
    k, p = _pair({"CHI": 0.60, "PIT": 0.41}, {"CHI": 0.59, "PIT": 0.60})        # PIT 0.41 + CHI 0.59 = $1.00
    rows = xvenue.price_pairs([(k, p)], now=NOW)
    assert rows and all(r.profit < 0 for r in rows)


def test_ranked_by_margin_not_by_dollars():
    fat_small = _pair({"CHI": 0.60, "PIT": 0.30}, {"CHI": 0.60, "PIT": 0.61}, k_size=40)
    thin_big = _pair({"CHI": 0.60, "PIT": 0.42}, {"CHI": 0.53, "PIT": 0.60}, k_size=100000)
    rows = [r for r in xvenue.price_pairs([fat_small, thin_big], bankroll=5000, now=NOW) if r.profit > 0]
    assert len(rows) == 2
    assert [r.margin for r in rows] == sorted((r.margin for r in rows), reverse=True)
    assert rows[0].contracts == 40 and rows[0].profit < rows[1].profit, "the small fat one is first, by margin"


def test_every_pairing_says_what_the_two_venues_do_differently_and_does_not_overclaim():
    for r in scan(arb_world()).pairs:
        n = r.note
        assert "postponed" in n and "48 hours" in n and "two days in baseball" not in n
        assert "Polymarket US" in n and "Kalshi" in n and "about two weeks" in n and "last fair market price" in n
        assert "tie pays 50c per side on both" in n
        assert "not promised" in n, "a fair-price settlement is not promised to add up to a dollar"
        assert not re.search(r"guarantee|risk-free|certain", n, re.I)
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    [row] = [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    assert "postponed" in row.note and "tie" not in row.note and "two days in baseball" in row.note
    assert not re.search(r"guarantee|risk-free|certain", row.note, re.I)


def test_a_game_under_way_says_so():
    v = arb_world()
    [best] = scan(v).pairs
    assert best.starts_at is not None and best.in_play is False      # kick-off is 2026-10-11 17:00 UTC
    later = xvenue.scan(v, clock=lambda: best.starts_at + 600, state=STATE)
    assert later.pairs and later.pairs[0].in_play is True


def test_age_is_measured_from_the_oldest_price_read():
    k, p = _pair({"CHI": 0.60, "PIT": 0.40}, {"CHI": 0.50, "PIT": 0.62})
    [row] = [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    assert row.read_at == NOW - 6 and row.age == 6.0                # Kalshi's read is the oldest
    p.depth_at["CHI"] = NOW - 30
    [row] = [r for r in xvenue.price_pairs([(k, p)], now=NOW) if r.profit > 0]
    assert row.age == 30.0, "an old order book makes the whole pair old"


# --- the scan ---------------------------------------------------------------------------

def test_the_recorded_market_has_no_arb_and_the_scan_says_nothing_pays():
    v = Venues()
    got = scan(v)
    assert got.pairs == [] and got.errors == []
    assert got.read_anything and got.matched >= 15
    assert got.source().endswith("0 playable") and "Kalshi games" in got.source() and "Polymarket US games" in got.source()
    assert {lg: c["matched"] for lg, c in got.leagues.items()} == {
        "nfl": 6, "mlb": 3, "nba": 5, "nhl": 5}, "every recorded game finds its other venue"
    assert got.kalshi_games == 21 and got.polymarket_us_games == 19 and got.matched == 19
    assert got.priced > 0


def test_only_pairs_that_pay_are_listed_never_the_nearest_misses():
    v = arb_world()
    # Another game, a few cents short: priced, close, and not a play.
    v.kalshi("nfl", PHI_JAC, "PHI", ask=0.22, size=1000)               # + Polymarket US's Jaguars at 76.75c: 98.75c, less fees
    got = scan(v)
    assert [r.game for r in got.pairs] == ["Houston Texans vs Tennessee Titans"]
    assert got.priced > len(got.pairs), "the near misses were priced, and not listed"
    k, p = games(v, "nfl")
    xvenue.add_pmus_depth(v, [b for _, b in xvenue.match(k, p)], {(PHI_JAX_PM, "JAX")}, clock=lambda: NOW)
    near = [r for r in xvenue.price_pairs(xvenue.match(k, p), now=NOW) if r.game.startswith("Jacksonville")]
    assert near and all(r.profit <= 0 for r in near)
    assert len(json.loads(json.dumps(got.as_dict()))["pairs"]) == len(got.pairs)


def test_hide_under_applies_to_the_return():
    v = arb_world()
    [best] = scan(v).pairs
    assert scan(v, min_margin=best.margin - 0.001).pairs
    assert scan(v, min_margin=best.margin + 0.001).pairs == []


def test_one_league_failing_does_not_fail_the_scan():
    v = arb_world()
    v.fail["KXNHLGAME"] = OSError("offline")
    got = scan(v)
    assert got.pairs and got.read_anything
    assert any("NHL" in e and "no connection" in e for e in got.errors)
    assert got.leagues["nfl"]["matched"] == 6 and got.leagues["nhl"]["kalshi_games"] == 0


def test_a_polymarket_us_league_that_is_not_operational_or_not_listed_is_named():
    v = Venues()
    for s in v.f["polymarket_us_sports"]["sports"]:
        if s["sport"] == "mlb":
            s["isOperational"] = False
    got = scan(v)
    assert any("Polymarket US lists no MLB games" in e for e in got.errors)
    assert got.leagues["mlb"]["polymarket_us_games"] == 0 and got.leagues["mlb"]["matched"] == 0
    assert got.leagues["nfl"]["matched"] == 6


def test_nothing_read_is_not_nothing_to_play():
    v = Venues()
    v.fail["api.elections.kalshi.com"] = OSError("offline")
    v.fail["gateway.polymarket.us"] = OSError("offline")
    got = scan(v)
    assert got.read_anything is False and got.pairs == [] and got.errors
    assert got.as_dict()["read_anything"] is False and got.as_dict()["ran"] is True


def test_a_failed_read_names_its_reason_in_plain_words():
    import socket
    import urllib.error
    v = Venues()
    v.fail["KXNFLGAME"] = urllib.error.HTTPError("u", 429, "Too Many", {}, None)
    v.fail["KXMLBGAME"] = socket.timeout("timed out")
    v.fail["KXNBAGAME"] = ValueError("{not json")
    got = scan(v)
    text = " | ".join(got.errors)
    assert "NFL prices could not be read (HTTP 429)" in text
    assert "MLB prices could not be read (timed out)" in text
    assert "NBA prices could not be read (an answer this version does not understand)" in text
    assert "{not json" not in text


def test_only_games_near_a_profit_get_their_book_read():
    """A book per game on the venue would be hundreds of requests."""
    v = arb_world()
    scan(v)
    asked = {u.split("/")[-2] for u in v.requests if u.endswith("/book")}
    assert HOU_TEN_PM in asked, "the Texans' book, behind the arbitrage, was read"
    v = Venues()
    got = scan(v)
    books = [u for u in v.requests if u.endswith("/book")]
    assert 0 < len(books) < got.matched, (len(books), got.matched)


def test_kalshis_cursor_is_followed_and_polymarket_uss_pages_are_walked():
    pages = {"": {"events": [{"event_ticker": "a"}], "cursor": "next page=1"}, "next page=1": {"events": [{"event_ticker": "b"}], "cursor": ""}}
    seen = []

    def fetch(url):
        seen.append(url)
        cursor = parse_qs(urlparse(url).query).get("cursor", [""])[0]
        return pages[cursor]
    payload, _ = xvenue.kalshi_events(fetch, "KXNFLGAME")
    assert [e["event_ticker"] for e in payload["events"]] == ["a", "b"]
    assert "cursor=next%20page%3D1" in seen[1]

    full = {"markets": [{"slug": f"x{i}"} for i in range(100)]}
    calls = []

    def pm(url):
        calls.append(parse_qs(urlparse(url).query)["offset"][0])
        return full if len(calls) == 1 else {"markets": [{"slug": "last"}]}
    got, _ = xvenue.pmus_markets(pm, "1")
    assert len(got) == 101 and calls == ["0", "100"]


def test_the_market_list_asks_for_one_leagues_open_moneylines():
    seen = []
    xvenue.pmus_markets(lambda url: seen.append(url) or {"markets": []}, "7")
    parsed = urlparse(seen[0])
    q = parse_qs(parsed.query)
    assert (parsed.netloc, parsed.path) == ("gateway.polymarket.us", "/v1/markets")
    assert q["tagIds"] == ["7"] and q["marketTypes"] == ["moneyline"] and q["active"] == ["true"]
    assert q["closed"] == ["false"] and q["limit"] == ["100"] and q["offset"] == ["0"]


def test_a_league_with_more_games_than_the_pages_hold_says_so():
    v = Venues()
    page = {"markets": [{"slug": f"x{i}"} for i in range(100)]}
    original = v.__call__

    def fat(url):
        if "/v1/markets?" in url and parse_qs(urlparse(url).query)["tagIds"] == ["1"]:
            return page
        return original(url)
    got = xvenue.scan(fat, clock=lambda: NOW, state=STATE)
    assert any("more NFL games than this version reads" in e for e in got.errors)


def test_the_requests_carry_nothing_about_the_person():
    """Public market data, going one way: no stake, no identity, no state, nothing but the league."""
    v = arb_world()
    scan(v, bankroll=12345.67, state="NJ")
    assert v.requests
    for url in v.requests:
        parsed = urlparse(url)
        assert parsed.netloc in ("api.elections.kalshi.com", "gateway.polymarket.us"), url
        assert "12345" not in url and "bankroll" not in url.lower(), url
        assert "state" not in url.lower() and "new%20jersey" not in url.lower(), url
        assert "NJ" not in [x for values in parse_qs(parsed.query).values() for x in values], url
        assert set(parse_qs(parsed.query)) <= {"series_ticker", "status", "with_nested_markets", "limit", "cursor",
                                               "offset", "active", "closed", "marketTypes", "tagIds"}, url


def test_the_scan_makes_all_its_requests_with_the_seam_it_was_given():
    """No fetcher means no network: the module opens no socket of its own."""
    src = (Path(xvenue.__file__)).read_text()
    for opener in ("urlopen", "urllib.request", "import socket", "import requests", "http.client"):
        assert opener not in src, opener
    assert re.search(r"def scan\(fetch,", src)


def test_nothing_international_is_read():
    """Polymarket's international gamma and clob hosts are not open to US persons."""
    src = (Path(xvenue.__file__)).read_text()
    for host in ("gamma-api.polymarket.com", "clob.polymarket.com", "docs.polymarket.com"):
        assert host not in src, host
    v = Venues()
    scan(v)
    assert {urlparse(u).netloc for u in v.requests} == {"api.elections.kalshi.com", "gateway.polymarket.us"}


def test_the_scan_serialises():
    got = json.loads(json.dumps(scan(arb_world()).as_dict()))
    pair = got["pairs"][0]
    assert {"league", "teams", "game", "legs", "contracts", "fees", "profit", "margin", "staked", "limited_by",
            "age", "in_play", "note"} <= set(pair)
    assert {"venue", "team", "name", "unit", "ask", "cents", "contracts", "on_offer", "cost", "fee", "if_wins"} <= set(pair["legs"][0])
    assert got["fees_read"] == xvenue.FEES_READ and got["read_at"] == NOW
    assert got["state"] == STATE and got["needs_state"] is False and got["ran"] is True
    assert got["unavailable"] == [] and got["state_notes"] == [] and got["message"] is None
    assert got["polymarket_us_games"] == 19 and "polymarket_games" not in got


# --- where the person is ---------------------------------------------------------------------

def test_in_a_state_where_a_venue_is_restricted_nothing_is_read_and_it_says_which_and_why():
    for st in ("MA", "MI", "NV", "WA"):
        v = arb_world()
        got = scan(v, state=st)
        assert v.requests == [], f"{st}: the scan made a request"
        assert got.ran is False and got.pairs == [] and got.read_anything is False
        d = got.as_dict()
        assert [u["venue"] for u in d["unavailable"]] == ["kalshi", "polymarket_us"], st
        assert all(u["kind"] == "restricted" and u["state"] == st for u in d["unavailable"])
        for u in d["unavailable"]:
            assert u["sources"] and all(s["name"] and s["date"] and s["url"].startswith("https://") for s in u["sources"])
        name = catalog.STATE_NAMES[st]
        assert d["pairs"] == [] and d["playable"] == 0 and d["message"].endswith("Live pairs are hidden there.") \
            or d["message"].endswith("so live pairs are hidden there.")
        assert f"sports contracts are not open in {name}" in d["message"] and "Fox Sports, Oct 5 2026" in d["message"]
    assert "CBS Sports, Oct 8 2026" in scan(Venues(), state="NV").message
    assert "CBS Sports" not in scan(Venues(), state="MI").message


def test_the_sentence_for_one_venue_that_is_closed_names_that_venue_and_its_source(monkeypatch):
    """Polymarket US alone, in a state where Kalshi is open (the table is edited by hand to say so)."""
    row = catalog.StateStatus("restricted", ("Fox Sports",))
    monkeypatch.setitem(catalog.STATE_STATUS["polymarket_us"], "NJ", row)
    v = arb_world()
    got = scan(v, state="NJ")
    assert v.requests == [] and got.ran is False
    assert got.message == ("Polymarket US's sports contracts are not open in New Jersey (Fox Sports, Oct 5 2026), "
                           "so live pairs are hidden there.")
    assert [u["venue"] for u in got.unavailable] == ["polymarket_us"]
    monkeypatch.undo()
    monkeypatch.setitem(catalog.STATE_STATUS["kalshi"], "NJ", row)
    got = scan(arb_world(), state="NJ")
    assert got.message.startswith("Kalshi's sports contracts are not open in New Jersey (Fox Sports, Oct 5 2026)")
    assert [u["venue"] for u in got.unavailable] == ["kalshi"]


def test_no_state_runs_the_scan_and_shows_no_pairs_and_says_to_pick_one():
    v = arb_world()
    got = scan(v, state=None)
    assert v.requests, "the venues are read"
    assert got.ran is True and got.needs_state is True and got.pairs == [] and got.read_anything
    assert got.message == "Pick your state to see pairs you can place."
    d = got.as_dict()
    assert d["pairs"] == [] and d["playable"] == 0 and d["needs_state"] is True and d["state"] is None
    assert d["matched"] == 19 and d["kalshi_games"] == 21, "what was checked is still counted"
    assert "pick your state to see pairs you can place" in got.source() and "playable" not in got.source()
    # With a state the same recording has the pair.
    assert scan(arb_world(), state=STATE).pairs


def test_a_state_that_is_open_shows_pairs_with_no_note_and_a_contested_one_says_so_in_one_line():
    for st in ("PA", "NJ", "FL", "CO"):
        got = scan(arb_world(), state=st)
        assert got.pairs and got.notes == [] and got.unavailable == [] and got.message == "", st
    for st in ("AZ", "IL", "MD", "NY", "OH"):
        got = scan(arb_world(), state=st)
        assert got.pairs and got.ran, st
        assert got.notes == [f"Prediction markets are being challenged in court in {catalog.STATE_NAMES[st]} "
                             f"(Fox Sports, Oct 5 2026). Kalshi and Polymarket US decide at sign-up whether you can "
                             f"trade there."], st
    assert json.loads(json.dumps(scan(arb_world(), state="OH").as_dict()))["state_notes"]


def test_a_state_can_be_typed_in_any_case_and_a_non_state_is_refused():
    assert scan(arb_world(), state="pa").state == "PA"
    assert scan(Venues(), state="mi").ran is False
    for bad in ("ZZ", "Pennsylvania", "P", "12"):
        with pytest.raises(ValueError):
            scan(Venues(), state=bad)


def test_a_state_a_venue_hides_it_in_is_never_shown_a_pair_whatever_the_table_holds():
    """Every state either venue's table row restricts, and the state-less case, against a
    recording with a real arbitrage in it: none lists a pair, and the restricted ones
    never touch the network."""
    restricted = set()
    for key in xvenue.LIVE_VENUES:
        restricted |= set(catalog.VENUES[key].excluded)
    assert restricted == {"MA", "MI", "NV", "WA"}
    for st in sorted(restricted):
        v = arb_world()
        assert scan(v, state=st).pairs == [] and v.requests == [], st
    assert scan(arb_world(), state=None).pairs == []
    # The other states, where both venues are open, do list it.
    for st in sorted(set(catalog.STATE_NAMES) - restricted):
        assert len(scan(arb_world(), state=st).pairs) == 1, st


# --- the command line: `board` and `board --live` -----------------------------------------

from overlay_engine import cli, pubfeed  # noqa: E402


def _board(monkeypatch, capsys, v, *argv):
    monkeypatch.setattr(pubfeed, "urllib_fetcher", v)
    code = cli.main(["board", *argv])
    return code, capsys.readouterr().out


def test_board_without_live_never_touches_a_network(monkeypatch, capsys):
    """The window passes --live only while its switch is on. Without it the
    board is the demonstration market and nothing here may open a connection."""
    import socket
    touched = []

    def refuse(*a, **k):
        touched.append(a)
        raise AssertionError("the board touched the network without --live")
    monkeypatch.setattr(pubfeed, "urllib_fetcher", refuse)
    monkeypatch.setattr(socket.socket, "connect", refuse)
    monkeypatch.setattr(socket, "create_connection", refuse)
    for argv in (["board", "--json"], ["board"], ["board", "--bankroll", "5000", "--min-margin", "0"],
                 ["board", "--state", "PA"], ["board", "--state", "MI", "--json"]):
        code = cli.main(argv)
        out = capsys.readouterr().out
        assert touched == [], f"{argv} touched the network without --live"
        assert code == 0 and "DEMONSTRATION" in out.upper()


def test_board_live_json_says_what_it_read_and_that_nothing_pays(monkeypatch, capsys):
    v = Venues()
    code, out = _board(monkeypatch, capsys, v, "--live", "--json", "--state", "PA")
    data = json.loads(out)
    assert code == 0 and data["live"] is True and data["command"] == "board"
    assert data["source"].startswith("LIVE") and data["source"].endswith("0 playable")
    assert data["rows"] == [], "rows is the sportsbook board; live pairs are under cross_venue"
    xv = data["cross_venue"]
    assert xv["pairs"] == [] and xv["playable"] == 0 and xv["matched"] == 19 and xv["errors"] == []
    assert xv["read_anything"] is True and xv["fees_read"] == xvenue.FEES_READ and xv["state"] == "PA"
    assert v.requests, "--live reads the venues"


def test_board_live_in_a_restricted_state_reads_nothing_and_says_why(monkeypatch, capsys):
    v = arb_world()
    code, out = _board(monkeypatch, capsys, v, "--live", "--json", "--state", "mi")
    data = json.loads(out)
    xv = data["cross_venue"]
    assert code == 0 and v.requests == []
    assert xv["ran"] is False and xv["pairs"] == [] and xv["playable"] == 0
    assert [u["venue"] for u in xv["unavailable"]] == ["kalshi", "polymarket_us"] and xv["state"] == "MI"
    assert xv["message"] == ("Kalshi's and Polymarket US's sports contracts are not open in Michigan "
                             "(Fox Sports, Oct 5 2026), so live pairs are hidden there.")
    assert data["source"].startswith("NOT READ") and data["markets_scanned"] == 0
    code, out = _board(monkeypatch, capsys, v, "--live", "--state", "NV")
    assert code == 0 and v.requests == []
    assert "not open in Nevada" in out and "CBS Sports, Oct 8 2026" in out and "Nothing was read" in out
    assert "No pair pays" not in out


def test_board_live_without_a_state_reads_and_lists_no_pair(monkeypatch, capsys):
    v = arb_world()
    code, out = _board(monkeypatch, capsys, v, "--live", "--json")
    xv = json.loads(out)["cross_venue"]
    assert code == 0 and v.requests
    assert xv["needs_state"] is True and xv["pairs"] == [] and xv["playable"] == 0
    assert xv["message"] == "Pick your state to see pairs you can place." and xv["matched"] == 19
    code, out = _board(monkeypatch, capsys, v, "--live")
    assert code == 0 and "Pick your state to see pairs you can place." in out and "--state" in out
    assert "locked" not in out and "No pair pays" not in out


def test_board_live_refuses_a_state_that_is_not_one(monkeypatch, capsys):
    v = Venues()
    monkeypatch.setattr(pubfeed, "urllib_fetcher", v)
    with pytest.raises(SystemExit):
        cli.main(["board", "--live", "--state", "ZZ"])
    capsys.readouterr()
    assert v.requests == []
    code = cli.main(["board", "--live", "--json", "--state", "Pennsylvania"])
    out = capsys.readouterr().out
    assert code != 0 and "is not a state" in out and "two letters" in out and v.requests == []


def test_board_live_lists_a_pair_with_the_size_on_offer(monkeypatch, capsys):
    code, out = _board(monkeypatch, capsys, arb_world(), "--live", "--json", "--bankroll", "1000", "--state", "PA")
    data = json.loads(out)
    [pair] = data["cross_venue"]["pairs"]
    assert code == 0 and data["source"].endswith("1 playable")
    assert [leg["on_offer"] for leg in pair["legs"]] == [500, 552547]
    assert pair["contracts"] == 500 and pair["profit"] == 29.38 and pair["limited_by"] == "kalshi"
    assert pair["legs"][0]["unit"] == "contracts" and pair["legs"][1]["unit"] == "contracts"
    assert pair["legs"][1]["venue"] == "polymarket_us"
    assert "postponed" in pair["note"]


def test_board_live_human_output_says_so_plainly_when_nothing_pays(monkeypatch, capsys):
    code, out = _board(monkeypatch, capsys, Venues(), "--live", "--state", "PA")
    assert code == 0
    assert "No pair pays right now at the size on offer." in out
    assert "19 games are listed on both venues" in out
    assert "guaranteed" not in out.lower() and "either way" not in out.lower()


def test_board_live_human_output_for_a_pair_keeps_its_promises(monkeypatch, capsys):
    code, out = _board(monkeypatch, capsys, arb_world(), "--live", "--state", "PA")
    assert code == 0
    assert "locked if both bets are accepted and stand" in out
    assert "Check the amount on offer before you bet." in out
    assert "500 contracts of 500 on offer" in out and "500 contracts of 552,547 on offer" in out
    assert "sized by kalshi" in out and "$4.47 fee" in out and "$6.15 fee" in out
    assert re.search(r"Polymarket US +Houston Texans to win at 77\.0c: 500 contracts of 552,547 on offer", out), (
        "the leg is labelled with the venue's name, not its catalog key")
    assert re.search(r"Kalshi +Tennessee Titans to win at 15\.0c", out) and "Polymarket_" not in out
    for word in ("guaranteed", "risk-free", "risk free", "either way"):
        assert word not in out.lower(), word


def test_board_live_in_a_contested_state_prints_its_one_line(monkeypatch, capsys):
    code, out = _board(monkeypatch, capsys, arb_world(), "--live", "--state", "OH")
    assert code == 0 and out.count("Prediction markets are being challenged in court in Ohio") == 1
    assert "(Fox Sports, Oct 5 2026)" in out and "locked if both bets are accepted and stand" in out


def test_board_live_that_could_not_read_either_venue_says_so_and_exits_nonzero(monkeypatch, capsys):
    v = Venues()
    v.fail["api.elections.kalshi.com"] = OSError("offline")
    v.fail["gateway.polymarket.us"] = OSError("offline")
    code, out = _board(monkeypatch, capsys, v, "--live", "--json", "--state", "PA")
    assert code == 1 and json.loads(out)["cross_venue"]["read_anything"] is False
    v.requests.clear()
    code, out = _board(monkeypatch, capsys, v, "--live", "--state", "PA")
    assert code == 1 and "could not be read from either venue" in out
    assert "No pair pays" not in out, "not reading the venues is not the same as nothing paying"


def test_board_live_hide_under_is_a_percentage(monkeypatch, capsys):
    _, out = _board(monkeypatch, capsys, arb_world(), "--live", "--json", "--min-margin", "1", "--state", "PA")
    assert len(json.loads(out)["cross_venue"]["pairs"]) == 1          # 7.6% clears 1%
    _, out = _board(monkeypatch, capsys, arb_world(), "--live", "--json", "--min-margin", "20", "--state", "PA")
    assert json.loads(out)["cross_venue"]["pairs"] == []
