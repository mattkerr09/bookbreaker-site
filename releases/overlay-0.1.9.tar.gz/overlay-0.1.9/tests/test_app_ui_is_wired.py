"""Every control in the window reaches something that exists.

This test exists because of the data plate that drew nothing. Five of its six
CSS classes did not exist, the build went green, and the figure gate could not
tell an invisible plate from a correct one — because geometry lives in a
`style` attribute the gate deliberately strips. Wrong and correct looked
identical in the region the checker was told to ignore.

The window has the same shape of hole. `cargo test` proves the shell spawns the
engine; the Python suite proves the engine's arithmetic. **Nothing checked that
a tab points at a panel that exists, or that the JavaScript reads an input the
HTML actually contains.** A typo in an element id would ship green: the tab
would highlight, the button would run, and the panel would sit empty.

None of this needs a GUI. The wiring is static and so is the check.
"""

from __future__ import annotations

import re
from pathlib import Path

UI = Path(__file__).resolve().parent.parent / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
RUST = (UI / "src-tauri" / "src" / "main.rs").read_text()


def _all(pattern: str, text: str) -> set[str]:
    return set(re.findall(pattern, text))


TABS = _all(r'data-panel="([a-z-]+)"', HTML)
PANELS = _all(r'id="panel-([a-z-]+)"', HTML)
#: The panel keys — what a button says it runs, and what the renderer map is
#: keyed by.
RUNS = _all(r'data-run="([a-z-]+)"', HTML)

#: The ENGINE commands those panels actually invoke: the first string in each
#: argv builder. These were the same set until a panel called `results` began
#: running `performance`, at which point comparing panel keys against the
#: Rust allow-list compared two different things and failed on a correct
#: wiring. The allow-list guards commands, so commands are what it must be
#: checked against.
INVOKES = {m.group(1) for m in re.finditer(
    r'^\s*[a-z-]+:\s*\(\)\s*=>\s*\[\s*"([a-z-]+)"', JS, re.M)}
ALLOWED = set(re.search(r'const ALLOWED: \[&str; \d+\] = \[([^\]]+)\]',
                        RUST).group(1).replace('"', '').replace(' ', '').split(','))


def test_there_is_at_least_one_of_everything():
    """A wiring test over empty sets passes trivially. That failure mode has
    appeared four times today; it does not get a fifth."""
    assert TABS and PANELS and RUNS and ALLOWED


def test_every_tab_points_at_a_panel_that_exists():
    assert TABS <= PANELS, f"tabs with no panel: {sorted(TABS - PANELS)}"


def test_every_panel_is_reachable_from_a_tab():
    """An unreachable panel is dead weight in the bundle and a half-finished
    feature nobody can find."""
    assert PANELS <= TABS, f"panels with no tab: {sorted(PANELS - TABS)}"


def test_every_run_button_lives_in_a_panel_that_exists():
    """Checked by position in the markup, not by name.

    This used to assert that each button's key matched a panel id, which was
    a stand-in for the real question and stopped being true the moment one
    panel held more than one action: Results gained Read slip, Save bet and
    Import beside Show. The question is whether the button can be reached,
    and a button is reachable when it sits inside a panel section.
    """
    orphans = []
    for m in re.finditer(r'data-run="([a-z-]+)"', HTML):
        before = HTML[:m.start()]
        opened = before.rfind('<section class="panel')
        closed = before.rfind("</section>")
        if opened < 0 or closed > opened:
            orphans.append(m.group(1))
    assert not orphans, f"buttons outside any panel: {orphans}"


def test_every_run_button_has_an_argument_builder():
    """The builder turns the panel's inputs into an engine command. Without one
    the button does nothing and the panel stays empty."""
    for kind in sorted(RUNS):
        assert re.search(rf"\b{kind}: \(\) =>", JS), f"no builder for {kind}"


def test_every_run_button_has_a_renderer():
    """`showDevig`, `showArb` and friends. A missing one throws inside the
    click handler, which surfaces as a button that appears to do nothing."""
    shown = {name.lower() for name in re.findall(r"function show([A-Za-z]+)", JS)}
    for kind in sorted(RUNS):
        assert kind in shown, f"no show{kind.title()} renderer"


def test_every_renderer_is_dispatched():
    """A renderer that exists but is not in the dispatch map is the same
    failure wearing a different hat."""
    dispatch = re.search(r"\(\{([^}]*)\}\)\[kind\]", JS, re.S).group(1)
    for kind in sorted(RUNS):
        assert re.search(rf"\b{kind}:", dispatch), f"{kind} not dispatched"


def test_every_command_the_window_runs_is_allowed_by_the_shell():
    """The Rust side refuses anything not on its list, so a panel calling an
    unlisted command fails at the boundary rather than in the window."""
    assert INVOKES, "no argv builders found — the extractor has drifted"
    assert INVOKES <= ALLOWED, (
        f"not allowed by the shell: {sorted(INVOKES - ALLOWED)}")


def test_the_shell_allows_nothing_the_window_cannot_reach():
    """The allow-list is an attack surface. Anything on it that no panel uses
    is a command a compromised frontend could run for free."""
    assert ALLOWED <= INVOKES, (
        f"allowed but unreachable: {sorted(ALLOWED - INVOKES)}")


def test_every_element_the_javascript_reads_exists_in_the_html():
    """The typo this whole file is about. `val("f-age")` against an input with
    id `f_age` returns undefined, the engine gets a malformed argument, and the
    panel shows an error nobody can trace back to a hyphen."""
    ids = _all(r'id="([^"]+)"', HTML)
    read = (_all(r'val\("([^"]+)"\)', JS)
            | _all(r'getElementById\("([^"]+)"\)', JS))
    missing = read - ids
    assert not missing, f"JavaScript reads ids the HTML does not define: {sorted(missing)}"


def test_every_input_in_a_panel_is_read_by_something():
    """An input nobody reads is a control that silently does nothing when the
    user changes it."""
    ids = _all(r'<input id="([^"]+)"', HTML)
    read = (_all(r'val\("([^"]+)"\)', JS)
            | _all(r'getElementById\("([^"]+)"\)', JS))
    assert ids <= read, f"inputs nothing reads: {sorted(ids - read)}"


def test_the_window_follows_the_system_theme():
    """It shipped from 0.1.0 to 0.1.2 pinned to `data-theme="light"`.

    The dark palette was written, maintained and restyled across three
    releases and never once applied: the attribute on `<html>` beat the media
    query every time. Anyone running macOS in dark mode opened a blazing white
    window, and nothing in the suite could tell, because every test read the
    CSS rather than the computed result.
    """
    assert 'data-theme=' not in HTML, (
        "the window pins its own theme; let prefers-color-scheme decide")


def test_a_dark_palette_exists_for_it_to_follow():
    """Removing the attribute only helps if there is something to fall back
    to — the paired half of the bug above."""
    css = (UI / "src" / "app.css").read_text()
    assert "prefers-color-scheme:dark" in css.replace(" ", "")


def test_closing_line_value_is_rendered_when_it_exists():
    """CLV is the one measure of a bet that does not need the result, and the
    number a serious bettor checks first. It is computed by the engine and was
    reaching the window with nothing to draw it."""
    assert "function clvBlock" in JS
    assert "clvBlock(out)" in JS, "defined but never called"
    for field in ("mean_clv", "beat_rate", "stdev"):
        assert field in JS, f"CLV block never reads {field}"


def test_the_results_panel_explains_an_ungraded_ledger():
    """Bets with no closing line yet are the normal state of a new ledger.
    Showing nothing there reads as 'this tool has no CLV', when the truth is
    'nothing has been graded yet' — and the fix is two commands."""
    assert "waiting on a closing" in JS
    assert "overlay grade" in JS


#: The shell commands the window may call, from `generate_handler![...]`.
HANDLERS = set(re.findall(r"\b([a-z_]+)\b", re.search(
    r"generate_handler!\[([^\]]*)\]", RUST).group(1)))


def test_every_shell_command_the_window_calls_is_registered():
    """An invoke of a command the shell never registered fails at the click,
    as a rejected promise, which reads as a button that does nothing. Check
    for updates added three commands beside `engine`; a typo in any of them
    would ship green without this."""
    called = (_all(r'\binvoke\("([a-z_]+)"', JS)
              | _all(r'\bcall\("([a-z_]+)"\)', JS))
    assert {"engine", "check_update", "install_update", "update_progress"} <= called
    assert called <= HANDLERS, f"not registered by the shell: {sorted(called - HANDLERS)}"
    for name in HANDLERS:
        assert re.search(rf"#\[tauri::command\]\s*(async\s+)?fn {name}\(", RUST), (
            f"{name} is registered but is not a command")


def test_the_check_for_updates_button_is_wired():
    """The button exists, sits on the version line, says what it does, and
    its click runs checkForUpdates."""
    button = re.search(r'<button[^>]*id="check-updates"[^>]*>([^<]*)</button>', HTML, re.S)
    assert button, "there is no Check for updates button"
    assert button.group(1).strip() == "Check for updates"
    assert 'type="button"' in button.group(0)
    assert ('document.getElementById("check-updates").addEventListener("click", '
            'checkForUpdates);') in JS
    assert re.search(r"^function checkForUpdates\(\) \{", JS, re.M)


def test_every_class_the_update_card_uses_is_styled():
    """Markup with no CSS renders as plain text and every other gate stays
    green. The card is built in JavaScript, so its classes are read from there."""
    css = (UI / "src" / "app.css").read_text()
    body = JS[JS.index("function checkForUpdates()"):]
    used = (_all(r'"(upd(?:-[a-z]+)?)"', body) | _all(r'class="(upd)"', HTML))
    assert {"upd", "upd-card", "upd-go", "upd-no"} <= used
    for cls in used:
        # A rule of its own: `.upd-card{` or `.upd-go,` in a selector list.
        # `.upd-card[hidden]` or `.upd:hover` alone does not draw the thing.
        assert re.search(rf"(?:^|[}},\s])\.{cls}\s*[,{{]", css, re.M), (
            f".{cls} has no rule of its own in app.css")


def test_a_result_the_window_cannot_draw_says_so():
    """An exception while drawing a result used to leave "Working…" on screen: an honest "could not show it"
    with a way to report it beats a box that looks like nothing happened. The engine's own error is
    escaped before it is drawn, so a message can never become markup."""
    dispatch = JS[JS.index("if (out.error) return fail(box, esc(out.error));"):]
    assert dispatch.lstrip().split("\n")[1].strip() == "try {", "the result's drawing is not guarded"
    assert "could not show it" in JS and "CONTACT" in JS


# ------------------------------------------------------------ navigation
# 2026-10-07: the tab strip became places on a rail, with sub-tabs in the top
# bar. Matthew's verdict on the tab strip was "confusing af"; the cost of
# fixing it must not be a calculator nobody can find. These pin every panel
# main's window has to a place a person can click.

#: Every panel the eight-tab window had, by the id the engine wiring uses.
OLD_PANELS = {"board", "devig", "arb", "kelly", "parlay", "fill", "welcome", "results"}
SECTION_OF = dict(re.findall(r'<section class="panel[^"]*" id="panel-([a-z-]+)" data-section="([a-z-]+)"', HTML))
RAIL = re.findall(r'<button class="nav[^"]*" data-section="([a-z-]+)" data-panel="([a-z-]+)"', HTML)
SUBNAVS = {sec: set(re.findall(r'data-panel="([a-z-]+)"', body)) for sec, body in
           re.findall(r'<nav class="subnav" data-section="([a-z-]+)"[^>]*>(.*?)</nav>', HTML, re.S)}


def test_every_panel_the_window_has_had_is_still_there():
    """The redesign regrouped the tabs; it deleted none of them."""
    assert OLD_PANELS <= PANELS, f"panels gone: {sorted(OLD_PANELS - PANELS)}"


def test_the_rail_has_six_places_at_most():
    """AVO's whole app is five tools on a rail. A rail that grows back into a
    tab strip is the thing this redesign replaced."""
    places = [sec for sec, _ in RAIL]
    assert places and len(places) == len(set(places)), places
    assert len(places) <= 6, f"{len(places)} places on the rail: {places}"


def test_every_panel_belongs_to_a_place_you_can_reach():
    """Each panel names its place, and is reached either as that place's page
    on the rail or as a sub-tab in that place's own strip."""
    assert set(SECTION_OF) == PANELS, "a panel without data-section, or a parse that drifted"
    rail = dict(RAIL)
    for panel, sec in SECTION_OF.items():
        assert sec in rail, f"{panel} lives in {sec!r}, which is not on the rail"
        assert rail[sec] == panel or panel in SUBNAVS.get(sec, set()), (
            f"{panel} sits in {sec!r} with no sub-tab and is not its rail page")
    for sec, default in RAIL:
        assert SECTION_OF.get(default) == sec, f"the rail's {sec!r} opens {default}, which lives elsewhere"
    for sec, tabs in SUBNAVS.items():
        assert all(SECTION_OF.get(t) == sec for t in tabs), f"{sec!r}'s strip reaches into another place: {tabs}"


def test_showing_a_panel_moves_the_rail_the_strip_and_the_title_with_it():
    """One function decides what is on screen, and it moves every indicator:
    the page, the rail, the sub-tab, which strip is visible, the title."""
    body = JS[JS.index("function show(panel)"):]
    body = body[:body.index("\n}\n")]
    for part in ('".panel"', '".nav"', '".tab"', '".subnav"', '"top-title"', "prime(panel)"):
        assert part in body, f"show() no longer updates {part}"


def test_the_parlay_reads_every_leg_box():
    """The parlay is typed like a betslip, one box per leg, so its inputs have
    no ids for the id check above to see. Every box is read by the builder."""
    assert HTML.count('class="pleg-in"') >= 2
    assert re.search(r'parlay: \(\) => \["parlay", \.\.\.parlayLegs\(\)', JS)
    assert re.search(r'const parlayLegs = \(\) => \[\.\.\.document\.querySelectorAll\("#p-legs \.pleg-in"\)\]', JS)


def test_the_version_line_keeps_its_container():
    """The status bar's version sentence is load-bearing (this app has no
    updater, so a person must be able to read what they run), and other work
    hangs off its container. It stays one span with class "ver"."""
    footer = HTML[HTML.index("<footer>"):HTML.index("</footer>")]
    assert re.search(r'<span class="ver">You are running \d+\.\d+\.\d+\.', footer)


# ------------------------------------------------------------ promos by state
# Offers differ by state (the offers-by-state engine sends each offer's
# `states` and marks the ones not offered where you bet). Main has no My books,
# so Promos carries its own state picker.

def test_promos_ask_for_a_state_before_showing_any_offer():
    """Every state's variant at once is a list of offers you mostly cannot
    take, so with no state chosen the page asks for one and runs nothing."""
    states = re.findall(r'<option value="([A-Z]{2})">', HTML[HTML.index('id="w-state"'):])
    assert len(set(states)) == 51, f"the state picker lists {len(set(states))} of the 50 states and DC"
    body = JS[JS.index("async function runOnce(kind)"):]
    guard = body.index('if (kind === "welcome" && !val("w-state"))')
    assert guard < body.index("const argv = {"), "Promos asks the engine before asking where you bet"
    assert re.search(r'welcome: \(\) => \["welcome",[^\]]*\.\.\.\(val\("w-state"\)', JS, re.S), \
        "the chosen state never reaches the engine"


def test_promos_show_where_an_offer_is_valid_only_when_the_engine_says():
    """`states` may be absent (an engine from before offers-by-state): the card
    then says nothing about states rather than guessing. An offer the engine
    marks ineligible says why, in the engine's words."""
    valid = JS[JS.index("function validIn(o)"):]
    valid = valid[:valid.index("\n}\n")]
    assert 'if (!Array.isArray(o.states) || !o.states.length) return "";' in valid
    assert "Valid in:" in valid
    assert re.search(r"if \(o\.ineligible\) \{", JS) and "cap(o.ineligible)" in JS


def test_an_engine_without_state_support_is_asked_again_and_says_so():
    """Until offers-by-state is merged the engine refuses --state. The page
    asks again without it and says the list is not sorted by state, rather
    than showing an error or pretending it is."""
    assert re.search(r'/unrecognized arguments: --state/\.test\(out\.error\)', JS)
    assert "cannot sort offers by state yet" in JS


# ------------------------------------------------------------ live prices
# 2026-10-08: the Arbitrage page gained a Live prices switch. A live pair fills
# the same console as the demo market, and these pin what it may and may not say.

LIVE_JS = JS[JS.index("function liveOn()"):JS.index("function drawBoard")]


def _live_output() -> dict:
    """What the engine sends for one pair that pays, built the way the engine builds it."""
    import datetime as dt
    from overlay_engine import xvenue

    when = dt.date(2026, 10, 22)
    teams = ("CHI", "PIT")
    k = xvenue.Game("kalshi", teams, when, {"CHI": 0.60, "PIT": 0.40}, "KX", league="nhl",
                    size={t: 9999 for t in teams}, read_at=1.0)
    p = xvenue.Game("polymarket_us", teams, when, {"CHI": 0.50, "PIT": 0.62}, "aec-nhl-chi-pit-2026-10-22", league="nhl",
                    size={t: 9999 for t in teams}, long="CHI", fee_rate=0.0695, read_at=1.0, starts_at=2.0,
                    depth_at={t: 1.0 for t in teams})
    rows = [r for r in xvenue.price_pairs([(k, p)], now=10.0) if r.profit > 0]
    assert rows, "the fixture must contain a pair that pays, or the field check below proves nothing"
    scan = xvenue.Scan(10.0, 1000.0, {"nhl": {"kalshi_games": 1, "polymarket_us_games": 1, "matched": 1}},
                       len(rows), rows, [], state="PA")
    return scan.as_dict()


def test_every_field_a_live_pair_reads_is_one_the_engine_sends():
    """The window reads `r.limited_by` from a pair the engine called `limit_by`
    and draws 'Sized by undefined' on a bet. The engine's real output is the
    list of names; the window's reads must be inside it."""
    sent = _live_output()
    pair = sent["pairs"][0]
    body = JS[JS.index("function livePlay(r)"):JS.index("function liveEmptyHTML()")]
    read_pair = set(re.findall(r"\br\.([a-z_]+)", body))
    read_leg = set(re.findall(r"\bl\.([a-z_]+)", body))
    assert read_pair >= {"league", "game", "margin", "profit", "staked", "age", "legs", "in_play", "fees",
                         "limited_by", "note"}, "the extractor has drifted"
    assert read_pair <= set(pair), f"read but never sent: {sorted(read_pair - set(pair))}"
    assert read_leg >= {"venue", "name", "cents", "cost", "contracts", "fee", "on_offer", "if_wins", "unit"}
    assert read_leg <= set(pair["legs"][0]), f"read but never sent: {sorted(read_leg - set(pair['legs'][0]))}"
    read_scan = set(re.findall(r"\bxv\.([a-z_]+)", LIVE_JS)) | {"pairs"}
    assert read_scan >= {"read_anything", "matched", "errors", "read_at", "kalshi_games", "polymarket_us_games", "fees_read",
                         "unavailable", "needs_state", "message", "state_notes"}
    assert read_scan <= set(sent), f"read but never sent: {sorted(read_scan - set(sent))}"


def test_a_live_board_draws_only_what_the_engine_lists_and_calls_all_of_it_locked():
    """The engine lists pairs that pay, and only those. A live board that kept
    a nearest-miss card, or let a pair be anything but an arb, would be padding
    dressed as a play."""
    assert "PLAYS = xv.pairs.map(livePlay);" in JS
    play = JS[JS.index("function livePlay(r)"):JS.index("function liveEmptyHTML()")]
    assert 'kind: "arb", live: true' in play and '"near"' not in play
    live_branch = JS[JS.index("if (out.cross_venue) {"):JS.index("// Locked-in plays first and largest")]
    assert "xv.pairs" in live_branch and "closest" not in live_branch.lower() and "near" not in live_branch
    assert "Closest, not arbs" in JS, "the demo market's nearest misses are the demo's own"


def test_a_live_board_says_nothing_pays_plainly_and_never_pads():
    empty = JS[JS.index("function liveEmptyHTML()"):JS.index("function consoleHTML(p)")]
    assert "No pair pays right now at the size on offer" in empty
    assert "either way" not in empty.lower(), "'either way' on its own promises more than a locked pair is"
    assert "Live prices could not be read" in empty
    assert "xv.read_anything" in empty, "not reading the venues is not the same as nothing paying"
    assert "xv.pairs" not in empty and "PLAYS" not in empty, "the empty state lists nothing"


def test_a_live_board_in_a_closed_state_says_why_and_that_nothing_was_read():
    """Where either venue's sports contracts are restricted the engine reads nothing and sends the
    sentence, naming the venue, the source and its date. The window prints that sentence as it is
    and does not turn the empty answer into 'could not be read' or 'nothing pays'."""
    empty = JS[JS.index("function liveEmptyHTML()"):JS.index("function consoleHTML(p)")]
    guard = "if (xv.unavailable && xv.unavailable.length) {"
    assert guard in empty, "the closed-state answer is drawn only when the engine says venues are unavailable"
    closed = empty[empty.index(guard):empty.index("if (xv.needs_state)")]
    assert "esc(xv.message)" in closed and "state_name" in closed and "Nothing was read from either venue" in closed
    assert empty.index(guard) < empty.index("if (!xv.read_anything)"), (
        "a state where nothing was read must not be reported as venues that did not answer")
    assert empty.index(guard) < empty.index("No pair pays right now"), "nor as nothing paying"
    lines = LIVE_JS[LIVE_JS.index("function liveLine()"):LIVE_JS.index("function liveHow()")]
    assert "xv.state_notes" in lines, "a contested state's one plain line is drawn above the board"


def test_a_live_board_with_no_state_asks_for_one_at_the_existing_picker_and_lists_nothing():
    """No second picker: the state is Promos' own (kept as bb.state on this Mac), so the board points
    there. The venues were read; no pair is listed until a state is chosen."""
    empty = JS[JS.index("function liveEmptyHTML()"):JS.index("function consoleHTML(p)")]
    asked = empty[empty.index("if (xv.needs_state)"):empty.index("if (!xv.read_anything)")]
    assert "esc(xv.message)" in asked and 'data-panel="welcome"' in asked and "Pick your state" in asked
    assert "stays on this Mac" in asked
    assert HTML.count('id="w-state"') == 1, "one state picker in the window, not two"
    assert JS.count('store.set("bb.state"') == 1 and JS.count('store.get("bb.state"') == 1, "one stored state"


def test_a_board_the_engine_is_holding_back_for_the_state_is_not_headed_no_arbs():
    """'No arbs right now' is a claim that the venues were read and nothing pays. When the engine hid
    pairs for where you are, or read nothing, the list says it is holding them, not that there are none."""
    held = JS[JS.index("function liveHeld()"):JS.index("function drawBoard")]
    assert "needs_state" in held and "unavailable" in held
    assert 'liveHeld() ? "None shown yet" : "No arbs right now"' in JS


def test_the_chosen_state_goes_to_the_engine_only_with_the_live_switch_on():
    board = re.search(r"\n    board: \(\) => \[(.*?)\],\n    results:", JS, re.S).group(1)
    assert '...(liveOn() && val("w-state") ? ["--state", val("w-state")] : [])' in board
    assert board.count('"--state"') == 1 and JS.count('"--state"') == 2, "welcome has its own --state; the board has this one"
    restore = JS[JS.index("(function restoreState()"):JS.index("// Where an offer is valid")]
    assert 'if (liveOn()) primed.delete("board");' in restore, "choosing a state makes the next opening of Arbitrage read again"
    assert 'run("board")' not in restore, "...and reads nothing by itself"


def test_a_live_pair_keeps_every_promise_the_demo_makes():
    assert "Check\", \"the amount on offer before you bet\"" in LIVE_JS
    assert "if both bets are accepted at these prices and stand, after both venues' fees" in LIVE_JS
    assert "of the ${l.on_offer.toLocaleString()} ${unit(l)} on offer at this price" in LIVE_JS
    assert "since the oldest of these prices was read" in LIVE_JS
    assert "guaranteed" not in LIVE_JS.lower(), "locked if both bets are accepted and stand, never guaranteed"
    assert "Locked if both stand" in JS and "Locked if both bets stand" in JS


def test_the_live_switch_is_wired_into_the_arbitrage_page():
    panel = HTML[HTML.index('id="panel-board"'):HTML.index('id="panel-welcome"')]
    assert 'id="b-live"' in panel and 'class="switch"' in panel and "Live prices" in panel
    assert 'id="out-board"' in panel
    assert "starts off" in panel, "the page says it starts off"


def test_every_class_the_live_board_uses_is_styled():
    css = (UI / "src" / "app.css").read_text()
    for rule in (r"\.srcline \.live", r"\.cside \.offer", r"ul\.why", r"\.switch", r"\.sends"):
        assert re.search(rf"(?:^|[}},\s]){rule}\s*[,{{:]", css, re.M), f"{rule} has no rule in app.css"
    for cls in ("live", "offer", "why"):
        assert f'class="{cls}"' in LIVE_JS, f"the live board no longer draws class {cls}: the rule above is dead"


def test_a_slow_engine_call_does_not_freeze_the_window():
    """A command without `async` runs on the main thread, and a Live prices scan
    reads the internet for several seconds. Every other command answers in
    milliseconds and never noticed; this one would freeze the whole window."""
    assert re.search(r"#\[tauri::command\]\s*async fn engine\(", RUST)


def test_flipping_the_switch_while_a_scan_is_out_ends_on_the_right_answer():
    """A live read takes seconds. Turn the switch off in the middle and the
    answer on the page must end up the demo, not the live board that was out."""
    assert "const AGAIN = new Set();" in JS
    assert "if (RUNNING.has(\"board\")) AGAIN.add(\"board\"); else run(\"board\");" in JS
    assert "if (AGAIN.delete(kind)) run(kind);" in JS
