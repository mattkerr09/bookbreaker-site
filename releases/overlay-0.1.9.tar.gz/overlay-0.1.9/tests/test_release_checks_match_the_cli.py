"""release.sh's smoke checks must pass against the engine as it is now.

release.sh installs the wheel in a clean venv and runs `check "<words>" overlay <args>`
for a handful of commands. Those words are copies of CLI output, and nothing ran them
until release time: on 2026-10-09 the arb printout stopped saying "guaranteed" (it now
says the profit is locked only if every bet is accepted and stands), and release.sh
still expected "guaranteed", so the next release would have failed at its last step.
This runs every check against the source engine, so a wording change fails here first.
"""
from __future__ import annotations

import re
import shlex
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
RELEASE = ROOT / "scripts" / "release.sh"


def _checks() -> list[tuple[str, str]]:
    """(expected words, the argument string) for every `check` line. A check whose
    quoted --text runs over several lines is joined until its quotes balance."""
    lines = RELEASE.read_text().splitlines()
    out, i = [], 0
    while i < len(lines):
        m = re.match(r'check "([^"]+)"\s+"\$OVERLAY"\s+(.*)$', lines[i])
        i += 1
        if not m:
            continue
        args = m.group(2)
        while args.count('"') % 2 and i < len(lines):
            args += "\n" + lines[i]
            i += 1
        out.append((m.group(1), args))
    return out


CHECKS = _checks()


def test_release_has_checks():
    assert len(CHECKS) >= 8, "release.sh's check lines were not found; update this parser"


@pytest.mark.parametrize("want,args", CHECKS, ids=[w for w, _ in CHECKS])
def test_each_release_check_passes_on_the_source_engine(want, args, tmp_path):
    argv = shlex.split(args.replace("$RUNDIR", str(tmp_path)).replace("\\$", "$"))
    got = subprocess.run([sys.executable, "-m", "overlay_engine", *argv], cwd=tmp_path,
                         capture_output=True, text=True, timeout=120,
                         env={"PYTHONPATH": str(ROOT / "backend"), "HOME": str(tmp_path),
                              "OVERLAY_HOME": str(tmp_path / ".overlay"), "PATH": "/usr/bin:/bin"})
    assert got.returncode == 0, got.stderr[-500:]
    assert want in got.stdout, f"release.sh expects {want!r} in `overlay {args[:60]}`"
