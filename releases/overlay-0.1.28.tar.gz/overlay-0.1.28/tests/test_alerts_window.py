"""Alerts in the window and the shell: a setting, a banner, and one notification, all after a read the person pressed.

Static, like the other window tests. What these pin is what a screenshot cannot show:

  * alerts are off until the person turns them on, and so is the Mac notification;
  * the setting rides only on a read the person started (Live prices on, or Live sportsbook odds), never on the
    demonstration board, and nothing in the window starts a read for an alert: no timer, no focus handler;
  * the window words no alert and computes nothing: the banner prints the engine's line, and the notification is
    that same line, handed to the shell once per read and not again when the board is re-drawn;
  * the shell's notify command takes only text and posts it as Bookbreaker (the system notification center, not
    osascript, so it never shows as Script Editor). The text is the notification's body through a typed setter, so a
    quote or a backslash in it is just characters; the Rust tests read the body back, these hold the shape of the
    code that makes the proof apply;
  * macOS is asked for permission when the person turns the switch on, never at launch, and a refusal is a sentence;
  * the setting says plainly that it alerts only after a refresh you start, and the privacy note says nothing
    leaves the Mac for it.
"""

import json
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()
RUST = (UI / "src-tauri" / "src" / "main.rs").read_text()


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


def _box() -> str:
    return HTML[HTML.index('<details class="alerts"'):HTML.index("</details>", HTML.index('<details class="alerts"'))]


# ------------------------------------------------------------ the setting, on the Arbitrage page

def test_the_setting_has_every_choice_the_person_was_promised():
    box = _box()
    for ident in ("a-on", "a-ev", "a-arb", "a-scope", "a-k-ev", "a-k-arb", "a-k-middle", "a-mac"):
        assert f'id="{ident}"' in box, ident
    assert "+EV edge at least" in box and "Locked return at least" in box
    assert "Recommended plays only" in box and "All plays" in box
    assert "Mac notification" in box


def test_alerts_and_the_mac_notification_start_off():
    box = _box()
    for ident in ("a-on", "a-mac"):
        tag = re.search(rf'<input id="{ident}"[^>]*>', box).group(0)
        assert "checked" not in tag, f"{ident} must start off"
    assert 'id="alerts-state">off<' in box


def test_the_setting_says_plainly_that_it_alerts_only_after_a_refresh_you_start():
    box = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", _box()))
    assert "Alerts fire only after a refresh you start" in box
    assert "Nothing is read in the background" in box and "spends your Odds API credits" in box
    assert "not in the previous refresh on this Mac" in box
    assert "nothing about an alert is sent anywhere" in box
    for word in ("guaranteed", "risk-free", "either way"):
        assert word not in box.lower()


def test_the_setting_sits_after_the_find_arbs_button_and_has_no_run_button_of_its_own():
    """The page's first data-run button is the one run when the page is first shown."""
    assert HTML.index('data-run="board"') < HTML.index('<details class="alerts"')
    assert "data-run" not in _box()


def test_the_privacy_note_says_alerts_add_nothing_that_leaves_the_mac():
    note = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", HTML[HTML.index("What leaves this Mac"):]))
    assert "Alerts add nothing to this list" in note
    assert "fire only after a refresh you start" in note and "sent nowhere" in note
    assert "Five things reach the internet" in note, "alerts are not a sixth path"


# ------------------------------------------------------------ what rides on which read

def test_the_setting_rides_only_on_a_read_the_person_started():
    argv = _braced(JS, "const argv = {")
    board = argv[argv.index("    board: () =>"):argv.index("    results: () =>")]
    odds = argv[argv.index("    oddsboard: () =>"):argv.index("    oddsestimate: () =>")]
    assert "...(liveOn() ? alertFlags() : [])" in board, "Live prices off is the demonstration board: it never alerts"
    assert "...alertFlags()" in odds
    assert argv.count("alertFlags()") == 2, "no other action carries the setting"
    flags = _braced(JS, "function alertFlags()")
    assert "alertsOn()" in flags and "--alerts=" in flags
    assert "function alertFlags() { return alertsOn() ?" in JS, "off means no flag at all"


def test_the_flag_is_one_token_so_a_setting_starting_with_a_brace_is_a_value():
    assert "`--alerts=${JSON.stringify(alertSetting())}`" in JS


def test_the_setting_is_sent_as_typed_and_the_window_does_arithmetic_on_none_of_it():
    setting = _braced(JS, "function alertSetting()")
    assert 'val("a-ev")' in setting and 'val("a-arb")' in setting
    for reach in ("parseFloat", "Number(", "parseInt", "Math.", "toFixed", " * ", " / ", " >= ", " <= "):
        assert reach not in setting, reach
    for fn in ("alertBanner", "announce"):
        body = _braced(JS, f"function {fn}(")
        for reach in ("parseFloat", "Number(", "Math.", "toFixed", " * ", " / "):
            assert reach not in body, f"{fn}: {reach}"


def test_the_setting_is_kept_in_the_windows_own_storage_under_one_key():
    assert re.findall(r'store\.(?:get|set)\("(bb\.alerts)"', JS) == ["bb.alerts", "bb.alerts"]
    restore = _braced(JS, "(function restoreAlerts()")
    assert "ALERT_FIELDS" in restore and "fetch" not in restore


def test_nothing_in_the_window_reads_for_an_alert_on_a_timer_or_a_focus():
    fn = _braced(JS, "(function restoreAlerts()") + _braced(JS, "function alertBanner(") + _braced(JS, "function announce(")
    for reach in ("setInterval", "setTimeout", "visibilitychange", "focus", 'run("', "run(", "invoke(\"engine\""):
        assert reach not in fn, reach


# ------------------------------------------------------------ the line is the engine's, and it is posted once

def test_the_banner_prints_the_engines_line_and_marks_come_from_the_engine():
    banner = _braced(JS, "function alertBanner(")
    for field in ("a.message", "a.note", "a.when", "a.status", "a.enabled"):
        assert field in banner, field
    assert "esc(a.message)" in banner and "esc(a.status)" in banner
    assert "const alertOf = (r) => ({ alert: r.alert === true });" in JS
    assert JS.count("...alertOf(r)") == 2, "an arb and a live pair carry the mark; nothing sets it in the window"
    assert JS.count("alert:") == 1, "only the engine's mark is read; the window never sets one"


def test_the_notification_is_the_engines_line_asked_for_only_by_a_person_who_turned_it_on():
    body = _braced(JS, "function announce(")
    assert JS.count('invoke("notify"') == 1 and 'invoke("notify", { text: a.message })' in body
    assert 'document.getElementById("a-mac").checked' in body
    assert "!a.message" in body, "no line, no notification"
    assert body.index("a-mac") < body.index('invoke("notify"')


def test_the_notification_is_asked_for_once_per_read_and_not_when_the_board_is_redrawn():
    callers = [m.start() for m in re.finditer(r"\bannounce\(", JS)]
    assert len(callers) == 3, "the definition and the two reads"
    assert "announce(BOARD.alerts);" in _braced(JS, "function showBoard(")
    assert "announce(BOARD.alerts);" in _braced(JS, "function showOddsboard(")
    for redraw in ("function setPreset(", "function refreshAlertPost("):
        assert "announce(" not in _braced(JS, redraw), redraw


def test_a_play_the_engine_marked_is_marked_on_the_list_and_the_console():
    assert "alert-tag" in _braced(JS, "function listCard(") and "c-pill alert" in JS
    assert "p.alert" in _braced(JS, "function listCard(")


# ------------------------------------------------------------ every field read is one the engine sends

def _block(monkeypatch, tmp_path):
    """The `alerts` block of a real second read, through the command line as the window calls it."""
    import contextlib
    import io
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from test_xvenue import Venues, arb_world

    from overlay_engine import cli, pubfeed
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    setting = json.dumps({"min_ev": 3, "min_arb": 1, "kinds": ["arb"], "recommended_only": False})
    out = io.StringIO()
    for world in (Venues(), arb_world()):
        monkeypatch.setattr(pubfeed, "urllib_fetcher", world)
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            assert cli.main(["board", "--live", "--state", "PA", "--alerts", setting, "--json"]) == 0
    return json.loads(out.getvalue())["alerts"]


def test_every_field_the_banner_reads_is_one_the_engine_sends(monkeypatch, tmp_path):
    block = _block(monkeypatch, tmp_path)
    banner = _braced(JS, "function alertBanner(")
    read = set(re.findall(r"\ba\.([a-z_]+)", banner)) - {"post"}
    assert read >= {"message", "note", "when", "status", "enabled"}
    assert read <= set(block), f"read but never sent: {sorted(read - set(block))}"
    assert block["message"] and block["when"].startswith("Alerts fire only after a refresh you start")


def test_every_class_the_alerts_use_is_styled():
    used = {"alerts", "alerts-state", "alerts-body", "alerts-grid", "alerts-kinds", "alertbar", "alert-tag", "alert-post"}
    for cls in used:
        assert re.search(rf"\.{re.escape(cls)}\b[^{{}}]*\{{", CSS), f".{cls} has no rule in app.css"
    assert re.search(r"\.c-head \.c-pill\.alert\{", CSS)
    drawn = _box() + JS
    for cls in used:
        assert cls in drawn, f".{cls} is styled and never drawn"


def test_the_alert_styles_use_the_windows_tokens_and_none_of_their_own():
    section = CSS[CSS.index("/* ------------------------------------------------------------ alerts"):]
    assert not re.search(r"#[0-9a-fA-F]{3,8}\b", section), "a hex colour in the alerts section"
    assert not re.search(r"rgba?\(", section)


# ------------------------------------------------------------ the shell

def test_notify_is_registered_and_takes_only_text():
    assert re.search(r"#\[tauri::command\]\s*async fn notify\(text: String\) -> serde_json::Value", RUST)
    assert "notify," in re.search(r"generate_handler!\[([^\]]*)\]", RUST).group(1)
    assert 'invoke("notify", { text: a.message })' in JS


def test_the_shell_posts_the_notification_itself_and_runs_no_program():
    section = RUST[RUST.index("// Alerts: one macOS notification"):RUST.index("// Updates: the one request")]
    code = "\n".join(l for l in section.splitlines() if not l.lstrip().startswith("//"))
    for gone in ("osascript", "OSASCRIPT", "NOTIFY_SCRIPT", "Command::new", "Command::", "do shell script", "sh -c",
                 "Script Editor"):
        assert gone not in code, f"{gone} is back in the notification code"
    assert "UNUserNotificationCenter::currentNotificationCenter()" in code
    content = _braced(code, "pub fn content_for(")
    assert "setBody(&NSString::from_str(text))" in content and "setTitle(&NSString::from_str(NOTIFY_TITLE))" in content
    assert "format!" not in content, "the text is never formatted into anything"
    post = _braced(code, "pub fn post(")
    assert "content_for(text)" in post and post.index("allow()?") < post.index("addNotificationRequest")
    command = _braced(code, "async fn notify(")
    assert "format!" not in command and "Command" not in command and ".arg(" not in command


def test_the_notification_plugin_is_not_what_posts_it_and_the_shell_asks_for_no_new_power():
    cargo = (UI / "src-tauri" / "Cargo.toml").read_text()
    assert not re.search(r"^tauri-plugin-notification\s*=", cargo, re.M) and "tauri_plugin_notification" not in RUST
    assert "notification" not in json.dumps(json.loads((UI / "src-tauri" / "tauri.conf.json").read_text())["plugins"])
    assert not (UI / "src-tauri" / "capabilities").exists(), "a capability file would widen what the window may call"
    assert 'cfg(target_os = "macos")' in cargo and "objc2-user-notifications" in cargo


def test_permission_is_asked_when_the_switch_goes_on_and_a_refusal_is_a_sentence():
    assert re.search(r"#\[tauri::command\]\s*async fn notify_allow\(\) -> serde_json::Value", RUST), "takes no input"
    assert "notify_allow," in re.search(r"generate_handler!\[([^\]]*)\]", RUST).group(1)
    assert JS.count('invoke("notify_allow"') == 1
    switch = JS[JS.index('document.getElementById("a-mac").addEventListener("change"'):]
    switch = _braced(switch, "addEventListener(")
    assert 'invoke("notify_allow")' in switch and "checked" in switch and "out.error" in switch
    assert switch.index("checked") < switch.index('invoke("notify_allow")'), "off must not ask"
    assert JS.count('invoke("notify_allow"') == 1 and 'invoke("notify_allow"' not in _braced(JS, "(function restoreAlerts()"), (
        "restoring the saved setting at launch must not ask macOS")
    assert 'id="a-mac-say"' in HTML and 'role="status"' in HTML[HTML.index('id="a-mac-say"') - 40:HTML.index('id="a-mac-say"') + 80]
    ask = _braced(RUST, "pub fn allow(")
    assert "Permission::Undecided" in ask and "ask(&center)" in ask
    assert ask.count("NOTIFY_REFUSED") == 2, "both a standing refusal and a refusal at the dialog are said"
    assert "System Settings, Notifications, Bookbreaker" in RUST
    # An installed app only: the center of a bare binary aborts the process, so it is never asked for.
    assert '.ends_with(".app")' in _braced(RUST, "fn center()")


def test_a_notification_shows_while_bookbreaker_is_in_front():
    delegate = RUST[RUST.index("define_class!("):]
    delegate = delegate[:delegate.index("/// The system's notification center")]
    assert "willPresentNotification" in delegate and "UNNotificationPresentationOptions::Banner" in delegate


def test_the_setting_note_says_bookbreaker_posts_it_and_never_names_script_editor():
    note = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", _box()))
    assert "Bookbreaker posts the notification itself" in note and "macOS asks" in note
    assert "Script Editor" not in HTML and "osascript" not in HTML and "Script Editor" not in JS


def test_the_shell_strips_control_characters_and_caps_the_length_before_posting():
    assert re.search(r"const NOTIFY_MAX_CHARS: usize = (\d+);", RUST)
    cap = int(re.search(r"const NOTIFY_MAX_CHARS: usize = (\d+);", RUST).group(1))
    assert 100 <= cap <= 300
    clean = _braced(RUST, "fn notification_text(")
    assert "c.is_control()" in clean and "is_invisible(c)" in clean
    assert "chars().count() > NOTIFY_MAX_CHARS" in clean and ".take(NOTIFY_MAX_CHARS - 1)" in clean
    command = _braced(RUST, "async fn notify(")
    assert command.index("notification_text(&text)") < command.index("notice_post(")
    assert "There was nothing to post." in command


def test_the_shell_has_the_rust_tests_that_prove_the_text_is_never_interpreted():
    for name in ("the_text_reaches_the_notification_body_unchanged_and_is_never_interpreted",
                 "a_notification_loses_its_control_characters_and_is_cut_to_the_cap",
                 "an_empty_notification_is_refused_before_anything_is_run",
                 "a_process_that_is_not_an_installed_app_says_so_and_does_not_ask_macos",
                 "only_an_authorized_status_posts_and_an_unknown_one_never_does",
                 "the_foreground_delegate_registers_and_answers_to_the_center_protocol"):
        assert f"fn {name}()" in RUST, name
    proof = _braced(RUST, "fn the_text_reaches_the_notification_body_unchanged_and_is_never_interpreted(")
    assert "content.body().to_string(), raw" in proof and "content_for(&text)" in proof and "witness" in proof
    assert "do shell script" in proof and '\\"' in proof and "\\\\" in proof, "the proof must carry a quote and a backslash"


def test_the_shell_starts_no_timer_and_no_reader_for_alerts():
    notify_part = RUST[RUST.index("// Alerts: one macOS notification"):RUST.index("// Updates: the one request")]
    for reach in ("sleep(", "interval(", "spawn", "thread::", "reqwest", "TcpStream", "UpdaterExt", "engine_path"):
        assert reach not in notify_part, reach
