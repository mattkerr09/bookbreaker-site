"""The Odds screen in the window: a grid of prices already on this Mac.

Static, like test_odds_source_window.py: none of it needs a GUI. What these pin is
what a screenshot cannot show:

  * the page fetches nothing and spends nothing. Its one engine call is
    `board --feed oddsapi --screen`, which the engine answers from files; the
    league and bet type switches ask the engine for nothing at all;
  * the window computes nothing here. Every figure, the best price in each row,
    which cells are best and every age is the engine's;
  * every field the page reads is one the engine really sends;
  * a reference book (Pinnacle and its kind) is drawn muted and never marked best.
"""

import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


PANEL = HTML[HTML.index('id="panel-screen"'):HTML.index("</section>", HTML.index('id="panel-screen"'))]
SCREEN_JS = JS[JS.index("const SCREEN = {"):JS.index("// Local and free: whether a key is set")]


# ------------------------------------------------------------ where it lives

def test_the_screen_is_a_page_of_odds_source_with_its_own_tab_and_the_rail_is_unchanged():
    assert re.search(r'<section class="panel" id="panel-screen" data-section="odds">', HTML)
    sub = re.search(r'<nav class="subnav" data-section="odds" hidden>(.*?)</nav>', HTML, re.S).group(1)
    assert re.findall(r'data-panel="([a-z]+)">([^<]+)<', sub) == [("screen", "Odds screen"), ("odds", "Your key")]
    assert len(re.findall(r'<button class="nav[^"]*" data-section=', HTML)) <= 6
    assert re.search(r'<button class="nav" data-section="odds" data-panel="odds"', HTML)


def test_the_key_page_points_at_the_screen_and_the_boards_read_line_does_too():
    assert re.search(r'<button class="go" type="button" data-panel="screen">Open the Odds screen</button>', HTML)
    assert 'data-panel="screen">See every book&rsquo;s price</button>' in _braced(JS, "function oddsLine(")


def test_the_page_says_it_fetches_nothing_and_spends_nothing():
    text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", PANEL))
    assert "Nothing on this page fetches anything or spends a credit" in text
    assert "already on this Mac" in text


# ------------------------------------------------------------ it spends nothing

def test_the_screens_one_engine_call_reads_files_only():
    builder = re.search(r"^\s*screen: \(\) => \[(.*?)\],?$", JS, re.M).group(1)
    # The state, when one is picked, only narrows which books a best price may be at; it reads nothing.
    assert builder == '"board", "--feed", "oddsapi", "--screen", ...stateFlags()'
    for flag in ("--estimate", "--sport", "--region", "--market", "--live", "--bankroll"):
        assert flag not in builder
    assert JS.count('"--feed"') == 4, "the refresh, its cost line, the screen and Low hold: no fifth way to the feed"
    assert JS.count('"--screen"') == 1, "one argv carries the flag"


def test_the_switches_ask_the_engine_for_nothing():
    for picker in ('getElementById("sc-league").addEventListener("change"',
                   'getElementById("sc-market").addEventListener("change"'):
        body = _braced(SCREEN_JS[SCREEN_JS.index(picker):], "=>")
        for call in ("run(", "invoke(", "fetch(", "await"):
            assert call not in body, (picker, call)
    for fn in ("fillScreenPickers", "fillMarketPicker", "drawScreen", "screenTable", "screenCell"):
        body = _braced(SCREEN_JS, f"function {fn}(")
        for call in ("run(", "invoke(", "fetch(", "await"):
            assert call not in body, (fn, call)


def test_the_screen_is_laid_out_again_only_when_it_is_opened_and_never_at_load_or_on_a_timer():
    assert JS.count('run("screen")') == 1
    assert 'if (panel === "screen") run("screen");' in _braced(JS, "function show(")
    assert re.findall(r'^run\("([a-z]+)"\);', JS, re.M) == ["keystatus", "oddsestimate"]
    for timer in ("setInterval", "setTimeout", "requestAnimationFrame"):
        for m in re.finditer(timer + r"\(", JS):
            assert "screen" not in JS[m.start():m.start() + 400].lower(), timer
    assert "visibilitychange" not in JS and '"focus"' not in JS


def test_the_page_runs_its_one_button_when_first_shown_and_that_is_free():
    first = re.search(r'data-run="([a-z-]+)"', PANEL).group(1)
    assert first == "screen"
    assert re.findall(r'data-run="([a-z-]+)"', PANEL) == ["screen"]


def test_the_boards_own_read_fills_the_screen_without_a_second_look():
    assert "if (out.screen) { SCREEN.books = out.books_for || null; setScreen(out.screen); }" in _braced(JS, "function showOddsboard(")


def test_clearing_the_key_clears_the_grid_of_what_it_read():
    clear = _braced(JS, "function showKeyclear(")
    assert "SCREEN.data = null;" in clear and "drawScreen();" in clear
    assert 'run("screen")' not in clear


# ------------------------------------------------------------ the window computes nothing here

def test_no_arithmetic_on_an_engine_figure_in_the_screen():
    for banned in ("Math.", ".toFixed(", ".reduce(", "parseFloat", "Number(", "Math.max", " Math.min"):
        assert banned not in SCREEN_JS, banned
    # The only multiplication is a clock: seconds from the engine turned into the Date the browser wants.
    assert SCREEN_JS.count("* 1000") == 2, "two clock conversions and no other multiplication"
    leaves = re.findall(r"\$\{([^`{}]*)\}", SCREEN_JS)
    assert len(leaves) > 25, "the extractor has drifted"
    for expr in leaves:
        bare = re.sub(r"\"[^\"]*\"|'[^']*'", "''", expr)
        assert not re.search(r"[\w)\]]\s*[*/%]\s*[\w(]|[\w)\]]\s+[+-]\s+[\w(]", bare), f"arithmetic on an engine figure: {expr}"


def test_the_best_price_comes_from_the_engines_flags_not_from_comparing_cells():
    cell = _braced(SCREEN_JS, "function screenCell(")
    assert "c.best" in cell and "b.bettable" in cell
    table = _braced(SCREEN_JS, "function screenTable(")
    assert "r.best" in table
    for compare in (">", "<", "sort(", "max("):
        assert compare not in re.sub(r"=>|</?\w+|\"[^\"]*\"|`[^`]*`", "", cell), compare


def test_the_engines_words_are_drawn_as_text_not_markup():
    block = "".join(_braced(SCREEN_JS, f"function {fn}(") for fn in ("screenCell", "screenTable", "drawScreen"))
    block += _braced(SCREEN_JS, "function fillScreenPickers(") + _braced(SCREEN_JS, "function fillMarketPicker(")
    raw = re.findall(r"\$\{((?:g|b|r|c|s|game|l|m)\.(?:label|name|game|message|note|warning|age_text|league_label|"
                     r"market_label|alias|key))\}", block)
    assert raw == [], f"engine text interpolated without esc(): {raw}"
    for sink in ("document.write", "outerHTML", "insertAdjacentHTML"):
        assert sink not in SCREEN_JS


def test_the_screen_never_says_guaranteed_or_risk_free_or_either_way():
    for text in (SCREEN_JS, PANEL):
        low = text.lower()
        for word in ("guarantee", "risk-free", "risk free", "riskfree", "either way"):
            assert word not in low, word


def test_a_reference_book_is_drawn_muted_and_labelled():
    table = _braced(SCREEN_JS, "function screenTable(")
    assert "bettable ? \"\" : \" ref\"" in table and "<em>reference</em>" in table
    assert 'b.bettable ? "" : " ref"' in _braced(SCREEN_JS, "function screenCell("), "a reference cell is muted too"
    assert "You cannot bet there from the US, so it is never marked best." in table
    for rule in (r"\.sgrid td\.sg-c\.ref", r"\.sgrid th\.sg-b\.ref"):
        assert re.search(rule + r"\s*\{", CSS), rule
    # Best is the only green cell, and a reference cell is never given it.
    best_rule = re.search(r"\.sgrid td\.sg-c\.best\{([^}]*)\}", CSS).group(1)
    assert "var(--profit)" in best_rule


def test_the_time_the_prices_were_read_and_their_age_are_on_the_page():
    draw = _braced(SCREEN_JS, "function drawScreen(")
    assert "clockTime(g.read_at)" in draw and "g.age_text" in draw
    assert "g.warning" in draw
    assert "LAST READ" in draw


def test_an_empty_screen_says_why_and_leads_to_arbitrage_and_a_missing_pair_says_what_reading_costs():
    draw = _braced(SCREEN_JS, "function drawScreen(")
    assert "esc(s.message)" in draw and 'data-panel="board">Open Arbitrage' in draw
    assert "spends credits from your Odds API allowance" in draw
    assert "if (!g)" in draw


# ------------------------------------------------------------ dispatch and styling

def test_the_renderer_is_dispatched_and_exists():
    dispatch = re.search(r"\(\{([^}]*)\}\)\[kind\]", JS, re.S).group(1)
    assert re.search(r"\bscreen: showScreen\b", dispatch)
    assert re.search(r"^function showScreen\(", JS, re.M)


def test_every_class_the_screen_uses_has_a_rule():
    used = {"sgwrap", "sgrid", "sg-game", "sg-side", "sg-best", "sg-b", "sg-c", "sg-at", "sg-first", "best", "ref", "none", "read"}
    for cls in used:
        assert re.search(rf"\.{re.escape(cls)}\b[^{{}}]*\{{", CSS), f".{cls} has no rule in app.css"
        assert re.search(rf'class="[^"]*\b{re.escape(cls)}\b|" {re.escape(cls)}"|\? " {re.escape(cls)}"', SCREEN_JS), (
            f".{cls} is styled and never drawn")


# ------------------------------------------------------------ the window reads only what the engine sends

@pytest.fixture(scope="module")
def sent(tmp_path_factory):
    import os

    import test_oddsapi as to
    import test_parity_grid as tp
    from overlay_engine import cli, oddsapi

    was = os.environ.get("OVERLAY_HOME")
    os.environ["OVERLAY_HOME"] = str(tmp_path_factory.mktemp("home"))
    try:
        oddsapi.refresh(to.est("nfl", markets=tp.ALL), to.KEY, clock=to.Clock(),
                        fetcher=to.FakeApi({"americanfootball_nfl": tp.world()}))
        import contextlib
        import io

        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            assert cli.main(["board", "--feed", "oddsapi", "--screen", "--json"]) == 0
        yield json.loads(out.getvalue())
    finally:
        if was is None:
            os.environ.pop("OVERLAY_HOME", None)
        else:
            os.environ["OVERLAY_HOME"] = was


def _keys(items):
    return set().union(*(set(i) for i in items)) if items else set()


def test_every_field_the_screen_reads_is_one_the_engine_sends(sent):
    s = sent["screen"]
    assert s["has_odds"] is True
    grids = s["grids"]
    games = [g for grid in grids for g in grid["games"]]
    rows = [r for g in games for r in g["rows"]]
    cells = [c for r in rows for c in r["cells"].values()]
    books = [b for grid in grids for b in grid["books"]]
    bests = [r["best"] for r in rows if r["best"]]
    # `message` is sent only when nothing has been read; test_the_empty_answer_has_the_fields_the_window_reads holds it.
    shapes = {"s": set(s) | {"message"}, "g": _keys(grids), "game": _keys(games), "r": _keys(rows), "c": _keys(cells),
              "b": _keys(books), "top": _keys(bests), "l": _keys(s["leagues"]), "m": _keys(s["markets"])}
    block = "".join(_braced(SCREEN_JS, f"function {fn}(") for fn in
                    ("screenCell", "screenTable", "drawScreen", "fillScreenPickers", "fillMarketPicker"))
    block = re.sub(r"\.(?:map|filter|find|some)\((\w+)", r".map(\1", block)
    for var, keys in shapes.items():
        read = set(re.findall(rf"(?<![\w.]){var}\.([a-z_]+)", block))
        read -= {"length", "join", "map", "filter", "find", "some", "push", "bettable_x"}
        assert read <= keys, f"{var}: read but never sent: {sorted(read - keys)}"
    assert {"alias", "label"} <= shapes["l"] and {"key", "label"} <= shapes["m"]
    assert {"league", "market", "league_label", "market_label", "read_at", "age_text", "books", "games",
            "under_way", "warning"} <= shapes["g"]
    assert {"american", "age_text"} <= shapes["c"] and {"key", "name", "bettable"} <= shapes["b"]
    assert {"label", "best", "cells"} <= shapes["r"] and {"game", "starts", "rows"} <= shapes["game"]


def test_the_empty_answer_has_the_fields_the_window_reads(tmp_path, monkeypatch):
    import contextlib
    import io

    from overlay_engine import cli

    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        assert cli.main(["board", "--feed", "oddsapi", "--screen", "--json"]) == 0
    s = json.loads(out.getvalue())["screen"]
    assert s["has_odds"] is False and s["message"] and s["grids"] == []
