"""Measuring the correlation `kelly.simultaneous_scale` has been assuming.

`simultaneous_scale` shrinks stakes when several bets are live at once:

    scale = 1 / sqrt(1 + (n - 1) * rho)

and until now `rho` was 0.15 — a stated prior, labelled as one in that module's
docstring, with nothing anywhere measuring it. That is the single most
load-bearing unmeasured number in the engine. Twelve overs riding one game
script is one undiversified position wearing twelve hats, and sizing each at
its individual optimum is a far larger bet than it looks.

**The estimator matches the consumer's own algebra**, which is why it is this
one and not a pairwise correlation matrix. For a group of `n` bets resolving
together with average pairwise correlation `rho`:

    Var(sum of returns) = n * sigma^2 * (1 + (n - 1) * rho)

Standardise each group's total by what independence would predict, and the
expected square of that quantity is `1 + (n - 1) * rho`. Averaging over groups
gives a method-of-moments estimate:

    rho = sum(z^2 - 1) / sum(n - 1)

The same `1 + (n - 1) * rho` that `simultaneous_scale` divides by. Nothing is
converted between one parameterisation and another, so nothing can be lost in
the conversion.

**A negative estimate is floored at zero, and the floor is reported.** Genuine
negative correlation exists — a hedge is exactly that — but a negative estimate
drawn from noise makes `simultaneous_scale` return *more* than 1.0, which
raises every stake above its independent optimum. Of the two ways to be wrong
here, only one of them can compound into a ruined bankroll.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from .kelly import DEFAULT_CORRELATION, simultaneous_scale

# Groups of two or more bets resolving together. Below this the estimate is a
# rumour: a handful of slates that happened to go the same way is exactly what
# an unlucky fortnight looks like.
MIN_GROUPS = 20

# Bets needed before the per-bet return variance is worth estimating at all.
# Everything downstream is a ratio against this number, so a bad sigma does not
# make the answer noisy — it makes it wrong.
MIN_BETS = 30

# Nothing above this is reported. A measured rho of 1.0 says every bet in the
# group is the same bet, which is possible and is far more often a sign that
# the grouping key is wrong.
MAX_RHO = 0.95

# Below this share of the returns' own scale, the spread is floating-point
# residue rather than variance. An absolute `var <= 0` test does not catch it:
# a hundred identical returns leave a variance around 1e-35, which is positive,
# and dividing by its square root turns rounding noise into a confident rho.
DEGENERATE = 1e-9

#: Groupings derivable from the bet row itself.
SCHEMA_KEYS = ("event", "day", "sport_day")

#: Groupings that need recorded event metadata. These are the ones that
#: actually explain a book of props — twelve overs riding one starting pitcher
#: are one bet, and no amount of staring at `event_id` will say so.
META_KEYS = ("starter", "venue", "weather")

KEYS = SCHEMA_KEYS + META_KEYS

# Share of bet-carrying events that must have the field recorded before a
# grouping on it is reported as measured.
#
# This is the guard the whole feature turns on. Metadata arrives piecemeal, and
# a correlation grouped on a field recorded for a tenth of the book is measured
# over that tenth — a real number about a subsample nobody chose, presented as
# a fact about the whole record. Worse if the missing ones are grouped under a
# blank: every unrecorded event lands in one enormous group, and the lump comes
# back as correlation.
MIN_COVERAGE = 0.5

DAY = 86_400.0


class CorrelationError(ValueError):
    """A correlation that cannot be estimated from what is on hand."""


def _group_key(row: dict, key: str, meta: dict | None = None) -> str | None:
    """The group this bet belongs to, or None when it belongs to none.

    None rather than a blank on purpose. A missing starter is not a starter
    named "", and grouping every unrecorded event together would manufacture
    the largest correlated block in the book out of nothing but absence.
    """
    if key in META_KEYS:
        value = (meta or {}).get(str(row.get("event_id") or ""), {}).get(key)
        if not value:
            return None
        if key == "weather":
            # Raw notes do not group: "wind 18mph" and "wind 19mph" are the
            # same conditions and two different strings, so every event ends up
            # alone and there is nothing left to measure. An unreadable note is
            # excluded rather than collected, for the same reason a missing one
            # is.
            from .weather import bucket

            banded = bucket(str(value))
            return f"weather:{banded}" if banded else None
        return f"{key}:{value}"
    if key == "event":
        return str(row.get("event_id") or "")
    day = int((row.get("placed_at") or 0.0) // DAY)
    if key == "day":
        return str(day)
    return f"{row.get('sport') or ''}:{day}"


def _return_of(row: dict) -> float | None:
    """Profit per unit staked, or None when the bet is not usable.

    Return rather than profit, because a group holding one $500 bet and one $5
    bet is not two equally correlated positions and summing dollars would say
    it was. Standardising by stake is what makes the group total comparable
    across groups of different sizes.

    The single definition on purpose. The pooled variance and the group totals
    have to be on the same scale or every z-score is nonsense, and two call
    sites each dividing by their own idea of a stake is how that stops being
    true without either one looking wrong.
    """
    stake = row.get("stake") or 0.0
    if stake <= 0 or row.get("profit") is None:
        return None
    return row["profit"] / stake


@dataclass(frozen=True)
class CorrelationEstimate:
    """A correlation, and everything needed to distrust it."""

    rho: float
    provenance: str  # "measured" | "prior"
    groups: int = 0
    bets: int = 0
    paired_bets: int = 0
    key: str = "event"
    coverage: float = 1.0
    """Share of usable bets whose event carries the grouping field. Always 1.0
    for groupings derived from the bet row itself; below `MIN_COVERAGE` the
    estimate is refused rather than reported over whatever happens to be
    recorded."""
    raw: float | None = None
    """The estimate before flooring at zero. Reported so a floored result is
    visibly floored rather than looking like a measurement that landed on
    exactly 0.00."""

    @property
    def measured(self) -> bool:
        return self.provenance == "measured"

    @property
    def floored(self) -> bool:
        return self.raw is not None and self.raw < 0.0

    def scale(self, n_bets: int) -> float:
        """The shrink factor this correlation implies for `n` live bets."""
        return simultaneous_scale(n_bets, self.rho)

    def describe(self) -> str:
        if not self.measured and self.key == "weather" and self.groups:
            from .weather import buckets

            return (
                f"rho {self.rho:.3f} (PRIOR \u2014 {self.groups} weather "
                f"buckets occupied, needs {MIN_GROUPS}).\n"
                f"  Weather is banded before grouping, and the banding admits "
                f"only {len(buckets())} buckets in total, so this bar is at the "
                "ceiling of\n  what the grouping can produce. That is a "
                "property of bucketing rather than of your record: coarse "
                "bands make groups\n  large enough to measure and few enough "
                "to fail a count. Group by starter or venue for a correlation "
                "this estimator\n  can actually certify.")
        if not self.measured:
            if self.key in META_KEYS and self.coverage < MIN_COVERAGE:
                return (f"rho {self.rho:.3f} (PRIOR — {self.key} recorded for "
                        f"{self.coverage:.0%} of bets, needs "
                        f"{MIN_COVERAGE:.0%}; a correlation grouped on a field "
                        "this sparse describes whichever events happen to be "
                        "recorded, not your book)")
            return (f"rho {self.rho:.3f} (PRIOR — {self.bets} settled bets, "
                    f"{self.groups} multi-bet groups; needs {MIN_BETS} and "
                    f"{MIN_GROUPS})")
        line = (f"rho {self.rho:.3f} (measured over {self.groups} groups, "
                f"{self.paired_bets} of {self.bets} bets)")
        if self.floored:
            line += (f"\n  raw estimate {self.raw:+.3f}, floored at zero — a "
                     "negative estimate would raise every stake above its\n"
                     "  independent optimum, and noise is the likelier "
                     "explanation than a genuinely hedged book")
        return line


def measure(rows: list[dict], key: str = "event",
            prior: float = DEFAULT_CORRELATION,
            meta: dict | None = None) -> CorrelationEstimate:
    """Average pairwise correlation of bets resolving together.

    Returns the labelled prior rather than raising when there is not enough
    to measure — the caller needs a number either way, and a number that says
    what it is beats an exception that gets caught and replaced by the same
    prior three frames up.
    """
    if key not in KEYS:
        raise CorrelationError(f"unknown grouping key {key!r}; use one of {KEYS}")
    if key in META_KEYS and meta is None:
        raise CorrelationError(
            f"grouping by {key!r} needs recorded event metadata; pass `meta` "
            "or use one of " + str(SCHEMA_KEYS))

    returns: list[float] = []
    groups: dict[str, list[float]] = {}
    grouped_bets = 0
    for row in rows:
        r = _return_of(row)
        if r is None:
            continue
        returns.append(r)
        name = _group_key(row, key, meta)
        if name is None:
            continue  # no recorded value: excluded, never lumped under a blank
        grouped_bets += 1
        groups.setdefault(name, []).append(r)
    n_bets = len(returns)
    paired = {k: v for k, v in groups.items() if len(v) >= 2}
    coverage = grouped_bets / n_bets if n_bets else 0.0

    if key in META_KEYS and coverage < MIN_COVERAGE:
        return CorrelationEstimate(
            rho=prior, provenance="prior", groups=len(paired), bets=n_bets,
            key=key, coverage=coverage)

    if n_bets < MIN_BETS or len(paired) < MIN_GROUPS:
        return CorrelationEstimate(
            rho=prior, provenance="prior", groups=len(paired), bets=n_bets,
            key=key, coverage=coverage)

    mean = sum(returns) / n_bets
    var = sum((r - mean) ** 2 for r in returns) / (n_bets - 1)
    sigma = math.sqrt(var) if var > 0 else 0.0
    if sigma <= DEGENERATE * (1.0 + abs(mean)):
        # Every bet returned the same thing. There is no variance to inflate,
        # so there is no correlation to read off it — not a rho of zero.
        # Measured against the returns' own scale, because identical values do
        # not sum to a variance of exactly zero in floating point and the
        # leftover is enough to divide by.
        return CorrelationEstimate(
            rho=prior, provenance="prior", groups=len(paired), bets=n_bets,
            key=key, coverage=coverage)

    excess = 0.0
    pairs = 0.0
    paired_bets = 0
    for members in paired.values():
        n = len(members)
        total = sum(members)
        # What independence predicts for this group's total, standardised.
        z = (total - n * mean) / (math.sqrt(n) * sigma)
        excess += z * z - 1.0
        pairs += n - 1
        paired_bets += n

    raw = excess / pairs if pairs else 0.0
    return CorrelationEstimate(
        rho=min(MAX_RHO, max(0.0, raw)),
        provenance="measured",
        groups=len(paired),
        bets=n_bets,
        paired_bets=paired_bets,
        raw=raw,
        key=key,
        coverage=coverage,
    )


def from_ledger(ledger, key: str = "event", sport: str | None = None,
                prior: float = DEFAULT_CORRELATION) -> CorrelationEstimate:
    """Measure correlation from a ledger's settled bets.

    Event metadata is loaded only when the grouping needs it, so a book that
    has never recorded a starter pays nothing for the feature existing.
    """
    meta = ledger.event_meta() if key in META_KEYS else None
    return measure(ledger.settled_bets(sport=sport), key=key, prior=prior,
                   meta=meta)


def scale_from_ledger(ledger, n_bets: int, key: str = "event",
                      sport: str | None = None) -> tuple[float, CorrelationEstimate]:
    """The shrink factor for `n` live bets, and the correlation behind it.

    Returned together on purpose. A scale factor on its own cannot be checked,
    and the difference between one resting on 400 measured groups and one
    resting on the stated prior is the difference between a size and a guess.
    """
    estimate = from_ledger(ledger, key=key, sport=sport)
    return estimate.scale(n_bets), estimate
