"""A polling REST provider, and the accounting that makes polling honest.

`docs/DATA.md` recommends starting here: a polling feed with instrumented
latency produces a *correct* fill model that reports low fill probabilities,
where a fast feed with no measurement produces a confident one that might be
wrong. This is that provider, mapped to the documented shape of The Odds API.

**The network is a seam, not a dependency.** `fetcher` is a callable that
returns `(payload, headers)`. Nothing in this module opens a socket, so the
mapping — which is the part that can be wrong — is tested exhaustively without
a key, without a network, and without spending a credit. Supplying the real
fetcher is a handful of lines in `urllib_fetcher`, and it is the only part that
cannot be tested here.

**A quote is dated by the feed or it is not dated at all.** Each bookmaker
block carries `last_update`; that is the feed's own observation time and it
becomes `seen_at`. When it is missing, `seen_at` falls back to our receipt
time, which makes `fetched_at <= seen_at` and drives `Quote.provenance` to
`assumed` on its own. That is the whole degradation: the provider never invents
an age, and nothing downstream can mistake an undated quote for a fresh one.

**Credits are counted out loud.** This tier bills per request per region per
market, so a capture pass has a price. The response headers carry what is left,
and `RestProvider.quota` reports it — a poller that silently burns an allowance
is one you discover through a failed capture on the day it matters.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .feed import FeedError, Provider
from .models import Market, Outcome, Quote

#: Market keys this provider understands, mapped to the engine's own names.
#: An unknown key is skipped rather than guessed at: a market whose semantics
#: nobody checked would be priced by the same code that prices the ones we
#: understand, and the arithmetic would look identical.
MARKET_KEYS: dict[str, str] = {
    "h2h": "h2h",
    "spreads": "spreads",
    "totals": "totals",
}

#: Decimal odds are the engine's native form and the only format this maps.
#: American prices arriving here would be read as decimals — -110 becomes a
#: decimal price of -110 — so the format is asserted rather than assumed.
MIN_DECIMAL = 1.0


def parse_time(text: str) -> float:
    """An ISO-8601 instant as an epoch second.

    `fromisoformat` did not accept a trailing `Z` before Python 3.11, and this
    is built for 3.9, so the suffix is normalised first. A naive timestamp is
    treated as UTC: this feed documents its times as UTC, and guessing local
    time would shift every latency measurement by the operator's offset.
    """
    if not text:
        raise FeedError("empty timestamp")
    cleaned = text.strip()
    if cleaned.endswith("Z"):
        cleaned = cleaned[:-1] + "+00:00"
    try:
        moment = datetime.fromisoformat(cleaned)
    except ValueError as exc:
        raise FeedError(f"unreadable timestamp {text!r}: {exc}") from None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.timestamp()


@dataclass
class Quota:
    """What this key has left, straight off the response headers."""

    remaining: int | None = None
    used: int | None = None

    @property
    def known(self) -> bool:
        return self.remaining is not None

    def describe(self) -> str:
        if not self.known:
            return "credits unknown — the response carried no quota headers"
        return f"{self.remaining} credits remaining, {self.used} used"


def read_quota(headers: dict) -> Quota:
    """Pull the quota out of response headers, case-insensitively."""
    lower = {str(k).lower(): v for k, v in (headers or {}).items()}

    def _int(name):
        raw = lower.get(name)
        try:
            return int(raw)
        except (TypeError, ValueError):
            return None

    return Quota(remaining=_int("x-requests-remaining"),
                 used=_int("x-requests-used"))


def markets_from_payload(payload, sport: str, received_at: float) -> list[Market]:
    """Map one documented response into `Market` objects.

    Grouped by `(event, market key)`, because that is the unit the engine
    compares across books — a market holding one book's prices cannot be
    devigged against anything.
    """
    if not isinstance(payload, list):
        raise FeedError(
            f"expected a list of events, got {type(payload).__name__}")

    grouped: dict[tuple[str, str], Market] = {}
    for event in payload:
        try:
            event_id = str(event["id"])
            starts_at = parse_time(event["commence_time"])
        except (KeyError, TypeError) as exc:
            raise FeedError(f"event missing {exc} — refusing a partial map")

        for book in event.get("bookmakers") or []:
            book_key = str(book.get("key") or "")
            if not book_key:
                raise FeedError(f"{event_id}: a bookmaker block has no key")
            book_update = book.get("last_update")

            for market in book.get("markets") or []:
                key = str(market.get("key") or "")
                if key not in MARKET_KEYS:
                    continue          # unknown semantics: skipped, never guessed
                market_type = MARKET_KEYS[key]

                # The market's own stamp when it has one, the book's otherwise,
                # and the receipt time when neither — which makes the quote
                # `assumed` rather than letting it claim a freshness nobody
                # observed.
                stamp = market.get("last_update") or book_update
                seen_at = parse_time(stamp) if stamp else received_at

                slot = grouped.get((event_id, market_type))
                if slot is None:
                    slot = Market(event_id=event_id, sport=sport,
                                  market_type=market_type, quotes=[],
                                  starts_at=starts_at)
                    grouped[(event_id, market_type)] = slot

                for outcome in market.get("outcomes") or []:
                    try:
                        price = float(outcome["price"])
                        name = str(outcome["name"])
                    except (KeyError, TypeError, ValueError) as exc:
                        raise FeedError(
                            f"{event_id} {market_type}: bad outcome ({exc})")
                    if price <= MIN_DECIMAL:
                        raise FeedError(
                            f"{event_id} {market_type}: price {price} is not "
                            "decimal odds — request oddsFormat=decimal, "
                            "because American prices map straight through and "
                            "read as decimals")
                    point = outcome.get("point")
                    slot.quotes.append(Quote(
                        book=book_key,
                        outcome=Outcome(name=name,
                                        line=None if point is None else float(point)),
                        decimal=price,
                        seen_at=seen_at,
                    ))

    return list(grouped.values())


@dataclass
class RestProvider(Provider):
    """Poll a documented REST odds feed.

    `fetcher(path, params) -> (payload, headers)` is injected so this class can
    be exercised end to end without a key or a socket.
    """

    fetcher: object = None
    api_key: str = ""
    regions: str = "us"
    market_keys: tuple[str, ...] = ("h2h", "spreads", "totals")
    sport_keys: tuple[str, ...] = ()
    key: str = "restfeed"
    quota: Quota = field(default_factory=Quota)
    received_at: float | None = None

    def sports(self) -> list[str]:
        if not self.sport_keys:
            raise FeedError(
                "no sports configured — this provider will not poll every "
                "sport a key can reach, because each one costs a credit")
        return list(self.sport_keys)

    def fetch(self, sport: str) -> list[Market]:
        if self.fetcher is None:
            raise FeedError("no fetcher supplied; nothing here opens a socket")
        import time as _time

        params = {
            "regions": self.regions,
            "markets": ",".join(self.market_keys),
            "oddsFormat": "decimal",
        }
        if self.api_key:
            params["apiKey"] = self.api_key

        received_at = _time.time() if self.received_at is None else self.received_at
        payload, headers = self.fetcher(f"/v4/sports/{sport}/odds", params)
        self.quota = read_quota(headers)
        return markets_from_payload(payload, sport, received_at)


def urllib_fetcher(base: str = "https://api.the-odds-api.com", timeout: float = 10.0):
    """The only part of this module that touches the network.

    Kept to a few lines and separated deliberately: everything above is pure
    mapping and is tested without a key, so a failure here is a connectivity or
    credentials problem and never a pricing one.
    """
    from urllib.parse import urlencode
    from urllib.request import urlopen

    def _fetch(path: str, params: dict):
        url = f"{base}{path}?{urlencode(params)}"
        with urlopen(url, timeout=timeout) as response:  # noqa: S310
            body = response.read().decode("utf-8")
            headers = dict(response.headers.items())
        try:
            return json.loads(body), headers
        except json.JSONDecodeError as exc:
            raise FeedError(f"feed returned non-JSON: {exc}") from None

    return _fetch
