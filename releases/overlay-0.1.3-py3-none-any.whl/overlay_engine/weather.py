"""Turning weather notes into groups that can actually be measured.

`correlation --key weather` groups bets by what their events shared. It did that
on the raw recorded string, which quietly defeated the whole grouping: "wind
18mph" and "wind 19mph" are the same conditions and two different strings, so
every event landed in its own group. The failure is not that the answer got
less precise. It is that `paired` — groups holding two or more bets — collapsed
toward zero, so the estimate either fell back to the stated prior or was
measured off whichever handful of notes happened to be typed identically.

**Bands are a stated choice, not a measurement.** Nothing here counts anything.
The edges below are a judgement about where weather starts changing how a game
is played, they are labelled as stated wherever they surface, and the module
exists to make groups large enough to measure rather than to be right about
meteorology.

**Two dimensions, not three.** Wind and precipitation. Temperature is parsed and
reported but deliberately kept out of the bucket key: adding five temperature
bands multiplies the bucket count by five and thins every group by the same
factor, which is the exact problem this module was written to fix. A bucketing
scheme that produces groups of one is the raw string with extra steps.

**Unreadable notes return None.** They are excluded from the grouping, never
collected into a bucket of their own. A bucket of everything nobody could parse
is the single largest correlated block in the book, assembled entirely out of
bad handwriting — the same failure as grouping unrecorded events under a blank.
"""

from __future__ import annotations

import re

#: Wind bands in miles per hour, as (upper bound, name). Stated, not measured.
#: The edges are where wind starts to matter to a kicker, to a passing game,
#: and to whether the game plan changes at all.
WIND_BANDS: tuple[tuple[float, str], ...] = (
    (8.0, "calm"),
    (16.0, "breezy"),
    (25.0, "windy"),
    (float("inf"), "gale"),
)

#: Temperature bands in Fahrenheit. Parsed and reported, deliberately not part
#: of the bucket key — see the module docstring.
TEMP_BANDS: tuple[tuple[float, str], ...] = (
    (32.0, "freezing"),
    (50.0, "cold"),
    (70.0, "mild"),
    (85.0, "warm"),
    (float("inf"), "hot"),
)

#: Wind described in words rather than a number. Plenty of notes say "calm"
#: and never a figure, and dropping those loses grouping for no reason — the
#: word carries the same band the number would have landed in.
WIND_WORDS: dict[str, str] = {
    "calm": "calm", "still": "calm", "light wind": "calm",
    "breezy": "breezy", "light breeze": "breezy",
    "windy": "windy", "gusty": "windy", "strong wind": "windy",
    "gale": "gale", "howling": "gale",
}

INDOOR_WORDS = ("dome", "indoor", "indoors", "roof closed", "closed roof",
                "retractable closed")
WET_WORDS = ("rain", "showers", "drizzle", "storm", "thunder", "wet")
SNOW_WORDS = ("snow", "sleet", "blizzard", "flurries", "wintry")

_WIND = re.compile(r"(\d+(?:\.\d+)?)\s*(mph|km/?h|kph)", re.I)
_TEMP = re.compile(r"(-?\d+(?:\.\d+)?)\s*(?:deg(?:rees)?\s*)?°?\s*([fc])\b", re.I)

KPH_TO_MPH = 0.621371


def _band(value: float, bands: tuple[tuple[float, str], ...]) -> str:
    for upper, name in bands:
        if value < upper:
            return name
    return bands[-1][1]  # pragma: no cover - inf guarantees a match above


def wind_band(text: str) -> str | None:
    """The wind band, from a figure if there is one and from words if not.

    A figure wins: "light breeze, 22mph" is a note disagreeing with itself, and
    the number is the part somebody measured.
    """
    speed = wind_mph(text)
    if speed is not None:
        return _band(speed, WIND_BANDS)
    low = text.lower()
    for phrase, band in sorted(WIND_WORDS.items(), key=lambda kv: -len(kv[0])):
        if phrase in low:
            return band
    return None


def wind_mph(text: str) -> float | None:
    """Wind speed in mph, converting from kph when that is what was written."""
    match = _WIND.search(text)
    if not match:
        return None
    value = float(match.group(1))
    if match.group(2).lower() != "mph":
        value *= KPH_TO_MPH
    return value


def temperature_f(text: str) -> float | None:
    """Temperature in Fahrenheit, converting from Celsius when written that way.

    A bare number with no unit is refused. "12" is 12°C in most of the world and
    12°F in the market this tool serves, and the two are a different game.
    """
    match = _TEMP.search(text)
    if not match:
        return None
    value = float(match.group(1))
    if match.group(2).lower() == "c":
        value = value * 9.0 / 5.0 + 32.0
    return value


def indoor(text: str) -> bool:
    low = text.lower()
    return any(word in low for word in INDOOR_WORDS)


def precipitation(text: str) -> str | None:
    """`snow`, `wet` or `dry` — or None when the note says nothing about it.

    Snow outranks rain when a note mentions both, because a note saying "rain
    turning to snow" describes a game played in snow.
    """
    low = text.lower()
    if any(word in low for word in SNOW_WORDS):
        return "snow"
    if any(word in low for word in WET_WORDS):
        return "wet"
    if "dry" in low or "clear" in low or "sunny" in low or "fair" in low:
        return "dry"
    return None


def bucket(text: str | None) -> str | None:
    """The grouping key for a weather note, or None if it cannot be read.

    Indoor short-circuits everything: a game under a closed roof has no weather,
    and every such game shares that. Outdoors, the key is the wind band and the
    precipitation state, which is coarse enough to make groups and fine enough
    that the groups mean something.
    """
    if not text or not text.strip():
        return None
    if indoor(text):
        return "indoor"

    band = wind_band(text)
    precip = precipitation(text)
    if band is None and precip is None:
        return None  # nothing readable; excluded rather than bucketed

    parts = []
    if band is not None:
        parts.append(f"wind:{band}")
    if precip is not None:
        parts.append(f"precip:{precip}")
    return "|".join(parts)


def describe(text: str | None) -> str:
    """A human-readable reading of a note, for showing what was understood."""
    got = bucket(text)
    if got is None:
        return f"{text!r}: not readable — excluded from weather grouping"
    speed, temp = wind_mph(text or ""), temperature_f(text or "")
    bits = [f"bucket {got}"]
    if speed is not None:
        bits.append(f"wind {speed:.0f} mph ({_band(speed, WIND_BANDS)})")
    if temp is not None:
        bits.append(
            f"temp {temp:.0f}F ({_band(temp, TEMP_BANDS)}, not in the bucket)")
    return "; ".join(bits)


def buckets() -> list[str]:
    """Every bucket this scheme can produce. Bounded on purpose: an unbounded
    bucket count is the raw string wearing a different name."""
    out = ["indoor"]
    for _, wind in WIND_BANDS:
        out.append(f"wind:{wind}")
        for precip in ("dry", "wet", "snow"):
            out.append(f"wind:{wind}|precip:{precip}")
    for precip in ("dry", "wet", "snow"):
        out.append(f"precip:{precip}")
    return out
