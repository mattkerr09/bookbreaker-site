"""The record. Without it, nothing here learns anything.

Every "learned" parameter in this engine — devig weights, quote survival, book
weights, correlation — is fitted from outcomes the user's own betting produces.
Until those outcomes are written down, each one is permanently its shipped
prior, and the product's central claim is false in the strict sense that no
mechanism exists for it to become true.

So this is the first thing built after the maths, and it has one rule that
shapes the whole schema:

**A bet is recorded with the model state that produced it, or not at all.**

Not the fair probability alone — the *whole* devig spread, every method's
answer, as it stood at bet time. Calibration asks "which method predicted the
closing line best", and that question is unanswerable six weeks later from
prices nobody kept. The market has moved, the book's line is gone, and there is
no way back to what `power` would have said. A bet logged without it is a bet
that can never train anything, and it will look completely normal in the table.

That is why `record_bet` validates rather than trusting `NOT NULL`. SQLite
catches a missing column; it cannot catch an empty JSON object, a band that
does not contain its own midpoint, or a probability of zero — all of which
store fine and are all equally useless later.

Storage is plain SQLite at `~/.overlay/overlay.db`, matching the Docket and
AdPlaybook convention: on your machine, no account, no server. `$OVERLAY_HOME`
relocates it.
"""

from __future__ import annotations

import json
import os
import sqlite3
import time
from dataclasses import dataclass, field
from pathlib import Path

from .clv import GradedBet
from .heat import AccountHeat, BetRecord
from .staleness import FillModel, LatencyModel, Observation

SCHEMA_VERSION = 10

# How a bet finished. A push returns the stake and is not a loss; a void
# removes the bet entirely and should not appear in turnover at all.
RESULTS = ("won", "lost", "push", "void")

# What a promotion is, and what it is doing now. `expired` is the state that
# matters: a bonus bet that lapses unused is worth exactly zero, and nothing
# else in this ledger records a loss you took by doing nothing.
PROMO_KINDS = ("bonus_bet", "profit_boost")
PROMO_STATES = ("held", "used", "expired")


class LedgerError(ValueError):
    """A write that would make the record less useful than no record."""


def home() -> Path:
    """Where the database lives. `$OVERLAY_HOME` overrides."""
    return Path(os.environ.get("OVERLAY_HOME", Path.home() / ".overlay"))


_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- One row per placed bet, carrying the model state that produced it. The
-- fair_* and devig_json columns are the reason this table exists; a row
-- without them is a row that can never grade or train anything.
CREATE TABLE IF NOT EXISTS bets (
    id                INTEGER PRIMARY KEY,
    placed_at         REAL NOT NULL,
    event_id          TEXT NOT NULL,
    sport             TEXT NOT NULL,
    market_type       TEXT NOT NULL,
    outcome           TEXT NOT NULL,
    book              TEXT NOT NULL,
    decimal_odds      REAL NOT NULL,
    stake             REAL NOT NULL,
    fair_prob         REAL NOT NULL,
    fair_low          REAL NOT NULL,
    fair_high         REAL NOT NULL,
    devig_json        TEXT NOT NULL,
    -- Each contributing book's devigged probability for this outcome at bet
    -- time. Nullable: rows written before schema v2 predate the column and
    -- stay perfectly valid — they simply cannot answer "how wrong was Circa",
    -- which is the honest state for a bet nobody recorded it for.
    book_probs        TEXT,
    -- The calibration in force when this bet was priced. Nullable, and never
    -- last in the column list — a comment between the final column and the
    -- closing paren makes that column undroppable, see `quotes`.
    weights_json      TEXT,
    -- 'import' for a bet read out of a book's CSV export, NULL for one this
    -- engine priced and placed. The distinction is load-bearing: an imported
    -- bet has no devig spread, so it can be tracked and CLV-graded but can
    -- never train the calibration.
    source            TEXT,
    -- The book's own reference for this bet, when the export carries one.
    -- Uniquely indexed where present, so re-importing a file corrects rather
    -- than duplicates.
    external_ref      TEXT,
    p_fill            REAL NOT NULL,
    heat              REAL NOT NULL,
    since_line_move   REAL,
    recreational      INTEGER NOT NULL DEFAULT 0,
    closing_fair_prob REAL,
    -- 'won' | 'lost' | 'push' | 'void', or NULL while unsettled. Kept apart
    -- from the boolean `won` because a push is neither: counting pushes as
    -- losses deflates win rate, and counting voided stakes in turnover
    -- deflates ROI. Both errors are silent and both flatter nobody.
    result            TEXT,
    won               INTEGER,
    profit            REAL,
    settled_at        REAL
);

-- Every attempt to take a quote, accepted or not. This is what fits the
-- survival model, and it is deliberately separate from `bets`: a rejected
-- attempt is not a bet, but it is the single most informative event the
-- fill model ever sees.
CREATE TABLE IF NOT EXISTS attempts (
    id           INTEGER PRIMARY KEY,
    attempted_at REAL NOT NULL,
    book         TEXT NOT NULL,
    market_type  TEXT NOT NULL,
    quote_age    REAL NOT NULL,
    accepted     INTEGER NOT NULL,
    bet_id       INTEGER REFERENCES bets(id)
);

-- Line history. Closing rows are the ground truth every learned parameter is
-- graded against, so they are captured whether or not a bet was placed —
-- a closing line only observed on markets we bet is a biased sample of
-- exactly the markets we were wrong about.
CREATE TABLE IF NOT EXISTS quotes (
    id           INTEGER PRIMARY KEY,
    seen_at      REAL NOT NULL,
    event_id     TEXT NOT NULL,
    sport        TEXT NOT NULL,
    market_type  TEXT NOT NULL,
    outcome      TEXT NOT NULL,
    book         TEXT NOT NULL,
    decimal_odds REAL NOT NULL,
    -- `fetched_at` is when this price reached us, against `seen_at` which is
    -- when it was true at the book. The gap is feed latency, a floor under
    -- every quote age. Nullable: rows written before schema v3 never recorded
    -- it, and unknown latency is not zero latency.
    --
    -- Kept off the last line deliberately. SQLite rebuilds the CREATE
    -- statement on ALTER TABLE ... DROP COLUMN, and a comment left dangling
    -- between the final column and the closing paren fails to parse
    -- ("incomplete input"), which makes that column permanently undroppable.
    fetched_at   REAL,
    is_closing   INTEGER NOT NULL DEFAULT 0
);

-- Final scores. The only way to learn what a margin distribution actually
-- looks like: real football margins cluster hard on 3 and 7, and no smooth
-- curve reproduces that. One row per event, so a re-reported score corrects
-- rather than double-counts.
CREATE TABLE IF NOT EXISTS scores (
    event_id   TEXT PRIMARY KEY,
    sport      TEXT NOT NULL,
    home_score INTEGER NOT NULL,
    away_score INTEGER NOT NULL,
    recorded_at REAL NOT NULL
);

-- Promotions currently held. A bonus bet is money until it expires and
-- nothing afterwards, so `expires_at` is the whole point of the table.
CREATE TABLE IF NOT EXISTS promos (
    id          INTEGER PRIMARY KEY,
    book        TEXT NOT NULL,
    kind        TEXT NOT NULL,
    amount      REAL NOT NULL,
    boost       REAL,
    received_at REAL NOT NULL,
    expires_at  REAL,
    state       TEXT NOT NULL DEFAULT 'held',
    used_at     REAL,
    realised    REAL,
    note        TEXT
);

-- Free-text labels on bets, so a bettor can test their own hypothesis
-- against the record: "line-shopped", "steam", "gut", "tired legs". One row
-- per (bet, tag), uniquely indexed, so tagging twice is idempotent rather
-- than doubling that bet's weight in its own slice.
CREATE TABLE IF NOT EXISTS event_meta (
    event_id    TEXT PRIMARY KEY,
    sport       TEXT,
    starter     TEXT,
    venue       TEXT,
    weather     TEXT,
    recorded_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS bet_tags (
    bet_id INTEGER NOT NULL REFERENCES bets(id),
    tag    TEXT NOT NULL,
    PRIMARY KEY (bet_id, tag)
);

CREATE TABLE IF NOT EXISTS settings (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_bets_placed   ON bets(placed_at);
CREATE INDEX IF NOT EXISTS idx_bets_book     ON bets(book);
CREATE INDEX IF NOT EXISTS idx_attempts_book ON attempts(book, market_type);
CREATE INDEX IF NOT EXISTS idx_quotes_event  ON quotes(event_id, market_type, outcome);
CREATE INDEX IF NOT EXISTS idx_quotes_close  ON quotes(is_closing, event_id);
"""


@dataclass(frozen=True)
class AtBet:
    """The model's state at the moment a bet was placed.

    Required, not optional. Every field here is unreconstructable once the
    market moves, and the whole point of the ledger is that it holds the
    things that stop being available.
    """

    fair_prob: float
    fair_low: float
    fair_high: float
    devig: dict[str, float]
    p_fill: float = 1.0
    heat: float = 0.0
    weights: dict | None = None
    """The calibration in force when this bet was priced — normally
    `PricingContext.as_record()`. Optional, and worth supplying: without it a
    bad calibration is undiagnosable after the fact, because the weights have
    since been overwritten and nothing says which ones were in force when the
    bet looked good."""

    book_probs: dict[str, float] = field(default_factory=dict)
    """Each contributing book's devigged probability for this outcome, as the
    blend saw it. Optional — a bet placed without it is still gradeable and
    still trains method weights; it simply cannot say how wrong any individual
    book was, which is the state every pre-v2 row is in."""

    def validate(self) -> None:
        """Refuse anything that would store cleanly and grade to nothing.

        `NOT NULL` cannot see any of these. An empty devig dict, a band that
        does not contain its own midpoint, a probability of 0 or 1 — all valid
        SQLite, all worthless to calibration, and all invisible in a table
        listing months later when the market they came from is gone.
        """
        if not 0.0 < self.fair_prob < 1.0:
            raise LedgerError(
                f"fair_prob must lie in (0, 1), got {self.fair_prob!r}"
            )
        if not self.devig:
            raise LedgerError(
                "a bet needs the full devig spread at bet time; calibration "
                "asks which method predicted the close, and that cannot be "
                "recovered from a fair probability alone once the line moves"
            )
        for method, prob in self.devig.items():
            if not 0.0 < prob < 1.0:
                raise LedgerError(
                    f"devig[{method!r}] must lie in (0, 1), got {prob!r}"
                )
        for book, prob in self.book_probs.items():
            if not 0.0 < prob < 1.0:
                raise LedgerError(
                    f"book_probs[{book!r}] must lie in (0, 1), got {prob!r}"
                )
        if not self.fair_low <= self.fair_prob <= self.fair_high:
            raise LedgerError(
                f"band {self.fair_low:.4f}..{self.fair_high:.4f} does not "
                f"contain fair_prob {self.fair_prob:.4f}"
            )
        if not 0.0 <= self.p_fill <= 1.0:
            raise LedgerError(f"p_fill must lie in [0, 1], got {self.p_fill!r}")
        if not 0.0 <= self.heat <= 1.0:
            raise LedgerError(f"heat must lie in [0, 1], got {self.heat!r}")


class Ledger:
    """The local record: bets, attempts, line history, learned settings."""

    def __init__(self, path: str | Path | None = None):
        if path is None:
            path = home() / "overlay.db"
        self.path = Path(path)
        if str(self.path) != ":memory:":
            self.path.parent.mkdir(parents=True, exist_ok=True)

        self.conn = sqlite3.connect(str(self.path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        if str(self.path) != ":memory:":
            # WAL survives a crash mid-write. The record is the asset here;
            # losing a month of bets to an unclean shutdown would cost more
            # than every other bug in this repo combined.
            self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.executescript(_SCHEMA)
        self._migrate()

    def _has_column(self, table: str, column: str) -> bool:
        return any(
            r["name"] == column
            for r in self.conn.execute(f"PRAGMA table_info({table})")
        )

    def _ensure_indexes(self) -> None:
        """Indexes over migration-added columns, created after the migration.

        These cannot live in `_SCHEMA`. That script runs before `_migrate`, so
        an index naming a column a later version introduced fails outright on
        every older database — the upgrade path dies before it can add the
        column. Found by the v6-to-v7 test, and it would have hit every
        existing install rather than only a test.
        """
        self.conn.execute(
            """CREATE UNIQUE INDEX IF NOT EXISTS idx_bets_ref
                   ON bets(external_ref) WHERE external_ref IS NOT NULL"""
        )

    def _migrate(self) -> None:
        """Bring an existing database up to `SCHEMA_VERSION`.

        Every step is additive and nullable. A migration that rewrote or
        dropped a column would put the one irreplaceable asset in this repo —
        months of bets nobody can re-observe — behind a code path that runs
        once and is hard to test. Adding a nullable column cannot lose a row,
        and the null is itself the honest answer for bets recorded before the
        column existed.
        """
        row = self.conn.execute(
            "SELECT value FROM meta WHERE key = \'schema_version\'"
        ).fetchone()

        if row is None:
            # Fresh database: `_SCHEMA` already built the current shape.
            with self.conn:
                self.conn.execute(
                    "INSERT INTO meta (key, value) VALUES (\'schema_version\', ?)",
                    (str(SCHEMA_VERSION),),
                )
            return

        found = int(row["value"])
        if found > SCHEMA_VERSION:
            raise LedgerError(
                f"database is schema v{found}; this build understands "
                f"v{SCHEMA_VERSION}. A newer Overlay wrote it — upgrade rather "
                "than letting an older build write rows it cannot read back."
            )
        if found == SCHEMA_VERSION:
            with self.conn:
                self._ensure_indexes()
            return

        with self.conn:
            # v1 -> v2: per-book devigged probabilities at bet time. Guarded by
            # a column check rather than a bare ALTER, because `_SCHEMA` runs
            # first and a database created by this build already has it.
            if found < 2 and not self._has_column("bets", "book_probs"):
                self.conn.execute("ALTER TABLE bets ADD COLUMN book_probs TEXT")

            # v9 -> v10: what an event shares with other events. A new
            # table rather than columns on `bets`, because the facts belong to
            # the event and not to any one bet on it — two bets on the same
            # game must not be able to disagree about who started.
            if found < 10:
                self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS event_meta (
                           event_id    TEXT PRIMARY KEY,
                           sport       TEXT,
                           starter     TEXT,
                           venue       TEXT,
                           weather     TEXT,
                           recorded_at REAL NOT NULL
                       )"""
                )

            # v2 -> v3: feed latency provenance on quotes.
            if found < 3 and not self._has_column("quotes", "fetched_at"):
                self.conn.execute("ALTER TABLE quotes ADD COLUMN fetched_at REAL")

            # v3 -> v4: which calibration priced each bet.
            if found < 4 and not self._has_column("bets", "weights_json"):
                self.conn.execute("ALTER TABLE bets ADD COLUMN weights_json TEXT")

            # v4 -> v5: final scores, for measured margin distributions. A new
            # table rather than a column, so nothing existing is touched.
            # v8 -> v9: free-text tags on bets.
            if found < 9:
                self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS bet_tags (
                           bet_id INTEGER NOT NULL REFERENCES bets(id),
                           tag    TEXT NOT NULL,
                           PRIMARY KEY (bet_id, tag)
                       )"""
                )

            # v7 -> v8: promotions held. A new table, so nothing existing is
            # touched.
            if found < 8:
                self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS promos (
                           id          INTEGER PRIMARY KEY,
                           book        TEXT NOT NULL,
                           kind        TEXT NOT NULL,
                           amount      REAL NOT NULL,
                           boost       REAL,
                           received_at REAL NOT NULL,
                           expires_at  REAL,
                           state       TEXT NOT NULL DEFAULT 'held',
                           used_at     REAL,
                           realised    REAL,
                           note        TEXT
                       )"""
                )

            # v6 -> v7: where a bet came from, and the book's own reference.
            #
            # `devig_json` stays NOT NULL. Relaxing it would need a table
            # rebuild, and rebuilding the one table nobody can re-observe is
            # the migration this project will not write. Imported bets store
            # '{}' instead, which is not a fudge — it says exactly what is
            # true, that no per-method spread was recorded — and every reader
            # that needs a spread already has to skip the empty case.
            if found < 7:
                if not self._has_column("bets", "source"):
                    self.conn.execute("ALTER TABLE bets ADD COLUMN source TEXT")
                if not self._has_column("bets", "external_ref"):
                    self.conn.execute(
                        "ALTER TABLE bets ADD COLUMN external_ref TEXT")

            # v5 -> v6: settlement result, so pushes and voids stop being
            # counted as bets.
            if found < 6 and not self._has_column("bets", "result"):
                self.conn.execute("ALTER TABLE bets ADD COLUMN result TEXT")

            if found < 5:
                self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS scores (
                           event_id   TEXT PRIMARY KEY,
                           sport      TEXT NOT NULL,
                           home_score INTEGER NOT NULL,
                           away_score INTEGER NOT NULL,
                           recorded_at REAL NOT NULL
                       )"""
                )

            self._ensure_indexes()
            self.conn.execute(
                "UPDATE meta SET value = ? WHERE key = \'schema_version\'",
                (str(SCHEMA_VERSION),),
            )

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "Ledger":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ------------------------------------------------------------- writing

    def record_bet(
        self,
        *,
        event_id: str,
        sport: str,
        market_type: str,
        outcome: str,
        book: str,
        decimal_odds: float,
        stake: float,
        at_bet: AtBet,
        placed_at: float | None = None,
        since_line_move: float | None = None,
        recreational: bool = False,
    ) -> int:
        """Record a placed bet. Returns its id.

        `at_bet` is keyword-only and has no default on purpose: a caller who
        has not got the model state should fail here, loudly, rather than
        write a row that looks fine and trains nothing.
        """
        if decimal_odds <= 1.0:
            raise LedgerError(f"decimal odds must exceed 1.0, got {decimal_odds}")
        if stake <= 0:
            raise LedgerError(f"stake must be positive, got {stake}")
        at_bet.validate()

        placed_at = time.time() if placed_at is None else placed_at
        with self.conn:
            cur = self.conn.execute(
                """INSERT INTO bets (
                       placed_at, event_id, sport, market_type, outcome, book,
                       decimal_odds, stake, fair_prob, fair_low, fair_high,
                       devig_json, book_probs, weights_json, p_fill, heat,
                       since_line_move, recreational
                   ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (placed_at, event_id, sport, market_type, outcome, book,
                 decimal_odds, stake, at_bet.fair_prob, at_bet.fair_low,
                 at_bet.fair_high, json.dumps(at_bet.devig, sort_keys=True),
                 json.dumps(at_bet.book_probs, sort_keys=True)
                 if at_bet.book_probs else None,
                 json.dumps(at_bet.weights, sort_keys=True)
                 if at_bet.weights else None,
                 at_bet.p_fill, at_bet.heat, since_line_move, int(recreational)),
            )
        return int(cur.lastrowid)

    def import_bet(
        self,
        *,
        event_id: str,
        sport: str,
        market_type: str,
        outcome: str,
        book: str,
        decimal_odds: float,
        stake: float,
        placed_at: float,
        result: str | None = None,
        profit: float | None = None,
        external_ref: str | None = None,
        settled_at: float | None = None,
    ) -> int | None:
        """Record a bet read from a book's export. Returns its id, or None
        when `external_ref` says it is already here.

        Deliberately not `record_bet`. That method demands the model state that
        produced the price, and an imported bet has none — nobody recorded what
        `power` said about a market weeks ago at a book. Rather than invent one,
        this writes an empty spread and marks the row `import`, so the bet
        counts toward P&L and can be CLV-graded but is invisible to
        calibration. A tracked bet and a training bet are different things and
        the schema should not blur them.
        """
        if decimal_odds <= 1.0:
            raise LedgerError(f"decimal odds must exceed 1.0, got {decimal_odds}")
        if stake <= 0:
            raise LedgerError(f"stake must be positive, got {stake}")
        if result is not None and result not in RESULTS:
            raise LedgerError(
                f"unknown result {result!r}; expected one of {', '.join(RESULTS)}"
            )

        if external_ref and self.conn.execute(
            "SELECT 1 FROM bets WHERE external_ref = ?", (external_ref,)
        ).fetchone():
            return None

        won = None if result in (None, "push", "void") else (result == "won")
        with self.conn:
            cur = self.conn.execute(
                """INSERT INTO bets (
                       placed_at, event_id, sport, market_type, outcome, book,
                       decimal_odds, stake, fair_prob, fair_low, fair_high,
                       devig_json, source, external_ref, p_fill, heat,
                       result, won, profit, settled_at
                   ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (placed_at, event_id, sport, market_type, outcome, book,
                 decimal_odds, stake,
                 # No fair value was computed for this bet. The break-even
                 # price is the only defensible stand-in and it is recorded as
                 # a band of zero width, so nothing downstream mistakes it for
                 # a model output.
                 1.0 / decimal_odds, 1.0 / decimal_odds, 1.0 / decimal_odds,
                 "{}", "import", external_ref, 1.0, 0.0,
                 result, None if won is None else int(won), profit,
                 settled_at if profit is not None else None),
            )
        return int(cur.lastrowid)

    def record_attempt(
        self,
        *,
        book: str,
        market_type: str,
        quote_age: float,
        accepted: bool,
        bet_id: int | None = None,
        attempted_at: float | None = None,
    ) -> int:
        """Record an attempt to take a quote — the fill model's only input."""
        if quote_age < 0:
            raise LedgerError(f"quote age cannot be negative, got {quote_age}")
        attempted_at = time.time() if attempted_at is None else attempted_at
        with self.conn:
            cur = self.conn.execute(
                """INSERT INTO attempts
                       (attempted_at, book, market_type, quote_age, accepted, bet_id)
                   VALUES (?,?,?,?,?,?)""",
                (attempted_at, book, market_type, quote_age, int(accepted), bet_id),
            )
        return int(cur.lastrowid)

    def record_quote(
        self,
        *,
        event_id: str,
        sport: str,
        market_type: str,
        outcome: str,
        book: str,
        decimal_odds: float,
        seen_at: float | None = None,
        is_closing: bool = False,
        fetched_at: float | None = None,
    ) -> int:
        """Record an observed price. `is_closing` marks the grading truth.

        `seen_at` is the feed's own timestamp; `fetched_at` is when it reached
        us. Storing both is what lets `latency_model()` measure the gap later
        — it cannot be recovered from a single timestamp, and a feed's delay is
        exactly the quantity that makes fill probability too optimistic when
        nobody is looking at it.
        """
        if decimal_odds <= 1.0:
            raise LedgerError(f"decimal odds must exceed 1.0, got {decimal_odds}")
        if fetched_at is not None and seen_at is not None and fetched_at < seen_at:
            raise LedgerError(
                f"fetched_at {fetched_at} precedes seen_at {seen_at}: a price "
                "cannot reach us before the book set it. Check the feed's clock "
                "rather than storing a negative latency."
            )
        seen_at = time.time() if seen_at is None else seen_at
        with self.conn:
            cur = self.conn.execute(
                """INSERT INTO quotes
                       (seen_at, event_id, sport, market_type, outcome, book,
                        decimal_odds, is_closing, fetched_at)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (seen_at, event_id, sport, market_type, outcome, book,
                 decimal_odds, int(is_closing), fetched_at),
            )
        return int(cur.lastrowid)

    def record_market(self, market, is_closing: bool = False) -> int:
        """Store every quote in a `Market`. The feed's write path.

        Returns the number of quotes stored. Capture happens for every market
        watched, not only the ones bet: a closing line observed only where we
        bet is a biased sample of exactly the markets we got wrong, and
        calibration fitted on that sample learns the bias rather than the
        market.
        """
        n = 0
        for quote in market.quotes:
            self.record_quote(
                event_id=market.event_id,
                sport=market.sport,
                market_type=market.market_type,
                outcome=quote.outcome.key,
                book=quote.book,
                decimal_odds=quote.decimal,
                seen_at=quote.seen_at,
                is_closing=is_closing,
                fetched_at=quote.fetched_at,
            )
            n += 1
        return n

    def closed_markets(self) -> set[tuple[str, str]]:
        """Every `(event_id, market_type)` that already has a closing capture.

        Read in one query rather than one per market: a scheduler asking
        `closing_market` per candidate turns a scheduling pass into a query
        storm, and the answer it needs is a membership test.
        """
        return {
            (row["event_id"], row["market_type"])
            for row in self.conn.execute(
                "SELECT DISTINCT event_id, market_type FROM quotes "
                "WHERE is_closing = 1")
        }

    def closing_market(self, event_id: str, market_type: str) -> dict[str, dict[str, float]]:
        """Closing prices for one market, grouped by book.

        Grouped rather than flattened because devigging needs a *complete*
        two-sided market from a single book. A fair probability built from one
        book's over and another's under is not a devig — it is the arbitrage
        between them, laundered into a probability, and it would grade every
        bet against a number no book ever offered.

        Latest quote per (book, outcome) wins.
        """
        out: dict[str, dict[str, float]] = {}
        for r in self.conn.execute(
            """SELECT book, outcome, decimal_odds FROM quotes
                WHERE is_closing = 1 AND event_id = ? AND market_type = ?
                ORDER BY seen_at""",
            (event_id, market_type),
        ):
            out.setdefault(r["book"], {})[r["outcome"]] = float(r["decimal_odds"])
        return out

    def ungraded_bets(self) -> list[dict]:
        """Bets still waiting on a closing line, oldest first."""
        return [
            dict(r) for r in self.conn.execute(
                """SELECT id, event_id, sport, market_type, outcome, book,
                          decimal_odds, placed_at
                     FROM bets WHERE closing_fair_prob IS NULL
                    ORDER BY placed_at"""
            )
        ]

    def tag_bet(self, bet_id: int, *tags: str) -> int:
        """Label a bet. Returns how many tags were newly added.

        Tags are lowercased and stripped, because "Steam", "steam " and
        "steam" are one hypothesis and three slices of a record is exactly how
        a pattern gets manufactured out of nothing.
        """
        if self.conn.execute(
            "SELECT 1 FROM bets WHERE id = ?", (bet_id,)
        ).fetchone() is None:
            raise LedgerError(f"no bet with id {bet_id}")

        added = 0
        with self.conn:
            for raw in tags:
                tag = raw.strip().lower()
                if not tag:
                    raise LedgerError("a tag cannot be blank")
                cur = self.conn.execute(
                    "INSERT OR IGNORE INTO bet_tags (bet_id, tag) VALUES (?,?)",
                    (bet_id, tag),
                )
                added += cur.rowcount
        return added

    def untag_bet(self, bet_id: int, tag: str) -> bool:
        with self.conn:
            cur = self.conn.execute(
                "DELETE FROM bet_tags WHERE bet_id = ? AND tag = ?",
                (bet_id, tag.strip().lower()),
            )
        return cur.rowcount > 0

    def tags(self) -> dict[str, int]:
        """Every tag in use, and how many bets carry it."""
        return {
            r["tag"]: r["n"] for r in self.conn.execute(
                "SELECT tag, COUNT(*) AS n FROM bet_tags "
                "GROUP BY tag ORDER BY n DESC, tag"
            )
        }

    def tags_for(self, bet_id: int) -> list[str]:
        return [
            r["tag"] for r in self.conn.execute(
                "SELECT tag FROM bet_tags WHERE bet_id = ? ORDER BY tag",
                (bet_id,),
            )
        ]

    def settled_by_tag(self) -> dict[str, list[dict]]:
        """Settled bets grouped by tag. A bet appears under every tag it has."""
        out: dict[str, list[dict]] = {}
        for row in self.conn.execute(
            """SELECT t.tag AS tag, b.* FROM bet_tags t
                 JOIN bets b ON b.id = t.bet_id
                WHERE b.profit IS NOT NULL
                ORDER BY b.placed_at"""
        ):
            record = dict(row)
            out.setdefault(record.pop("tag"), []).append(record)
        return out

    def record_promo(
        self,
        *,
        book: str,
        kind: str,
        amount: float,
        expires_at: float | None = None,
        boost: float | None = None,
        received_at: float | None = None,
        note: str = "",
    ) -> int:
        """Record a promotion you are holding."""
        if kind not in PROMO_KINDS:
            raise LedgerError(
                f"unknown promo kind {kind!r}; expected one of "
                f"{', '.join(PROMO_KINDS)}"
            )
        if amount <= 0:
            raise LedgerError(f"a promo must be worth something, got {amount}")
        if kind == "profit_boost" and not boost:
            raise LedgerError("a profit boost needs its boost fraction")
        received_at = time.time() if received_at is None else received_at
        if expires_at is not None and expires_at <= received_at:
            raise LedgerError(
                "a promo cannot expire before it was received; check the date "
                "rather than storing something already dead"
            )

        with self.conn:
            cur = self.conn.execute(
                """INSERT INTO promos
                       (book, kind, amount, boost, received_at, expires_at,
                        state, note)
                   VALUES (?,?,?,?,?,?,'held',?)""",
                (book, kind, amount, boost, received_at, expires_at, note),
            )
        return int(cur.lastrowid)

    def promos(self, state: str | None = None, book: str | None = None,
               now: float | None = None) -> list[dict]:
        """Promotions, optionally filtered.

        `state='held'` means *live*: still held and not past its expiry. A
        lapsed promotion is not a holding, and returning one would overstate
        the bankroll by money that no longer exists.
        """
        now = time.time() if now is None else now
        sql, args = "SELECT * FROM promos WHERE 1 = 1", []
        if book:
            sql += " AND book = ?"
            args.append(book)
        if state == "held":
            sql += (" AND state = 'held' AND"
                    " (expires_at IS NULL OR expires_at > ?)")
            args.append(now)
        elif state == "expired":
            sql += (" AND (state = 'expired' OR (state = 'held' AND"
                    " expires_at IS NOT NULL AND expires_at <= ?))")
            args.append(now)
        elif state:
            sql += " AND state = ?"
            args.append(state)
        sql += " ORDER BY COALESCE(expires_at, 1e18), id"
        return [dict(r) for r in self.conn.execute(sql, args)]

    def use_promo(self, promo_id: int, realised: float,
                  used_at: float | None = None) -> None:
        """Mark a promotion used, and record what it actually converted to.

        `realised` is what you got, not what it was worth in theory. The gap
        between the two is the only honest read on whether the conversion was
        done well, and it cannot be recovered later.
        """
        row = self.conn.execute(
            "SELECT state FROM promos WHERE id = ?", (promo_id,)
        ).fetchone()
        if row is None:
            raise LedgerError(f"no promo with id {promo_id}")
        if row["state"] != "held":
            raise LedgerError(
                f"promo {promo_id} is already {row['state']}; using it twice "
                "would count the same money in two places"
            )
        with self.conn:
            self.conn.execute(
                """UPDATE promos SET state = 'used', realised = ?, used_at = ?
                    WHERE id = ?""",
                (realised, time.time() if used_at is None else used_at, promo_id),
            )

    def expire_promos(self, now: float | None = None) -> int:
        """Write the expired state for promotions that have lapsed.

        `promos(state='held')` already excludes them on read, so this only
        makes the record match what is true. Returns how many lapsed.
        """
        now = time.time() if now is None else now
        with self.conn:
            cur = self.conn.execute(
                """UPDATE promos SET state = 'expired'
                    WHERE state = 'held' AND expires_at IS NOT NULL
                      AND expires_at <= ?""",
                (now,),
            )
        return cur.rowcount

    def record_score(self, *, event_id: str, sport: str,
                     home_score: int, away_score: int,
                     recorded_at: float | None = None) -> None:
        """Record a final score. Re-reporting one corrects it rather than
        double-counting — a margin distribution built from a table that counted
        the same game twice would be wrong in a way nothing else could see."""
        if home_score < 0 or away_score < 0:
            raise LedgerError(
                f"scores cannot be negative, got {home_score}-{away_score}"
            )
        with self.conn:
            self.conn.execute(
                """INSERT INTO scores
                       (event_id, sport, home_score, away_score, recorded_at)
                   VALUES (?,?,?,?,?)
                   ON CONFLICT(event_id) DO UPDATE SET
                       sport = excluded.sport,
                       home_score = excluded.home_score,
                       away_score = excluded.away_score,
                       recorded_at = excluded.recorded_at""",
                (event_id, sport, int(home_score), int(away_score),
                 time.time() if recorded_at is None else recorded_at),
            )

    META_FIELDS = ("starter", "venue", "weather")

    def record_event_meta(self, *, event_id: str, sport: str | None = None,
                          starter: str | None = None, venue: str | None = None,
                          weather: str | None = None,
                          recorded_at: float | None = None) -> None:
        """Record what an event shares with other events.

        Re-recording an event updates it rather than adding a second row: two
        rows disagreeing about who started would make the grouping depend on
        which one a query happened to read first.

        Every field is optional and stays NULL when absent. A blank is not a
        value — an event with no starter recorded is not an event whose starter
        is the empty string, and the correlation grouping depends on being able
        to tell those apart.
        """
        if not event_id:
            raise LedgerError("an event needs an id")
        clean = {
            "starter": (starter or "").strip() or None,
            "venue": (venue or "").strip() or None,
            "weather": (weather or "").strip() or None,
        }
        if not any(clean.values()) and not sport:
            raise LedgerError(
                f"{event_id}: nothing to record. A row of NULLs would count as "
                "coverage without carrying any."
            )
        with self.conn:
            self.conn.execute(
                """INSERT INTO event_meta
                       (event_id, sport, starter, venue, weather, recorded_at)
                   VALUES (?,?,?,?,?,?)
                   ON CONFLICT(event_id) DO UPDATE SET
                       sport       = COALESCE(excluded.sport, event_meta.sport),
                       starter     = COALESCE(excluded.starter, event_meta.starter),
                       venue       = COALESCE(excluded.venue, event_meta.venue),
                       weather     = COALESCE(excluded.weather, event_meta.weather),
                       recorded_at = excluded.recorded_at""",
                (event_id, sport, clean["starter"], clean["venue"],
                 clean["weather"],
                 time.time() if recorded_at is None else recorded_at),
            )

    def event_meta(self) -> dict[str, dict]:
        """Every recorded event's metadata, keyed by event id.

        Absent keys mean absent facts. Nothing is filled in, because a filled-in
        blank groups every unrecorded event together and reports the resulting
        lump as correlation.
        """
        out: dict[str, dict] = {}
        for row in self.conn.execute("SELECT * FROM event_meta"):
            record = dict(row)
            out[record["event_id"]] = {
                field: record.get(field)
                for field in self.META_FIELDS
                if record.get(field)
            }
        return out

    def meta_coverage(self, field: str) -> tuple[int, int]:
        """Events with this field recorded, against events holding bets."""
        if field not in self.META_FIELDS:
            raise LedgerError(f"unknown metadata field {field!r}")
        total = self.conn.execute(
            "SELECT COUNT(DISTINCT event_id) AS n FROM bets"
        ).fetchone()["n"]
        covered = self.conn.execute(
            f"""SELECT COUNT(*) AS n FROM event_meta
                 WHERE {field} IS NOT NULL
                   AND event_id IN (SELECT DISTINCT event_id FROM bets)"""
        ).fetchone()["n"]
        return covered, total

    def margins(self, sport: str | None = None) -> list[int]:
        """Absolute margin of victory for every recorded game."""
        sql = "SELECT home_score, away_score FROM scores"
        args: list = []
        if sport:
            sql += " WHERE sport = ?"
            args.append(sport)
        return [abs(r["home_score"] - r["away_score"])
                for r in self.conn.execute(sql, args)]

    def totals(self, sport: str | None = None) -> list[int]:
        """Combined score for every recorded game."""
        sql = "SELECT home_score, away_score FROM scores"
        args: list = []
        if sport:
            sql += " WHERE sport = ?"
            args.append(sport)
        return [r["home_score"] + r["away_score"]
                for r in self.conn.execute(sql, args)]

    def settle(
        self,
        bet_id: int,
        *,
        closing_fair_prob: float,
        won: bool | None = None,
        profit: float | None = None,
        settled_at: float | None = None,
        result: str | None = None,
    ) -> None:
        """Attach the closing fair probability and the result to a bet.

        `closing_fair_prob` must be *devigged*. Grading against a raw closing
        price scores every bet worse than it was, by the size of the closing
        margin — a uniform bias that would look exactly like a model that is
        slightly too optimistic, which is the one failure mode calibration is
        meant to detect.
        """
        if not 0.0 < closing_fair_prob < 1.0:
            raise LedgerError(
                f"closing_fair_prob must lie in (0, 1), got {closing_fair_prob!r}"
            )
        if self.conn.execute(
            "SELECT 1 FROM bets WHERE id = ?", (bet_id,)
        ).fetchone() is None:
            raise LedgerError(f"no bet with id {bet_id}")
        if result is not None and result not in RESULTS:
            raise LedgerError(
                f"unknown result {result!r}; expected one of {', '.join(RESULTS)}"
            )
        if result is None and won is not None:
            result = "won" if won else "lost"

        with self.conn:
            self.conn.execute(
                """UPDATE bets
                      SET closing_fair_prob = ?, won = ?, profit = ?,
                          settled_at = ?, result = ?
                    WHERE id = ?""",
                (closing_fair_prob,
                 None if won is None else int(won),
                 profit,
                 time.time() if settled_at is None else settled_at,
                 result,
                 bet_id),
            )

    # ------------------------------------------------------------- reading

    def closing_price(self, event_id: str, market_type: str,
                      outcome: str, book: str | None = None) -> float | None:
        """Latest recorded closing price for one outcome."""
        sql = ("SELECT decimal_odds FROM quotes WHERE is_closing = 1 "
               "AND event_id = ? AND market_type = ? AND outcome = ?")
        args: list = [event_id, market_type, outcome]
        if book is not None:
            sql += " AND book = ?"
            args.append(book)
        sql += " ORDER BY seen_at DESC LIMIT 1"
        row = self.conn.execute(sql, args).fetchone()
        return None if row is None else float(row["decimal_odds"])

    def graded_bets(self, sport: str | None = None,
                    market_type: str | None = None) -> list[GradedBet]:
        """Settled bets, ready for `clv.report` and `clv.method_scores`.

        Only bets with a closing fair probability. An ungraded bet is not a
        zero — including it would drag every average toward nothing and make
        a small sample look more certain than it is.
        """
        sql = "SELECT * FROM bets WHERE closing_fair_prob IS NOT NULL"
        args: list = []
        if sport:
            sql += " AND sport = ?"
            args.append(sport)
        if market_type:
            sql += " AND market_type = ?"
            args.append(market_type)
        sql += " ORDER BY placed_at"

        return [
            GradedBet(
                bet_id=str(r["id"]),
                sport=r["sport"],
                market_type=r["market_type"],
                book=r["book"],
                decimal=r["decimal_odds"],
                stake=r["stake"],
                fair_prob_at_bet=r["fair_prob"],
                closing_fair_prob=r["closing_fair_prob"],
                won=None if r["won"] is None else bool(r["won"]),
                profit=r["profit"],
            )
            for r in self.conn.execute(sql, args)
        ]

    def devig_at_bet(self, bet_id: int) -> dict[str, float]:
        """What every devig method said about this bet when it was placed.

        The input to `clv.method_scores`, and the reason `record_bet` refuses
        a bet without it.
        """
        row = self.conn.execute(
            "SELECT devig_json FROM bets WHERE id = ?", (bet_id,)
        ).fetchone()
        if row is None:
            raise LedgerError(f"no bet with id {bet_id}")
        return json.loads(row["devig_json"])

    def method_candidates(self, sport: str | None = None,
                          market_type: str | None = None) -> dict[str, list[float]]:
        """Per-method probability series aligned to `graded_bets`.

        Feeds `clv.method_scores` directly. Methods missing on any bet are
        dropped rather than filled: a method scored on a subset is not
        comparable with one scored on the whole set, and the resulting
        ranking would be an artefact of which markets each method could solve.
        """
        bets = [
            b for b in self.graded_bets(sport, market_type)
            if self.devig_at_bet(int(b.bet_id))
        ]
        if not bets:
            return {}

        spreads = [self.devig_at_bet(int(b.bet_id)) for b in bets]
        common = set(spreads[0])
        for s in spreads[1:]:
            common &= set(s)
        return {m: [s[m] for s in spreads] for m in sorted(common)}

    def book_probs_at_bet(self, bet_id: int) -> dict[str, float]:
        """What each contributing book believed when this bet was placed.

        Empty for bets recorded before schema v2, and for bets whose caller
        did not supply it. Empty is the honest answer — it means nobody wrote
        the number down, not that no book contributed.
        """
        row = self.conn.execute(
            "SELECT book_probs FROM bets WHERE id = ?", (bet_id,)
        ).fetchone()
        if row is None:
            raise LedgerError(f"no bet with id {bet_id}")
        return json.loads(row["book_probs"]) if row["book_probs"] else {}

    def weights_at_bet(self, bet_id: int) -> dict:
        """Which calibration priced this bet. Empty when nobody recorded it."""
        row = self.conn.execute(
            "SELECT weights_json FROM bets WHERE id = ?", (bet_id,)
        ).fetchone()
        if row is None:
            raise LedgerError(f"no bet with id {bet_id}")
        return json.loads(row["weights_json"]) if row["weights_json"] else {}

    def book_candidates(self, sport: str | None = None,
                        market_type: str | None = None) -> list[dict[str, float]]:
        """Per-bet book probabilities, aligned to `graded_bets`.

        A *list of dicts* rather than the per-series mapping `method_candidates`
        returns, and the difference is deliberate. Every devig method has an
        answer on every market, so a method missing anywhere is a signal and
        gets dropped. Books are different: no book prices every market, so
        intersecting across bets would leave almost nothing. The per-bet shape
        keeps the raggedness visible and lets the caller decide the coverage
        rule instead of hiding it behind a fill.
        """
        return [
            self.book_probs_at_bet(int(b.bet_id))
            for b in self.graded_bets(sport, market_type)
        ]

    def latency_model(self) -> LatencyModel:
        """Rebuild per-book feed latency from every quote that carries both
        timestamps.

        Quotes missing `fetched_at` contribute nothing rather than contributing
        a zero — unknown latency is not zero latency, and a zero averaged in
        drags the estimate toward "instant", the optimistic direction.

        `fetched_at > seen_at`, strictly. Equal timestamps carry no latency
        information: they mean either an undated quote or a sub-millisecond
        feed, and those are indistinguishable at float precision. Treating them
        as a measured zero is how an undated feed talks itself into looking
        fast. Enforced here as well as in `feed.stamp` because the ledger
        should not depend on its callers getting this right."""
        model = LatencyModel()
        for r in self.conn.execute(
            """SELECT book, seen_at, fetched_at FROM quotes
                WHERE fetched_at IS NOT NULL AND fetched_at > seen_at"""
        ):
            model.observe(r["book"], float(r["fetched_at"]) - float(r["seen_at"]))
        return model

    def fill_model(self) -> FillModel:
        """Rebuild the survival model by replaying every recorded attempt."""
        model = FillModel()
        for r in self.conn.execute(
            "SELECT book, market_type, quote_age, accepted FROM attempts "
            "ORDER BY attempted_at"
        ):
            model.observe(Observation(
                book=r["book"],
                market=r["market_type"],
                age=r["quote_age"],
                accepted=bool(r["accepted"]),
            ))
        return model

    def account_heat(self, since: float | None = None) -> AccountHeat:
        """Rebuild account heat from the bet log.

        `since` defaults to the last 30 days. Heat decays on a two-hour half
        life, so older bets contribute nothing measurable and loading them is
        pure cost — but the default is a window, not a row limit, because a
        row limit would silently change the answer as the log grows.
        """
        cutoff = (time.time() - 30 * 86400) if since is None else since
        account = AccountHeat()
        for r in self.conn.execute(
            """SELECT book, stake, market_type, placed_at, since_line_move,
                      recreational, won
                 FROM bets WHERE placed_at >= ? ORDER BY placed_at""",
            (cutoff,),
        ):
            account.add(BetRecord(
                book=r["book"],
                stake=r["stake"],
                market_type=r["market_type"],
                placed_at=r["placed_at"],
                seconds_since_line_move=r["since_line_move"],
                recreational=bool(r["recreational"]),
                won=None if r["won"] is None else bool(r["won"]),
            ))
        return account

    # ------------------------------------------------------------ settings

    def set_setting(self, key: str, value) -> None:
        """Store a JSON-serialisable value — calibrated weights live here."""
        with self.conn:
            self.conn.execute(
                """INSERT INTO settings (key, value, updated_at) VALUES (?,?,?)
                   ON CONFLICT(key) DO UPDATE SET value = excluded.value,
                                                  updated_at = excluded.updated_at""",
                (key, json.dumps(value), time.time()),
            )

    def get_setting(self, key: str, default=None):
        row = self.conn.execute(
            "SELECT value FROM settings WHERE key = ?", (key,)
        ).fetchone()
        return default if row is None else json.loads(row["value"])

    def setting_age(self, key: str) -> float | None:
        """Seconds since a setting was written, or None if it never was.

        Calibrated weights are a measurement with a date. A UI showing them
        without their age repeats the mistake the jurisdiction table was fixed
        for — asserting "true now", forever.
        """
        row = self.conn.execute(
            "SELECT updated_at FROM settings WHERE key = ?", (key,)
        ).fetchone()
        return None if row is None else time.time() - float(row["updated_at"])

    # --------------------------------------------------------------- stats

    def open_positions(self, book: str | None = None,
                       sport: str | None = None) -> list[dict]:
        """Bets with money still on them.

        `profit IS NULL` — not merely ungraded. A bet can have its closing line
        recorded long before it pays out, so grading is not settlement, and a
        graded-but-unpaid bet is still money at risk.
        """
        sql, args = "SELECT * FROM bets WHERE profit IS NULL", []
        if book:
            sql += " AND book = ?"
            args.append(book)
        if sport:
            sql += " AND sport = ?"
            args.append(sport)
        sql += " ORDER BY placed_at"
        return [dict(r) for r in self.conn.execute(sql, args)]

    def known_outcomes(self, event_id: str, market_type: str) -> list[str]:
        """Every outcome ever quoted on a market.

        Used to work out what an exposure does *not* cover. Inferring the
        outcome set from your own bets is the mistake this exists to prevent:
        the outcome you did not bet is the one that hurts, and it is invisible
        in a list built from your own slips.
        """
        return sorted({
            r["outcome"] for r in self.conn.execute(
                "SELECT DISTINCT outcome FROM quotes "
                "WHERE event_id = ? AND market_type = ?",
                (event_id, market_type),
            )
        })

    def settled_bets(
        self,
        sport: str | None = None,
        market_type: str | None = None,
        book: str | None = None,
        since: float | None = None,
        until: float | None = None,
        min_decimal: float | None = None,
        max_decimal: float | None = None,
    ) -> list[dict]:
        """Financially settled bets, filtered — the input to any P&L.

        Requires `profit IS NOT NULL`, not merely a closing line. A bet can be
        CLV-graded long before it is paid out, and counting an unpaid bet as a
        zero-profit one would drag every ROI toward nothing while looking like
        a settled record.
        """
        sql = "SELECT * FROM bets WHERE profit IS NOT NULL"
        args: list = []
        for clause, value in (
            (" AND sport = ?", sport),
            (" AND market_type = ?", market_type),
            (" AND book = ?", book),
            (" AND placed_at >= ?", since),
            (" AND placed_at <= ?", until),
            (" AND decimal_odds >= ?", min_decimal),
            (" AND decimal_odds <= ?", max_decimal),
        ):
            if value is not None:
                sql += clause
                args.append(value)
        sql += " ORDER BY placed_at"
        return [dict(r) for r in self.conn.execute(sql, args)]

    def stats(self) -> dict:
        """Counts, and how far the record is from being able to teach anything."""
        def count(sql: str, *args) -> int:
            return int(self.conn.execute(sql, args).fetchone()[0])

        bets = count("SELECT COUNT(*) FROM bets")
        graded = count("SELECT COUNT(*) FROM bets WHERE closing_fair_prob IS NOT NULL")
        attempts = count("SELECT COUNT(*) FROM attempts")
        rejected = count("SELECT COUNT(*) FROM attempts WHERE accepted = 0")

        return {
            "path": str(self.path),
            "bets": bets,
            "graded": graded,
            "ungraded": bets - graded,
            "attempts": attempts,
            "rejected": rejected,
            "quotes": count("SELECT COUNT(*) FROM quotes"),
            "closing_quotes": count("SELECT COUNT(*) FROM quotes WHERE is_closing = 1"),
            "books": count("SELECT COUNT(DISTINCT book) FROM bets"),
            "imported": count("SELECT COUNT(*) FROM bets WHERE source = 'import'"),
            # Imported bets can be tracked and graded but never trained on, so
            # this is the count that decides whether calibration has anything
            # to work with.
            "trainable": count(
                "SELECT COUNT(*) FROM bets "
                "WHERE closing_fair_prob IS NOT NULL AND devig_json != '{}'"
            ),
            # 30 is the floor `clv.CLVReport.significant` enforces, so it is
            # the honest answer to "when will this tell me something".
            "graded_needed": max(0, 30 - graded),
            "can_calibrate": graded >= 30,
        }
