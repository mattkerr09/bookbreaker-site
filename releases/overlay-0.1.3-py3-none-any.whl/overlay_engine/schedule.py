"""Deciding which markets need a closing capture, and when.

The closing line is the grading truth: every CLV figure, every method score and
every calibration weight is measured against it. Capturing it is therefore the
one job in this engine where being late is not a degraded result but a wrong
one, and the failure is silent — a price recorded after the off still stores,
still grades, and still trains the model.

Three rules, each of which exists because the alternative fails quietly:

**A line taken after the start is not a closing line.** It is a live price with
a settled scoreline behind it, and grading against it would score the model as
prescient. Markets whose start has passed are refused, never captured late and
labelled `closing`.

**Every market watched, not only the ones bet.** `capture` already takes a
sport list for this reason: a closing line observed only where a bet was placed
is a biased sample of exactly the markets the model got wrong. The scheduler
keeps that property by planning from the provider's markets rather than from
open positions.

**A market with no start time cannot be scheduled at all.** Not scheduled
immediately, not scheduled at some default distance — refused, with the reason
given. A guess here produces a capture at an arbitrary moment that is then
stored as the close, and nothing downstream can tell.
"""

from __future__ import annotations

from dataclasses import dataclass, field

#: How long before the off a closing capture should be taken, in seconds. A
#: stated choice, not a measurement: close enough that the line has stopped
#: moving much, far enough out that a late run still lands before the start.
LEAD = 300.0

#: The earliest a capture counts as a close. A price half an hour out is a
#: pre-game line; storing it as the close would make every CLV figure a
#: comparison against the wrong number. Markets further out than this are not
#: errors — they are simply not due yet.
EARLIEST = 1800.0


@dataclass(frozen=True)
class Due:
    """One market that should be captured now."""

    event_id: str
    market_type: str
    sport: str
    starts_at: float
    now: float

    @property
    def seconds_to_start(self) -> float:
        return self.starts_at - self.now

    @property
    def late(self) -> bool:
        """Whether this is already past its intended lead time.

        Still due — a capture at four minutes out is better than none — but
        worth surfacing, because a pass that is habitually late is a pass whose
        schedule is wrong.
        """
        return self.seconds_to_start < LEAD

    def describe(self) -> str:
        line = (f"{self.event_id} {self.market_type} ({self.sport}): "
                f"{self.seconds_to_start / 60:.1f} min to start")
        return line + "  LATE" if self.late else line


@dataclass
class Plan:
    """What to capture now, and why everything else was left alone."""

    due: list[Due] = field(default_factory=list)
    skipped: list[tuple[str, str]] = field(default_factory=list)

    def reasons(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for _, reason in self.skipped:
            counts[reason] = counts.get(reason, 0) + 1
        return dict(sorted(counts.items(), key=lambda kv: -kv[1]))

    @property
    def late(self) -> list[Due]:
        return [d for d in self.due if d.late]

    def describe(self) -> str:
        lines = [f"{len(self.due)} market(s) due for a closing capture"]
        if self.late:
            lines.append(
                f"  {len(self.late)} of them already inside the "
                f"{LEAD / 60:.0f}-minute lead — the pass is running late")
        for reason, n in self.reasons().items():
            lines.append(f"  {n:>4} skipped: {reason}")
        return "\n".join(lines)


def plan(markets: list, now: float,
         closed: set[tuple[str, str]] | None = None) -> Plan:
    """Which of these markets need a closing capture at `now`.

    `closed` is the set of `(event_id, market_type)` already captured, so the
    pass is idempotent: running it twice in the lead window captures once. That
    matters more than it sounds, because a second capture would overwrite a
    closing line taken at the right moment with one taken later.
    """
    closed = closed or set()
    out = Plan()

    for market in markets:
        key = (market.event_id, market.market_type)
        label = f"{market.event_id} {market.market_type}"
        starts_at = getattr(market, "starts_at", None)

        if key in closed:
            out.skipped.append((label, "close already captured"))
            continue
        if starts_at is None:
            out.skipped.append((
                label,
                "no start time recorded — a close cannot be timed, and "
                "capturing at an arbitrary moment would store it as one"))
            continue
        if starts_at <= now:
            out.skipped.append((
                label,
                "already started — a line taken after the off is not a "
                "closing line"))
            continue
        if starts_at - now > EARLIEST:
            out.skipped.append((label, "not due yet"))
            continue

        out.due.append(Due(
            event_id=market.event_id, market_type=market.market_type,
            sport=market.sport, starts_at=float(starts_at), now=now))

    out.due.sort(key=lambda d: d.starts_at)
    return out


def next_run_at(markets: list, now: float,
                closed: set[tuple[str, str]] | None = None) -> float | None:
    """When the next capture pass should run, or None if nothing is pending.

    The earliest moment at which some market enters its lead window, never
    earlier than `now`. A market already inside its window makes the answer
    *now* rather than a timestamp in the past: the question is when the next
    pass should run, and "two minutes ago" is not a time anyone can sleep
    until. Callers printing a countdown would otherwise show a negative one.

    None when nothing is pending, so a scheduler that is idle can say it is
    idle rather than looking hung.
    """
    closed = closed or set()
    times = [
        float(m.starts_at) - LEAD
        for m in markets
        if getattr(m, "starts_at", None) is not None
        and (m.event_id, m.market_type) not in closed
        and float(m.starts_at) > now
    ]
    return max(now, min(times)) if times else None
