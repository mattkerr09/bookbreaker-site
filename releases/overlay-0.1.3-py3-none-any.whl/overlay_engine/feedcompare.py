"""Choosing an odds feed on measured latency instead of published claims.

Feeds are sold on a latency number, and two of the four candidates in
`docs/DATA.md` publish none at all. The way to settle it is to record a trial
period from each to a snapshot and replay them through the same engine, so the
comparison is made on your markets rather than in someone's marketing.

Three things this refuses to do, and each is a way the comparison is normally
got wrong:

**It will not rank two feeds it cannot tell apart.** Latency varies quote to
quote. Two means differing by a tenth of a second across a few hundred quotes
is not a faster feed, it is the same feed measured twice, and a ranked list
implies a finding that the sample does not contain. `distinguishable` decides,
and `compare` says "too close to call" when it must.

**It will not read an unstamped feed as an instant one.** Latency is the gap
between the book's timestamp and our receipt of it. A feed that never sends a
timestamp has that gap recorded as zero, which is the fastest possible number
and comes from having measured nothing. A feed whose latencies are all zero is
therefore reported as indistinguishable from one supplying no observation time
— never as the winner.

**It will not average away the quotes it could not measure.** A feed that
stamps a tenth of its quotes and looks quick on those is not a quick feed; it
is a feed you can check a tenth of. `stamped_share` is reported beside every
mean, because a fast number over thin coverage is the easiest way to pick the
wrong provider.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path

#: Quotes carrying a usable timestamp before a mean is worth reporting. Below
#: this the sample is a handful of stamps in a feed that mostly does not stamp,
#: and its mean describes the exception rather than the feed.
MIN_STAMPED = 30

#: Share of a feed's quotes that must carry a timestamp before its latency is
#: treated as a property of the feed rather than of the subset that stamps.
MIN_COVERAGE = 0.5

#: Two-sided 95% bar for Welch's t. A normal quantile rather than a per-degree
#: lookup: at the sample sizes a trial produces the difference is well inside
#: the noise this test is meant to be honest about.
Z = 1.96

#: Below this mean, a feed cannot be distinguished from one that supplies no
#: observation time at all. Nothing arrives in under a millisecond, so a mean
#: this small is evidence about the timestamps rather than about the wire.
UNSTAMPED_BELOW = 0.001


class CompareError(ValueError):
    """A comparison that cannot be made from what is on hand."""


@dataclass
class Sample:
    """One feed's trial, and how much of it could actually be measured."""

    provider: str
    latencies: list[float] = field(default_factory=list)
    quotes: int = 0
    path: str = ""

    @property
    def stamped(self) -> int:
        return len(self.latencies)

    @property
    def stamped_share(self) -> float:
        return self.stamped / self.quotes if self.quotes else 0.0

    @property
    def mean(self) -> float | None:
        return sum(self.latencies) / self.stamped if self.latencies else None

    @property
    def sd(self) -> float | None:
        """Sample standard deviation, or None below two observations.

        None rather than zero: one observation has no spread, and reporting
        zero would let a single quote look like a perfectly consistent feed.
        """
        if self.stamped < 2:
            return None
        mean = self.mean
        var = sum((x - mean) ** 2 for x in self.latencies) / (self.stamped - 1)
        return math.sqrt(var)

    @property
    def stderr(self) -> float | None:
        sd = self.sd
        return sd / math.sqrt(self.stamped) if sd is not None else None

    @property
    def interval(self) -> tuple[float, float] | None:
        se, mean = self.stderr, self.mean
        if se is None or mean is None:
            return None
        return (max(0.0, mean - Z * se), mean + Z * se)

    @property
    def looks_unstamped(self) -> bool:
        """Whether this feed is indistinguishable from one sending no time.

        Deliberately not called `is_unstamped`. A genuinely instant feed would
        produce the same figures, and the point is that the two cannot be told
        apart — not that we know which it is.
        """
        mean = self.mean
        return mean is not None and mean < UNSTAMPED_BELOW

    @property
    def measurable(self) -> bool:
        return (self.stamped >= MIN_STAMPED
                and self.stamped_share >= MIN_COVERAGE
                and not self.looks_unstamped)

    def why_not(self) -> str | None:
        """Why this sample cannot carry a latency claim, or None if it can."""
        if self.stamped < MIN_STAMPED:
            return (f"{self.stamped} stamped quotes, needs {MIN_STAMPED} — "
                    "too few to characterise")
        if self.stamped_share < MIN_COVERAGE:
            return (f"only {self.stamped_share:.0%} of quotes carry a "
                    f"timestamp, needs {MIN_COVERAGE:.0%} — the mean describes "
                    "the subset that stamps, not the feed")
        if self.looks_unstamped:
            return ("latency is indistinguishable from zero, which is what a "
                    "feed sending no observation time looks like — this is "
                    "evidence about its timestamps, not its speed")
        return None

    def describe(self) -> str:
        if self.mean is None:
            return f"{self.provider}: no stamped quotes at all"
        band = self.interval
        line = f"{self.provider}: {self.mean:.3f}s mean"
        if band:
            line += f", 95% {band[0]:.3f}–{band[1]:.3f}s"
        line += (f", {self.stamped}/{self.quotes} stamped "
                 f"({self.stamped_share:.0%})")
        reason = self.why_not()
        if reason:
            line += f"\n    NOT USABLE: {reason}"
        return line


def read_snapshot(path: str | Path, provider: str | None = None) -> Sample:
    """Read one recorded trial and pull every quote's latency out of it.

    Latency is the snapshot's receipt time minus the book's own timestamp,
    floored at zero the same way `Quote.latency` floors it: a feed clock
    running ahead of ours must not credit a quote with arriving before it was
    published.
    """
    path = Path(path)
    try:
        data = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise CompareError(f"cannot read {path}: {exc}") from None

    fetched_at = data.get("fetched_at")
    if fetched_at is None:
        raise CompareError(
            f"{path.name} has no fetched_at, so nothing in it can be dated")

    sample = Sample(provider=provider or data.get("provider") or path.stem,
                    path=str(path))
    for market in data.get("markets", []):
        for quote in market.get("quotes", []):
            sample.quotes += 1
            seen_at = quote.get("seen_at")
            if seen_at is None:
                continue          # unstamped: counted, never averaged as zero
            sample.latencies.append(max(0.0, float(fetched_at) - float(seen_at)))
    if not sample.quotes:
        raise CompareError(f"{path.name} holds no quotes")
    return sample


def distinguishable(a: Sample, b: Sample) -> bool:
    """Whether these two means differ by more than the samples can explain.

    Welch's t, which does not assume the two feeds have equal variance — they
    do not, since a feed's consistency is exactly one of the things being
    compared.
    """
    if not (a.measurable and b.measurable):
        return False
    sa, sb = a.stderr, b.stderr
    if sa is None or sb is None:
        return False
    se = math.sqrt(sa * sa + sb * sb)
    if se <= 0:
        return False
    return abs(a.mean - b.mean) / se > Z


@dataclass
class Comparison:
    """Every trial, ranked where ranking is honest and refused where it is not."""

    samples: list[Sample]

    @property
    def usable(self) -> list[Sample]:
        return [s for s in self.samples if s.measurable]

    @property
    def ranked(self) -> list[Sample]:
        return sorted(self.usable, key=lambda s: s.mean)

    @property
    def winner(self) -> Sample | None:
        """The fastest feed, or None when the top two cannot be told apart."""
        order = self.ranked
        if not order:
            return None
        if len(order) == 1:
            return order[0]
        return order[0] if distinguishable(order[0], order[1]) else None

    def describe(self) -> str:
        lines = [s.describe() for s in self.samples]
        lines.append("")
        order = self.ranked
        if not order:
            lines.append(
                "No feed here can carry a latency claim. That is a finding "
                "rather than a failure:")
            lines.append(
                "a provider whose quotes cannot be dated cannot be checked, "
                "and its published")
            lines.append("number is the only number you will ever have.")
            return "\n".join(lines)

        best = self.winner
        if best is not None:
            lines.append(f"Fastest: {best.provider} at {best.mean:.3f}s.")
            if len(order) > 1:
                gap = order[1].mean - best.mean
                lines.append(
                    f"  Ahead of {order[1].provider} by {gap:.3f}s, and the "
                    "samples separate them.")
        else:
            lines.append(
                f"Too close to call: {order[0].provider} and "
                f"{order[1].provider} differ by "
                f"{abs(order[1].mean - order[0].mean):.3f}s, which these "
                "samples cannot separate.")
            lines.append(
                "  Record longer trials or choose on something else. A ranking "
                "here would be a coin toss with a decimal point.")

        skipped = [s for s in self.samples if not s.measurable]
        if skipped:
            lines.append("")
            lines.append(f"{len(skipped)} feed(s) left unranked, see above.")
        return "\n".join(lines)


def compare(paths: list[str | Path]) -> Comparison:
    """Read every trial and compare them."""
    if not paths:
        raise CompareError("nothing to compare")
    return Comparison(samples=[read_snapshot(p) for p in paths])
