#!/bin/bash
# Build the two files a download button can point at, and refuse to hand over
# either one until the wheel has been installed and run somewhere that has
# never seen this checkout.
#
# That last part is the whole point. A wheel that works when you test it from
# the repo root proves nothing: `pytest.ini` puts `backend/` on the path, the
# working directory holds `data/offer_terms.csv`, and every relative path in
# the CLI resolves by accident. The failure mode packaging exists to catch —
# a module that did not get packaged, an entry point that names a function
# that moved, a default that only resolves inside the source tree — is
# invisible from here and obvious from anywhere else. So the check below
# installs into a fresh virtualenv and runs from a temporary directory.
#
# This script does not publish. It does not upload, tag, push, log in, or
# touch a package index. It writes `dist/` and prints checksums; deciding
# where those files go is a separate act, and a deliberate one.
#
#     ./scripts/release.sh
#
# Exit 0 when both artifacts are built and the wheel passed every check.
# Exit non-zero, with dist/ left in place for inspection, otherwise.
#
# Idempotent: it clears dist/ and the stale egg-info before building, so a
# second run cannot leave you holding a stale wheel from a previous version
# alongside the new one and reading the checksum off the wrong line. The wheel
# is byte-for-byte reproducible — build the same source twice and the SHA-256
# matches, which is what makes publishing a checksum worth doing. The sdist is
# not; setuptools stamps real file mtimes into the tar, so its hash identifies
# the build rather than the source. Both are printed; only the wheel's is
# stable.

set -uo pipefail
cd "$(dirname "$0")/.." || exit 2

PY="${PYTHON:-python3}"

WORK="$(mktemp -d "${TMPDIR:-/tmp}/overlay-release-XXXXXX")" || exit 2
trap 'rm -rf "$WORK"' EXIT

die() {
  echo
  echo "RELEASE FAILED: $*"
  exit 1
}

# ── a fixed timestamp, so the wheel is a function of the source ────────────
# Without this every rebuild stamps the current clock into the zip and the
# checksum changes for a wheel whose contents did not. The value is arbitrary;
# only its stability matters. The last commit's date is stable, meaningful and
# already in the tree. 315532800 is 1980-01-01, the earliest a zip can store.
if [ -z "${SOURCE_DATE_EPOCH:-}" ]; then
  SOURCE_DATE_EPOCH="$(git log -1 --format=%ct 2>/dev/null)"
  [ -z "$SOURCE_DATE_EPOCH" ] && SOURCE_DATE_EPOCH=315532800
fi
export SOURCE_DATE_EPOCH

echo "── clean ──────────────────────────────────────────"
rm -rf dist build || die "could not clear dist/"
find backend -name "*.egg-info" -type d -exec rm -rf {} + 2>/dev/null
echo "  dist/, build/ and stale egg-info removed"
echo "  SOURCE_DATE_EPOCH=$SOURCE_DATE_EPOCH"
echo

# ── a builder ──────────────────────────────────────────────────────────────
# `build` is not a runtime dependency and has no business in requirements.txt,
# so it is fetched into a throwaway environment when the interpreter running
# this does not already have it. That step needs the network exactly once per
# run; nothing after it does.
echo "── builder ────────────────────────────────────────"
if "$PY" -m build --version >/dev/null 2>&1; then
  BUILDER="$PY"
  echo "  using $($PY -m build --version)"
else
  echo "  no 'build' module on $PY — provisioning a throwaway one"
  "$PY" -m venv "$WORK/buildenv" || die "could not create the build virtualenv"
  "$WORK/buildenv/bin/python" -m pip install --quiet --upgrade pip build \
    || die "could not install 'build' (this step, and only this step, needs the network)"
  BUILDER="$WORK/buildenv/bin/python"
  echo "  using $("$BUILDER" -m build --version)"
fi
echo

# ── build ──────────────────────────────────────────────────────────────────
echo "── build ──────────────────────────────────────────"
"$BUILDER" -m build --outdir dist . >"$WORK/build.log" 2>&1 \
  || { tail -30 "$WORK/build.log"; die "the build itself failed (full log above)"; }
tail -1 "$WORK/build.log" | sed 's/^/  /'
echo

WHEELS=(dist/*.whl)
SDISTS=(dist/*.tar.gz)
[ -e "${WHEELS[0]}" ] || die "no wheel in dist/"
[ -e "${SDISTS[0]}" ] || die "no sdist in dist/"
[ "${#WHEELS[@]}" -eq 1 ] || die "${#WHEELS[@]} wheels in dist/ — expected exactly one"
[ "${#SDISTS[@]}" -eq 1 ] || die "${#SDISTS[@]} sdists in dist/ — expected exactly one"
WHEEL="${WHEELS[0]}"
SDIST="${SDISTS[0]}"

# The version the package reports, read from the package rather than from the
# filename, so a filename that disagrees with `overlay_engine.__version__`
# is caught here instead of by whoever downloads it.
VERSION="$(PYTHONPATH=backend "$PY" -c 'import overlay_engine; print(overlay_engine.__version__)' 2>/dev/null)"
[ -n "$VERSION" ] || die "could not read overlay_engine.__version__"
case "$WHEEL" in
  *"-$VERSION-"*) ;;
  *) die "wheel $WHEEL does not carry version $VERSION" ;;
esac

# ── verify ─────────────────────────────────────────────────────────────────
# A fresh virtualenv, the built wheel, and a working directory that is not the
# repo. Each case asserts on stdout as well as the exit code: a command that
# exits 0 and prints nothing is the failure a returncode check sails past.
echo "── verify (clean virtualenv, run from outside the repo) ──"
"$PY" -m venv "$WORK/verify" || die "could not create the verification virtualenv"
VENV_PY="$WORK/verify/bin/python"
"$VENV_PY" -m pip install --quiet --disable-pip-version-check --no-index "$WHEEL" \
  || die "pip could not install $WHEEL"

OVERLAY="$WORK/verify/bin/overlay"
[ -x "$OVERLAY" ] || die "the wheel installed, but no 'overlay' console script appeared on PATH"

RUNDIR="$WORK/run"
mkdir -p "$RUNDIR"
failures=0

# `check <expected substring> <command...>` — run it from RUNDIR, not here.
check() {
  local want="$1"; shift
  local label="${*##*/}"
  local out rc
  out="$(cd "$RUNDIR" && "$@" 2>"$WORK/stderr")"
  rc=$?
  if [ "$rc" -ne 0 ]; then
    echo "  FAIL   $label — exit $rc"
    head -5 "$WORK/stderr" | sed 's/^/           /'
    failures=$((failures + 1))
    return
  fi
  case "$out" in
    *"$want"*) echo "  ok     $label" ;;
    *) echo "  EMPTY  $label — stdout missing '$want'"
       failures=$((failures + 1)) ;;
  esac
}

check "usage: overlay"  "$OVERLAY" --help
check "overround"       "$OVERLAY" devig -110 -110
check "guaranteed"      "$OVERLAY" arb 2.10 2.05 --stake 1000
check "full kelly"      "$OVERLAY" kelly --odds +150 --prob 0.45
check "never limits"    "$OVERLAY" books NJ
check "realised"        "$OVERLAY" demo
# A ledger command, because the engine's storage layer creates a sqlite file on
# first use and a packaging mistake there does not show up in pure arithmetic.
check "ledger:"         "$OVERLAY" ledger --db "$RUNDIR/probe.db"
# The console script is a generated shim. `-m` proves the package itself is
# runnable, which is the fallback when PATH is not cooperating.
check "usage: overlay"  "$VENV_PY" -m overlay_engine --help
check "$VERSION"        "$VENV_PY" -c "import overlay_engine; print(overlay_engine.__version__)"

# `dependencies = []` is a claim about the artifact, so the artifact is asked.
# Anything in the fresh environment beyond overlay and pip's own furniture
# means a dependency was declared, or vendored, without being noticed.
UNEXPECTED="$("$VENV_PY" -m pip list --format=freeze 2>/dev/null \
  | cut -d= -f1 | tr 'A-Z' 'a-z' \
  | grep -vxE 'overlay|pip|setuptools|wheel|pkg-resources|pkg_resources')"
if [ -n "$UNEXPECTED" ]; then
  echo "  FAIL   third-party packages were pulled in: $(echo "$UNEXPECTED" | tr '\n' ' ')"
  failures=$((failures + 1))
else
  echo "  ok     no dependencies pulled in"
fi

echo
if [ "$failures" -ne 0 ]; then
  die "$failures check(s) failed against the freshly built wheel — dist/ left in place"
fi

# ── artifacts ──────────────────────────────────────────────────────────────
echo "── artifacts ──────────────────────────────────────"
echo "  overlay $VERSION"
echo
for f in "$WHEEL" "$SDIST"; do
  sum="$(shasum -a 256 "$f" 2>/dev/null | cut -d' ' -f1)"
  [ -n "$sum" ] || sum="$(sha256sum "$f" | cut -d' ' -f1)"
  bytes="$(wc -c <"$f" | tr -d ' ')"
  echo "  $(basename "$f")"
  echo "    sha256  $sum"
  echo "    bytes   $bytes"
done
echo
echo "RELEASE OK"
