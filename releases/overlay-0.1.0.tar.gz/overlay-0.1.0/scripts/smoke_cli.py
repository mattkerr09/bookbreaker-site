#!/usr/bin/env python3
"""Run every CLI command and confirm it exits clean with real output.

The unit suite tests the engine; nothing tested that the CLI wires it up. A
subcommand can import fine, pass every unit test underneath it, and still
crash on an f-string — and the CLI is the only part a user actually touches.

Written after a throwaway shell loop reported all seven commands failing while
every one of them worked when run by hand. A probe that has been run once and
gone red is worth as little as one that has been run once and gone green; this
one asserts on stdout as well as the exit code, so an empty success cannot pass.

    python3 scripts/smoke_cli.py
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CLI = ROOT / "backend" / "cli.py"

# Ledger cases run against a throwaway database. Without `--db` the command
# would create `~/.overlay/overlay.db` on whoever's machine ran the gate, and a
# test suite that writes to a user's real record is a test suite that will
# eventually corrupt one.
_TMP = Path(tempfile.mkdtemp(prefix="overlay-smoke-"))
SMOKE_DB = _TMP / "smoke.db"

# A tiny replayable snapshot so the capture path is exercised for real rather
# than only through its error branch.
SMOKE_CSV = _TMP / "history.csv"
SMOKE_CSV.write_text(
    "Date Placed,Sportsbook,Sport,Bet Type,Selection,Odds,Stake,Result,Profit,Bet ID\n"
    "2026-01-05 13:20:00,DraftKings,NFL,Moneyline,Chiefs ML,-110,100.00,Won,90.91,DK-1\n"
    "2026-01-05 16:05:00,DraftKings,NFL,Spread,Bills -3.5,+105,50.00,Lost,-50.00,DK-2\n"
)

SMOKE_SNAPSHOT = _TMP / "snapshot.json"
SMOKE_SNAPSHOT.write_text(json.dumps({
    "fetched_at": 10_000.0,
    "markets": [{
        "event_id": "smoke1", "sport": "nfl", "market_type": "h2h",
        "starts_at": 13_600.0,
        "quotes": [
            {"book": "pinnacle", "outcome": "home", "line": None,
             "decimal": 1.95, "seen_at": 9_994.0},
            {"book": "pinnacle", "outcome": "away", "line": None,
             "decimal": 1.95, "seen_at": 9_994.0},
        ],
    }],
}))

# Betslips, as a book prints them. SMOKE_OPEN_SLIP is the important one: it
# carries a payout ("To Win $45.45") and no result, which an earlier build of
# the parser recorded as a settled win.
SMOKE_SLIP = _TMP / "slip.txt"
SMOKE_SLIP.write_text(
    "FanDuel\nMoneyline\nBoston Celtics +145\nRisk 25.00\nWon\n"
)

SMOKE_OPEN_SLIP = _TMP / "open_slip.txt"
SMOKE_OPEN_SLIP.write_text(
    "DraftKings\nStraight\nLos Angeles Lakers -3.5 (-110)\n"
    "Wager $50.00   To Win $45.45\nPlaced 1/5/2026 1:20 PM\n"
)

SMOKE_BAD_SLIP = _TMP / "bad_slip.txt"
SMOKE_BAD_SLIP.write_text("Lakers to cover the spread\nWager $50.00\n")

# A quote snapshot with two market classes, so the offers command exercises the
# measured path rather than only the prior fallback. Props are priced wider than
# the moneyline here because that is the restriction the module exists to price.
SMOKE_OFFER_SNAPSHOT = _TMP / "offer_snapshot.json"
SMOKE_OFFER_SNAPSHOT.write_text(json.dumps({
    "fetched_at": 1_800_000_000.0,
    "markets": [
        {"event_id": "o1", "sport": "nfl", "market_type": "h2h",
         "starts_at": 1_800_050_000.0,
         "quotes": [
             {"book": "dk", "outcome": "home", "line": None,
              "decimal": 1.909, "seen_at": 1_799_999_994.0},
             {"book": "dk", "outcome": "away", "line": None,
              "decimal": 1.909, "seen_at": 1_799_999_994.0},
         ]},
        {"event_id": "o2", "sport": "nfl", "market_type": "player_prop",
         "starts_at": 1_800_050_000.0,
         "quotes": [
             {"book": "dk", "outcome": "over", "line": None,
              "decimal": 1.75, "seen_at": 1_799_999_994.0},
             {"book": "dk", "outcome": "under", "line": None,
              "decimal": 1.75, "seen_at": 1_799_999_994.0},
         ]},
    ],
}))

SMOKE_TERMS = _TMP / "offer_terms.csv"
SMOKE_TERMS.write_text(
    "book,state,rollover,eligible,min_odds,includes_deposit,fetched_at,source,note\n"
    "smokebook,NJ,10,h2h|totals,1.5,true,1799913600.0,https://example.test/terms,\n"
    "staleco,NJ,10,h2h,,true,1000000.0,https://example.test/old,\n"
    "nosource,NJ,10,h2h,,true,1799913600.0,,\n"
)

# (argv, a string that must appear in stdout). The expected substring is the
# point — exit 0 with no output is the failure mode a returncode check misses.
CASES: list[tuple[list[str], str]] = [
    (["paste", str(SMOKE_SLIP)], "read from the slip"),
    (["paste", str(SMOKE_SLIP)], "<- 'Won'"),
    (["paste", str(SMOKE_SLIP)], "implied"),
    (["paste", str(SMOKE_OPEN_SLIP)], "not found: result"),
    (["paste", str(SMOKE_OPEN_SLIP)], "Nothing written"),
    (["paste", str(SMOKE_BAD_SLIP)], "NOT A BET"),
    (["paste", str(SMOKE_SLIP), "--db", str(SMOKE_DB), "--write"],
     "--write needs --event"),
    (["paste", str(SMOKE_SLIP), "--db", str(SMOKE_DB), "--write",
      "--event", "smoke-paste-1", "--sport", "basketball"], "written to"),
    (["offers", "--terms", str(SMOKE_TERMS), "--now", "1800000000"],
     "churn hold by market class"),
    (["offers", "--terms", str(SMOKE_TERMS), "--now", "1800000000"],
     "PRIOR"),
    (["offers", "--terms", str(SMOKE_TERMS), "--now", "1800000000"],
     "smokebook/NJ"),
    (["offers", "--terms", str(SMOKE_TERMS), "--now", "1800000000"],
     "days old"),
    (["offers", "--terms", str(SMOKE_TERMS), "--now", "1800000000"],
     "no source"),
    (["offers", "--terms", str(SMOKE_TERMS), "--snapshot",
      str(SMOKE_OFFER_SNAPSHOT), "--now", "1800000000"], "measured over"),
    (["offers", "--rollover", "10", "--eligible", "h2h", "--now", "1800000000"],
     "CLEARS"),
    (["offers", "--rollover", "10", "--eligible", "player_prop",
      "--now", "1800000000"], "DOES NOT CLEAR"),
    (["offers", "--rollover", "10", "--eligible", "nonsense",
      "--now", "1800000000"], "unknown market class"),
    # `--terms` defaults to a path relative to the working directory, so it
    # resolves in a checkout and nowhere else. Installed from the wheel this is
    # the ordinary case, and it used to be a traceback.
    (["offers", "--terms", str(_TMP / "no_such_terms.csv"), "--now", "1800000000"],
     "cannot read terms feed"),
    (["middles", "44.5", "47.5", "--market", "totals"], "Real totals cluster"),
    (["middles", "44.5", "47.5", "--market", "totals"], "(prior)"),
    (["middles", "44.5", "47.5", "--market", "totals"], "window probability"),
    (["middles", "44.5", "47.5", "--market", "totals", "--db", str(SMOKE_DB)],
     "approximation"),
    (["middles", "2.5", "3.5"], "Real margins cluster"),
    (["correlation", "--db", str(SMOKE_DB)], "grouped by event"),
    (["correlation", "--db", str(SMOKE_DB)], "PRIOR"),
    (["correlation", "--db", str(SMOKE_DB), "--all-keys"], "grouped by day"),
    (["correlation", "--db", str(SMOKE_DB), "--all-keys"], "grouped by sport_day"),
    (["correlation", "--db", str(SMOKE_DB), "--live", "20"], "twelve hats"),
    (["portfolio", "--db", str(SMOKE_DB), "--bankroll", "10000"], "bankroll"),
    (["portfolio", "--db", str(SMOKE_DB), "--bankroll", "10000"], "worst case"),
    (["portfolio", "--db", str(SMOKE_DB), "--bankroll", "10000"],
     "move this floor"),
    (["portfolio", "--db", str(SMOKE_DB), "--bankroll", "10000"], "PRIOR"),
    (["portfolio", "--db", str(SMOKE_DB), "--bankroll", "0"],
     "cannot build a portfolio view"),
    (["event-meta", "--db", str(SMOKE_DB)], "coverage across events"),
    (["event-meta", "--db", str(SMOKE_DB)], "never grouped under a blank"),
    (["event-meta", "--db", str(SMOKE_DB), "--event", "smoke-ev",
      "--starter", "deGrom"], "starter=deGrom"),
    (["event-meta", "--db", str(SMOKE_DB), "--event", "smoke-ev2"],
     "nothing to record"),
    (["correlation", "--db", str(SMOKE_DB), "--key", "starter"], "PRIOR"),
    (["demo"], "realised"),
    (["demo", "--bankroll", "50000"], "kelly says"),
    (["demo"], "uncalibrated"),
    (["demo", "--db", str(SMOKE_DB)], "calibration:"),
    (["devig", "-110", "-110"], "overround"),
    (["devig", "-145", "+125", "--index", "0"], "worst case"),
    (["devig", "2.20", "3.40", "3.30"], "consensus"),
    (["arb", "2.10", "2.05", "--stake", "1000"], "round stakes"),
    (["arb", "1.91", "1.91"], "no arbitrage"),
    (["fill", "--book", "dk", "--market", "live_h2h", "--age", "12"], "half life"),
    (["fill", "--book", "fd", "--market", "totals", "--age", "0"], "prior"),
    (["fill", "--book", "dk", "--market", "h2h", "--age", "10"], "feed latency"),
    (["fill", "--book", "dk", "--market", "h2h", "--age", "10",
      "--db", str(SMOKE_DB)], "ignoring latency"),
    (["kelly", "--odds", "+150", "--prob", "0.45"], "full kelly"),
    (["kelly", "--odds", "-200", "--prob", "0.72", "--prob-low", "0.68"], "conservative"),
    (["books", "NJ"], "Never limit winners"),
    (["books", "FL"], "Hard Rock"),
    (["books", "TX"], "No legal sports betting"),
    (["books", "NH"], "DraftKings"),
    (["books", "RI"], "Sportsbook Rhode Island"),
    (["books", "MS"], "in person only"),
    (["books", "CO", "--unverified"], "UNVERIFIED"),
    (["promo", "--bonus", "1000"], "guaranteed"),
    (["promo", "--bonus", "1000", "--max-hedge", "2000"], "over your hedge limit"),
    (["promo", "--bonus", "500", "--state", "NJ"], "claim order"),
    (["ledger", "--db", str(SMOKE_DB)], "more graded bets"),
    (["ledger", "--db", str(SMOKE_DB)], "all priors"),
    (["ledger", "--db", str(SMOKE_DB)], "none calibrated"),
    (["calibrate", "--db", str(SMOKE_DB)], "0 of"),
    (["calibrate", "--db", str(SMOKE_DB), "--dry-run"], "dry run"),
    (["capture", str(SMOKE_SNAPSHOT), "--db", str(SMOKE_DB)], "captured 2"),
    (["capture", str(SMOKE_SNAPSHOT), "--db", str(SMOKE_DB), "--closing"],
     "closing quotes"),
    (["capture", str(SMOKE_SNAPSHOT), "--db", str(SMOKE_DB), "--sport", "nba"],
     "captured nothing"),
    (["capture", str(_TMP / "missing.json"), "--db", str(SMOKE_DB)],
     "cannot read snapshot"),
    (["tags", "--db", str(SMOKE_DB)], "no tagged bets"),
    (["tags", "--db", str(SMOKE_DB), "--tag", "steam"], "--tag needs --bet"),
    (["exposure", "--db", str(SMOKE_DB)], "nothing open"),
    (["exposure", "--db", str(SMOKE_DB), "--book", "dk"], "nothing open"),
    (["promos", "--db", str(SMOKE_DB)], "no promotions recorded"),
    (["promos", "--db", str(SMOKE_DB), "--add", "100", "--book", "dk",
      "--days", "2"], "recorded promo"),
    (["promos", "--db", str(SMOKE_DB)], "expiring"),
    (["promos", "--db", str(SMOKE_DB), "--conversion", "0.55"], "55%"),
    (["import", str(SMOKE_CSV), "--db", str(SMOKE_DB)], "imported 2"),
    (["import", str(SMOKE_CSV), "--db", str(SMOKE_DB)], "already present"),
    (["import", str(_TMP / "nope.csv"), "--db", str(SMOKE_DB)], "cannot import"),
    (["performance", "--db", str(SMOKE_DB)], "settled"),
    (["performance", "--db", str(SMOKE_DB), "--sport", "nfl"], "filtered"),
    (["performance", "--db", str(SMOKE_DB), "--csv", str(_TMP / "out.csv")],
     "exported to"),
    (["middles", "2.5", "3.5"], "normal approximation"),
    (["middles", "220.5", "223.5", "--low-odds", "-105", "--high-odds", "-115"],
     "break-even"),
    (["middles", "3.5", "2.5"], "over 2.5"),
    (["middles", "3.5", "3.5"], "two different lines"),
    (["middles", "2.5", "3.5", "--db", str(SMOKE_DB)], "0 so far"),
    (["grade", "--db", str(SMOKE_DB)], "no closing quotes"),
    (["grade", "--db", str(SMOKE_DB), "--allow-retail"], "still waiting"),
    (["ledger", "--db", str(SMOKE_DB)], "book weights"),
    (["ledger", "--db", str(SMOKE_DB)], "no dated quotes yet"),
    (["calibrate", "--db", str(SMOKE_DB)], "book_weights.global"),
]

# `arb` exits 1 when there is no arbitrage — that is the documented contract,
# not a failure, so it cannot be scored as one.
NONZERO_OK = {
    ("event-meta", "--db", str(SMOKE_DB), "--event", "smoke-ev2"),

    ("portfolio", "--db", str(SMOKE_DB), "--bankroll", "0"),

    ("middles", "44.5", "47.5", "--market", "totals"),
    ("middles", "44.5", "47.5", "--market", "totals", "--db", str(SMOKE_DB)),
    ("middles", "2.5", "3.5"),

    ("offers", "--rollover", "10", "--eligible", "nonsense", "--now", "1800000000"),
    ("offers", "--terms", str(_TMP / "no_such_terms.csv"), "--now", "1800000000"),

    ("paste", str(SMOKE_BAD_SLIP)),
    ("paste", str(SMOKE_SLIP), "--db", str(SMOKE_DB), "--write"),

    ("arb", "1.91", "1.91"),
    ("middles", "3.5", "3.5"),
    ("import", str(_TMP / "nope.csv"), "--db", str(SMOKE_DB)),
    ("tags", "--db", str(SMOKE_DB), "--tag", "steam"),
    ("capture", str(_TMP / "missing.json"), "--db", str(SMOKE_DB)),
}


def main() -> int:
    failures: list[str] = []

    for argv, expect in CASES:
        label = " ".join(argv)
        result = subprocess.run(
            [sys.executable, str(CLI), *argv],
            cwd=ROOT, capture_output=True, text=True, timeout=60,
        )
        allow_nonzero = tuple(argv) in NONZERO_OK

        if result.returncode != 0 and not allow_nonzero:
            failures.append(f"{label}: exit {result.returncode}\n{result.stderr.strip()[:400]}")
            print(f"  FAIL   {label}")
            continue
        if expect not in result.stdout:
            failures.append(f"{label}: stdout missing {expect!r}")
            print(f"  EMPTY  {label}")
            continue
        if result.stderr.strip():
            failures.append(f"{label}: wrote to stderr: {result.stderr.strip()[:200]}")
            print(f"  NOISY  {label}")
            continue
        print(f"  ok     {label}")

    shutil.rmtree(_TMP, ignore_errors=True)

    print()
    if failures:
        print(f"{len(failures)} of {len(CASES)} CLI commands failed:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"all {len(CASES)} CLI commands clean")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
