"""Expected value, as an interval and after the cost of not getting filled.

Two rules, both of which the category routinely breaks:

**An EV is an interval.** It inherits the devig disagreement and the
between-book disagreement from `fair.py`. A screen printing "+3.4% EV" from a
band running -0.2% to +6.1% is reporting the midpoint of its own ignorance to
one decimal place. `ev_low` is the number that decides whether to bet.

**An EV you cannot get down is zero.** The quote that produced it may already
be gone. Multiplying by the fill probability from `staleness.py` reorders the
screen — and the reorder is the product. A 6% edge on a book that pulls its
price in four seconds is worth less than a 3% edge that is still there when
you tap it, and every tool that sorts on raw EV puts them the wrong way round.
"""

from __future__ import annotations

from dataclasses import dataclass

from .fair import FairValue, fair_value
from .models import Book, Edge, Market


def ev_per_unit(decimal: float, prob: float) -> float:
    """Expected profit per unit staked.

    Stake 1 at decimal odds d: win with probability q, returning d (profit
    d-1); lose otherwise, returning 0 (profit -1). So EV = q*d - 1.
    """
    return prob * decimal - 1.0


def breakeven_prob(decimal: float) -> float:
    """The win rate at which a price is exactly break-even.

    Identical arithmetic to implied probability, and a different claim: this
    is what *you* must hit, not what the book asserts.
    """
    return 1.0 / decimal


@dataclass(frozen=True)
class EVResult:
    """An EV point estimate and the band the modelling choices allow."""

    decimal: float
    fair: FairValue
    ev: float
    ev_low: float
    ev_high: float

    @property
    def robust(self) -> bool:
        """+EV even under the least favourable fair probability."""
        return self.ev_low > 0.0

    @property
    def edge_prob(self) -> float:
        """Probability points between the fair value and the break-even rate."""
        return self.fair.prob - breakeven_prob(self.decimal)


def evaluate(decimal: float, fair: FairValue) -> EVResult:
    """Price one offer against a fair value, keeping the band."""
    return EVResult(
        decimal=decimal,
        fair=fair,
        ev=ev_per_unit(decimal, fair.prob),
        ev_low=ev_per_unit(decimal, fair.low),
        ev_high=ev_per_unit(decimal, fair.high),
    )


def fair_without(
    market: Market,
    books: dict[str, Book],
    book_key: str,
    method_weights: dict[str, float] | None = None,
    contributors: set[str] | None = None,
) -> dict[str, FairValue]:
    """The market's fair values with `book_key`'s own price left out of them.

    This is the fair value every +EV row is priced against, in one place so the
    row on the board and the "EV by book" table beside it cannot be worked out
    two different ways. A book that helped set the fair value is removed and the
    blend recomputed; a book that is not part of the blend (no complete
    two-sided market, or not a tier that sets prices) is simply compared with it.
    """
    if contributors is None:
        contributors = set(market.complete_books())
    if book_key in contributors:
        holdout = {
            b: (books.get(b) or Book(key=b, name=b)).weight
            for b in contributors
        }
        holdout[book_key] = 0.0
        return fair_value(market, books, method_weights, book_weights=holdout)
    return fair_value(market, books, method_weights)


def find_edges(
    market: Market,
    books: dict[str, Book],
    now: float,
    min_ev: float = 0.0,
    require_robust: bool = True,
    require_anchor: bool = True,
    fill_model=None,
    method_weights: dict[str, float] | None = None,
    latency_model=None,
    formula=None,
    tally: dict | None = None,
) -> list[Edge]:
    """Every +EV offer in a market, sorted by the EV you can actually realise.

    A book is never priced against a fair value it helped set — its own weight
    is removed and the blend recomputed first. Skipping that step is
    self-referential: a soft book carrying even 6% of the weight pulls the
    fair value a little toward its own price, shrinking exactly the edge you
    are trying to detect, and doing so hardest on the markets where that book
    is the only outlier and the edge is largest.

    `formula` (`formula.Formula`) replaces the engine's blend with the person's own: the fair price is the weighted
    blend of the formula books that priced both sides, left-out book and all, and a bet is kept only when enough of
    the formula's weight was there. Given None, nothing here changes. `tally`, when given, gains `below`: the book of
    each bet that was +EV against the formula's price and left out for too little of its weight (see `formula`).
    """
    edges: list[Edge] = []
    outcome_keys = market.outcomes()
    if len(outcome_keys) < 2:
        return edges

    contributors = set(market.complete_books())
    by_formula: dict = {}

    def formula_fairs(book_key: str):
        if book_key not in by_formula:
            from . import formula as formula_mod
            by_formula[book_key] = formula_mod.blended(market, books, formula, method_weights, left_out=book_key)
        return by_formula[book_key]

    for outcome in outcome_keys:
        for quote in market.quotes:
            if quote.outcome.key != outcome:
                continue

            book = books.get(quote.book) or Book(key=quote.book, name=quote.book)

            if formula is not None:
                # The person's own price: who set it is their say, so the sharp-anchor test does not apply.
                fairs, presence = formula_fairs(quote.book)
            else:
                fairs = fair_without(market, books, quote.book, method_weights, contributors)

            fv = fairs.get(outcome)
            if fv is None:
                continue
            if formula is None and require_anchor and not fv.anchored:
                continue

            net = book.net_decimal(quote.decimal)
            res = evaluate(net, fv)
            if res.ev < min_ev:
                continue
            if require_robust and not res.robust:
                continue
            if formula is not None and not presence.meets:
                if tally is not None:
                    tally.setdefault("below", []).append(quote.book)
                continue

            # Feed latency is a floor under quote age, so it belongs here and
            # not in a footnote: a quote that arrived eight seconds stale is
            # eight seconds older than it looks, and every fill probability
            # computed without that is too optimistic on exactly the fastest
            # markets.
            floor = 0.0 if latency_model is None else latency_model.typical(quote.book)
            age = quote.age(now, latency_floor=floor)
            p_fill = 1.0
            if fill_model is not None:
                p_fill = fill_model.p_fill(quote.book, market.market_type, age)

            edges.append(
                Edge(
                    kind="ev",
                    event_id=market.event_id,
                    sport=market.sport,
                    market_type=market.market_type,
                    outcome=outcome,
                    book=quote.book,
                    decimal=quote.decimal,
                    fair_prob=fv.prob,
                    ev=res.ev,
                    ev_low=res.ev_low,
                    ev_high=res.ev_high,
                    p_fill=p_fill,
                    quote_age=age,
                    note="" if (formula is not None or fv.anchored) else "no sharp anchor",
                )
            )

    edges.sort(key=lambda e: e.realised_ev, reverse=True)
    return edges
