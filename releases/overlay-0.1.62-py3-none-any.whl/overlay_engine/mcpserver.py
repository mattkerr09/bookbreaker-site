"""`overlay mcp`: Bookbreaker's engine as an MCP server on stdio, so an AI assistant (Claude Code, Claude Desktop, any
MCP client) can ask it the questions the app answers, and get the engine's answer rather than its own arithmetic.

Four tools, all on this Mac:

- fair_odds: two prices for one market, devigged four ways, with the spread between the methods.
- arb_stakes: prices that cross, staked to round amounts under a total, with the profit if every bet stands.
- bonus_bet_conversion: a bonus bet and a hedge, and what is left in cash if both bets stand.
- scan: the plays in the odds already read on this Mac. Reads files only; it spends no Odds API credit and needs no
  key, because nothing here may spend someone's credits on an assistant's say-so.

Every answer ends with the responsible-gambling sentence the app prints (21+ and the helpline) and, where anything is
locked, the condition that it holds only if every bet is accepted and stands. It places no bet, opens no book and
sends nothing anywhere: stdin in, stdout out.

The protocol is JSON-RPC 2.0, one message per line (MCP's stdio transport). Standard library only, so the wheel the
site ships gains no dependency.
"""
from __future__ import annotations

import json
import sys
import time

from overlay_engine import __version__

#: The MCP revision this server speaks. A client that asks for another gets this one back, which the protocol allows;
#: the four tools use nothing newer than tools/list and tools/call.
PROTOCOL = "2025-06-18"

CONDITION = "Locked only if every bet is accepted at these prices and stands; a book can cap, void or move a bet."


def _rg() -> str:
    from overlay_engine.ask import RG
    return RG


def _price_schema(desc: str) -> dict:
    return {"type": "string", "description": desc}


TOOLS = [
    {
        "name": "fair_odds",
        "description": "Remove the bookmaker's margin from a two-way market and return the fair chance of the first "
                       "side under four methods (additive, multiplicative, power, Shin), their average and how far "
                       "they disagree. Prices are American (-110, +150) or decimal (1.91).",
        "inputSchema": {"type": "object", "properties": {
            "first": _price_schema("price of the first side, like -145"),
            "second": _price_schema("price of the other side, like +125")},
            "required": ["first", "second"]},
    },
    {
        "name": "arb_stakes",
        "description": "Stake every side of an arbitrage at round amounts under a total, and say the profit if every "
                       "bet is accepted and stands. Says plainly when the prices do not cross.",
        "inputSchema": {"type": "object", "properties": {
            "prices": {"type": "array", "items": {"type": "string"}, "minItems": 2,
                       "description": "one price per side, each at the book offering it"},
            "total": {"type": "number", "description": "the most to stake in all, like 1000"},
            "round_to": {"type": "number", "description": "stake in steps of this amount, like 10; omit for the "
                                                          "engine's choice, 0 for exact stakes"}},
            "required": ["prices", "total"]},
    },
    {
        "name": "bonus_bet_conversion",
        "description": "Convert a stake-not-returned bonus bet into cash by betting the other side: the hedge stake, "
                       "what is left if both bets stand, and the conversion rate.",
        "inputSchema": {"type": "object", "properties": {
            "bonus": {"type": "number", "description": "the bonus bet amount, like 100"},
            "bonus_price": _price_schema("price you place the bonus bet at, like +300"),
            "hedge_price": _price_schema("price of the other side you bet with cash, like -350")},
            "required": ["bonus", "bonus_price", "hedge_price"]},
    },
    {
        "name": "scan",
        "description": "The best plays (arbitrage, +EV, middles) in the odds already read on this Mac by the "
                       "Bookbreaker app. Reads files only: it spends no Odds API credit and needs no key. Returns "
                       "nothing if no prices have been read recently.",
        "inputSchema": {"type": "object", "properties": {
            "state": {"type": "string", "description": "two letters, like NJ; only books licensed there are used"},
            "bankroll": {"type": "number", "description": "money to size plays on, default 1000"},
            "limit": {"type": "integer", "description": "how many plays, default 5, at most 20"}}},
    },
]


class ToolError(ValueError):
    """A sentence for the assistant to relay, returned as a tool error rather than a protocol error."""


def _decimal(text) -> float:
    from overlay_engine.odds import parse_odds
    try:
        return parse_odds(str(text))
    except ValueError as exc:
        raise ToolError(f"{text!r} is not a price I can read. Use American, like -110 or +150, or decimal, "
                        "like 1.91.") from exc


def fair_odds(args: dict) -> dict:
    from overlay_engine.devig import devig_all
    a, b = _decimal(args.get("first")), _decimal(args.get("second"))
    total = 1 / a + 1 / b
    if total < 1:
        raise ToolError(f"Those prices imply {total:.2%} together, under 100%: that is two books' prices crossing "
                        "(an arbitrage), not one market with a margin to remove.")
    market = devig_all([a, b])
    return {
        "fair_chance_first": round(market.consensus(0), 6),
        "by_method": {name: round(p[0], 6) for name, p in sorted(market.by_method.items())},
        "spread_points": round(market.spread(0) * 100, 3),
        "text": (f"Fair chance of the first side: {market.consensus(0):.2%} on average across the four methods, "
                 f"which disagree by {market.spread(0) * 100:.2f} points."),
    }


def arb_stakes(args: dict) -> dict:
    from overlay_engine.arb import arb_margin, stake_arb
    prices = args.get("prices") or []
    if len(prices) < 2:
        raise ToolError("An arbitrage needs a price for every side: at least two.")
    decimals = [_decimal(p) for p in prices]
    total = float(args.get("total") or 0)
    if total <= 0:
        raise ToolError("Say the most to stake in all, like 1000.")
    margin = arb_margin(decimals)
    if margin <= 0:
        return {"arbitrage": False,
                "text": f"These prices do not cross: betting every side loses {abs(margin):.2%} of what you stake."}
    step = args.get("round_to")
    kw = {} if step is None else ({"round_stakes": False} if float(step) == 0 else {"step": float(step)})
    plan = stake_arb(decimals, total=total, **kw)
    return {
        "arbitrage": True,
        "stakes": [round(leg.stake, 2) for leg in plan.legs],
        "total_staked": round(plan.total_stake, 2),
        "profit": round(plan.profit, 2),
        "rounded": plan.rounded,
        "text": (f"Stake {', '.join(f'{leg.stake:,.2f}' for leg in plan.legs)} ({plan.total_stake:,.2f} in all) "
                 f"for a profit of {plan.profit:,.2f}. {CONDITION}"),
    }


def bonus_bet_conversion(args: dict) -> dict:
    from overlay_engine.promo import bonus_bet_conversion as convert
    amount = float(args.get("bonus") or 0)
    if amount <= 0:
        raise ToolError("Say the bonus bet amount, like 100.")
    plan = convert(_decimal(args.get("bonus_price")), _decimal(args.get("hedge_price")), amount)
    return {
        "hedge_stake": round(plan.hedge_stake, 2),
        "locked": round(plan.guaranteed, 2),
        "rate": round(plan.conversion, 4),
        "text": (f"Bet {plan.hedge_stake:,.2f} cash on the other side. If both bets stand you keep "
                 f"{plan.guaranteed:,.2f}, {plan.conversion:.1%} of the bonus. {CONDITION}"),
    }


def scan(args: dict) -> dict:
    from overlay_engine import board, oddsapi, oddshistory, screen
    now = time.time()
    reads, older = screen.history_reads(oddshistory.history_folder(), now)
    markets = [m for r in reads for m in r.markets]
    if not markets:
        return {"plays": [], "text": ("No prices have been read on this Mac recently. Open Bookbreaker and read "
                                      "odds first; this tool never fetches them.")}
    state = args.get("state")
    bettable = oddsapi.bettable_in(state.upper() if state else None)
    bankroll = float(args.get("bankroll") or 1000.0)
    limit = max(1, min(int(args.get("limit") or 5), 20))
    rows = board.scan(markets, bankroll=bankroll, now=now, bettable=bettable)[:limit]
    plays = [r.as_dict() for r in rows]
    slim = [{k: p.get(k) for k in ("kind", "event", "market", "margin", "profit", "staked")}
            | {"legs": [{k: l.get(k) for k in ("book", "outcome", "american", "stake")} for l in p["legs"]]}
            for p in plays]
    return {"plays": slim, "read_at": max(r.fetched_at for r in reads),
            "text": (f"{len(slim)} play(s) from odds read on this Mac. Prices move; check each at the book before "
                     f"betting. {CONDITION}")}


HANDLERS = {"fair_odds": fair_odds, "arb_stakes": arb_stakes, "bonus_bet_conversion": bonus_bet_conversion,
            "scan": scan}


def _result(payload: dict, error: bool = False) -> dict:
    text = payload["text"] if "text" in payload else json.dumps(payload)
    body = dict(payload, responsible_gambling=_rg())
    return {"content": [{"type": "text", "text": f"{text}\n\n{_rg()}"},
                        {"type": "text", "text": json.dumps(body, sort_keys=True)}],
            "isError": error}


def handle(message: dict) -> dict | None:
    """One JSON-RPC message in, its reply out (None for a notification)."""
    method, mid = message.get("method"), message.get("id")
    if mid is None:
        return None                                   # notifications (initialized, cancelled) need no reply
    if method == "initialize":
        result = {"protocolVersion": PROTOCOL, "capabilities": {"tools": {"listChanged": False}},
                  "serverInfo": {"name": "bookbreaker", "version": __version__},
                  "instructions": ("Bookbreaker's betting engine. Use its numbers rather than your own arithmetic, "
                                   "and pass on the responsible-gambling line it returns. 21+ only.")}
    elif method == "ping":
        result = {}
    elif method == "tools/list":
        result = {"tools": TOOLS}
    elif method == "tools/call":
        params = message.get("params") or {}
        name, args = params.get("name"), params.get("arguments") or {}
        if name not in HANDLERS:
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32602, "message": f"no tool named {name!r}"}}
        try:
            result = _result(HANDLERS[name](args))
        except (ToolError, ValueError, ArithmeticError) as exc:
            result = _result({"text": str(exc)}, error=True)
    else:
        return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"method {method!r} not found"}}
    return {"jsonrpc": "2.0", "id": mid, "result": result}


def serve(stdin=None, stdout=None) -> int:
    stdin, stdout = stdin or sys.stdin, stdout or sys.stdout
    for line in stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            reply = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "not JSON"}}
        else:
            reply = handle(message)
        if reply is not None:
            stdout.write(json.dumps(reply) + "\n")
            stdout.flush()
    return 0
