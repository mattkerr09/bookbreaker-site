"""Every welcome offer on one screen, ranked by what it is actually worth.

The competitor feature this answers is OddsJam's Promo Converter and the
"best sportsbook bonuses" tables every affiliate site runs. Those tables sort
by the headline — "$350 in FanCash" beats "$150 in bonus bets" — and the
headline is the one number on the page that is not what you keep.

What you keep from a bet-and-get offer is the bonus bets *converted*: placed
on one side, hedged with cash on the other side at a second book, so that
whichever way the game goes you end with the same amount. That amount is
roughly two thirds of the face value, and the ranking by it is not the
ranking by headline.

**Every offer carries a source and the day it was read, or it does not load.**
Offers change monthly and differ by state. A stale row reads exactly like a
current one, so rows older than MAX_AGE_DAYS are listed as stale and never
priced, and the screen says so. A row past the end date its source gives is
treated the same way.

**Every offer says which states it is for, or it does not load.** One book
can run $200 in one state, $150 in the next and nothing in a third, so the
feed holds one row per distinct offer with the states it applies in. An empty
`states` cell is refused rather than read as "everywhere", and so is a state
where the catalog does not have the book operating: an offer cannot be more
legal than the book it is at.

**The two assumptions are stated, never hidden.** Conversion depends on the
odds you place the bonus at and on how much hold the best two books leave
between them. Both are priors below, both are printed beside every figure,
and `--bonus-odds` / `--hold` move them.
"""

from __future__ import annotations

import csv
import datetime as dt
from dataclasses import dataclass, field
from pathlib import Path

from .catalog import VENUES
from .promo import (bet_and_get_value, bonus_bet_conversion, profit_boost_value,
                    safety_net_value)

#: Inside the package, not beside the repo. It sat at repo/data/ and every
#: test passed — they run from source — while the built app crashed on
#: FileNotFoundError, because PyInstaller freezes code and not loose files.
#: Package-relative resolves the same way from source and from the frozen
#: bundle, and build_app.sh adds this directory explicitly.
FEED = Path(__file__).resolve().parent / "data" / "welcome_offers.csv"

#: Offers roll monthly. Past this, a row is shown as stale and not priced.
MAX_AGE_DAYS = 21

#: What a `states` cell may hold: the fifty states and DC, as two-letter codes.
US_STATES = frozenset(
    "AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN "
    "MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA "
    "WV WI WY".split()
)

#: The shapes `price` knows how to value. Anything else is refused at load,
#: because an unpriced row would reach the screen as "$0.00".
#:
#: `bet_and_get_on_win` is "bet $10, get $150 in bonus bets if it wins" (BetMGM and
#: theScore Bet in Michigan): a bet-and-get whose bonus exists only when the
#: qualifying bet wins, so it is an average and never a locked amount.
OFFER_TYPES = frozenset({"bet_and_get", "bet_and_get_on_win", "profit_boost", "safety_net"})

#: PRIOR. How often the qualifying bet wins, taken at even money. A bettor can pick a
#: favourite and win more often, at the price of a larger hedge; nothing here assumes
#: that, and it is printed beside every figure that uses it.
PRIOR_QUALIFIER_WIN = 0.5

#: PRIOR. Where the stock advice places a bonus bet: +300, decimal 4.0.
#: Longer converts a higher share of face but needs a larger cash hedge.
PRIOR_BONUS_DECIMAL = 4.0

#: PRIOR. Combined overround left between the best price on each side across
#: two books. A single book's hold is ~4.5%; line-shopping two books gets a
#: bettor to roughly 2%. Measured values replace this once the ledger has
#: captured quotes for the market being converted.
PRIOR_TWO_BOOK_HOLD = 0.02


#: The most rounding a hedge to a round amount may cost: its worst case stays within this share of the exact plan's.
ROUNDING_COST_LIMIT = 0.02


def round_hedge(amount: float, free_decimal: float, hedge_decimal_: float):
    """A hedge stake in a round amount, and what it locks if both bets stand.

    The exact hedge is calculator output ($115.50, $577.50), which nobody types. The stake is the multiple of five
    that keeps the most money, and the amount reported is the worse of the two outcomes on THAT stake, because
    rounding makes them unequal and quoting the better one describes a position the bettor does not hold. Rounding
    is a convenience only: it never chooses an amount for how it looks to a book (CEO, 2026-11-04).
    """
    exact = amount * (free_decimal - 1.0) / hedge_decimal_
    exact_floor = exact * (hedge_decimal_ - 1.0)

    def floor_for(h: float) -> float:
        return min(amount * (free_decimal - 1.0) - h, h * (hedge_decimal_ - 1.0))

    return round_stake(exact, floor_for, exact_floor)


def round_stake(exact: float, floor_for, exact_floor: float):
    """`round_hedge`'s rounding for any two-leg plan: `floor_for(h)` is the worse of the plan's two outcomes at hedge
    stake `h`. Returns the multiple of five near `exact` with the best worst case, and that worst case."""
    candidates = [5.0 * k for k in range(max(1, int(exact * 0.9 / 5)), int(exact * 1.1 / 5) + 2)]
    h = max(candidates, key=lambda h: (round(floor_for(h), 9), -abs(h - exact)))
    return h, floor_for(h)

KEEP_THE_ACCOUNT = (
    "Books set their own limits and can limit or close an account under "
    "their terms; nothing here gets around that. Read each book's terms "
    "before you start, and keep a record of every bet."
)


def hedge_decimal(bonus_decimal: float, hold: float) -> float:
    """The best price on the other side, given the combined hold."""
    implied_other = (1.0 + hold) - 1.0 / bonus_decimal
    if not 0.0 < implied_other < 1.0:
        raise ValueError("hold and bonus odds leave no room for a hedge")
    return 1.0 / implied_other


@dataclass
class Priced:
    book: str
    name: str
    offer_type: str
    headline: str
    face: float
    guaranteed: float
    expected: float
    cost: float
    conversion: float
    steps: list[str] = field(default_factory=list)
    expires_days: str = ""
    installments: int = 1
    read: str = ""
    source: str = ""
    note: str = ""
    stale: bool = False
    age_days: int = 0
    hedge_stake: float = 0.0
    #: The two-letter codes this offer applies in, sorted.
    states: list[str] = field(default_factory=list)
    #: The last day the source says the offer runs, ISO, or "" when it gives none.
    ends: str = ""
    #: Past `ends`. Listed, never priced, like a stale row.
    ended: bool = False
    #: Why this person cannot take it, set by `for_you`. "" when they can.
    ineligible: str = ""

    def as_dict(self) -> dict:
        return dict(self.__dict__)


def _days(n: str) -> str:
    return "1 day" if str(n).strip() == "1" else f"{n} days"


def parse_states(row: dict) -> frozenset[str]:
    """The states a row's offer applies in, checked against the catalog.

    Refuses an empty cell: read as "everywhere", it would show a $200 offer
    to someone in the state where the same book pays $150, or nothing. And
    refuses a state where the catalog does not have the venue operating,
    because an offer is never more legal than the book it is at.
    """
    book = row.get("book")
    codes = frozenset((row.get("states") or "").replace(",", " ").upper().split())
    if not codes:
        raise ValueError(f"{book}: no states. Offers differ by state, and a row "
                         "that does not say where it applies is not loaded")
    bad = sorted(codes - US_STATES)
    if bad:
        raise ValueError(f"{book}: {', '.join(bad)} is not a state code. Not loaded")
    # `load` refuses a book the catalog lacks before this runs; .get keeps
    # that refusal the one that fires, with its own message.
    venue = VENUES.get(book)
    outside = sorted(s for s in codes if venue is not None and not venue.available_in(s))
    if outside:
        raise ValueError(f"{book}: listed in {', '.join(outside)}, where the catalog "
                         f"does not have {venue.name} operating. Not loaded")
    return codes


def load(path: Path = FEED, today: dt.date | None = None) -> list[dict]:
    """Rows with a source, a read date and the states they apply in.

    Anything else is refused, loudly: a feed that half loads looks complete.
    """
    today = today or dt.date.today()
    out = []
    with Path(path).open() as fh:
        for row in csv.DictReader(fh):
            # An offer for a venue the catalog does not cover would render
            # with no name and no state coverage behind it. `b365` and `czr`
            # did exactly that before this check existed.
            if row.get("book") not in VENUES:
                raise ValueError(f"{row.get('book')}: not a catalog venue — not loaded")
            if not (row.get("source") or "").startswith("http"):
                raise ValueError(f"{row.get('book')}: no source URL — not loaded")
            try:
                read = dt.date.fromisoformat(row["read"])
            except (KeyError, ValueError):
                raise ValueError(f"{row.get('book')}: no read date — not loaded")
            if row.get("offer_type") not in OFFER_TYPES:
                raise ValueError(f"{row.get('book')}: offer type {row.get('offer_type')!r} "
                                 "is not one this screen can price. Not loaded")
            row["_states"] = parse_states(row)
            ends = (row.get("ends") or "").strip()
            if ends:
                try:
                    row["_ended"] = today > dt.date.fromisoformat(ends)
                except ValueError:
                    raise ValueError(f"{row.get('book')}: end date {ends!r} is not a date. Not loaded")
            row["_age"] = (today - read).days
            out.append(row)
    return out


#: Books that run no new-customer sports offer in a state, each with the page that says
#: so. Without it a book missing from the Promos list and a book never looked at read
#: the same, and a state looks thinner than it is.
NONE_FEED = Path(__file__).resolve().parent / "data" / "welcome_none.csv"


def load_none(path: Path = NONE_FEED, today: dt.date | None = None) -> list[dict]:
    """Rows recording that a book has no new-customer sports offer in some states.

    "No offer" is a claim, and it goes stale like any offer, so a row needs a source
    and the day it was read, names the states it holds in, and is listed as stale past
    MAX_AGE_DAYS. A book the catalog lacks, or a state it does not operate in, is
    refused as an offer is.
    """
    today = today or dt.date.today()
    out = []
    with Path(path).open() as fh:
        for row in csv.DictReader(fh):
            if row.get("book") not in VENUES:
                raise ValueError(f"{row.get('book')}: not a catalog venue — not loaded")
            if not (row.get("source") or "").startswith("http"):
                raise ValueError(f"{row.get('book')}: no source URL — not loaded")
            try:
                read = dt.date.fromisoformat(row["read"])
            except (KeyError, ValueError):
                raise ValueError(f"{row.get('book')}: no read date — not loaded")
            row["_states"] = parse_states(row)
            row["_age"] = (today - read).days
            row["_stale"] = row["_age"] > MAX_AGE_DAYS
            out.append(row)
    return out


def no_offer_in(rows: list[dict], state: str = "") -> list[dict]:
    """The `load_none` rows that hold in `state` (all of them with no state), as plain
    dicts for the CLI and the window."""
    st = state.strip().upper()
    return [{"book": r["book"], "name": VENUES[r["book"]].name, "states": sorted(r["_states"]),
             "read": r["read"], "source": r["source"], "note": r.get("note", ""),
             "age_days": r["_age"], "stale": r["_stale"]}
            for r in rows if not st or st in r["_states"]]


def price(rows: list[dict], *, bonus_decimal: float = PRIOR_BONUS_DECIMAL,
          hold: float = PRIOR_TWO_BOOK_HOLD) -> list[Priced]:
    """Price every offer and write the steps to collect it."""
    hedge = hedge_decimal(bonus_decimal, hold)
    plan_per_dollar = bonus_bet_conversion(bonus_decimal, hedge, 1.0)
    conversion = plan_per_dollar.guaranteed
    american = f"{(bonus_decimal - 1) * 100:+.0f}"

    priced = []
    for r in rows:
        stale = r["_age"] > MAX_AGE_DAYS
        ended = bool(r.get("_ended"))
        stake = float(r.get("qualifying_stake") or 0)
        inst = int(r.get("installments") or 1)
        states = r.get("_states") or (r.get("states") or "").replace(",", " ").upper().split()
        base = Priced(
            book=r["book"], name=VENUES[r["book"]].name, offer_type=r["offer_type"], headline=r["headline"],
            face=0.0, guaranteed=0.0, expected=0.0, cost=0.0,
            conversion=conversion, expires_days=r.get("expires_days") or "",
            installments=inst, read=r["read"], source=r["source"],
            note=r.get("note", ""), stale=stale or ended, age_days=r["_age"],
            states=sorted(states), ends=r.get("ends") or "", ended=ended,
        )
        if base.stale:
            priced.append(base)
            continue

        if r["offer_type"] == "bet_and_get":
            bonus = float(r["bonus"])
            v = bet_and_get_value(stake, hold, bonus, conversion=conversion)
            each = bonus / inst
            h_stake, h_floor = round_hedge(each, bonus_decimal, hedge)
            guaranteed = h_floor * inst - v.cost
            base.face, base.guaranteed = bonus, guaranteed
            base.expected, base.cost = guaranteed, v.cost
            base.hedge_stake = h_stake
            base.steps = [
                f"Qualify: bet ${stake:,.0f}"
                + (" in all, on the schedule its terms set," if inst > 1 else "")
                + " at this book on the lowest-hold "
                f"market you can find, and hedge the other side at a second "
                f"book. It costs about ${v.cost:,.2f}. It is a fee, not a bet.",
                (f"Convert: place each ${each:,.0f} bonus bet at {american} and "
                 f"hedge ${h_stake:,.0f} cash on the other side at another "
                 f"book. If both bets are accepted and stand, you keep at least "
                 f"${h_floor:,.2f} whichever side wins."
                 + (f" Repeat for all {inst} installments." if inst > 1 else "")),
                f"Collect: ${guaranteed:,.2f} locked from ${bonus:,.0f} face if both "
                f"bets are accepted and stand, before the bonus expires"
                + (f" ({_days(r['expires_days'])})." if r.get("expires_days") else "."),
                KEEP_THE_ACCOUNT,
            ]
        elif r["offer_type"] == "bet_and_get_on_win":
            # The bonus is a bet-and-get's, and converts like one, but it is paid only
            # if the qualifying bet wins. Hedging that bet at a second book locks the
            # qualifier's cost, not its outcome, so the bonus arrives PRIOR_QUALIFIER_WIN
            # of the time and the value is an average, never a floor.
            bonus = float(r["bonus"])
            v = bet_and_get_value(stake, hold, bonus, conversion=conversion)
            each = bonus / inst
            h_stake, h_floor = round_hedge(each, bonus_decimal, hedge)
            kept = h_floor * inst
            base.face, base.cost = bonus, v.cost
            # Never locked: the guaranteed figure is 0 whatever the bonus converts to.
            base.expected, base.guaranteed = PRIOR_QUALIFIER_WIN * kept - v.cost, 0.0
            base.hedge_stake = h_stake
            base.steps = [
                f"Qualify: bet ${stake:,.0f} at this book on a market near even money, "
                "and hedge the other side at a second book. It costs about "
                f"${v.cost:,.2f}. The bonus is paid only if this bet WINS, and the hedge "
                f"cannot change that: at even money that is about {PRIOR_QUALIFIER_WIN:.0%} "
                "of the time (a prior).",
                (f"If it wins, convert: place each ${each:,.0f} bonus bet at {american} and "
                 f"hedge ${h_stake:,.0f} cash on the other side at another book. If both "
                 f"bets are accepted and stand, you keep at least ${h_floor:,.2f} "
                 "whichever side wins."
                 + (f" Repeat for all {inst} bonus bets." if inst > 1 else "")),
                f"Expected value about ${base.expected:,.2f}: {PRIOR_QUALIFIER_WIN:.0%} of "
                f"${kept:,.2f} kept, less ${v.cost:,.2f}. Not a locked amount: the other "
                f"{1 - PRIOR_QUALIFIER_WIN:.0%} of the time you hold no bonus"
                + (f", and a bonus bet not used within {_days(r['expires_days'])} is lost."
                   if r.get("expires_days") else "."),
                KEEP_THE_ACCOUNT,
            ]
        elif r["offer_type"] == "profit_boost":
            boost = float(r["boost"])
            cap = float(r["max_stake"])
            q = (1.0 / bonus_decimal) / (1.0 + hold)
            v = profit_boost_value(cap, bonus_decimal, q, boost)
            base.face = cap * (bonus_decimal - 1.0) * boost * inst
            base.expected = v.expected * inst
            base.guaranteed = 0.0
            base.steps = [
                f"Each of {inst} tokens: bet the ${cap:,.0f} maximum at "
                f"{american} or longer. The boost multiplies profit, so it is "
                "worth most on a longshot.",
                f"Expected value about ${v.expected:,.2f} a token, "
                f"${base.expected:,.2f} across all {inst}. Not a locked amount: a "
                "boost cannot be hedged to a fixed floor in general.",
            ]
        elif r["offer_type"] == "safety_net":
            # "Second chance", "no sweat", "bet reset", "first bet back": a
            # cash bet refunded in bonus bets only if it loses. The refund is
            # the whole value, so it is priced as promo.safety_net_value
            # prices it: an average over win and loss, never a locked floor.
            cap = float(r["max_stake"])
            q = (1.0 / bonus_decimal) / (1.0 + hold)
            net = safety_net_value(cap, bonus_decimal, q, conversion)
            # `qualifying_stake` on a safety net is a separate cash bet that
            # unlocks the tokens (Hard Rock's $5), not the token bets. Hedged,
            # it costs its hold, like a bet-and-get's qualifier.
            base.cost = stake * hold
            base.face = cap * inst
            base.expected = net.expected * inst - base.cost
            each = f"Each of {inst} tokens: bet" if inst > 1 else "Bet"
            base.steps = ([
                f"Qualify: bet ${stake:,.0f} at this book on the lowest-hold market "
                "you can find, and hedge the other side at a second book. That "
                f"unlocks the tokens, for about ${base.cost:,.2f}."] if stake else []) + [
                f"{each} up to the ${cap:,.0f} cap in cash at {american} or "
                "longer. If it loses, the book refunds the stake in bonus bets. "
                "The refund is the value, and a longer price collects it more often.",
                f"Convert any refund like a bonus bet: placed at {american} and "
                f"hedged at another book, about {conversion:.0%} of it is kept if "
                "both bets are accepted and stand.",
                f"Expected value about ${net.expected:,.2f}"
                + (f" a token, ${base.expected:,.2f} across all {inst}" if inst > 1 else "")
                + f". Not a locked amount: about {1 - q:.0%} of the time the cash "
                "stake loses and you hold bonus bets instead, so size it against "
                "losing the stake, not against the average.",
            ]
        priced.append(base)

    live = [p for p in priced if not p.stale]
    stale = [p for p in priced if p.stale]
    live.sort(key=lambda p: (p.guaranteed, p.expected), reverse=True)
    return live + stale


def for_you(priced: list[Priced], have: str = "", state: str = "") -> list[Priced]:
    """The offers this person can take, first; the rest labelled, at the end.

    `priced` is `price`'s output, ranked. In a state, an offer written for
    other states is dropped: it is another state's version of a book's offer,
    not a second offer for this person. Then, as the window's My books tab
    expects:

      - a book not licensed in the state is labelled so, once;
      - a book you already have an account at is labelled so, once, because
        welcome offers are for new customers;
      - a book's second offer in the same state is labelled as an
        alternative, because a new account takes one welcome offer.

    With no state, nothing is dropped, and a book's other rows are labelled as
    differing by state, so no list or total ever counts one book twice.
    Labelled rows carry no value.
    """
    mine = {b.strip() for b in have.split(",") if b.strip()}
    st = state.strip().upper()
    legal = None
    if st:
        from .catalog import for_state
        legal = {v.key for v in for_state(st)}
    out: list[Priced] = []
    said: set[str] = set()      # books already labelled not-for-you once
    taken: dict[str, Priced] = {}  # each book's best offer for this person
    for p in priced:
        why = ""
        if legal is not None and p.book not in legal:
            why = f"not licensed in {st}"
        elif p.book in mine:
            why = ("you already have an account there; welcome offers "
                   "are for new customers")
        if why:
            # One row per book says why. A second would say the same thing.
            if p.book in said:
                continue
            said.add(p.book)
            p.ineligible = why
        elif st and st not in p.states:
            continue
        elif p.book in taken and not p.stale:
            p.ineligible = (
                f"an alternative: a new account at {p.name} takes one welcome "
                f"offer, and \"{taken[p.book].headline}\" above is worth more here"
                if st else
                f"offers at {p.name} differ by state; set your state to see which one is yours")
        elif not p.stale:
            taken[p.book] = p
        if p.ineligible:
            p.guaranteed = 0.0
            p.expected = 0.0
        out.append(p)
    return [p for p in out if not p.ineligible] + [p for p in out if p.ineligible]


def best_per_book(offers: list[Priced], state: str | None = None) -> list[Priced]:
    """Each book's single best offer, ranked by what you keep.

    A new account takes one welcome offer, so a book's alternatives and its
    other states' versions are never added to its best one. With `state`,
    only offers that apply there are considered. Without it, each book's best
    offer anywhere is returned: one row per book, but not a list any one
    person can collect in full, so do not total it as if it were. Stale,
    ended and labelled offers are left out; they carry no value.
    """
    st = (state or "").strip().upper()
    best: dict[str, Priced] = {}
    for p in offers:
        if p.stale or p.ineligible or (st and st not in p.states):
            continue
        cur = best.get(p.book)
        if cur is None or (p.guaranteed, p.expected) > (cur.guaranteed, cur.expected):
            best[p.book] = p
    return sorted(best.values(), key=lambda p: (p.guaranteed, p.expected), reverse=True)
