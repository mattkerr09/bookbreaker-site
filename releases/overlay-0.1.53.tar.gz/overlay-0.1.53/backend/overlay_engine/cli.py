"""Overlay CLI — drive the engine from a terminal.

Installed, every example below is spelled `overlay`; from a checkout it is
`python3 backend/cli.py`. The two are the same program — `backend/cli.py` is a
shim onto this module, so a bug can only be fixed in one place.

    overlay demo
    overlay devig -110 -110
    overlay devig +250 -300 --index 0
    overlay arb 2.10 2.05 --stake 1000
    overlay fill --book dk --market player_points --age 25
    overlay kelly --odds +150 --prob 0.45 --bankroll 5000
    pbpaste | overlay key set                 keep your Odds API key in the Keychain
    overlay board --feed oddsapi --estimate   what a live-odds refresh would cost
    overlay ask "who is most likely to pass for 300 yards this week"
    overlay players --stat "passing yards" --line 299.5 --week this
    overlay goal --bankroll 10 --target 200 --tickets 10
    overlay deposit MI 1000                   which books to fund in Michigan with $1,000, in what order, and how much
    overlay board --feed oddsapi --lowhold --credit-book dk   cheapest two-way pairs with a bet at DraftKings (no credits)
    overlay board --feed oddsapi --futures --futures-league nfl --estimate   what reading NFL futures would cost
    overlay board --feed oddsapi --futures-stored   the futures already read on this Mac, with every price's age (no credits)
    overlay board --feed oddsapi --alt-lines --alt-league nfl --alt-event ID --estimate   what one game's alternate lines would cost
    pbpaste | overlay key set --service anthropic    keep your Anthropic key (for Ask) in the Keychain

The demo runs a full market through the whole pipeline and prints the working,
because a screen that shows a number without its derivation cannot be checked.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from overlay_engine import (
    AccountHeat,
    Book,
    BookTier,
    FillModel,
    Market,
    Outcome,
    Quote,
    arb_margin,
    devig_all,
    fair_value,
    find_arbs,
    find_edges,
    kelly_fraction,
    parse_odds,
    shape,
    size_bet,
    stake_arb,
)
from overlay_engine.odds import decimal_to_american, hold, overround
from overlay_engine.pricing import fair_for
from overlay_engine.staleness import PRIOR_LATENCY

NOW = 1_700_000_000.0

DEFAULT_BOOKS = {
    "pinnacle": Book("pinnacle", "Pinnacle", BookTier.SHARP, limits_winners=False),
    "circa": Book("circa", "Circa", BookTier.SHARP, limits_winners=False),
    "kalshi": Book("kalshi", "Kalshi", BookTier.EXCHANGE, commission=0.0,
                   limits_winners=False),
    "betfair": Book("betfair", "Betfair", BookTier.EXCHANGE, commission=0.02,
                    limits_winners=False),
    "dk": Book("dk", "DraftKings", BookTier.RETAIL),
    "fd": Book("fd", "FanDuel", BookTier.RETAIL),
    "mgm": Book("mgm", "BetMGM", BookTier.RETAIL),
}


def _fmt_odds(decimal: float) -> str:
    a = decimal_to_american(decimal)
    return f"{a:+.0f} ({decimal:.3f})"



# --------------------------------------------------------------- machine mode

def emit(payload: dict) -> int:
    """Print a result as JSON and return 0.

    A user interface cannot parse the tables this CLI prints, and the wrong fix
    is to reimplement the arithmetic wherever the interface happens to be
    written. That would put a second copy of the devig, a second Kelly and a
    second fill model behind glass, gated by nothing, free to disagree with the
    engine the site's figures come from.

    So the engine stays the only implementation and grows a machine-readable
    mouth. Every `--json` payload carries the same numbers the human output
    prints, from the same call.
    """
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


def cmd_parlay(args: argparse.Namespace) -> int:
    """Price a parlay against what it should pay.

    The engine has had this arithmetic since parlay.py landed and the site has
    two pages arguing from it, but nothing exposed it to a person or to the
    window. A parlay is the most-searched calculation in betting and the worst
    priced, so it is the obvious thing for the app to answer.
    """
    from overlay_engine.parlay import ASSUMPTION, correlation_note, value

    decimals = [parse_odds(o) for o in args.odds]
    priced = value(decimals)
    note = correlation_note(same_game=args.same_game)

    if args.json:
        return emit({
            "command": "parlay",
            "legs": priced.legs,
            "decimals": decimals,
            "offered": priced.offered,
            "fair": priced.fair,
            "pays": priced.offered - 1.0,
            "fair_pays": priced.fair - 1.0,
            "hold": priced.hold,
            "leg_hold": priced.leg_hold,
            "multiple": priced.multiple,
            "ev": priced.ev,
            "same_game": args.same_game,
            "correlation_note": note,
            "assumption": ASSUMPTION,
            # The same answer in the money a person bets: $100 on the ticket.
            "per_100": {"wins": round(100 * (priced.offered - 1.0), 2),
                        "fair_wins": round(100 * (priced.fair - 1.0), 2),
                        "expected": round(100 * priced.ev, 2)},
            "american": round(decimal_to_american(priced.offered)),
            "fair_american": round(decimal_to_american(priced.fair)),
        })

    print(f"{priced.legs} legs: {', '.join(_fmt_odds(d) for d in decimals)}")
    print(f"  pays        {priced.offered - 1:.2f} to 1")
    print(f"  fair        {priced.fair - 1:.2f} to 1")
    print(f"  hold        {priced.hold:.1%}"
          f"   ({priced.multiple:.1f}x the {priced.leg_hold:.2%} on a single)")
    print(f"  EV per unit {priced.ev:+.2%}")
    print()
    print(f"  {ASSUMPTION}")
    print(f"  {note}")
    return 0


def cmd_contract(args: argparse.Namespace) -> int:
    """`contract`: a Kalshi or Polymarket US price, as the odds it really pays after the venue's taker fee."""
    from overlay_engine.contract import price_odds

    r = price_odds(args.price, args.venue, sport=args.sport, contracts=args.contracts)
    if args.json:
        return emit({"command": "contract", **r})
    print(r["say"])
    for label, value in r["rows"]:
        print(f"  {label}: {value}")
    for note in r["notes"]:
        print(f"  {note}")
    return 0


def cmd_kparlay(args: argparse.Namespace) -> int:
    """`kparlay`: a fair price for a parlay across games, from Kalshi's game-winner prices (no key)."""
    from overlay_engine import mktparlay

    found = mktparlay.games(leagues=tuple(args.league) if args.league else mktparlay.xvenue.LEAGUES)
    if args.list or not args.pick:
        rows = mktparlay.listing(found)
        if args.json:
            return emit({"command": "kparlay", "games": rows, "caveats": list(mktparlay.CAVEATS)})
        for r in rows:
            a, b = r["sides"]
            print(f"{r['date']} {r['league'].upper():4} {a['name']} {a['ask_text']} ({a['chance_text']}) v "
                  f"{b['name']} {b['ask_text']} ({b['chance_text']})   pick {a['pick']} or {b['pick']}")
        return 0
    try:
        r = mktparlay.price(found, args.pick, book_odds=args.book_odds, state=args.state)
    except OddsError as e:
        return emit({"command": "kparlay", "error": str(e)}) if args.json else (print(e, file=sys.stderr) or 1)
    if args.json:
        return emit({"command": "kparlay", **r})
    print(r["headline"])
    for leg in r["legs"]:
        print(f"  {leg['name']} to beat {leg['opponent']}: {leg['ask_text']}, {leg['chance_text']} "
              f"(fair {leg['fair_text']}), {leg['age_text']}")
    if r.get("book"):
        print("  " + r["book"]["say"])
    print("  " + r["state"]["message"])
    for c in r["caveats"]:
        print("  " + c)
    return 0


def cmd_crashes(args: argparse.Namespace) -> int:
    """Show crash reports, and bundle them only if asked."""
    from overlay_engine import crash

    found = crash.reports()
    native = crash.CRASH_DIR / "native.log"

    if args.bundle:
        made = crash.bundle()
        if made is None:
            print("no crash reports to bundle")
            return 0
        print(f"bundled to {made}")
        print("Attach it to an email if you want to. Nothing was sent.")
        return 0

    # faulthandler opens native.log on every launch, so the file existing
    # means nothing; only bytes in it mean a native crash happened.
    native_bytes = native.stat().st_size if native.exists() else 0

    if not found and not native_bytes:
        print("no crash reports — nothing has crashed on this machine")
        return 0

    print(f"{len(found)} crash report(s) in {crash.CRASH_DIR}")
    for path in found[-10:]:
        try:
            data = json.loads(path.read_text())
            print(f"  {path.name}")
            print(f"    {data.get('exception')}: {data.get('message', '')[:70]}")
            print(f"    version {data.get('version')} · {data.get('kind')}")
        except Exception:                                # noqa: BLE001
            print(f"  {path.name}  (unreadable)")
    if native_bytes:
        print(f"  native.log  ({native_bytes} bytes of native stacks)")
    print()
    print("These stay on this machine. `overlay crashes --bundle` zips them")
    print("so you can send them yourself; nothing here uploads anything.")
    return 0


def cmd_roundrobin(args: argparse.Namespace) -> int:
    """Every parlay of a given size, and what each has to do to pay."""
    from overlay_engine import roundrobin

    legs = [parse_odds(x) for x in args.legs]
    probs = args.probs if args.probs else None
    rr = roundrobin.build(legs, args.by, args.stake, probs, args.correlated)
    rows = rr.by_leg_count()
    ev = rr.expected_value()
    breakeven = rr.breakeven_legs()

    if args.json:
        print(json.dumps({
            "command": "roundrobin", "legs": legs, "sizes": rr.sizes,
            "tickets": rr.tickets, "stake_each": rr.stake_each,
            "total_stake": rr.total_stake, "breakeven_legs": breakeven,
            "by_leg_count": rows, "expected_value": ev,
        }, sort_keys=True))
        return 0

    print(f"{rr.tickets} tickets at {rr.stake_each:,.2f} = "
          f"{rr.total_stake:,.2f} at risk")
    print()
    print(f"  {'legs won':>9}  {'returns':>21}  {'profit':>21}")
    for row in rows:
        rng = (f"{row['returned_low']:>9,.2f}" if
               row['returned_low'] == row['returned_high']
               else f"{row['returned_low']:>9,.2f}–{row['returned_high']:,.2f}")
        prof = (f"{row['profit_low']:>9,.2f}" if
                row['profit_low'] == row['profit_high']
                else f"{row['profit_low']:>9,.2f}–{row['profit_high']:,.2f}")
        print(f"  {row['legs_won']:>9}  {rng:>21}  {prof:>21}")
    print()
    print(f"  {breakeven} of {len(legs)} legs must land before the ticket "
          f"is above water.")
    if ev:
        print(f"  Expected profit {ev['expected_profit']:,.2f} "
              f"({ev['expected_roi']:+.2%}); the same money on singles returns "
              f"{ev['same_money_on_singles']:,.2f}.")
        if ev["singles_are_better"]:
            print("  The singles are better. A round robin buys a different "
                  "shape of outcome, not a better expectation.")
        print(f"  Independence: {ev['independence']}.")
    else:
        print("  No probabilities given, so no expected value. An EV computed "
              "from the book's own prices describes its margin, not your edge.")
    return 0


def cmd_poisson(args: argparse.Namespace) -> int:
    """Scorelines from two scoring rates, and where the model stops."""
    from overlay_engine import poisson

    model = poisson.build(args.home, args.away)
    out = model.outcomes()
    totals = model.total_over(args.line)
    tops = model.top_scorelines(6)
    against = (poisson.disagreement(totals["over"], parse_odds(args.over_odds))
               if args.over_odds else None)

    if args.json:
        print(json.dumps({
            "command": "poisson", "home_lambda": args.home,
            "away_lambda": args.away, "outcomes": out, "totals": totals,
            "top_scorelines": tops, "versus_book": against,
        }, sort_keys=True))
        return 0

    print(f"Home {args.home} vs away {args.away} expected goals\n")
    print(f"  home {out['home']:>7.2%}   draw {out['draw']:>7.2%}   "
          f"away {out['away']:>7.2%}")
    print()
    print(f"  total {args.line}:  over {totals['over']:.2%}   "
          f"under {totals['under']:.2%}"
          + (f"   push {totals['push']:.2%}" if totals["pushes"] else ""))
    print()
    print("  most likely scorelines")
    for row in tops:
        print(f"    {row['score']:<6} {row['prob']:.2%}")
    if against:
        print()
        print(f"  book implies {against['book_implied']:.2%} on the over; "
              f"this model says {against['model']:.2%}")
        print(f"  edge under this model: "
              f"{against['edge_under_this_model']:+.2%}")
    print()
    print("  Poisson assumes the two sides score independently. They do not:")
    print("  real scorelines carry more draws and more blowouts than this.")
    return 0


def cmd_lowhold(args: argparse.Namespace) -> int:
    """The cheapest way to turn money over, and what it still costs."""
    from overlay_engine import lowhold

    quotes = []
    for raw in args.quotes:
        parts = raw.split(":")
        if len(parts) != 3:
            raise LedgerError(
                f"expected book:side:price, got {raw!r}")
        quotes.append(lowhold.Quote(parts[0], parts[1], parse_odds(parts[2])))

    ranked = lowhold.best(quotes, limit=args.top)
    baseline = lowhold.single_book_baseline(quotes)
    top = ranked[0]

    if args.json:
        print(json.dumps({
            "command": "lowhold",
            "turnover": args.turnover,
            "best": {"hold": top.hold, "is_arb": top.is_arb,
                     "cost": top.cost_of(args.turnover),
                     "picks": [{"book": q.book, "side": q.side,
                                "decimal": q.decimal} for q in top.picks],
                     "stakes": top.stakes(args.turnover)},
            "single_book_baseline": (
                {"hold": baseline.hold, "cost": baseline.cost_of(args.turnover),
                 "book": baseline.picks[0].book} if baseline else None),
            "ranked": [{"hold": p.hold, "cost": p.cost_of(args.turnover),
                        "picks": [f"{q.book} {q.side} {q.decimal}"
                                  for q in p.picks]} for p in ranked],
        }, sort_keys=True))
        return 0

    cost = top.cost_of(args.turnover)
    print(f"Turning over {args.turnover:,.2f}\n")
    for rank, pairing in enumerate(ranked, 1):
        legs = "  ".join(f"{q.book} {q.side} @ {q.decimal:g}"
                         for q in pairing.picks)
        marker = "  <- arbitrage" if pairing.is_arb else ""
        print(f"  {rank}. hold {pairing.hold:+.3%}   costs "
              f"{pairing.cost_of(args.turnover):>10,.2f}   {legs}{marker}")
    print()
    if baseline:
        saved = baseline.cost_of(args.turnover) - cost
        print(f"  Cheapest without leaving one book: {baseline.hold:+.3%}, "
              f"costing {baseline.cost_of(args.turnover):,.2f}.")
        print(f"  Splitting it across books saves {saved:,.2f}.")
    else:
        print("  No single book prices every side, so there is no "
              "same-book baseline to compare against.")
    print()
    if top.is_arb:
        print(f"  This one is an arbitrage: it makes "
              f"{abs(cost):,.2f} rather than costing anything.")
    elif abs(cost) < 0.01:
        # "This still costs 0.00" is true and reads like a bug. The two
        # prices cancel; say that instead of printing a rounded zero.
        print(f"  The two prices cancel: at {args.turnover:,.2f} of turnover "
              f"this costs nothing measurable.")
        print("  That is a fair market found across two books, not an edge — "
              "there is no profit in it either.")
    else:
        print(f"  This still costs {cost:,.2f}. Low hold is cheaper than the "
              f"obvious way, not free —")
        print(f"  whether the turnover is worth {cost:,.2f} is your call, and "
              f"nothing here decides it for you.")
    print()
    print("  Stakes for that pairing:")
    for leg in top.stakes(args.turnover):
        print(f"    {leg['book']:<8} {leg['side']:<8} "
              f"stake {leg['stake']:>10,.2f}   returns {leg['returns']:>10,.2f}")
    return 0


def _state_code(text: str) -> str:
    """A two-letter state (or DC), upper-cased. Anything else is refused: a typo
    must not read as a state with nothing against it."""
    from overlay_engine import catalog

    code = str(text).strip().upper()
    if code not in catalog.STATE_NAMES:
        raise argparse.ArgumentTypeError(f"{text!r} is not a state. Use its two letters, like PA.")
    return code


def _warnings(rows: list, names: dict | None = None) -> dict:
    """Mark every play of a board with what it runs into among the person's open bets (`betwarn`), and say so for
    the board. Reads the ledger file without opening it for writing and removes no play."""
    from overlay_engine import betwarn
    from overlay_engine.ledger import home
    return betwarn.attach(rows, home() / "overlay.db", names)


def _hiding(rows: list, args: argparse.Namespace, now, complete: bool = True) -> dict:
    """Give every play the block the window hides it by (`hidden.mark`), and, when the window sent its hidden list on
    a read the person started, say which entries to drop (`hidden.apply`). Removes no play and changes no result."""
    from overlay_engine import hidden as hidden_mod
    hidden_mod.mark(rows)
    if getattr(args, "hidden_error", None):
        return hidden_mod.refused(args.hidden_error)
    return hidden_mod.apply(rows, getattr(args, "hidden_entries", None) or [], now, complete)


def _held_back(args: argparse.Namespace) -> frozenset:
    """The keys of the plays the person hid, for the alert check, or nothing."""
    from overlay_engine import hidden as hidden_mod
    return hidden_mod.keys_of(getattr(args, "hidden_entries", None) or [])


def _board_live(args: argparse.Namespace) -> int:
    """`board --live`: the same game on Kalshi and on Polymarket US, priced after
    both venues' fees at the size resting at each price.

    The only place the board touches a network, and only because the person
    turned Live prices on (the window passes --live only then). A pair is
    listed only when it pays and only where both venues are open: with --state
    for a state either venue is restricted in, nothing is read at all, and with
    no --state the venues are read and no pair is listed. When nothing pays it
    says so, and counts what it checked, rather than listing the nearest misses
    as though they were plays.
    """
    import time

    from overlay_engine import boardfilter, catalog, filtercounts, pubfeed, xvenue

    got = xvenue.scan(pubfeed.urllib_fetcher, bankroll=args.bankroll,
                      min_margin=args.min_margin / 100.0, state=args.state)
    if args.json:
        xv = got.as_dict()
        payload = {
            "command": "board", "source": got.source(), "live": True,
            "markets_scanned": got.kalshi_games + got.polymarket_us_games,
            "bankroll": args.bankroll, "rows": [],
            "note": "Live pairs are in cross_venue.pairs; rows holds the sportsbook board only.",
            "cross_venue": xv,
        }
        payload["warnings"] = _warnings(xv["pairs"])
        xv["filters"] = filtercounts.of_rows(got.pairs, args.min_margin, got.under_margin,
                                             payload["warnings"]["by_code"])
        payload["hidden"] = _hiding(xv["pairs"], args, got.read_at if got.read_anything else None,
                                    complete=not got.errors)
        setting = getattr(args, "alert_setting", None)
        if getattr(args, "alert_error", None):
            from overlay_engine import alerts as alerts_mod
            payload["alerts"] = alerts_mod.refused(args.alert_error)
        if setting:
            # Only a read that saw the venues and was allowed to list pairs can say what is new.
            from overlay_engine import alerts as alerts_mod
            if not got.ran:
                payload["alerts"] = alerts_mod.skipped(setting, "nothing was read from either venue.")
            elif not got.read_anything:
                payload["alerts"] = alerts_mod.skipped(setting, "neither venue could be read.")
            elif got.needs_state:
                payload["alerts"] = alerts_mod.skipped(setting, "pick your state to see pairs you can place.")
            else:
                payload["alerts"] = alerts_mod.check(xv["pairs"], setting, "live", got.read_at,
                                                     complete=not got.errors, hidden=_held_back(args))
        # Narrowed and sorted last: alerts and the hidden list above speak for every pair the read found.
        order, payload["board_filters"] = boardfilter.apply(xv["pairs"], args.bf_spec,
                                                            got.read_at if got.read_anything else None,
                                                            args.bf_problem)
        xv["pairs"] = [xv["pairs"][i] for i in order]
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0 if got.read_anything or not got.ran else 1

    print(f"source: {got.source()}")
    if not got.ran:
        print("\nNothing was read from either venue.")
        return 0
    print(f"read {time.strftime('%H:%M:%S', time.localtime(got.read_at))}; fees are the venues' published "
          f"formulas, read {xvenue.FEES_READ}.\n")
    for why in got.errors:
        print(f"not read: {why}")
    if got.errors:
        print()
    for note in got.notes:
        print(note)
    if got.notes:
        print()
    if not got.read_anything:
        print("Live prices could not be read from either venue. Nothing is shown rather than a stale guess.")
        return 1
    if got.needs_state:
        print(f"{got.message} Add --state with your two letters, like --state PA.")
        print(f"{got.matched} games are listed on both venues; whether you can place a pair depends on where you are.")
        return 0
    if not got.pairs:
        print("No pair pays right now at the size on offer.")
        print(f"{got.matched} games are listed on both venues; after both venues' fees none leaves a profit")
        print("at the size resting at those prices. Gaps open when one side moves first, so check again later.")
        return 0

    pairs = _narrowed(got.pairs, [p.as_dict() for p in got.pairs], args, got.read_at)
    if not pairs:
        print("Board filters leave no pair.")
        return 0
    print(f"{len(pairs)} pair(s) locked if both bets are accepted and stand, best return first:\n")
    for r in pairs:
        play = " (game under way)" if r.in_play else ""
        print(f"{r.profit:+9.2f}  {r.margin:>6.2%}  {r.league.upper()}  {r.game}{play}")
        for leg in r.legs:
            print(f"{'':>20}{catalog.VENUES[leg['venue']].name:<14} {leg['name']} to win at {leg['cents']:.1f}c: "
                  f"{leg['contracts']:,} {leg['unit']} of {leg['on_offer']:,} on offer, "
                  f"${leg['cost']:,.2f} + ${leg['fee']:.2f} fee")
        print(f"{'':>20}sized by {r.limited_by}; prices read {r.age:.0f}s ago")
    print("\nCheck the amount on offer before you bet. " + got.pairs[0].note)
    return 0


def _book_balances() -> dict:
    """The balances typed in Your books, {book: amount}, read without opening the ledger for writing."""
    from overlay_engine import wallet
    from overlay_engine.ledger import home
    return wallet.read_file(home() / "overlay.db")


def _leg_opens(shown: list, args: argparse.Namespace) -> None:
    """"Open <book>" on each play for the sportsbooks licensed in the chosen state, with the compliance line
    (offerlink.leg_opens; the CEO's ruling of 2026-10-31)."""
    from overlay_engine.offerlink import leg_opens
    leg_opens(shown, getattr(args, "state", None))


def _stake_ev(shown: list, args: argparse.Namespace) -> None:
    """A suggested stake on every +EV row (kelly.stake_rows): on that book's balance in Your books when one is typed,
    otherwise on the saved bankroll."""
    from overlay_engine.kelly import stake_rows
    from overlay_engine.wallet import book_name, short_rows
    balances = _book_balances()
    short_rows(shown, balances)              # an arb or middle bet above a book's balance, and the plan that fits
    if getattr(args, "kelly_bankroll", None) or balances:
        stake_rows(shown, getattr(args, "kelly_bankroll", None), getattr(args, "kelly_fraction", 0.25), balances,
                   {b: book_name(b) for b in balances})


def cmd_board(args: argparse.Namespace) -> int:
    """Every play on one board, best first.

    The screen someone who has used OddsJam or AVO expects to open to. It
    exists to answer "what should I bet right now", which is the question a
    bettor actually has, rather than "what is this price worth", which is the
    one every other command here answers.

    **Where the prices come from is printed every time.** With `--snapshot`
    they are recorded prices from that file. Without one, there is a single
    demonstration market and the board says so — because a board full of
    plausible rows is an instruction to go and stake real money on markets
    that do not exist, and that is the most expensive thing this program
    could get wrong.
    """
    from overlay_engine import board as board_mod
    from overlay_engine import filtercounts
    from overlay_engine import preset as preset_mod

    clash = _board_source_clash(args)
    if clash:
        print(json.dumps({"command": "board", "error": clash}) if args.json else clash,
              file=sys.stdout if args.json else sys.stderr)
        return 2

    # The alert setting is checked here, and a bad one does not stop the read: the person pressed it, and a typo in
    # an alert must not take the board away. It is said in the answer's `alerts` block instead.
    args.alert_setting = None
    args.alert_error = None
    if getattr(args, "alerts", None) is not None:
        from overlay_engine import alerts as alerts_mod
        try:
            args.alert_setting = alerts_mod.parse(args.alerts)
        except alerts_mod.AlertError as exc:
            args.alert_error = str(exc)

    # The hidden list is checked the same way: a list the engine cannot read is said in the answer's `hidden` block
    # and the board is still whole.
    args.hidden_entries = None
    args.hidden_error = None
    if getattr(args, "hidden", None) is not None:
        from overlay_engine import hidden as hidden_mod
        try:
            args.hidden_entries = hidden_mod.parse(args.hidden)
        except hidden_mod.HiddenError as exc:
            args.hidden_error = str(exc)

    # The board filters are checked the same way. In the window a price typed wrongly is no filter and a sentence in
    # the answer's `board_filters`; on the command line it is refused, so a script never runs on a filter it lost.
    from overlay_engine import boardfilter
    args.bf_spec, args.bf_problem = boardfilter.from_args(args)
    if args.bf_problem and not args.json:
        print(args.bf_problem, file=sys.stderr)
        return 2

    # The EV formula is checked the same way: text the engine cannot read is no formula and a one-line notice, and the
    # board is still whole.
    from overlay_engine import formula as formula_mod
    args.formula_setting = None
    if getattr(args, "formula", None) is not None or getattr(args, "formula_paused", False):
        args.formula_setting = formula_mod.parse(getattr(args, "formula", None),
                                                 paused=bool(getattr(args, "formula_paused", False)))

    if getattr(args, "live", False):
        return _board_live(args)

    if getattr(args, "feed", None):
        return _board_oddsapi(args)

    if args.snapshot:
        from overlay_engine.feed import ReplayProvider
        provider = ReplayProvider(args.snapshot)
        markets = [m for sport in provider.sports() for m in provider.fetch(sport)]
        source = f"recorded snapshot {args.snapshot}"
        live = False
    else:
        markets = [_demo_market()]
        source = "ONE DEMONSTRATION MARKET — no feed is connected"
        live = False

    # Recorded prices are aged against the recording, not against the wall
    # clock. Scanning a snapshot from last Tuesday with now=time.time() made
    # every quote 87,109,150 seconds old and every fill zero — an age column
    # that is nonsense is worse than no age column, because the whole product
    # argument is that age is what you are not being told.
    stamps = [q.seen_at for m in markets for q in m.quotes
              if getattr(q, "seen_at", None)]
    as_of = max(stamps) if stamps else None

    kinds = tuple(args.kind) if args.kind else board_mod.KINDS
    stats = {}
    setting = args.formula_setting
    rows = board_mod.scan(markets, DEFAULT_BOOKS, bankroll=args.bankroll,
                          min_margin=args.min_margin / 100.0, now=as_of,
                          kinds=kinds, min_ev=args.min_ev / 100.0, detail=args.json, stats=stats,
                          formula=setting.formula if setting else None)

    if args.json:
        shown = [r.as_dict() for r in rows]
        _stake_ev(shown, args)
        _leg_opens(shown, args)
        from overlay_engine import hidden as hidden_mod
        # The demonstration market is never read, so there is no hidden list to apply to it.
        hidden_mod.mark(shown, {k: b.name for k, b in DEFAULT_BOOKS.items() if b.name})
        warned = _warnings(shown, {k: b.name for k, b in DEFAULT_BOOKS.items() if b.name})
        extra = {"formula": formula_mod.board_block(setting, stats)} if setting else {}
        # Narrowed and sorted last, so the counts, the warnings and the preset speak for every play the read found.
        order, narrowed = boardfilter.apply(shown, args.bf_spec, as_of, args.bf_problem)
        print(json.dumps({
            **extra,
            "command": "board", "source": source, "live": live,
            "markets_scanned": len(markets), "bankroll": args.bankroll,
            "rows": [shown[i] for i in order], "board_filters": narrowed, "warnings": warned,
            # How many plays each filter would leave, said by the engine before anything is changed.
            "filters": filtercounts.of_rows(rows, args.min_margin, stats.get("under_margin", 0), warned["by_code"],
                                            formula_mod.counts(setting, stats) if setting else None),
            # What the Recommended preset does to these rows, said by the engine. Every row is still sent: the
            # window shows or hides them by their own `recommended` flag.
            "preset": preset_mod.summary([r.preset_misses for r in rows]),
        }, indent=2, sort_keys=True))
        return 0

    print(f"source: {source}")
    _print_formula(setting, stats)
    print(f"scanned {len(markets)} market(s) at a {args.bankroll:,.0f} bankroll")
    rows = _narrowed(rows, [r.as_dict() for r in rows], args, as_of)
    print()
    return _print_board(rows, kinds, empty_hint=FILTERED_HINT if args.bf_spec.active else None)


FILTERED_HINT = "your board filters left nothing: run it again without them to see the plays they hid."


def _narrowed(rows: list, views: list, args: argparse.Namespace, now) -> list:
    """The board's rows after the person's filters and sort (`boardfilter`), with the one line that says what they
    left. `views` is each row as a dict, in the same order."""
    from overlay_engine import boardfilter
    order, block = boardfilter.apply(views, args.bf_spec, now)
    if block["sentence"]:
        print(block["sentence"])
    return [rows[i] for i in order]


def _print_formula(setting, stats) -> None:
    """The EV formula's line on a printed board: what it was, or why it was not used."""
    if setting is None:
        return
    from overlay_engine import formula as formula_mod
    if setting.notice:
        print(setting.notice)
    line = formula_mod.board_block(setting, stats)["sentence"]
    if line:
        print(line)


def _print_board(rows, kinds, empty_hint=None) -> int:
    """The board as a table. One place, so the demo, a snapshot and a live feed
    cannot word the same row three ways."""
    from overlay_engine import board as board_mod

    if not rows:
        asked = ", ".join(kinds)
        print(f"nothing on the board ({asked}).")
        if empty_hint == FILTERED_HINT:
            print(FILTERED_HINT.capitalize())
            return 0
        print("That is the normal state of a small board, not a failure —")
        print(empty_hint or "connect a feed with --snapshot to scan real markets.")
        return 0

    # An arb's profit is locked only if every bet is accepted at the price shown
    # and stands; a +EV bet's is an average over many bets and can lose every
    # time; a middle's is a payoff that needs the result to land in a window.
    # Printing one PROFIT column across all three would imply they are the same
    # kind of number, which is the most misleading thing a mixed board can do.
    basis = {"arb": "locked if both bets stand", "ev": "expected", "middle": "if it lands"}
    width = max(len(v) for v in basis.values())
    print(f"{'KIND':<7}{'RETURN':>9}  {'EDGE':>7}  {'FILL':>5}  {'AGE':>5}  PLAY")
    for row in rows:
        legs = "  vs  ".join(
            f"{leg.get('book_name', leg['book'])} {leg['outcome']} @{leg['decimal']:.3f} "
            f"for {leg['stake']:,.2f}" for leg in row.legs)
        print(f"{row.kind:<7}{row.profit:>9,.2f}  {row.margin:>6.2%}  "
              f"{row.p_fill:>5.0%}  {row.age:>4.0f}s  {row.event} {row.market}")
        print(f"{'':<7}{basis[row.kind]:>{width}}  {legs}")

    counts = {k: sum(1 for r in rows if r.kind == k) for k in board_mod.KINDS}
    print(f"\n{len(rows)} play(s): "
          + ", ".join(f"{n} {k}" for k, n in counts.items() if n))
    print("An arb's return is locked only if both bets are accepted at the prices shown")
    print("and both stand. A +EV return is an AVERAGE over many bets and can lose every")
    print("one of them. A middle pays only if the result lands in the window. They are")
    print("not the same number.")
    return 0


def _board_source_clash(args: argparse.Namespace):
    """One board has one source of prices. Two asked for at once, or the live-odds
    choices given with no live-odds feed, is a mistake worth saying out loud: the
    quiet alternative is a board built from a source other than the one the person
    thought they chose, and every row on it is an instruction to stake money."""
    feed = getattr(args, "feed", None)
    if getattr(args, "alerts", None) is not None:
        if not args.json:
            return "--alerts is for the window and needs --json."
        if not (feed or getattr(args, "live", False)):
            return ("--alerts only works after a read you start: add --live or --feed oddsapi. "
                    "The demonstration market never alerts.")
        if getattr(args, "screen", False) or getattr(args, "lowhold", False) or args.estimate:
            return ("--alerts only works after a read of prices. --screen, --lowhold and --estimate read "
                    "nothing, so they never alert.")
    if getattr(args, "hidden", None) is not None:
        if not args.json:
            return "--hidden is for the window and needs --json."
        if not (feed or getattr(args, "live", False)):
            return ("--hidden only works after a read you start: add --live or --feed oddsapi. "
                    "The demonstration market is never read.")
        if getattr(args, "screen", False) or getattr(args, "lowhold", False) or args.estimate:
            return ("--hidden only works after a read of prices. --screen, --lowhold and --estimate read "
                    "nothing, so there is nothing to drop from the list.")
    if getattr(args, "formula", None) is not None or getattr(args, "formula_paused", False):
        if getattr(args, "live", False):
            return ("--formula only works on sportsbook odds, a recorded snapshot or the demonstration board. "
                    "Live prices pairs have no fair price to blend.")
        if getattr(args, "screen", False) or getattr(args, "lowhold", False):
            return ("--formula only works on a read of prices. --screen and --lowhold lay out the prices already read "
                    "and price nothing against a fair price.")
        if getattr(args, "formula_paused", False) and getattr(args, "formula", None) is None:
            return "--formula-paused only works with --formula."
    from overlay_engine import boardfilter as _boardfilter
    if _boardfilter.flags_given(args):
        if (args.estimate or getattr(args, "screen", False) or getattr(args, "lowhold", False)
                or _futures_flags(args) or _alt_flags(args)):
            return ("The board filters (--sort, --min-price, --max-price, --game-state, --within, --league-off, "
                    "--bet-type-off, --min-window) work on the board of plays. --estimate, --screen, --lowhold, "
                    "futures and alternate lines have no board to filter.")
    futures_clash = _futures_clash(args, feed) or _alt_clash(args, feed)
    if futures_clash:
        return futures_clash
    if feed and args.snapshot:
        return ("Choose one source of prices: --feed oddsapi reads live sportsbook odds, "
                "--snapshot reads a recorded file.")
    if feed and getattr(args, "live", False):
        return ("Choose one source of prices: --live reads Kalshi and Polymarket, "
                "--feed oddsapi reads sportsbook odds.")
    if not feed and (args.sport or args.region or args.market or args.estimate
                     or _props_flags(args) or getattr(args, "screen", False)):
        return ("--sport, --region, --market, --estimate, --screen and the player-prop choices "
                "only work with --feed oddsapi.")
    if feed and _props_flags(args) and not getattr(args, "props", False):
        return ("Player props are off unless you ask for them: add --props to read them "
                "(they cost far more than the main odds, and the estimate says how much).")
    if getattr(args, "screen", False) and (args.sport or args.region or args.market or args.estimate
                                           or _props_flags(args) or getattr(args, "props", False)):
        return ("--screen only lays out the prices already read on this Mac, so it takes no league, region or bet "
                "type to read, and costs nothing.")
    lowhold = getattr(args, "lowhold", False)
    if (getattr(args, "credit_book", None) or getattr(args, "amount", None) is not None) and not lowhold:
        return "--credit-book and --amount only work with --lowhold."
    if any(getattr(args, k, None) is not None for k in ("credit_min", "credit_max", "other_min", "other_max")) \
            and not lowhold:
        return "--credit-min, --credit-max, --other-min and --other-max only work with --lowhold."
    if lowhold and not feed:
        return "--lowhold only works with --feed oddsapi."
    if lowhold and getattr(args, "screen", False):
        return "Choose one view of the prices already read: --screen is the grid of books, --lowhold the cheapest pairs."
    if lowhold and (args.sport or args.region or args.market or args.estimate
                    or _props_flags(args) or getattr(args, "props", False)):
        return ("--lowhold only works from the prices already read on this Mac, so it takes no league, region or bet "
                "type to read, and costs nothing.")
    return None


def _futures_flags(args: argparse.Namespace) -> bool:
    return bool(getattr(args, "futures", False) or getattr(args, "futures_stored", False)
                or getattr(args, "futures_league", None) or getattr(args, "futures_region", None))


def _alt_flags(args: argparse.Namespace) -> bool:
    return bool(getattr(args, "alt_lines", False) or getattr(args, "alt_stored", False)
                or getattr(args, "alt_league", None) or getattr(args, "alt_event", None)
                or getattr(args, "alt_market", None) or getattr(args, "alt_region", None))


def _alt_clash(args: argparse.Namespace, feed):
    """Alternate lines are read one game at a time and on their own, like futures."""
    if not _alt_flags(args):
        return None
    reading, opening = getattr(args, "alt_lines", False), getattr(args, "alt_stored", False)
    if not feed:
        return "--alt-lines, --alt-stored and their choices only work with --feed oddsapi."
    if not (reading or opening):
        return ("Alternate lines are off unless you ask for them: add --alt-lines to read one game (it costs "
                "credits, and --estimate says how many) or --alt-stored to open one already read.")
    if reading and opening:
        return ("Choose one: --alt-lines reads the game (it spends credits), --alt-stored only opens the one already "
                "read on this Mac (it costs nothing).")
    if not (getattr(args, "alt_league", None) and getattr(args, "alt_event", None)):
        return "Name the game: --alt-league (like nfl) and --alt-event (its Odds API id, from the Odds screen)."
    if opening and (args.estimate or getattr(args, "alt_market", None) or getattr(args, "alt_region", None)):
        return "--alt-stored reads nothing, so there is nothing to choose or price. Add --alt-lines to read."
    if (args.sport or args.region or args.market or _props_flags(args) or _futures_flags(args)
            or getattr(args, "screen", False) or getattr(args, "lowhold", False)):
        return ("Alternate lines are read on their own: --sport, --region, --market, --props, --futures, --screen "
                "and --lowhold belong to the other reads.")
    if getattr(args, "alerts", None) is not None or getattr(args, "hidden", None) is not None:
        return "--alerts and --hidden are for the board of plays, not for alternate lines."
    return None


def _futures_clash(args: argparse.Namespace, feed):
    """Futures are an opt-in group of their own, like player props: off unless asked for, and a read of them
    reads futures only, so the main-odds choices mean nothing beside them."""
    if not _futures_flags(args):
        return None
    reading, opening = getattr(args, "futures", False), getattr(args, "futures_stored", False)
    if not feed:
        return "--futures, --futures-stored and the futures choices only work with --feed oddsapi."
    if (getattr(args, "futures_league", None) or getattr(args, "futures_region", None)) and not reading:
        return ("Futures are off unless you ask for them: add --futures to read them (each futures market costs "
                "a credit per region, and --estimate says how much).")
    if reading and opening:
        return ("Choose one: --futures reads the leagues you pick (it spends credits), --futures-stored only opens "
                "the futures already read on this Mac (it costs nothing).")
    if (args.sport or args.region or args.market or _props_flags(args)
            or getattr(args, "screen", False) or getattr(args, "lowhold", False)):
        return ("Futures are read on their own: use --futures-league and --futures-region to choose them. "
                "--sport, --region, --market, --props, --screen and --lowhold belong to the main odds.")
    if opening and args.estimate:
        return "--futures-stored reads nothing, so there is no cost to estimate. Add --futures to price a read."
    if getattr(args, "alerts", None) is not None or getattr(args, "hidden", None) is not None:
        return "--alerts and --hidden are for the board of plays, not for futures."
    return None


def _props_flags(args: argparse.Namespace) -> bool:
    return bool(getattr(args, "props", False) or getattr(args, "prop", None)
                or getattr(args, "prop_region", None) or getattr(args, "prop_games", None) is not None)


def _board_oddsapi(args: argparse.Namespace) -> int:
    """`board --feed oddsapi`: the board on live sportsbook odds, read with the
    person's own key.

    The order is the promise. What the refresh will cost is worked out and said
    first, from the choices alone (no key, no network). Only then is the key
    read from the Keychain and the odds fetched, and what it actually cost is
    read back off the response headers. The key is read here, handed to
    `refresh()` (which gives it to the fetcher and no one else) and dropped: it
    is not printed, not returned, not in the JSON, and in no error message.
    """
    from overlay_engine import FillModel, LatencyModel
    from overlay_engine import board as board_mod
    from overlay_engine import boardfilter, keystore, oddsapi, oddshistory
    from overlay_engine import filtercounts
    from overlay_engine import preset as preset_mod
    from overlay_engine import screen as screen_mod
    from overlay_engine.ledger import home
    from overlay_engine.linehistory import LineHistory

    def refuse(exc, reason) -> int:
        if args.json:
            print(json.dumps({"command": "board", "feed": "oddsapi",
                              "error": str(exc), "reason": reason}, sort_keys=True))
        else:
            print(f"{exc}", file=sys.stderr)
        return 2

    if getattr(args, "screen", False):
        return _board_screen(args)
    if getattr(args, "lowhold", False):
        return _board_lowhold(args)
    if getattr(args, "futures", False) or getattr(args, "futures_stored", False):
        return _board_futures(args)
    if getattr(args, "alt_lines", False) or getattr(args, "alt_stored", False):
        return _board_altlines(args)

    try:
        props = (oddsapi.props_plan(args.prop, args.prop_region, args.prop_games)
                 if args.props else None)
        est = oddsapi.estimate(args.sport, args.region, args.market, props=props)
    except oddsapi.OddsApiError as exc:
        return refuse(exc, exc.reason)

    from overlay_engine import formula as formula_mod
    setting = args.formula_setting

    cache = oddsapi.Cache()
    if args.estimate:
        if args.json:
            # The EV formula's panel rides on the estimate: the cards, the shares, the Requires line and what a
            # region it needs would cost. It reads nothing and spends no credit.
            panel = {"formula": formula_mod.panel(setting or formula_mod.parse(None), est)}
            credits = cache.recall()
            return emit({"command": "board", "feed": "oddsapi", "estimate": est.as_dict(),
                         "choices": oddsapi.choices(est), "credits": credits,
                         "budget": oddsapi.budget(est.total, credits), **panel})
        print(est.sentence())
        if setting is not None:
            note = formula_mod.regions_note(setting.weights, est)["text"]
            for line in (setting.notice, note):
                if line:
                    print(line)
        print(f"Rule: {oddsapi.COST_RULE}")
        print(f"      ({oddsapi.COST_RULE_SOURCE})")
        if est.props is not None:
            print(f"Player props: {oddsapi.PROPS_COST_RULE}")
            print(f"      ({oddsapi.PROPS_COST_RULE_SOURCE})")
        print("Nothing was fetched and no credits were spent.")
        return 0

    try:
        key = keystore.get_key()
        if not key:
            raise oddsapi.OddsApiError(oddsapi.NO_KEY, "no_key")
        # Said BEFORE the fetch, so it is on screen while the fetch runs.
        if not args.json:
            print(est.sentence(), flush=True)
        got = oddsapi.refresh(est, key, cache=cache)
    except keystore.KeyStoreError as exc:
        return refuse(exc, "keychain")
    except oddsapi.OddsApiError as exc:
        return refuse(exc, exc.reason)
    finally:
        key = None

    kinds = tuple(args.kind) if args.kind else board_mod.KINDS
    books = oddsapi.books_table()
    # Each row's price over the reads kept on this Mac, with the fair price and the person's own bet. Read only
    # when a row asks for it; it opens the ledger file read-only and fetches nothing.
    line_history = (LineHistory.from_disk(oddshistory.history_folder(), home() / "overlay.db", now=got.now)
                    if args.json else None)
    stats = {}
    common = dict(bankroll=args.bankroll, min_margin=args.min_margin / 100.0,
                  now=got.now, fill_model=FillModel(), latency_model=LatencyModel(),
                  min_ev=args.min_ev / 100.0, bettable=oddsapi.bettable_in(args.state),
                  detail=args.json, names=got.book_names, history=line_history, stats=stats,
                  formula=setting.formula if setting else None)
    rows = []
    paired = tuple(k for k in kinds if k in ("arb", "ev"))
    if paired:
        rows += board_mod.scan(oddsapi.split_by_line(got.markets), books, kinds=paired, **common)
    if "middle" in kinds:
        rows += board_mod.scan(got.markets, books, kinds=("middle",), **common)
    if paired and got.props:
        # Each prop market is already one player at one line (`parse_prop_event`),
        # so the scan can only set the same player's over against his under.
        # Middles are not looked for in props.
        rows += board_mod.scan(got.props, books, kinds=paired, **common)
    rows = board_mod._rank(rows)

    source = oddsapi.source_line(got)
    shown = oddsapi.describe_rows(rows, got)

    if args.json:
        extra = {}
        if getattr(args, "alert_error", None):
            from overlay_engine import alerts as alerts_mod
            extra["alerts"] = alerts_mod.refused(args.alert_error)
        if getattr(args, "alert_setting", None):
            from overlay_engine import alerts as alerts_mod
            extra["alerts"] = alerts_mod.check(shown, args.alert_setting, "oddsapi", got.now,
                                               complete=not got.errors, hidden=_held_back(args))
        extra["hidden"] = _hiding(shown, args, got.now, complete=not got.errors)
        if setting is not None:
            extra["formula"] = formula_mod.board_block(setting, stats, est)
        _stake_ev(shown, args)
        _leg_opens(shown, args)
        warned = _warnings(shown, got.book_names)
        # Narrowed and sorted last: alerts, the hidden list, warnings and the counts all speak for every play found.
        order, narrowed = boardfilter.apply(shown, args.bf_spec, got.now, args.bf_problem)
        return emit({
            **extra,
            "board_filters": narrowed,
            "warnings": warned,
            "filters": filtercounts.of_rows(rows, args.min_margin, stats.get("under_margin", 0), warned["by_code"],
                                            formula_mod.counts(setting, stats) if setting else None),
            "command": "board", "feed": "oddsapi", "source": source, "live": True,
            "markets_scanned": len(got.markets) + len(got.props), "bankroll": args.bankroll,
            "read_at": got.now, "rows": [shown[i] for i in order], "odds": oddsapi.summary(got, args.state),
            # The moment every age on the board is counted to, and what Recommended does to these rows.
            "as_of": got.now, "preset": preset_mod.summary([r.preset_misses for r in rows]),
            # The same read, laid out as a grid of books. Nothing more is fetched for it.
            "screen": screen_mod.from_refresh(got, oddsapi.bettable_in(args.state)),
            "books_for": oddsapi.books_for(args.state),
        })

    for row, d in zip(rows, shown):
        row.event = d["event"]
    print(f"source: {source}")
    print(oddsapi.credits_line(got))
    _print_formula(setting, stats)
    for why in got.errors:
        print(f"not everything was read: {why}")
    print(f"scanned {len(got.markets) + len(got.props)} market(s) at a {args.bankroll:,.0f} bankroll")
    rows = _narrowed(rows, shown, args, got.now)
    print()
    status = _print_board(rows, kinds, empty_hint=FILTERED_HINT if args.bf_spec.active else (
        "Real prices were read; none of them is a play right now. Check again later."))
    if not args.state:
        print(oddsapi.NO_STATE)
    for note in oddsapi.summary(got, args.state)["notes"]:
        print(note)
    print("Check each price at the book before you bet. A price can move or a bet be")
    print("refused, and then nothing is locked.")
    return status


def _board_futures(args: argparse.Namespace) -> int:
    """`board --feed oddsapi --futures`: who wins the title, every book's price side by side.

    Opt in, like player props. The order is the promise: the cost is worked out from the choices alone and said
    first (no key, no network), only the leagues picked are ever read, and what was read is stored on this Mac so
    `--futures-stored` can open it again for nothing. `--futures-stored` reads files and nothing else: it does
    not read the Keychain, does not build a fetcher and does not call the Odds API.
    """
    from overlay_engine import futures as fut
    from overlay_engine import keystore, oddsapi

    def refuse(exc, reason) -> int:
        if args.json:
            print(json.dumps({"command": "board", "feed": "oddsapi", "error": str(exc), "reason": reason},
                             sort_keys=True))
        else:
            print(f"{exc}", file=sys.stderr)
        return 2

    setting = args.formula_setting
    formula = setting.formula if setting else None
    sentence = fut.formula_sentence(setting)
    min_ev = args.min_ev / 100.0

    def shown(view: dict) -> dict:
        view["formula_sentence"] = sentence
        return view

    if args.futures_stored:
        view = shown(fut.from_store(formula=formula, min_ev=min_ev, state=args.state))
        if args.json:
            return emit({"command": "board", "feed": "oddsapi", "futures": view})
        return _print_futures(view, None)

    try:
        est = fut.estimate(args.futures_league, args.futures_region)
    except oddsapi.OddsApiError as exc:
        return refuse(exc, exc.reason)

    cache = oddsapi.Cache()
    if args.estimate:
        if args.json:
            return emit({"command": "board", "feed": "oddsapi",
                         "futures": {"estimate": est.as_dict(), "choices": fut.choices(est),
                                     "credits": cache.recall()}})
        print(est.sentence())
        print(f"Rule: {fut.COST_RULE}")
        print(f"      ({fut.COST_RULE_SOURCE})")
        print("Nothing was fetched and no credits were spent.")
        return 0

    try:
        key = keystore.get_key()
        if not key:
            raise oddsapi.OddsApiError(oddsapi.NO_KEY, "no_key")
        # Said BEFORE the fetch, so it is on screen while the fetch runs.
        if not args.json:
            print(est.sentence(), flush=True)
        got = fut.read(est, key, cache=cache)
    except keystore.KeyStoreError as exc:
        return refuse(exc, "keychain")
    except oddsapi.OddsApiError as exc:
        return refuse(exc, exc.reason)
    finally:
        key = None

    view = shown(fut.from_store(now=got.now, formula=formula, min_ev=min_ev, state=args.state))
    if args.json:
        return emit({"command": "board", "feed": "oddsapi", "futures": view, "read": got.as_dict(),
                     "estimate": est.as_dict()})
    return _print_futures(view, got)


def _board_altlines(args: argparse.Namespace) -> int:
    """`board --feed oddsapi --alt-lines`: one game's alternate spreads and totals as a ladder.

    The futures order, kept: the cost from the choices alone and said first (no key, no network), only the game
    named is ever read, and the read is kept on this Mac so `--alt-stored` opens it again for nothing.
    `--alt-stored` reads one file and nothing else."""
    from overlay_engine import altlines, keystore, oddsapi

    def refuse(exc, reason) -> int:
        if args.json:
            print(json.dumps({"command": "board", "feed": "oddsapi", "error": str(exc), "reason": reason},
                             sort_keys=True))
        else:
            print(f"{exc}", file=sys.stderr)
        return 2

    setting = args.formula_setting
    formula = setting.formula if setting else None
    min_ev = args.min_ev / 100.0

    def done(view: dict, est=None) -> int:
        if args.json:
            extra = {"estimate": est.as_dict()} if est is not None else {}
            return emit({"command": "board", "feed": "oddsapi", "altlines": view, **extra})
        return _print_altlines(view)

    if args.alt_stored:
        got = altlines.load(args.alt_league, args.alt_event)
        if got is None:
            return refuse(oddsapi.OddsApiError("This game's alternate lines have not been read on this Mac, or the "
                                               "read is more than 30 days old. Press Read to read them.",
                                               "not_read"), "not_read")
        return done(altlines.ladder(got, state=args.state, formula=formula, min_ev=min_ev))

    try:
        est = altlines.estimate(args.alt_league, args.alt_event, args.alt_market, args.alt_region)
    except oddsapi.OddsApiError as exc:
        return refuse(exc, exc.reason)
    cache = oddsapi.Cache()
    if args.estimate:
        if args.json:
            return emit({"command": "board", "feed": "oddsapi",
                         "altlines": {"estimate": est.as_dict(), "credits": cache.recall()}})
        print(est.sentence())
        print(f"Rule: {altlines.COST_RULE}")
        print(f"      ({altlines.COST_RULE_SOURCE})")
        print("Nothing was fetched and no credits were spent.")
        return 0
    try:
        key = keystore.get_key()
        if not key:
            raise oddsapi.OddsApiError(oddsapi.NO_KEY, "no_key")
        if not args.json:
            print(est.sentence(), flush=True)
        left = (cache.recall() or {}).get("remaining")
        got = altlines.read(est, key, cache=cache, remaining=left)
    except keystore.KeyStoreError as exc:
        return refuse(exc, "keychain")
    except oddsapi.OddsApiError as exc:
        return refuse(exc, exc.reason)
    finally:
        key = None
    return done(altlines.ladder(got, state=args.state, formula=formula, min_ev=min_ev), est)


def _print_altlines(view: dict) -> int:
    """The ladder as text, in the window's words."""
    if view.get("books_for", {}).get("sentence"):
        print(view["books_for"]["sentence"])
    if view.get("warning"):
        print(view["warning"])
    print(f"{view['game']}: alternate lines")
    if not view["has_lines"]:
        print(view["message"])
    for s in view["sections"]:
        print(f"\n{s['label']}")
        for line in s["lines"]:
            for r in line["rows"]:
                best = r["best"]
                at = f"best {best['american']:+d} at {', '.join(best['books'])}" if best else "no book you can bet at"
                fair = f"fair {r['fair']['american']:+d}" if r.get("fair") else "no fair price"
                evs = [f"{b} +{c['ev'] * 100:.1f}% EV" for b, c in r["cells"].items() if c.get("ev")]
                print(f"  {r['label']:<28} {at:<30} {fair}{'  ' + ', '.join(evs) if evs else ''}")
    print(view["note"])
    return 0


def _print_futures(view: dict, got) -> int:
    """The futures view as text: one block per league, the same words the window shows."""
    if got is not None:
        print(got.credits_line())
        for why in got.errors:
            print(f"not everything was read: {why}")
        for _, why in got.skipped:
            print(why)
    if not view["has_futures"]:
        print(view["message"])
        return 0
    if view.get("formula_sentence"):
        print(view["formula_sentence"])
    for b in view["boards"]:
        print(f"\n{b['league_label']} {b['question']}: read {b['age_text']}, {b['names']} names, "
              f"{len(b['books'])} books")
        print(b["hold_sentence"])
        print(b["fair_sentence"])
        for note in b["notes"]:
            print(note)
        called = {c["key"]: c["name"] for c in b["books"]}
        for r in b["rows"][:12]:
            best = r["best"]
            top = (f"best {best['american']:+d} at {', '.join(called[k] for k in best['books'])}"
                   if best else "no price you can bet")
            fair = f", fair {r['fair']['american']:+d}" if r["fair"] else ""
            print(f"  {r['label']}: {top}{fair}")
        for p in b["plays"]:
            print(f"  +EV: {p['outcome']} at {p['book_name']} {p['american']:+d}: {p['text']}")
    print()
    print(view["ties_up"])
    print(view["long_shot"])
    print(view["note"])
    return 0


def _board_screen(args: argparse.Namespace) -> int:
    """`board --feed oddsapi --screen`: the grid of books, from what the last
    refreshes left on this Mac.

    It reads files and nothing else. It does not read the Keychain, does not
    build a fetcher and does not call the Odds API, so it costs no credits and
    works with the key cleared or never set (then there is simply nothing to
    show, and it says so).
    """
    import time

    from overlay_engine import oddsapi, oddshistory
    from overlay_engine import screen as screen_mod

    grid = screen_mod.from_history(oddshistory.history_folder(), oddsapi.bettable_in(args.state), time.time())
    if args.json:
        return emit({"command": "board", "feed": "oddsapi", "screen": grid, "books_for": oddsapi.books_for(args.state)})
    if not grid["has_odds"]:
        print(grid["message"])
        return 0
    for g in grid["grids"]:
        print(f"{g['league_label']} {g['market_label']}: read {int(g['age'] // 60)} minutes ago, "
              f"{len(g['games'])} games, {len(g['books'])} books")
    print(grid["note"])
    return 0


def _board_lowhold(args: argparse.Namespace) -> int:
    """`board --feed oddsapi --lowhold`: the two-way markets ranked by combined hold,
    from what the last refreshes left on this Mac.

    The same rule as `--screen`: it reads files and nothing else. It does not read the
    Keychain, does not build a fetcher and does not call the Odds API, so it costs no
    credits and works with the key cleared or never set. `--credit-book` is the book
    where the person has bonus money to play through (every row then has a leg there)
    and `--amount` is what they put through; both only change which rows and what they
    cost, never what is read.
    """
    import time

    from overlay_engine import lowholdview, oddsapi, oddshistory

    amount = args.amount if args.amount is not None else lowholdview.DEFAULT_AMOUNT
    try:
        limits = lowholdview.Limits(args.credit_book or "", args.credit_min, args.credit_max, args.other_min,
                                    args.other_max)
        out = lowholdview.from_history(oddshistory.history_folder(), oddsapi.bettable_in(args.state), time.time(),
                                       credit_book=args.credit_book or "", amount=amount, limits=limits)
    except lowholdview.LowHoldError as exc:
        if args.json:
            print(json.dumps({"command": "board", "feed": "oddsapi", "error": str(exc)}, sort_keys=True))
        else:
            print(f"{exc}", file=sys.stderr)
        return 2
    if args.json:
        return emit({"command": "board", "feed": "oddsapi", "lowhold": out, "books_for": oddsapi.books_for(args.state)})
    if not out["has_odds"]:
        print(out["message"])
        return 0
    print(f"Prices read {out['age_text']}. {out['amount_text']}")
    if out["warning"]:
        print(out["warning"])
    if not out["rows"]:
        print(out["message"])
    for r in out["rows"]:
        legs = "  /  ".join(f"{l['label']} {l['american']:+d} at {l['book_name']} ({l['stake']:,.2f})"
                            for l in r["legs"])
        print(f"{r['hold_text']:>7}  {r['league_label']} {r['market_label']}: {r['game']}")
        print(f"         {legs}")
        print(f"         {r['cost_line']}" + (f" {r['one_book']['line']}" if r["one_book"] else ""))
    if out["rows"]:
        print(f"Showing {out['shown']} of {out['qualifying']} at {out['max_hold_text']} or less.")
    print(out["cost_means"])
    print(out["note"])
    return 0


def cmd_key(args: argparse.Namespace) -> int:
    """Where a key is kept: set, status, clear. Two kinds: the Odds API key (default) and,
    with `--service anthropic`, the Anthropic key Ask uses.

    The key is read from standard input (or typed at a hidden prompt) and goes
    to the Mac's Keychain. It is never an argument, because a command line is
    visible to every program running as the same user, and it is never printed:
    status says whether one is set and its last four characters.
    """
    from overlay_engine import keystore, oddsapi

    action = args.key_action
    name = getattr(args, "service", "oddsapi") or "oddsapi"
    label = keystore.service(name).label

    def done(payload: dict, text: str) -> int:
        if args.json:
            return emit({"command": "key", "action": action, "service": name, **payload})
        print(text)
        return 0

    try:
        if action == "set":
            if sys.stdin is not None and sys.stdin.isatty():
                import getpass
                typed = getpass.getpass(f"{label} key (what you type is hidden): ")
            else:
                typed = sys.stdin.read(4096) if sys.stdin is not None else ""
            status = keystore.set_key(typed, name=name)
            typed = None
            return done({**status.as_dict(), "text": f"Saved. {status.describe()}"},
                        f"Saved in your Mac's Keychain. {status.describe()}")

        if action == "clear":
            removed = keystore.clear_key(name=name)
            if name == "oddsapi":
                # Whatever the key fetched goes with it.
                oddsapi.Cache().clear()
                text = ("Your Odds API key was removed from the Keychain, and the odds it fetched were deleted."
                        if removed else "No Odds API key was set, so there was nothing to remove.")
            else:
                text = (f"Your {label} key was removed from the Keychain."
                        if removed else f"No {label} key was set, so there was nothing to remove.")
            payload = {"set": False, "removed": removed, "text": text}
            if name == "oddsapi":
                from overlay_engine import firstrun
                payload["start"] = firstrun.start(False)
            return done(payload, text)

        status = keystore.status(name=name)
        credits = oddsapi.Cache().recall() if (name == "oddsapi" and status.is_set) else None
        text = status.describe()
        if credits and credits.get("remaining") is not None:
            text += (f" After the last refresh, {credits['remaining']} credits were left "
                     f"this month ({credits['used']} used).")
        payload = {**status.as_dict(), "text": text}
        if name == "oddsapi":
            payload["credits"] = credits
            # With no key yet, what works without one, for the window's first page (firstrun.py).
            from overlay_engine import firstrun
            start = firstrun.start(status.is_set)
            if start is not None:
                payload["start"] = start
        return done(payload, text)
    except keystore.KeyStoreError as exc:
        if args.json:
            print(json.dumps({"command": "key", "action": action, "service": name, "error": str(exc)}, sort_keys=True))
            return 2
        raise


def cmd_welcome(args: argparse.Namespace) -> int:
    """Every welcome offer, ranked by what it converts to, with the steps."""
    from overlay_engine import welcome

    rows = welcome.load()
    priced = welcome.price(rows, bonus_decimal=args.bonus_odds, hold=args.hold / 100.0)
    priced = welcome.for_you(priced, have=args.have, state=args.state)
    state = args.state.strip().upper()
    assumptions = (f"PRIORS: bonus bets placed at decimal {args.bonus_odds:.2f}, "
                   f"{args.hold:.1f}% combined hold across the best two books")
    # Books recorded as having no new-customer sports offer here, with the page that says so.
    no_offer = welcome.no_offer_in(welcome.load_none(), state)

    if args.json:
        # "Open this offer" only for a sportsbook licensed in the state, with 21+, the state's helpline and how
        # Bookbreaker is paid under the list (offerlink.py). An ended, stale or not-for-you offer gets no link.
        from overlay_engine import offerlink
        offers = []
        for p in priced:
            d = p.as_dict()
            usable = not (p.ended or p.stale or p.ineligible)
            d["open"] = offerlink.link(p.book, state) if usable else None
            offers.append(d)
        print(json.dumps({"command": "welcome", "assumptions": assumptions,
                          "max_age_days": welcome.MAX_AGE_DAYS, "state": state,
                          "offers": offers, "no_offer": no_offer,
                          "compliance": offerlink.compliance(state) if any(o["open"] for o in offers) else None},
                         indent=2, sort_keys=True))
        return 0

    print(assumptions)
    print("Ranked by what you KEEP, not by the headline.")
    print(f"Showing offers for {state}.\n" if state else
          "Offers differ by state. Pass --state with your two-letter code to see only yours.\n")
    total = 0.0
    for p in priced:
        if p.ended:
            print(f"  {p.book:<9} ENDED {p.ends}, by its source. Not priced until it is read again.")
            continue
        if p.stale:
            print(f"  {p.book:<9} STALE: read {p.read}, {p.age_days} days ago. Not priced.")
            continue
        if p.ineligible:
            print(f"  {p.book:<9} not for you: {p.ineligible}")
            continue
        worth = (f"{p.guaranteed:>8,.2f} locked if both bets are accepted and stand" if p.guaranteed
                 else f"{p.expected:>8,.2f} expected on average, not locked")
        print(f"  {p.book:<9} {worth}   {p.headline}")
        for step in p.steps:
            print(f"             - {step}")
        print(f"             in: {' '.join(p.states)}")
        print(f"             source: {p.source}  (read {p.read})\n")
        total += p.guaranteed
    for n in no_offer:
        stale = f" STALE: read {n['read']}, {n['age_days']} days ago." if n["stale"] else ""
        print(f"  {n['book']:<9} no new-customer sports offer in {state or ' '.join(n['states'])}: "
              f"{n['note']}{stale}")
        print(f"             source: {n['source']}  (read {n['read']})\n")
    # Only inside one state: offers in different states are never summed,
    # because nobody can collect a book's $365 in Indiana and its $200 in Ohio.
    if state:
        print(f"{total:,.2f} locked across the offers above in {state}, if every bet is "
              "accepted and stands. One welcome offer per book.")
    print("Offers change monthly. Check each source for your state before you sign up.")
    return 0


def cmd_deposit(args: argparse.Namespace) -> int:
    """Which books to fund in a state, in what order, and how much in each."""
    from overlay_engine import deposit

    out = deposit.plan(args.state, args.bankroll, have=args.have,
                       bonus_decimal=args.bonus_odds, hold=args.hold / 100.0)
    if args.json:
        return emit(out)
    print(deposit.describe(out))
    return 0


#: How the Fair odds panel may remove the cut (the AVO bar's item 10): the four methods' average, one method, or the
#: worst case, the lowest chance any method gives each side.
DEVIG_CHOICES = {
    "consensus": "the average of the four methods",
    "multiplicative": "the multiplicative method (each side's chance scaled down by the same share)",
    "additive": "the additive method (the same amount taken off each side's chance)",
    "power": "the power method (more taken off the long shot)",
    "shin": "Shin's method (allows for bettors who know more than the book)",
    "worst": "the worst case (the lowest chance any of the four methods gives each side)",
}


def _devig_chosen(decimals, spread, method: str) -> dict:
    """The fair price and chance for each side under the method chosen, with the sentence the panel shows."""
    if method not in DEVIG_CHOICES:
        raise SystemExit(f"Unknown way to remove the cut: {method!r}. Choose from {', '.join(DEVIG_CHOICES)}.")
    if method not in ("consensus", "worst") and method not in spread.by_method:
        method = "consensus"
    out = []
    for i in range(len(decimals)):
        chance = (spread.consensus(i) if method == "consensus" else spread.low(i) if method == "worst"
                  else spread.by_method[method][i])
        fair = round(decimal_to_american(1 / chance)) if 0 < chance < 1 else None
        out.append({"index": i, "chance": chance, "fair_american": fair})
    text = f"Fair prices from {DEVIG_CHOICES[method]}."
    if method == "worst":
        text += (" Each side's fair price here is the one a bet must beat under every method, so it is the cautious "
                 "price to size from. The chances do not add up to 100%, on purpose.")
    return {"method": method, "label": DEVIG_CHOICES[method], "outcomes": out, "text": text}


def cmd_devig(args: argparse.Namespace) -> int:
    decimals = [parse_odds(o) for o in args.odds]
    spread = devig_all(decimals)
    chosen = _devig_chosen(decimals, spread, getattr(args, "method", None) or "consensus")

    if args.json:
        return emit({
            "command": "devig",
            "decimals": decimals,
            "overround": overround(decimals),
            "hold": hold(decimals),
            "methods": list(spread.methods),
            "outcomes": [
                {
                    "index": i,
                    "by_method": {m: spread.by_method[m][i]
                                  for m in spread.methods},
                    "consensus": spread.consensus(i),
                    "spread": spread.spread(i),
                    # The no-vig price, as a book would print it.
                    "fair_american": (round(decimal_to_american(1 / spread.consensus(i)))
                                      if 0 < spread.consensus(i) < 1 else None),
                    "american": round(decimal_to_american(decimals[i])),
                }
                for i in range(len(decimals))
            ],
            "failed": dict(spread.failed),
            "chosen": chosen,
        })

    print(f"market: {', '.join(_fmt_odds(d) for d in decimals)}")
    print(f"overround {overround(decimals):.4f}   hold {hold(decimals):.2%}")
    print()

    header = "outcome  " + "".join(f"{m:>16}" for m in spread.methods)
    print(header + f"{'consensus':>12}{'spread':>10}")
    for i in range(len(decimals)):
        row = f"{i:<9}"
        for m in spread.methods:
            row += f"{spread.by_method[m][i]:>15.2%} "
        row += f"{spread.consensus(i):>11.2%}{spread.spread(i):>10.2%}"
        print(row)

    for method, why in spread.failed.items():
        print(f"\n{method}: no solution — {why}")

    if args.index is not None:
        i = args.index
        print()
        print(f"outcome {i}: fair {spread.consensus(i):.2%}, "
              f"worst case {spread.low(i):.2%}")
        print(f"  break-even price {_fmt_odds(1 / spread.consensus(i))}")
        print(f"  bet is +EV above {_fmt_odds(1 / spread.low(i))} "
              f"under every method")
    return 0


#: The rounding a person can pick for arb stakes, as the calculator's menu offers it.
ROUNDING = ("auto", "exact", "1", "5", "10", "25", "50", "100")


def _rounding(choice: str) -> dict:
    """`stake_arb` keyword arguments for one menu choice."""
    if choice == "exact":
        return {"round_stakes": False}
    if choice == "auto":
        return {}
    return {"step": float(choice)}


def _arb_solve(decimals: list, args: argparse.Namespace, rounding: dict):
    """The Arb calculator's two solves (the AVO bar's item 16): `--lock N=AMOUNT` holds side N at that stake and sizes
    the others to the cent so every result returns the same; `--target AMOUNT` finds the smallest total, at the
    rounding chosen, whose locked amount is at least the target. Returns (plan, solve) or raises _ArbSolveError with a
    sentence. Neither may need more than the most to bet."""
    lock, target = getattr(args, "lock", None), getattr(args, "target", None)
    if lock is None and target is None:
        return None, None
    if lock is not None and target is not None:
        raise _ArbSolveError("Lock one side or set a target, not both.")
    implied = sum(1 / d for d in decimals)
    if lock is not None:
        side, _, amount = str(lock).partition("=")
        try:
            i, held = int(side) - 1, float(amount)
        except ValueError:
            raise _ArbSolveError("Type the side to lock and its stake, like 1=250.") from None
        if not 0 <= i < len(decimals):
            raise _ArbSolveError(f"There is no side {side}: these prices have {len(decimals)} sides.")
        if not held > 0:
            raise _ArbSolveError("The locked stake must be more than zero.")
        need = held * decimals[i] * implied
        if need > args.stake + 0.005:
            raise _ArbSolveError(f"Holding side {i + 1} at ${held:,.2f} needs ${need:,.2f} in all, more than the "
                                 f"${args.stake:,.2f} you set as the most to bet.")
        plan = stake_arb(decimals, total=need, round_stakes=False, anchor=i)
        text = (f"Side {i + 1} is held at ${held:,.2f}; the other bets are sized to the cent so every result returns "
                f"the same. That is ${plan.total_stake:,.2f} in all.")
        return plan, {"kind": "lock", "side": i + 1, "amount": held, "text": text}
    try:
        goal = float(target)
    except ValueError:
        raise _ArbSolveError("Type the target as an amount, like 25.") from None
    if not goal > 0:
        raise _ArbSolveError("The target must be more than zero.")
    total = goal / (1 / implied - 1)
    step = rounding.get("step") or 1.0
    plan = stake_arb(decimals, total=total, **rounding)
    for _ in range(2000):
        if plan.profit >= goal - 1e-9 or total > args.stake:
            break
        total += step
        plan = stake_arb(decimals, total=total, **rounding)
    if plan.profit < goal - 1e-9 or plan.total_stake > args.stake + 0.005:
        raise _ArbSolveError(f"Locking ${goal:,.2f} at these prices needs about ${total:,.2f} in all, more than the "
                             f"${args.stake:,.2f} you set as the most to bet.")
    text = (f"The smallest total that locks at least ${goal:,.2f} at these prices is ${plan.total_stake:,.2f}, "
            "if every bet is accepted and stands.")
    return plan, {"kind": "target", "amount": goal, "text": text}


class _ArbSolveError(ValueError):
    """A lock or a target the calculator cannot meet: one sentence."""


def cmd_arb(args: argparse.Namespace) -> int:
    decimals = [parse_odds(o) for o in args.odds]
    margin = arb_margin(decimals)
    rounding = _rounding(getattr(args, "round", "auto"))

    if args.json:
        # No arbitrage is a result, not an error: a UI needs to render "these
        # prices do not cross" rather than receive nothing and guess why.
        if margin <= 0:
            return emit({
                "command": "arb", "decimals": decimals, "margin": margin,
                "arbitrage": False,
                "total_implied": sum(1 / d for d in decimals),
                "loss_per_unit": abs(margin),
            })
        exact = stake_arb(decimals, total=args.stake, round_stakes=False)
        plan = stake_arb(decimals, total=args.stake, **rounding)
        try:
            solved, solve = _arb_solve(decimals, args, rounding)
        except _ArbSolveError as exc:
            print(json.dumps({"error": str(exc)}))
            return 2
        if solved is not None:
            plan = solved
            exact = stake_arb(decimals, total=plan.total_stake, round_stakes=False)
        return emit({
            "solve": solve,
            "command": "arb",
            "decimals": decimals,
            "total_implied": sum(1 / d for d in decimals),
            "margin": margin,
            "arbitrage": True,
            "exact_profit": exact.profit,
            "total_stake": plan.total_stake,
            "profit": plan.profit,
            "ideal_profit": plan.ideal_profit,
            "roi": plan.roi,
            "rounded": plan.rounded,
            "rounding_cost": plan.rounding_cost,
            "round": getattr(args, "round", "auto"),
            "budget": args.stake,
            "legs": [{"decimal": leg.decimal, "stake": leg.stake,
                      "returns": leg.stake * leg.decimal,
                      "american": round(decimal_to_american(leg.decimal)),
                      # Profit on the whole pair if this leg wins; `profit` is the smallest.
                      "if_wins": round(won, 2)}
                     for leg, won in zip(plan.legs, plan.returns())],
        })

    print(f"legs: {', '.join(_fmt_odds(d) for d in decimals)}")
    print(f"total implied {sum(1 / d for d in decimals):.4f}")
    if margin <= 0:
        print(f"no arbitrage — you would lose {abs(margin):.2%} of turnover")
        return 1
    print(f"margin {margin:.2%}, locked if every bet is accepted at these prices and stands")
    print()

    exact = stake_arb(decimals, total=args.stake, round_stakes=False)
    plan = stake_arb(decimals, total=args.stake, **rounding)

    print("exact stakes (the number every other calculator gives you):")
    for leg in exact.legs:
        print(f"  {leg.stake:>10.2f} at {_fmt_odds(leg.decimal)}")
    print(f"  profit {exact.profit:.2f} on {exact.total_stake:.2f}"
          f"  ({exact.roi:.2%})")
    print()

    label = "round stakes" if plan.rounded else "round stakes (none held the arb)"
    print(f"{label}:")
    for leg in plan.legs:
        print(f"  {leg.stake:>10.0f} at {_fmt_odds(leg.decimal)}")
    print(f"  profit {plan.profit:.2f} on {plan.total_stake:.2f}"
          f"  ({plan.roi:.2%})")
    if plan.rounded:
        print(f"  rounding cost {plan.rounding_cost:.2f}"
              f" — paid to not look like a bot")
    return 0


def cmd_fill(args: argparse.Namespace) -> int:
    from overlay_engine import LatencyModel
    from overlay_engine.ledger import Ledger

    model = FillModel()
    latency = LatencyModel()
    if args.db:
        with Ledger(args.db) as db:
            model = db.fill_model()
            latency = db.latency_model()

    tau = model.tau(args.book, args.market)
    fitted = model.is_fitted(args.book, args.market)
    lag = latency.typical(args.book)
    measured_lag = latency.is_measured(args.book)

    # Latency is a floor under quote age, so a fill probability quoted without
    # it is the optimistic answer to a question nobody asked.
    effective = args.age + lag
    p = model.p_fill(args.book, args.market, effective)
    naive = model.p_fill(args.book, args.market, args.age)

    if args.json:
        return emit({
            "command": "fill",
            "book": args.book,
            "market": args.market,
            "age": args.age,
            "effective_age": effective,
            "latency": lag,
            "latency_measured": measured_lag,
            "tau": tau,
            "tau_measured": fitted,
            "half_life": model.half_life(args.book, args.market),
            "fill": p,
            "fill_naive": naive,
            "edge": 0.04,
            "edge_realised": 0.04 * p,
        })

    print(f"{args.book} / {args.market}")
    print(f"  mean quote life  {tau:.0f}s"
          f"  ({'measured' if fitted else 'prior — nothing observed yet'})")
    print(f"  half life        {model.half_life(args.book, args.market):.0f}s")
    print(f"  feed latency     {lag:.1f}s"
          f"  ({'measured' if measured_lag else 'prior — no dated quotes yet'})")
    print()
    print(f"  a quote {args.age:.0f}s old is really {effective:.0f}s old once the"
          " feed's lag is counted")
    print(f"  still there: {p:.0%}   (a screen ignoring latency would say"
          f" {naive:.0%})")
    print()
    print("  a 4% edge at this age is really "
          f"{0.04 * p:.2%} after the chance of not getting on")
    return 0


class _SharpError(ValueError):
    """A sharp book's prices that cannot be read: one sentence for the window."""


def _sharp_fair(decimal: float, pairs: list, method: str, bankroll: float) -> dict:
    """The +EV calculator in one (the AVO bar's item 17): each sharp book's two prices for this bet's market (this
    side first), the cut removed by `method`, averaged across the books, with the worst case beside it. Returns the
    chance to size from (the worst case's, the cautious end), the edge and the expected profit per $100, in words."""
    from overlay_engine.odds import OddsError
    books, mids, lows = [], [], []
    for i, text in enumerate(pairs, 1):
        mine, _, other = str(text).partition("/")
        try:
            prices = [parse_odds(mine.strip()), parse_odds(other.strip())]
        except (OddsError, ValueError):
            raise _SharpError(f"Sharp book {i}: type its two prices as your side/other side, like -120/+105.")
        spread = devig_all(prices)
        chosen = _devig_chosen(prices, spread, method)
        chance = chosen["outcomes"][0]["chance"]
        books.append({"prices": [round(decimal_to_american(d)) for d in prices], "chance": chance})
        mids.append(chance)
        lows.append(spread.low(0))
    chance, low = sum(mids) / len(mids), min(lows)
    ev = chance * decimal - 1.0
    fair = round(decimal_to_american(1 / chance)) if 0 < chance < 1 else None
    many = f"the {len(books)} sharp books" if len(books) > 1 else "the sharp book"
    if ev > 0:
        text = (f"Fair chance {chance:.1%} from {many} ({DEVIG_CHOICES[method]}), fair price "
                f"{fair:+d}. At your price that is an edge of {ev:.1%}: about ${ev * 100:,.2f} expected on every "
                "$100, an average over many bets like it. Any one bet can lose.")
    else:
        text = (f"Fair chance {chance:.1%} from {many} ({DEVIG_CHOICES[method]}), fair price {fair:+d}. "
                "Your price is not better than fair, so there is no edge to bet.")
    return {"books": books, "method": method, "chance": chance, "chance_low": low, "fair_american": fair,
            "ev": ev, "expected_per_100": round(ev * 100, 2), "text": text,
            "sized_on": "The stake is sized on the worst case across the books and methods, the cautious end."}


def cmd_kelly(args: argparse.Namespace) -> int:
    decimal = parse_odds(args.odds)
    fair = None
    if getattr(args, "sharp", None):
        try:
            fair = _sharp_fair(decimal, args.sharp, args.method, args.bankroll)
        except _SharpError as exc:
            print(json.dumps({"error": str(exc)}) if args.json else str(exc), file=sys.stdout if args.json else sys.stderr)
            return 2
        args.prob, args.prob_low = fair["chance"], fair["chance_low"]
    elif args.prob is None:
        said = "Fill in the win chance, or the sharp books' prices to work it out from."
        print(json.dumps({"error": said}) if args.json else said, file=sys.stdout if args.json else sys.stderr)
        return 2
    sizing = size_bet(
        decimal, args.prob, bankroll=args.bankroll,
        fraction=args.fraction, prob_low=args.prob_low,
    )
    if args.json:
        return emit({
            "fair": fair,
            "command": "kelly",
            "decimal": decimal,
            "prob": args.prob,
            "bankroll": args.bankroll,
            "fraction": args.fraction,
            "full_kelly": sizing.full_kelly,
            "stake": sizing.stake,
            "stake_fraction": (sizing.stake / args.bankroll
                               if args.bankroll else 0.0),
            "binding": sizing.binding,
            "prob_low": args.prob_low,
        })

    print(f"price {_fmt_odds(decimal)}   fair {args.prob:.2%}"
          f"   bankroll {args.bankroll:,.0f}")
    print(f"  full kelly      {sizing.full_kelly:.2%} of bankroll")
    print(f"  at {args.fraction:.0%} kelly   {sizing.stake:,.2f}"
          f"  ({sizing.bankroll_share:.2%})")
    print(f"  binding constraint: {sizing.binding}")
    if args.prob_low is not None:
        print(f"  sized on the conservative {args.prob_low:.2%}, not {args.prob:.2%}")
    return 0


def _demo_market() -> Market:
    """An NBA total where DraftKings is a step behind the sharp market."""
    prices = [
        ("pinnacle", "over", 220.5, 1.952),
        ("pinnacle", "under", 220.5, 1.952),
        ("circa", "over", 220.5, 1.935),
        ("circa", "under", 220.5, 1.970),
        ("dk", "over", 220.5, 2.100),
        ("dk", "under", 220.5, 1.740),
        ("fd", "over", 220.5, 1.980),
        ("fd", "under", 220.5, 1.870),
        ("mgm", "over", 220.5, 1.909),
        ("mgm", "under", 220.5, 1.909),
    ]
    quotes = [
        Quote(book=b, outcome=Outcome(name=n, line=line), decimal=d, seen_at=NOW - 6)
        for b, n, line, d in prices
    ]
    return Market(
        event_id="nba_2026_bos_lal",
        sport="basketball_nba",
        market_type="totals",
        quotes=quotes,
        starts_at=NOW + 5400,
    )


def cmd_demo(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger
    from overlay_engine.pricing import PricingContext, context_for, price_market

    market = _demo_market()
    books = DEFAULT_BOOKS

    # Priced through the same entry point everything else uses. A demo that
    # assembled the learned parts by hand would drift from the product and
    # quietly stop demonstrating it.
    if args.db:
        with Ledger(args.db) as db:
            ctx = context_for(db, books, market)
    else:
        ctx = PricingContext.uncalibrated(books)
    fills = ctx.fill

    print("=" * 72)
    print("BOS @ LAL — total 220.5, quotes 6 seconds old")
    print("=" * 72)
    for q in market.quotes:
        book = books[q.book]
        print(f"  {book.name:<12} {q.outcome.name:<6} {_fmt_odds(q.decimal)}"
              f"   [{book.tier.value}]")

    print()
    print("-- fair value " + "-" * 58)
    fairs = fair_for(market, ctx)
    for key, fv in fairs.items():
        print(f"  {key:<14} {fv.prob:.2%}"
              f"   band {fv.low:.2%}–{fv.high:.2%}"
              f"   fair price {_fmt_odds(fv.fair_decimal)}")
        print(f"  {'':<14} anchored: {fv.anchored}"
              f"   contributors: {', '.join(sorted(fv.contributors))}")

    print()
    print("-- edges, ranked by the EV you can actually realise " + "-" * 20)
    print(f"  calibration: {ctx.describe()}")
    edges = price_market(market, ctx, now=NOW)
    if not edges:
        print("  none")
    for e in edges:
        print(f"  {books[e.book].name:<12} {e.outcome:<14} {_fmt_odds(e.decimal)}")
        print(f"  {'':<12} EV {e.ev:+.2%}  band {e.ev_low:+.2%}..{e.ev_high:+.2%}"
              f"  fill {e.p_fill:.0%}  ->  realised {e.realised_ev:+.2%}")
        print(f"  {'':<12} robust: {e.robust}"
              + (f"   note: {e.note}" if e.note else ""))

    print()
    print("-- arbitrage " + "-" * 59)
    arbs = find_arbs(market, books, now=NOW)
    if not arbs:
        best_over = market.best("over@220.5")
        best_under = market.best("under@220.5")
        implied = 1 / best_over.decimal + 1 / best_under.decimal
        print(f"  none — best of both sides still implies {implied:.4f}"
              f" ({(implied - 1):.2%} against you)")
    for a in arbs:
        print(f"  margin {a['margin']:.2%} gross")
        for leg in a["legs"]:
            print(f"    {books[leg['book']].name:<12} {leg['outcome']:<14}"
                  f" {_fmt_odds(leg['decimal'])}")
        decimals = [leg["net_decimal"] for leg in a["legs"]]
        exact = stake_arb(decimals, total=args.bankroll * 0.1, round_stakes=False)
        plan = stake_arb(
            decimals,
            total=args.bankroll * 0.1,
            books=[leg["book"] for leg in a["legs"]],
            outcomes=[leg["outcome"] for leg in a["legs"]],
        )
        print(f"    exact  {' / '.join(f'{l.stake:.2f}' for l in exact.legs)}"
              f"  -> {exact.profit:.2f} locked if all accepted")
        print(f"    round  {' / '.join(f'{l.stake:.0f}' for l in plan.legs)}"
              f"  -> {plan.profit:.2f} locked if all accepted"
              f"  (costs {plan.rounding_cost:.2f} to look human)")

    print()
    print("-- sizing and account heat " + "-" * 45)
    account = AccountHeat()
    for e in edges[:1]:
        sizing = size_bet(
            e.decimal, e.fair_prob, bankroll=args.bankroll,
            prob_low=e.fair_prob - (e.ev - e.ev_low) / e.decimal,
        )
        shaped = shape(e.book, sizing.stake, e.ev, account, books, now=NOW)
        print(f"  {books[e.book].name} {e.outcome} at {_fmt_odds(e.decimal)}")
        print(f"    kelly says       {sizing.stake:,.2f}  ({sizing.binding})")
        print(f"    shaped stake     {shaped.stake:,.0f}")
        print(f"    reason           {shaped.reason or 'none needed'}")
        print(f"    delay before bet {shaped.delay:.0f}s")

    print()
    print("Every number above is arithmetic on the ten prices at the top.")
    if ctx.calibrated:
        print(f"Priced with: {ctx.describe()}")
    else:
        print("Nothing here is fitted, because nothing has been observed yet —")
        print("every learned parameter is a stated prior, and says so.")
    return 0


def cmd_books(args: argparse.Namespace) -> int:
    from overlay_engine import catalog

    state = args.state.upper()
    summary = catalog.state_summary(state)

    print(f"{state} — {summary['venues']} venues"
          f"  (table read {summary['as_of']}, {summary['stale_days']} days ago)")
    reg = catalog.regulator_list(state)
    if reg is not None:
        print(f"  {reg.regulator}'s own list, read {reg.read} "
              f"({summary['regulator']['days']} days ago): {reg.stated_count} operators "
              "offer online sports betting.")
    if not summary["legal"]:
        print("  No legal sports betting in this state as of the table date.")
    if not summary["covered"]:
        print(f"  Coverage gap: {summary['gap_reason']}")
    if summary["retail_only"]:
        print(f"  Legal in person only — {summary['retail_only']}.")
        print("  Not a gap in this table: there is no online venue to list.")
    if summary["single_operator"]:
        print(f"  A single-operator market: {summary['single_operator']}.")
    print()

    for venue in catalog.for_state(state, include_unverified=args.unverified):
        flags = []
        if not venue.limits_winners:
            flags.append("never limits")
        if venue.commission:
            flags.append(f"{venue.commission:.1%} commission")
        if venue.jurisdiction_unknown:
            flags.append("JURISDICTION UNVERIFIED — check yourself")
        tag = f"  [{', '.join(flags)}]" if flags else ""
        print(f"  {venue.tier.value:<9} {venue.name:<24}{tag}")
        if venue.note:
            print(f"  {'':<9} {venue.note}")
        listed = next((b for b in reg.brands if b.key == venue.key), None) if reg else None
        if listed:
            print(f"  {'':<9} {listed.operator}; platform: {listed.platform}")

    if reg is not None:
        for e in reg.exits:
            print(f"  Left {state}: {e.brand}, {e.ended}.")
        for line in reg.casino_only:
            print(f"  Not a sportsbook: {line}.")

    print()
    if summary["has_anchor"]:
        print(f"  {summary['anchors']} anchor venue(s) — +EV numbers here rest on"
              " a sharp or exchange price.")
    else:
        print("  No sharp or exchange venue. +EV here would be a poll of the"
              " books you intend to beat.")
    print(f"  Never limit winners: {', '.join(summary['never_limit']) or 'none'}")
    print()
    print("  Legality moves. This is a dated starting point for your own check,"
          " not advice;")
    print("  the book's own site decides whether it will accept you.")
    return 0


def _promo_convert(args: argparse.Namespace) -> int:
    """`promo --type ...`: one promo the person holds, converted. The window's Convert my own promo."""
    from overlay_engine import promoconv

    if args.amount is None:
        raise promoconv.PromoError("Type the amount of the promo.")
    out = promoconv.convert(
        args.type, args.book, args.amount, boost_pct=args.boost, max_win=args.max_win,
        match_pct=args.match, rollover=args.rollover, max_hedge=args.max_hedge,
        state=(args.state or "").strip().upper() or None)
    if args.json:
        print(json.dumps(out, indent=2, sort_keys=True))
        return 0
    worth = out["worth"]

    def usd(x: float) -> str:
        return f"-${abs(x):,.2f}" if x < 0 else f"${x:,.2f}"

    print(f"{out['type_name']}{' at ' + out['book_name'] if out['book_name'] else ''}, {usd(out['amount'])}")
    print(f"  {usd(worth['amount'])} {worth['caption']}")
    print(f"  {out['assumptions']}")
    for o in out["outcomes"]:
        print(f"  {o['name']}: you {'keep' if o['kept'] >= 0 else 'lose'} {usd(abs(o['kept']))}. {o['note']}")
    pair = out.get("pair")
    if pair:
        for key in ("promo", "hedge"):
            leg = pair.get(key)
            if leg:
                print(f"  {key:>5}: ${leg['stake']:,.2f} on {leg['side']} at {leg['american']:+d}"
                      f" ({leg['book_name'] or 'any book'})")
        if pair.get("why"):
            print(f"  {pair['why']}")
    for note in out["notes"]:
        print(f"  {note}")
    return 0


def cmd_promo(args: argparse.Namespace) -> int:
    from overlay_engine import promo
    from overlay_engine.catalog import for_state

    if getattr(args, "type", None):
        return _promo_convert(args)

    print("=" * 70)
    print("WELCOME OFFERS — what the headline is actually worth")
    print("=" * 70)

    hedge_pairs = [
        (american_to_decimal_safe(a), american_to_decimal_safe(h))
        for a, h in ((100, -110), (200, -230), (400, -450), (700, -800), (1200, -1400))
    ]
    hedge_pairs = [(a, h) for a, h in hedge_pairs if a and h]

    plan = promo.best_conversion(args.bonus, hedge_pairs, max_hedge=args.max_hedge)
    conv = plan.conversion if plan else 0.75

    print()
    print(f"-- converting a {args.bonus:,.0f} bonus bet " + "-" * 26)
    print(f"  {'free leg':>10}{'hedge at':>12}{'hedge stake':>14}"
          f"{'guaranteed':>13}{'rate':>8}")
    for free_odds, hedge_odds in hedge_pairs:
        p = promo.bonus_bet_conversion(free_odds, hedge_odds, args.bonus)
        over = args.max_hedge is not None and p.hedge_stake > args.max_hedge
        mark = "  (over your hedge limit)" if over else ""
        print(f"  {decimal_to_american(free_odds):>+10.0f}"
              f"{decimal_to_american(hedge_odds):>+12.0f}"
              f"{p.hedge_stake:>14,.0f}{p.guaranteed:>13,.0f}"
              f"{p.conversion:>8.1%}{mark}")

    print()
    if plan is None:
        print("  No hedgeable pair inside your hedge limit.")
    else:
        print(f"  best: {plan.describe()}")
        print(f"  ceiling at these odds in a no-vig market: "
              f"{promo.fair_conversion_ceiling(plan.free_leg_odds):.1%}")
        print(f"  a naive bet at even money returns about "
              f"{args.bonus * 0.5:,.0f} in expectation and nothing guaranteed")
    print()
    print("  The hedge column is the constraint the advice always omits. Longer")
    print("  odds convert better and need more cash at the second book — pass")
    print("  --max-hedge to see only the plans you can actually place.")

    print()
    print("-- offer types, at this conversion rate " + "-" * 30)

    bag = promo.bet_and_get_value(5.0, 0.045, args.bonus, conv)
    print(f"  bet-and-get {args.bonus:,.0f}")
    print(f"    guaranteed {bag.guaranteed:,.2f}"
          f"   ({bag.headline_ratio:.0%} of headline)")
    print(f"    {bag.note}")

    net = promo.safety_net_value(args.bonus, 4.0, 0.24, conv)
    print(f"  safety net {args.bonus:,.0f} at +300")
    print(f"    expected {net.expected:+,.2f}, guaranteed {net.guaranteed:,.2f}")
    print(f"    {net.note}")

    match = promo.deposit_match_value(args.bonus, args.bonus, rollover=10.0)
    print(f"  100% deposit match on {args.bonus:,.0f}, 10x rollover")
    print(f"    expected {match.expected:+,.2f} for "
          f"{10 * 2 * args.bonus:,.0f} of turnover")
    print(f"    {match.note}")

    if args.state:
        keys = [v.key for v in for_state(args.state)]
        order = promo.sequence(keys)
        print()
        print(f"-- claim order in {args.state.upper()} " + "-" * 40)
        print("  Open two bet-and-get books first: converting a bonus needs a")
        print("  hedge at a second book, so one account alone is worth little.")
        for i, (book, offer_type) in enumerate(order, 1):
            print(f"    {i:>2}. {book:<12} {offer_type.value}")
    return 0


def cmd_ledger(args: argparse.Namespace) -> int:
    from overlay_engine.clv import report as clv_report
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        stats = db.stats()
        print(f"ledger: {stats['path']}")
        print(f"  bets          {stats['bets']:>6}"
              f"   ({stats['graded']} graded, {stats['ungraded']} awaiting a close)")
        print(f"  attempts      {stats['attempts']:>6}"
              f"   ({stats['rejected']} rejected)")
        print(f"  quotes        {stats['quotes']:>6}"
              f"   ({stats['closing_quotes']} closing)")
        print(f"  books         {stats['books']:>6}")

        print()
        if stats["can_calibrate"]:
            print("  Enough graded bets to calibrate.")
        else:
            print(f"  {stats['graded_needed']} more graded bets before anything"
                  " can be calibrated.")
            print("  Until then every learned parameter is its shipped prior,"
                  " and says so.")

        graded = db.graded_bets()
        if graded:
            rep = clv_report(graded)
            print()
            print(f"  CLV: {rep.verdict()}")
            print(f"  beat the close on {rep.beat_rate:.0%} of"
                  f" {rep.n} bets, {rep.total_staked:,.0f} staked")

        from overlay_engine.calibrate import weights_for

        weights, age = weights_for(db)
        print()
        if weights is None:
            print("  devig weights — none calibrated; all four methods equal.")
        else:
            best = max(weights, key=weights.get)
            print(f"  devig weights — measured {age / 86400:.1f} days ago,"
                  f" led by {best} at {weights[best]:.3f}")

        from overlay_engine.calibrate import book_weights_for

        book_w, book_age = book_weights_for(db)
        if book_w is None:
            print("  book weights  — none calibrated; tier defaults, which are"
                  " stated priors and not measurements.")
        else:
            best = max(book_w, key=book_w.get)
            print(f"  book weights  — measured {book_age / 86400:.1f} days ago,"
                  f" led by {best} at {book_w[best]:.3f}"
                  f" ({len(book_w)} books)")

        model = db.fill_model()
        fitted = [
            (book, klass) for (book, klass), n in model.counts.items() if n >= 5
        ]
        print()
        if fitted:
            print("  fill model — measured:")
            for book, klass in sorted(fitted):
                print(f"    {book:<12} {klass:<12}"
                      f" half life {model.half_life(book, klass):>5.0f}s"
                      f"  ({model.counts[(book, klass)]} attempts)")
        else:
            print("  fill model — no cell has 5+ attempts yet; all priors.")

        latency = db.latency_model()
        measured = [b for b in latency.counts if latency.is_measured(b)]
        if measured:
            print("  feed latency — measured:")
            for book in sorted(measured):
                print(f"    {book:<12} {latency.typical(book):>5.1f}s"
                      f"  ({latency.observations(book)} dated quotes)")
        else:
            print(f"  feed latency — no dated quotes yet; assuming"
                  f" {PRIOR_LATENCY:.0f}s, which is a prior, not a measurement.")
    return 0


def cmd_calibrate(args: argparse.Namespace) -> int:
    from overlay_engine.calibrate import calibrate_all
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        results = calibrate_all(db, holdout=args.holdout, write=not args.dry_run)

        print(f"ledger: {db.path}")
        if args.dry_run:
            print("dry run — nothing will be written")
        print()

        for r in sorted(results, key=lambda r: (not r.accepted, r.scope)):
            print(f"  {r.describe()}")
            if r.accepted:
                # Only the top few: a global scope can weight twenty books and
                # the tail is all at the floor, which is noise on a screen.
                ranked = sorted(r.weights.items(), key=lambda kv: -kv[1])
                for name, weight in ranked[:6]:
                    print(f"      {name:<16} {weight:.3f}")
                if len(ranked) > 6:
                    print(f"      ... {len(ranked) - 6} more at or near the floor")

        accepted = sum(1 for r in results if r.accepted)
        print()
        print(f"  {accepted} of {len(results)} scope(s) updated.")
        if accepted == 0:
            print("  Declining is a normal result — it means the weights already")
            print("  in place predict the closing line at least as well as any")
            print("  candidate fitted on the older part of the log.")
    return 0


def cmd_grade(args: argparse.Namespace) -> int:
    from overlay_engine.calibrate import weights_for
    from overlay_engine.grade import grade_pending
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        # Grade with the same weights the engine prices with. Grading against
        # a blend nothing else computes would measure CLV on a scale no other
        # number in the product uses.
        weights, _ = weights_for(db)
        report = grade_pending(db, require_anchor=not args.allow_retail,
                               method_weights=weights)

        print(f"ledger: {db.path}")
        print(f"  {report.describe()}")

        if report.skipped:
            print()
            print("  not graded:")
            for reason, n in report.reasons().items():
                print(f"    {n:>4}  {reason}")

        stats = db.stats()
        print()
        print(f"  {stats['graded']} graded, {stats['ungraded']} still waiting"
              f" on a close")
        if not stats["can_calibrate"]:
            print(f"  {stats['graded_needed']} more before anything can be"
                  " calibrated")
    return 0


def cmd_capture(args: argparse.Namespace) -> int:
    from overlay_engine.feed import FeedError, ReplayProvider, capture
    from overlay_engine.ledger import Ledger

    try:
        provider = ReplayProvider(args.snapshot)
    except FeedError as exc:
        print(f"cannot read snapshot: {exc}")
        return 1

    with Ledger(args.db) as db:
        report = capture(db, provider, sports=args.sport or None,
                         is_closing=args.closing)
        print(f"ledger: {db.path}")
        print(f"  provider: replay ({args.snapshot})")
        print(f"  {report.describe()}")

        if report.markets and not report.dated:
            print()
            print("  This feed dates none of its quotes, so staleness is")
            print("  inferred from a prior rather than measured. Fill")
            print("  probabilities from it are the optimistic answer.")

        latency = db.latency_model()
        measured = sorted(b for b in latency.counts if latency.is_measured(b))
        if measured:
            print()
            print("  measured feed latency:")
            for book in measured:
                print(f"    {book:<12} {latency.typical(book):>5.1f}s"
                      f"  ({latency.observations(book)} dated quotes)")
    return 0


def cmd_middles(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger
    from overlay_engine.middles import (
        MIN_GAMES, MIN_PER_CELL, MIN_TOTAL_GAMES, MarginModel, TotalsModel,
        find_middles)

    low, high = sorted((args.low, args.high))
    if low == high:
        print("a middle needs two different lines")
        return 1

    is_totals = args.market == "totals"
    model = totals_model = None
    games = 0
    per_cell = 0.0
    if args.db:
        with Ledger(args.db) as db:
            if is_totals:
                totals_model = TotalsModel.from_ledger(db)
                games = totals_model.games(args.sport)
                per_cell = totals_model.per_cell(args.sport)
            else:
                model = MarginModel.from_ledger(db)
                games = model.games(args.sport)

    market = Market(
        event_id="cli", sport=args.sport, market_type=args.market,
        quotes=[
            Quote(book="book-a", outcome=Outcome("over", low),
                  decimal=parse_odds(args.low_odds), seen_at=NOW),
            Quote(book="book-b", outcome=Outcome("under", high),
                  decimal=parse_odds(args.high_odds), seen_at=NOW),
        ],
    )
    plans = find_middles(market, {}, sport=args.sport, model=model,
                         totals_model=totals_model,
                         sigma=args.sigma, total=args.stake)
    if not plans:
        print("no middle between those lines")
        return 1

    plan = plans[0]
    print(f"{args.sport}: over {low:g} / under {high:g}")
    print(f"  stakes        {plan.low_stake:,.0f} at "
          f"{_fmt_odds(plan.low_decimal)} / {plan.high_stake:,.0f} at "
          f"{_fmt_odds(plan.high_decimal)}")
    print(f"  one side wins {plan.one_side_profit:+,.2f}")
    print(f"  middle hits   {plan.middle_profit:+,.2f}")
    print()
    print(f"  window probability  {plan.p_middle:.2%}  ({plan.source})")
    print(f"  break-even          {plan.breakeven_p:.2%}"
          "   — arithmetic on the two prices, no distribution involved")
    print(f"  expected value      {plan.ev:+.2%} per unit staked")
    print()
    noun = "totals" if is_totals else "margins"
    used = totals_model if is_totals else model
    floor = MIN_TOTAL_GAMES if is_totals else MIN_GAMES

    if plan.measured:
        print(f"  Counted from {games} recorded {args.sport} games.")
        keys = used.key_numbers(args.sport, top=3) if used else []
        if keys:
            shown = ", ".join(f"{v} ({q:.1%})" for v, q in keys)
            print(f"  Most common {noun}: {shown}")
    else:
        print(f"  A normal approximation, not a count. Real {noun} cluster on"
              " key numbers")
        print(f"  and no smooth curve reproduces that. Record {floor}"
              f" {args.sport} scores")
        print(f"  ({games} so far) and this becomes a measurement.")
        print(f"  Spread used: {plan.sigma:.2f} points ({plan.sigma_source}).")
        if is_totals and games >= MIN_TOTAL_GAMES and per_cell < MIN_PER_CELL:
            print(f"  Games are there ({games}) but spread thin —"
                  f" {per_cell:.1f} per distinct total against"
                  f" {MIN_PER_CELL:.0f} needed.")
            print("  Declined rather than counted off a handful of games"
                  " per bucket.")
    return 0


def cmd_performance(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger
    from overlay_engine.performance import from_ledger, to_csv

    filters = {
        "sport": args.sport, "book": args.book, "market_type": args.market,
        "min_decimal": args.min_odds and parse_odds(args.min_odds),
        "max_decimal": args.max_odds and parse_odds(args.max_odds),
    }
    filters = {k: v for k, v in filters.items() if v}

    with Ledger(args.db) as db:
        if args.csv:
            Path(args.csv).write_text(to_csv(db.settled_bets(**filters)))
            print(f"exported to {args.csv}")
            return 0

        rep = from_ledger(db, **filters)
        o = rep.overall

        if args.json:
            # The window had no results screen for one reason: this command
            # ignored --json, so there was nothing for it to read. Everything
            # Pikkit puts on a dashboard is already computed here.
            from overlay_engine import oddshistory, tracker
            from overlay_engine.clv import report as clv_report

            graded = db.graded_bets()
            clv = None
            if graded:
                cr = clv_report(graded)
                # Beating the close is the only measure of a bet that does
                # not need the result. A winning month on bets that all
                # closed worse is variance; a losing month on bets that all
                # closed better is the process working. Pikkit leads with
                # this and it is the number a serious bettor checks first.
                clv = {"n": cr.n, "mean_clv": cr.mean_clv,
                       "stdev": cr.stdev, "beat_rate": cr.beat_rate,
                       "total_staked": cr.total_staked,
                       "verdict": cr.verdict(),
                       "by_book": cr.by_book, "by_market": cr.by_market}
            def group(rows):
                # Slice carries `label`, not `key`, and reports flat_return
                # rather than roi. Written against the wrong shape, this
                # raised AttributeError on the first ledger that actually had
                # bets in it — an empty ledger yields empty lists, so the
                # comprehension never ran and every test passed.
                return [{"key": g.label, "n": g.n, "won": g.won,
                         "lost": g.lost, "push": g.push,
                         "turnover": g.turnover, "profit": g.profit,
                         "roi": (g.profit / g.turnover) if g.turnover else 0.0,
                         "flat_return": g.flat_return,
                         "win_rate": (g.won / (g.won + g.lost))
                                     if (g.won + g.lost) else 0.0}
                        for g in rows]

            print(json.dumps({
                "command": "performance",
                "ledger": str(db.path),
                "filters": {k: str(v) for k, v in filters.items()},
                "settled": o.n, "won": o.won, "lost": o.lost,
                "push": o.push, "void": o.void, "decided": o.decided,
                "turnover": o.turnover, "profit": o.profit,
                "win_rate": o.win_rate, "roi": o.roi,
                "flat_return": o.flat_return,
                "staking_effect": rep.staking_effect,
                "units": o.units(args.unit) if args.unit else None,
                "verdict": o.verdict(),
                "by_sport": group(rep.by_sport), "by_book": group(rep.by_book),
                "by_market": group(rep.by_market), "by_price": group(rep.by_odds),
                "clv": clv,
                "graded": len(graded), "ungraded": db.stats()["ungraded"],
                # The My bets dashboard: the sentence, actual against expected profit, profit by book and by
                # market, and the month calendar. All of it is the engine's; the window prints it.
                "tracker": tracker.dashboard(db, rep, filters, time.time(), oddshistory.history_folder()),
            }, indent=2, sort_keys=True))
            return 0

        print(f"ledger: {db.path}")
        if filters:
            print(f"  filtered: {', '.join(f'{k}={v}' for k, v in filters.items())}")
        print()
        print(f"  settled       {o.n:>8}"
              f"   ({o.won}W {o.lost}L {o.push}P"
              + (f" {o.void} void" if o.void else "") + ")")
        print(f"  turnover      {o.turnover:>8,.0f}")
        print(f"  profit        {o.profit:>+8,.2f}")
        if args.unit:
            print(f"  units         {o.units(args.unit):>+8,.2f}"
                  f"   (at {args.unit:,.0f} a unit)")
        print(f"  win rate      {o.win_rate:>8.1%}   of {o.decided} decided")
        print()
        print(f"  money ROI     {o.roi:>+8.2%}   what actually happened")
        print(f"  flat-bet ROI  {o.flat_return:>+8.2%}"
              "   betting the same amount every time")
        effect = rep.staking_effect
        if o.n:
            direction = "added" if effect > 0 else "cost"
            print(f"  staking       {effect:>+8.2%}   sizing {direction} this much")
        print()
        print(f"  {o.verdict()}")

        for title, group in (("by sport", rep.by_sport), ("by book", rep.by_book),
                             ("by market", rep.by_market), ("by price", rep.by_odds)):
            shown = [s for s in group if s.n]
            if not shown:
                continue
            print()
            print(f"  -- {title} " + "-" * (46 - len(title)))
            for sl in shown:
                flag = "" if sl.n >= 30 else "  (thin)"
                print(f"    {sl.label:<28} {sl.n:>5} bets"
                      f" {sl.flat_return:>+8.2%}{flag}")

        leaks = rep.leaks()
        if leaks:
            print()
            print("  -- losing on a sample worth believing " + "-" * 12)
            for sl in leaks:
                print(f"    {sl.label:<28} {sl.n:>5} bets {sl.flat_return:>+8.2%}")
    return 0


def _slip_display(name: str, value) -> str:
    """How a read value should appear to a person checking it against a slip.

    Formatted here rather than in the window so the window does no betting
    arithmetic: `1.6666666666666665` is what the float is, and `-150 (1.667)`
    is what the slip said.
    """
    from overlay_engine.catalog import VENUES
    from overlay_engine.odds import decimal_to_american

    if name == "book" and value in VENUES:
        return VENUES[value].name
    if name == "decimal_odds" and isinstance(value, (int, float)):
        return f"{decimal_to_american(value):+.0f}  ({value:.3f})"
    if name in ("stake", "profit") and isinstance(value, (int, float)):
        return f"${value:,.2f}"
    if name == "market_type":
        return {"h2h": "Moneyline", "spreads": "Spread", "totals": "Total",
                "player_prop": "Player prop", "parlay": "Parlay",
                "teaser": "Teaser", "futures": "Future"}.get(value, str(value))
    return str(value)


def cmd_paste(args: argparse.Namespace) -> int:
    """Read a betslip pasted on stdin. Shows the reading; writes only on ask."""
    import pathlib

    from overlay_engine.betslip import implied, parse, to_import

    if getattr(args, "text", None) is not None:
        # The window has no stdin to hand the engine; the slip arrives as an
        # argument instead. Same parser, same refusals.
        text = args.text
    elif args.path in (None, "-"):
        text = sys.stdin.read()
    else:
        text = pathlib.Path(args.path).read_text()
    got = parse(text)

    if args.json:
        out = {
            "command": "paste",
            "usable": got.usable,
            "needs": got.needs,
            "fields": {k: {"value": f.value, "source": f.source,
                           "display": _slip_display(k, f.value)}
                       for k, f in got.fields.items()},
            "implied": implied(got) if got.usable else None,
            "written": False,
        }
        if got.usable and args.write:
            if not args.event:
                out["error"] = ("--write needs --event: a bet with no event "
                                "cannot be graded")
            else:
                from overlay_engine.ledger import Ledger
                with Ledger(args.db) as db:
                    out["bet_id"] = db.import_bet(**to_import(
                        got, event_id=args.event, sport=args.sport))
                    out["written"] = True
                    out["ledger"] = str(db.path)
        print(json.dumps(out, indent=2, sort_keys=True, default=str))
        return 0 if got.usable else 1

    print("read from the slip:")
    print(got.describe())

    if not got.usable:
        print()
        print(f"  NOT A BET: {', '.join(got.needs)} missing.")
        print("  Nothing written. A slip without a price is not a bet with an")
        print("  unknown price - it is text that did not parse.")
        return 1

    print()
    print(f"  implied      {implied(got):.2%}  (includes the vig)")

    unknown = [f for f in ("book", "market_type", "result") if got.get(f) is None]
    if unknown:
        print(f"  not found: {', '.join(unknown)}"
              "  (left blank rather than guessed)")

    print()
    print("  Check every line above against the slip before writing it. The")
    print("  source text after each arrow is what the value was read from.")

    if not args.write:
        print()
        print("  Nothing written. Re-run with --write --event EVENT_ID to record it.")
        return 0

    if not args.event:
        print()
        print("  --write needs --event EVENT_ID: a bet with no event cannot be")
        print("  graded, and an ungradeable bet never becomes evidence.")
        return 1

    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        bet_id = db.import_bet(**to_import(got, event_id=args.event,
                                           sport=args.sport))
        print()
        print(f"  written to {db.path} as bet {bet_id}")
    return 0


def cmd_track(args: argparse.Namespace) -> int:
    """Save a bet from the board to this Mac with the fair price it was found against, or say how a
    saved one ended.

    `--pick` is the block a board row's leg carried (`tracking.leg_pick`), handed back as one token;
    `--price` and `--stake` are what the person actually got and bet. Nothing here reaches a book or a
    network: it writes one row to the ledger."""
    from overlay_engine import tracking
    from overlay_engine.ledger import Ledger, LedgerError

    def refuse(message: str) -> int:
        if args.json:
            print(json.dumps({"command": "track", "error": message}, sort_keys=True))
        else:
            print(message, file=sys.stderr)
        return 2

    try:
        with Ledger(args.db) as db:
            if args.settle is not None:
                if not args.result:
                    return refuse("Say how it ended: --result won, lost, push or void.")
                out = tracking.settle(db, args.settle, args.result)
                out["ledger"] = str(db.path)
            else:
                if not args.pick:
                    return refuse("There is no bet to save. Track one from a row on the board.")
                if args.price is None or args.stake is None:
                    return refuse("Say the price you got and the amount you bet.")
                out = tracking.save(db, tracking.read_pick(args.pick), price=args.price, stake=args.stake,
                                    game=args.game or "", league=args.league or "", ref=args.ref)
    except LedgerError as exc:
        return refuse(str(exc))
    out["command"] = "track"
    if args.json:
        return emit(out)
    print(out["text"])
    return 0


def cmd_wallet(args: argparse.Namespace) -> int:
    """`wallet`: the balance the person says they have at each book, kept on this Mac. `--set BOOK AMOUNT` types
    one. Nothing here reads a book or reaches a network."""
    from overlay_engine import wallet
    from overlay_engine.ledger import Ledger, LedgerError

    try:
        with Ledger(args.db) as db:
            changed = None
            if args.set is not None:
                changed = wallet.set_balance(db, args.set[0], args.set[1])
            out = wallet.balances(db)
            out["changed"] = changed
            out["text"] = wallet.wallet_text(db)
            out["ledger"] = str(db.path)
    except LedgerError as exc:
        if args.json:
            print(json.dumps({"command": "wallet", "error": str(exc)}, sort_keys=True))
        else:
            print(exc, file=sys.stderr)
        return 2
    out["command"] = "wallet"
    if args.json:
        return emit(out)
    if changed:
        print(changed["text"])
        print()
    print(out["text"])
    return 0


def cmd_hedge(args: argparse.Namespace) -> int:
    """`hedge`: what to bet on the other side of a bet you have, and what each result then pays. Places nothing."""
    from overlay_engine import hedge
    from overlay_engine.ledger import Ledger, LedgerError
    from overlay_engine.odds import parse_odds

    try:
        if args.bet is not None:
            with Ledger(args.db) as db:
                out = hedge.for_bet(db, args.bet, args.other)
        else:
            if args.stake is None or args.held is None:
                raise OddsError("Say which saved bet (--bet ID), or type its stake and price (--stake, --held).")
            out = hedge.plan(float(str(args.stake).replace("$", "").replace(",", "")), parse_odds(args.held), args.other)
    except (OddsError, LedgerError, ValueError) as exc:
        if args.json:
            return emit({"command": "hedge", "error": str(exc)})
        print(exc, file=sys.stderr)
        return 2
    out["command"] = "hedge"
    if args.json:
        return emit(out)
    print(out["headline"])
    for r in out["rows"]:
        print(f"  {r['name']:12} hedge {r['hedge_text']:>10}   if your bet wins {r['if_held_text']:>10}   "
              f"if the other side wins {r['if_other_text']:>10}")
    for n in out["notes"]:
        print("  " + n)
    return 0


def cmd_offers(args: argparse.Namespace) -> int:
    """Whether a deposit match clears, given the markets its terms allow."""
    import time

    from overlay_engine.offers import (
        CLASSES,
        RolloverTerms,
        OfferError,
        evaluate,
        load_terms,
        measure_class_holds,
    )

    now = args.now if args.now is not None else time.time()

    # Holds are measured from a snapshot when one is given. Without it every
    # class falls back to a labelled prior, and the verdict says so rather than
    # quietly presenting a stated 4.5% as though it were this book's number.
    measured = {}
    if args.snapshot:
        from overlay_engine.feed import FeedError, ReplayProvider

        try:
            provider = ReplayProvider(args.snapshot)
        except FeedError as exc:
            print(f"cannot read snapshot: {exc}")
            return 1
        markets = []
        for sport in (args.sport or ["nfl"]):
            markets.extend(provider.fetch(sport))
        measured = measure_class_holds(markets, now=now)

    print("churn hold by market class:")
    for klass in CLASSES:
        got = measured.get(klass)
        if got:
            print(f"  {got.describe()}")
        else:
            print(f"  {klass}: not measured — a labelled prior will be used")
    if not measured:
        print()
        print("  Nothing measured. Pass --snapshot to price these off real")
        print("  quotes; every verdict below rests on a stated prior until you do.")

    verdicts = []

    if args.rollover is not None:
        eligible = frozenset(c.strip() for c in (args.eligible or "h2h").split(",")
                             if c.strip())
        try:
            terms = RolloverTerms(
                book=args.book, state=args.state.upper(),
                rollover=args.rollover, eligible=eligible, fetched_at=now,
                source="supplied on the command line",
                includes_deposit=not args.bonus_only)
            verdicts.append(evaluate(terms, args.deposit, args.bonus, measured, now))
        except OfferError as exc:
            print()
            print(f"  {exc}")
            return 1
    else:
        # `--terms` defaults to a path relative to the working directory, which
        # only exists in a checkout. Installed from the wheel and run from
        # anywhere else this is the common case, not the exotic one, so it gets
        # the same one-line refusal every other file-reading command here gives
        # rather than a traceback.
        try:
            report = load_terms(args.terms, now)
        except OSError as exc:
            print()
            print(f"cannot read terms feed: {exc}")
            print("  Point --terms at a dated, sourced CSV, or price one offer")
            print("  directly with --rollover:")
            print("    overlay offers --rollover 10 --eligible h2h,totals")
            return 1
        print()
        print(f"terms feed: {args.terms}")
        print(f"  {report.describe()}")
        for label, why in report.refused:
            print(f"    refused  {label}: {why}")
        for terms in report.terms:
            try:
                verdicts.append(
                    evaluate(terms, args.deposit, args.bonus, measured, now))
            except OfferError as exc:
                print(f"    refused  {terms.book}/{terms.state}: {exc}")
        if not report.terms:
            print()
            print("  Nothing to evaluate. Add a dated, sourced row to the feed,")
            print("  or pass --rollover to price one offer directly:")
            print("    overlay offers --rollover 10 --eligible h2h,totals")
            return 0

    print()
    for verdict in sorted(verdicts, key=lambda v: -v.margin):
        print(verdict.describe())
        print()
    return 0


def cmd_correlation(args: argparse.Namespace) -> int:
    """Measure the correlation Kelly sizing has been assuming."""
    from overlay_engine.correlation import KEYS, from_ledger
    from overlay_engine.kelly import DEFAULT_CORRELATION, simultaneous_scale
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        print(f"ledger: {db.path}")
        print()
        for key in (KEYS if args.all_keys else (args.key,)):
            got = from_ledger(db, key=key, sport=args.sport)
            print(f"grouped by {key}:")
            print(f"  {got.describe()}")
            if got.measured:
                assumed = simultaneous_scale(args.live, DEFAULT_CORRELATION)
                print(f"  {args.live} live bets scale to"
                      f" {got.scale(args.live):.3f}"
                      f" (the {DEFAULT_CORRELATION:.2f} prior said"
                      f" {assumed:.3f})")
            print()

    print("  Correlation is the reason twelve +EV bets are not twelve")
    print("  positions. Sizing each at its own optimum when they share a game")
    print("  script is one bet in twelve hats, at twelve times the stake.")
    return 0


def cmd_portfolio(args: argparse.Namespace) -> int:
    """Bankroll, exposure, correlation and the next stake, in one view."""
    from overlay_engine.ledger import Ledger
    from overlay_engine.portfolio import PortfolioError, build

    with Ledger(args.db) as db:
        try:
            view = build(db, bankroll=args.bankroll, key=args.key,
                         sport=args.sport, book=args.book)
        except PortfolioError as exc:
            print(f"cannot build a portfolio view: {exc}")
            return 1

        print(f"ledger: {db.path}")
        print()
        print(view.describe())

        if view.exposure.markets:
            print()
            print("  open markets:")
            for market in view.exposure.markets[:10]:
                print(f"    {market.describe()}")
            if len(view.exposure.markets) > 10:
                print(f"    ... and {len(view.exposure.markets) - 10} more")
    return 0


def cmd_event_meta(args: argparse.Namespace) -> int:
    """Record what an event shares with others, or show what is recorded."""
    from overlay_engine.correlation import META_KEYS, MIN_COVERAGE
    from overlay_engine.ledger import Ledger, LedgerError

    with Ledger(args.db) as db:
        print(f"ledger: {db.path}")
        if args.event:
            try:
                db.record_event_meta(
                    event_id=args.event, sport=args.sport,
                    starter=args.starter, venue=args.venue,
                    weather=args.weather)
            except LedgerError as exc:
                print(f"  {exc}")
                return 1
            recorded = db.event_meta().get(args.event, {})
            shown = ", ".join(f"{k}={v}" for k, v in sorted(recorded.items()))
            print(f"  {args.event}: {shown}")
            print()

        if args.weather:
            from overlay_engine.weather import buckets, describe

            print(f"  reading: {describe(args.weather)}")
            print(f"  bands are a stated choice, not a measurement"
                  f" &mdash; {len(buckets())} buckets in all".replace("&mdash;", "-"))
            print()

        print("  coverage across events holding bets:")
        for field in META_KEYS:
            covered, total = db.meta_coverage(field)
            share = covered / total if total else 0.0
            mark = "ok " if share >= MIN_COVERAGE else "   "
            print(f"    {mark} {field:<9} {covered}/{total}  ({share:.0%})")
        print()
        print(f"  A grouping needs {MIN_COVERAGE:.0%} before it is measured"
              " rather than a prior.")
        print("  Unrecorded events are excluded, never grouped under a blank —")
        print("  a blank would make every unrecorded event one correlated"
              " block.")
    return 0


def cmd_compare_feeds(args: argparse.Namespace) -> int:
    """Rank recorded feed trials on measured latency, or refuse to."""
    from overlay_engine.feedcompare import CompareError, compare

    try:
        result = compare(args.snapshots)
    except CompareError as exc:
        print(f"cannot compare: {exc}")
        return 1

    print(f"{len(result.samples)} trial(s):")
    print()
    print(result.describe())
    print()
    print("  Latency is the gap between the book's timestamp and receipt, so a")
    print("  feed that sends no timestamp records as instant. That is why an")
    print("  all-zero trial is left unranked rather than put first.")
    return 0


def cmd_schedule(args: argparse.Namespace) -> int:
    """What needs a closing capture now, and when to run next."""
    import time as _time

    from overlay_engine.feed import FeedError, ReplayProvider
    from overlay_engine.ledger import Ledger
    from overlay_engine.schedule import EARLIEST, LEAD, next_run_at, plan

    now = args.now if args.now is not None else _time.time()
    try:
        provider = ReplayProvider(args.snapshot)
    except FeedError as exc:
        print(f"cannot read snapshot: {exc}")
        return 1

    markets = []
    for sport in (args.sport or provider.sports()):
        markets.extend(provider.fetch(sport))

    with Ledger(args.db) as db:
        closed = db.closed_markets()
        result = plan(markets, now, closed=closed)
        upcoming = next_run_at(markets, now, closed=closed)

        print(f"ledger: {db.path}")
        print(f"  {len(markets)} market(s) in the snapshot,"
              f" {len(closed)} already closed")
        print()
        print(result.describe())
        for due in result.due[:10]:
            print(f"    {due.describe()}")
        if len(result.due) > 10:
            print(f"    ... and {len(result.due) - 10} more")

        print()
        if upcoming is None:
            print("  Nothing pending. No market here has a future start that"
                  " still needs a close.")
        else:
            print(f"  Next pass due in {(upcoming - now) / 60:.1f} min.")
        print(f"  Lead {LEAD / 60:.0f} min, earliest {EARLIEST / 60:.0f} min"
              " out. Both are stated choices, not measurements.")
    return 0


def cmd_import(args: argparse.Namespace) -> int:
    from overlay_engine.importer import ImportError_, detect_columns, import_csv
    from overlay_engine.ledger import Ledger

    source = args.path
    tmp = None
    if getattr(args, "text", None) is not None:
        # CSV content from the window, which cannot hand the engine a path.
        # Written to a private temp file only because import_csv reads a
        # path; removed afterwards whatever happens.
        import os
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix=".csv")
        with os.fdopen(fd, "w") as fh:
            fh.write(args.text)
        source = tmp
    if source is None:
        print("import needs a CSV path or --text", file=sys.stderr)
        return 2
    try:
        with Ledger(args.db) as db:
            report = import_csv(db, source, default_book=args.book,
                                default_sport=args.sport)
            if args.json:
                print(json.dumps({
                    "command": "import", "ledger": str(db.path),
                    "summary": report.describe(),
                    "imported": report.imported, "duplicates": report.duplicates,
                    "skipped": len(report.skipped), "reasons": report.reasons(),
                    "mapping": report.mapping, "profit_source": report.profit_source,
                }, indent=2, sort_keys=True))
                return 0
            print(f"ledger: {db.path}")
            print(f"  {report.describe()}")

            print()
            print(f"  columns matched ({len(report.mapping)}):")
            for field_name, column in sorted(report.mapping.items()):
                print(f"    {field_name:<16} <- {column}")

            unmatched = [f for f in ("sport", "market_type", "result", "book")
                         if f not in report.mapping]
            if unmatched:
                print(f"  not found: {', '.join(unmatched)}"
                      "  (defaults used where possible)")

            print()
            if report.profit_source == "payout":
                print("  Profit derived from a payout column — payout includes"
                      " the stake, so it")
                print("  is converted rather than read across. Reading it"
                      " across would inflate")
                print("  every winning bet by its own stake.")
            elif report.profit_source == "none":
                print("  No profit or payout column; profit derived from the"
                      " result and price.")

            if report.skipped:
                print()
                print("  skipped:")
                for reason, n in report.reasons().items():
                    print(f"    {n:>4}  {reason}")

            stats = db.stats()
            print()
            print(f"  {stats['bets']} bets in the ledger"
                  f" ({stats['imported']} imported, {stats['trainable']} trainable)")
            if stats["imported"] and not stats["trainable"]:
                print("  Imported bets track and grade but never train the"
                      " calibration —")
                print("  nobody recorded what each devig method said at bet time.")
    except ImportError_ as exc:
        print(f"cannot import: {exc}")
        return 1
    finally:
        if tmp:
            import os as _os
            _os.unlink(tmp)
    return 0


def cmd_promos(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger, LedgerError
    from overlay_engine.promo import URGENT_DAYS, report_holdings

    with Ledger(args.db) as db:
        if args.add:
            try:
                promo_id = db.record_promo(
                    book=args.book, kind=args.kind, amount=args.add,
                    boost=args.boost,
                    expires_at=(None if args.days is None
                                else __import__("time").time() + args.days * 86400),
                    note=args.note,
                )
            except LedgerError as exc:
                print(f"cannot record: {exc}")
                return 1
            print(f"recorded promo {promo_id}: {args.book} "
                  f"{args.add:,.0f} {args.kind}")
            return 0

        if args.used is not None:
            try:
                db.use_promo(args.used, realised=args.realised or 0.0)
            except LedgerError as exc:
                print(f"cannot mark used: {exc}")
                return 1
            print(f"promo {args.used} marked used, realised "
                  f"{args.realised or 0.0:,.2f}")
            return 0

        rep = report_holdings(db, conversion=args.conversion)
        print(f"ledger: {db.path}")
        print(f"  {rep.verdict()}")

        if rep.live:
            print()
            print("  held:")
            for h in sorted(rep.live, key=lambda h: h.expires_at or 1e18):
                mark = "  <- expiring" if h.urgent(rep.now) else ""
                print(f"    [{h.promo_id:>3}] {h.describe(rep.now)}{mark}")

        if rep.expired:
            print()
            print(f"  lost to expiry ({rep.lost_to_expiry:,.0f} face):")
            for h in rep.expired:
                print(f"    [{h.promo_id:>3}] {h.book} {h.amount:,.0f} "
                      f"{h.kind}")
            print("    Every one of these was money until the day it was not.")

        print()
        print(f"  Values assume {args.conversion:.0%} conversion, which depends"
              " on the hedge you")
        print("  can place — see `overlay promo --max-hedge` for the ladder.")
        if rep.urgent:
            print(f"  A bonus converted at 55% today beats one converted at 80%"
                  f" after it expires.")
    return 0


def cmd_exposure(args: argparse.Namespace) -> int:
    from overlay_engine.exposure import report as exposure_report
    from overlay_engine.ledger import Ledger

    with Ledger(args.db) as db:
        rep = exposure_report(db, book=args.book, sport=args.sport)
        print(f"ledger: {db.path}")
        print(f"  {rep.verdict()}")

        if not rep.markets:
            return 0

        print()
        for market in rep.markets:
            flag = "  [outcome set inferred]" if market.inferred else ""
            print(f"  {market.event_id} {market.market_type}"
                  f"  {market.at_risk:,.0f} at risk{flag}")
            for outcome, amount in market.scenarios():
                held = sum(p.stake for p in market.positions
                           if p.outcome == outcome)
                on = f"{held:,.0f} on" if held else "nothing on"
                print(f"      {outcome:<18} {amount:>+10,.2f}   ({on} it)")
            if market.locked:
                print("      locked — every result pays")
            print()

        print(f"  worst case {rep.worst_case:+,.2f}"
              f"   best case {rep.best_case:+,.2f}")
        print("  The worst case sums each market's worst result. That is a"
              " floor only if")
        print("  the markets are independent — same game or same starter and"
              " they can all")
        print("  land badly together.")

        if rep.concentrated:
            event, share = rep.concentration
            print()
            print(f"  {share:.0%} of your exposure rides on {event}.")

        if rep.inferred_markets:
            print()
            print(f"  {len(rep.inferred_markets)} market(s) have no recorded"
                  " quotes, so their outcome")
            print("  set comes from your own bets — the result you did not back"
                  " is invisible")
            print("  and their worst case is optimistic. Run `capture` to fix"
                  " that.")
    return 0


def cmd_tags(args: argparse.Namespace) -> int:
    from overlay_engine.ledger import Ledger, LedgerError
    from overlay_engine.performance import MIN_BETS, tag_report

    with Ledger(args.db) as db:
        if args.tag is not None:
            if args.bet is None:
                print("--tag needs --bet")
                return 1
            try:
                added = (db.untag_bet(args.bet, args.tag) if args.remove
                         else db.tag_bet(args.bet, *args.tag.split(",")))
            except LedgerError as exc:
                print(f"cannot tag: {exc}")
                return 1
            verb = "removed" if args.remove else "added"
            print(f"{verb} on bet {args.bet}: {db.tags_for(args.bet) or 'none'}")
            return 0

        rep = tag_report(db, alpha=args.alpha)
        print(f"ledger: {db.path}")
        print(f"  {rep.verdict()}")

        if not rep.slices:
            return 0

        print()
        print(f"  {'tag':<20}{'bets':>6}{'flat ROI':>11}{'interval':>20}")
        survivors = {s.label for s in rep.survivors}
        naive = {s.label for s in rep.naive_winners}
        for sl in rep.slices:
            if sl.n < MIN_BETS:
                mark = "  thin"
            elif sl.label in survivors:
                mark = "  SURVIVES"
            elif sl.label in naive:
                mark = "  luck-shaped"
            else:
                mark = ""
            band = f"{sl.roi_low:+.1%} to {sl.roi_high:+.1%}"
            print(f"  {sl.label:<20}{sl.n:>6}{sl.flat_return:>+11.2%}"
                  f"{band:>20}{mark}")

        print()
        print(f"  Bar for a single test: z {1.96:.2f}. With {rep.tests} tags"
              f" tested at once: z {rep.bar:.2f}.")
        if rep.naive_winners and not rep.survivors:
            print("  Everything that looked significant is consistent with"
                  " having tried enough")
            print("  slices. That is not a bug in the tags — it is what testing"
                  " many hypotheses")
            print("  does, and no other tracker tells you.")
    return 0


def american_to_decimal_safe(value: float) -> float | None:
    try:
        return parse_odds(value)
    except Exception:
        return None


#: what each field is called in the window, for a sentence a person can act on
_FIELD = {"stake": "the stake", "bankroll": "the bankroll", "odds": "the odds", "prob": "the win chance",
          "age": "the quote's age in seconds", "min_margin": "the minimum margin", "unit": "the unit size",
          "hold": "the hold", "state": "your state", "bonus_odds": "the bonus bet's odds", "index": "the outcome number",
          "amount": "the amount", "boost": "the boost percentage", "max_win": "the max winnings",
          "match": "the match percentage", "rollover": "the playthrough", "max_hedge": "the most you can hedge"}


class _InputError(Exception):
    """Argparse's complaint about what was typed, kept for a plain sentence instead of a usage dump."""


class _Parser(argparse.ArgumentParser):
    """An ArgumentParser that, when the window is asking (--json), raises instead of printing usage and
    exiting: the window shows the error text it gets, and argparse's is written for a terminal."""
    json_mode = False

    def error(self, message):
        if _Parser.json_mode:
            raise _InputError(message)
        super().error(message)


def plain_input_error(message: str) -> str:
    """Argparse's message as one plain sentence: what was wrong and what to type instead."""
    import re
    m = re.match(r"argument (?:--)?([\w-]+): invalid (?:float|int) value: '(.*)'", message)
    if m:
        field = _FIELD.get(m.group(1).replace("-", "_"), m.group(1).replace("-", " "))
        hint = "like -110 or +150" if field == "the odds" else "like 100" if field in (
            "the stake", "the bankroll", "the unit size") else "as a number"
        return f"'{m.group(2)}' is not a number. Type {field} {hint}."
    m = re.match(r"the following arguments are required: (.*)", message)
    if m:
        names = [_FIELD.get(n.strip().lstrip("-").replace("-", "_"), n.strip()) for n in m.group(1).split(",")]
        return "Fill in " + " and ".join(names) + " first."
    return f"That could not be read: {message}."



def cmd_parlays(args: argparse.Namespace) -> int:
    """`parlays`: every yardage and receptions prop priced, then the best same-game parlays and a day plan.
    The cost is said first; `--stored` spends nothing."""
    from overlay_engine import keystore, oddsapi, propparlay as pp

    def refuse(exc, reason) -> int:
        if args.json:
            print(json.dumps({"command": "parlays", "error": str(exc), "reason": reason}, sort_keys=True))
        else:
            print(f"{exc}", file=sys.stderr)
        return 2

    state = (args.state or "").strip().upper() or None
    context = pp.context_from_nflverse()

    def done(got, est=None) -> int:
        view = pp.build(got, state=state, book=args.book, tickets=args.tickets, stake=args.stake, context=context)
        if est is not None:
            view["estimate"] = est.as_dict()
        if args.json:
            return emit({"command": "parlays", **view})
        return _print_parlays(view)

    if args.stored:
        got = pp.load()
        if got is None:
            return refuse(oddsapi.OddsApiError("No player props have been read on this Mac in the last two days. "
                                               "Run parlays without --stored to read them.", "not_read"), "not_read")
        return done(got)
    cache = oddsapi.Cache()
    try:
        key = None
        ids = args.game
        if not ids:
            key = keystore.get_key()
            if not key:
                raise oddsapi.OddsApiError(oddsapi.NO_KEY, "no_key")
            ids = [g["id"] for g in pp.upcoming_games(key, cache=cache)[:max(1, args.games)]]
            if not ids:
                raise oddsapi.OddsApiError("No NFL games in the next seven days.", "no_games")
        est = pp.estimate(ids)
        if args.estimate:
            if args.json:
                return emit({"command": "parlays", "estimate": est.as_dict(), "credits": cache.recall()})
            print(est.sentence())
            print(f"Rule: {pp.COST_RULE}")
            print(f"      ({pp.COST_RULE_SOURCE})")
            print("Nothing was fetched and no credits were spent.")
            return 0
        key = key or keystore.get_key()
        if not key:
            raise oddsapi.OddsApiError(oddsapi.NO_KEY, "no_key")
        if not args.json:
            print(est.sentence(), flush=True)
        left = (cache.recall() or {}).get("remaining")
        got = pp.read(est, key, cache=cache, remaining=left)
    except keystore.KeyStoreError as exc:
        return refuse(exc, "keychain")
    except oddsapi.OddsApiError as exc:
        return refuse(exc, exc.reason)
    finally:
        key = None
    return done(got, est)


def _print_parlays(view: dict) -> int:
    if view.get("warning"):
        print(view["warning"])
    print(f"\n{view['all_legs']} legs priced, {view['value_legs']} priced better than fair at a book you can bet at.")
    print("\nLegs, smallest margin first")
    for x in view["legs"][:12]:
        print(f"  {x['label']:<40} fair {x['fair_american']:+d}  best {x['best_american']:+d} at {', '.join(x['books'])}"
              f"  {x['ev'] * 100:+.1f}% value  ({x['game']})")
        for why in x.get("red", []):
            print(f"      kept off tickets: {why}")
        for why in x.get("green", []):
            print(f"      in its favour: {why}")
    print("\nSame-game parlays (one per game)")
    for t in view["same_game"][:8]:
        print(f"  {t['game']}: fair chance it lands {t['chance'] * 100:.0f}%. Fair {t['fair_american']:+d}; the legs multiplied "
              f"pay {t['legs_multiplied_american']:+d}, a cost of {t['cost_vs_fair'] * 100:+.1f}% against fair "
              f"(a same-game price is usually shorter). It only beats the fair price at {t['take_at_or_longer']:+d} "
              f"or longer; below that it costs you money on average.")
        if t.get("correlation_note"):
            print(f"     Correlated: {', '.join(t['correlated'])}. {t['correlation_note']}")
        for x in t["legs"]:
            print(f"     {x['label']}")
    if view.get("across_games"):
        c = view["across_games"]
        print(f"\nAcross games at {c['book']}: pays {c['price_american']:+d} against a fair {c['fair_american']:+d}, "
              f"fair chance it lands {c['chance'] * 100:.0f}%, a cost of {c['cost_vs_fair'] * 100:+.1f}% against fair")
        for x in c["legs"]:
            print(f"     {x['label']} ({x['game']})")
    plan = view["plan"]
    print(f"\nDay plan, {plan.get('stake', 0):.0f} in all")
    for t in plan["tickets"]:
        print(f"  {t['stake']:>6.2f}  {t['game']}  ({t['chance'] * 100:.0f}%){'  anchor' if t['role'] else ''}")
    if plan.get("chance_at_least_one") is not None:
        print(f"  Fair chance at least one ticket lands: {plan['chance_at_least_one'] * 100:.0f}%.")
    print(plan["note"])
    if view.get("kept_off"):
        print(f"{view['kept_off']} legs were kept off every ticket: an injury tag, or usage falling.")
    if not view["stacked"]:
        print("No nflverse data on this Mac, so stacks, injury tags and usage are not checked. Ask's data update adds it.")
    print(view["note"])
    return 0

def main(argv: list[str] | None = None) -> int:
    # First thing, before anything else initialises: an import-time failure is
    # exactly the crash that produces "it doesn't open", and a handler
    # installed later cannot see it.
    from overlay_engine import crash

    crash.install()

    # Raw, because the description is a list of example invocations and the
    # default formatter reflows them into one paragraph — which is exactly the
    # part of `--help` a new user copies out of.
    _Parser.json_mode = "--json" in (sys.argv[1:] if argv is None else argv)
    parser = _Parser(
        prog="overlay", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    # `--json` goes after the subcommand, and only there. It was briefly on
    # the top-level parser as well, which meant `overlay --json devig` parsed
    # fine and then printed a table: the subparser's own default overwrote the
    # flag. An unrecognised-argument error is a worse experience than working,
    # and a far better one than silently ignoring what was asked for. Argparse puts a
    # top-level flag before the subcommand only, and `overlay --json devig` is
    # not what anyone types — a parent parser gives every subcommand the same
    # flag so both forms work and no subparser has to remember to add it.
    machine = argparse.ArgumentParser(add_help=False)
    machine.add_argument("--json", action="store_true",
                         help="emit the result as JSON for a UI to read")
    sub = parser.add_subparsers(dest="command", required=True,
                                parser_class=lambda **kw: _Parser(
                                    parents=[machine], **kw))

    p = sub.add_parser("devig", help="devig a market by every method")
    p.add_argument("odds", nargs="+")
    p.add_argument("--index", type=int, default=None,
                   help="report break-even prices for this outcome")
    p.add_argument("--method", default="consensus", choices=list(DEVIG_CHOICES),
                   help="how the headline fair price removes the cut: consensus (default), one method, or worst "
                        "(the lowest chance any method gives, the cautious price)")
    p.set_defaults(func=cmd_devig)

    p = sub.add_parser("arb", help="check and stake an arbitrage")
    p.add_argument("odds", nargs="+")
    p.add_argument("--stake", type=float, default=1000.0,
                   help="the most to bet across every leg; the plan never stakes more")
    p.add_argument("--round", default="auto", choices=ROUNDING,
                   help="round each bet to this many dollars, 'exact' for cents, "
                        "or 'auto' for a step that suits the size")
    p.add_argument("--lock", default=None, metavar="SIDE=STAKE",
                   help="hold one side at this stake (1=250) and size the others to the cent around it")
    p.add_argument("--target", default=None, metavar="AMOUNT",
                   help="the smallest total, at the rounding chosen, that locks at least this amount")
    p.set_defaults(func=cmd_arb)

    p = sub.add_parser("fill", help="fill probability for a quote age")
    p.add_argument("--book", default="dk")
    p.add_argument("--market", default="h2h")
    p.add_argument("--age", type=float, default=10.0)
    p.add_argument("--db", default=None,
                   help="use measured quote life and latency from this ledger")
    p.set_defaults(func=cmd_fill)

    p = sub.add_parser("kelly", help="size a bet")
    p.add_argument("--odds", required=True)
    p.add_argument("--prob", type=float, default=None,
                   help="your win chance; not used when --sharp prices are given")
    p.add_argument("--sharp", action="append", default=None, metavar="THIS/OTHER",
                   help="a sharp book's two prices for this market, this side first (-120/+105); repeat per book. "
                        "The fair chance is worked out from them and the stake sized on the worst case")
    p.add_argument("--method", default="consensus", choices=list(DEVIG_CHOICES),
                   help="with --sharp: how each book's cut is removed (as devig --method)")
    p.add_argument("--prob-low", type=float, default=None)
    p.add_argument("--bankroll", type=float, default=10_000.0)
    p.add_argument("--fraction", type=float, default=0.25)
    p.set_defaults(func=cmd_kelly)

    p = sub.add_parser("demo", help="run a full market through the pipeline")
    p.add_argument("--bankroll", type=float, default=10_000.0)
    p.add_argument("--db", default=None,
                   help="price with the calibration in this ledger")
    p.set_defaults(func=cmd_demo)

    p = sub.add_parser("books", help="venues you can legally use in a state")
    p.add_argument("state")
    p.add_argument("--unverified", action="store_true",
                   help="also show venues whose jurisdiction is unconfirmed")
    p.set_defaults(func=cmd_books)

    p = sub.add_parser("ledger", help="what the local record holds, and what it can teach")
    p.add_argument("--db", default=None,
                   help="database path (default ~/.overlay/overlay.db, or $OVERLAY_HOME)")
    p.set_defaults(func=cmd_ledger)

    p = sub.add_parser("tags", help="per-tag performance, corrected for how many you tested")
    p.add_argument("--db", default=None)
    p.add_argument("--bet", type=int, default=None, help="bet id to tag")
    p.add_argument("--tag", default=None,
                   help="comma-separated tags to add to --bet")
    p.add_argument("--remove", action="store_true", help="remove --tag instead")
    p.add_argument("--alpha", type=float, default=0.05)
    p.set_defaults(func=cmd_tags)

    p = sub.add_parser("exposure", help="open positions and what each result pays")
    p.add_argument("--db", default=None)
    p.add_argument("--book", default=None)
    p.add_argument("--sport", default=None)
    p.set_defaults(func=cmd_exposure)

    p = sub.add_parser("promos", help="promotions held, what they are worth, what expires")
    p.add_argument("--db", default=None)
    p.add_argument("--conversion", type=float, default=0.75,
                   help="assumed bonus-bet conversion rate")
    p.add_argument("--add", type=float, default=None,
                   help="record a promo of this face value")
    p.add_argument("--book", default="unknown")
    p.add_argument("--kind", default="bonus_bet",
                   choices=("bonus_bet", "profit_boost"))
    p.add_argument("--boost", type=float, default=None,
                   help="boost fraction, for a profit boost")
    p.add_argument("--days", type=float, default=None,
                   help="days until it expires")
    p.add_argument("--note", default="")
    p.add_argument("--used", type=int, default=None, metavar="ID",
                   help="mark a promo used")
    p.add_argument("--realised", type=float, default=None,
                   help="what it actually converted to")
    p.set_defaults(func=cmd_promos)

    p = sub.add_parser("paste", help="read a bet out of a pasted betslip")
    p.add_argument("path", nargs="?", default="-",
                   help="file to read, or - for stdin (the default)")
    p.add_argument("--db", default=None)
    p.add_argument("--write", action="store_true",
                   help="record it; without this the reading is only shown")
    p.add_argument("--event", default=None, help="event id, required by --write")
    p.add_argument("--sport", default="unknown")
    p.add_argument("--text", default=None,
                   help="the slip itself, for callers with no stdin")
    p.set_defaults(func=cmd_paste)

    p = sub.add_parser("track", help="save a bet from the board with its fair price, or settle a saved one")
    p.add_argument("--pick", default=None,
                   help="the bet as the board sent it (one JSON token)")
    p.add_argument("--price", default=None, help="the price you got, like +110, -150 or 2.10")
    p.add_argument("--stake", default=None, help="what you bet")
    p.add_argument("--game", default=None, help="the game, as the board named it")
    p.add_argument("--league", default=None)
    p.add_argument("--ref", default=None,
                   help="a token that makes saving the same bet twice save it once")
    p.add_argument("--settle", type=int, default=None, metavar="ID", help="say how bet ID ended")
    p.add_argument("--result", default=None, choices=("won", "lost", "push", "void"))
    p.add_argument("--db", default=None)
    p.set_defaults(func=cmd_track)

    p = sub.add_parser("wallet", help="the balance you have at each book, kept on this Mac; type one with --set")
    p.add_argument("--set", nargs=2, default=None, metavar=("BOOK", "AMOUNT"),
                   help="type what is in a book's account, like --set dk 250")
    p.add_argument("--db", default=None)
    p.set_defaults(func=cmd_wallet)

    p = sub.add_parser("hedge", help="what to bet on the other side of a bet you have, and what each result pays")
    p.add_argument("--bet", type=int, default=None, metavar="ID", help="a saved, open bet in My bets")
    p.add_argument("--other", required=True, help="the other side's price now, like -120 or +105")
    p.add_argument("--stake", default=None, help="without --bet: what you bet")
    p.add_argument("--held", default=None, help="without --bet: the price you got")
    p.add_argument("--db", default=None)
    p.set_defaults(func=cmd_hedge)

    p = sub.add_parser(
        "offers", help="does a deposit match clear, given what it lets you churn in")
    p.add_argument("--terms", default="data/offer_terms.csv",
                   help="dated, sourced terms feed keyed by (book, state)")
    p.add_argument("--snapshot", default=None,
                   help="quote snapshot to measure class holds from")
    p.add_argument("--sport", action="append", default=None)
    p.add_argument("--deposit", type=float, default=1000.0)
    p.add_argument("--bonus", type=float, default=1000.0)
    p.add_argument("--rollover", type=float, default=None,
                   help="price one offer directly instead of reading the feed")
    p.add_argument("--eligible", default=None,
                   help="comma-separated market classes the rollover allows")
    p.add_argument("--book", default="adhoc")
    p.add_argument("--state", default="--")
    p.add_argument("--bonus-only", action="store_true",
                   help="rollover applies to the bonus alone, not deposit+bonus")
    p.add_argument("--now", type=float, default=None)
    p.set_defaults(func=cmd_offers)

    p = sub.add_parser(
        "correlation",
        help="measure how much your simultaneous bets actually co-move")
    p.add_argument("--db", default=None)
    p.add_argument("--key", default="event",
                   choices=("event", "day", "sport_day",
                            "starter", "venue", "weather"),
                   help="what counts as resolving together")
    p.add_argument("--all-keys", action="store_true",
                   help="report every grouping")
    p.add_argument("--sport", default=None)
    p.add_argument("--live", type=int, default=12,
                   help="how many simultaneous bets to size for")
    p.set_defaults(func=cmd_correlation)

    p = sub.add_parser(
        "portfolio",
        help="bankroll, exposure and correlation in one view")
    # Required, and deliberately so: nothing in the ledger knows the bankroll,
    # and a default would make every ratio here a fiction with a percent sign.
    p.add_argument("--bankroll", type=float, required=True)
    p.add_argument("--db", default=None)
    p.add_argument("--key", default="event",
                   choices=("event", "day", "sport_day",
                            "starter", "venue", "weather"),
                   help="what counts as resolving together")
    p.add_argument("--sport", default=None)
    p.add_argument("--book", default=None)
    p.set_defaults(func=cmd_portfolio)

    p = sub.add_parser(
        "event-meta",
        help="record what an event shares with others (starter, venue, weather)")
    p.add_argument("--db", default=None)
    p.add_argument("--event", default=None,
                   help="event id to record; omit to show coverage only")
    p.add_argument("--sport", default=None)
    p.add_argument("--starter", default=None)
    p.add_argument("--venue", default=None)
    p.add_argument("--weather", default=None)
    p.set_defaults(func=cmd_event_meta)

    p = sub.add_parser(
        "compare-feeds",
        help="rank recorded feed trials on measured latency")
    p.add_argument("snapshots", nargs="+",
                   help="snapshot files, one recorded trial per candidate")
    p.set_defaults(func=cmd_compare_feeds)

    p = sub.add_parser(
        "schedule", help="which markets need a closing capture, and when")
    p.add_argument("snapshot")
    p.add_argument("--db", default=None)
    p.add_argument("--sport", action="append", default=None)
    p.add_argument("--now", type=float, default=None)
    p.set_defaults(func=cmd_schedule)

    p = sub.add_parser(
        "parlay", help="what a parlay pays against what it should")
    p.add_argument("odds", nargs="+",
                   help="each leg's price, American or decimal")
    p.add_argument("--same-game", action="store_true",
                   help="legs are in one game, so they are not independent")
    p.set_defaults(func=cmd_parlay)

    p = sub.add_parser(
        "contract", help="a Kalshi or Polymarket US price, as the odds it pays after the venue's fee")
    p.add_argument("price", help="the contract's price in cents, like 47")
    p.add_argument("--venue", default="kalshi", help="kalshi or polymarket")
    p.add_argument("--sport", default="", help="the league (Kalshi charges baseball game series half the fee: mlb)")
    p.add_argument("--contracts", type=int, default=100, help="how many contracts in the order (default 100)")
    p.set_defaults(func=cmd_contract)

    p = sub.add_parser(
        "kparlay", help="a fair price for a parlay across games, from Kalshi's game-winner prices (no key)")
    p.add_argument("--list", action="store_true", help="list the open games and what to type to pick each side")
    p.add_argument("--pick", action="append", help="REF:TEAM from --list; repeat, one per game")
    p.add_argument("--book-odds", help="a sportsbook's price for the same parlay, like +359, to judge against fair")
    p.add_argument("--state", help="two letters, like MI: says whether Kalshi is open there")
    p.add_argument("--league", action="append", help="nfl, nba, nhl or mlb; repeatable (default: all)")
    p.set_defaults(func=cmd_kparlay)

    p = sub.add_parser("parlays", help="price every NFL yardage and receptions prop, and show what a parlay of them costs against its fair price")
    p.add_argument("--state", help="two letters, like MI: only books licensed there are priced")
    p.add_argument("--book", default="fd", help="the book you will place them at, by engine key (default fd)")
    p.add_argument("--game", action="append", help="an Odds API game id; repeat for more (default: the soonest)")
    p.add_argument("--games", type=int, default=3, help="how many of the soonest games to read (default 3)")
    p.add_argument("--tickets", type=int, default=5, help="how many tickets in the day plan (default 5)")
    p.add_argument("--stake", type=float, default=50.0, help="the day's total stake (default 50)")
    p.add_argument("--estimate", action="store_true", help="say what the read costs and stop")
    p.add_argument("--stored", action="store_true", help="build from the last read on this Mac; spends nothing")
    p.set_defaults(func=cmd_parlays)

    p = sub.add_parser("board", help="every play on one board, best first")
    p.add_argument("--snapshot", default=None,
                   help="a recorded snapshot to scan instead of the demo market")
    p.add_argument("--bankroll", type=float, default=1000.0)
    p.add_argument("--min-margin", type=float, default=0.0,
                   help="hide anything under this margin, in percent")
    p.add_argument("--kind", action="append", choices=("arb", "ev", "middle"),
                   help="limit to one kind of play; repeatable")
    p.add_argument("--min-ev", type=float, default=0.0,
                   help="hide +EV plays under this edge, in percent")
    p.add_argument("--kelly-bankroll", type=float, default=None,
                   help="your bankroll for +EV bets: each +EV play gets a suggested stake")
    p.add_argument("--kelly-fraction", type=float, default=0.25,
                   help="the share of the full Kelly stake to suggest (default a quarter)")
    p.add_argument("--feed", choices=("oddsapi",), default=None,
                   help="read live sportsbook odds from The Odds API with your own "
                        "key (save it with `key set`). It says what the refresh "
                        "will cost in credits before it fetches, and what it did "
                        "cost after. Without this flag nothing here touches a network.")
    p.add_argument("--sport", action="append", default=None,
                   choices=("nfl", "ncaaf", "nba", "ncaab", "mlb", "nhl"),
                   help="with --feed: a league to read; repeatable. Default: the "
                        "leagues in season")
    p.add_argument("--region", action="append", default=None,
                   choices=("us", "us2", "eu", "us_ex"),
                   help="with --feed: a bookmaker region; repeatable. Default: us "
                        "and eu (Europe carries Pinnacle, which prices fair odds)")
    p.add_argument("--market", action="append", default=None,
                   choices=("h2h", "spreads", "totals"),
                   help="with --feed: a bet type; repeatable. Default: h2h "
                        "(each one multiplies the cost)")
    p.add_argument("--estimate", action="store_true",
                   help="with --feed: say what a refresh would cost and fetch nothing")
    from overlay_engine import oddsapi as _oddsapi
    p.add_argument("--props", action="store_true",
                   help="with --feed: ALSO read player props (off unless you add this). "
                        "They are read one game at a time and cost far more: the estimate "
                        "says how many games and markets it counts before anything is fetched")
    p.add_argument("--prop", action="append", default=None, choices=_oddsapi.PROP_KEYS,
                   help="with --props: a player prop market to read, e.g. player_pass_yds; "
                        "repeatable. Default: three or two for each league")
    p.add_argument("--prop-region", action="append", default=None,
                   choices=("us", "us2", "eu", "us_ex"),
                   help="with --props: a region to read props from; repeatable. Default: us "
                        "(each region multiplies the props cost)")
    p.add_argument("--prop-games", type=int, default=None,
                   help="with --props: how many games per league, soonest first "
                        f"(1 to {_oddsapi.MAX_PROP_GAMES}, default {_oddsapi.DEFAULT_PROP_GAMES})")
    from overlay_engine import futures as _futures
    p.add_argument("--futures", action="store_true",
                   help="with --feed: read futures (who wins the title) for the leagues you pick with "
                        "--futures-league. Off unless you add this. Each futures market costs a credit per "
                        "region: --estimate says how many before anything is fetched")
    p.add_argument("--futures-league", action="append", default=None, choices=_futures.aliases(),
                   help="with --futures: a league's futures to read; repeatable. Nothing else is ever read")
    p.add_argument("--futures-region", action="append", default=None,
                   choices=("us", "us2", "eu", "us_ex"),
                   help="with --futures: a region to read futures from; repeatable. Default: us and eu "
                        "(Europe carries Pinnacle, which prices fair odds; each region multiplies the cost)")
    p.add_argument("--alt-lines", action="store_true",
                   help="with --feed: read one game's alternate spreads and totals (--alt-league and --alt-event). "
                        "Off unless you add this. It costs up to markets x regions credits for that one game: "
                        "--estimate says how many before anything is fetched")
    p.add_argument("--alt-stored", action="store_true",
                   help="with --feed: open one game's alternate lines already read on this Mac (--alt-league and "
                        "--alt-event). Reads files only: no key, no request, no credits")
    p.add_argument("--alt-league", default=None, help="with --alt-lines or --alt-stored: the game's league, like nfl")
    p.add_argument("--alt-event", default=None, help="with --alt-lines or --alt-stored: the game's Odds API id")
    p.add_argument("--alt-market", action="append", default=None, choices=("alternate_spreads", "alternate_totals"),
                   help="with --alt-lines: a ladder to read; repeatable. Default: both")
    p.add_argument("--alt-region", action="append", default=None, choices=("us", "us2", "eu", "us_ex"),
                   help="with --alt-lines: a region to read; repeatable. Default: us and eu")
    p.add_argument("--futures-stored", action="store_true",
                   help="with --feed: open the futures already read on this Mac, with every price's age. "
                        "Reads files only: no key, no request, no credits")
    p.add_argument("--screen", action="store_true",
                   help="with --feed: lay out the prices already read on this Mac as a grid, "
                        "one column per sportsbook. Reads files only: no key, no request, no credits")
    p.add_argument("--lowhold", action="store_true",
                   help="with --feed: list the two-way markets already read on this Mac, cheapest to cover "
                        "first (lowest combined hold), with what putting an amount through costs. Reads "
                        "files only: no key, no request, no credits")
    p.add_argument("--credit-book", default=None,
                   help="with --lowhold: the book where you have bonus money to play through, by key "
                        "(dk, fd, mgm...); every row then has a bet there")
    p.add_argument("--amount", type=float, default=None,
                   help="with --lowhold: the amount to put through. With a credit book it is what you "
                        "bet there; otherwise the total across both bets (default 1000)")
    for flag, what in (("--credit-min", "the lowest odds for the bet at your credit book"),
                       ("--credit-max", "the highest odds for the bet at your credit book"),
                       ("--other-min", "the lowest odds for the other bet (each bet, with no credit book)"),
                       ("--other-max", "the highest odds for the other bet (each bet, with no credit book)")):
        p.add_argument(flag, default=None, metavar="AMERICAN",
                       help=f"with --lowhold: {what}, as American odds; write a minus price with = "
                            "(--credit-min=-200). Only pairs inside the limits are listed")
    p.add_argument("--live", action="store_true",
                   help="fetch live prices from the public, keyless venues "
                        "(Kalshi, Polymarket US) and list the pairs that pay, "
                        "after both venues' fees, at the size on offer. "
                        "Off by default: without this flag nothing here "
                        "touches a network.")
    p.add_argument("--alerts", default=None, metavar="JSON",
                   help="with --json and --live or --feed: the window's alert setting as one JSON object "
                        "(min_ev, min_arb, kinds, recommended_only). After this read, plays that are new "
                        "since the previous read on this Mac and meet it are marked and worded. Reads "
                        "nothing of its own and never runs by itself")
    p.add_argument("--hidden", default=None, metavar="JSON",
                   help="with --json and --live or --feed: the plays the window has hidden, as a JSON array of "
                        "{key, starts_at}. Hidden plays do not alert, and an entry that is off the board once its "
                        "game has started is named in the answer's `hidden.drop`. Hides nothing itself: every play "
                        "is still sent")
    p.add_argument("--formula", default=None, metavar="JSON",
                   help="your EV formula, as one JSON object {weights: {book: 0 to 10}, threshold: 0 to 100}. A +EV "
                        "bet is priced against the weighted blend of those books and shown only when at least the "
                        "threshold's share of their weight priced the market. All weights 0 is no formula. Works "
                        "on prices already read: it spends no credits and never changes a region")
    p.add_argument("--formula-paused", action="store_true",
                   help="with --formula: hold the formula and price with the engine's own blend. The window sets "
                        "this while Recommended is on")
    p.add_argument("--state", type=_state_code, default=None,
                   help="where you bet (two letters). With --live, a pair is listed only if both venues are open "
                        "there; where either is restricted nothing is read, and without it no pair is listed. With "
                        "--feed oddsapi (the board, --screen and --lowhold), every best price, leg and alert is at a "
                        "sportsbook licensed in that state; without it, at any book on the US list, and the answer "
                        "says to pick a state.")
    from overlay_engine import boardfilter as _bf
    p.add_argument("--sort", choices=_bf.SORTS, default=None,
                   help="the order of the board: return (the dollars a play pays), edge (the headline percentage) or "
                        "start (soonest game first). Without it the board keeps its own order, by what survives")
    p.add_argument("--min-price", default=None, metavar="AMERICAN",
                   help="hide +EV bets priced under this American price, like -150 or +100 (write --min-price=-150). "
                        "Arbs and middles are priced as a pair and are not held to it")
    p.add_argument("--max-price", default=None, metavar="AMERICAN",
                   help="hide +EV bets priced over this American price, like +300. Arbs and middles are not held to it")
    p.add_argument("--game-state", choices=_bf.STATES, default=None,
                   help="show only plays whose game has not started, or is in play, by the start time in the data. A "
                        "play with no start time in the data is left out")
    p.add_argument("--within", choices=_bf.WITHIN, default=None,
                   help="show only plays whose game starts in the next hour, today (midnight to midnight on this Mac), "
                        "the next 24 hours or the next 7 days. A play with no start time in the data is left out")
    p.add_argument("--league-off", action="append", default=None, metavar="LEAGUE",
                   help="leave a league off the board, by the name the board shows (NBA, NFL, ...); repeatable")
    p.add_argument("--bet-type-off", action="append", default=None, metavar="BET_TYPE",
                   help="leave a bet type off the board: h2h, spreads, totals, or a prop's name; repeatable")
    p.add_argument("--min-window", default=None, metavar="POINTS",
                   help="hide middles whose window (the gap between the two lines) is under this many points. Arbs "
                        "and +EV bets have no window and are not held to it")
    # --json comes from the shared `machine` parent every subparser inherits.
    p.set_defaults(func=cmd_board)

    p = sub.add_parser(
        "key", help="your Odds API key, kept in the Mac's Keychain: set, status, clear")
    ksub = p.add_subparsers(dest="key_action", required=True,
                            parser_class=lambda **kw: _Parser(parents=[machine], **kw))
    k = ksub.add_parser(
        "set", help="save the key. It is read from standard input, never typed "
                    "as an argument: `pbpaste | overlay key set`",
        description="Reads the key from standard input, never from an argument, so "
                    "no program can see it in `ps`. Use: pbpaste | overlay key set")
    k.add_argument("--service", choices=("oddsapi", "anthropic"), default="oddsapi",
                   help="which key: the Odds API key (default) or the Anthropic key Ask uses")
    k.set_defaults(func=cmd_key)
    k = ksub.add_parser("status", help="whether a key is set, and its last four characters")
    k.add_argument("--service", choices=("oddsapi", "anthropic"), default="oddsapi")
    k.set_defaults(func=cmd_key)
    k = ksub.add_parser("clear", help="delete the key (and, for the Odds API key, the odds it fetched)")
    k.add_argument("--service", choices=("oddsapi", "anthropic"), default="oddsapi")
    k.set_defaults(func=cmd_key)

    p = sub.add_parser("welcome", help="every welcome offer, ranked by what it converts to")
    p.add_argument("--bonus-odds", type=float, default=4.0,
                   help="decimal odds you place bonus bets at (prior: 4.0, i.e. +300)")
    p.add_argument("--hold", type=float, default=2.0,
                   help="combined hold across the best two books, percent (prior: 2.0)")
    p.add_argument("--have", default="",
                   help="books you already have accounts at (welcome offers are for new customers)")
    p.add_argument("--state", default="",
                   help="your state; offers from books not licensed there are marked, not priced")
    p.set_defaults(func=cmd_welcome)

    p = sub.add_parser("deposit", help="which books to fund in your state, in what order, and how much in each")
    p.add_argument("state", type=_state_code, help="your state, two letters")
    p.add_argument("bankroll", type=float, help="what you have to deposit across all the books, in dollars")
    p.add_argument("--have", default="",
                   help="books you already have accounts at (welcome offers are for new customers)")
    p.add_argument("--bonus-odds", type=float, default=4.0,
                   help="decimal odds you place bonus bets at (prior: 4.0, i.e. +300)")
    p.add_argument("--hold", type=float, default=2.0,
                   help="combined hold across the best two books, percent (prior: 2.0)")
    p.set_defaults(func=cmd_deposit)

    p = sub.add_parser("crashes", help="crash reports written on this machine")
    p.add_argument("--bundle", action="store_true",
                   help="zip them so you can send them yourself")
    p.set_defaults(func=cmd_crashes)

    p = sub.add_parser("roundrobin",
                       help="every parlay of a size, and what must land")
    p.add_argument("legs", nargs="+", help="decimal or american odds per leg")
    p.add_argument("--by", type=int, nargs="+", default=[2],
                   help="parlay sizes, e.g. --by 2 3")
    p.add_argument("--stake", type=float, default=10.0,
                   help="stake on each ticket")
    p.add_argument("--probs", type=float, nargs="+", default=None,
                   help="your probability for each leg, if you have one")
    p.add_argument("--correlated", action="store_true",
                   help="legs are from the same game, so independence is false")
    p.set_defaults(func=cmd_roundrobin)

    p = sub.add_parser("poisson",
                       help="scorelines and totals from two scoring rates")
    p.add_argument("home", type=float, help="home expected goals")
    p.add_argument("away", type=float, help="away expected goals")
    p.add_argument("--line", type=float, default=2.5, help="totals line")
    p.add_argument("--over-odds", default=None,
                   help="the book's price on the over, to compare against")
    p.set_defaults(func=cmd_poisson)

    p = sub.add_parser("lowhold",
                       help="cheapest way to turn money over, and its cost")
    p.add_argument("quotes", nargs="+", metavar="BOOK:SIDE:PRICE",
                   help="e.g. dk:home:-110 fd:away:+105")
    p.add_argument("--turnover", type=float, default=1000.0,
                   help="how much you intend to put through")
    p.add_argument("--top", type=int, default=5,
                   help="how many pairings to rank")
    p.set_defaults(func=cmd_lowhold)

    p = sub.add_parser("import", help="read a book's CSV bet history into the ledger")
    p.add_argument("path", nargs="?", default=None)
    p.add_argument("--text", default=None,
                   help="the CSV itself, for callers that cannot pass a path")
    p.add_argument("--db", default=None)
    p.add_argument("--book", default="unknown",
                   help="book name for files that do not carry one")
    p.add_argument("--sport", default="unknown",
                   help="sport for files that do not carry one")
    p.set_defaults(func=cmd_import)

    p = sub.add_parser("performance", help="P&L, ROI and win rate, with intervals")
    p.add_argument("--db", default=None)
    p.add_argument("--sport", default=None)
    p.add_argument("--book", default=None)
    p.add_argument("--market", default=None)
    p.add_argument("--min-odds", default=None)
    p.add_argument("--max-odds", default=None)
    p.add_argument("--unit", type=float, default=None,
                   help="stake size for reporting profit in units")
    p.add_argument("--csv", default=None, help="export to this path instead")
    p.set_defaults(func=cmd_performance)

    p = sub.add_parser("middles",
                       help="price a middle against counted margins or totals")
    p.add_argument("low", type=float, help="the lower line")
    p.add_argument("high", type=float, help="the higher line")
    p.add_argument("--low-odds", default="-110")
    p.add_argument("--high-odds", default="-110")
    p.add_argument("--sport", default="nfl")
    p.add_argument("--stake", type=float, default=1000.0)
    p.add_argument("--market", default="spreads", choices=("spreads", "totals"),
                   help="a margin middle or an over/under one")
    # No default. A default here would be an override on every run, and the
    # measured standard deviation could then never be used — the fallback
    # would silently outrank the measurement it exists to stand in for.
    p.add_argument("--sigma", type=float, default=None,
                   help="override the spread of the normal fallback")
    p.add_argument("--db", default=None,
                   help="use counted margins or totals from this ledger")
    p.set_defaults(func=cmd_middles)

    p = sub.add_parser("capture", help="store a snapshot of markets into the ledger")
    p.add_argument("snapshot", help="path to a recorded snapshot JSON file")
    p.add_argument("--db", default=None)
    p.add_argument("--sport", action="append", default=[],
                   help="limit to these sports (repeatable)")
    p.add_argument("--closing", action="store_true",
                   help="mark these quotes as the closing line")
    p.set_defaults(func=cmd_capture)

    p = sub.add_parser("grade", help="settle bets against recorded closing lines")
    p.add_argument("--db", default=None)
    p.add_argument("--allow-retail", action="store_true",
                   help="grade off a soft book's close when no sharp one exists")
    p.set_defaults(func=cmd_grade)

    p = sub.add_parser("calibrate", help="refit devig weights from the graded log")
    p.add_argument("--db", default=None)
    p.add_argument("--holdout", type=float, default=0.3,
                   help="fraction of the log, most recent first, held back to verify")
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(func=cmd_calibrate)

    p = sub.add_parser("promo", help="what a welcome offer is really worth")
    p.add_argument("--bonus", type=float, default=1000.0)
    p.add_argument("--max-hedge", type=float, default=None,
                   help="most you can stake at the hedging book")
    p.add_argument("--state", default="")
    # Convert my own promo: one promo the person holds, priced and paired.
    p.add_argument("--type", default=None, choices=("bonus_bet", "refund", "boost", "deposit_match"),
                   help="convert a promo you hold instead of listing the welcome offers")
    p.add_argument("--book", default="", help="the sportsbook key the promo is at, like dk")
    p.add_argument("--amount", type=float, default=None,
                   help="the bonus bet, the first bet, the boosted stake or the deposit")
    p.add_argument("--boost", type=float, default=None, help="profit boost, in percent")
    p.add_argument("--max-win", type=float, default=None, help="the most profit a boosted bet can pay")
    p.add_argument("--match", type=float, default=None, help="deposit match, in percent")
    p.add_argument("--rollover", type=float, default=None, help="deposit match playthrough, in times")
    p.set_defaults(func=cmd_promo)

    # Ask, the NFL player projections and the goal planner.
    from overlay_engine import cmds_ask
    cmds_ask.register(sub, _state_code)

    try:
        args = parser.parse_args(argv)
    except _InputError as exc:
        # The window shows what it is given: a sentence a person can act on, not a usage dump.
        print(json.dumps({"error": plain_input_error(str(exc))}))
        return 2
    try:
        return args.func(args)
    except Exception as exc:                             # noqa: BLE001
        # The app's own refusals are answers, not stack traces. `parlay 2.10`
        # is a person making an ordinary mistake, and a traceback tells them
        # the program is broken when it is they who are being told no.
        if not crash.is_expected(type(exc)):
            raise
        print(f"{exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
