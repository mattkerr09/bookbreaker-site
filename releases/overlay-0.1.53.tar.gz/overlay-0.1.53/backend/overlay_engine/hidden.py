"""Hidden plays: the engine's half of "hide this play, with undo".

OddsJam has Hide on a row and a "Show Hidden Bets" list. Here the person's choice is kept by the window, on this Mac,
and the engine does the two things the window must not do for itself:

  * **Identity.** Every play is sent with a `hide` block (`key`, `label`, `starts_at`). The key is the one alerts use
    (`alerts.play_key`: kind, game, market, and each bet's book and side, never a price), so a price that moves does
    not unhide a play and a play that comes back on a later read is still hidden. The window compares keys it was
    given and works out nothing.
  * **When a hidden play can go.** A hidden play that is no longer on the board drops off the list once its game has
    started: after that it can never come back, and a list that only grows is a list nobody reads. The window sends
    the hidden keys with their start times on a read the person starts; the engine says which to drop. A read that
    did not see everything drops nothing (the play may only be missing from a read that failed), a play whose start
    is not known is never dropped, and a play still on the board is never dropped.

**Hiding changes what is drawn and nothing else.** Every play is still sent and still checked: Recommended, bet
warnings and the price ages are exactly what they were. The one engine result a hidden play does change is an alert:
a hidden play does not alert (`alerts.check(..., hidden=...)`), and showing it again does not announce it as new,
because the record of the previous read still holds it.
"""

from __future__ import annotations

import json

from .alerts import _view, play_key, scope_keys
from .betwarn import _market_word
from .screen import book_name

#: The most hidden plays one read will take. Wide enough never to get in the way; a list past it is not one a
#: person made by hand.
MAX_HIDDEN = 2000

#: Said on the alerts setting, and the reason it is true is in `alerts.check`.
ALERTS_NOTE = ("A play you hide does not alert, and showing it again does not announce it as new.")

STORED = "Hidden plays are kept on this Mac, in this window, and nowhere else."
DROPS = ("A hidden play that is no longer on the board drops off this list once its game has started.")


class HiddenError(ValueError):
    """The hidden list is not one the engine can use. The text is a sentence the window can print."""


def parse(text: str) -> list:
    """The list the window sent: a JSON array of `{"key": str, "starts_at": number or null}`. Anything else is
    refused in a sentence: a quietly repaired list could let a hidden play alert, or keep one that should go."""
    bad = HiddenError("The list of hidden plays was not readable, so hiding did not change this refresh.")
    try:
        raw = json.loads(text)
    except (TypeError, ValueError):
        raise bad from None
    if not isinstance(raw, list) or len(raw) > MAX_HIDDEN:
        raise bad
    out = []
    for item in raw:
        if not isinstance(item, dict) or set(item) - {"key", "starts_at"}:
            raise bad
        key, start = item.get("key"), item.get("starts_at")
        if not isinstance(key, str) or not key:
            raise bad
        if start is not None and (isinstance(start, bool) or not isinstance(start, (int, float)) or start != start):
            raise bad
        out.append({"key": key, "starts_at": None if start is None else float(start)})
    return out


def starts_at(row: dict):
    """When the play's game starts, as epoch seconds, or None when the source does not say. Live prices pairs carry
    seconds already; a sportsbook row carries the feed's ISO text."""
    start = row.get("starts_at")
    if isinstance(start, bool):
        return None
    if isinstance(start, (int, float)):
        return float(start)
    if isinstance(start, str) and start:
        from .feed import FeedError
        from .restfeed import parse_time
        try:
            return parse_time(start)
        except FeedError:
            return None
    return None


def _game(row: dict) -> str:
    game = str(row.get("event") or row.get("game") or "")
    parts = game.split("_")
    if " " not in game and len(parts) >= 4:          # the demonstration market's id: nba_2026_bos_lal
        return f"{parts[-2].upper()} vs {parts[-1].upper()}"
    return game


def label(row: dict, names: dict | None = None) -> str:
    """One play, in a short phrase that does not change when a price moves: what it is and where."""
    v = _view(row)
    names = names or {}
    books = []
    for leg in v.get("legs") or []:
        if leg.get("venue"):
            from .catalog import VENUES
            venue = VENUES.get(leg["venue"])
            books.append(venue.name if venue else str(leg["venue"]))
        else:
            books.append(str(leg.get("book_name") or book_name(str(leg.get("book", "")), names)))
    market = "moneyline" if v.get("cross") else _market_word(str(v.get("market", "")))
    kind = {"arb": "arb", "ev": "+EV bet", "middle": "middle"}.get(v.get("kind"), "play")
    return f"{_game(v)}, {market} {kind} at {' and '.join(books)}"


def _book_word(key: str, row: dict, names: dict) -> str:
    for leg in _view(row).get("legs") or []:
        if leg.get("venue") == key:
            from .catalog import VENUES
            venue = VENUES.get(key)
            return venue.name if venue else key
        if leg.get("book") == key:
            return str(leg.get("book_name") or book_name(key, names))
    return key


def also(row: dict, names: dict | None = None) -> list:
    """The wider hides a play offers: its whole game, then each book it bets at. Each has the key the window keeps,
    the label the Hidden plays list shows, the button's words, and a start time (a game's, so it can drop off the list
    once the game has started; none for a book, which stays hidden until shown again)."""
    names = names or {}
    v, start, out = _view(row), starts_at(row), []
    for key in scope_keys(v):
        what, rest = key.split("|", 1)
        if what == "game":
            out.append({"key": key, "what": "game", "label": f"Every play in {_game(v)}",
                        "button": "Hide this whole game", "starts_at": start})
        else:
            name = _book_word(rest, row, names)
            out.append({"key": key, "what": "book", "label": f"Every play at {name}",
                        "button": f"Hide every play at {name}", "starts_at": None})
    return out


def mark(rows: list, names: dict | None = None) -> None:
    """Give every play (dicts, in place) the block the window hides it by. Nothing is removed or reordered."""
    for row in rows:
        row["hide"] = {"key": play_key(_view(row)), "label": label(row, names), "starts_at": starts_at(row),
                       "also": also(row, names)}


def keys_of(entries: list) -> frozenset:
    return frozenset(e["key"] for e in entries)


def apply(rows: list, entries: list, now, complete: bool = True) -> dict:
    """What a read says about the person's hidden list: how many are on this board, and which entries to drop.

    `now` is the moment of the read (None for the demonstration market, which has no clock to compare with). The
    window removes exactly the keys in `drop` and decides nothing else."""
    on_board = {play_key(_view(r)) for r in rows} | {k for r in rows for k in scope_keys(_view(r))}
    here = sum(1 for e in entries if e["key"] in on_board)
    drop = []
    if complete and now is not None:
        drop = [e["key"] for e in entries
                if e["key"] not in on_board and e["starts_at"] is not None and e["starts_at"] <= now]
    left = len(entries) - len(drop)
    said = f"{left} hidden play{'s' if left != 1 else ''} kept on this Mac, {here} of them on this board."
    if drop:
        said += (f" {len(drop)} dropped off the list because {'its game has' if len(drop) == 1 else 'their games have'}"
                 " started.")
    return {"enabled": True, "count": left, "on_board": here, "drop": drop, "sentence": said,
            "note": ALERTS_NOTE}


def refused(why: str) -> dict:
    """The block for a list the engine could not use. The read still happened and the board is whole; nothing is
    dropped and no alert is held back."""
    return {"enabled": False, "count": 0, "on_board": 0, "drop": [], "sentence": why, "note": ALERTS_NOTE}
