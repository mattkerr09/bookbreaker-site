"""Open <book> on a play (the AVO bar's item 26, built on the CEO's ruling of 2026-10-31), under the rules of Open
this offer: only a sportsbook licensed in the chosen state; 21+, the state's helpline and how Bookbreaker is paid
beside the buttons; the router's affiliate link only where a program has approved bookbreaker.bet (the router and
partners.csv decide; the app adds no tracking); and never a bet slip: the router lands on the book's own page."""
import json
import os
import re
import subprocess
import sys
from pathlib import Path

from overlay_engine import offerlink

ROOT = Path(__file__).resolve().parents[1]
JS = (ROOT / "ui" / "src" / "app.js").read_text()
RUST = (ROOT / "ui" / "src-tauri" / "src" / "main.rs").read_text()


def rows(*books):
    return [{"kind": "arb", "legs": [{"book": b, "outcome": f"s{i}"} for i, b in enumerate(books)]}]


def test_only_books_licensed_in_the_state_get_a_button():
    r = rows("dk", "fd")
    offerlink.leg_opens(r, "MI")
    assert [o["book"] for o in r[0]["opens"]] == [b for b in ("dk", "fd") if offerlink.can_link(b, "MI")]
    r = rows("dk", "pinnacle", "kalshi")
    offerlink.leg_opens(r, "CA")                       # no legal sportsbook in California
    assert r[0]["opens"] == [] and r[0]["open_note"] is None
    r = rows("pinnacle", "kalshi", "polymarket_us")
    offerlink.leg_opens(r, "NJ")
    assert r[0]["opens"] == [], "no offshore book or exchange is ever linked"


def test_no_state_means_no_button():
    r = rows("dk")
    offerlink.leg_opens(r, None)
    assert r[0]["opens"] == [] and r[0]["open_note"] is None


def test_every_button_has_the_age_helpline_and_paid_line_beside_it():
    r = rows("dk", "mgm")
    offerlink.leg_opens(r, "MI")
    assert r[0]["opens"]
    note = r[0]["open_note"]
    assert note.startswith("21+ and in MI.") and "helpline" in note and offerlink.PAID in note


def test_a_button_carries_only_the_book_and_state_never_an_address():
    r = rows("dk")
    offerlink.leg_opens(r, "MI")
    assert all(set(o) == {"book", "state", "label"} for o in r[0]["opens"]), "no URL, so no slip and no tracking"


def test_the_board_command_sends_them_for_the_chosen_state_only(tmp_path):
    env = {**os.environ, "OVERLAY_HOME": str(tmp_path)}
    run = lambda *a: json.loads(subprocess.run([sys.executable, "-m", "overlay_engine.cli", "board", *a, "--json"],
                                               cwd=ROOT / "backend", capture_output=True, text=True, check=True,
                                               env=env).stdout)
    with_state = run("--state", "MI")["rows"]
    assert any(r["opens"] for r in with_state) and all((r["open_note"] is None) == (not r["opens"]) for r in with_state)
    assert all(r["opens"] == [] for r in run()["rows"])


def test_the_window_draws_the_engines_buttons_and_line_and_the_shell_builds_the_address():
    handler = JS[JS.index("/* Open <book> from a play"):]
    handler = handler[:handler.index("});\n") + 4]
    assert 'invoke("open_go", { book: b.dataset.legBook, state: b.dataset.legState, from: "board" })' in handler
    assert not re.search(r"url|href|location|window\.open", handler), "the window passes no address"
    tpl = JS[JS.index("${p.opens && p.opens.length ?"):]
    tpl = tpl[:tpl.index('` : ""}') + 7]
    assert 'data-leg-book="${esc(o.book)}" data-leg-state="${esc(o.state)}">${esc(o.label)}' in tpl
    assert '<p class="note comply">${esc(p.openNote)}</p>' in tpl, "the line sits with the buttons, every time"
    assert 'const GO_PREFIX: &str = "https://bookbreaker.bet/go/";' in RUST
    assert 'format!("{GO_PREFIX}{book}/?state={state}&src=app-{from}")' in RUST, "the router, never a slip address"
