"""The Arb calculator's leg lock and target profit (the AVO bar's item 16): hold one side's stake and size the others
around it, or find the smallest total that locks at least an amount, never over the most to bet."""
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine.arb import stake_arb
from overlay_engine.odds import parse_odds

ROOT = Path(__file__).resolve().parents[1]
PRICES = ["-110", "+120"]
D = [parse_odds(p) for p in PRICES]


def run(*extra, stake="2000", ok=True):
    r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "arb", *PRICES, "--stake", stake, *extra, "--json"],
                       cwd=ROOT / "backend", capture_output=True, text=True)
    out = json.loads(r.stdout)
    if ok:
        assert r.returncode == 0 and "error" not in out, out
    return r.returncode, out


def test_a_held_side_keeps_its_stake_and_every_result_returns_the_same():
    _, d = run("--lock=1=250")
    assert d["legs"][0]["stake"] == pytest.approx(250.0)
    returns = [l["stake"] * l["decimal"] for l in d["legs"]]
    assert max(returns) - min(returns) < 0.01
    assert d["total_stake"] == pytest.approx(250 * D[0] * sum(1 / x for x in D))
    assert d["solve"]["kind"] == "lock" and "Side 1 is held at $250.00" in d["solve"]["text"]


def test_a_hold_that_needs_more_than_the_most_to_bet_is_one_sentence():
    code, d = run("--lock=2=900", stake="1000", ok=False)
    assert code == 2 and d["error"].startswith("Holding side 2 at $900.00 needs $")
    assert "more than the $1,000.00 you set" in d["error"]


@pytest.mark.parametrize("extra,words", [(["--lock=3=10"], "There is no side 3"), (["--lock=x"], "like 1=250"),
                                         (["--lock=1=0"], "more than zero"), (["--lock=1=50", "--target=5"], "not both"),
                                         (["--target=lots"], "like 25"), (["--target=-5"], "more than zero")])
def test_a_solve_that_cannot_be_read_is_refused(extra, words):
    code, d = run(*extra, ok=False)
    assert code == 2 and words in d["error"]


@pytest.mark.parametrize("rounding", ["10", "exact", "auto"])
def test_the_target_total_is_the_smallest_that_reaches_it_at_the_rounding_chosen(rounding):
    _, d = run("--target=25", "--round", rounding)
    assert d["profit"] >= 25 - 1e-9 and d["total_stake"] <= 2000
    if rounding == "10":
        smaller = stake_arb(D, total=d["total_stake"] - 10, step=10.0)
        assert smaller.profit < 25, "a total one step smaller would have reached the target too"
    assert "if every bet is accepted and stands" in d["solve"]["text"]


def test_a_target_out_of_reach_is_one_sentence():
    code, d = run("--target=25", stake="1000", ok=False)
    assert code == 2 and d["error"].startswith("Locking $25.00 at these prices needs about $")


def test_the_words_never_promise():
    for extra in (["--lock=1=250"], ["--target=25"]):
        t = run(*extra)[1]["solve"]["text"]
        assert not re.search(r"guarantee|risk.free|either way|free bet|\bwin\b|sure thing", t, re.I)


def test_the_window_sends_one_token_each_and_draws_the_engines_sentence():
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    assert '...(val("arb-lock-side") && val("arb-lock") ? [`--lock=${val("arb-lock-side")}=${val("arb-lock")}`] : [])' in js
    assert '...(val("arb-target") ? [`--target=${val("arb-target")}`] : [])' in js
    assert '${out.solve ? `<p class="ans-say">${esc(out.solve.text)}</p>` : ""}' in js
