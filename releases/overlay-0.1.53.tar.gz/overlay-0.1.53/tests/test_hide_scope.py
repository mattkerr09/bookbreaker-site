"""Hide a whole game, or every play at one book (the AVO bar's item 14). Leagues and bet types are switched off with
the board filters (0.1.46), so these are the two wider hides a play's detail offers.

Pinned: the engine names each scope with a key the window keeps as given; a play inside a hidden game or at a hidden
book is hidden and does not alert; a hidden game drops off the list once it has started and is off the board, a hidden
book never drops; and the window offers the engine's words and compares only the engine's keys.
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import test_hidden_plays as th  # noqa: E402
from overlay_engine import alerts, hidden  # noqa: E402

arb, SETTING, JS = th.arb, th.SETTING, th.JS
throwaway_home = th.throwaway_home


def test_a_play_offers_its_game_and_each_book_it_bets_at():
    row = arb("g1", books=("dk", "fd"), starts=5000.0)
    hidden.mark([row], {"dk": "DraftKings", "fd": "FanDuel"})
    also = row["hide"]["also"]
    assert [a["key"] for a in also] == ["game|g1", "book|dk", "book|fd"]
    assert also[0]["button"] == "Hide this whole game" and also[0]["starts_at"] == 5000.0
    assert also[0]["label"].startswith("Every play in ")
    assert also[1]["button"] == "Hide every play at DK" and also[1]["label"] == "Every play at DK"
    assert all(a["starts_at"] is None for a in also[1:]), "a book has no start: it stays hidden until shown again"
    assert all(set(a) == {"key", "what", "label", "button", "starts_at"} for a in also)


def test_a_play_at_a_hidden_book_or_in_a_hidden_game_does_not_alert():
    alerts.check([], SETTING, "oddsapi", 1000.0)
    at_dk, in_g2, free = arb("g1", books=("dk", "fd")), arb("g2", books=("mgm", "fd")), arb("g3", books=("mgm", "caesars"))
    out = alerts.check([at_dk, in_g2, free], SETTING, "oddsapi", 2000.0, hidden=frozenset({"book|dk", "game|g2"}))
    assert "alert" not in at_dk and "alert" not in in_g2 and free["alert"] is True
    assert out["matched"] == 1 and out["hidden_matched"] == 2


def test_a_hidden_game_drops_once_started_and_off_the_board_and_a_hidden_book_never_drops():
    rows = [arb("live", books=("dk", "fd"), starts=1000.0)]
    hidden.mark(rows)
    entries = [{"key": "game|gone", "starts_at": 500.0}, {"key": "game|live", "starts_at": 1000.0},
               {"key": "book|betrivers", "starts_at": None}, {"key": "book|dk", "starts_at": None}]
    out = hidden.apply(rows, entries, now=2000.0)
    assert out["drop"] == ["game|gone"]
    assert out["on_board"] == 2, "the game and the book on this board are counted as on it"


def test_the_window_offers_the_engines_words_and_compares_only_its_keys():
    assert 'p.hide.also.some((a) => a.key === h.key)' in JS
    assert 'data-hide-also="${PLAYS.indexOf(p)}:${j}">${esc(a.button)}</button>' in JS
    body = th._braced(JS, "function hideAlso(")
    assert "HIDDEN.push({ key: a.key, label: a.label, starts_at: a.starts_at })" in body
    assert not re.search(r"split\(\"\|\"\)|game\||book\|", body), "the window never builds or reads a scope key itself"
