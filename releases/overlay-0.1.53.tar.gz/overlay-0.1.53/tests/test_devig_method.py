"""Fair odds: choose how the cut is removed (the AVO bar's item 10): the average of four methods, one method, or the
worst case, the lowest chance any method gives each side, which is the cautious price to size from."""
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import cli
from overlay_engine.devig import devig_all
from overlay_engine.odds import decimal_to_american, parse_odds

ROOT = Path(__file__).resolve().parents[1]
PRICES = ["-145", "+125"]


def run(*extra):
    out = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "devig", *extra, "--json", *PRICES],
                         cwd=ROOT / "backend", capture_output=True, text=True, check=True).stdout
    return json.loads(out)


def test_the_default_is_the_average_and_matches_the_old_headline():
    d = run()
    assert d["chosen"]["method"] == "consensus"
    for o, c in zip(d["outcomes"], d["chosen"]["outcomes"]):
        assert c["chance"] == pytest.approx(o["consensus"]) and c["fair_american"] == o["fair_american"]


@pytest.mark.parametrize("method", ["multiplicative", "additive", "power", "shin"])
def test_one_method_gives_that_methods_chances(method):
    d = run("--method", method)
    assert d["chosen"]["method"] == method
    for o, c in zip(d["outcomes"], d["chosen"]["outcomes"]):
        assert c["chance"] == pytest.approx(o["by_method"][method])
        assert c["fair_american"] == round(decimal_to_american(1 / c["chance"]))


def test_the_worst_case_is_the_lowest_chance_of_any_method_for_each_side():
    d = run("--method", "worst")
    spread = devig_all([parse_odds(p) for p in PRICES])
    lows = [c["chance"] for c in d["chosen"]["outcomes"]]
    assert lows == pytest.approx([spread.low(0), spread.low(1)])
    assert sum(lows) < 1, "the cautious chances do not add up to 100%"
    for o, c in zip(d["outcomes"], d["chosen"]["outcomes"]):
        assert c["chance"] <= min(o["by_method"].values()) + 1e-12
    assert "do not add up to 100%" in d["chosen"]["text"]


def test_an_unknown_method_is_refused():
    r = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "devig", "--method", "vibes", *PRICES],
                       cwd=ROOT / "backend", capture_output=True, text=True)
    assert r.returncode == 2 and "invalid choice" in r.stderr


def test_every_choice_says_what_it_did_in_plain_words():
    for m in cli.DEVIG_CHOICES:
        t = run("--method", m)["chosen"]["text"]
        assert t.startswith("Fair prices from ")
        assert not re.search(r"guarantee|risk.free|either way|free bet|\block\b", t, re.I)


def test_the_window_sends_the_choice_and_draws_the_engines_price():
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    html = (ROOT / "ui" / "src" / "index.html").read_text()
    assert '...(val("devig-m") ? [`--method=${val("devig-m")}`] : [])' in js
    assert "${amer(ca.fair_american)}" in js and "esc(out.chosen.text)" in js
    options = re.findall(r'<option value="([a-z]+)"', html[html.index('id="devig-m"'):html.index("</select>", html.index('id="devig-m"'))])
    assert set(options) == set(cli.DEVIG_CHOICES), "every choice the engine takes, and nothing else"
