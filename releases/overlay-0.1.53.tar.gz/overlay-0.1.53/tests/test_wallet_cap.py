"""A bet above a book's balance in Your books (the AVO bar's items 23 and 16): an arb or middle whose bet at a book is
more than the balance typed for it is marked, with the same plan scaled down so it fits and every result scaled the
same. A book with no balance typed sets no limit; a +EV bet is sized on the balance already (0.1.46)."""
import json
import os
import re
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import wallet
from overlay_engine.ledger import Ledger

ROOT = Path(__file__).resolve().parents[1]


def arb(stakes=(470.0, 500.0), books=("dk", "circa"), kind="arb"):
    return {"kind": kind, "legs": [{"book": b, "stake": s} for b, s in zip(books, stakes)]}


def test_a_bet_above_the_balance_is_marked_with_the_plan_that_fits():
    r = arb()
    wallet.short_rows([r], {"dk": 200.0})
    w = r["wallet"]
    assert [s["book"] for s in w["short"]] == ["dk"] and w["scale"] == pytest.approx(200 / 470, abs=1e-4)
    assert w["fit"] == [200.0, round(500 * 200 / 470, 2)]
    assert w["fit"][0] <= 200.0, "the scaled bet fits the balance"
    assert "the same plan at 43% of the size" in w["text"]


def test_the_tightest_book_sets_the_scale_when_two_fall_short():
    r = arb()
    wallet.short_rows([r], {"dk": 400.0, "circa": 100.0})
    assert r["wallet"]["scale"] == pytest.approx(100 / 500, abs=1e-4)
    assert all(f <= b + 0.005 for f, b in zip(r["wallet"]["fit"], (400.0, 100.0)))


def test_no_balance_typed_or_enough_money_means_no_mark():
    for held in ({}, {"dk": 470.0}, {"fd": 10.0}):
        r = arb()
        wallet.short_rows([r], held)
        assert r["wallet"] is None, held


def test_only_arbs_and_middles_are_marked():
    rows = [arb(kind="ev"), arb(kind="middle")]
    wallet.short_rows(rows, {"dk": 100.0})
    assert rows[0]["wallet"] is None and rows[1]["wallet"]["short"]


def test_a_zero_balance_says_so_and_offers_no_plan():
    r = arb()
    wallet.short_rows([r], {"dk": 0.0})
    assert r["wallet"]["fit"] is None and "too low" in r["wallet"]["text"]


def test_the_board_marks_the_play_from_the_balances_on_this_mac(tmp_path):
    env = {**os.environ, "OVERLAY_HOME": str(tmp_path)}
    with Ledger(tmp_path / "overlay.db") as led:
        wallet.set_balance(led, "dk", 200)
    out = json.loads(subprocess.run([sys.executable, "-m", "overlay_engine.cli", "board", "--json"], cwd=ROOT / "backend",
                                    capture_output=True, text=True, check=True, env=env).stdout)
    marked = [r for r in out["rows"] if r.get("wallet")]
    assert marked and all(r["kind"] in ("arb", "middle") for r in marked)
    assert all("wallet" in r for r in out["rows"]), "every row carries the field"


def test_the_words_never_promise():
    for held in ({"dk": 200.0}, {"dk": 0.0}):
        r = arb()
        wallet.short_rows([r], held)
        assert not re.search(r"guarantee|risk.free|either way|free bet|\bwin\b|sure thing", r["wallet"]["text"], re.I)


def test_the_window_draws_the_engines_sentence():
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    assert "wallet: r.wallet || null," in js
    assert '${p.wallet ? `<p class="note warn wallet-short">${esc(p.wallet.text)}</p>` : ""}' in js
