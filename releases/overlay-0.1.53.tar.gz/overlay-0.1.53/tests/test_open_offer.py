"""Opening a sportsbook's sign-up page from the app: the shell's one door that takes arguments (main.rs open_go)."""

import re
from pathlib import Path

from overlay_engine import catalog

ROOT = Path(__file__).resolve().parent.parent
RUST = (ROOT / "ui" / "src-tauri" / "src" / "main.rs").read_text()


def _list(name):
    body = re.search(rf"const {name}: &\[&str\] = &\[(.*?)\];", RUST, re.S).group(1)
    return re.findall(r'"([^"]+)"', body)


def test_the_prefix_is_bookbreaker_bets_own_router_and_nothing_else():
    assert 'const GO_PREFIX: &str = "https://bookbreaker.bet/go/";' in RUST
    fn = RUST[RUST.index("fn go_url("):RUST.index("#[tauri::command]\nfn open_go(")]
    assert 'format!("{GO_PREFIX}{book}/?state={state}&src=app-{from}")' in fn


def test_every_book_the_shell_will_open_is_a_us_sportsbook_in_the_catalog():
    for book in _list("GO_BOOKS"):
        venue = catalog.VENUES.get(book)
        assert venue is not None, book
        assert venue.states or venue.nationwide, f"{book} is licensed nowhere in the catalog"
        assert not venue.exited, f"{book} has left: {venue.exited}"


def test_the_pages_it_opens_from_are_the_offer_pages_and_a_plays_detail():
    # "board" since the CEO's ruling of 2026-10-31 (AVO bar item 26): Open <book> on a play, same router and rules.
    assert set(_list("GO_FROM")) == {"promos", "convert", "deposit", "board"}


def test_the_command_is_registered_and_takes_only_book_state_and_page():
    assert "            open_go,\n" in RUST
    assert re.search(r"#\[tauri::command\]\nfn open_go\(book: String, state: String, from: String\)", RUST)


# ------------------------------------------------------------ the engine's side (offerlink.py)

import json  # noqa: E402

from overlay_engine import cli, offerlink  # noqa: E402


def test_the_engine_and_the_shell_name_the_same_books():
    assert tuple(_list("GO_BOOKS")) == offerlink.GO_BOOKS


def test_a_link_only_for_a_book_licensed_in_the_state_and_never_without_a_state():
    assert offerlink.link("dk", "MI") == {"book": "dk", "state": "MI", "label": "Open this offer"}
    assert offerlink.link("bally", "MI") is None, "Bally Bet is not licensed in Michigan"
    assert offerlink.link("dk", None) is None and offerlink.link("dk", "") is None
    for gone_or_offshore in ("betfred", "betr", "superbook", "underdog", "pinnacle", "bovada"):
        assert offerlink.link(gone_or_offshore, "MI") is None and offerlink.link(gone_or_offshore, "NJ") is None


def test_beside_the_links_21_plus_the_states_own_helpline_with_its_source_and_how_bookbreaker_is_paid():
    c = offerlink.compliance("MI")
    assert c["age"] == "21+" and "1-800-270-7117" in c["helpline"] and "michigan.gov" in c["helpline_source"]
    assert "bookbreaker.bet/how-we-are-paid/" in c["paid"]
    for claim in ("not paid", "earns nothing", "partner", "may be paid"):
        assert claim not in c["text"].lower(), claim
    for banned in ("—", "free bet", "guarantee", "risk-free"):
        assert banned not in c["text"].lower()


def test_a_state_with_no_line_of_its_own_gets_the_national_one():
    assert offerlink.compliance("ZZ")["helpline"].startswith("National problem gambling helpline: 1-800-MY-RESET")


def test_promos_carries_a_link_on_usable_offers_only_and_the_compliance_when_any_shows(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    assert cli.main(["welcome", "--state", "MI", "--json"]) == 0
    d = json.loads(capsys.readouterr().out)
    linked = [o for o in d["offers"] if o["open"]]
    assert linked and d["compliance"]["age"] == "21+"
    for o in linked:
        assert offerlink.can_link(o["book"], "MI") and not (o.get("ended") or o.get("stale") or o.get("ineligible"))
    assert cli.main(["welcome", "--json"]) == 0
    d = json.loads(capsys.readouterr().out)
    assert not any(o["open"] for o in d["offers"]) and d["compliance"] is None


# ------------------------------------------------------------ the window

JS = (ROOT / "ui" / "src" / "app.js").read_text()


def test_the_button_sits_above_the_steps_never_inside_or_beside_them():
    card = JS[JS.index("function showWelcome("):JS.index("/* Open this offer:")]
    assert card.index("data-open-book") < card.index('<details class="how"><summary>How to collect it')
    steps = card[card.index('<details class="how">'):card.index("</details>")]
    assert "data-open-book" not in steps


def test_only_promos_opens_an_offer_and_it_passes_only_the_engines_book_and_state():
    assert JS.count('invoke("open_go"') == 2, "Open this offer, and Open <book> on a play (tests/test_leg_open.py)"
    handler = JS[JS.index("/* Open this offer:"):]
    handler = handler[:handler.index("});\n") + 4]
    assert 'from: "promos"' in handler and "b.dataset.openBook" in handler and "b.dataset.openState" in handler
    for results in ("function showOddsboard(", "function showBoard(", "function altLadder(", "function showPromo("):
        block = JS[JS.index(results):JS.index(results) + 4000]
        assert "data-open-book" not in block, results


def test_the_compliance_line_is_drawn_whenever_the_engine_sends_one():
    card = JS[JS.index("function showWelcome("):JS.index("/* Open this offer:")]
    assert "out.compliance ? `<p class=\"note comply\">${esc(out.compliance.text)}</p>`" in card


def test_what_leaves_this_mac_names_the_offer_link_and_what_it_carries():
    html = (ROOT / "ui" / "src" / "index.html").read_text()
    note = re.search(r'<div class="privacy-pop">(.*?)</div>', html, re.S).group(1)
    item = next(i for i in re.findall(r"<li>(.*?)</li>", note, re.S) if "<b>Open this offer</b>" in i)
    text = re.sub(r"\s+", " ", item)
    assert "your state" in text and "bookbreaker.bet" in text and "Nothing else about you is sent." in text
