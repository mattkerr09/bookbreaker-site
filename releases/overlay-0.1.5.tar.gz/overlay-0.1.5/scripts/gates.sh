#!/bin/bash
# Every gate, in one command. Nothing is done until this exits 0.
#
# Three, because each catches what the others cannot:
#   pytest        the engine's arithmetic
#   break_test    that the arithmetic tests can actually fail
#   smoke_cli     that the CLI wires the engine up at all — a subcommand can
#                 pass every unit test underneath it and still crash on an
#                 f-string, and the CLI is the only part a user touches
#   check_catalog that the jurisdiction table is fresh and self-consistent.
#                 Nothing about a stale table looks wrong: it answers every
#                 question confidently, in the same shape, and thirty pages of
#                 the live site are generated from it
#
# Prints the real counts. A gate whose number you cannot read is a gate you
# are trusting rather than checking.
set -uo pipefail
cd "$(dirname "$0")/.." || exit 2

fail=0
echo "── pytest ─────────────────────────────────────────"
# No `-q` here: pytest.ini already sets it, and a second one means
# `-qq`, which suppresses the summary line entirely — the run went
# green with the count invisible, which is the one thing this
# script exists to print.
python3 -m pytest 2>&1 | grep -Ei "passed|failed|error" | tail -2 || fail=1
echo
echo "── break tests ────────────────────────────────────"
python3 scripts/break_test.py 2>&1 | tail -3 || fail=1
echo
echo "── catalog ────────────────────────────────────────"
python3 scripts/check_catalog.py 2>&1 | tail -2 || fail=1
echo
echo "── cli smoke ──────────────────────────────────────"
python3 scripts/smoke_cli.py 2>&1 | tail -3 || fail=1
echo
if [ "$fail" -ne 0 ]; then
  echo "GATES RED"
  exit 1
fi
echo "GATES GREEN"
