#!/usr/bin/env python3
"""Report how old the jurisdiction table is, and fail when it is too old.

`catalog.py` is a snapshot. Markets launch, operators withdraw, and a table
that was right in August is wrong by November — but nothing about a stale table
looks wrong. It answers every question confidently, in the same shape, with the
same tone.

Thirty pages of the live site are generated from it, so a table nobody
re-checks becomes thirty pages of confident, dated, incorrect claims. This
turns "somebody should look at that again" into a build failure.

    python3 scripts/check_catalog.py
    python3 scripts/check_catalog.py --max-age 60

Exit 0 when the table is fresh and internally consistent, 1 otherwise.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from overlay_engine.catalog import (  # noqa: E402
    AS_OF,
    COVERAGE_GAPS,
    NO_LEGAL_BETTING,
    RETAIL_ONLY,
    SINGLE_OPERATOR,
    SOURCE,
    VENUES,
    for_state,
    stale_days,
)
from overlay_engine.models import BookTier  # noqa: E402

# Beyond this the table is refused. Roughly a betting season: long enough that
# a re-check is not busywork, short enough that a launched market cannot sit
# unrecorded through a whole football schedule.
MAX_AGE_DAYS = 120


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-age", type=int, default=MAX_AGE_DAYS,
                        help="days before the table is considered stale")
    args = parser.parse_args()

    age = stale_days()
    print(f"jurisdiction table read {AS_OF} ({age} days ago)")
    print(f"  source: {SOURCE}")
    print(f"  {len(VENUES)} venues, {len(COVERAGE_GAPS)} uncatalogued, "
          f"{len(RETAIL_ONLY)} retail-only, "
          f"{len(NO_LEGAL_BETTING)} with no legal betting")

    fails: list[str] = []

    if age > args.max_age:
        fails.append(
            f"the table is {age} days old, past the {args.max_age}-day limit. "
            "Re-read the source, update AS_OF and AS_OF_EPOCH together, and "
            "re-render the site — thirty of its pages are generated from this."
        )

    # A state cannot be both retail-only and have online venues listed.
    for state in RETAIL_ONLY:
        online = [v.name for v in for_state(state)
                  if v.tier is BookTier.RETAIL]
        if online:
            fails.append(
                f"{state} is marked retail-only but lists online books: "
                f"{online}"
            )

    # Nor can a state with no legal betting have a state-licensed venue.
    for state in NO_LEGAL_BETTING:
        licensed = [v.name for v in for_state(state) if not v.nationwide]
        if licensed:
            fails.append(
                f"{state} is marked as having no legal betting but lists "
                f"{licensed}"
            )

    # A single-operator note must describe a state that actually has one.
    for state, note in SINGLE_OPERATOR.items():
        retail = [v for v in for_state(state) if v.tier is BookTier.RETAIL]
        if len(retail) != 1:
            fails.append(
                f"{state} carries a single-operator note ({note[:40]}...) but "
                f"lists {len(retail)} retail books"
            )

    # Every venue must be reachable somewhere, or it is dead weight that will
    # never be noticed.
    unreachable = [
        v.key for v in VENUES.values()
        if v.verified and not v.nationwide and not v.states
    ]
    if unreachable:
        fails.append(f"verified venues reachable from nowhere: {unreachable}")

    unverified = sorted(v.key for v in VENUES.values() if not v.verified)
    if unverified:
        print(f"  unverified: {', '.join(unverified)} "
              "(hidden from every state unless asked for)")

    print()
    if fails:
        print(f"{len(fails)} problem(s):")
        for problem in fails:
            print(f"  - {problem}")
        return 1
    print("CATALOG OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
