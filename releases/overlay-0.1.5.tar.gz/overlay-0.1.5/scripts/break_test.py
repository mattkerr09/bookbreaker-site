#!/usr/bin/env python3
"""Break each load-bearing invariant on purpose and confirm a test catches it.

A passing suite proves the tests ran, not that they can fail. Every gate here
guards a claim the product is sold on — that the arb margin is right, that
commission is netted, that fill probability reorders the screen — and a gate
that has never been watched to fail is worth nothing.

Each case edits one file, runs the named test, and restores. Restores use
absolute paths and are verified by re-reading the file, because a silent
restore failure leaves a deliberately broken engine in the tree and the next
green run means nothing.

    python3 scripts/break_test.py

Exit 0 when every break was caught, 1 otherwise.
"""

from __future__ import annotations

import os
import contextlib
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ENGINE = ROOT / "backend" / "overlay_engine"

# (label, file, find, replace, test that must fail)
CASES = [
    (
        "arb margin reported as the shortfall (1 - S) instead of the return",
        ENGINE / "arb.py",
        "    return 1.0 / total - 1.0",
        "    return 1.0 - total",
        "tests/test_arb.py::test_arb_margin_is_the_return_not_the_shortfall",
    ),
    (
        "exchange commission not netted before calling an arb",
        ENGINE / "arb.py",
        "            scored.append((book.net_decimal(q.decimal), q))",
        "            scored.append((q.decimal, q))",
        "tests/test_arb.py::test_commission_is_netted_before_the_arb_is_called",
    ),
    (
        "stakes rounded naively instead of searched",
        ENGINE / "arb.py",
        "        span = 1 if i == anchor else 3",
        "        span = 0",
        "tests/test_arb.py::test_search_beats_naive_rounding_or_ties_it",
    ),
    (
        "fill probability dropped from realised EV",
        ENGINE / "models.py",
        "        return self.ev * self.p_fill",
        "        return self.ev",
        "tests/test_fair_ev.py::test_fill_probability_reorders_the_screen",
    ),
    (
        "a book priced against a fair value it helped set",
        ENGINE / "ev.py",
        "                holdout[quote.book] = 0.0",
        "                pass",
        "tests/test_fair_ev.py::test_a_book_is_never_priced_against_a_fair_value_it_helped_set",
    ),
    (
        "additive devig clamps to zero instead of refusing",
        ENGINE / "devig.py",
        "    if any(p <= 0.0 for p in out):",
        "    if False:",
        "tests/test_devig.py::test_additive_refuses_rather_than_clamping",
    ),
    (
        "hold reported as the overround excess",
        ENGINE / "odds.py",
        "    return 1.0 - 1.0 / overround(decimals)",
        "    return overround(decimals) - 1.0",
        "tests/test_odds.py::test_hold_is_not_the_overround_excess",
    ),
    (
        "an accept treated as dating the quote's death",
        ENGINE / "staleness.py",
        "        if not obs.accepted:\n            self._failures[key] = self._failures.get(key, 0) + 1",
        "        self._failures[key] = self._failures.get(key, 0) + 1",
        "tests/test_staleness_heat.py::test_an_accept_dates_survival_not_death",
    ),
    (
        "anti-limit shaping applied to books that never limit",
        ENGINE / "heat.py",
        "        b = books.get(book)\n        if b is not None and (not b.limits_winners or b.tier in (BookTier.SHARP, BookTier.EXCHANGE)):\n            return Shaping(stake=stake, delay=0.0, min_edge=0.0, defer=False, reason=\"\")",
        "        pass",
        "tests/test_staleness_heat.py::test_shaping_leaves_non_limiting_books_alone",
    ),
    (
        "CLV significance claimed without a sample-size floor",
        ENGINE / "clv.py",
        "        return self.n >= 30 and self.t_stat > 2.0",
        "        return self.t_stat > 2.0",
        "tests/test_kelly_clv.py::test_a_small_sample_refuses_to_claim_an_edge",
    ),
    (
        "bonus bet treated as returning its stake",
        ENGINE / "promo.py",
        "    hedge = amount * (free_odds - 1.0) / hedge_odds",
        "    hedge = amount * free_odds / hedge_odds",
        "tests/test_promo_catalog.py::test_a_bonus_bet_at_even_money_converts_to_half",
    ),
    (
        "deposit match quoted without its playthrough cost",
        ENGINE / "promo.py",
        "    cost = turnover * hold_per_bet\n    net = bonus - cost",
        "    cost = turnover * hold_per_bet\n    net = bonus",
        "tests/test_promo_catalog.py::test_a_deposit_match_can_be_worth_less_than_nothing",
    ),
    (
        "a safety net reported as guaranteed money",
        ENGINE / "promo.py",
        "        offer_type=OfferType.SAFETY_NET,\n        headline=stake,\n        expected=expected,\n        guaranteed=0.0,",
        "        offer_type=OfferType.SAFETY_NET,\n        headline=stake,\n        expected=expected,\n        guaranteed=expected,",
        "tests/test_promo_catalog.py::test_a_safety_net_is_never_guaranteed",
    ),
    (
        "unverified jurisdictions surfaced as though confirmed",
        ENGINE / "catalog.py",
        "        if (v.available_in(state) and v.verified)",
        "        if (v.available_in(state) or v.jurisdiction_unknown)",
        "tests/test_promo_catalog.py::test_unverified_venues_are_excluded_by_default",
    ),
    (
        "a hedge larger than the book will take still counted as a plan",
        ENGINE / "promo.py",
        "        if max_hedge is not None and plan.hedge_stake > max_hedge:\n            continue",
        "        if False:\n            continue",
        "tests/test_promo_catalog.py::test_a_hedge_you_cannot_place_is_not_a_plan",
    ),
    (
        "a bet stored without the devig spread that produced it",
        ENGINE / "ledger.py",
        "        if not self.devig:\n            raise LedgerError(",
        "        if False:\n            raise LedgerError(",
        "tests/test_ledger.py::test_a_bet_without_its_devig_spread_is_refused",
    ),
    (
        "an ungraded bet counted as a graded one",
        ENGINE / "ledger.py",
        '        sql = "SELECT * FROM bets WHERE closing_fair_prob IS NOT NULL"',
        '        sql = "SELECT * FROM bets WHERE 1 = 1"',
        "tests/test_ledger.py::test_an_ungraded_bet_is_not_a_zero",
    ),
    (
        "devig methods filled in where they were missing, not dropped",
        ENGINE / "ledger.py",
        "            common &= set(s)",
        "            common |= set(s)",
        "tests/test_ledger.py::test_methods_missing_on_any_bet_are_dropped_not_filled",
    ),
    (
        "an older build writing to a newer schema",
        ENGINE / "ledger.py",
        "        if found > SCHEMA_VERSION:",
        "        if False:",
        "tests/test_ledger.py::test_a_newer_schema_is_refused_rather_than_written_to",
    ),
    (
        "tag slices judged at a single-test bar",
        ENGINE / "performance.py",
        "        return bonferroni_z(self.tests, self.alpha)",
        "        return Z",
        "tests/test_tags.py::test_the_same_slice_can_fail_once_more_tags_are_tested",
    ),
    (
        "tag case differences counted as separate hypotheses",
        ENGINE / "ledger.py",
        "                tag = raw.strip().lower()",
        "                tag = raw",
        "tests/test_tags.py::test_tags_are_normalised",
    ),
    (
        "the same bet counted twice under one tag",
        ENGINE / "ledger.py",
        '                    "INSERT OR IGNORE INTO bet_tags (bet_id, tag) VALUES (?,?)",',
        '                    "INSERT OR REPLACE INTO bet_tags (bet_id, tag) VALUES (?,?)",',
        "tests/test_tags.py::test_tagging_twice_is_idempotent",
    ),
    (
        "an inferred outcome set reported as a locked market",
        ENGINE / "exposure.py",
        "        return not self.inferred and self.worst[1] > 0",
        "        return self.worst[1] > 0",
        "tests/test_exposure.py::test_an_inferred_market_is_never_reported_as_locked",
    ),
    (
        "a market's worst case taken as the sum of its stakes",
        ENGINE / "exposure.py",
        "        won = sum(p.to_return for p in self.positions if p.outcome == outcome)\n        return won - self.at_risk",
        "        return -self.at_risk",
        "tests/test_exposure.py::test_both_sides_at_a_profit_is_a_locked_market",
    ),
    (
        "a graded but unpaid bet dropped from exposure",
        ENGINE / "ledger.py",
        '        sql, args = "SELECT * FROM bets WHERE profit IS NULL", []',
        '        sql, args = "SELECT * FROM bets WHERE closing_fair_prob IS NULL", []',
        "tests/test_exposure.py::test_a_graded_but_unpaid_bet_is_still_at_risk",
    ),
    (
        "the outcome set built from your own bets instead of the quotes",
        ENGINE / "exposure.py",
        "            known=ledger.known_outcomes(event_id, market_type),",
        "            known=[],",
        "tests/test_exposure.py::test_recorded_quotes_reveal_the_outcome_that_hurts",
    ),
    (
        "a parlay priced as though the margin did not compound",
        ENGINE / "parlay.py",
        "        return 1.0 - self.offered / self.fair",
        "        return self.leg_hold",
        "tests/test_parlay.py::test_the_hold_compounds_with_legs",
    ),
    (
        "same-game legs multiplied as if independent, without the caveat",
        ENGINE / "parlay.py",
        "    if not same_game:\n        return (\"Legs in different games are close enough to independent that \"\n                \"multiplying the probabilities is the right sum.\")",
        "    if True:\n        return \"independent\"",
        "tests/test_parlay.py::test_same_game_legs_are_flagged_as_an_upper_bound",
    ),
    (
        "a payout label on an open slip read as a settled win",
        ENGINE / "betslip.py",
        "    \"won\": \"won\", \"winner\": \"won\", \"cashed\": \"won\",",
        "    \"won\": \"won\", \"win\": \"won\", \"cashed\": \"won\",",
        "tests/test_betslip.py::test_an_unsettled_slip_showing_a_payout_is_not_recorded_as_a_win",
    ),
    (
        "a slip missing its price imported anyway instead of refused",
        ENGINE / "betslip.py",
        "    if not parsed.usable:",
        "    if False:",
        "tests/test_betslip.py::test_a_slip_with_no_price_is_refused_not_guessed",
    ),
    (
        "the to-win amount read as the stake",
        ENGINE / "betslip.py",
        "    stake = _money_near(text, STAKE_WORDS)",
        "    stake = _money_near(text, RETURN_WORDS)",
        "tests/test_betslip.py::test_the_to_win_number_is_never_read_as_the_stake",
    ),
    (
        "a parsed field reporting the lookup key instead of the slip text",
        ENGINE / "betslip.py",
        "            return Field(key, text[at:at + len(name)])",
        "            return Field(key, name)",
        "tests/test_betslip.py::test_every_field_carries_the_text_it_came_from",
    ),
    (
        "the churn hold taken from the most expensive eligible market",
        ENGINE / "offers.py",
        "    return min(candidates, key=lambda c: c.hold)",
        "    return max(candidates, key=lambda c: c.hold)",
        "tests/test_offers.py::test_the_churn_hold_is_the_cheapest_eligible_class_not_the_cheapest_class",
    ),
    (
        "a stated prior reported as though it were measured",
        ENGINE / "offers.py",
        "    return ClassHold(market_class=klass, hold=PRIOR_HOLDS[klass],\n                     provenance=\"prior\")",
        "    return ClassHold(market_class=klass, hold=PRIOR_HOLDS[klass],\n                     provenance=\"measured\")",
        "tests/test_offers.py::test_an_unmeasured_class_falls_back_to_a_prior_that_says_so",
    ),
    (
        "a hold assembled across two books instead of within one",
        ENGINE / "offers.py",
        "        for book in market.complete_books():",
        "        for book in {q.book for q in market.quotes}:",
        "tests/test_offers.py::test_a_book_quoting_two_of_a_three_way_market_is_not_measured",
    ),
    (
        "stale offer terms reported instead of refused",
        ENGINE / "offers.py",
        "    if terms.stale(now):",
        "    if False:",
        "tests/test_offers.py::test_stale_terms_are_refused_rather_than_reported_with_a_warning",
    ),
    (
        "rollover terms accepted with no source to check them against",
        ENGINE / "offers.py",
        "        if not self.source.strip():",
        "        if False:",
        "tests/test_offers.py::test_terms_with_no_source_are_refused",
    ),
    (
        "net money computed off a different base than break-even",
        ENGINE / "offers.py",
        "        base = (self.deposit + self.bonus) if self.includes_deposit else self.bonus",
        "        base = (self.deposit + self.bonus)",
        "tests/test_offers.py::test_net_uses_the_same_base_as_break_even",
    ),
    (
        "a one-sided quote treated as a whole market",
        ENGINE / "offers.py",
        "            if len(prices) < 2:",
        "            if False:",
        "tests/test_offers.py::test_a_market_with_only_one_side_quoted_is_not_measured",
    ),
    (
        "a totals market dispatched to the margin distribution",
        ENGINE / "middles.py",
        "    if market_type == \"totals\":",
        "    if market_type == \"spread\":",
        "tests/test_totals_middles.py::test_a_totals_market_is_never_priced_off_a_margin_distribution",
    ),
    (
        "the totals model reading the margin column",
        ENGINE / "middles.py",
        "    @staticmethod\n    def _column(ledger, sport: str) -> list[int]:\n        return ledger.totals(sport)",
        "    @staticmethod\n    def _column(ledger, sport: str) -> list[int]:\n        return ledger.margins(sport)",
        "tests/test_totals_middles.py::test_a_totals_model_counts_combined_scores_not_margins",
    ),
    (
        "thin totals cells counted as though they were thick",
        ENGINE / "middles.py",
        "        return (self.games(sport) >= self._MIN_GAMES\n                and self.per_cell(sport) >= MIN_PER_CELL)",
        "        return self.games(sport) >= self._MIN_GAMES",
        "tests/test_totals_middles.py::test_a_thin_totals_model_is_declined_even_above_the_game_count",
    ),
    (
        "totals held to the margin game count",
        ENGINE / "middles.py",
        "MIN_TOTAL_GAMES = 400",
        "MIN_TOTAL_GAMES = 200",
        "tests/test_totals_middles.py::test_a_totals_model_at_the_margin_threshold_is_not_measured",
    ),
    (
        "a stated prior spread reported as a measured one",
        ENGINE / "middles.py",
        "    return PRIOR_SIGMA.get(market_type, PRIOR_SIGMA[\"spreads\"]), \"prior\"",
        "    return PRIOR_SIGMA.get(market_type, PRIOR_SIGMA[\"spreads\"]), \"measured\"",
        "tests/test_totals_middles.py::test_sigma_falls_back_to_a_prior_that_says_it_is_one",
    ),
    (
        "a negative correlation estimate passed through unfloored",
        ENGINE / "correlation.py",
        "        rho=min(MAX_RHO, max(0.0, raw)),",
        "        rho=min(MAX_RHO, min(0.0, raw)),",
        "tests/test_correlation.py::test_a_negative_estimate_is_floored_at_zero",
    ),
    (
        "floating-point residue read as real variance",
        ENGINE / "correlation.py",
        "    if sigma <= DEGENERATE * (1.0 + abs(mean)):",
        "    if sigma < 0.0:",
        "tests/test_correlation.py::test_zero_variance_returns_the_prior_not_a_correlation_of_zero",
    ),
    (
        "the stated prior returned labelled as a measurement",
        ENGINE / "correlation.py",
        "    if n_bets < MIN_BETS or len(paired) < MIN_GROUPS:\n        return CorrelationEstimate(\n            rho=prior, provenance=\"prior\", groups=len(paired), bets=n_bets,",
        "    if n_bets < MIN_BETS or len(paired) < MIN_GROUPS:\n        return CorrelationEstimate(\n            rho=prior, provenance=\"measured\", groups=len(paired), bets=n_bets,",
        "tests/test_correlation.py::test_too_few_bets_returns_the_labelled_prior",
    ),
    (
        "group size weighted by bets instead of pairs",
        ENGINE / "correlation.py",
        "        pairs += n - 1",
        "        pairs += n",
        "tests/test_correlation.py::test_larger_groups_recover_the_same_correlation",
    ),
    (
        "dollars summed instead of returns",
        ENGINE / "correlation.py",
        "    return row[\"profit\"] / stake",
        "    return row[\"profit\"]",
        "tests/test_correlation.py::test_one_big_bet_beside_small_ones_does_not_hide_their_co_movement",
    ),
    (
        "a positive floor reported as a share of bankroll lost",
        ENGINE / "portfolio.py",
        "        return abs(min(0.0, self.worst_case)) / self.bankroll",
        "        return abs(max(0.0, self.worst_case)) / self.bankroll",
        "tests/test_portfolio.py::test_a_book_bet_on_both_sides_reports_its_floor_as_a_share_of_bankroll",
    ),
    (
        "effective bets drifting from the sizing rule it explains",
        ENGINE / "portfolio.py",
        "    return n * simultaneous_scale(n, rho) ** 2",
        "    return n * simultaneous_scale(n, rho)",
        "tests/test_portfolio.py::test_effective_bets_is_exactly_n_times_scale_squared",
    ),
    (
        "a zero bankroll divided by instead of refused",
        ENGINE / "portfolio.py",
        "    if bankroll <= 0:",
        "    if False:",
        "tests/test_portfolio.py::test_a_zero_bankroll_is_refused_rather_than_divided_by",
    ),
    (
        "the next-stake cap ignoring what is already open",
        ENGINE / "portfolio.py",
        "        return self.bankroll * MAX_SINGLE * self.scale",
        "        return self.bankroll * MAX_SINGLE",
        "tests/test_portfolio.py::test_the_next_stake_cap_shrinks_with_what_is_already_open",
    ),
    (
        "a portfolio resting on a prior correlation without saying so",
        ENGINE / "portfolio.py",
        "    if not view.correlation.measured:",
        "    if False:",
        "tests/test_portfolio.py::test_an_empty_record_falls_back_to_the_prior_and_flags_it",
    ),
    (
        "an undiversified book passing without a flag",
        ENGINE / "portfolio.py",
        "    if view.live > 1 and view.effective < view.live / 2:",
        "    if False:",
        "tests/test_portfolio.py::test_a_book_behaving_like_half_its_position_count_is_flagged",
    ),
    (
        "a correlation measured over whatever metadata happens to exist",
        ENGINE / "correlation.py",
        "MIN_COVERAGE = 0.5",
        "MIN_COVERAGE = 0.0",
        "tests/test_event_meta.py::test_sparse_metadata_is_refused_rather_than_measured_over_a_subsample",
    ),
    (
        "unrecorded events grouped together under a blank",
        ENGINE / "correlation.py",
        "        if not value:\n            return None",
        "        if False:\n            return None",
        "tests/test_event_meta.py::test_unrecorded_events_are_excluded_rather_than_lumped_together",
    ),
    (
        "a metadata grouping asked for without metadata, answered anyway",
        ENGINE / "correlation.py",
        "    if key in META_KEYS and meta is None:",
        "    if False:",
        "tests/test_event_meta.py::test_asking_for_a_metadata_key_without_metadata_raises",
    ),
    (
        "a blank recorded as a value rather than as an absence",
        ENGINE / "ledger.py",
        "            \"starter\": (starter or \"\").strip() or None,",
        "            \"starter\": starter,",
        "tests/test_event_meta.py::test_a_blank_value_is_stored_as_absent_not_as_a_value",
    ),
    (
        "re-recording an event adding a second contradictory row",
        ENGINE / "ledger.py",
        "                       starter     = COALESCE(excluded.starter, event_meta.starter),",
        "                       starter     = excluded.starter,",
        "tests/test_event_meta.py::test_recording_an_event_twice_updates_rather_than_duplicates",
    ),
    (
        "the wind band dropped from the weather bucket",
        ENGINE / "weather.py",
        "    band = wind_band(text)",
        "    band = wind_bald(text)",
        "tests/test_weather.py::test_two_notes_a_mile_an_hour_apart_land_in_one_bucket",
    ),
    (
        "kilometres per hour read as miles per hour",
        ENGINE / "weather.py",
        "    if match.group(2).lower() != \"mph\":\n        value *= KPH_TO_MPH",
        "    if False:\n        value *= KPH_TO_MPH",
        "tests/test_weather.py::test_kph_is_converted_rather_than_read_as_mph",
    ),
    (
        "an unreadable weather note collected into a bucket of its own",
        ENGINE / "weather.py",
        "    if band is None and precip is None:\n        return None  # nothing readable; excluded rather than bucketed",
        "    if False:\n        return None",
        "tests/test_weather.py::test_an_unreadable_note_is_excluded_rather_than_bucketed",
    ),
    (
        "a bare number read as a temperature without its unit",
        ENGINE / "weather.py",
        "_TEMP = re.compile(r\"(-?\\d+(?:\\.\\d+)?)\\s*(?:deg(?:rees)?\\s*)?\u00b0?\\s*([fc])\\b\", re.I)",
        "_TEMP = re.compile(r\"(-?\\d+(?:\\.\\d+)?)\\s*(?:deg(?:rees)?\\s*)?\u00b0?\\s*([fc]?)\\b\", re.I)",
        "tests/test_weather.py::test_a_bare_number_is_refused_because_the_unit_decides_the_game",
    ),
    (
        "raw weather notes grouped without bucketing",
        ENGINE / "correlation.py",
        "            banded = bucket(str(value))\n            return f\"weather:{banded}\" if banded else None",
        "            return f\"weather:{value}\"",
        "tests/test_weather.py::test_bucketing_turns_singleton_groups_into_measurable_ones",
    ),
    (
        "the fastest feed picked by the largest latency",
        ENGINE / "feedcompare.py",
        "        return sorted(self.usable, key=lambda s: s.mean)",
        "        return sorted(self.usable, key=lambda s: -s.mean)",
        "tests/test_feedcompare.py::test_a_clear_winner_is_named",
    ),
    (
        "an unstamped feed ranked as the fastest one",
        ENGINE / "feedcompare.py",
        "                and not self.looks_unstamped)",
        "                and True)",
        "tests/test_feedcompare.py::test_an_unstamped_feed_never_wins_however_fast_it_looks",
    ),
    (
        "two feeds ranked when the samples cannot separate them",
        ENGINE / "feedcompare.py",
        "        return order[0] if distinguishable(order[0], order[1]) else None",
        "        return order[0]",
        "tests/test_feedcompare.py::test_a_close_pair_is_refused_rather_than_ranked",
    ),
    (
        "unstamped quotes averaged in as zero latency",
        ENGINE / "feedcompare.py",
        "            if seen_at is None:\n                continue          # unstamped: counted, never averaged as zero",
        "            if seen_at is None:\n                seen_at = fetched_at",
        "tests/test_feedcompare.py::test_unstamped_quotes_are_counted_but_never_averaged_as_zero",
    ),
    (
        "a feed judged on the sliver of quotes it bothers to stamp",
        ENGINE / "feedcompare.py",
        "                and self.stamped_share >= MIN_COVERAGE\n",
        "                and True\n",
        "tests/test_feedcompare.py::test_thin_coverage_is_refused_even_with_plenty_of_stamps",
    ),
    (
        "a clock running ahead crediting a quote with arriving early",
        ENGINE / "feedcompare.py",
        "            sample.latencies.append(max(0.0, float(fetched_at) - float(seen_at)))",
        "            sample.latencies.append(float(fetched_at) - float(seen_at))",
        "tests/test_feedcompare.py::test_a_clock_running_ahead_cannot_make_a_quote_arrive_early",
    ),
    (
        "a market captured as closing after it has started",
        ENGINE / "schedule.py",
        "        if starts_at <= now:",
        "        if starts_at >= now:",
        "tests/test_schedule.py::test_a_started_market_is_refused_rather_than_captured_late",
    ),
    (
        "a market with no start time scheduled anyway",
        ENGINE / "schedule.py",
        "        if starts_at is None:",
        "        if False:",
        "tests/test_schedule.py::test_a_market_with_no_start_time_is_refused_not_guessed",
    ),
    (
        "a close captured twice, overwriting the timely one",
        ENGINE / "schedule.py",
        "        if key in closed:",
        "        if False:",
        "tests/test_schedule.py::test_a_market_already_captured_is_not_captured_again",
    ),
    (
        "the next run reported as a moment in the past",
        ENGINE / "schedule.py",
        "    return max(now, min(times)) if times else None",
        "    return min(times) if times else None",
        "tests/test_schedule.py::test_an_overdue_pass_is_due_now_rather_than_in_the_past",
    ),
    (
        "routine captures counted as closing lines",
        ENGINE / "ledger.py",
        "                \"SELECT DISTINCT event_id, market_type FROM quotes \"\n                \"WHERE is_closing = 1\")",
        "                \"SELECT DISTINCT event_id, market_type FROM quotes\")",
        "tests/test_schedule.py::test_a_non_closing_capture_does_not_count_as_the_close",
    ),
    (
        "no-arbitrage reported as an error instead of a result",
        ENGINE / "cli.py",
        "        if margin <= 0:\n            return emit({",
        "        if False:\n            return emit({",
        "tests/test_cli_json.py::test_no_arbitrage_is_a_result_rather_than_an_error",
    ),
    (
        "json payload printed alongside the human table",
        ENGINE / "cli.py",
        "    print(json.dumps(payload, indent=2, sort_keys=True))",
        "    print(\"result:\")\n    print(json.dumps(payload, indent=2, sort_keys=True))",
        "tests/test_cli_json.py::test_json_is_the_only_thing_on_stdout",
    ),
    (
        "same-game parlay legs multiplied as if independent",
        ENGINE / "cli.py",
        "    note = correlation_note(same_game=args.same_game)",
        "    note = correlation_note(same_game=False)",
        "tests/test_cli_json.py::test_same_game_legs_are_flagged_as_an_upper_bound",
    ),
    (
        "a fill probability reported without the feed's own lag",
        ENGINE / "cli.py",
        "    effective = args.age + lag",
        "    effective = args.age",
        "tests/test_cli_json.py::test_latency_is_added_to_the_age_the_screen_showed",
    ),
    (
        "a tab pointing at a panel that does not exist",
        ROOT / "ui" / "src" / "index.html",
        "data-panel=\"fill\"",
        "data-panel=\"filll\"",
        "tests/test_app_ui_is_wired.py::test_every_tab_points_at_a_panel_that_exists",
    ),
    (
        "the window reading an input id the HTML does not define",
        ROOT / "ui" / "src" / "app.js",
        "val(\"f-age\")",
        "val(\"f_age\")",
        "tests/test_app_ui_is_wired.py::test_every_element_the_javascript_reads_exists_in_the_html",
    ),
    (
        "a retail-only state listed with online books",
        ENGINE / "catalog.py",
        '    ("betrivers", "BetRivers", _s("DE", "MI", "NJ", "PA", "WV")),',
        '    ("betrivers", "BetRivers", _s("DE", "MI", "MS", "NJ", "PA", "WV")),',
        "tests/test_promo_catalog.py::test_a_retail_only_state_lists_no_online_book",
    ),
    (
        "a single-operator state quietly gaining a second book",
        ENGINE / "catalog.py",
        '    ("sportsbook-ri", "Sportsbook Rhode Island", _s("RI")),',
        '    ("sportsbook-ri", "Sportsbook Rhode Island", _s("RI", "NH")),',
        "tests/test_promo_catalog.py::test_the_lottery_states_are_now_catalogued",
    ),
    (
        "a lapsed promotion still counted as a holding",
        ENGINE / "ledger.py",
        "            sql += (\" AND state = 'held' AND\"\n                    \" (expires_at IS NULL OR expires_at > ?)\")\n            args.append(now)",
        "            sql += \" AND state = 'held'\"",
        "tests/test_holdings.py::test_a_lapsed_promo_is_not_a_holding",
    ),
    (
        "an expired bonus bet valued as if it were still live",
        ENGINE / "promo.py",
        "        if self.expired(now):\n            return 0.0",
        "        if False:\n            return 0.0",
        "tests/test_holdings.py::test_an_expired_holding_is_worth_exactly_nothing",
    ),
    (
        "a bonus bet valued at its face amount",
        ENGINE / "promo.py",
        "        return self.amount * self.conversion",
        "        return self.amount",
        "tests/test_holdings.py::test_face_value_is_never_the_value",
    ),
    (
        "the same promotion spent twice",
        ENGINE / "ledger.py",
        "        if row[\"state\"] != \"held\":",
        "        if False:",
        "tests/test_holdings.py::test_a_promo_cannot_be_used_twice",
    ),
    (
        "money lost to expiry quietly dropped from the report",
        ENGINE / "promo.py",
        "        return sum(h.amount for h in self.expired)",
        "        return 0.0",
        "tests/test_holdings.py::test_what_expired_unused_is_counted_and_named",
    ),
    (
        "a payout column read across as profit",
        ENGINE / "importer.py",
        "                profit = payout - stake if result != \"void\" else 0.0",
        "                profit = payout",
        "tests/test_importer.py::test_a_payout_column_is_converted_not_read_as_profit",
    ),
    (
        "re-importing a file duplicating every bet",
        ENGINE / "importer.py",
        "    digest = hashlib.sha256(\n        f\"{book}|{placed_at:.0f}|{outcome}|{stake:.2f}|{odds:.4f}\".encode()\n    ).hexdigest()[:16]\n    return f\"{book}:auto:{digest}\"",
        "    return \"\"",
        "tests/test_importer.py::test_rows_without_a_book_id_still_deduplicate",
    ),
    (
        "an imported bet fed to the calibration it cannot train",
        ENGINE / "ledger.py",
        "        bets = [\n            b for b in self.graded_bets(sport, market_type)\n            if self.devig_at_bet(int(b.bet_id))\n        ]",
        "        bets = self.graded_bets(sport, market_type)",
        "tests/test_importer.py::test_engine_bets_stay_trainable_alongside_imports",
    ),
    (
        "an unreadable row defaulted instead of skipped",
        ENGINE / "importer.py",
        '        placed_at = parse_date(value("placed_at"))\n        if placed_at is None:',
        '        placed_at = parse_date(value("placed_at")) or 0.0\n        if False:',
        "tests/test_importer.py::test_a_row_with_an_unreadable_date_is_skipped_not_defaulted",
    ),
    (
        "an index created before the migration that adds its column",
        ENGINE / "ledger.py",
        "CREATE INDEX IF NOT EXISTS idx_bets_placed   ON bets(placed_at);",
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_bets_ref\n    ON bets(external_ref) WHERE external_ref IS NOT NULL;\nCREATE INDEX IF NOT EXISTS idx_bets_placed   ON bets(placed_at);",
        "tests/test_importer.py::test_a_v6_database_migrates_to_v7",
    ),
    (
        "a push counted as a loss in win rate",
        ENGINE / "performance.py",
        "        return self.won / self.decided if self.decided else 0.0",
        "        total = self.won + self.lost + self.push\n        return self.won / total if total else 0.0",
        "tests/test_performance.py::test_a_push_is_not_a_loss",
    ),
    (
        "a voided stake left in turnover",
        ENGINE / "performance.py",
        '    live = [b for b in bets if b.get("result") != "void"]',
        "    live = list(bets)",
        "tests/test_performance.py::test_a_void_leaves_turnover_entirely",
    ),
    (
        "ROI reported without its interval clearing zero",
        ENGINE / "performance.py",
        "        se = self.standard_error\n        if self.n < MIN_BETS or not math.isfinite(se) or se <= 0:\n            return False\n        return abs(self.flat_return) > z * se",
        "        return self.flat_return != 0",
        "tests/test_performance.py::test_a_noisy_positive_record_is_not_called_profitable",
    ),
    (
        "a leak flagged from a sample too thin to mean it",
        ENGINE / "performance.py",
        "            if s.n >= min_bets and s.roi_high < 0",
        "            if s.roi_high < 0",
        "tests/test_performance.py::test_leaks_need_a_sample_before_they_are_flagged",
    ),
    (
        "an unpaid bet counted as a settled one",
        ENGINE / "ledger.py",
        '        sql = "SELECT * FROM bets WHERE profit IS NOT NULL"',
        '        sql = "SELECT * FROM bets WHERE closing_fair_prob IS NOT NULL"',
        "tests/test_performance.py::test_settled_bets_require_payment_not_just_a_closing_line",
    ),
    (
        "the v5 to v6 migration skipped, losing push and void handling",
        ENGINE / "ledger.py",
        '            if found < 6 and not self._has_column("bets", "result"):',
        "            if False:",
        "tests/test_performance.py::test_a_v5_database_migrates_to_v6",
    ),
    (
        "an unmeasured margin table treated as a confident zero",
        ENGINE / "middles.py",
        "        if not self.is_measured(sport):\n            return None\n        return self.counts[sport].get(value, 0) / self.games(sport)",
        "        return self.counts[sport].get(value, 0) / max(1, self.games(sport))",
        "tests/test_middles.py::test_p_margin_declines_below_the_floor_too",
    ),
    (
        "a result landing on the line counted as winning the middle",
        ENGINE / "middles.py",
        "            if low < value < high",
        "            if low <= value <= high",
        "tests/test_middles.py::test_the_window_is_exclusive_at_both_ends",
    ),
    (
        "the reverse pair offered as a middle",
        ENGINE / "middles.py",
        "            if high_line <= low_line:\n                continue",
        "            if False:\n                continue",
        "tests/test_middles.py::test_the_reverse_pair_is_not_a_middle",
    ),
    (
        "a middle quoting the better leg instead of the worse one",
        ENGINE / "middles.py",
        "        return min(low_wins, high_wins)",
        "        return max(low_wins, high_wins)",
        "tests/test_middles.py::test_one_side_is_the_worse_side_not_the_better",
    ),
    (
        "an approximated window reported as counted",
        ENGINE / "middles.py",
        '    return middle_probability(low - centre, high - centre, sigma), "approximated"',
        '    return middle_probability(low - centre, high - centre, sigma), "counted"',
        "tests/test_middles.py::test_provenance_is_reported_not_implied",
    ),
    (
        "calibrated devig weights dropped at pricing time",
        ENGINE / "pricing.py",
        "        method_weights=ctx.method_weights,\n        latency_model=ctx.latency,",
        "        method_weights=None,\n        latency_model=ctx.latency,",
        "tests/test_pricing.py::test_calibrated_devig_weights_change_the_price",
    ),
    (
        "raw book weights handed to fair_value without rescaling",
        ENGINE / "pricing.py",
        "            book_weights=apply_book_weights(raw_books, books) if raw_books else None,",
        "            book_weights=raw_books,",
        "tests/test_pricing.py::test_book_weights_arrive_rescaled_never_raw",
    ),
    (
        "calibration age reported from the newest half instead of the oldest",
        ENGINE / "pricing.py",
        "        return max(ages) if ages else None",
        "        return min(ages) if ages else None",
        "tests/test_pricing.py::test_age_reports_the_oldest_half_not_the_newest",
    ),
    (
        "a stale calibration presented as current",
        ENGINE / "pricing.py",
        "        return age is not None and age > MAX_WEIGHT_AGE",
        "        return False",
        "tests/test_pricing.py::test_old_weights_are_flagged_stale",
    ),
    (
        "the v3 to v4 migration skipped, losing pricing provenance",
        ENGINE / "ledger.py",
        "            if found < 4 and not self._has_column(\"bets\", \"weights_json\"):",
        "            if False:",
        "tests/test_pricing.py::test_a_v3_database_migrates_to_v4",
    ),
    (
        "an undated quote recorded as a measured zero latency",
        ENGINE / "feed.py",
        "                quote.fetched_at = None\n                snapshot.undated += 1",
        "                quote.fetched_at = fetched_at\n                snapshot.undated += 1",
        "tests/test_feed.py::test_stamp_leaves_an_undated_quote_without_a_fetch_time",
    ),
    (
        "the ledger trusting equal timestamps as a measured latency",
        ENGINE / "ledger.py",
        "                WHERE fetched_at IS NOT NULL AND fetched_at > seen_at",
        "                WHERE fetched_at IS NOT NULL AND fetched_at >= seen_at",
        "tests/test_feed.py::test_the_ledger_ignores_equal_timestamps",
    ),
    (
        "a quote dated in the future kept instead of dropped",
        ENGINE / "feed.py",
        "            if quote.seen_at > fetched_at + MAX_CLOCK_SKEW:",
        "            if False:",
        "tests/test_feed.py::test_a_quote_dated_far_in_the_future_is_dropped",
    ),
    (
        "the handicap line dropped when a market is serialised",
        ENGINE / "feed.py",
        '                "line": q.outcome.line,',
        '                "line": None,',
        "tests/test_feed.py::test_the_line_survives_the_round_trip",
    ),
    (
        "quote age measured from our fetch instead of the book's timestamp",
        ENGINE / "models.py",
        "        base = max(0.0, (time.time() if now is None else now) - self.seen_at)",
        "        base = max(0.0, (time.time() if now is None else now) - (self.fetched_at or self.seen_at))",
        "tests/test_latency.py::test_age_is_measured_from_the_book_not_from_our_fetch",
    ),
    (
        "feed latency ignored when ranking an undated quote",
        ENGINE / "ev.py",
        "            floor = 0.0 if latency_model is None else latency_model.typical(quote.book)",
        "            floor = 0.0",
        "tests/test_latency.py::test_latency_lowers_fill_probability_on_an_undated_feed",
    ),
    (
        "a dated quote penalised for its latency twice",
        ENGINE / "models.py",
        "        if latency_floor > 0.0 and self.provenance == \"assumed\":",
        "        if latency_floor > 0.0:",
        "tests/test_latency.py::test_a_dated_feed_is_not_penalised_twice",
    ),
    (
        "unknown feed latency treated as zero latency",
        ENGINE / "staleness.py",
        "        if n == 0:\n            return PRIOR_LATENCY",
        "        if n == 0:\n            return 0.0",
        "tests/test_latency.py::test_the_model_starts_at_a_stated_prior",
    ),
    (
        "the v2 to v3 migration skipped",
        ENGINE / "ledger.py",
        "            if found < 3 and not self._has_column(\"quotes\", \"fetched_at\"):",
        "            if False:",
        "tests/test_latency.py::test_a_v2_database_migrates_to_v3",
    ),
    (
        "book weights written despite losing out of sample",
        ENGINE / "calibrate.py",
        "    if result.candidate_score >= result.incumbent_score - MIN_IMPROVEMENT:\n        result.reason = (\n            f\"candidate scored {result.candidate_score:.6f} out of sample \"\n            f\"against the incumbent's {result.incumbent_score:.6f} — no better, \"\n            \"so the existing weights stand\"\n        )\n        return result\n\n    result.accepted = True\n    if write:\n        ledger.set_setting(key, proposed)\n    return result\n\n\ndef book_weights_for(",
        "    result.accepted = True\n    if write:\n        ledger.set_setting(key, proposed)\n    return result\n\n\ndef book_weights_for(",
        "tests/test_calibrate_books.py::test_calibration_refuses_weights_that_lose_out_of_sample",
    ),
    (
        "a book weighted from too few markets to compare",
        ENGINE / "calibrate.py",
        "    eligible = {b: e for b, e in errors.items() if counts[b] >= min_coverage}",
        "    eligible = dict(errors)",
        "tests/test_calibrate_books.py::test_a_book_below_the_coverage_floor_is_not_weighted",
    ),
    (
        "book blending done in probability space instead of log-odds",
        ENGINE / "calibrate.py",
        "    return _expit(sum(_logit(probs[b]) * w for b, w in used.items()) / total)",
        "    return sum(probs[b] * w for b, w in used.items()) / total",
        "tests/test_calibrate_books.py::test_the_book_blend_matches_fair_value",
    ),
    (
        "calibrated book weights left on a scale that swamps the defaults",
        ENGINE / "calibrate.py",
        "    tier_total = sum(books[k].weight for k in covered)",
        "    tier_total = float(len(covered))",
        "tests/test_calibrate_books.py::test_calibrated_weights_are_rescaled_onto_the_tier_scale",
    ),
    (
        "the v1 to v2 migration skipped, leaving old rows unreadable",
        ENGINE / "ledger.py",
        "            if found < 2 and not self._has_column(\"bets\", \"book_probs\"):",
        "            if False:",
        "tests/test_calibrate_books.py::test_a_v1_database_with_rows_migrates_without_losing_them",
    ),
    (
        "grading built from two books' halves of one market",
        ENGINE / "grade.py",
        "    complete = {\n        book: prices for book, prices in closing.items() if len(prices) >= 2\n    }",
        "    merged = {}\n    for prices in closing.values():\n        merged.update(prices)\n    complete = {'merged': merged} if len(merged) >= 2 else {}",
        "tests/test_grade.py::test_books_are_never_mixed",
    ),
    (
        "grading a bet against a close at a different line",
        ENGINE / "grade.py",
        "    if not with_outcome:\n        return None, f\"line moved: no close on {outcome}\"",
        "    if not with_outcome:\n        with_outcome = complete",
        "tests/test_grade.py::test_a_moved_line_is_refused_not_approximated",
    ),
    (
        "a soft book's close accepted as market truth",
        ENGINE / "grade.py",
        "    if require_anchor and _rank(best, books) > _TIER_RANK[BookTier.EXCHANGE]:",
        "    if False:",
        "tests/test_grade.py::test_a_retail_only_close_is_refused_by_default",
    ),
    (
        "a mid-market quote treated as a closing line",
        ENGINE / "ledger.py",
        "                WHERE is_closing = 1 AND event_id = ? AND market_type = ?",
        "                WHERE event_id = ? AND market_type = ?",
        "tests/test_grade.py::test_only_closing_quotes_count",
    ),
    (
        "calibration writing weights that lose out of sample",
        ENGINE / "calibrate.py",
        "    if result.candidate_score >= result.incumbent_score - MIN_IMPROVEMENT:",
        "    if False:",
        "tests/test_calibrate.py::test_calibration_refuses_weights_that_do_not_beat_the_incumbent",
    ),
    (
        "calibration fitted on the slice it is verified against",
        ENGINE / "calibrate.py",
        "    proposed = weights_from_scores(method_scores(train, train_c))",
        "    proposed = weights_from_scores(method_scores(bets, candidates))",
        "tests/test_calibrate.py::test_calibration_can_make_things_worse_and_is_caught",
    ),
    (
        "calibration running below the graded-bet floor",
        ENGINE / "calibrate.py",
        "    if len(bets) < min_graded:",
        "    if False:",
        "tests/test_calibrate.py::test_calibration_refuses_a_small_sample",
    ),
    (
        "the calibrated blend diverging from the one the engine uses",
        ENGINE / "calibrate.py",
        "    return sum(probs[m] * w for m, w in used.items()) / total",
        "    return sum(probs[m] * w * w for m, w in used.items()) / total",
        "tests/test_calibrate.py::test_blending_matches_the_engine_it_calibrates",
    ),
    (
        "a band that does not contain its own midpoint accepted",
        ENGINE / "ledger.py",
        "        if not self.fair_low <= self.fair_prob <= self.fair_high:",
        "        if False:",
        "tests/test_ledger.py::test_a_band_that_does_not_contain_its_own_midpoint_is_refused",
    ),
    (
        "crash reporter writes the exception message verbatim",
        ENGINE / "crash.py",
        '"message": sanitise(str(exc_value)),',
        '"message": str(exc_value),',
        "tests/test_crash_capture.py::test_a_credential_in_the_exception_message_never_reaches_the_file",
    ),
    (
        "crash reporter writes argv verbatim",
        ENGINE / "crash.py",
        '"argv": [sanitise(a) for a in sys.argv],',
        '"argv": sys.argv,',
        "tests/test_crash_capture.py::test_a_credential_in_argv_never_reaches_the_file",
    ),
    (
        "crash directory left world-readable",
        ENGINE / "crash.py",
        "        os.chmod(CRASH_DIR, 0o700)",
        "        pass",
        "tests/test_crash_capture.py::test_the_file_is_readable_only_by_its_owner",
    ),
    (
        "crash handler installed after the parser is built",
        ROOT / "backend" / "overlay_engine" / "cli.py",
        "    crash.install()",
        "    pass",
        "tests/test_crash_capture.py::test_install_happens_before_anything_else_in_main",
    ),
    (
        "an ordinary refusal shown to the user as a stack trace",
        ROOT / "backend" / "overlay_engine" / "cli.py",
        "        if not crash.is_expected(type(exc)):",
        "        if True:",
        "tests/test_crash_capture.py::test_a_refusal_prints_a_sentence_and_writes_no_report",
    ),
    (
        "a refusal reaching the hook filed as a crash",
        ENGINE / "crash.py",
        "        if not is_expected(exc_type):",
        "        if True:",
        "tests/test_crash_capture.py::test_the_hook_itself_ignores_refusals_not_just_the_cli",
    ),
]


def _purge_bytecode() -> None:
    """Delete every `__pycache__` under the engine.

    Python invalidates cached bytecode on (mtime, size). Several breaks here
    are *same-size* edits — `&=` for `|=`, `1` for `0` — and when one lands in
    the same mtime second as the original, the cache decides the file is
    unchanged and loads the old bytecode. The broken code then never runs, the
    test passes, and the harness reports a perfectly good gate as MISSED.

    That happened: "devig methods filled in where they were missing" flipped to
    undetected after an unrelated edit shifted the file's timing, while the same
    break caught correctly when run by hand. A harness that reports a false
    result is worse than no harness, because the whole point of this file is to
    be the thing you trust when a green suite isn't enough.
    """
    for cache in ROOT.rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)


def run(test: str) -> bool:
    """True when the test passes. Always compiles the engine from source."""
    _purge_bytecode()
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    result = subprocess.run(
        [sys.executable, "-B", "-m", "pytest", test, "-q", "--no-header",
         "-p", "no:cacheprovider"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        env=env,
    )
    return result.returncode == 0


# ---------------------------------------------------------------- the lock

LOCK_PATH = ROOT / ".break_test.lock"


class ConcurrentRun(RuntimeError):
    """Another harness run holds the tree."""


def _holder(text: str) -> int | None:
    try:
        return int(text.split(None, 1)[0])
    except (ValueError, IndexError):
        return None


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True          # exists, owned by someone else
    return True


@contextlib.contextmanager
def exclusive():
    """Refuse to run two harnesses against one tree.

    This harness edits engine source in place and restores it afterwards. The
    restore is careful — it re-reads and verifies — but `original` is captured
    per case, so a run that *starts* while another has a file broken records
    the sabotage as the original and faithfully restores it. The tree is then
    left with a disabled guard and a green-looking test suite, which is the
    worst failure this repo can produce: the next commit ships an engine whose
    checks are off.

    That is not hypothetical. Two loop iterations fired at once, and three
    guards in `ledger.py` were left as `if False:` — a band check, a migration
    step and the double-spend check on promotions. Nothing failed loudly; the
    breaks simply reported themselves stale, three different ones each run.

    So the lock is exclusive, and a live holder is a hard refusal rather than a
    wait. Waiting would serialise the runs and hide the fact that the loop is
    firing twice, which is itself worth knowing.
    """
    try:
        fd = os.open(LOCK_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        held = LOCK_PATH.read_text() if LOCK_PATH.exists() else ""
        pid = _holder(held)
        if pid is not None and _alive(pid):
            raise ConcurrentRun(
                f"another break-test run holds this tree (pid {pid}).\n"
                "  This harness rewrites engine source, so two runs corrupt\n"
                "  each other and can leave a disabled guard behind. Wait for\n"
                "  it, or kill it and delete " + str(LOCK_PATH) + "."
            )
        # The holder is gone. Its tree may still carry sabotage, which the
        # per-case check below will name.
        print(f"  stale lock from pid {pid} — taking over", file=sys.stderr)
        LOCK_PATH.unlink(missing_ok=True)
        fd = os.open(LOCK_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY)

    try:
        os.write(fd, f"{os.getpid()} break_test".encode())
        os.close(fd)
        yield
    finally:
        LOCK_PATH.unlink(missing_ok=True)


def main() -> int:
    failures: list[str] = []

    # At least one case must be a same-size edit. That is the shape that
    # defeats Python's (mtime, size) bytecode invalidation, so it is the shape
    # that proves `_purge_bytecode` is still doing its job. Without one, the
    # purge could be deleted and every case would still pass — the harness
    # would look healthy while quietly testing stale bytecode.
    same_size = [c for c in CASES if len(c[2]) == len(c[3])]
    if not same_size:
        print("no same-size break case — the bytecode-staleness guard is untested",
              file=sys.stderr)
        return 2

    for label, path, find, replace, test in CASES:
        original = path.read_text()

        if find not in original:
            if replace in original:
                print(
                    f"\nANCHOR GONE, REPLACEMENT PRESENT in {path.name}.\n"
                    f"  Two things look like this and only one is an emergency:\n"
                    f"    1. an interrupted run left sabotage in the tree, and a\n"
                    f"       guard is currently disabled \u2014 repair it now;\n"
                    f"    2. a refactor moved the anchor and made the\n"
                    f"       replacement text a legitimate line \u2014 repoint\n"
                    f"       the case.\n"
                    f"  Read the line in context before deciding which:\n"
                    f"    want: {find.strip()}\n"
                    f"    have: {replace.strip()}",
                    file=sys.stderr)
                return 2
            failures.append(f"{label}: anchor text not found in {path.name} — case is stale")
            continue

        # Baseline: the gate must be green before it is broken. A test that was
        # already failing would otherwise be scored as a successful catch.
        if not run(test):
            failures.append(f"{label}: {test} was already failing before the break")
            continue

        path.write_text(original.replace(find, replace, 1))
        try:
            caught = not run(test)
        finally:
            path.write_text(original)
            # Verify the restore rather than trusting a write nobody watched.
            if path.read_text() != original:
                print(f"RESTORE FAILED for {path} — the tree is broken", file=sys.stderr)
                return 2

        if caught:
            print(f"  caught   {label}")
        else:
            print(f"  MISSED   {label}")
            failures.append(f"{label}: {test} passed against a deliberately broken engine")

    print()
    if failures:
        print(f"{len(failures)} of {len(CASES)} breaks went undetected:")
        for f in failures:
            print(f"  - {f}")
        return 1

    print(f"all {len(CASES)} breaks caught")
    return 0


def _guarded() -> int:
    try:
        with exclusive():
            return main()
    except ConcurrentRun as exc:
        print(f"REFUSING: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(_guarded())
