#!/usr/bin/env bash
# Serve the shipped frontend with a stubbed Tauri bridge, so the window can be
# LOOKED AT without installing the app.
#
# Why this exists: the fill panel shipped in 0.1.2 on a green suite that had
# never rendered it. `cargo test` proves the shell spawns the engine and pytest
# proves the arithmetic; between them sits the window, which nothing saw. That
# is the same hole as the data plate whose CSS classes did not exist — the
# build was green because geometry lives where the checker does not look.
#
# tests/test_app_ui_is_wired.py now catches broken wiring statically. It cannot
# catch "renders, but wrong", and nothing static can. This is the thing you
# look at.
#
#   ./scripts/preview_ui.sh          # builds and serves on :8901
#
# The bridge is stubbed with REAL output from the sidecar inside the built
# .app, so what renders here is what renders in the window.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${PORT:-8901}"
WORK="${TMPDIR:-/tmp}/bookbreaker-ui-preview"

SIDECAR="$(find "$ROOT/ui/src-tauri/target/release/bundle/macos/Bookbreaker.app" \
  -name overlay-engine -type f 2>/dev/null | head -1 || true)"
if [ -z "$SIDECAR" ]; then
  echo "no bundled sidecar — run ./scripts/build_app.sh first" >&2
  exit 2
fi
echo "sidecar: $SIDECAR"

rm -rf "$WORK"; mkdir -p "$WORK"
cp "$ROOT/ui/src/index.html" "$ROOT/ui/src/app.js" "$ROOT/ui/src/app.css" "$WORK/"

ENGINE="$SIDECAR" WORK="$WORK" python3 - <<'PY'
import json, os, pathlib, subprocess
engine, work = os.environ["ENGINE"], pathlib.Path(os.environ["WORK"])
cases = {
    "devig": ["devig", "-145", "+125", "--json"],
    "arb": ["arb", "2.10", "2.05", "--stake", "1000", "--json"],
    "kelly": ["kelly", "--odds", "+150", "--prob", "0.45",
              "--bankroll", "10000", "--json"],
    "parlay": ["parlay", "-110", "-110", "-110", "-110", "--json"],
    "fill": ["fill", "--age", "10", "--book", "dk", "--market", "h2h", "--json"],
}
table = {}
for name, argv in cases.items():
    run = subprocess.run([engine] + argv, capture_output=True, text=True, timeout=60)
    if run.returncode != 0:
        raise SystemExit(f"{name}: sidecar failed — {run.stderr[:200]}")
    table[name] = json.loads(run.stdout)
(work / "stub.js").write_text(
    "window.__TAURI__ = { core: { invoke: async (cmd, a) => {\n"
    f"  const T = {json.dumps(table)};\n"
    "  if (T[a.args[0]]) return T[a.args[0]];\n"
    "  throw new Error('no stub for ' + a.args.join(' '));\n} } };\n")
page = work / "index.html"
html = page.read_text().replace(
    '<script src="app.js"></script>',
    '<script src="stub.js"></script>\n<script src="app.js"></script>', 1)
if "stub.js" not in html:
    raise SystemExit("could not inject the stub — the script tag moved")
page.write_text(html)
print(f"stubbed {len(table)} panels with real sidecar output")
PY

echo "open http://localhost:${PORT}/  (ctrl-c to stop)"
cd "$WORK" && exec python3 -m http.server "$PORT"
