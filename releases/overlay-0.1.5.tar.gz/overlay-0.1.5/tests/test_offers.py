"""The churn hold decides the offer, so the churn hold has to be honest."""

import pytest

from overlay_engine.models import Book, BookTier, Market, Outcome, Quote
from overlay_engine.offers import (
    CLASSES,
    MAX_TERMS_AGE_DAYS,
    PRIOR_HOLDS,
    ClassHold,
    OfferError,
    RolloverTerms,
    cheapest_eligible,
    evaluate,
    hold_for,
    load_terms,
    measure_class_holds,
)

NOW = 1_800_000_000.0
DAY = 86_400.0


def _market(market_type: str, prices: dict[str, float], book: str = "dk") -> Market:
    return Market(
        event_id="e1", sport="nfl", market_type=market_type,
        quotes=[
            Quote(book=Book(key=book, name=book, tier=BookTier.RETAIL),
                  outcome=Outcome(name=k), decimal=v, seen_at=NOW)
            for k, v in prices.items()
        ],
    )


def _terms(**kw) -> RolloverTerms:
    base = dict(book="prime", state="NJ", rollover=10.0,
                eligible=frozenset({"h2h"}), fetched_at=NOW - DAY,
                source="https://example.test/terms")
    base.update(kw)
    return RolloverTerms(**base)


# ------------------------------------------------------------ measuring

def test_a_measured_hold_comes_off_the_prices_not_a_table():
    """-110/-110 is a 4.55% hold; nothing here is allowed to assert it."""
    got = measure_class_holds([_market("h2h", {"home": 1.909, "away": 1.909})])
    assert got["h2h"].measured
    assert got["h2h"].hold == pytest.approx(0.0455, abs=1e-3)
    assert got["h2h"].n_markets == 1


def test_a_class_with_nothing_to_measure_is_absent_not_zero():
    """Absent and zero are different answers, and zero is the dangerous one."""
    got = measure_class_holds([_market("h2h", {"home": 1.909, "away": 1.909})])
    assert "parlay" not in got


def test_a_hold_is_never_assembled_from_two_books_prices():
    """That is the arbitrage between them, not either one's margin."""
    m = _market("h2h", {"home": 2.10}, book="dk")
    m.quotes.append(Quote(book=Book(key="fd", name="fd", tier=BookTier.RETAIL),
                          outcome=Outcome(name="away"), decimal=2.10, seen_at=NOW))
    got = measure_class_holds([m])
    assert "h2h" not in got  # neither book prices the market completely


def test_a_book_quoting_two_of_a_three_way_market_is_not_measured():
    """The case the two-book test cannot reach.

    A book with two of three outcomes has two prices, so a "at least two
    prices" check waves it through. Its overround is missing a leg, and a hold
    read off it is understated by exactly the side that is absent — which makes
    the market look cheaper to churn than it is.
    """
    m = _market("h2h", {"home": 2.6, "away": 3.4})       # no draw
    m.quotes.append(Quote(book=Book(key="fd", name="fd", tier=BookTier.RETAIL),
                          outcome=Outcome(name="draw"), decimal=3.5, seen_at=NOW))
    assert "h2h" not in measure_class_holds([m])


def test_a_market_with_only_one_side_quoted_is_not_measured():
    """The only case the completeness check cannot reach.

    With one outcome on the board, the book quoting it *is* quoting every
    outcome, so completeness is satisfied. A hold read off a single price is
    not a margin at all — it comes out negative — and a negative churn hold
    makes every offer look like it clears.
    """
    assert measure_class_holds([_market("h2h", {"home": 2.10})]) == {}


def test_measuring_averages_across_markets_and_counts_them():
    got = measure_class_holds([
        _market("h2h", {"home": 1.909, "away": 1.909}),
        _market("h2h", {"home": 1.952, "away": 1.952}),
    ])
    assert got["h2h"].n_markets == 2
    assert 0.02 < got["h2h"].hold < 0.05


def test_an_unknown_market_type_is_skipped_rather_than_binned_somewhere():
    got = measure_class_holds([_market("corners", {"o": 1.9, "u": 1.9})])
    assert got == {}


# ------------------------------------------------------------ provenance

def test_an_unmeasured_class_falls_back_to_a_prior_that_says_so():
    got = hold_for("parlay", {})
    assert not got.measured
    assert got.provenance == "prior"
    assert got.hold == PRIOR_HOLDS["parlay"]
    assert "PRIOR" in got.describe()


def test_a_measured_class_is_preferred_over_its_prior():
    measured = measure_class_holds([_market("h2h", {"home": 1.99, "away": 1.99})])
    got = hold_for("h2h", measured)
    assert got.measured
    assert got.hold != PRIOR_HOLDS["h2h"]


def test_every_class_has_a_prior_so_nothing_can_fall_through():
    assert set(PRIOR_HOLDS) == set(CLASSES)


def test_a_prior_never_reports_a_market_count_it_does_not_have():
    assert hold_for("futures", {}).n_markets == 0


def test_an_unknown_class_raises_rather_than_inventing_a_prior():
    with pytest.raises(OfferError, match="unknown market class"):
        hold_for("esports_map_handicap", {})


# ------------------------------------------------------------ eligibility

def test_the_churn_hold_is_the_cheapest_eligible_class_not_the_cheapest_class():
    """The whole module in one assertion.

    A book that excludes h2h and allows only props is not a 4.5% churn, and
    treating it as one is what makes a losing offer look like a winning one.
    """
    measured = measure_class_holds([
        _market("h2h", {"home": 1.909, "away": 1.909}),
        _market("player_prop", {"over": 1.75, "under": 1.75}),
    ])
    props_only = cheapest_eligible(_terms(eligible=frozenset({"player_prop"})),
                                   measured)
    both = cheapest_eligible(_terms(eligible=frozenset({"h2h", "player_prop"})),
                             measured)
    assert props_only.market_class == "player_prop"
    assert both.market_class == "h2h"
    assert props_only.hold > both.hold


def test_a_verdict_flips_when_the_cheap_market_is_excluded():
    """Same headline offer, opposite answer, decided only by the restriction."""
    measured = measure_class_holds([
        _market("h2h", {"home": 1.909, "away": 1.909}),
        _market("player_prop", {"over": 1.75, "under": 1.75}),
    ])
    open_terms = _terms(eligible=frozenset({"h2h", "player_prop"}))
    shut_terms = _terms(eligible=frozenset({"player_prop"}))
    assert evaluate(open_terms, 1000, 1000, measured, NOW).clears
    assert not evaluate(shut_terms, 1000, 1000, measured, NOW).clears


def test_terms_with_no_eligible_market_are_refused_at_construction():
    with pytest.raises(OfferError, match="no eligible markets"):
        _terms(eligible=frozenset())


def test_terms_naming_a_market_class_that_does_not_exist_are_refused():
    with pytest.raises(OfferError, match="unknown market class"):
        _terms(eligible=frozenset({"h2h", "shirt_numbers"}))


# ------------------------------------------------------------ the verdict

def test_break_even_on_a_100_percent_match_at_10x_is_5_percent():
    """The number that decides every deposit match, computed not asserted."""
    v = evaluate(_terms(rollover=10.0), 1000, 1000, {}, NOW)
    assert v.breakeven == pytest.approx(0.05, abs=1e-9)


def test_net_and_margin_agree_about_the_same_offer():
    """`net` positive and `margin` negative would be two answers to one
    question, and the base is the only place they can drift apart."""
    measured = measure_class_holds([_market("h2h", {"home": 1.909, "away": 1.909})])
    for includes in (True, False):
        v = evaluate(_terms(includes_deposit=includes), 1000, 1000, measured, NOW)
        assert (v.net > 0) == (v.margin > 0) == v.clears


def test_net_uses_the_same_base_as_break_even():
    v = evaluate(_terms(includes_deposit=False, rollover=10.0), 1000, 1000, {}, NOW)
    # base = bonus only: 10 * 1000 * hold, against a break-even of 1000/10000.
    assert v.breakeven == pytest.approx(0.10, abs=1e-9)
    assert v.net == pytest.approx(1000 - 10 * 1000 * v.churn.hold, abs=1e-6)


def test_a_verdict_resting_on_a_prior_says_so_in_its_output():
    v = evaluate(_terms(eligible=frozenset({"parlay"})), 1000, 1000, {}, NOW)
    assert not v.measured
    assert "PRIOR" in v.describe()


def test_a_verdict_resting_on_a_measurement_does_not_cry_prior():
    measured = measure_class_holds([_market("h2h", {"home": 1.909, "away": 1.909})])
    v = evaluate(_terms(), 1000, 1000, measured, NOW)
    assert v.measured
    assert "PRIOR" not in v.describe()


# ------------------------------------------------------------ staleness

def test_stale_terms_are_refused_rather_than_reported_with_a_warning():
    old = _terms(fetched_at=NOW - (MAX_TERMS_AGE_DAYS + 1) * DAY)
    with pytest.raises(OfferError, match="days old"):
        evaluate(old, 1000, 1000, {}, NOW)


def test_terms_inside_the_window_evaluate_normally():
    fresh = _terms(fetched_at=NOW - (MAX_TERMS_AGE_DAYS - 1) * DAY)
    assert evaluate(fresh, 1000, 1000, {}, NOW).terms_age_days < MAX_TERMS_AGE_DAYS


def test_terms_with_no_source_are_refused():
    with pytest.raises(OfferError, match="no source"):
        _terms(source="   ")


def test_terms_with_no_date_are_refused():
    with pytest.raises(OfferError, match="no fetched_at"):
        _terms(fetched_at=0)


# ------------------------------------------------------------ the feed

def _write(tmp_path, body):
    path = tmp_path / "offer_terms.csv"
    path.write_text(
        "book,state,rollover,eligible,min_odds,includes_deposit,"
        "fetched_at,source,note\n" + body)
    return path


def test_the_shipped_feed_parses_and_every_row_in_it_is_sourced():
    """The file that ships must load clean, empty or not.

    Deliberately against the real clock rather than the frozen NOW every other
    test uses. A row that ships today and rots in six weeks would pass forever
    against a fixed timestamp — the point of the freshness rule is that it
    fires when nobody is looking at it.
    """
    import time
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    report = load_terms(root / "data" / "offer_terms.csv", time.time())
    assert not report.refused, report.refused
    for terms in report.terms:
        assert terms.source.startswith("http")


def test_an_empty_feed_says_it_is_empty_rather_than_looking_broken():
    import time
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    report = load_terms(root / "data" / "offer_terms.csv", time.time())
    if not report.terms:
        assert "nothing has been sourced" in report.describe()


def test_a_row_with_no_source_is_refused_and_named(tmp_path):
    path = _write(tmp_path, f"prime,NJ,10,h2h,,true,{NOW - DAY},,\n")
    report = load_terms(path, NOW)
    assert not report.terms
    assert len(report.refused) == 1
    assert "no source" in report.refused[0][1]
    assert "prime" in report.refused[0][0]


def test_a_stale_row_is_refused_by_the_loader_too(tmp_path):
    old = NOW - (MAX_TERMS_AGE_DAYS + 5) * DAY
    path = _write(tmp_path, f"prime,NJ,10,h2h,,true,{old},https://x.test/t,\n")
    report = load_terms(path, NOW)
    assert not report.terms
    assert "days old" in report.refused[0][1]


def test_a_good_row_loads_with_its_classes_split(tmp_path):
    path = _write(
        tmp_path,
        f"prime,nj,10,h2h|totals,1.5,false,{NOW - DAY},https://x.test/t,note here\n")
    report = load_terms(path, NOW)
    assert len(report.terms) == 1
    got = report.terms[0]
    assert got.eligible == frozenset({"h2h", "totals"})
    assert got.state == "NJ"
    assert got.min_odds == 1.5
    assert got.includes_deposit is False


def test_blank_lines_are_skipped_not_refused(tmp_path):
    path = _write(tmp_path,
                  f"prime,NJ,10,h2h,,true,{NOW - DAY},https://x.test/t,\n,,,,,,,,\n")
    report = load_terms(path, NOW)
    assert len(report.terms) == 1
    assert not report.refused


def test_one_bad_row_does_not_stop_the_good_ones(tmp_path):
    path = _write(
        tmp_path,
        f"prime,NJ,10,h2h,,true,{NOW - DAY},https://x.test/t,\n"
        f"betparx,PA,15,nonsense,,true,{NOW - DAY},https://x.test/u,\n")
    report = load_terms(path, NOW)
    assert len(report.terms) == 1
    assert len(report.refused) == 1


def test_class_hold_describe_reports_the_market_count_it_measured():
    got = ClassHold(market_class="h2h", hold=0.045, provenance="measured",
                    n_markets=7)
    assert "7 markets" in got.describe()
