"""P&L, ROI and win rate — and how much of it the record can actually support."""

import pytest

from overlay_engine.ledger import AtBet, Ledger, LedgerError
from overlay_engine.performance import (
    CSV_COLUMNS,
    MIN_BETS,
    from_ledger,
    report,
    to_csv,
)

DEVIG = {"power": 0.50, "shin": 0.50, "additive": 0.50, "multiplicative": 0.50}


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "perf.db") as ledger:
        yield ledger


def place(db, i, *, stake=100.0, decimal=2.0, sport="nfl", market="h2h",
          book="dk", result=None, profit=None):
    bet_id = db.record_bet(
        event_id=f"e{i}", sport=sport, market_type=market, outcome="home",
        book=book, decimal_odds=decimal, stake=stake, placed_at=1000.0 + i,
        at_bet=AtBet(fair_prob=0.50, fair_low=0.47, fair_high=0.53,
                     devig=dict(DEVIG)),
    )
    if result is not None:
        db.settle(bet_id, closing_fair_prob=0.50, result=result, profit=profit)
    return bet_id


def bet(result, profit, stake=100.0, decimal=2.0, sport="nfl",
        market="h2h", book="dk"):
    """A settled-bet row as `Ledger.settled_bets` returns one."""
    return {
        "id": 1, "placed_at": 1000.0, "settled_at": 2000.0, "sport": sport,
        "market_type": market, "outcome": "home", "book": book,
        "decimal_odds": decimal, "stake": stake, "result": result,
        "profit": profit, "fair_prob": 0.5, "closing_fair_prob": 0.5,
        "p_fill": 1.0, "heat": 0.0,
    }


# ----------------------------------------------------------------- the basics


def test_profit_and_roi(db):
    rep = report([bet("won", 100.0), bet("lost", -100.0), bet("won", 100.0)])
    assert rep.overall.profit == pytest.approx(100.0)
    assert rep.overall.turnover == pytest.approx(300.0)
    assert rep.overall.roi == pytest.approx(1 / 3)


def test_an_empty_record_says_so():
    rep = report([])
    assert rep.overall.n == 0
    assert rep.overall.verdict() == "no settled bets"
    assert rep.overall.roi == 0.0


def test_win_rate_counts_decided_bets_only():
    rep = report([bet("won", 100.0), bet("lost", -100.0), bet("push", 0.0)])
    assert rep.overall.decided == 2
    assert rep.overall.win_rate == pytest.approx(0.5)


def test_a_push_is_not_a_loss():
    """The difference between a break-even record and an apparent 49% one on a
    book full of pushed spreads."""
    with_push = report([bet("won", 100.0)] * 5 + [bet("push", 0.0)] * 5)
    assert with_push.overall.win_rate == pytest.approx(1.0)
    assert with_push.overall.push == 5


def test_a_void_leaves_turnover_entirely():
    """Leaving a voided stake in turnover deflates ROI, silently."""
    rep = report([bet("won", 100.0), bet("void", 0.0, stake=900.0)])
    assert rep.overall.turnover == pytest.approx(100.0)
    assert rep.overall.roi == pytest.approx(1.0)
    assert rep.overall.void == 1
    assert rep.overall.n == 1


def test_units_need_a_stated_unit():
    rep = report([bet("won", 250.0)])
    assert rep.overall.units(50.0) == pytest.approx(5.0)
    with pytest.raises(ValueError):
        rep.overall.units(0.0)


# ------------------------------------------------------------- the honesty


def test_a_small_sample_refuses_to_be_characterised():
    """A 2% edge over 500 even-money bets swings between -7% and +11% for no
    reason the bettor did anything about."""
    rep = report([bet("won", 100.0), bet("lost", -100.0)] * 5)
    assert rep.overall.n == 10
    assert not rep.overall.significant
    assert "too few" in rep.overall.verdict()


def test_a_noisy_positive_record_is_not_called_profitable():
    rows = [bet("won", 100.0)] * 26 + [bet("lost", -100.0)] * 24
    rep = report(rows)
    assert rep.overall.profit > 0
    assert rep.overall.roi_low < 0 < rep.overall.roi_high
    assert not rep.overall.significant
    assert "indistinguishable from break-even" in rep.overall.verdict()


def test_a_clear_winner_is_called_profitable():
    rows = [bet("won", 100.0)] * 90 + [bet("lost", -100.0)] * 10
    rep = report(rows)
    assert rep.overall.significant
    assert rep.overall.roi_low > 0
    assert "profitable" in rep.overall.verdict()


def test_a_clear_loser_is_called_losing():
    rows = [bet("won", 100.0)] * 10 + [bet("lost", -100.0)] * 90
    rep = report(rows)
    assert rep.overall.significant
    assert rep.overall.roi_high < 0
    assert "losing" in rep.overall.verdict()


def test_the_interval_narrows_with_more_bets():
    small = report([bet("won", 100.0), bet("lost", -100.0)] * 25).overall
    large = report([bet("won", 100.0), bet("lost", -100.0)] * 250).overall
    assert (large.roi_high - large.roi_low) < (small.roi_high - small.roi_low)


def test_one_bet_has_an_infinite_standard_error():
    assert report([bet("won", 100.0)]).overall.standard_error == float("inf")


def test_the_evidence_bar_matches_the_rest_of_the_engine():
    from overlay_engine.calibrate import MIN_GRADED

    assert MIN_BETS == MIN_GRADED == 30


# ------------------------------------------------------- flat vs money ROI


def test_flat_and_money_roi_agree_on_level_stakes():
    rep = report([bet("won", 100.0), bet("lost", -100.0), bet("won", 100.0)])
    assert rep.overall.flat_return == pytest.approx(rep.overall.roi)
    assert rep.staking_effect == pytest.approx(0.0)


def test_good_sizing_shows_as_a_positive_staking_effect():
    """Bigger bets landing more often than smaller ones. The only direct read
    on whether the Kelly sizing is working."""
    rows = [bet("won", 500.0, stake=500.0), bet("lost", -50.0, stake=50.0)]
    rep = report(rows)
    assert rep.overall.roi > rep.overall.flat_return
    assert rep.staking_effect > 0


def test_bad_sizing_shows_as_a_negative_staking_effect():
    rows = [bet("lost", -500.0, stake=500.0), bet("won", 50.0, stake=50.0)]
    rep = report(rows)
    assert rep.overall.roi < rep.overall.flat_return
    assert rep.staking_effect < 0


# ------------------------------------------------------------ segmentation


def test_the_record_breaks_down_by_sport_book_and_market():
    rows = [bet("won", 100.0, sport="nfl", book="dk", market="h2h"),
            bet("lost", -100.0, sport="nba", book="fd", market="totals")]
    rep = report(rows)
    assert {s.label for s in rep.by_sport} == {"nfl", "nba"}
    assert {s.label for s in rep.by_book} == {"dk", "fd"}
    assert {s.label for s in rep.by_market} == {"h2h", "totals"}


def test_odds_are_bucketed_not_split_per_price():
    rows = [bet("won", 40.0, decimal=1.4), bet("lost", -100.0, decimal=5.0)]
    labels = {s.label for s in report(rows).by_odds}
    assert "heavy favourite (under -200)" in labels
    assert "longshot (+200 to +500)" in labels


def test_segments_are_ordered_by_size():
    rows = [bet("won", 100.0, sport="nfl")] * 10 + [bet("won", 100.0, sport="nba")]
    assert report(rows).by_sport[0].label == "nfl"


def test_leaks_need_a_sample_before_they_are_flagged():
    """With enough slices something always looks bad. A screen that flags
    'you lose on Tuesday night hockey' from nine bets is manufacturing a
    pattern."""
    rows = ([bet("won", 100.0, sport="nfl")] * 60
            + [bet("lost", -100.0, sport="nba")] * 5)
    rep = report(rows)
    assert [s.label for s in rep.leaks()] == []


def test_a_real_leak_is_flagged():
    rows = ([bet("won", 100.0, sport="nfl")] * 60
            + [bet("lost", -100.0, sport="nba")] * 60)
    assert "nba" in [s.label for s in report(rows).leaks()]


# ------------------------------------------------------------- the ledger


def test_settled_bets_require_payment_not_just_a_closing_line(db):
    """A bet can be CLV-graded long before it is paid out; counting an unpaid
    bet as zero profit drags every ROI toward nothing."""
    bet_id = place(db, 0)
    db.settle(bet_id, closing_fair_prob=0.50)
    assert db.graded_bets()
    assert db.settled_bets() == []


def test_filters_narrow_the_record(db):
    place(db, 0, sport="nfl", book="dk", result="won", profit=100.0)
    place(db, 1, sport="nba", book="fd", result="lost", profit=-100.0,
          decimal=5.0)
    assert len(db.settled_bets(sport="nfl")) == 1
    assert len(db.settled_bets(book="fd")) == 1
    assert len(db.settled_bets(min_decimal=3.0)) == 1
    assert len(db.settled_bets(since=1001.0)) == 1
    assert len(db.settled_bets(until=1000.5)) == 1
    assert len(db.settled_bets()) == 2


def test_from_ledger_reads_the_whole_record(db):
    for i in range(40):
        place(db, i, result="won" if i % 2 else "lost",
              profit=100.0 if i % 2 else -100.0)
    rep = from_ledger(db)
    assert rep.overall.n == 40
    assert rep.overall.profit == pytest.approx(0.0)


def test_an_unknown_result_is_refused(db):
    bet_id = place(db, 0)
    with pytest.raises(LedgerError, match="unknown result"):
        db.settle(bet_id, closing_fair_prob=0.5, result="kind-of-won")


def test_won_still_implies_the_result(db):
    """Older callers pass `won=` and no result; the two must not disagree."""
    bet_id = place(db, 0)
    db.settle(bet_id, closing_fair_prob=0.5, won=True, profit=100.0)
    assert db.settled_bets()[0]["result"] == "won"


def test_a_pre_v6_row_is_classified_by_the_sign_of_its_profit():
    """A settled bet with a known profit is real money whether or not anyone
    labelled the outcome."""
    rows = [bet(None, 100.0), bet(None, -100.0), bet(None, 0.0)]
    rep = report(rows)
    assert rep.overall.won == 1
    assert rep.overall.lost == 1
    assert rep.overall.push == 1


def test_a_v5_database_migrates_to_v6(tmp_path):
    from overlay_engine.ledger import SCHEMA_VERSION

    path = tmp_path / "v5.db"
    with Ledger(path) as db:
        place(db, 0, result="won", profit=100.0)
        db.conn.execute("ALTER TABLE bets DROP COLUMN result")
        db.conn.execute("UPDATE meta SET value = '5' WHERE key = 'schema_version'")
        db.conn.commit()

    with Ledger(path) as db:
        assert db._has_column("bets", "result")
        assert len(db.settled_bets()) == 1
        row = db.conn.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        assert int(row["value"]) == SCHEMA_VERSION


# ---------------------------------------------------------------- export


def test_csv_has_a_fixed_header():
    """An export whose columns move between versions breaks every spreadsheet
    built on it."""
    text = to_csv([bet("won", 100.0)])
    assert text.splitlines()[0] == ",".join(CSV_COLUMNS)


def test_csv_writes_a_row_per_bet():
    text = to_csv([bet("won", 100.0), bet("lost", -100.0)])
    assert len(text.strip().splitlines()) == 3


def test_csv_leaves_missing_values_empty_not_none():
    row = bet("won", 100.0)
    row["closing_fair_prob"] = None
    line = to_csv([row]).splitlines()[1]
    assert "None" not in line
    assert ",," in line


def test_csv_quotes_a_value_containing_a_comma():
    row = bet("won", 100.0)
    row["outcome"] = "over 2.5, first half"
    assert '"over 2.5, first half"' in to_csv([row])


def test_an_empty_export_is_still_a_valid_file():
    assert to_csv([]) == ",".join(CSV_COLUMNS) + "\n"
