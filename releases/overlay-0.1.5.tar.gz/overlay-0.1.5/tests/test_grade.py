"""Grading against recorded closing lines — mostly, what it refuses to grade."""

import pytest

from overlay_engine.grade import GradeReport, Skip, closing_fair_prob, grade_pending
from overlay_engine.ledger import AtBet, Ledger
from overlay_engine.models import Book, BookTier, Market, Outcome, Quote

PIN = Book("pinnacle", "Pinnacle", BookTier.SHARP, limits_winners=False)
CIRCA = Book("circa", "Circa", BookTier.SHARP, limits_winners=False)
KALSHI = Book("kalshi", "Kalshi", BookTier.EXCHANGE, limits_winners=False)
DK = Book("dk", "DraftKings", BookTier.RETAIL)
FD = Book("fd", "FanDuel", BookTier.RETAIL)
BOOKS = {b.key: b for b in (PIN, CIRCA, KALSHI, DK, FD)}


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "grade.db") as ledger:
        yield ledger


def bet(db, outcome="home", market="h2h", event="e1", **over):
    args = dict(
        event_id=event, sport="nfl", market_type=market, outcome=outcome,
        book="dk", decimal_odds=2.10, stake=100.0, placed_at=1000.0,
        at_bet=AtBet(fair_prob=0.50, fair_low=0.48, fair_high=0.52,
                     devig={"power": 0.50, "shin": 0.50,
                            "additive": 0.50, "multiplicative": 0.50}),
    )
    args.update(over)
    return db.record_bet(**args)


def close(db, book, prices, event="e1", market="h2h", seen_at=9000.0):
    for outcome, decimal in prices.items():
        db.record_quote(event_id=event, sport="nfl", market_type=market,
                        outcome=outcome, book=book, decimal_odds=decimal,
                        seen_at=seen_at, is_closing=True)


# --------------------------------------------------------- closing_fair_prob


def test_a_complete_sharp_close_devigs():
    prob, source = closing_fair_prob(
        {"pinnacle": {"home": 1.95, "away": 1.95}}, "home", BOOKS)
    assert prob == pytest.approx(0.5, abs=1e-9)
    assert source == "pinnacle"


def test_the_sharpest_available_book_is_used():
    prob, source = closing_fair_prob(
        {"dk": {"home": 2.20, "away": 1.70},
         "pinnacle": {"home": 1.95, "away": 1.95}},
        "home", BOOKS)
    assert source == "pinnacle"
    assert prob == pytest.approx(0.5, abs=1e-9)


def test_an_exchange_close_is_acceptable_truth():
    _, source = closing_fair_prob(
        {"dk": {"home": 2.20, "away": 1.70},
         "kalshi": {"home": 2.00, "away": 2.00}},
        "home", BOOKS)
    assert source == "kalshi"


def test_a_sharp_book_outranks_an_exchange():
    _, source = closing_fair_prob(
        {"kalshi": {"home": 2.00, "away": 2.00},
         "circa": {"home": 1.95, "away": 1.95}},
        "home", BOOKS)
    assert source == "circa"


def test_book_choice_is_deterministic_within_a_tier():
    """Two sharp books both priced it; the same one must win every run, or
    grading is non-reproducible and CLV drifts between passes."""
    closing = {"pinnacle": {"home": 1.95, "away": 1.95},
               "circa": {"home": 1.97, "away": 1.93}}
    picks = {closing_fair_prob(closing, "home", BOOKS)[1] for _ in range(5)}
    assert picks == {"circa"}


def test_a_retail_only_close_is_refused_by_default():
    """A soft book's close is not truth — it is the last price it was willing
    to offer recreational money. Graded against it, a bet that beat a soft book
    scores as beating 'the market'."""
    prob, reason = closing_fair_prob(
        {"dk": {"home": 2.20, "away": 1.70}}, "home", BOOKS)
    assert prob is None
    assert reason == "no sharp or exchange close"


def test_a_retail_close_can_be_allowed_explicitly():
    prob, source = closing_fair_prob(
        {"dk": {"home": 2.20, "away": 1.70}}, "home", BOOKS,
        require_anchor=False)
    assert prob is not None
    assert source == "dk"


def test_books_are_never_mixed():
    """One book's over and another's under is the arbitrage between them
    laundered into a probability — a price no book ever offered."""
    prob, reason = closing_fair_prob(
        {"pinnacle": {"home": 1.95}, "circa": {"away": 1.95}}, "home", BOOKS)
    assert prob is None
    assert reason == "no book priced the full market at close"


def test_a_moved_line_is_refused_not_approximated():
    """over 220.5 and over 221.5 are different bets. This fires often on
    totals, and that is the point."""
    prob, reason = closing_fair_prob(
        {"pinnacle": {"over@221.5": 1.95, "under@221.5": 1.95}},
        "over@220.5", BOOKS)
    assert prob is None
    assert "line moved" in reason


def test_no_closing_quotes_at_all():
    prob, reason = closing_fair_prob({}, "home", BOOKS)
    assert prob is None
    assert reason == "no closing quotes"


def test_an_unknown_book_cannot_anchor():
    prob, reason = closing_fair_prob(
        {"mystery": {"home": 1.95, "away": 1.95}}, "home", BOOKS)
    assert prob is None
    assert reason == "no sharp or exchange close"


def test_an_undeviggable_close_is_reported_not_crashed():
    """A closing market quoting an arb against itself is a stale capture, not
    a gift, and it must not take the grading pass down with it."""
    prob, reason = closing_fair_prob(
        {"pinnacle": {"home": 2.10, "away": 2.10}}, "home", BOOKS)
    if prob is None:
        assert "devig" in reason
    else:
        assert 0.0 < prob < 1.0


def test_calibrated_weights_reach_the_closing_devig():
    """Grading must use the same weights the engine uses, or CLV is measured
    against a blend nothing else computes."""
    closing = {"pinnacle": {"home": 1.69, "away": 2.25}}
    a, _ = closing_fair_prob(closing, "home", BOOKS,
                             method_weights={"power": 1.0})
    b, _ = closing_fair_prob(closing, "home", BOOKS,
                             method_weights={"multiplicative": 1.0})
    assert a != pytest.approx(b)


# ------------------------------------------------------------ grade_pending


def test_a_bet_is_graded_from_a_recorded_close(db):
    bet_id = bet(db)
    close(db, "pinnacle", {"home": 1.95, "away": 1.95})
    report = grade_pending(db, BOOKS)

    assert report.graded == 1
    assert report.skipped == []
    graded = db.graded_bets()
    assert len(graded) == 1
    assert graded[0].closing_fair_prob == pytest.approx(0.5, abs=1e-9)


def test_grading_computes_clv_the_bet_could_not_have_known(db):
    """The whole point: a bet at +110 against a 50% close beat the market by
    5%, and nobody had to work that out by hand."""
    bet(db, decimal_odds=2.10)
    close(db, "pinnacle", {"home": 1.95, "away": 1.95})
    grade_pending(db, BOOKS)
    assert db.graded_bets()[0].clv == pytest.approx(0.05, abs=1e-9)


def test_grading_is_idempotent(db):
    """This runs on a schedule. A grader that re-settles would rewrite history
    every time a later quote arrived."""
    bet(db)
    close(db, "pinnacle", {"home": 1.95, "away": 1.95})
    assert grade_pending(db, BOOKS).graded == 1
    second = grade_pending(db, BOOKS)
    assert second.graded == 0
    assert second.attempted == 0
    assert len(db.graded_bets()) == 1


def test_ungradeable_bets_are_reported_not_dropped(db):
    """A grader that silently skips is indistinguishable from one that has
    nothing to do."""
    bet_id = bet(db)
    report = grade_pending(db, BOOKS)
    assert report.graded == 0
    assert report.skipped == [Skip(bet_id=bet_id, reason="no closing quotes")]
    assert db.stats()["ungraded"] == 1


def test_a_skipped_bet_stays_available_for_a_later_pass(db):
    """Capture is asynchronous; a bet ungradeable this hour is gradeable once
    its close lands."""
    bet(db)
    assert grade_pending(db, BOOKS).graded == 0
    close(db, "pinnacle", {"home": 1.95, "away": 1.95})
    assert grade_pending(db, BOOKS).graded == 1


def test_only_closing_quotes_count(db):
    """A mid-market quote is not a close, and grading against one would make
    every early bet look like it beat a line that had not settled."""
    bet(db)
    db.record_quote(event_id="e1", sport="nfl", market_type="h2h",
                    outcome="home", book="pinnacle", decimal_odds=1.95)
    db.record_quote(event_id="e1", sport="nfl", market_type="h2h",
                    outcome="away", book="pinnacle", decimal_odds=1.95)
    report = grade_pending(db, BOOKS)
    assert report.graded == 0
    assert report.skipped[0].reason == "no closing quotes"


def test_grading_matches_on_event_and_market_not_just_event(db):
    """A close on the moneyline cannot grade a bet on the total."""
    bet(db, market="totals", outcome="over@220.5")
    close(db, "pinnacle", {"home": 1.95, "away": 1.95}, market="h2h")
    report = grade_pending(db, BOOKS)
    assert report.graded == 0
    assert report.skipped[0].reason == "no closing quotes"


def test_a_mixed_batch_grades_what_it_can(db):
    ready = bet(db, event="ready")
    moved = bet(db, event="moved", market="totals", outcome="over@220.5")
    missing = bet(db, event="missing")

    close(db, "pinnacle", {"home": 1.95, "away": 1.95}, event="ready")
    close(db, "pinnacle", {"over@221.5": 1.95, "under@221.5": 1.95},
          event="moved", market="totals")

    report = grade_pending(db, BOOKS)
    assert report.graded == 1
    assert report.attempted == 3
    assert {s.bet_id for s in report.skipped} == {moved, missing}
    assert report.reasons() == {"line moved": 1, "no closing quotes": 1}


def test_the_report_summarises_by_reason(db):
    """Fifty 'line moved' is a fact about totals betting; fifty 'no closing
    quotes' means capture is broken. Those have to look different."""
    for i in range(3):
        bet(db, event=f"e{i}")
    report = grade_pending(db, BOOKS)
    assert report.reasons() == {"no closing quotes": 3}
    assert "graded 0 of 3" in report.describe()


def test_an_empty_ledger_says_so(db):
    assert grade_pending(db, BOOKS).describe() == "nothing to grade"


def test_grading_defaults_to_the_real_catalogue(db):
    """No `books` argument must still resolve tiers, or every close reads as
    UNKNOWN and nothing ever grades."""
    bet(db)
    close(db, "circa", {"home": 1.95, "away": 1.95})
    assert grade_pending(db).graded == 1


def test_grading_feeds_calibration_end_to_end(db):
    """The loop this module exists to close: capture, grade, calibrate — with
    nobody devigging a closing line by hand."""
    from overlay_engine.calibrate import calibrate_methods

    for i in range(40):
        db.record_bet(
            event_id=f"e{i}", sport="nfl", market_type="h2h", outcome="home",
            book="dk", decimal_odds=2.10, stake=100.0, placed_at=1000.0 + i,
            at_bet=AtBet(fair_prob=0.50, fair_low=0.47, fair_high=0.53,
                         devig={"power": 0.5000, "shin": 0.5040,
                                "additive": 0.5200, "multiplicative": 0.5500}),
        )
        close(db, "pinnacle", {"home": 2.00, "away": 2.00}, event=f"e{i}")

    assert grade_pending(db, BOOKS).graded == 40
    result = calibrate_methods(db)
    assert result.accepted
    assert max(result.weights, key=result.weights.get) == "power"


# ----------------------------------------------------------- record_market


def test_record_market_stores_every_quote(db):
    market = Market(
        event_id="e1", sport="nfl", market_type="totals",
        quotes=[
            Quote(book="pinnacle", outcome=Outcome("over", 220.5),
                  decimal=1.95, seen_at=9000.0),
            Quote(book="pinnacle", outcome=Outcome("under", 220.5),
                  decimal=1.95, seen_at=9000.0),
        ],
    )
    assert db.record_market(market, is_closing=True) == 2
    assert db.closing_market("e1", "totals") == {
        "pinnacle": {"over@220.5": 1.95, "under@220.5": 1.95}
    }


def test_recorded_markets_keep_the_line_in_the_outcome_key(db):
    """Without the line, over 220.5 and over 221.5 collapse into one key and
    the moved-line refusal silently stops firing."""
    market = Market(
        event_id="e1", sport="nba", market_type="totals",
        quotes=[Quote(book="circa", outcome=Outcome("over", 221.5),
                      decimal=1.91, seen_at=9000.0)],
    )
    db.record_market(market, is_closing=True)
    assert "over@221.5" in db.closing_market("e1", "totals")["circa"]


def test_a_market_recorded_without_a_bet_is_still_captured(db):
    """Capture covers every market watched. A close observed only where we bet
    is a biased sample of exactly the markets we got wrong."""
    market = Market(
        event_id="unbet", sport="nfl", market_type="h2h",
        quotes=[Quote(book="pinnacle", outcome=Outcome("home"),
                      decimal=1.95, seen_at=9000.0)],
    )
    db.record_market(market, is_closing=True)
    assert db.stats()["bets"] == 0
    assert db.stats()["closing_quotes"] == 1


def test_the_latest_capture_wins_per_book_and_outcome(db):
    close(db, "pinnacle", {"home": 2.00, "away": 2.00}, seen_at=100.0)
    close(db, "pinnacle", {"home": 1.90, "away": 2.10}, seen_at=200.0)
    assert db.closing_market("e1", "h2h")["pinnacle"]["home"] == pytest.approx(1.90)


def test_ungraded_bets_come_back_oldest_first(db):
    late = bet(db, event="late", placed_at=2000.0)
    early = bet(db, event="early", placed_at=1000.0)
    assert [b["id"] for b in db.ungraded_bets()] == [early, late]


def test_ungraded_bets_excludes_settled_ones(db):
    bet_id = bet(db)
    db.settle(bet_id, closing_fair_prob=0.5)
    assert db.ungraded_bets() == []


def test_an_empty_report_has_no_reasons():
    assert GradeReport().reasons() == {}
    assert GradeReport().attempted == 0
