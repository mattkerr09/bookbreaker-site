"""The estimator has to recover a correlation it was given, or it measures
nothing at all."""

import math
import random

import pytest

from overlay_engine.correlation import (
    MAX_RHO,
    MIN_BETS,
    MIN_GROUPS,
    CorrelationError,
    CorrelationEstimate,
    from_ledger,
    measure,
    scale_from_ledger,
)
from overlay_engine.kelly import DEFAULT_CORRELATION, simultaneous_scale

DAY = 86_400.0


def _bets(groups: int, per_group: int, rho: float, seed: int = 1,
          sigma: float = 1.0) -> list[dict]:
    """Synthetic settled bets with a known within-group correlation.

    Each group's returns are `sqrt(rho) * shared + sqrt(1-rho) * idiosyncratic`,
    which has exactly `rho` pairwise correlation by construction. That is what
    makes this a test of the estimator rather than a test of its own output.
    """
    rng = random.Random(seed)
    rows = []
    for g in range(groups):
        shared = rng.gauss(0.0, 1.0)
        for i in range(per_group):
            own = rng.gauss(0.0, 1.0)
            r = sigma * (math.sqrt(rho) * shared + math.sqrt(1.0 - rho) * own)
            rows.append({
                "event_id": f"e{g}", "sport": "nfl",
                "placed_at": g * DAY, "stake": 100.0, "profit": r * 100.0,
            })
    return rows


# ------------------------------------------------------------ recovery

@pytest.mark.parametrize("truth", [0.0, 0.15, 0.4, 0.7])
def test_the_estimator_recovers_a_correlation_it_was_given(truth):
    got = measure(_bets(400, 4, truth, seed=hash(truth) % 1000))
    assert got.measured
    assert got.rho == pytest.approx(truth, abs=0.08)


def test_independent_bets_come_back_near_zero_not_near_the_prior():
    """The prior must not leak into a measured answer."""
    got = measure(_bets(400, 4, 0.0, seed=11))
    assert got.measured
    assert got.rho < 0.1


def test_perfectly_correlated_bets_come_back_near_one():
    got = measure(_bets(400, 4, 0.99, seed=12))
    assert got.rho > 0.8


def test_the_estimate_is_capped_below_one():
    got = measure(_bets(400, 4, 1.0, seed=13))
    assert got.rho <= MAX_RHO


def test_larger_groups_recover_the_same_correlation():
    """The (n-1) weighting has to be right or group size biases the answer."""
    small = measure(_bets(400, 2, 0.4, seed=21))
    large = measure(_bets(200, 8, 0.4, seed=22))
    assert small.rho == pytest.approx(0.4, abs=0.1)
    assert large.rho == pytest.approx(0.4, abs=0.1)


# ------------------------------------------------------------- the floor

def test_a_negative_estimate_is_floored_at_zero():
    """Floored, because a negative rho makes simultaneous_scale exceed 1.0 and
    raise every stake above its independent optimum."""
    rows = []
    for g in range(60):
        for r in (1.0, -1.0):     # perfectly hedged: rho = -1 by construction
            rows.append({"event_id": f"e{g}", "sport": "nfl",
                         "placed_at": g * DAY, "stake": 100.0,
                         "profit": r * 100.0})
    got = measure(rows)
    assert got.rho == 0.0
    assert got.raw is not None and got.raw < 0.0
    assert got.floored


def test_a_floored_estimate_says_so_rather_than_reading_as_a_clean_zero():
    rows = [{"event_id": f"e{g}", "sport": "nfl", "placed_at": g * DAY,
             "stake": 100.0, "profit": r * 100.0}
            for g in range(60) for r in (1.0, -1.0)]
    shown = measure(rows).describe()
    assert "floored at zero" in shown
    assert "raw estimate" in shown


def test_a_floored_correlation_never_scales_a_stake_upward():
    got = measure([{"event_id": f"e{g}", "sport": "nfl", "placed_at": g * DAY,
                    "stake": 100.0, "profit": r * 100.0}
                   for g in range(60) for r in (1.0, -1.0)])
    assert got.scale(12) <= 1.0


# -------------------------------------------------------------- refusal

def test_too_few_bets_returns_the_labelled_prior():
    got = measure(_bets(5, 2, 0.4))
    assert not got.measured
    assert got.rho == DEFAULT_CORRELATION
    assert "PRIOR" in got.describe()


def test_too_few_multi_bet_groups_returns_the_prior_even_with_many_bets():
    """100 bets that never share an event say nothing about correlation."""
    rows = [{"event_id": f"solo{i}", "sport": "nfl", "placed_at": i * DAY,
             "stake": 100.0, "profit": 10.0 * (i % 3 - 1)} for i in range(100)]
    got = measure(rows)
    assert got.bets >= MIN_BETS
    assert got.groups < MIN_GROUPS
    assert not got.measured


def test_zero_variance_returns_the_prior_not_a_correlation_of_zero():
    """Every bet returning the same thing has no variance to inflate, which is
    not the same as having no correlation."""
    rows = [{"event_id": f"e{g}", "sport": "nfl", "placed_at": g * DAY,
             "stake": 100.0, "profit": 5.0}
            for g in range(40) for _ in range(3)]
    got = measure(rows)
    assert not got.measured
    assert got.rho == DEFAULT_CORRELATION


def test_unsettled_bets_are_excluded_rather_than_counted_as_zero():
    rows = _bets(400, 4, 0.4, seed=31)
    for row in rows[:100]:
        row["profit"] = None
    got = measure(rows)
    assert got.bets == len(rows) - 100


def test_a_zero_stake_bet_cannot_divide_the_estimate_by_zero():
    rows = _bets(400, 4, 0.3, seed=32)
    rows[0]["stake"] = 0.0
    assert measure(rows).measured


def test_an_unknown_grouping_key_raises():
    with pytest.raises(CorrelationError, match="unknown grouping key"):
        measure(_bets(40, 2, 0.2), key="phase_of_moon")


# ------------------------------------------------------------- grouping

def test_grouping_by_day_finds_correlation_that_grouping_by_event_cannot():
    """Bets on different games of one slate share weather, pace and news."""
    rng = random.Random(5)
    rows = []
    for d in range(300):
        shared = rng.gauss(0.0, 1.0)
        for i in range(4):
            own = rng.gauss(0.0, 1.0)
            r = math.sqrt(0.5) * shared + math.sqrt(0.5) * own
            rows.append({"event_id": f"d{d}-g{i}", "sport": "nfl",
                         "placed_at": d * DAY, "stake": 100.0,
                         "profit": r * 100.0})
    by_event = measure(rows, key="event")
    by_day = measure(rows, key="day")
    assert not by_event.measured          # every event holds exactly one bet
    assert by_day.measured
    assert by_day.rho == pytest.approx(0.5, abs=0.1)


def test_sport_day_separates_two_sports_on_the_same_date():
    rows = _bets(300, 3, 0.4, seed=41)
    for i, row in enumerate(rows):
        row["sport"] = "nfl" if i % 2 else "nba"
    assert measure(rows, key="sport_day").measured


def test_one_big_bet_beside_small_ones_does_not_hide_their_co_movement():
    """Returns, not dollars — and it is *within* a group that this bites.

    Scaling every bet in a group by the same amount changes nothing: the
    estimator reads a ratio, and a per-group factor cancels between the group
    total and the pooled variance. Measured, not assumed — a record staked at
    $5 on half its groups and $500 on the other half returns the same rho
    either way.

    Mixed stakes inside one group are different. Summing dollars lets the one
    big bet set the group total on its own, so the small bets' co-movement
    stops reaching the sum at all: on this data the estimate falls from 0.48
    to 0.01, reporting a book riding one game script as a diversified one.
    """
    rng = random.Random(7)
    rows = []
    for g in range(600):
        shared = rng.gauss(0.0, 1.0)
        for stake in (500.0, 5.0, 5.0, 5.0):
            r = math.sqrt(0.5) * shared + math.sqrt(0.5) * rng.gauss(0.0, 1.0)
            rows.append({"event_id": f"e{g}", "sport": "nfl",
                         "placed_at": g * DAY, "stake": stake,
                         "profit": r * stake})
    got = measure(rows)
    assert got.measured
    assert got.rho == pytest.approx(0.5, abs=0.1)


def test_scaling_every_stake_in_a_group_leaves_the_estimate_alone():
    """The invariance the test above depends on, pinned separately."""
    def book(stake_for_group):
        rng = random.Random(101)
        rows = []
        for g in range(400):
            shared = rng.gauss(0.0, 1.0)
            for _ in range(4):
                r = math.sqrt(0.5) * shared + math.sqrt(0.5) * rng.gauss(0.0, 1.0)
                st = stake_for_group(g)
                rows.append({"event_id": f"e{g}", "sport": "nfl",
                             "placed_at": g * DAY, "stake": st,
                             "profit": r * st})
        return measure(rows).rho

    flat = book(lambda g: 100.0)
    mixed = book(lambda g: 5.0 if g % 2 else 500.0)
    assert flat == pytest.approx(mixed, abs=1e-9)


# ---------------------------------------------------- feeding the consumer

def test_the_estimate_plugs_straight_into_simultaneous_scale():
    got = measure(_bets(400, 4, 0.4, seed=51))
    assert got.scale(12) == simultaneous_scale(12, got.rho)


def test_a_measured_correlation_changes_the_stake_it_implies():
    """If the measurement did not move the scale, nothing was gained."""
    low = measure(_bets(400, 4, 0.05, seed=61))
    high = measure(_bets(400, 4, 0.7, seed=62))
    assert high.scale(12) < low.scale(12)


def test_one_live_bet_is_never_shrunk_whatever_the_correlation():
    assert measure(_bets(400, 4, 0.9, seed=71)).scale(1) == 1.0


def test_a_prior_estimate_reproduces_the_previous_default_behaviour():
    """Nothing regresses for a user with no record yet."""
    got = measure([])
    assert got.scale(12) == simultaneous_scale(12, DEFAULT_CORRELATION)


# ------------------------------------------------------------- the ledger

def test_from_ledger_reads_settled_bets(tmp_path):
    from overlay_engine.ledger import Ledger

    with Ledger(str(tmp_path / "t.db")) as db:
        for i, row in enumerate(_bets(30, 3, 0.4, seed=81)):
            db.import_bet(
                event_id=row["event_id"], sport="nfl", market_type="h2h",
                outcome="home", book="dk", decimal_odds=2.0,
                stake=row["stake"], placed_at=row["placed_at"],
                result="won" if row["profit"] > 0 else "lost",
                profit=row["profit"], external_ref=f"r{i}")
        got = from_ledger(db)
        scale, same = scale_from_ledger(db, 12)
    assert got.measured
    assert scale == same.scale(12)


def test_describe_never_presents_a_prior_as_a_measurement():
    assert "PRIOR" in CorrelationEstimate(rho=0.15, provenance="prior").describe()
    assert "PRIOR" not in measure(_bets(400, 4, 0.3, seed=91)).describe()
