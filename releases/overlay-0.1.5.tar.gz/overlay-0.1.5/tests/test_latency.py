"""Quote provenance and feed latency — the floor under every fill probability."""

import pytest

from overlay_engine.ev import find_edges
from overlay_engine.ledger import SCHEMA_VERSION, Ledger, LedgerError
from overlay_engine.models import Book, BookTier, Market, Outcome, Quote
from overlay_engine.staleness import (
    LATENCY_PRIOR_STRENGTH,
    PRIOR_LATENCY,
    FillModel,
    LatencyModel,
)

PIN = Book("pinnacle", "Pinnacle", BookTier.SHARP, limits_winners=False)
DK = Book("dk", "DraftKings", BookTier.RETAIL)
FD = Book("fd", "FanDuel", BookTier.RETAIL)
BOOKS = {b.key: b for b in (PIN, DK, FD)}


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "lat.db") as ledger:
        yield ledger


# ------------------------------------------------------------ quote metadata


def test_latency_is_the_gap_between_the_book_and_us():
    q = Quote(book="dk", outcome=Outcome("home"), decimal=2.0,
              seen_at=1000.0, fetched_at=1008.0)
    assert q.latency == pytest.approx(8.0)
    assert q.provenance == "measured"


def test_an_undated_quote_has_unknown_latency_not_zero():
    q = Quote(book="dk", outcome=Outcome("home"), decimal=2.0, seen_at=1000.0)
    assert q.latency is None
    assert q.provenance == "assumed"


def test_a_feed_clock_running_ahead_cannot_produce_negative_latency():
    """It would credit the quote with being fresher than live."""
    q = Quote(book="dk", outcome=Outcome("home"), decimal=2.0,
              seen_at=1000.0, fetched_at=995.0)
    assert q.latency == 0.0
    assert q.provenance == "assumed"


def test_age_is_measured_from_the_book_not_from_our_fetch():
    """The whole point. Measuring from `fetched_at` understates age by exactly
    the latency and so overstates the chance of getting the bet down."""
    q = Quote(book="dk", outcome=Outcome("home"), decimal=2.0,
              seen_at=1000.0, fetched_at=1008.0)
    assert q.age(now=1010.0) == pytest.approx(10.0)
    assert q.age(now=1010.0) != pytest.approx(2.0)


def test_a_measured_quote_does_not_get_the_floor_added_twice():
    """Its latency is already inside `now - seen_at`."""
    q = Quote(book="dk", outcome=Outcome("home"), decimal=2.0,
              seen_at=1000.0, fetched_at=1008.0)
    assert q.age(now=1010.0, latency_floor=5.0) == pytest.approx(10.0)


def test_an_assumed_quote_gets_the_floor_added():
    """The true age is at least this much larger than we can see."""
    q = Quote(book="dk", outcome=Outcome("home"), decimal=2.0, seen_at=1000.0)
    assert q.age(now=1010.0) == pytest.approx(10.0)
    assert q.age(now=1010.0, latency_floor=5.0) == pytest.approx(15.0)


def test_age_still_never_goes_negative():
    q = Quote(book="dk", outcome=Outcome("home"), decimal=2.0, seen_at=1000.0)
    assert q.age(now=990.0) == 0.0


# ------------------------------------------------------------ latency model


def test_the_model_starts_at_a_stated_prior():
    """Not zero: every feed has some delay, and assuming none is the
    assumption that makes fill probability too optimistic."""
    model = LatencyModel()
    assert model.typical("dk") == PRIOR_LATENCY
    assert PRIOR_LATENCY > 0
    assert not model.is_measured("dk")


def test_observations_move_it_off_the_prior():
    model = LatencyModel()
    for _ in range(40):
        model.observe("dk", 9.0)
    assert PRIOR_LATENCY < model.typical("dk") < 9.0
    assert model.is_measured("dk")


def test_the_shrinkage_is_the_documented_formula():
    """Pinned rather than approximated. Two tests here guessed a tolerance and
    failed against a model that was behaving exactly as written."""
    model = LatencyModel()
    for _ in range(40):
        model.observe("dk", 9.0)
    w = 40 / (40 + LATENCY_PRIOR_STRENGTH)
    assert model.typical("dk") == pytest.approx(w * 9.0 + (1 - w) * PRIOR_LATENCY)


def test_more_evidence_moves_it_closer_to_what_was_observed():
    few, many = LatencyModel(), LatencyModel()
    for _ in range(5):
        few.observe("dk", 12.0)
    for _ in range(500):
        many.observe("dk", 12.0)
    assert abs(many.typical("dk") - 12.0) < abs(few.typical("dk") - 12.0)


def test_a_tiny_sample_stays_near_the_prior():
    model = LatencyModel()
    model.observe("dk", 30.0)
    assert model.typical("dk") < 10.0


def test_books_are_measured_separately():
    model = LatencyModel()
    for _ in range(30):
        model.observe("dk", 12.0)
    assert model.typical("dk") > model.typical("pinnacle")


def test_negative_latency_is_refused():
    with pytest.raises(ValueError):
        LatencyModel().observe("dk", -1.0)


def test_observing_a_quote_reports_whether_it_could():
    model = LatencyModel()
    dated = Quote(book="dk", outcome=Outcome("home"), decimal=2.0,
                  seen_at=1000.0, fetched_at=1004.0)
    undated = Quote(book="dk", outcome=Outcome("home"), decimal=2.0, seen_at=1000.0)
    assert model.observe_quote(dated) is True
    assert model.observe_quote(undated) is False
    assert model.observations("dk") == 1


def test_the_model_round_trips():
    model = LatencyModel()
    for _ in range(10):
        model.observe("dk", 6.0)
    restored = LatencyModel.from_dict(model.to_dict())
    assert restored.typical("dk") == pytest.approx(model.typical("dk"))


def test_an_empty_dict_restores_to_priors():
    assert LatencyModel.from_dict({}).typical("dk") == PRIOR_LATENCY


# ------------------------------------------------------- effect on the screen


def _market(seen_at, fetched_at=None):
    prices = [("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95),
              ("dk", "home", 2.20), ("dk", "away", 1.70)]
    return Market(
        event_id="e1", sport="nfl", market_type="h2h",
        quotes=[
            Quote(book=b, outcome=Outcome(n), decimal=d,
                  seen_at=seen_at, fetched_at=fetched_at)
            for b, n, d in prices
        ],
    )


def test_latency_lowers_fill_probability_on_an_undated_feed():
    """A quote that arrived stale is older than it looks, and the fill
    probability has to say so."""
    market = _market(seen_at=1000.0)
    fills = FillModel()

    slow = LatencyModel()
    for _ in range(30):
        slow.observe("dk", 20.0)

    without = find_edges(market, BOOKS, now=1010.0, fill_model=fills)[0]
    with_latency = find_edges(market, BOOKS, now=1010.0, fill_model=fills,
                              latency_model=slow)[0]
    assert with_latency.quote_age > without.quote_age
    assert with_latency.p_fill < without.p_fill
    assert with_latency.realised_ev < without.realised_ev


def test_a_dated_feed_is_not_penalised_twice():
    """Its latency is already in the age; adding the model's estimate again
    would understate fill on exactly the feeds that reported honestly."""
    market = _market(seen_at=1000.0, fetched_at=1004.0)
    fills = FillModel()
    slow = LatencyModel()
    for _ in range(30):
        slow.observe("dk", 20.0)

    plain = find_edges(market, BOOKS, now=1010.0, fill_model=fills)[0]
    modelled = find_edges(market, BOOKS, now=1010.0, fill_model=fills,
                          latency_model=slow)[0]
    assert modelled.quote_age == pytest.approx(plain.quote_age)


def test_the_dated_feed_still_shows_the_full_age():
    """10 seconds since the book set it, of which 4 were the feed's."""
    market = _market(seen_at=1000.0, fetched_at=1004.0)
    edge = find_edges(market, BOOKS, now=1010.0, fill_model=FillModel())[0]
    assert edge.quote_age == pytest.approx(10.0)


def test_arbitrage_ages_account_for_latency():
    from overlay_engine.arb import find_arbs

    market = Market(
        event_id="e1", sport="nfl", market_type="h2h",
        quotes=[
            Quote(book="dk", outcome=Outcome("home"), decimal=2.10, seen_at=1000.0),
            Quote(book="pinnacle", outcome=Outcome("away"), decimal=2.05, seen_at=1000.0),
        ],
    )
    slow = LatencyModel()
    for _ in range(30):
        slow.observe("dk", 15.0)

    plain = find_arbs(market, BOOKS, now=1010.0)[0]
    modelled = find_arbs(market, BOOKS, now=1010.0, latency_model=slow)[0]
    assert modelled["max_age"] > plain["max_age"]


# ------------------------------------------------------------------ storage


def test_the_schema_stores_both_timestamps(db):
    """Third time a test has broken on a hard-coded schema number. The
    behaviour under test is the two timestamps, not the version they arrived
    in, so the version assertion is gone rather than bumped again."""
    db.record_quote(event_id="e1", sport="nfl", market_type="h2h",
                    outcome="home", book="dk", decimal_odds=2.0,
                    seen_at=1000.0, fetched_at=1006.0)
    model = db.latency_model()
    assert model.observations("dk") == 1
    assert model.typical("dk") > PRIOR_LATENCY


def test_a_v2_database_migrates_to_v3(tmp_path):
    path = tmp_path / "v2.db"
    with Ledger(path) as db:
        db.record_quote(event_id="e1", sport="nfl", market_type="h2h",
                        outcome="home", book="dk", decimal_odds=2.0,
                        seen_at=1000.0)
        db.conn.execute("ALTER TABLE quotes DROP COLUMN fetched_at")
        db.conn.execute("UPDATE meta SET value = '2' WHERE key = 'schema_version'")
        db.conn.commit()

    with Ledger(path) as db:
        assert db._has_column("quotes", "fetched_at")
        assert db.stats()["quotes"] == 1
        row = db.conn.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        assert int(row["value"]) == SCHEMA_VERSION


def test_a_v1_database_migrates_all_the_way_to_v3(tmp_path):
    """Skipping a version is the normal case for anyone who did not upgrade
    every week, so the chain has to run, not just the last step."""
    path = tmp_path / "v1.db"
    with Ledger(path) as db:
        db.record_quote(event_id="e1", sport="nfl", market_type="h2h",
                        outcome="home", book="dk", decimal_odds=2.0, seen_at=1000.0)
        db.conn.execute("ALTER TABLE bets DROP COLUMN book_probs")
        db.conn.execute("ALTER TABLE quotes DROP COLUMN fetched_at")
        db.conn.execute("UPDATE meta SET value = '1' WHERE key = 'schema_version'")
        db.conn.commit()

    with Ledger(path) as db:
        assert db._has_column("bets", "book_probs")
        assert db._has_column("quotes", "fetched_at")
        assert db.stats()["quotes"] == 1


def test_quotes_without_a_fetch_time_contribute_nothing(db):
    """Unknown latency is not zero latency, and averaging in a zero would drag
    every book's estimate toward 'instant'."""
    for i in range(10):
        db.record_quote(event_id=f"e{i}", sport="nfl", market_type="h2h",
                        outcome="home", book="dk", decimal_odds=2.0,
                        seen_at=1000.0)
    model = db.latency_model()
    assert model.observations("dk") == 0
    assert model.typical("dk") == PRIOR_LATENCY


def test_a_fetch_before_the_book_set_the_price_is_refused(db):
    """A price cannot reach us before the book set it. Storing it would put a
    negative latency in the record."""
    with pytest.raises(LedgerError, match="precedes"):
        db.record_quote(event_id="e1", sport="nfl", market_type="h2h",
                        outcome="home", book="dk", decimal_odds=2.0,
                        seen_at=1000.0, fetched_at=990.0)


def test_record_market_carries_provenance_through(db):
    market = _market(seen_at=1000.0, fetched_at=1007.0)
    db.record_market(market)
    model = db.latency_model()
    assert model.observations("dk") == 2
    assert model.typical("dk") > PRIOR_LATENCY


def test_the_latency_model_survives_a_reopen(tmp_path):
    path = tmp_path / "reopen.db"
    with Ledger(path) as db:
        for i in range(20):
            db.record_quote(event_id=f"e{i}", sport="nfl", market_type="h2h",
                            outcome="home", book="dk", decimal_odds=2.0,
                            seen_at=1000.0, fetched_at=1011.0)
    with Ledger(path) as db:
        w = 20 / (20 + LATENCY_PRIOR_STRENGTH)
        assert db.latency_model().typical("dk") == pytest.approx(
            w * 11.0 + (1 - w) * PRIOR_LATENCY
        )
