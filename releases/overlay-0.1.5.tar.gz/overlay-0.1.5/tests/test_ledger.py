"""The ledger: what it stores, and what it refuses to store."""

import json
import time

import pytest

from overlay_engine.clv import method_scores, report
from overlay_engine.ledger import AtBet, Ledger, LedgerError, SCHEMA_VERSION, home


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "test.db") as ledger:
        yield ledger


def good_at_bet(**over) -> AtBet:
    base = dict(
        fair_prob=0.52,
        fair_low=0.505,
        fair_high=0.535,
        devig={"multiplicative": 0.519, "additive": 0.521,
               "power": 0.520, "shin": 0.520},
        p_fill=0.94,
        heat=0.12,
    )
    base.update(over)
    return AtBet(**base)


def place(db, **over) -> int:
    args = dict(
        event_id="e1", sport="nfl", market_type="h2h", outcome="home",
        book="dk", decimal_odds=2.05, stake=100.0, at_bet=good_at_bet(),
        placed_at=1000.0,
    )
    args.update(over)
    return db.record_bet(**args)


# ------------------------------------------------------------------ basics


def test_a_fresh_database_stamps_its_schema_version(tmp_path):
    with Ledger(tmp_path / "new.db") as db:
        row = db.conn.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'"
        ).fetchone()
        assert int(row["value"]) == SCHEMA_VERSION


def test_reopening_preserves_the_record(tmp_path):
    path = tmp_path / "persist.db"
    with Ledger(path) as db:
        place(db)
    with Ledger(path) as db:
        assert db.stats()["bets"] == 1


def test_a_newer_schema_is_refused_rather_than_written_to(tmp_path):
    """An older build writing rows a newer one cannot read back is the one
    corruption no backup helps with."""
    path = tmp_path / "future.db"
    with Ledger(path) as db:
        db.conn.execute("UPDATE meta SET value = ? WHERE key = 'schema_version'",
                        (str(SCHEMA_VERSION + 1),))
        db.conn.commit()
    with pytest.raises(LedgerError, match="newer Overlay"):
        Ledger(path)


def test_overlay_home_relocates_the_database(monkeypatch, tmp_path):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path / "elsewhere"))
    assert home() == tmp_path / "elsewhere"


def test_the_default_home_is_a_dotfolder(monkeypatch):
    monkeypatch.delenv("OVERLAY_HOME", raising=False)
    assert home().name == ".overlay"


# -------------------------------------------------- the load-bearing refusal


def test_a_bet_without_its_devig_spread_is_refused():
    """The invariant the whole schema is shaped around. Calibration asks which
    method predicted the close; that is unanswerable later from a fair
    probability alone, and an empty dict stores perfectly happily."""
    with pytest.raises(LedgerError, match="devig spread"):
        good_at_bet(devig={}).validate()


def test_record_bet_enforces_it(db):
    with pytest.raises(LedgerError, match="devig spread"):
        place(db, at_bet=good_at_bet(devig={}))
    assert db.stats()["bets"] == 0


def test_a_band_that_does_not_contain_its_own_midpoint_is_refused(db):
    """Stores fine as three floats; means nothing as an interval."""
    with pytest.raises(LedgerError, match="does not"):
        place(db, at_bet=good_at_bet(fair_low=0.55, fair_high=0.60))


@pytest.mark.parametrize("prob", [0.0, 1.0, -0.1, 1.4])
def test_an_impossible_fair_probability_is_refused(db, prob):
    with pytest.raises(LedgerError, match="fair_prob"):
        place(db, at_bet=good_at_bet(fair_prob=prob, fair_low=0.0, fair_high=1.0))


def test_an_impossible_devig_entry_is_refused(db):
    with pytest.raises(LedgerError, match="power"):
        place(db, at_bet=good_at_bet(devig={"power": 0.0}))


@pytest.mark.parametrize("field,value", [("p_fill", 1.4), ("heat", -0.2)])
def test_out_of_range_model_state_is_refused(db, field, value):
    with pytest.raises(LedgerError):
        place(db, at_bet=good_at_bet(**{field: value}))


def test_impossible_odds_and_stakes_are_refused(db):
    with pytest.raises(LedgerError, match="decimal odds"):
        place(db, decimal_odds=1.0)
    with pytest.raises(LedgerError, match="stake"):
        place(db, stake=0.0)


def test_at_bet_is_keyword_only_with_no_default(db):
    """A caller who has not got the model state must fail loudly, not write a
    row that looks fine and trains nothing."""
    with pytest.raises(TypeError):
        db.record_bet(
            event_id="e1", sport="nfl", market_type="h2h", outcome="home",
            book="dk", decimal_odds=2.05, stake=100.0,
        )


# ------------------------------------------------------------------ writing


def test_a_bet_round_trips_with_its_model_state(db):
    bet_id = place(db)
    spread = db.devig_at_bet(bet_id)
    assert spread["power"] == pytest.approx(0.520)
    assert set(spread) == {"multiplicative", "additive", "power", "shin"}


def test_devig_is_stored_as_sorted_json(db):
    """Stable ordering so two identical bets produce identical rows — a diff
    that flags on key order is a diff nobody reads."""
    bet_id = place(db)
    raw = db.conn.execute("SELECT devig_json FROM bets WHERE id = ?",
                          (bet_id,)).fetchone()["devig_json"]
    assert raw == json.dumps(json.loads(raw), sort_keys=True)


def test_devig_at_bet_rejects_an_unknown_id(db):
    with pytest.raises(LedgerError, match="no bet"):
        db.devig_at_bet(999)


def test_attempts_record_both_outcomes(db):
    db.record_attempt(book="dk", market_type="h2h", quote_age=3.0, accepted=True)
    db.record_attempt(book="dk", market_type="h2h", quote_age=40.0, accepted=False)
    stats = db.stats()
    assert stats["attempts"] == 2
    assert stats["rejected"] == 1


def test_a_negative_quote_age_is_refused(db):
    with pytest.raises(LedgerError, match="negative"):
        db.record_attempt(book="dk", market_type="h2h", quote_age=-1.0,
                          accepted=True)


def test_an_attempt_can_be_tied_to_its_bet(db):
    bet_id = place(db)
    attempt = db.record_attempt(book="dk", market_type="h2h", quote_age=2.0,
                                accepted=True, bet_id=bet_id)
    row = db.conn.execute("SELECT bet_id FROM attempts WHERE id = ?",
                          (attempt,)).fetchone()
    assert row["bet_id"] == bet_id


def test_closing_quotes_are_captured_without_a_bet(db):
    """A closing line only observed on markets we bet is a biased sample of
    exactly the markets we were wrong about."""
    db.record_quote(event_id="e9", sport="nfl", market_type="h2h",
                    outcome="home", book="pinnacle", decimal_odds=1.95,
                    is_closing=True)
    assert db.stats()["bets"] == 0
    assert db.stats()["closing_quotes"] == 1
    assert db.closing_price("e9", "h2h", "home") == pytest.approx(1.95)


def test_the_latest_closing_price_wins(db):
    for seen, price in ((100.0, 2.00), (200.0, 1.90)):
        db.record_quote(event_id="e1", sport="nfl", market_type="h2h",
                        outcome="home", book="pinnacle", decimal_odds=price,
                        seen_at=seen, is_closing=True)
    assert db.closing_price("e1", "h2h", "home") == pytest.approx(1.90)


def test_closing_price_can_be_filtered_by_book(db):
    db.record_quote(event_id="e1", sport="nfl", market_type="h2h", outcome="home",
                    book="pinnacle", decimal_odds=1.95, is_closing=True)
    db.record_quote(event_id="e1", sport="nfl", market_type="h2h", outcome="home",
                    book="dk", decimal_odds=2.10, is_closing=True)
    assert db.closing_price("e1", "h2h", "home", book="dk") == pytest.approx(2.10)
    assert db.closing_price("e1", "h2h", "home", book="fd") is None


def test_a_non_closing_quote_is_not_a_closing_price(db):
    db.record_quote(event_id="e1", sport="nfl", market_type="h2h", outcome="home",
                    book="pinnacle", decimal_odds=1.95)
    assert db.closing_price("e1", "h2h", "home") is None


# ---------------------------------------------------------------- settling


def test_settling_makes_a_bet_gradeable(db):
    bet_id = place(db)
    assert db.graded_bets() == []
    db.settle(bet_id, closing_fair_prob=0.50, won=True, profit=105.0)
    graded = db.graded_bets()
    assert len(graded) == 1
    assert graded[0].closing_fair_prob == pytest.approx(0.50)
    assert graded[0].won is True


def test_an_ungraded_bet_is_not_a_zero(db):
    """Including it would drag every average toward nothing and make a small
    sample look more certain than it is."""
    place(db)
    settled = place(db, event_id="e2")
    db.settle(settled, closing_fair_prob=0.48)
    assert db.stats()["bets"] == 2
    assert db.stats()["ungraded"] == 1
    assert len(db.graded_bets()) == 1


def test_a_vigged_closing_probability_is_refused(db):
    """Not detectable in general, but the impossible cases are — and grading
    against a raw closing price biases every bet by the closing margin, which
    looks exactly like a model that is slightly too optimistic."""
    bet_id = place(db)
    with pytest.raises(LedgerError, match="closing_fair_prob"):
        db.settle(bet_id, closing_fair_prob=1.04)


def test_settling_an_unknown_bet_is_refused(db):
    with pytest.raises(LedgerError, match="no bet"):
        db.settle(999, closing_fair_prob=0.5)


def test_graded_bets_filter_by_sport_and_market(db):
    a = place(db, sport="nfl", market_type="h2h")
    b = place(db, sport="nba", market_type="totals", event_id="e2")
    db.settle(a, closing_fair_prob=0.50)
    db.settle(b, closing_fair_prob=0.49)
    assert len(db.graded_bets(sport="nfl")) == 1
    assert len(db.graded_bets(market_type="totals")) == 1
    assert len(db.graded_bets()) == 2


# -------------------------------------------------------- feeding the models


def test_the_fill_model_is_rebuilt_from_attempts(db):
    fresh = db.fill_model()
    prior = fresh.tau("dk", "h2h")
    for _ in range(40):
        db.record_attempt(book="dk", market_type="h2h", quote_age=4.0,
                          accepted=False)
    fitted = db.fill_model()
    assert fitted.tau("dk", "h2h") < prior
    assert fitted.is_fitted("dk", "h2h")


def test_an_empty_ledger_yields_a_prior_only_fill_model(db):
    model = db.fill_model()
    assert not model.is_fitted("dk", "h2h")
    assert model.p_fill("dk", "h2h", 0.0) == 1.0


def test_account_heat_is_rebuilt_from_the_bet_log(db):
    now = time.time()
    for i in range(10):
        place(db, event_id=f"e{i}", stake=127.43, market_type="alternate_spreads",
              placed_at=now - i, since_line_move=0.5)
    account = db.account_heat()
    assert account.score("dk", now=now) > 0.3


def test_heat_ignores_bets_outside_the_window(db):
    now = time.time()
    place(db, placed_at=now - 400 * 86400)
    assert db.account_heat().score("dk", now=now) == 0.0


def test_recreational_flag_survives_the_round_trip(db):
    now = time.time()
    place(db, placed_at=now, recreational=True)
    account = db.account_heat()
    assert account.history[0].recreational is True


def test_method_candidates_align_with_graded_bets(db):
    for i in range(5):
        bet_id = place(db, event_id=f"e{i}")
        db.settle(bet_id, closing_fair_prob=0.51)
    candidates = db.method_candidates()
    bets = db.graded_bets()
    assert set(candidates) == {"additive", "multiplicative", "power", "shin"}
    assert all(len(v) == len(bets) for v in candidates.values())

    # The fixture's multiplicative (0.519) sits closest to the 0.51 close and
    # additive (0.521) furthest, so the scoring must rank them that way. This
    # is the whole calibration loop in one assertion: the record decides which
    # method wins, not the author.
    scores = method_scores(bets, candidates)
    assert scores["multiplicative"] < scores["power"] < scores["additive"]


def test_methods_missing_on_any_bet_are_dropped_not_filled(db):
    """A method scored on a subset is not comparable with one scored on the
    whole set; the ranking would be an artefact of which markets each could
    solve."""
    a = place(db, at_bet=good_at_bet(devig={"power": 0.52, "shin": 0.52}))
    b = place(db, event_id="e2", at_bet=good_at_bet(devig={"power": 0.51}))
    db.settle(a, closing_fair_prob=0.50)
    db.settle(b, closing_fair_prob=0.50)
    assert set(db.method_candidates()) == {"power"}


def test_method_candidates_on_an_empty_ledger(db):
    assert db.method_candidates() == {}


def test_a_full_grading_cycle_reaches_a_clv_verdict(db):
    """End to end: place, settle, grade, and get a verdict that refuses to
    overclaim on 5 bets."""
    for i in range(5):
        bet_id = place(db, event_id=f"e{i}", decimal_odds=2.10)
        db.settle(bet_id, closing_fair_prob=0.50 + 0.004 * (i % 3))
    rep = report(db.graded_bets())
    assert rep.n == 5
    assert not rep.significant
    assert "too few" in rep.verdict()


# ---------------------------------------------------------------- settings


def test_settings_round_trip_json(db):
    db.set_setting("method_weights", {"power": 0.4, "shin": 0.6})
    assert db.get_setting("method_weights")["shin"] == pytest.approx(0.6)


def test_a_missing_setting_returns_the_default(db):
    assert db.get_setting("nope", default={"a": 1}) == {"a": 1}
    assert db.get_setting("nope") is None


def test_setting_a_key_twice_overwrites(db):
    db.set_setting("k", 1)
    db.set_setting("k", 2)
    assert db.get_setting("k") == 2
    assert db.conn.execute("SELECT COUNT(*) FROM settings").fetchone()[0] == 1


def test_calibrated_weights_carry_their_age(db):
    """A measurement shown without its date asserts 'true now', forever — the
    same mistake the jurisdiction table was fixed for."""
    assert db.setting_age("weights") is None
    db.set_setting("weights", {"power": 1.0})
    assert db.setting_age("weights") < 5.0


# ------------------------------------------------------------------- stats


def test_stats_say_how_far_off_calibration_is(db):
    assert db.stats()["graded_needed"] == 30
    assert not db.stats()["can_calibrate"]
    for i in range(30):
        bet_id = place(db, event_id=f"e{i}")
        db.settle(bet_id, closing_fair_prob=0.50)
    assert db.stats()["graded_needed"] == 0
    assert db.stats()["can_calibrate"]


def test_stats_count_distinct_books(db):
    place(db, book="dk")
    place(db, book="fd", event_id="e2")
    place(db, book="dk", event_id="e3")
    assert db.stats()["books"] == 2
