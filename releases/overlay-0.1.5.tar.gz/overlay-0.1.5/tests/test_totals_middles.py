"""Totals are not margins, and the ways they differ all cost money."""

import pytest

from overlay_engine.middles import (
    MIN_GAMES,
    MIN_PER_CELL,
    MIN_TOTAL_GAMES,
    PRIOR_SIGMA,
    MarginModel,
    TotalsModel,
    find_middles,
    model_for,
    sigma_for,
)
from overlay_engine.models import Book, BookTier, Market, Outcome, Quote

NOW = 1_800_000_000.0


def _totals(spread: range, per_value: int) -> TotalsModel:
    return TotalsModel(counts={"nfl": {v: per_value for v in spread}})


def _thick() -> TotalsModel:
    """Enough games and enough per cell to be counted."""
    return _totals(range(35, 55), 30)     # 20 cells x 30 = 600 games


def _market(low: float, high: float, market_type: str = "totals") -> Market:
    book = lambda k: Book(key=k, name=k, tier=BookTier.RETAIL)  # noqa: E731
    return Market(
        event_id="e1", sport="nfl", market_type=market_type,
        quotes=[
            Quote(book=book("dk"), outcome=Outcome("over", low),
                  decimal=1.91, seen_at=NOW),
            Quote(book=book("fd"), outcome=Outcome("under", high),
                  decimal=1.91, seen_at=NOW),
        ],
    )


# ------------------------------------------------------------- the column

def test_a_totals_model_counts_combined_scores_not_margins(tmp_path):
    from overlay_engine.ledger import Ledger

    with Ledger(str(tmp_path / "t.db")) as db:
        db.record_score(event_id="g1", sport="nfl", home_score=24, away_score=21)
        totals = TotalsModel.from_ledger(db)
        margins = MarginModel.from_ledger(db)
    assert totals.counts["nfl"] == {45: 1}
    assert margins.counts["nfl"] == {3: 1}


def test_the_two_models_read_different_columns_of_the_same_table(tmp_path):
    """A blowout and a shootout are the same game to one and not the other."""
    from overlay_engine.ledger import Ledger

    with Ledger(str(tmp_path / "t.db")) as db:
        db.record_score(event_id="a", sport="nfl", home_score=45, away_score=3)
        db.record_score(event_id="b", sport="nfl", home_score=24, away_score=24)
        assert sorted(TotalsModel.from_ledger(db).counts["nfl"]) == [48]
        assert sorted(MarginModel.from_ledger(db).counts["nfl"]) == [0, 42]


# ------------------------------------------------------------- thresholds

def test_totals_demand_more_games_than_margins():
    """Not a matter of taste: an unfolded distribution spreads wider, so the
    same game count buys thinner cells."""
    assert MIN_TOTAL_GAMES > MIN_GAMES


def test_a_totals_model_at_the_margin_threshold_is_not_measured():
    """200 games would satisfy MarginModel and must not satisfy this."""
    assert not _totals(range(35, 55), 10).is_measured("nfl")  # 200 games


def test_a_thin_totals_model_is_declined_even_above_the_game_count():
    """Enough games, spread too thin. The game count alone is not the guard."""
    sprawling = _totals(range(0, 120), 5)   # 600 games, 5 per cell
    assert sprawling.games("nfl") >= MIN_TOTAL_GAMES
    assert sprawling.per_cell("nfl") < MIN_PER_CELL
    assert not sprawling.is_measured("nfl")


def test_a_thick_totals_model_is_measured():
    thick = _thick()
    assert thick.games("nfl") >= MIN_TOTAL_GAMES
    assert thick.per_cell("nfl") >= MIN_PER_CELL
    assert thick.is_measured("nfl")


def test_per_cell_is_measured_from_the_data_not_assumed():
    assert _totals(range(35, 55), 30).per_cell("nfl") == pytest.approx(30.0)
    assert _totals(range(0, 120), 5).per_cell("nfl") == pytest.approx(5.0)


def test_an_empty_model_reports_zero_per_cell_rather_than_dividing_by_zero():
    assert TotalsModel().per_cell("nfl") == 0.0
    assert TotalsModel().cells("nfl") == 0


# --------------------------------------------------------------- windows

def test_a_counted_totals_window_is_exclusive_at_both_ends():
    """44.5/47.5 wins on 45, 46, 47 — never on a number sitting on a line."""
    thick = _thick()
    assert thick.p_window("nfl", 44.5, 47.5) == pytest.approx(3 * 30 / 600)


def test_an_unmeasured_totals_window_is_none_not_zero():
    assert _totals(range(35, 55), 5).p_window("nfl", 44.5, 47.5) is None


def test_a_totals_middle_is_counted_when_the_model_is_thick():
    plans = find_middles(_market(44.5, 47.5), {}, totals_model=_thick())
    assert plans and plans[0].source == "counted"


def test_a_totals_middle_falls_back_when_the_model_is_thin():
    plans = find_middles(_market(44.5, 47.5), {},
                         totals_model=_totals(range(0, 120), 5))
    assert plans and plans[0].source == "approximated"


# ---------------------------------------------------------- the dispatch

def test_a_totals_market_is_never_priced_off_a_margin_distribution():
    """The bug this dispatch exists to make impossible.

    Both models count small integers and both answer `p_window`, so a totals
    market handed a margin distribution returns a confident number with
    nothing wrong on the surface. It would price a 44.5/47.5 window off how
    often games are decided by 45 to 47 points.
    """
    margins = MarginModel(counts={"nfl": {v: 30 for v in range(0, 20)}})
    assert model_for("totals", margins, None) is None
    assert model_for("spreads", margins, None) is margins


def test_a_spread_market_is_never_priced_off_a_totals_distribution():
    thick = _thick()
    assert model_for("spreads", None, thick) is None
    assert model_for("totals", None, thick) is thick


def test_find_middles_on_a_totals_market_ignores_a_margin_model():
    margins = MarginModel(counts={"nfl": {v: 30 for v in range(0, 20)}})
    plans = find_middles(_market(44.5, 47.5), {}, model=margins)
    assert plans and plans[0].source == "approximated"


# ------------------------------------------------------------ dispersion

def test_sigma_is_measured_off_recorded_games_when_there_are_enough():
    spread, source = sigma_for("nfl", _thick(), "totals")
    assert source == "measured"
    assert spread > 0
    assert spread != PRIOR_SIGMA["totals"]


def test_sigma_falls_back_to_a_prior_that_says_it_is_one():
    spread, source = sigma_for("nfl", None, "totals")
    assert source == "prior"
    assert spread == PRIOR_SIGMA["totals"]


def test_a_thin_model_does_not_get_to_supply_a_sigma():
    """A dispersion off thirty games is a rumour with a decimal point."""
    assert _totals(range(35, 55), 5).sigma("nfl") is None
    assert sigma_for("nfl", _totals(range(35, 55), 5), "totals")[1] == "prior"


def test_an_explicit_sigma_overrides_and_is_labelled_as_an_override():
    spread, source = sigma_for("nfl", _thick(), "totals", override=9.0)
    assert (spread, source) == (9.0, "override")


def test_every_market_class_has_a_prior_sigma():
    assert set(PRIOR_SIGMA) >= {"spreads", "totals"}


def test_a_plan_carries_the_sigma_it_used_and_where_it_came_from():
    plans = find_middles(_market(44.5, 47.5), {}, totals_model=TotalsModel())
    assert plans[0].sigma_source == "prior"
    assert plans[0].sigma == PRIOR_SIGMA["totals"]


def test_a_model_too_thin_to_count_is_still_thick_enough_to_measure_spread():
    """Two questions, two answers, and conflating them loses information.

    The per-cell rule exists because counting a three-point window off thin
    buckets is unreliable. A standard deviation uses every game at once and
    does not care how they are bucketed — so declining to count while still
    trusting the dispersion is correct, not a leak.
    """
    thin = _totals(range(0, 120), 5)          # 600 games, 5 per cell
    assert not thin.is_measured("nfl")        # will not count a window
    assert thin.sigma("nfl") is not None      # will supply a dispersion
    plans = find_middles(_market(44.5, 47.5), {}, totals_model=thin)
    assert plans[0].source == "approximated"
    assert plans[0].sigma_source == "measured"


def test_a_measured_sigma_reaches_the_plan():
    plans = find_middles(_market(20.5, 90.5), {}, totals_model=_thick())
    assert plans[0].sigma_source == "measured"


# ------------------------------------------------------ regression guards

def test_margin_middles_still_work_exactly_as_before():
    margins = MarginModel(counts={"nfl": {v: 30 for v in range(0, 20)}})
    plans = find_middles(_market(2.5, 3.5, "spreads"), {}, model=margins)
    assert plans and plans[0].source == "counted"
    assert plans[0].p_middle == pytest.approx(30 / 600)


def test_margin_model_keeps_its_own_threshold():
    """Raising the totals bar must not quietly raise the margin one."""
    assert MarginModel(counts={"nfl": {v: 10 for v in range(0, 20)}}).is_measured("nfl")


def test_p_margin_and_p_total_are_the_same_call_on_different_columns():
    margins = MarginModel(counts={"nfl": {3: 200, 7: 100}})
    assert margins.p_margin("nfl", 3) == pytest.approx(200 / 300)
    thick = _thick()
    assert thick.p_total("nfl", 44) == pytest.approx(30 / 600)
