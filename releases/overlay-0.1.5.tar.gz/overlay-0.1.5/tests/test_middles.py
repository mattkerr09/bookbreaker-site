"""Middles: the window probability, and refusing to invent one."""

import pytest

from overlay_engine.ledger import Ledger, LedgerError
from overlay_engine.middles import (
    MIN_GAMES,
    MarginModel,
    MiddlePlan,
    find_middles,
    hold_cost,
    stake_middle,
    window_probability,
)
from overlay_engine.models import Book, BookTier, Market, Outcome, Quote

DK = Book("dk", "DraftKings", BookTier.RETAIL)
FD = Book("fd", "FanDuel", BookTier.RETAIL)
EX = Book("betfair", "Betfair", BookTier.EXCHANGE, commission=0.02)
BOOKS = {b.key: b for b in (DK, FD, EX)}


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "mid.db") as ledger:
        yield ledger


def load_margins(db, margins, sport="nfl"):
    """Record games producing exactly these absolute margins."""
    for i, margin in enumerate(margins):
        db.record_score(event_id=f"g{i}", sport=sport,
                        home_score=20 + margin, away_score=20)


# NFL-shaped: heavy on 3 and 7, the lumps a smooth curve cannot reproduce.
NFL_SHAPE = ([3] * 45 + [7] * 27 + [6] * 21 + [10] * 18 + [4] * 15
             + [14] * 12 + [1] * 12 + [2] * 12 + [5] * 12 + [8] * 12
             + [11] * 9 + [13] * 9 + [17] * 9 + [20] * 9 + [9] * 6
             + [12] * 6 + [16] * 6 + [21] * 6 + [24] * 6 + [28] * 6
             + [15] * 6 + [18] * 6 + [19] * 5 + [22] * 5 + [23] * 5)


# ------------------------------------------------------------ the score table


def test_scores_round_trip(db):
    db.record_score(event_id="e1", sport="nfl", home_score=27, away_score=24)
    assert db.margins("nfl") == [3]
    assert db.totals("nfl") == [51]


def test_a_re_reported_score_corrects_rather_than_double_counts(db):
    """A distribution built from a table that counted the same game twice is
    wrong in a way nothing else could see."""
    db.record_score(event_id="e1", sport="nfl", home_score=27, away_score=24)
    db.record_score(event_id="e1", sport="nfl", home_score=30, away_score=24)
    assert db.margins("nfl") == [6]


def test_the_margin_is_absolute(db):
    db.record_score(event_id="e1", sport="nfl", home_score=17, away_score=24)
    assert db.margins("nfl") == [7]


def test_negative_scores_are_refused(db):
    with pytest.raises(LedgerError, match="negative"):
        db.record_score(event_id="e1", sport="nfl", home_score=-3, away_score=10)


def test_scores_are_separated_by_sport(db):
    db.record_score(event_id="a", sport="nfl", home_score=27, away_score=24)
    db.record_score(event_id="b", sport="nba", home_score=110, away_score=99)
    assert db.margins("nfl") == [3]
    assert db.margins("nba") == [11]
    assert len(db.margins()) == 2


# ------------------------------------------------------------- the refusals


def test_an_empty_model_declines_to_give_a_probability(db):
    model = MarginModel.from_ledger(db)
    assert not model.is_measured("nfl")
    assert model.p_margin("nfl", 3) is None
    assert model.p_window("nfl", 2.5, 3.5) is None


def test_a_small_sample_still_declines(db):
    """A margin that has not happened in 40 games is not a margin with
    probability zero, and treating it as one would price some middles at
    infinity and others at nothing."""
    load_margins(db, [3] * 40)
    model = MarginModel.from_ledger(db)
    assert model.games("nfl") == 40
    assert not model.is_measured("nfl")
    assert model.p_window("nfl", 2.5, 3.5) is None


def test_p_margin_declines_below_the_floor_too(db):
    """`p_margin` and `p_window` each carry the floor. A break in one is
    invisible to a test that only exercises the other."""
    load_margins(db, [3] * 40)
    model = MarginModel.from_ledger(db)
    assert model.p_margin("nfl", 3) is None
    assert model.p_margin("nfl", 99) is None


def test_the_floor_is_stated():
    assert MIN_GAMES == 200


def test_enough_games_unlocks_the_counted_distribution(db):
    load_margins(db, NFL_SHAPE)
    model = MarginModel.from_ledger(db)
    assert model.games("nfl") >= MIN_GAMES
    assert model.is_measured("nfl")
    assert model.p_margin("nfl", 3) > 0


def test_key_numbers_come_out_of_the_counting(db):
    """The lumps are the whole reason this class exists."""
    load_margins(db, NFL_SHAPE)
    model = MarginModel.from_ledger(db)
    top = [margin for margin, _ in model.key_numbers("nfl", top=2)]
    assert top == [3, 7]


def test_key_numbers_are_empty_below_the_floor(db):
    load_margins(db, [3] * 40)
    assert MarginModel.from_ledger(db).key_numbers("nfl") == []


def test_a_lumpy_distribution_is_not_a_smooth_one(db):
    """A 2.5/3.5 middle is worth far more than a smooth curve says and a
    4.5/5.5 middle far less. That difference is the product."""
    load_margins(db, NFL_SHAPE)
    model = MarginModel.from_ledger(db)

    on_key, _ = window_probability("nfl", 2.5, 3.5, model, sigma=13.0)
    off_key, _ = window_probability("nfl", 4.5, 5.5, model, sigma=13.0)
    smooth_on, _ = window_probability("nfl", 2.5, 3.5, None, sigma=13.0)
    smooth_off, _ = window_probability("nfl", 4.5, 5.5, None, sigma=13.0)

    assert on_key > off_key * 2
    assert smooth_on == pytest.approx(smooth_off)
    assert on_key > smooth_on


def test_the_window_is_exclusive_at_both_ends(db):
    """A result on a line is a push there, not a win. Counting it would inflate
    every middle by the frequency of its own key number."""
    load_margins(db, NFL_SHAPE)
    model = MarginModel.from_ledger(db)
    assert model.p_window("nfl", 3.0, 4.0) == 0.0
    assert model.p_window("nfl", 2.5, 3.5) > 0


def test_an_inverted_window_has_no_probability(db):
    load_margins(db, NFL_SHAPE)
    assert MarginModel.from_ledger(db).p_window("nfl", 5.5, 2.5) == 0.0


def test_provenance_is_reported_not_implied(db):
    """A middle priced off a smooth curve and one priced off two thousand real
    games are different claims and must not print identically."""
    _, source = window_probability("nfl", 2.5, 3.5, None, sigma=13.0)
    assert source == "approximated"

    load_margins(db, NFL_SHAPE)
    _, source = window_probability("nfl", 2.5, 3.5,
                                   MarginModel.from_ledger(db), sigma=13.0)
    assert source == "counted"


def test_an_unmeasured_sport_falls_back_even_when_another_is_measured(db):
    load_margins(db, NFL_SHAPE, sport="nfl")
    model = MarginModel.from_ledger(db)
    _, source = window_probability("nba", 2.5, 3.5, model, sigma=13.0)
    assert source == "approximated"


# ---------------------------------------------------------------- staking


def test_staking_equalises_the_single_leg_outcomes():
    lo, hi = stake_middle(1.91, 1.91, total=1000.0, round_stakes=False)
    assert lo == pytest.approx(hi)
    assert lo + hi == pytest.approx(1000.0)


def test_stakes_are_rounded_by_default():
    """A middle is placed at two retail books by definition, so the fingerprint
    matters as much as it does on an arbitrage."""
    lo, hi = stake_middle(2.05, 1.87, total=1000.0)
    assert lo % 25 == 0
    assert hi % 25 == 0


# --------------------------------------------------------------- economics


def _plan(low_d=1.91, high_d=1.91, p=0.10, source="counted"):
    lo, hi = stake_middle(low_d, high_d, total=1000.0, round_stakes=False)
    return MiddlePlan(
        low_line=220.5, high_line=223.5, low_book="dk", high_book="fd",
        low_decimal=low_d, high_decimal=high_d, low_stake=lo, high_stake=hi,
        p_middle=p, source=source,
    )


def test_one_side_is_the_worse_side_not_the_better():
    """Quoting the better leg describes a position the bettor does not hold.

    Stakes are deliberately unequal. An earlier version of this test staked to
    *equalise* the two legs and then asserted min-versus-max on two identical
    numbers, so it passed against a build that returned the better side. In
    practice rounding is what makes them differ, which is exactly when the
    distinction starts to matter.
    """
    plan = MiddlePlan(
        low_line=220.5, high_line=223.5, low_book="dk", high_book="fd",
        low_decimal=2.10, high_decimal=1.80,
        low_stake=400.0, high_stake=600.0,
        p_middle=0.10, source="counted",
    )
    low_wins = 400.0 * 2.10 - 1000.0
    high_wins = 600.0 * 1.80 - 1000.0
    assert low_wins != pytest.approx(high_wins), "the legs must actually differ"
    assert plan.one_side_profit == pytest.approx(min(low_wins, high_wins))
    assert plan.one_side_profit == pytest.approx(-160.0)


def test_holding_the_position_usually_costs_a_little():
    assert _plan().one_side_profit < 0


def test_the_middle_pays_both_legs():
    plan = _plan()
    assert plan.middle_profit > 0
    assert plan.middle_profit > plan.one_side_profit


def test_breakeven_does_not_depend_on_any_distribution():
    """It is arithmetic on the two prices, which is what makes it the number to
    compare a claimed window against."""
    a = _plan(p=0.02)
    b = _plan(p=0.40)
    assert a.breakeven_p == pytest.approx(b.breakeven_p)


def test_a_window_above_breakeven_is_positive_ev():
    plan = _plan(p=0.10)
    assert plan.breakeven_p < 0.10
    assert plan.ev > 0


def test_a_window_below_breakeven_is_negative_ev():
    assert _plan(p=0.01).ev < 0


def test_a_middle_that_cannot_pay_has_a_breakeven_of_one():
    plan = MiddlePlan(
        low_line=1, high_line=2, low_book="a", high_book="b",
        low_decimal=1.5, high_decimal=1.5, low_stake=0.0, high_stake=0.0,
        p_middle=0.5, source="counted",
    )
    assert plan.breakeven_p == 1.0
    assert plan.ev == 0.0


def test_the_plan_says_where_its_number_came_from():
    assert _plan(source="counted").measured
    assert not _plan(source="approximated").measured
    assert "approximated" in _plan(source="approximated").describe()


def test_hold_cost_flags_a_pair_that_is_already_an_arb():
    assert hold_cost(1.91, 1.91) < 0
    assert hold_cost(2.10, 2.10) > 0


# ------------------------------------------------------------- the screen


def _market(prices, market_type="totals", sport="nfl"):
    return Market(
        event_id="e1", sport=sport, market_type=market_type,
        quotes=[
            Quote(book=b, outcome=Outcome(name=n, line=line), decimal=d,
                  seen_at=1000.0)
            for b, n, line, d in prices
        ],
    )


def test_a_middle_is_found_across_two_books():
    market = _market([("dk", "over", 220.5, 1.91), ("fd", "under", 223.5, 1.91)])
    plans = find_middles(market, BOOKS, total=1000.0)
    assert len(plans) == 1
    assert plans[0].low_line == 220.5
    assert plans[0].high_line == 223.5


def test_the_reverse_pair_is_not_a_middle():
    """Over the higher number and under the lower one is a market where both
    legs can lose; reporting it as a middle inverts the sign of the position."""
    market = _market([("dk", "over", 223.5, 1.91), ("fd", "under", 220.5, 1.91)])
    assert find_middles(market, BOOKS) == []


def test_same_line_is_not_a_middle():
    market = _market([("dk", "over", 220.5, 1.91), ("fd", "under", 220.5, 1.91)])
    assert find_middles(market, BOOKS) == []


def test_a_book_middling_itself_is_not_offered():
    market = _market([("dk", "over", 220.5, 1.91), ("dk", "under", 223.5, 1.91)])
    assert find_middles(market, BOOKS) == []


def test_quotes_without_a_line_are_ignored():
    market = _market([("dk", "over", None, 1.91), ("fd", "under", 223.5, 1.91)])
    assert find_middles(market, BOOKS) == []


def test_commission_is_netted_into_the_middle():
    plain = _market([("dk", "over", 220.5, 2.05), ("fd", "under", 223.5, 2.05)])
    exchange = _market([("dk", "over", 220.5, 2.05),
                        ("betfair", "under", 223.5, 2.05)])
    a = find_middles(plain, BOOKS)[0]
    b = find_middles(exchange, BOOKS)[0]
    assert b.high_decimal < a.high_decimal


def test_the_screen_uses_counted_probabilities_when_it_has_them(db):
    load_margins(db, NFL_SHAPE)
    model = MarginModel.from_ledger(db)
    market = _market([("dk", "home", 2.5, 1.91), ("fd", "away", 3.5, 1.91)],
                     market_type="spreads")
    plan = find_middles(market, BOOKS, model=model)[0]
    assert plan.source == "counted"
    assert plan.p_middle == pytest.approx(model.p_window("nfl", 2.5, 3.5))


def test_the_screen_labels_an_approximation(db):
    market = _market([("dk", "over", 220.5, 1.91), ("fd", "under", 223.5, 1.91)])
    plan = find_middles(market, BOOKS, model=MarginModel.from_ledger(db))[0]
    assert plan.source == "approximated"


def test_plans_are_ranked_by_ev(db):
    load_margins(db, NFL_SHAPE)
    market = _market([("dk", "home", 2.5, 1.91), ("dk", "home", 6.5, 1.91),
                      ("fd", "away", 3.5, 1.91), ("fd", "away", 7.5, 1.91)],
                     market_type="spreads")
    plans = find_middles(market, BOOKS, model=MarginModel.from_ledger(db))
    assert len(plans) >= 2
    assert plans == sorted(plans, key=lambda m: m.ev, reverse=True)
    assert plans[0].ev >= plans[-1].ev


def test_min_ev_filters(db):
    market = _market([("dk", "over", 220.5, 1.91), ("fd", "under", 223.5, 1.91)])
    assert find_middles(market, BOOKS, min_ev=0.99) == []


def test_a_market_with_no_lines_yields_nothing():
    market = Market(event_id="e1", sport="nfl", market_type="h2h", quotes=[])
    assert find_middles(market, BOOKS) == []
