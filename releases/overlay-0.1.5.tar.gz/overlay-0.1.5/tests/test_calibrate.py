"""Calibration: what it learns, and everything it refuses to learn."""

import pytest

from overlay_engine.calibrate import (
    MIN_GRADED,
    Calibration,
    blended,
    calibrate_all,
    calibrate_methods,
    scope_key,
    score,
    split,
    weights_for,
)
from overlay_engine.devig import devig_all
from overlay_engine.ledger import AtBet, Ledger


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "cal.db") as ledger:
        yield ledger


def add(db, i, devig, closing, sport="nfl", market="h2h", at=None):
    """Place and settle one bet with a chosen devig spread and closing line."""
    bet_id = db.record_bet(
        event_id=f"e{i}", sport=sport, market_type=market, outcome="home",
        book="dk", decimal_odds=2.0, stake=100.0,
        placed_at=1000.0 + i if at is None else at,
        at_bet=AtBet(fair_prob=0.5, fair_low=0.4, fair_high=0.6, devig=devig),
    )
    db.settle(bet_id, closing_fair_prob=closing)
    return bet_id


ALL_METHODS = ("multiplicative", "additive", "power", "shin")


def spread_where(good: str, bad: str, closing: float) -> dict[str, float]:
    """A four-method spread with `good` on the close and `bad` furthest off.

    Built by name rather than as a dict literal. The literal form —
    `{good: c, bad: c + 0.06, "additive": ..., "shin": ...}` — silently
    collapses whenever `good` or `bad` *is* one of the hard-coded names,
    because a later duplicate key wins. That produced a two-method spread
    where four were intended and quietly inverted the case the test was
    written to check, which then passed for the wrong reason.
    """
    if good == bad:
        raise ValueError("good and bad must differ")
    out = {good: closing, bad: closing + 0.06}
    for j, method in enumerate(m for m in ALL_METHODS if m not in (good, bad)):
        out[method] = closing + 0.01 * (j + 1)
    assert len(out) == len(ALL_METHODS)
    return out


def fill(db, n, *, good="power", bad="multiplicative", closing=0.50,
         sport="nfl", market="h2h", start=0):
    """n bets where `good` sits on the close and `bad` sits well off it."""
    devig = spread_where(good, bad, closing)
    for i in range(start, start + n):
        add(db, i, dict(devig), closing, sport=sport, market=market)


# --------------------------------------------------------------- primitives


def test_scope_keys_are_stable_and_distinct():
    assert scope_key(None, None) == "method_weights.global"
    assert scope_key("nfl", "moneyline") == "method_weights.nfl.moneyline"
    assert scope_key("nfl", None) != scope_key(None, "moneyline")


def test_blending_matches_the_engine_it_calibrates():
    """If these diverge, calibration optimises a quantity the engine never
    computes and writes confidently wrong weights."""
    spread = devig_all([1.69, 2.25])
    probs = {m: v[0] for m, v in spread.by_method.items()}
    weights = {"power": 3.0, "shin": 1.0}
    assert blended(probs, weights) == pytest.approx(spread.consensus(0, weights))
    assert blended(probs, None) == pytest.approx(spread.consensus(0))


def test_blending_ignores_weights_for_absent_methods():
    assert blended({"power": 0.5}, {"shin": 1.0}) == pytest.approx(0.5)


def test_blending_an_empty_set_is_refused():
    with pytest.raises(ValueError):
        blended({}, None)


def test_score_is_zero_for_a_perfect_predictor(db):
    fill(db, 4)
    bets = db.graded_bets()
    assert score(bets, db.method_candidates(), {"power": 1.0}) == pytest.approx(0.0)


def test_score_rises_as_the_blend_drifts(db):
    fill(db, 4)
    bets, cands = db.graded_bets(), db.method_candidates()
    assert (score(bets, cands, {"power": 1.0})
            < score(bets, cands, None)
            < score(bets, cands, {"multiplicative": 1.0}))


def test_an_empty_scoring_set_is_infinite_not_zero():
    """Zero would read as a perfect score and win every comparison."""
    assert score([], {}, None) == float("inf")


def test_the_split_is_temporal_and_always_leaves_both_sides():
    assert split(list(range(100)), 0.3) == 70
    assert split(list(range(2)), 0.3) == 1
    assert split(list(range(2)), 0.9) == 1
    assert split(list(range(50)), 0.5) == 25


def test_a_degenerate_holdout_is_refused():
    """A hold-out of zero would silently turn the gate off and accept every
    candidate."""
    for bad in (0.0, 1.0, -0.1, 1.5):
        with pytest.raises(ValueError):
            split(list(range(10)), bad)


# ------------------------------------------------------------- the refusals


def test_calibration_refuses_a_small_sample(db):
    fill(db, 12)
    result = calibrate_methods(db)
    assert not result.accepted
    assert result.n == 12
    assert "need 30" in result.reason
    assert db.get_setting(scope_key(None, None)) is None


def test_the_refusal_is_visible_not_silent(db):
    fill(db, 5)
    assert "not calibrated" in calibrate_methods(db).describe()


def test_an_empty_log_refuses_rather_than_crashing(db):
    result = calibrate_methods(db)
    assert not result.accepted
    assert result.n == 0


def test_one_method_cannot_be_weighted_against_itself(db):
    for i in range(40):
        add(db, i, {"power": 0.50}, 0.50)
    result = calibrate_methods(db)
    assert not result.accepted
    assert "at least two" in result.reason


def test_calibration_refuses_weights_that_do_not_beat_the_incumbent(db):
    """The gate that matters. Train on a slice where `power` is best, hold out
    a slice where it is worst, and the candidate must be thrown away."""
    fill(db, 30, good="power", bad="multiplicative", start=0)
    # The recent tail — the held-out slice — inverts which method is right.
    fill(db, 15, good="multiplicative", bad="power", start=100)

    result = calibrate_methods(db, holdout=0.3)
    assert result.n == 45
    assert result.n_holdout == 14
    assert not result.accepted
    assert "no better" in result.reason
    assert result.improvement <= 0
    assert db.get_setting(scope_key(None, None)) is None


def test_calibration_can_make_things_worse_and_is_caught(db):
    """Stated as its own test because it is the whole reason the hold-out
    exists: without it this would look identical from outside — weights would
    change, numbers would move, and nothing would get better."""
    fill(db, 30, good="shin", bad="additive", start=0)
    fill(db, 15, good="additive", bad="shin", start=100)
    naive = calibrate_methods(db, holdout=0.3, write=False)
    assert naive.candidate_score > naive.incumbent_score
    assert not naive.accepted


def test_nothing_is_written_when_calibration_declines(db):
    fill(db, 30, good="power", start=0)
    fill(db, 15, good="multiplicative", bad="power", start=100)
    calibrate_methods(db)
    assert weights_for(db) == (None, None)


# ------------------------------------------------------------- the successes


def test_calibration_accepts_weights_that_hold_up_out_of_sample(db):
    fill(db, 60, good="power", bad="multiplicative")
    result = calibrate_methods(db)
    assert result.accepted
    assert result.n_train == 42
    assert result.n_holdout == 18
    assert result.candidate_score < result.incumbent_score
    assert result.improvement > 0


def test_the_winning_method_gets_the_most_weight(db):
    fill(db, 60, good="power", bad="multiplicative")
    weights = calibrate_methods(db).weights
    assert max(weights, key=weights.get) == "power"
    assert sum(weights.values()) == pytest.approx(1.0)


def test_a_losing_method_is_demoted_not_deleted(db):
    """40 bets cannot distinguish a bad method from an unlucky one, and a
    deleted method never gets the chance to come back."""
    fill(db, 60, good="power", bad="multiplicative")
    weights = calibrate_methods(db).weights
    assert weights["multiplicative"] >= 0.05


def test_accepted_weights_are_written_and_readable(db):
    fill(db, 60, good="power")
    calibrate_methods(db)
    weights, age = weights_for(db)
    assert weights is not None
    assert max(weights, key=weights.get) == "power"
    assert age is not None and age < 5.0


def test_write_false_calibrates_without_storing(db):
    fill(db, 60, good="power")
    result = calibrate_methods(db, write=False)
    assert result.accepted
    assert weights_for(db) == (None, None)


def test_a_second_run_on_the_same_data_declines(db):
    """Once the incumbent is the best available, calibration correctly does
    nothing — a frequent and normal result, not an error."""
    fill(db, 60, good="power")
    assert calibrate_methods(db).accepted
    second = calibrate_methods(db)
    assert not second.accepted
    assert "no better" in second.reason


# ------------------------------------------------------------------- scoping


def test_scopes_are_bucketed_by_market_class(db):
    """One user will never place enough bets on one exotic market type to fit
    four weights, but will place plenty across the class."""
    fill(db, 60, good="power", market="player_points")
    result = calibrate_methods(db, sport="nfl", market="player_points")
    assert result.scope == "method_weights.nfl.player_prop"


def test_a_specific_scope_beats_the_global_fallback(db):
    fill(db, 60, good="power", sport="nfl", market="h2h")
    fill(db, 60, good="shin", bad="power", sport="nba", market="totals", start=200)
    calibrate_methods(db)
    calibrate_methods(db, sport="nba", market="totals")

    nba, _ = weights_for(db, sport="nba", market="totals")
    glob, _ = weights_for(db)
    assert max(nba, key=nba.get) == "shin"
    assert nba != glob


def test_an_uncalibrated_scope_falls_back_to_global(db):
    fill(db, 60, good="power")
    calibrate_methods(db)
    weights, _ = weights_for(db, sport="mlb", market="totals")
    assert weights == db.get_setting(scope_key(None, None))


def test_calibrate_all_discovers_scopes_from_the_log(db):
    """A user who only bets NBA totals never sees an empty NFL row."""
    fill(db, 60, good="power", sport="nba", market="totals")
    results = calibrate_all(db)
    scopes = {r.scope for r in results}
    assert "method_weights.global" in scopes
    assert "method_weights.nba.total" in scopes
    assert not any("nfl" in s for s in scopes)


def test_calibrate_all_reports_refusals_alongside_successes(db):
    fill(db, 60, good="power", sport="nba", market="totals")
    fill(db, 8, good="power", sport="nfl", market="h2h", start=500)
    results = calibrate_all(db)
    assert any(r.accepted for r in results)
    assert any(not r.accepted and "need 30" in r.reason for r in results)


def test_min_graded_matches_the_clv_significance_floor():
    """The same evidence bar, applied to the thing that consumes the evidence."""
    assert MIN_GRADED == 30


def test_improvement_is_zero_when_there_is_no_incumbent_score():
    assert Calibration(scope="x", n=0).improvement == 0.0


def test_the_fixture_builds_all_four_methods_whatever_the_names():
    """Guards the helper itself. The dict-literal version collapsed to two
    methods whenever good or bad was one of the hard-coded names, and the
    tests built on it passed for the wrong reason."""
    for good, bad in (("power", "multiplicative"), ("shin", "additive"),
                      ("additive", "shin"), ("multiplicative", "power")):
        spread = spread_where(good, bad, 0.50)
        assert set(spread) == set(ALL_METHODS)
        assert spread[good] == 0.50
        assert spread[bad] == pytest.approx(0.56)
        assert max(spread, key=spread.get) == bad


def test_the_fixture_refuses_a_degenerate_pair():
    with pytest.raises(ValueError):
        spread_where("power", "power", 0.50)
