"""Arbitrage: the margin formula, and staking that survives rounding."""

import pytest

from overlay_engine.arb import (
    ArbPlan,
    arb_margin,
    find_arbs,
    ideal_stakes,
    middle_probability,
    stake_arb,
)
from overlay_engine.models import Book, BookTier, Market, Outcome, Quote

DK = Book(key="dk", name="DraftKings", tier=BookTier.RETAIL)
PIN = Book(key="pinnacle", name="Pinnacle", tier=BookTier.SHARP, limits_winners=False)
EX = Book(key="betfair", name="Betfair", tier=BookTier.EXCHANGE, commission=0.02)
BOOKS = {b.key: b for b in (DK, PIN, EX)}


def test_arb_margin_is_the_return_not_the_shortfall():
    """S = 0.95 returns 5.26%, not 5%. Every calculator that prints 1 - S is
    wrong by this amount."""
    decimals = [1.0 / 0.475, 1.0 / 0.475]
    assert sum(1 / d for d in decimals) == pytest.approx(0.95)
    assert arb_margin(decimals) == pytest.approx(0.0526315, abs=1e-6)
    assert arb_margin(decimals) != pytest.approx(0.05, abs=1e-4)


def test_no_arb_is_a_negative_margin():
    assert arb_margin([1.91, 1.91]) < 0


def test_ideal_stakes_equalise_the_return():
    decimals = [2.10, 2.05]
    stakes = ideal_stakes(decimals, 1000.0)
    payouts = [s * d for s, d in zip(stakes, decimals)]
    assert payouts[0] == pytest.approx(payouts[1])
    assert sum(stakes) == pytest.approx(1000.0)


def test_staking_produces_round_numbers():
    """The whole point: $473.82 is the fingerprint, so it must never appear."""
    plan = stake_arb([2.10, 2.05], total=1000.0)
    assert plan.rounded
    for leg in plan.legs:
        assert leg.stake % 5 == 0, f"{leg.stake} is not a round stake"


def test_round_staking_keeps_the_arb():
    plan = stake_arb([2.10, 2.05], total=1000.0)
    assert plan.guaranteed
    assert all(r > 0 for r in plan.returns())


def test_rounding_cost_is_reported_not_hidden():
    plan = stake_arb([2.10, 2.05], total=1000.0)
    assert plan.rounding_cost >= 0
    assert plan.profit == pytest.approx(plan.ideal_profit - plan.rounding_cost)


def test_profit_is_the_worst_outcome_not_the_average():
    """Once rounded the legs pay differently; quoting anything but the minimum
    describes a position the bettor does not hold."""
    plan = stake_arb([2.10, 2.05], total=1000.0)
    assert plan.profit == pytest.approx(min(plan.returns()))


def test_search_beats_naive_rounding_or_ties_it():
    """Straight rounding is one point in the neighbourhood we search, so the
    search can never do worse."""
    decimals = [2.14, 2.02]
    plan = stake_arb(decimals, total=500.0)
    naive = ideal_stakes(decimals, 500.0)
    naive_round = [max(5.0, round(s / 5.0) * 5.0) for s in naive]
    naive_profit = min(s * d for s, d in zip(naive_round, decimals)) - sum(naive_round)
    assert plan.profit >= naive_profit - 1e-9


def test_thin_arbs_fall_back_to_exact_stakes_rather_than_breaking():
    """A 0.1% margin has less slack than one ladder step. Say so; do not ship
    a broken lock."""
    plan = stake_arb([2.002, 2.002], total=100.0)
    assert plan.total_stake == pytest.approx(100.0)
    if not plan.rounded:
        assert plan.profit == pytest.approx(plan.ideal_profit)


def test_unrounded_staking_is_available_for_comparison():
    plan = stake_arb([2.10, 2.05], total=1000.0, round_stakes=False)
    assert not plan.rounded
    assert plan.profit == pytest.approx(plan.ideal_profit)


def test_larger_stakes_use_a_coarser_ladder():
    """Nobody bets $2,315 — the ladder has to widen with the number."""
    plan = stake_arb([2.10, 2.05], total=5000.0)
    for leg in plan.legs:
        assert leg.stake % 25 == 0


def test_three_way_arb_stakes_all_legs():
    plan = stake_arb([3.60, 3.90, 3.70], total=300.0)
    assert len(plan.legs) == 3
    assert plan.guaranteed


def test_staking_rejects_a_single_outcome():
    with pytest.raises(ValueError):
        stake_arb([2.0], total=100.0)


def test_staking_rejects_a_zero_stake():
    with pytest.raises(ValueError):
        stake_arb([2.10, 2.05], total=0.0)


def _market(prices, market_type="h2h", seen_at=1000.0):
    quotes = []
    for book, name, decimal in prices:
        quotes.append(
            Quote(book=book, outcome=Outcome(name=name), decimal=decimal, seen_at=seen_at)
        )
    return Market(event_id="e1", sport="nfl", market_type=market_type, quotes=quotes)


def test_find_arbs_detects_a_cross_book_arb():
    market = _market(
        [("dk", "home", 2.10), ("pinnacle", "home", 1.95),
         ("dk", "away", 1.80), ("pinnacle", "away", 2.05)]
    )
    found = find_arbs(market, BOOKS, now=1000.0)
    assert len(found) == 1
    assert found[0]["margin"] > 0
    assert {leg["book"] for leg in found[0]["legs"]} == {"dk", "pinnacle"}


def test_find_arbs_returns_nothing_on_a_normal_market():
    market = _market(
        [("dk", "home", 1.91), ("pinnacle", "home", 1.92),
         ("dk", "away", 1.91), ("pinnacle", "away", 1.93)]
    )
    assert find_arbs(market, BOOKS, now=1000.0) == []


def test_commission_is_netted_before_the_arb_is_called():
    """A 1.8% arb against a 2% exchange is not an arb. Reporting it costs the
    user money on every one surfaced."""
    market = _market(
        [("dk", "home", 2.01), ("betfair", "away", 2.01)]
    )
    gross = arb_margin([2.01, 2.01])
    assert gross > 0
    assert find_arbs(market, BOOKS, now=1000.0) == []


def test_a_book_arbing_itself_is_not_offered():
    """Both legs at one book is a stale line and the loudest possible signal
    to that book's risk desk."""
    market = _market([("dk", "home", 2.10), ("dk", "away", 2.10)])
    assert find_arbs(market, BOOKS, now=1000.0) == []


def test_fill_probability_discounts_the_margin():
    class Model:
        def p_fill(self, book, market, age):
            return 0.5

    market = _market(
        [("dk", "home", 2.10), ("pinnacle", "home", 1.95),
         ("dk", "away", 1.80), ("pinnacle", "away", 2.05)]
    )
    found = find_arbs(market, BOOKS, now=1000.0, fill_model=Model())[0]
    assert found["p_fill"] == pytest.approx(0.25)
    assert found["realised_margin"] == pytest.approx(found["margin"] * 0.25)


def test_min_margin_filters():
    market = _market(
        [("dk", "home", 2.10), ("pinnacle", "home", 1.95),
         ("dk", "away", 1.80), ("pinnacle", "away", 2.05)]
    )
    assert find_arbs(market, BOOKS, now=1000.0, min_margin=0.99) == []


def test_middle_probability_is_symmetric_and_bounded():
    p = middle_probability(-1.5, 1.5, sigma=13.0)
    assert 0.0 < p < 1.0
    assert middle_probability(-3.0, 3.0, sigma=13.0) > p


def test_an_empty_window_has_no_middle():
    assert middle_probability(2.0, 2.0, sigma=13.0) == 0.0
    assert middle_probability(3.0, 1.0, sigma=13.0) == 0.0


def test_middle_probability_rejects_a_zero_sigma():
    with pytest.raises(ValueError):
        middle_probability(-1.0, 1.0, sigma=0.0)
