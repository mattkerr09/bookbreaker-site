"""Promotions you are holding, what they are worth, and what expiry costs."""

import pytest

from overlay_engine.ledger import Ledger, LedgerError
from overlay_engine.promo import URGENT_DAYS, Holding, report_holdings

DAY = 86400.0
NOW = 1_800_000_000.0


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "promo.db") as ledger:
        yield ledger


def add(db, *, book="dk", kind="bonus_bet", amount=100.0, days=7.0, **over):
    return db.record_promo(
        book=book, kind=kind, amount=amount,
        received_at=NOW,
        expires_at=None if days is None else NOW + days * DAY,
        **over,
    )


# ------------------------------------------------------------------ storage


def test_a_promo_round_trips(db):
    add(db, amount=50.0, days=5.0)
    held = db.promos(state="held", now=NOW)
    assert len(held) == 1
    assert held[0]["amount"] == pytest.approx(50.0)
    assert held[0]["state"] == "held"


def test_an_unknown_kind_is_refused(db):
    with pytest.raises(LedgerError, match="unknown promo kind"):
        add(db, kind="mystery_tokens")


def test_a_worthless_promo_is_refused(db):
    with pytest.raises(LedgerError, match="worth something"):
        add(db, amount=0.0)


def test_a_boost_needs_its_boost_fraction(db):
    with pytest.raises(LedgerError, match="boost fraction"):
        add(db, kind="profit_boost")
    add(db, kind="profit_boost", boost=0.5)


def test_a_promo_that_expired_before_it_arrived_is_refused(db):
    """Storing something already dead hides a date-entry mistake as a loss."""
    with pytest.raises(LedgerError, match="cannot expire before"):
        db.record_promo(book="dk", kind="bonus_bet", amount=50.0,
                        received_at=NOW, expires_at=NOW - DAY)


def test_a_promo_with_no_stated_expiry_is_allowed(db):
    add(db, days=None)
    assert db.promos(state="held", now=NOW)[0]["expires_at"] is None


# ------------------------------------------------------------- the expiry


def test_a_lapsed_promo_is_not_a_holding(db):
    """Returning one would overstate the bankroll by money that no longer
    exists."""
    add(db, amount=100.0, days=2.0)
    assert len(db.promos(state="held", now=NOW)) == 1
    assert db.promos(state="held", now=NOW + 3 * DAY) == []


def test_a_lapsed_promo_shows_up_as_expired_before_it_is_written(db):
    add(db, days=2.0)
    assert len(db.promos(state="expired", now=NOW + 3 * DAY)) == 1


def test_expiring_writes_the_state_to_match(db):
    add(db, days=2.0)
    assert db.expire_promos(now=NOW + 3 * DAY) == 1
    assert db.promos(state="expired", now=NOW + 3 * DAY)[0]["state"] == "expired"


def test_expiring_leaves_live_promos_alone(db):
    add(db, days=30.0)
    assert db.expire_promos(now=NOW + DAY) == 0
    assert len(db.promos(state="held", now=NOW + DAY)) == 1


def test_a_promo_with_no_expiry_never_lapses(db):
    add(db, days=None)
    assert db.expire_promos(now=NOW + 3650 * DAY) == 0
    assert len(db.promos(state="held", now=NOW + 3650 * DAY)) == 1


# --------------------------------------------------------------- using one


def test_using_a_promo_records_what_it_actually_converted_to(db):
    promo_id = add(db, amount=100.0)
    db.use_promo(promo_id, realised=78.50, used_at=NOW + DAY)
    used = db.promos(state="used", now=NOW + DAY)
    assert used[0]["realised"] == pytest.approx(78.50)
    assert db.promos(state="held", now=NOW + DAY) == []


def test_a_promo_cannot_be_used_twice(db):
    """Counting the same money in two places."""
    promo_id = add(db)
    db.use_promo(promo_id, realised=75.0)
    with pytest.raises(LedgerError, match="already used"):
        db.use_promo(promo_id, realised=75.0)


def test_using_an_unknown_promo_is_refused(db):
    with pytest.raises(LedgerError, match="no promo"):
        db.use_promo(999, realised=50.0)


# ------------------------------------------------------------- the valuing


def test_face_value_is_never_the_value():
    """A bonus bet does not return its stake."""
    h = Holding(promo_id=1, book="dk", kind="bonus_bet", amount=100.0,
                conversion=0.75, expires_at=NOW + 7 * DAY)
    assert h.value(NOW) == pytest.approx(75.0)
    assert h.value(NOW) < h.amount


def test_an_expired_holding_is_worth_exactly_nothing():
    h = Holding(promo_id=1, book="dk", kind="bonus_bet", amount=100.0,
                conversion=0.75, expires_at=NOW - DAY)
    assert h.expired(NOW)
    assert h.value(NOW) == 0.0


def test_a_boost_is_valued_on_the_profit_not_the_stake():
    """A boost adds to the profit of a bet you were placing anyway."""
    boost = Holding(promo_id=1, book="dk", kind="profit_boost", amount=100.0,
                    conversion=1.0, boost=0.5, expires_at=NOW + 7 * DAY)
    assert boost.value(NOW) == pytest.approx(50.0)


def test_days_left_and_urgency():
    soon = Holding(promo_id=1, book="dk", kind="bonus_bet", amount=50.0,
                   conversion=0.75, expires_at=NOW + 2 * DAY)
    later = Holding(promo_id=2, book="dk", kind="bonus_bet", amount=50.0,
                    conversion=0.75, expires_at=NOW + 30 * DAY)
    assert soon.days_left(NOW) == pytest.approx(2.0)
    assert soon.urgent(NOW)
    assert not later.urgent(NOW)


def test_a_promo_with_no_expiry_is_never_urgent():
    h = Holding(promo_id=1, book="dk", kind="bonus_bet", amount=50.0,
                conversion=0.75)
    assert h.days_left(NOW) is None
    assert not h.urgent(NOW)
    assert h.value(NOW) > 0


def test_an_expired_holding_is_not_urgent_it_is_gone():
    h = Holding(promo_id=1, book="dk", kind="bonus_bet", amount=50.0,
                conversion=0.75, expires_at=NOW - DAY)
    assert not h.urgent(NOW)


def test_the_urgency_window_is_stated():
    assert URGENT_DAYS == 3.0


# ------------------------------------------------------------- the report


def test_the_report_totals_face_and_value(db):
    add(db, amount=100.0)
    add(db, amount=50.0)
    rep = report_holdings(db, conversion=0.8, now=NOW)
    assert rep.face == pytest.approx(150.0)
    assert rep.value == pytest.approx(120.0)
    assert "worth about 120" in rep.verdict()


def test_the_conversion_rate_travels_with_the_number(db):
    """It depends on what hedge you can actually place — the 80% plan needs
    eleven times the bonus sitting at another book."""
    add(db, amount=100.0)
    assert "75%" in report_holdings(db, conversion=0.75, now=NOW).verdict()
    assert "55%" in report_holdings(db, conversion=0.55, now=NOW).verdict()


def test_urgent_holdings_are_surfaced_soonest_first(db):
    add(db, amount=25.0, days=2.5)
    add(db, amount=25.0, days=1.0)
    add(db, amount=25.0, days=40.0)
    rep = report_holdings(db, now=NOW)
    assert [h.amount for h in rep.urgent] == [25.0, 25.0]
    assert rep.urgent[0].days_left(NOW) < rep.urgent[1].days_left(NOW)
    assert "expiring within 3 days" in rep.verdict()


def test_what_expired_unused_is_counted_and_named(db):
    """The number nobody else shows, and the one that changes behaviour."""
    add(db, amount=100.0, days=2.0)
    add(db, amount=60.0, days=90.0)
    rep = report_holdings(db, now=NOW + 5 * DAY)
    assert rep.lost_to_expiry == pytest.approx(100.0)
    assert rep.face == pytest.approx(60.0)
    assert "100 face already lost to expiry" in rep.verdict()


def test_a_used_promo_is_neither_held_nor_lost(db):
    promo_id = add(db, amount=100.0, days=2.0)
    db.use_promo(promo_id, realised=80.0, used_at=NOW)
    rep = report_holdings(db, now=NOW + 5 * DAY)
    assert rep.face == 0.0
    assert rep.lost_to_expiry == 0.0


def test_an_empty_ledger_says_so(db):
    assert report_holdings(db, now=NOW).verdict() == "no promotions recorded"
    assert report_holdings(db, now=NOW).value == 0.0


def test_holdings_can_be_filtered_by_book(db):
    add(db, book="dk")
    add(db, book="fd")
    assert len(db.promos(state="held", book="dk", now=NOW)) == 1


def test_a_v7_database_migrates_to_v8(tmp_path):
    from overlay_engine.ledger import SCHEMA_VERSION

    path = tmp_path / "v7.db"
    with Ledger(path) as db:
        db.record_promo(book="dk", kind="bonus_bet", amount=50.0,
                        received_at=NOW)
        db.conn.execute("DROP TABLE promos")
        db.conn.execute("UPDATE meta SET value = '7' WHERE key = 'schema_version'")
        db.conn.commit()

    with Ledger(path) as db:
        assert db.promos(now=NOW) == []
        db.record_promo(book="fd", kind="bonus_bet", amount=25.0,
                        received_at=NOW)
        assert len(db.promos(state="held", now=NOW)) == 1
        row = db.conn.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        assert int(row["value"]) == SCHEMA_VERSION
