"""Odds conversion, and the hole in American odds."""

import pytest

from overlay_engine.odds import (
    OddsError,
    Price,
    american_to_decimal,
    american_to_prob,
    decimal_to_american,
    decimal_to_prob,
    hold,
    overround,
    parse_odds,
    prob_to_american,
    prob_to_decimal,
)


@pytest.mark.parametrize(
    "american,decimal",
    [
        (100, 2.0),
        (-100, 2.0),
        (150, 2.5),
        (-200, 1.5),
        (-110, 1.9090909090909092),
        (500, 6.0),
        (-1000, 1.1),
    ],
)
def test_american_to_decimal(american, decimal):
    assert american_to_decimal(american) == pytest.approx(decimal)


@pytest.mark.parametrize("american", [150, -200, -110, 2500, -3000])
def test_conversion_round_trips(american):
    assert decimal_to_american(american_to_decimal(american)) == pytest.approx(american)


def test_even_money_resolves_to_plus_100():
    """2.0 is +100 and -100 at once; every US book shows +100."""
    assert decimal_to_american(2.0) == 100.0


@pytest.mark.parametrize("bad", [0, 50, -50, 99.9, -99.9])
def test_the_hole_in_american_odds_is_rejected(bad):
    with pytest.raises(OddsError):
        american_to_decimal(bad)


@pytest.mark.parametrize("bad", [1.0, 0.5, 0.0, -2.0])
def test_decimal_odds_at_or_below_one_are_rejected(bad):
    with pytest.raises(OddsError):
        decimal_to_american(bad)
    with pytest.raises(OddsError):
        decimal_to_prob(bad)


def test_probability_round_trip():
    assert prob_to_decimal(0.25) == pytest.approx(4.0)
    assert decimal_to_prob(4.0) == pytest.approx(0.25)
    assert prob_to_american(0.5) == pytest.approx(100.0)
    assert american_to_prob(-110) == pytest.approx(0.5238095238)


@pytest.mark.parametrize("bad", [0.0, 1.0, -0.1, 1.5])
def test_probability_bounds_are_enforced(bad):
    with pytest.raises(OddsError):
        prob_to_decimal(bad)


@pytest.mark.parametrize(
    "text,decimal",
    [
        ("+150", 2.5),
        ("-200", 1.5),
        (" -110 ", 1.9090909090909092),
        ("2.5", 2.5),
        ("250", 3.5),
        (2.5, 2.5),
        (-110, 1.9090909090909092),
        ("+1,500", 16.0),
    ],
)
def test_parse_odds_reads_every_form(text, decimal):
    assert parse_odds(text) == pytest.approx(decimal)


def test_parse_odds_resolves_100_as_american():
    """100 is both a decimal price and +100. +100 is the real-world quote."""
    assert parse_odds(100) == pytest.approx(2.0)


@pytest.mark.parametrize("bad", ["", "abc", 0.5, 1.0])
def test_parse_odds_rejects_nonsense(bad):
    with pytest.raises((OddsError, ValueError)):
        parse_odds(bad)


def test_overround_of_a_standard_juiced_market():
    """-110 both sides is the canonical 4.76% hold."""
    both = [american_to_decimal(-110), american_to_decimal(-110)]
    assert overround(both) == pytest.approx(1.047619, abs=1e-6)
    assert hold(both) == pytest.approx(0.0454545, abs=1e-6)


def test_hold_is_not_the_overround_excess():
    """A 1.05 overround holds 4.76%, not 5%. The distinction is the test."""
    market = [prob_to_decimal(0.525), prob_to_decimal(0.525)]
    assert overround(market) == pytest.approx(1.05)
    assert hold(market) == pytest.approx(0.047619, abs=1e-6)
    assert hold(market) != pytest.approx(0.05, abs=1e-4)


def test_overround_below_one_is_an_arb_not_an_error():
    assert overround([2.1, 2.1]) < 1.0
    assert hold([2.1, 2.1]) < 0.0


def test_overround_needs_outcomes():
    with pytest.raises(OddsError):
        overround([])


def test_price_carries_its_own_age():
    p = Price(book="pinnacle", decimal=2.5, seen_at=1000.0)
    assert p.age(1012.0) == pytest.approx(12.0)
    assert p.american == pytest.approx(150.0)
    assert p.implied == pytest.approx(0.4)


def test_price_age_never_goes_negative():
    """Clock skew between a feed and the local machine is routine; a negative
    age would feed a fill probability above 1."""
    p = Price(book="dk", decimal=2.0, seen_at=1000.0)
    assert p.age(990.0) == 0.0


def test_price_rejects_an_impossible_decimal():
    with pytest.raises(OddsError):
        Price(book="dk", decimal=1.0, seen_at=0.0)
