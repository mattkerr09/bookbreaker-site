"""Two scripts share `dist/` and `build/`, and one of them used to wipe both.

`scripts/release.sh` builds the Python wheel and sdist into `dist/`.
`scripts/build_app.sh --ship` puts the notarised DMG into `dist/` and the
stapled zip into `build/`. release.sh opened with `rm -rf dist build`, which
is the correct instinct for a reproducible build and the wrong blast radius:
running it after a ship deleted a freshly notarised application that had just
cost four minutes of Apple's notary service.

Nothing failed. Both scripts printed OK. The DMG was simply gone, and the only
reason it was noticed is that someone looked for it.

These tests pin the boundary rather than the wording, so a future rewrite of
either script is free as long as neither destroys the other's output.
"""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RELEASE = (ROOT / "scripts" / "release.sh").read_text()
BUILD = (ROOT / "scripts" / "build_app.sh").read_text()


def _removals(script: str) -> list[str]:
    """Every path this script deletes."""
    out = []
    for line in script.splitlines():
        line = line.split("#", 1)[0].strip()
        for match in re.finditer(r"\brm\s+(-[a-zA-Z]+\s+)*(.+)", line):
            out.extend(match.group(2).split("||")[0].split())
    return [p for p in out if p and not p.startswith("-")]


def test_release_does_not_delete_the_whole_dist_directory():
    """The specific line that destroyed a notarised build."""
    removed = _removals(RELEASE)
    assert "dist" not in removed
    assert "build" not in removed


def test_release_removes_nothing_from_dist_but_python_artefacts():
    """Temp directories are its own business. What it must never do is take a
    file out of dist/ that it did not put there."""
    for path in _removals(RELEASE):
        if not path.startswith("dist/"):
            continue                    # temp dirs, egg-info, its own build tree
        assert path.endswith((".whl", ".tar.gz")), path


def test_the_app_build_does_not_delete_the_wheel():
    """The same collision in the other direction."""
    for path in _removals(BUILD):
        assert not path.endswith((".whl", ".tar.gz")), path
        assert path not in ("dist", "dist/", "dist/*"), path


def test_both_scripts_still_write_where_the_site_stages_from():
    """If either moved its output elsewhere these tests would pass while the
    download page silently lost an artefact."""
    assert "dist/" in RELEASE
    assert 'DMG="dist/Bookbreaker-' in BUILD
