"""Schema v2, per-book probabilities, and book-weight calibration."""

import pytest

from overlay_engine.calibrate import (
    MIN_BOOK_COVERAGE,
    apply_book_weights,
    book_blended,
    book_scope_key,
    book_score,
    book_weights_for,
    calibrate_all,
    calibrate_books,
)
from overlay_engine.fair import fair_value
from overlay_engine.ledger import SCHEMA_VERSION, AtBet, Ledger, LedgerError
from overlay_engine.models import Book, BookTier, Market, Outcome, Quote

PIN = Book("pinnacle", "Pinnacle", BookTier.SHARP, limits_winners=False)
CIRCA = Book("circa", "Circa", BookTier.SHARP, limits_winners=False)
DK = Book("dk", "DraftKings", BookTier.RETAIL)
FD = Book("fd", "FanDuel", BookTier.RETAIL)
BOOKS = {b.key: b for b in (PIN, CIRCA, DK, FD)}

DEVIG = {"power": 0.50, "shin": 0.50, "additive": 0.50, "multiplicative": 0.50}


def place(db, i, book_probs, closing=0.50, sport="nfl", market="h2h"):
    bet_id = db.record_bet(
        event_id=f"e{i}", sport=sport, market_type=market, outcome="home",
        book="dk", decimal_odds=2.10, stake=100.0, placed_at=1000.0 + i,
        at_bet=AtBet(fair_prob=0.50, fair_low=0.47, fair_high=0.53,
                     devig=dict(DEVIG), book_probs=book_probs),
    )
    db.settle(bet_id, closing_fair_prob=closing)
    return bet_id


def fill(db, n, *, good="pinnacle", bad="dk", closing=0.50, start=0, **over):
    """n bets where `good` sits on the close and `bad` sits well off it."""
    for i in range(start, start + n):
        place(db, i, {good: closing, bad: closing + 0.06,
                      "circa": closing + 0.005, "fd": closing + 0.03},
              closing=closing, **over)


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "books.db") as ledger:
        yield ledger


# ------------------------------------------------------------- the migration


def test_a_fresh_database_is_stamped_current(db):
    """Asserts against SCHEMA_VERSION rather than a literal. Two tests here
    hard-coded `2` and both broke the moment v3 landed, which is a test failing
    for a reason that has nothing to do with what it checks."""
    row = db.conn.execute(
        "SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
    assert int(row["value"]) == SCHEMA_VERSION
    assert db._has_column("bets", "book_probs")


def test_a_v1_database_with_rows_migrates_without_losing_them(tmp_path):
    """The one irreplaceable asset in this repo is months of bets nobody can
    re-observe. A migration gets exactly one chance."""
    path = tmp_path / "v1.db"
    with Ledger(path) as db:
        for i in range(3):
            place(db, i, {"pinnacle": 0.50})
        # Rewind to v1 and drop the v2 column, reproducing a real old database.
        db.conn.execute("ALTER TABLE bets DROP COLUMN book_probs")
        db.conn.execute("UPDATE meta SET value = '1' WHERE key = 'schema_version'")
        db.conn.commit()

    with Ledger(path) as db:
        assert db.stats()["bets"] == 3
        assert db.stats()["graded"] == 3
        row = db.conn.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        assert int(row["value"]) == SCHEMA_VERSION
        assert db._has_column("bets", "book_probs")


def test_pre_v2_rows_report_no_book_probabilities_rather_than_guessing(tmp_path):
    """Empty means nobody wrote the number down, not that no book contributed."""
    path = tmp_path / "v1.db"
    with Ledger(path) as db:
        bet_id = place(db, 0, {"pinnacle": 0.50})
        db.conn.execute("ALTER TABLE bets DROP COLUMN book_probs")
        db.conn.execute("UPDATE meta SET value = '1' WHERE key = 'schema_version'")
        db.conn.commit()

    with Ledger(path) as db:
        assert db.book_probs_at_bet(bet_id) == {}
        assert db.devig_at_bet(bet_id)["power"] == pytest.approx(0.50)


def test_migrating_twice_is_a_no_op(tmp_path):
    """Opening an already-current database must not re-run the ALTER, which
    would raise on the second open and make every later session fail."""
    path = tmp_path / "twice.db"
    with Ledger(path) as db:
        place(db, 0, {"pinnacle": 0.50})

    for _ in range(3):
        with Ledger(path) as db:
            assert db.stats()["bets"] == 1
            assert db._has_column("bets", "book_probs")
            row = db.conn.execute(
                "SELECT value FROM meta WHERE key = \'schema_version\'").fetchone()
            assert int(row["value"]) == SCHEMA_VERSION


def test_a_newer_schema_is_still_refused(tmp_path):
    path = tmp_path / "future.db"
    with Ledger(path) as db:
        db.conn.execute("UPDATE meta SET value = ? WHERE key = 'schema_version'",
                        (str(SCHEMA_VERSION + 1),))
        db.conn.commit()
    with pytest.raises(LedgerError, match="newer Overlay"):
        Ledger(path)


# --------------------------------------------------------- storing and reading


def test_book_probabilities_round_trip(db):
    bet_id = place(db, 0, {"pinnacle": 0.51, "dk": 0.56})
    assert db.book_probs_at_bet(bet_id) == {"pinnacle": 0.51, "dk": 0.56}


def test_book_probabilities_are_optional(db):
    """A bet without them is still gradeable and still trains method weights."""
    bet_id = place(db, 0, {})
    assert db.book_probs_at_bet(bet_id) == {}
    assert len(db.graded_bets()) == 1


@pytest.mark.parametrize("prob", [0.0, 1.0, -0.2, 1.3])
def test_an_impossible_book_probability_is_refused(db, prob):
    with pytest.raises(LedgerError, match="book_probs"):
        place(db, 0, {"pinnacle": prob})


def test_book_candidates_align_with_graded_bets(db):
    fill(db, 5)
    candidates = db.book_candidates()
    assert len(candidates) == len(db.graded_bets())
    assert all(set(c) == {"pinnacle", "dk", "circa", "fd"} for c in candidates)


def test_book_candidates_keep_the_raggedness_visible(db):
    """No book prices every market. Intersecting across bets, the way method
    candidates do, would leave almost nothing."""
    place(db, 0, {"pinnacle": 0.50, "dk": 0.55})
    place(db, 1, {"circa": 0.51})
    assert db.book_candidates() == [{"pinnacle": 0.50, "dk": 0.55}, {"circa": 0.51}]


def test_book_probs_rejects_an_unknown_id(db):
    with pytest.raises(LedgerError, match="no bet"):
        db.book_probs_at_bet(999)


# ----------------------------------------------------------------- the blend


def test_the_book_blend_matches_fair_value():
    """`fair_value` blends books in logit space, not probability space. A local
    reimplementation is exactly how the two would drift apart."""
    market = Market(
        event_id="e1", sport="nfl", market_type="h2h",
        quotes=[
            Quote(book="pinnacle", outcome=Outcome("home"), decimal=1.80, seen_at=0),
            Quote(book="pinnacle", outcome=Outcome("away"), decimal=2.15, seen_at=0),
            Quote(book="circa", outcome=Outcome("home"), decimal=1.90, seen_at=0),
            Quote(book="circa", outcome=Outcome("away"), decimal=2.02, seen_at=0),
        ],
    )
    weights = {"pinnacle": 3.0, "circa": 1.0}
    engine = fair_value(market, BOOKS, book_weights=weights)["home"].prob

    from overlay_engine.devig import devig_all
    probs = {
        "pinnacle": devig_all([1.80, 2.15]).consensus(0),
        "circa": devig_all([1.90, 2.02]).consensus(0),
    }
    assert book_blended(probs, weights) == pytest.approx(engine, abs=1e-9)


def test_the_book_blend_is_not_an_arithmetic_mean():
    """Averaging probabilities near the edges biases toward the middle, and
    longshots are where phantom edges live."""
    probs = {"a": 0.02, "b": 0.10}
    assert book_blended(probs, None) < (0.02 + 0.10) / 2


def test_blending_with_no_usable_weights_falls_back_to_equal():
    probs = {"a": 0.30, "b": 0.60}
    assert book_blended(probs, {"z": 1.0}) == pytest.approx(book_blended(probs, None))


def test_blending_an_empty_book_set_is_refused():
    with pytest.raises(ValueError):
        book_blended({}, None)


def test_book_score_skips_bets_with_nothing_recorded():
    """A pre-v2 row is missing data, not evidence of a perfect prediction."""
    from overlay_engine.clv import GradedBet

    bet = GradedBet(bet_id="1", sport="nfl", market_type="h2h", book="dk",
                    decimal=2.0, stake=100.0, fair_prob_at_bet=0.5,
                    closing_fair_prob=0.5)
    assert book_score([bet], [{}], None) == float("inf")
    assert book_score([bet], [{"pinnacle": 0.5}], None) == pytest.approx(0.0)


# ----------------------------------------------------------------- the gates


def test_calibration_refuses_a_small_sample(db):
    fill(db, 12)
    result = calibrate_books(db)
    assert not result.accepted
    assert "need 30" in result.reason


def test_calibration_refuses_when_the_rows_predate_the_column(db):
    """A ledger full of pre-v2 bets cannot say how wrong any book was, and
    must say that rather than fitting on the handful that can."""
    for i in range(40):
        place(db, i, {})
    result = calibrate_books(db)
    assert not result.accepted
    assert "schema v2" in result.reason


def test_a_book_below_the_coverage_floor_is_not_weighted(db):
    """Scoring a book on the eight markets it happened to quote, then trusting
    that against a book scored on two hundred, is the subset problem."""
    for i in range(40):
        place(db, i, {"pinnacle": 0.50, "dk": 0.56,
                      **({"circa": 0.50} if i < 5 else {})})
    result = calibrate_books(db)
    assert "circa" not in result.weights


def test_fewer_than_two_eligible_books_refuses(db):
    for i in range(40):
        place(db, i, {"pinnacle": 0.50})
    result = calibrate_books(db)
    assert not result.accepted
    assert "at least two" in result.reason


def two_book_fill(db, n, *, accurate, wrong, start=0, closing=0.50):
    """n bets priced by exactly two books, one on the close and one off it.

    Two books only, on purpose. The four-book `fill` helper keeps `circa` near
    the close in every slice, so an inversion of pinnacle and dk left circa
    winning both halves and the candidate was correctly accepted — the test
    read as a broken gate when the gate was fine and the fixture was not.
    """
    for i in range(start, start + n):
        place(db, i, {accurate: closing, wrong: closing + 0.06}, closing=closing)


def test_calibration_refuses_weights_that_lose_out_of_sample(db):
    """Same gate as method calibration: train where pinnacle is best, hold out
    where it is worst, and the candidate must be discarded."""
    two_book_fill(db, 40, accurate="pinnacle", wrong="dk", start=0)
    two_book_fill(db, 20, accurate="dk", wrong="pinnacle", start=100)
    result = calibrate_books(db, holdout=0.3)
    assert not result.accepted
    assert "no better" in result.reason
    assert book_weights_for(db) == (None, None)


def test_the_holdout_is_temporal_here_too(db):
    fill(db, 60)
    result = calibrate_books(db)
    assert result.n_train == 42
    assert result.n_holdout == 18


# -------------------------------------------------------------- the successes


def test_the_sharpest_predictor_gets_the_most_weight(db):
    fill(db, 60, good="pinnacle", bad="dk")
    result = calibrate_books(db)
    assert result.accepted
    assert max(result.weights, key=result.weights.get) == "pinnacle"
    assert result.candidate_score < result.incumbent_score


def test_a_soft_book_is_demoted_not_deleted(db):
    fill(db, 60, good="pinnacle", bad="dk")
    weights = calibrate_books(db).weights
    assert weights["dk"] > 0
    assert weights["dk"] < weights["pinnacle"]


def test_the_floor_scales_with_the_number_of_books(db):
    """A flat 0.05 floor stops working past 20 books; it must scale rather
    than raise."""
    many = {f"book{i}": 0.55 for i in range(25)}
    many["pinnacle"] = 0.50
    for i in range(60):
        place(db, i, dict(many))
    result = calibrate_books(db)
    assert result.accepted
    assert sum(result.weights.values()) == pytest.approx(1.0)
    assert min(result.weights.values()) > 0


def test_accepted_weights_carry_their_age(db):
    fill(db, 60, good="pinnacle")
    calibrate_books(db)
    weights, age = book_weights_for(db)
    assert max(weights, key=weights.get) == "pinnacle"
    assert age is not None and age < 5.0


def test_a_second_run_declines(db):
    fill(db, 60, good="pinnacle")
    assert calibrate_books(db).accepted
    assert not calibrate_books(db).accepted


def test_method_and_book_scopes_do_not_collide(db):
    assert book_scope_key(None, None) != "method_weights.global"
    assert book_scope_key("nfl", "moneyline") == "book_weights.nfl.moneyline"


def test_calibrate_all_covers_both_kinds(db):
    fill(db, 60, good="pinnacle")
    scopes = {r.scope for r in calibrate_all(db)}
    assert "method_weights.global" in scopes
    assert "book_weights.global" in scopes


def test_coverage_floor_is_stated_not_magic():
    assert MIN_BOOK_COVERAGE == 20


# ----------------------------------------------------------------- applying


def test_calibrated_weights_are_rescaled_onto_the_tier_scale():
    """Handing `fair_value` a mix of normalised values (~0.2) and raw tier
    defaults (1.0 for a sharp book) would let one uncovered sharp book swamp
    every measured one."""
    calibrated = {"pinnacle": 0.7, "dk": 0.3}
    applied = apply_book_weights(calibrated, BOOKS)
    assert applied["pinnacle"] > applied["dk"]
    covered = applied["pinnacle"] + applied["dk"]
    assert covered == pytest.approx(PIN.weight + DK.weight)


def test_an_uncovered_book_keeps_its_default():
    applied = apply_book_weights({"pinnacle": 1.0}, BOOKS)
    assert applied["fd"] == pytest.approx(FD.weight)
    assert applied["circa"] == pytest.approx(CIRCA.weight)


def test_no_calibration_means_pure_tier_defaults():
    assert apply_book_weights({}, BOOKS) == {k: b.weight for k, b in BOOKS.items()}
    assert apply_book_weights({"unknown_book": 1.0}, BOOKS) == {
        k: b.weight for k, b in BOOKS.items()
    }


def test_applied_weights_change_a_fair_value(db):
    """End to end: calibrated book weights must actually move the number the
    engine prices with, or the whole loop is decorative."""
    market = Market(
        event_id="e1", sport="nfl", market_type="h2h",
        quotes=[
            Quote(book="pinnacle", outcome=Outcome("home"), decimal=1.80, seen_at=0),
            Quote(book="pinnacle", outcome=Outcome("away"), decimal=2.15, seen_at=0),
            Quote(book="circa", outcome=Outcome("home"), decimal=2.10, seen_at=0),
            Quote(book="circa", outcome=Outcome("away"), decimal=1.80, seen_at=0),
        ],
    )
    default = fair_value(market, BOOKS)["home"].prob
    tilted = fair_value(
        market, BOOKS,
        book_weights=apply_book_weights({"pinnacle": 0.95, "circa": 0.05}, BOOKS),
    )["home"].prob
    assert tilted != pytest.approx(default)
    assert abs(tilted - 0.5528) < abs(default - 0.5528) or tilted < default
