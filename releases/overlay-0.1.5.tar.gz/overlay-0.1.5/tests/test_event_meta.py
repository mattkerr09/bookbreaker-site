"""Twelve overs riding one starting pitcher are one bet, and only recorded
metadata can say so.

The danger is not that metadata is missing. It is that missing metadata looks
exactly like recorded metadata with a blank value, and a blank groups every
unrecorded event into one enormous block that comes back as correlation.
"""

import math
import random

import pytest

from overlay_engine.correlation import (
    META_KEYS,
    MIN_COVERAGE,
    MIN_GROUPS,
    SCHEMA_KEYS,
    CorrelationError,
    from_ledger,
    measure,
)
from overlay_engine.kelly import DEFAULT_CORRELATION
from overlay_engine.ledger import Ledger, LedgerError

DAY = 86_400.0


def _rows(groups, per_group, rho, seed=1, starters=True):
    """Bets correlated within a starter, spread across distinct events."""
    rng = random.Random(seed)
    rows, meta = [], {}
    for g in range(groups):
        shared = rng.gauss(0.0, 1.0)
        for i in range(per_group):
            r = math.sqrt(rho) * shared + math.sqrt(1 - rho) * rng.gauss(0.0, 1.0)
            event = f"g{g}-{i}"          # every bet its own event
            rows.append({"event_id": event, "sport": "mlb",
                         "placed_at": g * DAY, "stake": 100.0,
                         "profit": r * 100.0})
            if starters:
                meta[event] = {"starter": f"pitcher{g}"}
    return rows, meta


# ------------------------------------------------------------- the schema

def test_the_migration_is_additive(tmp_path):
    """An existing database opens, keeps its rows, and gains the table."""
    path = str(tmp_path / "m.db")
    with Ledger(path) as db:
        db.import_bet(event_id="e1", sport="nfl", market_type="h2h",
                      outcome="home", book="dk", decimal_odds=2.0, stake=50.0,
                      placed_at=1.0, result="won", profit=50.0, external_ref="a")
    with Ledger(path) as db:
        assert db.stats()["bets"] == 1
        db.record_event_meta(event_id="e1", starter="deGrom")
        assert db.event_meta()["e1"]["starter"] == "deGrom"


def test_recording_an_event_twice_updates_rather_than_duplicates(tmp_path):
    """Two rows disagreeing about who started would make the grouping depend
    on which one a query read first."""
    with Ledger(str(tmp_path / "m.db")) as db:
        db.record_event_meta(event_id="e1", starter="deGrom")
        db.record_event_meta(event_id="e1", venue="Citi Field")
        got = db.event_meta()["e1"]
    assert got == {"starter": "deGrom", "venue": "Citi Field"}


def test_a_blank_value_is_stored_as_absent_not_as_a_value(tmp_path):
    with Ledger(str(tmp_path / "m.db")) as db:
        db.record_event_meta(event_id="e1", starter="   ", venue="Wrigley")
        assert "starter" not in db.event_meta()["e1"]


def test_a_row_of_nothing_is_refused(tmp_path):
    """A NULL row counts as coverage while carrying none."""
    with Ledger(str(tmp_path / "m.db")) as db:
        with pytest.raises(LedgerError, match="nothing to record"):
            db.record_event_meta(event_id="e1")


def test_an_event_with_no_id_is_refused(tmp_path):
    with Ledger(str(tmp_path / "m.db")) as db:
        with pytest.raises(LedgerError, match="an event needs an id"):
            db.record_event_meta(event_id="", starter="x")


def test_coverage_counts_events_that_actually_carry_bets(tmp_path):
    with Ledger(str(tmp_path / "m.db")) as db:
        for i in range(4):
            db.import_bet(event_id=f"e{i}", sport="mlb", market_type="h2h",
                          outcome="home", book="dk", decimal_odds=2.0,
                          stake=10.0, placed_at=1.0, external_ref=f"r{i}")
        db.record_event_meta(event_id="e0", starter="a")
        db.record_event_meta(event_id="unrelated", starter="b")
        assert db.meta_coverage("starter") == (1, 4)


def test_an_unknown_metadata_field_is_refused(tmp_path):
    with Ledger(str(tmp_path / "m.db")) as db:
        with pytest.raises(LedgerError, match="unknown metadata field"):
            db.meta_coverage("mood")


# ------------------------------------------------------------- grouping

def test_a_shared_starter_finds_correlation_no_schema_key_can_see():
    """Every bet is on a different event on a different day. `event`, `day`
    and `sport_day` are all blind to this; the starter is not."""
    rows, meta = _rows(300, 4, 0.5, seed=3)
    assert not measure(rows, key="event").measured
    by_starter = measure(rows, key="starter", meta=meta)
    assert by_starter.measured
    assert by_starter.rho == pytest.approx(0.5, abs=0.1)


def test_grouping_by_venue_groups_on_the_recorded_string():
    rows, _ = _rows(300, 4, 0.5, seed=4, starters=False)
    for i, row in enumerate(rows):
        row["event_id"] = f"ev{i}"
    meta = {row["event_id"]: {"venue": f"venue{i // 4}"}
            for i, row in enumerate(rows)}
    assert measure(rows, key="venue", meta=meta).measured


def test_grouping_by_weather_groups_on_the_bucket_not_the_string():
    """Weather is banded before grouping, so notes that differ by a mile an
    hour land together instead of each forming a group of one."""
    rows, _ = _rows(300, 4, 0.5, seed=4, starters=False)
    for i, row in enumerate(rows):
        row["event_id"] = f"ev{i}"
    notes = ["dome", "wind 4mph", "wind 20mph rain", "snow"]
    meta = {row["event_id"]: {"weather": notes[(i // 4) % len(notes)]}
            for i, row in enumerate(rows)}
    got = measure(rows, key="weather", meta=meta)
    assert got.coverage == 1.0
    assert got.groups == len(notes)      # bucketed, not one group per event


def test_weather_cannot_clear_the_group_count_and_says_why():
    """The honest consequence of bucketing, and it is not a bug.

    Banding caps the number of groups at the number of buckets, and that
    ceiling sits at the group-count bar. Weather therefore returns the prior
    almost always, and the refusal explains that this is a property of the
    grouping rather than a shortage in the record.
    """
    from overlay_engine.weather import buckets

    rows, _ = _rows(300, 4, 0.5, seed=4, starters=False)
    for i, row in enumerate(rows):
        row["event_id"] = f"ev{i}"
    notes = ["dome", "wind 4mph", "wind 20mph rain", "snow"]
    meta = {row["event_id"]: {"weather": notes[(i // 4) % len(notes)]}
            for i, row in enumerate(rows)}
    got = measure(rows, key="weather", meta=meta)
    assert not got.measured
    assert MIN_GROUPS >= len(buckets())          # the bar is at the ceiling
    shown = got.describe()
    assert "buckets occupied" in shown
    assert "property of bucketing" in shown


def test_opaque_labels_are_not_weather_and_are_excluded():
    rows, _ = _rows(300, 4, 0.5, seed=4, starters=False)
    for i, row in enumerate(rows):
        row["event_id"] = f"ev{i}"
    meta = {row["event_id"]: {"weather": f"weather{i // 4}"}
            for i, row in enumerate(rows)}
    got = measure(rows, key="weather", meta=meta)
    assert got.coverage == 0.0
    assert not got.measured


def test_asking_for_a_metadata_key_without_metadata_raises():
    """A caller error, not a data shortage — silently returning the prior would
    hide a wiring mistake behind a plausible number."""
    rows, _ = _rows(50, 4, 0.4)
    with pytest.raises(CorrelationError, match="needs recorded event metadata"):
        measure(rows, key="starter")


def test_schema_keys_never_demand_metadata():
    rows, _ = _rows(300, 4, 0.4, seed=5)
    for key in SCHEMA_KEYS:
        assert measure(rows, key=key).coverage == 1.0


# ------------------------------------------------------------- the guard

def test_unrecorded_events_are_excluded_rather_than_lumped_together():
    """The failure this guard exists for.

    Group every unrecorded event under a blank and they become one enormous
    block whose combined swing reads as correlation. Excluded, the estimate is
    simply measured over fewer bets — and the coverage figure says how many.
    """
    rows, meta = _rows(300, 4, 0.5, seed=6)
    for row in rows[:600]:
        meta.pop(row["event_id"], None)
    got = measure(rows, key="starter", meta=meta)
    assert got.coverage == pytest.approx(0.5, abs=0.02)
    assert got.rho == pytest.approx(0.5, abs=0.15)


def test_sparse_metadata_is_refused_rather_than_measured_over_a_subsample():
    rows, meta = _rows(300, 4, 0.5, seed=7)
    keep = {row["event_id"] for row in rows[:120]}       # 10% of bets
    meta = {k: v for k, v in meta.items() if k in keep}
    got = measure(rows, key="starter", meta=meta)
    assert got.coverage < MIN_COVERAGE
    assert not got.measured
    assert got.rho == DEFAULT_CORRELATION


def test_the_refusal_says_which_field_was_too_sparse():
    rows, meta = _rows(300, 4, 0.5, seed=8)
    keep = {row["event_id"] for row in rows[:120]}
    meta = {k: v for k, v in meta.items() if k in keep}
    shown = measure(rows, key="starter", meta=meta).describe()
    assert "starter recorded for" in shown
    assert "not your book" in shown


def test_coverage_just_above_the_bar_is_measured():
    rows, meta = _rows(300, 4, 0.5, seed=9)
    drop = {row["event_id"] for row in rows[:520]}      # keep ~57%
    meta = {k: v for k, v in meta.items() if k not in drop}
    got = measure(rows, key="starter", meta=meta)
    assert got.coverage > MIN_COVERAGE
    assert got.measured


def test_no_metadata_at_all_is_zero_coverage_not_a_crash():
    rows, _ = _rows(300, 4, 0.5, seed=10)
    got = measure(rows, key="starter", meta={})
    assert got.coverage == 0.0
    assert not got.measured


def test_every_meta_key_is_a_column_the_ledger_records(tmp_path):
    """The two lists must not drift: a key here with no column is a grouping
    that can never have coverage."""
    with Ledger(str(tmp_path / "m.db")) as db:
        assert set(META_KEYS) == set(db.META_FIELDS)


# ------------------------------------------------------------- end to end

def test_from_ledger_groups_by_a_recorded_starter(tmp_path):
    rows, meta = _rows(80, 4, 0.5, seed=11)
    with Ledger(str(tmp_path / "e.db")) as db:
        for i, row in enumerate(rows):
            db.import_bet(
                event_id=row["event_id"], sport="mlb", market_type="h2h",
                outcome="home", book="dk", decimal_odds=2.0,
                stake=row["stake"], placed_at=row["placed_at"],
                result="won" if row["profit"] > 0 else "lost",
                profit=row["profit"], external_ref=f"x{i}")
        for event, fields in meta.items():
            db.record_event_meta(event_id=event, **fields)
        got = from_ledger(db, key="starter")
    assert got.measured
    assert got.rho == pytest.approx(0.5, abs=0.15)


def test_from_ledger_does_not_load_metadata_it_does_not_need(tmp_path):
    """A book that never records a starter pays nothing for the feature."""
    with Ledger(str(tmp_path / "e.db")) as db:
        db.event_meta = lambda: (_ for _ in ()).throw(
            AssertionError("metadata loaded for a schema grouping"))
        assert not from_ledger(db, key="event").measured
