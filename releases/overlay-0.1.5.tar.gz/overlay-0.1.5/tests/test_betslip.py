"""The betslip parser's job is to be checkable, not clever."""

import pytest

from overlay_engine.betslip import (
    MARKET_WORDS,
    RESULT_WORDS,
    Parsed,
    implied,
    parse,
    to_import,
)

DRAFTKINGS = """DraftKings
Straight
Los Angeles Lakers -3.5 (-110)
Wager $50.00   To Win $45.45
Placed 1/5/2026 1:20 PM
"""

FANDUEL = """FanDuel
Moneyline
Boston Celtics +145
Risk 25.00
Win 36.25
Won
"""

DECIMAL_SLIP = """Pinnacle
Total Over 220.5 @ 1.95
Stake $100.00
"""


def test_a_straight_slip_reads_end_to_end():
    got = parse(DRAFTKINGS)
    assert got.usable
    assert got.get("book") == "dk"
    assert got.get("market_type") == "spreads"
    assert got.get("stake") == 50.0
    assert got.get("decimal_odds") == pytest.approx(1.909, abs=1e-3)
    assert "Lakers" in got.get("outcome")


def test_every_field_carries_the_text_it_came_from():
    """The whole safety argument rests on this being checkable by eye."""
    got = parse(DRAFTKINGS)
    for name, found in got.fields.items():
        assert found.source, f"{name} has no source text"
        if name != "profit":  # profit is derived, not read
            assert found.source in DRAFTKINGS or found.source.strip() in DRAFTKINGS


def test_a_slip_with_no_price_is_refused_not_guessed():
    got = parse("DraftKings\nLakers to cover\nWager $50.00\n")
    assert not got.usable
    assert "decimal_odds" in got.needs
    with pytest.raises(ValueError, match="decimal_odds"):
        to_import(got, event_id="e1")


def test_a_slip_with_no_stake_is_refused_not_guessed():
    got = parse("DraftKings\nLakers -3.5 (-110)\n")
    assert not got.usable
    assert "stake" in got.needs


def test_empty_text_is_refused():
    got = parse("   \n\n  ")
    assert not got.usable
    assert set(got.needs) == {"decimal_odds", "stake"}


def test_the_to_win_number_is_never_read_as_the_stake():
    """`To Win $45.45` sits on the same line as `Wager $50.00`.

    Reading the wrong one understates the stake and inflates every return
    computed from it — the same failure the CSV importer guards, arriving by a
    different route.
    """
    got = parse(DRAFTKINGS)
    assert got.get("stake") == 50.0
    assert got.get("stake") != 45.45


def test_an_unsettled_slip_showing_a_payout_is_not_recorded_as_a_win():
    """The most expensive misreading available, and it looks harmless.

    Every unsettled DraftKings slip carries `To Win $45.45`. Read that as a
    result and the ledger gains a winning bet that has not happened, with a
    profit to match — invisible once it is a row, and it inflates every ROI,
    every CLV score and every calibration weight computed from it afterwards.
    """
    got = parse(DRAFTKINGS)  # has "To Win $45.45" and no result word
    assert got.get("result") is None
    assert got.get("profit") is None


def test_a_bare_win_label_above_a_payout_is_not_a_result_either():
    got = parse("FanDuel\nCeltics +145\nRisk 25.00\nWin 36.25\n")
    assert got.get("result") is None


def test_profit_is_derived_from_stake_and_price_not_read_off_the_slip():
    got = parse(FANDUEL)
    assert got.get("result") == "won"  # from the "Won" line, not "Win 36.25"
    # +145 on 25.00 is 36.25 profit. The slip prints it too, but the derived
    # number is the one used, because some books put the total return there.
    assert got.get("profit") == pytest.approx(36.25, abs=0.01)
    assert "derived" in got.fields["profit"].source


def test_a_losing_bet_derives_a_negative_profit_of_exactly_the_stake():
    got = parse("DraftKings\nLakers -3.5 (-110)\nWager $50.00\nLost\n")
    assert got.get("profit") == -50.0


def test_a_push_derives_zero_not_the_stake_back():
    got = parse("DraftKings\nLakers -3.0 (-110)\nWager $50.00\nPush\n")
    assert got.get("profit") == 0.0


def test_an_open_bet_gets_no_result_and_no_profit():
    got = parse("DraftKings\nLakers -3.5 (-110)\nWager $50.00\nPending\n")
    assert got.usable
    assert got.get("result") is None
    assert got.get("profit") is None


def test_decimal_prices_parse_when_no_american_price_is_present():
    got = parse(DECIMAL_SLIP)
    assert got.get("decimal_odds") == pytest.approx(1.95)
    assert got.get("market_type") == "totals"


def test_a_line_number_is_not_mistaken_for_a_decimal_price():
    """`220.5` is a total, not a price. One decimal place gives it away."""
    got = parse(DECIMAL_SLIP)
    assert got.get("decimal_odds") != 220.5


def test_american_beats_decimal_when_a_slip_shows_both():
    got = parse("DraftKings\nLakers -3.5 (-110) 1.91\nWager $50.00\n")
    assert got.get("decimal_odds") == pytest.approx(1.909, abs=1e-3)


def test_the_book_comes_from_the_catalog_not_a_hand_written_list():
    """A book added to the catalog must be parseable without touching this."""
    from overlay_engine.catalog import VENUES

    sample = VENUES["mgm"]
    got = parse(f"{sample.name}\nLakers -3.5 (-110)\nWager $50.00\n")
    assert got.get("book") == "mgm"


def test_an_unknown_book_is_left_missing_rather_than_defaulted():
    got = parse("Some Local Bookie\nLakers -3.5 (-110)\nWager $50.00\n")
    assert got.usable  # book is not essential
    assert got.get("book") is None
    assert to_import(got, event_id="e1")["book"] == "unknown"


def test_to_import_produces_arguments_ledger_import_bet_accepts(tmp_path):
    from overlay_engine.ledger import Ledger

    got = parse(FANDUEL)
    with Ledger(str(tmp_path / "t.db")) as db:
        bet_id = db.import_bet(**to_import(got, event_id="nba-1", sport="basketball"))
        assert bet_id is not None
        assert db.stats()["bets"] == 1


def test_implied_is_vig_inclusive():
    got = parse(DRAFTKINGS)
    assert implied(got) == pytest.approx(0.5238, abs=1e-3)
    assert implied(Parsed()) is None


def test_result_words_never_map_a_loss_to_a_win():
    """A one-character slip in this table silently reverses a P&L."""
    for word, mapped in RESULT_WORDS.items():
        if word.startswith("los") or word in ("lose", "loss"):
            assert mapped == "lost", word
        if word in ("won", "win", "winner", "cashed"):
            assert mapped == "won", word


def test_market_words_map_only_to_market_types_the_ledger_reports_on():
    known = {"h2h", "spreads", "totals", "parlay", "teaser", "player_prop",
             "futures"}
    assert set(MARKET_WORDS.values()) <= known


def test_the_longest_market_phrase_wins():
    """`run line` must not be read as the bare word `line` or as `total`."""
    got = parse("BetMGM\nRun Line Yankees -1.5 (+120)\nWager $20.00\n")
    assert got.get("market_type") == "spreads"


def test_describe_names_every_missing_field():
    got = parse("just some text with no numbers")
    shown = got.describe()
    assert "decimal_odds" in shown and "NOT FOUND" in shown
    assert "stake" in shown


def test_describe_shows_the_source_text_for_every_field_it_found():
    shown = parse(DRAFTKINGS).describe()
    assert "<-" in shown
    assert "-110" in shown


def test_over_and_under_name_a_total():
    got = parse("BetMGM\nOver 45.5 (-115)\nWager $30.00\n")
    assert got.get("market_type") == "totals"
    assert got.fields["market_type"].source.lower() == "over"


def test_a_player_prop_carrying_over_is_still_a_prop():
    """`player` is longer than `over`, and longest-phrase-first is what keeps
    a prop from being filed as a total."""
    got = parse("Caesars\nPlayer Points - LeBron James Over 27.5 (-120)\n"
                "Stake $40.00\n")
    assert got.get("market_type") == "player_prop"
