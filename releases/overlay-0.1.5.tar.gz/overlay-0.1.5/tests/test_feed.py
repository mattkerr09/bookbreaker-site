"""The provider seam, timestamp stamping, and the capture pass."""

import json

import pytest

from overlay_engine.feed import (
    MAX_CLOCK_SKEW,
    CaptureReport,
    FeedError,
    ReplayProvider,
    capture,
    market_from_dict,
    market_to_dict,
    stamp,
    write_snapshot,
)
from overlay_engine.ledger import Ledger
from overlay_engine.models import Market, Outcome, Quote

NOW = 10_000.0


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "feed.db") as ledger:
        yield ledger


def market(seen_at, event="e1", sport="nfl", market_type="h2h", line=None):
    return Market(
        event_id=event, sport=sport, market_type=market_type,
        quotes=[
            Quote(book="pinnacle", outcome=Outcome("home", line),
                  decimal=1.95, seen_at=seen_at),
            Quote(book="dk", outcome=Outcome("away", line),
                  decimal=2.10, seen_at=seen_at),
        ],
        starts_at=NOW + 3600,
    )


# ------------------------------------------------------------------ stamping


def test_a_dated_quote_keeps_its_own_timestamp():
    snap = stamp([market(seen_at=NOW - 7)], fetched_at=NOW)
    quote = snap.markets[0].quotes[0]
    assert quote.seen_at == NOW - 7
    assert quote.fetched_at == NOW
    assert quote.latency == pytest.approx(7.0)
    assert quote.provenance == "measured"
    assert snap.dated == 2
    assert snap.undated == 0


def test_an_undated_quote_is_marked_not_assumed_fresh():
    """A provider without its own timestamps would otherwise make every quote
    look brand new, latency measure as zero, and the headline number optimistic
    by an amount nobody can see."""
    snap = stamp([market(seen_at=NOW)], fetched_at=NOW)
    quote = snap.markets[0].quotes[0]
    assert quote.provenance == "assumed"
    assert quote.latency is None or quote.latency == 0.0
    assert snap.undated == 2
    assert snap.dated == 0


def test_stamping_reports_how_much_the_feed_can_tell_you():
    mixed = [market(seen_at=NOW - 5, event="a"), market(seen_at=NOW, event="b")]
    snap = stamp(mixed, fetched_at=NOW)
    assert snap.dated == 2
    assert snap.undated == 2
    assert snap.dated_fraction == pytest.approx(0.5)
    assert "50% dated" in snap.describe()


def test_a_quote_dated_far_in_the_future_is_dropped():
    """A broken clock, not a fresh price. Kept, it would have negative age and
    rank above every honestly-dated quote on the screen."""
    snap = stamp([market(seen_at=NOW + MAX_CLOCK_SKEW + 60)], fetched_at=NOW)
    assert snap.skewed == 2
    assert snap.markets == []
    assert "clock skew" in snap.describe()


def test_small_skew_is_absorbed_rather_than_dropped():
    snap = stamp([market(seen_at=NOW + 5)], fetched_at=NOW)
    assert snap.skewed == 0
    assert snap.undated == 2
    assert snap.markets[0].quotes[0].seen_at == NOW


def test_a_market_left_with_no_quotes_is_dropped_entirely():
    good = market(seen_at=NOW - 3, event="good")
    bad = market(seen_at=NOW + 9999, event="bad")
    snap = stamp([good, bad], fetched_at=NOW)
    assert [m.event_id for m in snap.markets] == ["good"]


def test_stamping_an_empty_fetch_is_not_an_error():
    snap = stamp([], fetched_at=NOW)
    assert snap.markets == []
    assert snap.quotes == 0
    assert snap.dated_fraction == 0.0


def test_the_snapshot_counts_its_own_quotes():
    snap = stamp([market(seen_at=NOW - 1, event="a"),
                  market(seen_at=NOW - 1, event="b")], fetched_at=NOW)
    assert snap.quotes == 4


# ----------------------------------------------------------- serialisation


def test_a_market_round_trips_through_a_dict():
    original = market(seen_at=NOW - 4, line=220.5)
    restored = market_from_dict(market_to_dict(original))
    assert restored.event_id == original.event_id
    assert restored.starts_at == original.starts_at
    assert [q.outcome.key for q in restored.quotes] == [
        q.outcome.key for q in original.quotes
    ]
    assert restored.quotes[0].seen_at == original.quotes[0].seen_at


def test_the_line_survives_the_round_trip():
    """Without it, over 220.5 and over 221.5 collapse into one key and every
    line-crossing refusal downstream silently stops firing."""
    restored = market_from_dict(market_to_dict(market(seen_at=NOW, line=220.5)))
    assert restored.quotes[0].outcome.key == "home@220.5"


def test_a_malformed_market_is_refused_with_its_reason():
    with pytest.raises(FeedError, match="malformed"):
        market_from_dict({"event_id": "e1", "sport": "nfl"})


def test_a_quote_missing_a_price_is_refused():
    with pytest.raises(FeedError, match="malformed"):
        market_from_dict({
            "event_id": "e1", "sport": "nfl", "market_type": "h2h",
            "quotes": [{"book": "dk", "outcome": "home", "seen_at": NOW}],
        })


# --------------------------------------------------------- replay provider


def test_replay_serves_recorded_markets(tmp_path):
    path = tmp_path / "snap.json"
    assert write_snapshot(path, [market(seen_at=NOW - 3)], fetched_at=NOW) == 2

    provider = ReplayProvider(path)
    assert provider.sports() == ["nfl"]
    markets = provider.fetch("nfl")
    assert len(markets) == 1
    assert markets[0].quotes[0].seen_at == NOW - 3


def test_replay_filters_by_sport(tmp_path):
    path = tmp_path / "snap.json"
    write_snapshot(path, [market(seen_at=NOW, event="a", sport="nfl"),
                          market(seen_at=NOW, event="b", sport="nba")])
    provider = ReplayProvider(path)
    assert provider.sports() == ["nba", "nfl"]
    assert [m.event_id for m in provider.fetch("nba")] == ["b"]
    assert provider.fetch("mlb") == []


def test_a_missing_snapshot_says_so(tmp_path):
    with pytest.raises(FeedError, match="no snapshot"):
        ReplayProvider(tmp_path / "nope.json")


def test_a_corrupt_snapshot_names_the_problem(tmp_path):
    path = tmp_path / "bad.json"
    path.write_text("{not json")
    with pytest.raises(FeedError, match="not valid JSON"):
        ReplayProvider(path)


def test_an_empty_snapshot_is_valid(tmp_path):
    path = tmp_path / "empty.json"
    path.write_text(json.dumps({"markets": []}))
    assert ReplayProvider(path).sports() == []


# ------------------------------------------------------------- the capture


def test_capture_stores_every_market_the_provider_serves(db, tmp_path):
    path = tmp_path / "snap.json"
    write_snapshot(path, [market(seen_at=NOW - 6, event="a"),
                          market(seen_at=NOW - 6, event="b")])

    report = capture(db, ReplayProvider(path), now=NOW)
    assert report.markets == 2
    assert report.quotes == 4
    assert db.stats()["quotes"] == 4


def test_capture_records_markets_nobody_bet(db, tmp_path):
    """A closing line observed only where a bet was placed is a biased sample
    of exactly the markets the model got wrong."""
    path = tmp_path / "snap.json"
    write_snapshot(path, [market(seen_at=NOW - 2, event="unbet")])
    capture(db, ReplayProvider(path), is_closing=True, now=NOW)
    assert db.stats()["bets"] == 0
    assert db.stats()["closing_quotes"] == 2


def test_captured_quotes_carry_their_latency_into_the_model(db, tmp_path):
    """The whole reason stamping happens at the boundary: the ledger can only
    measure feed lag if both timestamps survive the trip."""
    path = tmp_path / "snap.json"
    write_snapshot(path, [market(seen_at=NOW - 9, event=f"e{i}")
                          for i in range(15)])
    capture(db, ReplayProvider(path), now=NOW)

    model = db.latency_model()
    assert model.observations("dk") == 15
    assert model.is_measured("dk")
    assert model.typical("dk") > 5.0


def test_stamp_leaves_an_undated_quote_without_a_fetch_time():
    """The feed layer's half of the guard, tested on its own.

    `fetched_at == seen_at` reads downstream as a *measured* latency of zero.
    The end-to-end test below cannot police this alone: the ledger holds the
    same line independently, so breaking either layer by itself leaves the
    other catching it and the break looks undetected.
    """
    snap = stamp([market(seen_at=NOW)], fetched_at=NOW)
    quote = snap.markets[0].quotes[0]
    assert quote.fetched_at is None
    assert quote.seen_at == NOW
    assert quote.provenance == "assumed"


def test_the_ledger_ignores_equal_timestamps(db):
    """The ledger layer's half, tested on its own.

    Equal timestamps mean either an undated quote or a sub-millisecond feed,
    and those are indistinguishable at float precision. The ledger does not
    trust its callers to have made the distinction.
    """
    for i in range(10):
        db.record_quote(event_id=f"e{i}", sport="nfl", market_type="h2h",
                        outcome="home", book="dk", decimal_odds=2.0,
                        seen_at=1000.0, fetched_at=1000.0)
    assert db.latency_model().observations("dk") == 0


def test_undated_quotes_teach_the_latency_model_nothing(db, tmp_path):
    """Both layers together, end to end. Unknown latency is not zero latency;
    averaging in a zero would drag every book's estimate toward 'instant'."""
    path = tmp_path / "snap.json"
    write_snapshot(path, [market(seen_at=NOW, event=f"e{i}") for i in range(15)])
    report = capture(db, ReplayProvider(path), now=NOW)

    assert report.undated == 30
    assert report.dated == 0
    assert db.latency_model().observations("dk") == 0


def test_capture_marks_closing_quotes_only_when_asked(db, tmp_path):
    path = tmp_path / "snap.json"
    write_snapshot(path, [market(seen_at=NOW - 1)])

    capture(db, ReplayProvider(path), now=NOW)
    assert db.stats()["closing_quotes"] == 0

    capture(db, ReplayProvider(path), is_closing=True, now=NOW)
    assert db.stats()["closing_quotes"] == 2


def test_capture_can_be_limited_to_named_sports(db, tmp_path):
    path = tmp_path / "snap.json"
    write_snapshot(path, [market(seen_at=NOW - 1, event="a", sport="nfl"),
                          market(seen_at=NOW - 1, event="b", sport="nba")])
    report = capture(db, ReplayProvider(path), sports=["nba"], now=NOW)
    assert report.markets == 1
    assert report.sports == ["nba"]


def test_capture_drops_skewed_quotes_and_says_so(db, tmp_path):
    path = tmp_path / "snap.json"
    write_snapshot(path, [market(seen_at=NOW + 9999, event="skewed"),
                          market(seen_at=NOW - 3, event="fine")])
    report = capture(db, ReplayProvider(path), now=NOW)
    assert report.skewed == 2
    assert report.markets == 1
    assert db.stats()["quotes"] == 2


def test_capturing_nothing_reports_nothing_rather_than_success(db, tmp_path):
    """An empty capture that printed a cheerful summary is how a broken feed
    stays broken for a week."""
    path = tmp_path / "snap.json"
    write_snapshot(path, [])
    report = capture(db, ReplayProvider(path), now=NOW)
    assert report.markets == 0
    assert report.describe() == "captured nothing"


def test_the_report_describes_what_it_did():
    report = CaptureReport(markets=3, quotes=12, dated=10, undated=2,
                           closing=True)
    text = report.describe()
    assert "12 closing quotes" in text
    assert "3 markets" in text
    assert "10 dated" in text


def test_capture_feeds_the_grading_path_end_to_end(db, tmp_path):
    """Capture a close, then grade a bet against it — the chain the scheduler
    will drive once a real provider exists."""
    from overlay_engine.grade import grade_pending
    from overlay_engine.ledger import AtBet

    bet_id = db.record_bet(
        event_id="e1", sport="nfl", market_type="h2h", outcome="home",
        book="dk", decimal_odds=2.10, stake=100.0, placed_at=NOW - 3600,
        at_bet=AtBet(fair_prob=0.50, fair_low=0.47, fair_high=0.53,
                     devig={"power": 0.50, "shin": 0.50,
                            "additive": 0.50, "multiplicative": 0.50}),
    )
    path = tmp_path / "close.json"
    write_snapshot(path, [Market(
        event_id="e1", sport="nfl", market_type="h2h",
        quotes=[
            Quote(book="pinnacle", outcome=Outcome("home"), decimal=1.95,
                  seen_at=NOW - 4),
            Quote(book="pinnacle", outcome=Outcome("away"), decimal=1.95,
                  seen_at=NOW - 4),
        ],
    )])

    capture(db, ReplayProvider(path), is_closing=True, now=NOW)
    assert grade_pending(db).graded == 1
    assert db.graded_bets()[0].clv == pytest.approx(0.05, abs=1e-9)
