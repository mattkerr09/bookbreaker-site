"""A crash report the user can read, and send only if they choose to.

Matthew's report was "it doesn't even open". That failure happens during
import, before any window exists and before any handler installed inside a
request path could run — so this module's whole value depends on two things
being true, and neither is visible by reading the code casually:

**Installed at process entry.** A handler installed after argument parsing
cannot capture a crash in argument parsing.

**Safe to send.** The report is written on the promise that the user can
attach it to an email. A traceback prints the locals of the frame that raised
and argv carries whatever was on the command line, so a report that copies
either verbatim can carry a live credential into a file we invited them to
share. Every string that reaches the file goes through `sanitise`; a reporter
that sanitises most fields and interpolates into one is a reporter that leaks
through that one.

And it never uploads. The app makes no network calls at all — see
`test_app_is_offline.py` — and a crash reporter is the single most plausible
route by which that would stop being true, because every commercial one
uploads by default.
"""

import ast
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "backend" / "overlay_engine" / "crash.py"

from overlay_engine import crash  # noqa: E402


# --- it never leaves the machine -------------------------------------------

#: Every one of these uploads by default. Finding one here is a FAILURE, not a
#: finding to weigh up: it means a crash now leaves the machine.
UPLOADERS = ("sentry", "crashlytics", "bugsnag", "rollbar", "raygun",
             "airbrake", "honeybadger", "appcenter", "datadog", "posthog")

NETWORK = ("requests", "urllib.request", "urllib3", "http.client", "httpx",
           "socket", "aiohttp", "smtplib", "ftplib", "telnetlib")


def test_the_reporter_imports_nothing_that_can_reach_a_network():
    tree = ast.parse(SRC.read_text())
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported.update(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported.add(node.module)
    for name in imported:
        root = name.split(".")[0]
        assert root not in {n.split(".")[0] for n in NETWORK}, (
            f"crash.py imports {name}; a crash reporter is exactly where an "
            f"uploader gets added"
        )


def test_no_commercial_crash_service_anywhere_in_the_reporter():
    text = SRC.read_text().lower()
    for vendor in UPLOADERS:
        assert vendor not in text, f"{vendor} would upload crashes"


def test_the_report_goes_under_overlay_home():
    """So it is somewhere the user can find, delete, and inspect."""
    assert crash.CRASH_DIR.name == "crashes"
    assert "overlay" in str(crash.CRASH_DIR).lower()


# --- it is safe to send ----------------------------------------------------

LIVE_LOOKING = [
    "sk-ant-abcd1234567890abcdef",
    "AKIAIOSFODNN7EXAMPLE",
    "ghp_abcdefghijklmnopqrstuvwxyz0123",
    "xoxb-1234567890-abcdefghijkl",
    "api_key=hunter2secret",
    "password: correcthorsebattery",
]


@pytest.mark.parametrize("secret", LIVE_LOOKING)
def test_a_credential_in_the_exception_message_never_reaches_the_file(
    secret, tmp_path, monkeypatch
):
    """The message is whatever the process was holding when it died.

    `raise ValueError(f"bad key {key}")` is an ordinary line to write and puts
    a live credential into the report.
    """
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(crash, "CRASH_DIR", tmp_path / "crashes")
    try:
        raise ValueError(f"failed with {secret}")
    except ValueError:
        written = crash.write_report("test", *sys.exc_info())
    raw = written.read_text()
    assert secret not in raw, f"{secret} was written to a report we ask users to email"


def test_a_credential_in_argv_never_reaches_the_file(tmp_path, monkeypatch):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(crash, "CRASH_DIR", tmp_path / "crashes")
    monkeypatch.setattr(sys, "argv", ["overlay", "--token", "sk-ant-livekey1234567890"])
    try:
        raise RuntimeError("boom")
    except RuntimeError:
        written = crash.write_report("test", *sys.exc_info())
    assert "sk-ant-livekey1234567890" not in written.read_text()


def test_a_credential_in_a_traceback_frame_never_reaches_the_file(
    tmp_path, monkeypatch
):
    """A traceback prints the source line, and source lines contain literals."""
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(crash, "CRASH_DIR", tmp_path / "crashes")
    try:
        _key = "sk-ant-insideaframe12345678"
        raise RuntimeError(f"see {_key}")
    except RuntimeError:
        written = crash.write_report("test", *sys.exc_info())
    assert "sk-ant-insideaframe12345678" not in written.read_text()


def test_the_type_name_is_still_readable_after_sanitising():
    """Redacting everything is safe and useless. The report has to stay a
    report: the exception type and the shape of the message survive."""
    assert crash.sanitise("boom sk-ant-abcd1234567890xy") == "boom sk-ant-REDACTED"
    assert crash.sanitise("division by zero") == "division by zero"


def test_the_file_is_readable_only_by_its_owner(tmp_path, monkeypatch):
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    monkeypatch.setattr(crash, "CRASH_DIR", tmp_path / "crashes")
    try:
        raise ValueError("x")
    except ValueError:
        written = crash.write_report("test", *sys.exc_info())
    assert stat.S_IMODE(written.stat().st_mode) == 0o600
    assert stat.S_IMODE(written.parent.stat().st_mode) == 0o700


# --- it is installed early enough to see the crash Matthew hit --------------

def test_install_happens_before_anything_else_in_main():
    """The "doesn't even open" crash happens during import and argument
    parsing. A handler installed after either cannot see it."""
    source = (ROOT / "backend" / "overlay_engine" / "cli.py").read_text()
    at_main = source.index("def main(")
    body = source[at_main:at_main + 600]
    install_at = body.index("crash.install()")
    parse_at = body.find("build_parser")
    assert parse_at < 0 or install_at < parse_at, (
        "crash.install() must run before the parser is built"
    )


def test_a_real_process_crash_writes_a_real_report(tmp_path):
    """Read tests pass on a handler that was never wired up. This one runs a
    fresh interpreter through the actual entry point and looks for the file."""
    env = dict(os.environ, OVERLAY_HOME=str(tmp_path),
               PYTHONPATH=str(ROOT / "backend"))
    subprocess.run(
        [sys.executable, "-c",
         "from overlay_engine import crash; crash.install();"
         " raise SystemError('crash under test')"],
        env=env, capture_output=True, timeout=60,
    )
    written = sorted((tmp_path / "crashes").glob("crash-*.json"))
    assert written, "a crashing process wrote no report"
    data = json.loads(written[0].read_text())
    assert data["exception"] == "SystemError"
    assert "crash under test" in data["message"]


def test_the_oldest_reports_are_dropped(tmp_path, monkeypatch):
    """An unbounded directory in the user's home is a slow leak, and the
    twenty-first crash is not more interesting than the first."""
    monkeypatch.setattr(crash, "CRASH_DIR", tmp_path / "crashes")
    for i in range(crash.KEEP + 5):
        try:
            raise ValueError(f"crash {i}")
        except ValueError:
            crash.write_report("test", *sys.exc_info())
    assert len(list((tmp_path / "crashes").glob("crash-*.json"))) <= crash.KEEP


# --- a refusal is not a crash ----------------------------------------------

def test_the_apps_own_refusals_are_not_crashes():
    """`overlay parlay 2.10` is a person making an ordinary mistake.

    Filing it as a crash does two kinds of damage: the user is told the
    program broke when it is they who were told no, and the crash directory
    fills with noise until a real crash is invisible inside it.
    """
    from overlay_engine.odds import OddsError
    from overlay_engine.ledger import LedgerError

    assert crash.is_expected(OddsError)
    assert crash.is_expected(LedgerError)
    assert crash.is_expected(KeyboardInterrupt)
    assert not crash.is_expected(ValueError)
    assert not crash.is_expected(AttributeError)


def test_a_refusal_prints_a_sentence_and_writes_no_report(tmp_path):
    """End to end, through the real entry point: one line on stderr, exit 2,
    and an empty crash directory."""
    env = dict(os.environ, OVERLAY_HOME=str(tmp_path),
               PYTHONPATH=str(ROOT / "backend"))
    done = subprocess.run(
        [sys.executable, str(ROOT / "backend" / "cli.py"), "parlay", "2.10"],
        env=env, capture_output=True, text=True, timeout=60,
    )
    assert done.returncode == 2
    assert "Traceback" not in done.stderr, "a refusal showed the user a stack trace"
    assert "at least two legs" in done.stderr
    assert not list((tmp_path / "crashes").glob("crash-*.json"))


def test_the_hook_itself_ignores_refusals_not_just_the_cli(tmp_path):
    """The CLI catches its own refusals before the hook sees them, so the
    hook's guard is unreachable from the command line and a break case aimed
    there proves nothing. The window imports the engine directly, where there
    is no such catch — this exercises that path."""
    env = dict(os.environ, OVERLAY_HOME=str(tmp_path),
               PYTHONPATH=str(ROOT / "backend"))
    subprocess.run(
        [sys.executable, "-c",
         "from overlay_engine import crash; from overlay_engine.odds import OddsError;"
         " crash.install(); raise OddsError('needs at least two legs')"],
        env=env, capture_output=True, timeout=60,
    )
    assert not list((tmp_path / "crashes").glob("crash-*.json")), (
        "an OddsError reaching the hook was filed as a crash"
    )
