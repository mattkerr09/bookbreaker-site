"""Sizing and the closing-line scoreboard."""

import pytest

from overlay_engine.clv import (
    GradedBet,
    implied_clv,
    method_scores,
    report,
    weights_from_scores,
)
from overlay_engine.kelly import (
    arb_free_roll,
    kelly_fraction,
    simultaneous_scale,
    size_bet,
)


def test_kelly_on_a_known_case():
    """A 60% shot at even money is the textbook 20%."""
    assert kelly_fraction(2.0, 0.6) == pytest.approx(0.2)


def test_no_edge_is_no_stake():
    assert kelly_fraction(2.0, 0.5) == pytest.approx(0.0)


def test_negative_edge_returns_zero_not_a_short():
    """You cannot lay at a sportsbook, and a negative fraction invites abs()."""
    assert kelly_fraction(2.0, 0.4) == 0.0


def test_kelly_rejects_impossible_inputs():
    with pytest.raises(ValueError):
        kelly_fraction(1.0, 0.6)
    with pytest.raises(ValueError):
        kelly_fraction(2.0, 1.5)


def test_fractional_kelly_is_the_default():
    sizing = size_bet(2.0, 0.6, bankroll=10_000.0, fraction=0.25)
    assert sizing.full_kelly == pytest.approx(0.2)
    assert sizing.bankroll_share == pytest.approx(0.05)


def test_the_conservative_probability_is_the_one_kelly_sees():
    confident = size_bet(2.0, 0.60, bankroll=10_000.0)
    cautious = size_bet(2.0, 0.60, bankroll=10_000.0, prob_low=0.55)
    assert cautious.stake < confident.stake
    assert cautious.full_kelly == pytest.approx(confident.full_kelly)


def test_the_single_bet_cap_binds_and_says_so():
    sizing = size_bet(2.0, 0.90, bankroll=10_000.0)
    assert sizing.bankroll_share == pytest.approx(0.05)
    assert sizing.binding == "max_single"


def test_a_book_maximum_binds_and_says_so():
    sizing = size_bet(2.0, 0.60, bankroll=10_000.0, book_max=50.0)
    assert sizing.stake == 50.0
    assert sizing.binding == "book_max"


def test_binding_names_kelly_when_kelly_is_actually_deciding():
    sizing = size_bet(2.0, 0.53, bankroll=10_000.0)
    assert sizing.binding == "kelly"


def test_no_edge_is_reported_as_no_edge():
    assert size_bet(2.0, 0.45, bankroll=10_000.0).binding == "no_edge"


def test_fill_probability_does_not_shrink_the_stake():
    """A partially-likely fill is not a partially-sized bet."""
    a = size_bet(2.0, 0.55, bankroll=10_000.0, p_fill=1.0)
    b = size_bet(2.0, 0.55, bankroll=10_000.0, p_fill=0.2)
    assert a.stake == pytest.approx(b.stake)


def test_bankroll_must_be_positive():
    with pytest.raises(ValueError):
        size_bet(2.0, 0.6, bankroll=0.0)


def test_simultaneous_bets_shrink_the_size():
    assert simultaneous_scale(1) == 1.0
    assert simultaneous_scale(10) < 1.0
    assert simultaneous_scale(10, correlation=0.9) < simultaneous_scale(10, correlation=0.0)


def test_independent_bets_need_no_shrink():
    """Kelly's individual optima are already right for independent bets;
    shrinking them anyway is superstition dressed as prudence."""
    assert simultaneous_scale(10, correlation=0.0) == 1.0


def test_perfect_correlation_treats_ten_bets_as_one():
    """Twelve overs on one game script is one bet, not twelve."""
    assert simultaneous_scale(10, correlation=1.0) == pytest.approx(1 / 10**0.5)


def test_simultaneous_scale_rejects_an_impossible_correlation():
    with pytest.raises(ValueError):
        simultaneous_scale(5, correlation=1.5)


def test_arb_free_roll_measures_the_worst_leg():
    assert arb_free_roll([2.10, 2.05], [500.0, 500.0]) == pytest.approx(0.025)
    assert arb_free_roll([1.91, 1.91], [500.0, 500.0]) < 0
    assert arb_free_roll([2.0, 2.0], []) == 0.0


def _bet(clv_edge: float, book="dk", market="h2h", stake=100.0) -> GradedBet:
    """A bet whose CLV is exactly `clv_edge` at even-money-ish odds."""
    decimal = 2.0
    closing = (1.0 + clv_edge) / decimal
    return GradedBet(
        bet_id="b",
        sport="nfl",
        market_type=market,
        book=book,
        decimal=decimal,
        stake=stake,
        fair_prob_at_bet=closing,
        closing_fair_prob=closing,
    )


def test_clv_is_ev_with_hindsight():
    bet = _bet(0.03)
    assert bet.clv == pytest.approx(0.03)
    assert bet.beat_close


def test_losing_to_the_close_is_negative_clv():
    assert not _bet(-0.02).beat_close


def test_model_error_points_the_dangerous_way():
    """Positive means the model was more optimistic than the close — the
    direction that manufactures phantom edges."""
    bet = GradedBet(
        bet_id="b", sport="nfl", market_type="h2h", book="dk", decimal=2.0,
        stake=100.0, fair_prob_at_bet=0.55, closing_fair_prob=0.52,
    )
    assert bet.model_error == pytest.approx(0.03)


def test_a_small_sample_refuses_to_claim_an_edge():
    """A tight 1.2% mean over 10 bets is not evidence, and the report has to
    say so.

    The spread is deliberate. An earlier version of this test used ten
    identical CLVs, which gives zero variance, an undefined t-statistic, and a
    pass no matter what the code does — it went green against a build with the
    sample-size floor deleted. These values carry enough variance that t is
    about 3.8, so only the n >= 30 floor can hold the verdict back.
    """
    rep = report([_bet(0.012 + 0.01 * (i % 3 - 1)) for i in range(10)])
    assert rep.n == 10
    assert rep.t_stat > 2.0, "the sample must look significant on t alone"
    assert not rep.significant
    assert "too few" in rep.verdict()


def test_a_zero_variance_sample_is_not_called_significant():
    """Identical CLVs give an undefined t. Resolving that to 'significant'
    would make the smallest, most degenerate sample the most confident."""
    rep = report([_bet(0.03) for _ in range(50)])
    assert rep.stdev == 0.0
    assert rep.t_stat == 0.0
    assert not rep.significant


def test_a_large_consistent_sample_is_significant():
    bets = [_bet(0.03 + 0.001 * (i % 5 - 2)) for i in range(120)]
    rep = report(bets)
    assert rep.n == 120
    assert rep.significant
    assert "beating the close" in rep.verdict()


def test_a_noisy_positive_mean_is_not_called_an_edge():
    bets = [_bet(0.05 if i % 2 else -0.045) for i in range(60)]
    rep = report(bets)
    assert rep.mean_clv > 0
    assert not rep.significant
    assert "not significant" in rep.verdict()


def test_losing_to_the_close_is_reported_plainly():
    assert "losing to the close" in report([_bet(-0.03) for _ in range(40)]).verdict()


def test_report_groups_by_book_and_market():
    bets = [_bet(0.05, book="dk"), _bet(-0.01, book="fd", market="totals")]
    rep = report(bets)
    assert rep.by_book["dk"] == pytest.approx(0.05)
    assert rep.by_market["totals"] == pytest.approx(-0.01)
    assert rep.total_staked == pytest.approx(200.0)


def test_an_empty_report_is_not_a_crash():
    rep = report([])
    assert rep.n == 0
    assert rep.verdict().startswith("0 bets")


def test_standard_error_is_infinite_for_a_single_bet():
    assert report([_bet(0.03)]).standard_error == float("inf")


def test_method_scores_prefer_the_method_that_predicted_the_close():
    bets = [_bet(0.0) for _ in range(20)]
    truth = [b.closing_fair_prob for b in bets]
    scores = method_scores(
        bets,
        {
            "power": truth,
            "multiplicative": [p + 0.05 for p in truth],
        },
    )
    assert scores["power"] < scores["multiplicative"]


def test_method_scores_skip_mismatched_lengths():
    bets = [_bet(0.0) for _ in range(5)]
    assert method_scores(bets, {"power": [0.5]}) == {}


def test_weights_follow_the_scores_but_never_delete_a_method():
    """40 bets cannot distinguish a bad method from an unlucky one."""
    weights = weights_from_scores({"power": 0.0001, "multiplicative": 0.05})
    assert weights["power"] > weights["multiplicative"]
    assert weights["multiplicative"] >= 0.05
    assert sum(weights.values()) == pytest.approx(1.0)


def test_a_floor_that_cannot_be_honoured_is_refused():
    with pytest.raises(ValueError):
        weights_from_scores({"a": 1.0, "b": 1.0, "c": 1.0}, floor=0.4)


def test_no_evidence_means_equal_weights():
    weights = weights_from_scores({})
    assert len(set(round(w, 9) for w in weights.values())) == 1
    assert sum(weights.values()) == pytest.approx(1.0)


def test_implied_clv_is_named_apart_because_it_understates():
    """It compares two vigged prices; mixing it into a real CLV average would
    silently bias the result."""
    assert implied_clv(2.10, 1.91) == pytest.approx(0.099476, abs=1e-5)
