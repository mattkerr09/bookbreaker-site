"""Tags, and the bar that knows how many hypotheses you tested."""

import pytest

from overlay_engine.ledger import AtBet, Ledger, LedgerError
from overlay_engine.performance import (
    MIN_BETS,
    Z,
    bonferroni_z,
    family_error_rate,
    tag_report,
)

DEVIG = {"power": 0.50, "shin": 0.50, "additive": 0.50, "multiplicative": 0.50}


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "tags.db") as ledger:
        yield ledger


def place(db, i, *, result=None, profit=None, stake=100.0):
    bet_id = db.record_bet(
        event_id=f"e{i}", sport="nfl", market_type="h2h", outcome="home",
        book="dk", decimal_odds=2.0, stake=stake, placed_at=1000.0 + i,
        at_bet=AtBet(fair_prob=0.50, fair_low=0.47, fair_high=0.53,
                     devig=dict(DEVIG)),
    )
    if result:
        db.settle(bet_id, closing_fair_prob=0.50, result=result, profit=profit)
    return bet_id


def tagged(db, tag, wins, losses, start=0):
    """`wins` winning and `losses` losing bets, all carrying `tag`."""
    i = start
    for _ in range(wins):
        db.tag_bet(place(db, i, result="won", profit=100.0), tag)
        i += 1
    for _ in range(losses):
        db.tag_bet(place(db, i, result="lost", profit=-100.0), tag)
        i += 1
    return i


# ------------------------------------------------------------------ storage


def test_a_bet_can_carry_tags(db):
    bet_id = place(db, 0)
    assert db.tag_bet(bet_id, "steam", "line-shopped") == 2
    assert db.tags_for(bet_id) == ["line-shopped", "steam"]


def test_tags_are_normalised(db):
    """"Steam", "steam " and "steam" are one hypothesis, and three slices of a
    record is how a pattern gets manufactured out of nothing."""
    bet_id = place(db, 0)
    db.tag_bet(bet_id, "Steam", "steam ", " STEAM")
    assert db.tags_for(bet_id) == ["steam"]


def test_tagging_twice_is_idempotent(db):
    bet_id = place(db, 0)
    assert db.tag_bet(bet_id, "gut") == 1
    assert db.tag_bet(bet_id, "gut") == 0
    assert db.tags() == {"gut": 1}


def test_a_blank_tag_is_refused(db):
    bet_id = place(db, 0)
    with pytest.raises(LedgerError, match="cannot be blank"):
        db.tag_bet(bet_id, "   ")


def test_tagging_an_unknown_bet_is_refused(db):
    with pytest.raises(LedgerError, match="no bet"):
        db.tag_bet(999, "steam")


def test_a_tag_can_be_removed(db):
    bet_id = place(db, 0)
    db.tag_bet(bet_id, "gut")
    assert db.untag_bet(bet_id, "GUT") is True
    assert db.untag_bet(bet_id, "gut") is False
    assert db.tags_for(bet_id) == []


def test_tags_are_counted_by_use(db):
    a, b = place(db, 0), place(db, 1)
    db.tag_bet(a, "steam")
    db.tag_bet(b, "steam", "gut")
    assert db.tags() == {"steam": 2, "gut": 1}


def test_a_bet_appears_under_every_tag_it_carries(db):
    bet_id = place(db, 0, result="won", profit=100.0)
    db.tag_bet(bet_id, "steam", "gut")
    grouped = db.settled_by_tag()
    assert set(grouped) == {"steam", "gut"}
    assert grouped["steam"][0]["id"] == bet_id


def test_unsettled_bets_are_not_in_the_tag_report(db):
    db.tag_bet(place(db, 0), "steam")
    assert db.settled_by_tag() == {}


# ---------------------------------------------- the multiple-comparisons bar


def test_the_bar_rises_with_the_number_of_tests():
    assert bonferroni_z(1) == pytest.approx(Z, abs=0.01)
    assert bonferroni_z(12) > bonferroni_z(5) > bonferroni_z(1)


def test_the_family_error_rate_is_the_reason():
    """With twelve slices, the chance one clears the ordinary bar by luck is
    about 46% — so a tag that clears it out of twelve has told you nothing."""
    assert family_error_rate(1) == pytest.approx(0.05)
    assert family_error_rate(12) == pytest.approx(0.46, abs=0.01)
    assert family_error_rate(20) > 0.6
    assert family_error_rate(0) == 0.0


def test_significance_at_a_stricter_bar_is_harder():
    """300 bets at 57%, not 100.

    A first version used 100 and failed: 57 wins in 100 even-money bets gives
    z = 1.41, which is genuinely not significant. The model was right and the
    fixture was wrong — and it is a fair illustration of why the whole report
    carries intervals, since 57% over a hundred bets looks like a season worth
    bragging about.
    """
    from overlay_engine.performance import report

    rows = [{"id": 1, "placed_at": 0, "settled_at": 0, "sport": "nfl",
             "market_type": "h2h", "outcome": "x", "book": "dk",
             "decimal_odds": 2.0, "stake": 100.0,
             "result": "won" if i % 100 < 57 else "lost",
             "profit": 100.0 if i % 100 < 57 else -100.0,
             "fair_prob": 0.5, "closing_fair_prob": 0.5,
             "p_fill": 1.0, "heat": 0.0} for i in range(300)]
    overall = report(rows).overall
    assert overall.significant_at(1.96)
    assert not overall.significant_at(6.0)


def test_a_hundred_bets_at_fifty_seven_percent_is_not_evidence():
    """Named on its own because it is the most common self-deception in
    betting, and the interval is the only thing that says so."""
    from overlay_engine.performance import report

    rows = [{"id": 1, "placed_at": 0, "settled_at": 0, "sport": "nfl",
             "market_type": "h2h", "outcome": "x", "book": "dk",
             "decimal_odds": 2.0, "stake": 100.0,
             "result": "won" if i % 100 < 57 else "lost",
             "profit": 100.0 if i % 100 < 57 else -100.0,
             "fair_prob": 0.5, "closing_fair_prob": 0.5,
             "p_fill": 1.0, "heat": 0.0} for i in range(100)]
    overall = report(rows).overall
    assert overall.win_rate == pytest.approx(0.57)
    assert overall.flat_return > 0
    assert not overall.significant
    assert "indistinguishable from break-even" in overall.verdict()


def test_a_thin_slice_is_never_significant_at_any_bar(db):
    tagged(db, "thin", wins=5, losses=1)
    rep = tag_report(db)
    assert rep.tests == 0
    assert "nothing testable yet" in rep.verdict()


# ------------------------------------------------------------- the report


def test_one_tag_is_judged_at_the_ordinary_bar(db):
    tagged(db, "sharp", wins=70, losses=30)
    rep = tag_report(db)
    assert rep.tests == 1
    assert rep.bar == pytest.approx(Z, abs=0.01)
    assert len(rep.survivors) == 1


def test_the_same_slice_can_fail_once_more_tags_are_tested(db):
    """The whole point. Nothing about the tag changed — only how many
    hypotheses were checked alongside it."""
    end = tagged(db, "edge", wins=61, losses=39)
    alone = tag_report(db)

    for i in range(14):
        end = tagged(db, f"noise{i}", wins=20, losses=20, start=end)
    crowded = tag_report(db)

    assert alone.tests == 1
    assert crowded.tests > alone.tests
    assert crowded.bar > alone.bar

    edge_alone = next(s for s in alone.slices if s.label == "edge")
    edge_crowded = next(s for s in crowded.slices if s.label == "edge")
    assert edge_alone.flat_return == pytest.approx(edge_crowded.flat_return)
    assert edge_alone.significant_at(alone.bar)
    assert not edge_crowded.significant_at(crowded.bar)


def test_the_verdict_names_both_counts(db):
    end = tagged(db, "a", wins=70, losses=30)
    for i in range(6):
        end = tagged(db, f"b{i}", wins=20, losses=20, start=end)
    verdict = tag_report(db).verdict()
    assert "look significant" in verdict
    assert "survive the correction" in verdict
    assert "by luck alone" in verdict


def test_slices_are_ordered_by_size(db):
    end = tagged(db, "big", wins=30, losses=30)
    tagged(db, "small", wins=5, losses=5, start=end)
    assert tag_report(db).slices[0].label == "big"


def test_an_untagged_ledger_says_so(db):
    place(db, 0, result="won", profit=100.0)
    assert tag_report(db).verdict() == "no tagged bets"


def test_tag_slices_carry_the_usual_numbers(db):
    tagged(db, "steam", wins=40, losses=20)
    slice_ = tag_report(db).slices[0]
    assert slice_.n == 60
    assert slice_.profit == pytest.approx(2000.0)
    assert slice_.win_rate == pytest.approx(40 / 60)
    assert slice_.roi == pytest.approx(2000.0 / 6000.0)


def test_the_evidence_floor_still_applies_per_tag(db):
    end = tagged(db, "tiny", wins=20, losses=0)
    tagged(db, "real", wins=70, losses=30, start=end)
    rep = tag_report(db)
    tiny = next(s for s in rep.slices if s.label == "tiny")
    assert tiny.n < MIN_BETS
    assert not tiny.significant
    assert rep.tests == 1


def test_a_v8_database_migrates_to_v9(tmp_path):
    from overlay_engine.ledger import SCHEMA_VERSION

    path = tmp_path / "v8.db"
    with Ledger(path) as db:
        bet_id = place(db, 0)
        db.tag_bet(bet_id, "steam")
        db.conn.execute("DROP TABLE bet_tags")
        db.conn.execute("UPDATE meta SET value = '8' WHERE key = 'schema_version'")
        db.conn.commit()

    with Ledger(path) as db:
        assert db.tags() == {}
        db.tag_bet(1, "gut")
        assert db.tags() == {"gut": 1}
        row = db.conn.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        assert int(row["value"]) == SCHEMA_VERSION
