"""The single pricing entry point: what it loads, and what it refuses to hide."""

import pytest

from overlay_engine.calibrate import book_scope_key, scope_key
from overlay_engine.ledger import AtBet, Ledger
from overlay_engine.models import Book, BookTier, Market, Outcome, Quote
from overlay_engine.pricing import (
    MAX_WEIGHT_AGE,
    PricingContext,
    context_for,
    fair_for,
    price_market,
)

PIN = Book("pinnacle", "Pinnacle", BookTier.SHARP, limits_winners=False)
CIRCA = Book("circa", "Circa", BookTier.SHARP, limits_winners=False)
DK = Book("dk", "DraftKings", BookTier.RETAIL)
FD = Book("fd", "FanDuel", BookTier.RETAIL)
BOOKS = {b.key: b for b in (PIN, CIRCA, DK, FD)}

NOW = 10_000.0


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "pricing.db") as ledger:
        yield ledger


def market(seen_at=NOW - 5, sport="nfl", market_type="h2h"):
    prices = [("pinnacle", "home", 1.75), ("pinnacle", "away", 2.20),
              ("circa", "home", 1.80), ("circa", "away", 2.12),
              ("dk", "home", 1.95), ("dk", "away", 1.95)]
    return Market(
        event_id="e1", sport=sport, market_type=market_type,
        quotes=[
            Quote(book=b, outcome=Outcome(n), decimal=d, seen_at=seen_at)
            for b, n, d in prices
        ],
    )


# ------------------------------------------------------------------ loading


def test_a_fresh_ledger_prices_on_priors_and_says_so(db):
    ctx = PricingContext.from_ledger(db, BOOKS)
    assert not ctx.calibrated
    assert ctx.age is None
    assert not ctx.stale
    assert "shipped priors" in ctx.describe()


def test_calibrated_weights_are_loaded(db):
    db.set_setting(scope_key(None, None), {"power": 0.8, "shin": 0.2})
    ctx = PricingContext.from_ledger(db, BOOKS)
    assert ctx.calibrated
    assert ctx.method_weights["power"] == pytest.approx(0.8)
    assert "devig led by power" in ctx.describe()


def test_book_weights_arrive_rescaled_never_raw(db):
    """Calibration returns weights summing to 1; tier defaults run to 1.0 for a
    sharp book. Handing `fair_value` the mixture would let one uncovered sharp
    book swamp every measured one."""
    db.set_setting(book_scope_key(None, None), {"pinnacle": 0.7, "dk": 0.3})
    ctx = PricingContext.from_ledger(db, BOOKS)

    covered = ctx.book_weights["pinnacle"] + ctx.book_weights["dk"]
    assert covered == pytest.approx(PIN.weight + DK.weight)
    assert ctx.book_weights["circa"] == pytest.approx(CIRCA.weight)


def test_the_scope_is_respected_with_a_global_fallback(db):
    db.set_setting(scope_key(None, None), {"power": 1.0})
    db.set_setting(scope_key("nba", "total"), {"shin": 1.0})

    nba = PricingContext.from_ledger(db, BOOKS, sport="nba", market_type="totals")
    nfl = PricingContext.from_ledger(db, BOOKS, sport="nfl", market_type="h2h")
    assert max(nba.method_weights, key=nba.method_weights.get) == "shin"
    assert max(nfl.method_weights, key=nfl.method_weights.get) == "power"


def test_context_for_reads_the_market_s_own_scope(db):
    """The right devig method for an NBA total is not the right one for a
    tennis outright — pricing everything from the global scope throws away the
    reason calibration is scoped."""
    db.set_setting(scope_key("nba", "total"), {"shin": 1.0})
    ctx = context_for(db, BOOKS, market(sport="nba", market_type="totals"))
    assert ctx.sport == "nba"
    assert max(ctx.method_weights, key=ctx.method_weights.get) == "shin"


def test_the_fill_and_latency_models_come_along(db):
    from overlay_engine.staleness import Observation

    for i in range(30):
        db.record_attempt(book="dk", market_type="h2h", quote_age=4.0,
                          accepted=False)
        db.record_quote(event_id=f"e{i}", sport="nfl", market_type="h2h",
                        outcome="home", book="dk", decimal_odds=2.0,
                        seen_at=1000.0, fetched_at=1008.0)

    ctx = PricingContext.from_ledger(db, BOOKS)
    assert ctx.fill.is_fitted("dk", "h2h")
    assert ctx.latency.is_measured("dk")


def test_an_uncalibrated_context_needs_no_ledger():
    ctx = PricingContext.uncalibrated(BOOKS)
    assert not ctx.calibrated
    assert ctx.method_weights is None


# ------------------------------------------------------------------ staleness


def test_age_reports_the_oldest_half_not_the_newest(db):
    """A price built from fresh devig weights and year-old book weights is only
    as current as the year-old half."""
    ctx = PricingContext(books=BOOKS, method_weights={"power": 1.0},
                         book_weights={"pinnacle": 1.0},
                         method_age=60.0, book_age=400 * 86400.0)
    assert ctx.age == pytest.approx(400 * 86400.0)


def test_old_weights_are_flagged_stale(db):
    ctx = PricingContext(books=BOOKS, method_weights={"power": 1.0},
                         method_age=MAX_WEIGHT_AGE + 86400.0)
    assert ctx.stale
    assert "STALE" in ctx.describe()


def test_fresh_weights_are_not_flagged():
    ctx = PricingContext(books=BOOKS, method_weights={"power": 1.0},
                         method_age=3600.0)
    assert not ctx.stale
    assert "STALE" not in ctx.describe()


def test_a_stale_calibration_is_still_used(db):
    """Reverting to defaults silently would be a behaviour change nobody could
    see. It stays in force and is labelled."""
    ctx = PricingContext(books=BOOKS, method_weights={"power": 1.0},
                         method_age=MAX_WEIGHT_AGE * 5)
    assert ctx.stale
    assert ctx.method_weights == {"power": 1.0}


def test_an_uncalibrated_context_is_never_stale():
    assert not PricingContext.uncalibrated(BOOKS).stale


# -------------------------------------------------------------- the pricing


def test_calibrated_devig_weights_change_the_price(db):
    """The bug this module exists to fix: the loop measured correctly and then
    priced as though it had not."""
    plain = PricingContext(books=BOOKS)
    tilted = PricingContext(books=BOOKS, method_weights={"multiplicative": 1.0},
                            method_age=60.0)

    a = price_market(market(), plain, now=NOW)
    b = price_market(market(), tilted, now=NOW)
    assert a and b
    assert a[0].fair_prob != pytest.approx(b[0].fair_prob)


def test_calibrated_book_weights_change_a_fair_value():
    plain = PricingContext(books=BOOKS)
    tilted = PricingContext(
        books=BOOKS,
        book_weights={**{k: b.weight for k, b in BOOKS.items()},
                      "circa": 0.01, "pinnacle": 2.0},
        book_age=60.0,
    )
    assert (fair_for(market(), plain)["home"].prob
            != pytest.approx(fair_for(market(), tilted)["home"].prob))


def test_pricing_applies_the_fill_model(db):
    for _ in range(40):
        db.record_attempt(book="dk", market_type="h2h", quote_age=2.0,
                          accepted=False)
    ctx = PricingContext.from_ledger(db, BOOKS)
    edges = price_market(market(seen_at=NOW - 30), ctx, now=NOW)
    assert edges
    assert all(e.p_fill < 1.0 for e in edges)


def test_pricing_applies_the_latency_floor(db):
    for i in range(30):
        db.record_quote(event_id=f"q{i}", sport="nfl", market_type="h2h",
                        outcome="home", book="dk", decimal_odds=2.0,
                        seen_at=1000.0, fetched_at=1020.0)
    ctx = PricingContext.from_ledger(db, BOOKS)
    plain = PricingContext(books=BOOKS, fill=ctx.fill)

    with_lat = price_market(market(), ctx, now=NOW)
    without = price_market(market(), plain, now=NOW)
    dk_with = [e for e in with_lat if e.book == "dk"]
    dk_without = [e for e in without if e.book == "dk"]
    if dk_with and dk_without:
        assert dk_with[0].quote_age > dk_without[0].quote_age


def test_pricing_an_empty_market_is_not_a_crash():
    empty = Market(event_id="e0", sport="nfl", market_type="h2h", quotes=[])
    assert price_market(empty, PricingContext.uncalibrated(BOOKS), now=NOW) == []


# ------------------------------------------------------------- provenance


def test_the_context_serialises_what_priced_a_bet():
    ctx = PricingContext(books=BOOKS, method_weights={"power": 0.9},
                         method_age=2 * 86400.0, sport="nfl",
                         market_type="h2h")
    record = ctx.as_record()
    assert record["method_weights"]["power"] == pytest.approx(0.9)
    assert record["method_age_days"] == pytest.approx(2.0)
    assert record["scope"] == "nfl/h2h"


def test_an_uncalibrated_record_is_explicit_not_empty():
    record = PricingContext.uncalibrated(BOOKS).as_record()
    assert record["method_weights"] is None
    assert record["method_age_days"] is None


def test_weights_round_trip_onto_the_bet(db):
    """Without this a bad calibration is undiagnosable: the weights have since
    been overwritten and nothing says which were in force."""
    ctx = PricingContext(books=BOOKS, method_weights={"power": 0.9},
                         method_age=86400.0, sport="nfl", market_type="h2h")
    bet_id = db.record_bet(
        event_id="e1", sport="nfl", market_type="h2h", outcome="home",
        book="dk", decimal_odds=2.10, stake=100.0,
        at_bet=AtBet(fair_prob=0.50, fair_low=0.47, fair_high=0.53,
                     devig={"power": 0.50, "shin": 0.50},
                     weights=ctx.as_record()),
    )
    stored = db.weights_at_bet(bet_id)
    assert stored["method_weights"]["power"] == pytest.approx(0.9)
    assert stored["scope"] == "nfl/h2h"


def test_a_bet_without_recorded_weights_reads_as_empty(db):
    bet_id = db.record_bet(
        event_id="e1", sport="nfl", market_type="h2h", outcome="home",
        book="dk", decimal_odds=2.10, stake=100.0,
        at_bet=AtBet(fair_prob=0.50, fair_low=0.47, fair_high=0.53,
                     devig={"power": 0.50, "shin": 0.50}),
    )
    assert db.weights_at_bet(bet_id) == {}


def test_weights_at_bet_rejects_an_unknown_id(db):
    from overlay_engine.ledger import LedgerError

    with pytest.raises(LedgerError, match="no bet"):
        db.weights_at_bet(999)


def test_a_v3_database_migrates_to_v4(tmp_path):
    from overlay_engine.ledger import SCHEMA_VERSION

    path = tmp_path / "v3.db"
    with Ledger(path) as db:
        db.record_bet(
            event_id="e1", sport="nfl", market_type="h2h", outcome="home",
            book="dk", decimal_odds=2.10, stake=100.0,
            at_bet=AtBet(fair_prob=0.50, fair_low=0.47, fair_high=0.53,
                         devig={"power": 0.50, "shin": 0.50}),
        )
        db.conn.execute("ALTER TABLE bets DROP COLUMN weights_json")
        db.conn.execute("UPDATE meta SET value = '3' WHERE key = 'schema_version'")
        db.conn.commit()

    with Ledger(path) as db:
        assert db._has_column("bets", "weights_json")
        assert db.stats()["bets"] == 1
        row = db.conn.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        assert int(row["value"]) == SCHEMA_VERSION
