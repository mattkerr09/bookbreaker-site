"""Fill probability and account heat — the two models nobody else ships."""

import pytest

from overlay_engine.heat import (
    AccountHeat,
    BetRecord,
    market_heat,
    reaction_heat,
    shape,
    stake_precision_heat,
    velocity_heat,
)
from overlay_engine.models import Book, BookTier
from overlay_engine.staleness import (
    PRIOR_TAU,
    FillModel,
    Observation,
    market_class,
)

DK = Book(key="dk", name="DraftKings", tier=BookTier.RETAIL)
PIN = Book(key="pinnacle", name="Pinnacle", tier=BookTier.SHARP, limits_winners=False)
KALSHI = Book(key="kalshi", name="Kalshi", tier=BookTier.EXCHANGE, limits_winners=False)
BOOKS = {b.key: b for b in (DK, PIN, KALSHI)}


@pytest.mark.parametrize(
    "market_type,expected",
    [
        ("h2h", "moneyline"),
        ("spreads", "spread"),
        ("totals", "total"),
        ("player_points", "player_prop"),
        ("alternate_spreads", "alt_line"),
        ("live_h2h", "live"),
        ("outrights", "futures"),
        ("something_else", "default"),
    ],
)
def test_market_class_buckets(market_type, expected):
    assert market_class(market_type) == expected


def test_fill_starts_at_the_prior():
    model = FillModel()
    assert model.tau("dk", "h2h") == PRIOR_TAU["moneyline"]
    assert not model.is_fitted("dk", "h2h")


def test_live_markets_are_priced_as_faster_than_pregame():
    model = FillModel()
    assert model.p_fill("dk", "live_h2h", 20.0) < model.p_fill("dk", "h2h", 20.0)


def test_fill_decays_with_age():
    model = FillModel()
    fresh = model.p_fill("dk", "h2h", 1.0)
    stale = model.p_fill("dk", "h2h", 120.0)
    assert 0.0 < stale < fresh <= 1.0


def test_a_zero_age_quote_is_certain():
    assert FillModel().p_fill("dk", "h2h", 0.0) == 1.0


def test_fill_has_a_floor_so_stale_and_unknown_stay_distinguishable():
    assert FillModel().p_fill("dk", "live_h2h", 10_000.0) == pytest.approx(0.01)


def test_rejections_shorten_the_estimated_lifetime():
    model = FillModel()
    before = model.tau("dk", "h2h")
    for _ in range(40):
        model.observe(Observation(book="dk", market="h2h", age=5.0, accepted=False))
    assert model.tau("dk", "h2h") < before
    assert model.is_fitted("dk", "h2h")


def test_accepts_lengthen_it():
    model = FillModel()
    before = model.tau("dk", "h2h")
    for _ in range(40):
        model.observe(Observation(book="dk", market="h2h", age=80.0, accepted=True))
    assert model.tau("dk", "h2h") > before


def test_an_accept_dates_survival_not_death():
    """An accept at 40s says the quote lived at least 40s; only a reject
    dates its death. The estimator has to treat them differently."""
    accepts = FillModel()
    rejects = FillModel()
    for _ in range(30):
        accepts.observe(Observation(book="dk", market="h2h", age=30.0, accepted=True))
        rejects.observe(Observation(book="dk", market="h2h", age=30.0, accepted=False))
    assert accepts.tau("dk", "h2h") > rejects.tau("dk", "h2h")


def test_the_prior_dominates_a_tiny_sample():
    """Five bets must not overturn a shipped default."""
    model = FillModel()
    prior = model.tau("dk", "h2h")
    for _ in range(3):
        model.observe(Observation(book="dk", market="h2h", age=1.0, accepted=False))
    assert abs(model.tau("dk", "h2h") - prior) < prior * 0.35


def test_the_estimate_is_capped_when_nothing_has_been_rejected():
    """'Nothing rejected yet' is not evidence that nothing ever will be."""
    model = FillModel()
    for _ in range(200):
        model.observe(Observation(book="dk", market="h2h", age=600.0, accepted=True))
    assert model.tau("dk", "h2h") <= model.max_tau


def test_books_are_modelled_separately():
    model = FillModel()
    for _ in range(40):
        model.observe(Observation(book="dk", market="h2h", age=2.0, accepted=False))
    assert model.tau("dk", "h2h") < model.tau("fd", "h2h")


def test_half_life_is_the_human_number():
    model = FillModel()
    hl = model.half_life("dk", "h2h")
    assert model.p_fill("dk", "h2h", hl) == pytest.approx(0.5, abs=1e-9)


def test_fill_model_round_trips_through_a_dict():
    model = FillModel()
    for _ in range(20):
        model.observe(Observation(book="dk", market="player_points", age=9.0, accepted=False))
    restored = FillModel.from_dict(model.to_dict())
    assert restored.tau("dk", "player_points") == pytest.approx(
        model.tau("dk", "player_points")
    )


@pytest.mark.parametrize(
    "stake,ceiling",
    [(473.82, 1.01), (100.0, 0.01), (250.0, 0.13), (95.0, 0.31), (97.0, 0.76)],
)
def test_stake_precision_heat_ladder(stake, ceiling):
    assert stake_precision_heat(stake) <= ceiling


def test_cents_are_the_loudest_signal():
    assert stake_precision_heat(473.82) == 1.0
    assert stake_precision_heat(473.82) > stake_precision_heat(473.0)


def test_reaction_heat_peaks_on_instant_placement():
    assert reaction_heat(0.0) == pytest.approx(1.0)
    assert reaction_heat(300.0) < 0.01
    assert reaction_heat(0.0) > reaction_heat(30.0) > reaction_heat(120.0)


def test_unknown_reaction_time_scores_mid_not_zero():
    """An unmeasured signal is not an absent one."""
    assert reaction_heat(None) == 0.5


def test_velocity_is_flat_for_a_recreational_evening():
    assert velocity_heat(3) == 0.0
    assert velocity_heat(8) > 0
    assert velocity_heat(50) == 1.0


def test_exotic_markets_carry_more_heat_than_main_ones():
    assert market_heat("alternate_spreads") > market_heat("player_points")
    assert market_heat("player_points") > market_heat("h2h")


def test_heat_accumulates_and_decays():
    account = AccountHeat()
    for i in range(10):
        account.add(
            BetRecord(book="dk", stake=127.43, market_type="alternate_spreads",
                      placed_at=1000.0 + i, seconds_since_line_move=0.5)
        )
    hot = account.score("dk", BOOKS, now=1010.0)
    cold = account.score("dk", BOOKS, now=1010.0 + 86400.0)
    assert hot > 0.5
    assert cold < hot


def test_ten_mechanical_bets_are_worse_than_one():
    """An average would rate them identically."""
    one = AccountHeat()
    one.add(BetRecord(book="dk", stake=127.43, market_type="alternate_spreads",
                      placed_at=1000.0, seconds_since_line_move=0.5))
    many = AccountHeat()
    for i in range(10):
        many.add(BetRecord(book="dk", stake=127.43, market_type="alternate_spreads",
                           placed_at=1000.0 + i, seconds_since_line_move=0.5))
    assert many.score("dk", BOOKS, now=1010.0) > one.score("dk", BOOKS, now=1010.0)


def test_recreational_bets_cool_the_profile():
    mechanical = BetRecord(book="dk", stake=127.43, market_type="alternate_spreads",
                           placed_at=1000.0, seconds_since_line_move=0.5)
    recreational = BetRecord(book="dk", stake=25.0, market_type="h2h",
                             placed_at=1000.0, seconds_since_line_move=600.0,
                             recreational=True)
    account = AccountHeat()
    assert account.bet_heat(recreational) < account.bet_heat(mechanical)


def test_books_that_never_limit_score_zero():
    """Spending anti-limiting effort at Pinnacle buys protection from a risk
    desk that does not exist."""
    account = AccountHeat()
    for i in range(20):
        account.add(BetRecord(book="pinnacle", stake=473.82, market_type="alternate_spreads",
                              placed_at=1000.0 + i, seconds_since_line_move=0.1))
    assert account.score("pinnacle", BOOKS, now=1020.0) == 0.0
    assert account.score("kalshi", BOOKS, now=1020.0) == 0.0


def test_an_untouched_book_is_cold():
    assert AccountHeat().score("dk", BOOKS, now=1000.0) == 0.0
    assert AccountHeat().seconds_since_last("dk", now=1000.0) is None


def test_shaping_rounds_the_stake_for_free():
    account = AccountHeat()
    result = shape("dk", stake=473.82, edge=0.03, account=account, books=BOOKS, now=1000.0)
    assert result.stake == 470.0
    assert "rounded" in result.reason
    assert not result.defer


def test_shaping_leaves_non_limiting_books_alone():
    account = AccountHeat()
    result = shape("pinnacle", stake=473.82, edge=0.03, account=account, books=BOOKS, now=1000.0)
    assert result.stake == 473.82
    assert result.reason == ""
    assert not result.acted


def test_a_cooldown_delays_a_clustered_bet():
    account = AccountHeat()
    account.add(BetRecord(book="dk", stake=100.0, market_type="h2h", placed_at=995.0))
    result = shape("dk", stake=100.0, edge=0.03, account=account, books=BOOKS, now=1000.0)
    assert result.delay > 0


def test_a_hot_account_raises_its_edge_floor():
    account = AccountHeat()
    for i in range(12):
        account.add(BetRecord(book="dk", stake=127.43, market_type="alternate_spreads",
                              placed_at=900.0 + i * 5, seconds_since_line_move=0.4))
    marginal = shape("dk", stake=100.0, edge=0.012, account=account, books=BOOKS, now=1000.0)
    strong = shape("dk", stake=100.0, edge=0.08, account=account, books=BOOKS, now=1000.0)
    assert marginal.min_edge > 0
    assert marginal.defer
    assert not strong.defer or "hour" in strong.reason


def test_burst_velocity_defers_regardless_of_edge():
    account = AccountHeat()
    for i in range(9):
        account.add(BetRecord(book="dk", stake=100.0, market_type="h2h",
                              placed_at=400.0 + i * 60))
    result = shape("dk", stake=100.0, edge=0.20, account=account, books=BOOKS, now=1000.0)
    assert result.defer
    assert "last hour" in result.reason


def test_heat_is_bounded():
    account = AccountHeat()
    for i in range(200):
        account.add(BetRecord(book="dk", stake=127.43, market_type="alternate_spreads",
                              placed_at=1000.0 + i, seconds_since_line_move=0.1))
    assert 0.0 <= account.score("dk", BOOKS, now=1200.0) <= 1.0
