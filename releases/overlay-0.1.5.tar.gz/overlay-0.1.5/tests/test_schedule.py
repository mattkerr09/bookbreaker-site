"""Capturing the close is the one job where late is wrong rather than worse,
and the failure is silent: a price taken after the off still stores, still
grades, and still trains the model."""

import pytest

from overlay_engine.models import Market
from overlay_engine.schedule import EARLIEST, LEAD, next_run_at, plan

NOW = 1_800_000_000.0
MIN = 60.0


def _market(event_id, starts_in, market_type="h2h", sport="nfl"):
    return Market(event_id=event_id, sport=sport, market_type=market_type,
                  quotes=[],
                  starts_at=None if starts_in is None else NOW + starts_in)


# ------------------------------------------------------------- due or not

def test_a_market_inside_the_window_is_due():
    got = plan([_market("a", 4 * MIN)], NOW)
    assert [d.event_id for d in got.due] == ["a"]


def test_a_market_far_out_is_not_due_and_is_not_an_error():
    got = plan([_market("a", EARLIEST + MIN)], NOW)
    assert got.due == []
    assert got.reasons() == {"not due yet": 1}


def test_a_market_exactly_at_the_earliest_bound_is_due():
    assert plan([_market("a", EARLIEST)], NOW).due


def test_a_started_market_is_refused_rather_than_captured_late():
    """A line taken after the off is a live price with a settled scoreline
    behind it; grading against it would score the model as prescient."""
    got = plan([_market("a", -MIN)], NOW)
    assert got.due == []
    assert "not a closing line" in list(got.reasons())[0]


def test_a_market_starting_exactly_now_is_refused():
    got = plan([_market("a", 0.0)], NOW)
    assert got.due == []


def test_a_market_with_no_start_time_is_refused_not_guessed():
    """Capturing at an arbitrary moment stores that moment as the close, and
    nothing downstream can tell."""
    got = plan([_market("a", None)], NOW)
    assert got.due == []
    assert "no start time recorded" in list(got.reasons())[0]


# ------------------------------------------------------------ idempotence

def test_a_market_already_captured_is_not_captured_again():
    """A second capture would overwrite a close taken at the right moment with
    one taken later."""
    got = plan([_market("a", 4 * MIN)], NOW, closed={("a", "h2h")})
    assert got.due == []
    assert got.reasons() == {"close already captured": 1}


def test_the_capture_key_is_event_and_market_together():
    """Two market types on one event close separately."""
    markets = [_market("a", 4 * MIN, "h2h"), _market("a", 4 * MIN, "totals")]
    got = plan(markets, NOW, closed={("a", "h2h")})
    assert [d.market_type for d in got.due] == ["totals"]


def test_running_the_pass_twice_captures_once():
    markets = [_market("a", 4 * MIN)]
    first = plan(markets, NOW)
    assert first.due
    captured = {(d.event_id, d.market_type) for d in first.due}
    assert plan(markets, NOW + 30, closed=captured).due == []


# ------------------------------------------------------------- lateness

def test_a_capture_inside_the_lead_is_flagged_late_but_still_due():
    """Four minutes out is better than nothing, and a pass that is habitually
    late has a schedule that is wrong."""
    got = plan([_market("a", LEAD - MIN)], NOW)
    assert got.due and got.due[0].late
    assert "running late" in got.describe()


def test_a_capture_outside_the_lead_is_not_late():
    got = plan([_market("a", LEAD + MIN)], NOW)
    assert got.due and not got.due[0].late
    assert "running late" not in got.describe()


# --------------------------------------------------------------- order

def test_the_soonest_start_is_captured_first():
    markets = [_market("late", 20 * MIN), _market("soon", 2 * MIN),
               _market("mid", 9 * MIN)]
    assert [d.event_id for d in plan(markets, NOW).due] == ["soon", "mid", "late"]


# --------------------------------------------------------- the next run

def test_the_next_run_is_when_the_soonest_market_enters_its_window():
    markets = [_market("a", 60 * MIN), _market("b", 90 * MIN)]
    assert next_run_at(markets, NOW) == pytest.approx(NOW + 60 * MIN - LEAD)


def test_an_overdue_pass_is_due_now_rather_than_in_the_past():
    """"Two minutes ago" is not a time anyone can sleep until, and a caller
    printing a countdown would show a negative one."""
    markets = [_market("a", LEAD - 2 * MIN)]      # already inside its window
    assert next_run_at(markets, NOW) == NOW


def test_nothing_pending_reports_no_next_run_rather_than_zero():
    """Zero would read as "run immediately" — an idle scheduler must be able to
    say it is idle rather than look hung."""
    assert next_run_at([], NOW) is None
    assert next_run_at([_market("a", -MIN)], NOW) is None


def test_captured_markets_do_not_hold_the_schedule_open():
    markets = [_market("a", 60 * MIN)]
    assert next_run_at(markets, NOW, closed={("a", "h2h")}) is None


def test_a_market_with_no_start_never_sets_the_next_run():
    assert next_run_at([_market("a", None)], NOW) is None


# ------------------------------------------------------------- reporting

def test_the_plan_counts_every_reason_it_skipped_something():
    markets = [_market("started", -MIN), _market("undated", None),
               _market("far", EARLIEST + MIN), _market("done", 4 * MIN)]
    got = plan(markets, NOW, closed={("done", "h2h")})
    assert got.due == []
    assert sum(got.reasons().values()) == 4
    assert len(got.reasons()) == 4


def test_describe_names_the_due_count():
    assert "1 market(s) due" in plan([_market("a", 4 * MIN)], NOW).describe()


# --------------------------------------------------- through the ledger

def test_closed_markets_reads_back_what_was_captured(tmp_path):
    from overlay_engine.ledger import Ledger
    from overlay_engine.models import Outcome, Quote

    market = Market(event_id="e1", sport="nfl", market_type="h2h",
                    starts_at=NOW + 4 * MIN,
                    quotes=[Quote(book="dk", outcome=Outcome("home"),
                                  decimal=1.91, seen_at=NOW)])
    with Ledger(str(tmp_path / "s.db")) as db:
        assert plan([market], NOW, closed=db.closed_markets()).due
        db.record_market(market, is_closing=True)
        assert db.closed_markets() == {("e1", "h2h")}
        assert plan([market], NOW, closed=db.closed_markets()).due == []


def test_a_non_closing_capture_does_not_count_as_the_close(tmp_path):
    """Ordinary captures happen constantly; only the closing one is grading
    truth, and treating a routine capture as one would freeze the wrong price."""
    from overlay_engine.ledger import Ledger
    from overlay_engine.models import Outcome, Quote

    market = Market(event_id="e1", sport="nfl", market_type="h2h",
                    starts_at=NOW + 4 * MIN,
                    quotes=[Quote(book="dk", outcome=Outcome("home"),
                                  decimal=1.91, seen_at=NOW)])
    with Ledger(str(tmp_path / "s.db")) as db:
        db.record_market(market, is_closing=False)
        assert db.closed_markets() == set()
        assert plan([market], NOW, closed=db.closed_markets()).due
