"""Bucketing exists so that groups are big enough to measure.

The bug it fixes is quiet: grouping on the raw note put every event in a group
of one, so `paired` collapsed and the correlation either fell back to the prior
or was measured off whichever notes happened to be typed identically.
"""

import pytest

from overlay_engine.correlation import MIN_GROUPS, measure
from overlay_engine.weather import (
    TEMP_BANDS,
    WIND_BANDS,
    bucket,
    buckets,
    describe,
    indoor,
    precipitation,
    temperature_f,
    wind_band,
    wind_mph,
)

DAY = 86_400.0


# --------------------------------------------------------- the actual bug

def test_two_notes_a_mile_an_hour_apart_land_in_one_bucket():
    """The regression this module exists for."""
    assert bucket("wind 18mph") == bucket("wind 19mph")


def test_the_same_conditions_written_differently_still_group():
    assert bucket("Wind 20 mph") == bucket("winds of 20mph") == bucket("20 MPH")


def test_grouping_on_raw_notes_would_have_produced_groups_of_one():
    """Ten events, ten slightly different notes, all the same weather.

    Raw strings give ten groups of one and nothing to measure. Bucketed they
    give one group of ten.
    """
    notes = [f"wind {17 + i * 0.1:.1f}mph" for i in range(10)]
    assert len({n for n in notes}) == 10
    assert len({bucket(n) for n in notes}) == 1


# ------------------------------------------------------------- wind

def test_wind_bands_are_ordered_and_cover_everything():
    uppers = [u for u, _ in WIND_BANDS]
    assert uppers == sorted(uppers)
    assert uppers[-1] == float("inf")


@pytest.mark.parametrize("speed,band", [
    (0, "calm"), (7.9, "calm"), (8, "breezy"), (15.9, "breezy"),
    (16, "windy"), (24.9, "windy"), (25, "gale"), (80, "gale"),
])
def test_every_wind_band_edge(speed, band):
    assert wind_band(f"{speed}mph") == band


def test_kph_is_converted_rather_than_read_as_mph():
    """20 kph is 12 mph and breezy. Read as mph the same figure is windy, one
    band out, which is the whole cost of ignoring the unit."""
    assert wind_band("20 kph") == "breezy"
    assert wind_band("20 mph") == "windy"
    # And at the top end the gap is two bands.
    assert wind_band("40 kph") == "windy"
    assert wind_band("40 mph") == "gale"


def test_km_per_hour_spelled_with_a_slash_also_converts():
    assert wind_mph("40 km/h") == pytest.approx(24.85, abs=0.1)


def test_wind_words_band_when_there_is_no_figure():
    assert wind_band("calm") == "calm"
    assert wind_band("gusty") == "windy"
    assert wind_band("howling") == "gale"


def test_a_figure_beats_a_word_that_disagrees_with_it():
    """"light breeze, 22mph" is a note contradicting itself, and the number is
    the half somebody measured."""
    assert wind_band("light breeze, 22mph") == "windy"


def test_a_note_with_no_wind_information_has_no_band():
    assert wind_band("partly cloudy") is None
    assert wind_mph("partly cloudy") is None


# ------------------------------------------------------ temperature

def test_celsius_is_converted():
    assert temperature_f("0C") == pytest.approx(32.0)
    assert temperature_f("100 C") == pytest.approx(212.0)


def test_fahrenheit_is_left_alone():
    assert temperature_f("75F") == pytest.approx(75.0)


def test_a_bare_number_is_refused_because_the_unit_decides_the_game():
    assert temperature_f("12") is None


def test_negative_temperatures_parse():
    assert temperature_f("-5F") == pytest.approx(-5.0)


def test_temperature_is_deliberately_not_in_the_bucket():
    """Adding five bands multiplies the bucket count by five and thins every
    group by the same factor — the exact problem this module fixes."""
    assert bucket("wind 20mph, 75F") == bucket("wind 20mph, 10F")


def test_temperature_bands_are_ordered_and_cover_everything():
    uppers = [u for u, _ in TEMP_BANDS]
    assert uppers == sorted(uppers)
    assert uppers[-1] == float("inf")


# ---------------------------------------------------------- indoor

def test_a_closed_roof_is_indoor_however_it_is_written():
    for note in ("dome", "Dome", "indoors", "roof closed", "closed roof"):
        assert bucket(note) == "indoor"


def test_indoor_ignores_the_weather_outside():
    """A closed roof has no weather, and every such game shares that."""
    assert bucket("dome, 30mph gale outside, snow") == "indoor"


# --------------------------------------------------- precipitation

def test_snow_outranks_rain_when_a_note_says_both():
    assert precipitation("rain turning to snow") == "snow"


def test_dry_words_are_recognised():
    for note in ("clear", "sunny", "dry", "fair"):
        assert precipitation(note) == "dry"


def test_a_note_silent_on_precipitation_says_nothing():
    assert precipitation("wind 12mph") is None


# ---------------------------------------------------- unreadable notes

def test_an_unreadable_note_is_excluded_rather_than_bucketed():
    """A bucket of everything nobody could parse is the largest correlated
    block in the book, assembled out of bad handwriting."""
    assert bucket("who knows") is None
    assert bucket("partly cloudy 12") is None


def test_empty_and_missing_notes_are_excluded():
    assert bucket("") is None
    assert bucket("   ") is None
    assert bucket(None) is None


def test_describe_says_why_an_unreadable_note_was_dropped():
    assert "not readable" in describe("who knows")


def test_describe_marks_temperature_as_outside_the_bucket():
    shown = describe("wind 20mph, 40F")
    assert "not in the bucket" in shown


# ------------------------------------------------------ bounded set

def test_the_bucket_set_is_bounded():
    """An unbounded bucket count is the raw string wearing a different name."""
    assert len(buckets()) < 30


def test_every_bucket_a_note_can_produce_is_in_the_declared_set():
    notes = [
        "dome", "wind 3mph", "wind 12mph", "wind 20mph", "wind 40mph",
        "wind 3mph rain", "wind 12mph snow", "wind 20mph clear",
        "wind 40mph sleet", "rain", "snow", "sunny", "calm", "gusty",
    ]
    declared = set(buckets())
    for note in notes:
        got = bucket(note)
        assert got in declared, f"{note!r} produced {got!r}, not in buckets()"


# ------------------------------------------------- through correlation

def _rows(notes):
    rows, meta = [], {}
    for i, note in enumerate(notes):
        event = f"e{i}"
        rows.append({"event_id": event, "sport": "nfl", "placed_at": i * DAY,
                     "stake": 100.0, "profit": (1.0 if i % 2 else -1.0) * 100.0})
        meta[event] = {"weather": note}
    return rows, meta


def test_bucketing_turns_singleton_groups_into_measurable_ones():
    """The end-to-end point: raw notes give nothing to pair, buckets give
    groups. Both runs use the same bets and the same conditions."""
    notes = [f"wind {17 + i * 0.05:.2f}mph" for i in range(80)]
    rows, meta = _rows(notes)
    got = measure(rows, key="weather", meta=meta)
    # Every note buckets to one group, so every bet is paired.
    assert got.groups == 1
    assert got.coverage == 1.0


def test_unreadable_notes_lower_coverage_rather_than_forming_a_group():
    notes = ["wind 20mph"] * 40 + ["who knows"] * 40
    rows, meta = _rows(notes)
    got = measure(rows, key="weather", meta=meta)
    assert got.coverage == pytest.approx(0.5, abs=0.02)
    assert got.groups == 1        # the readable half only


def test_a_book_of_unreadable_notes_is_refused_not_lumped():
    rows, meta = _rows(["who knows"] * 80)
    got = measure(rows, key="weather", meta=meta)
    assert got.coverage == 0.0
    assert not got.measured
    assert got.groups < MIN_GROUPS
