"""Open positions: what each result pays, and what the list cannot see."""

import pytest

from overlay_engine.exposure import (
    CONCENTRATION_FLAG,
    MarketExposure,
    Position,
    report,
)
from overlay_engine.ledger import AtBet, Ledger

DEVIG = {"power": 0.50, "shin": 0.50, "additive": 0.50, "multiplicative": 0.50}


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "exp.db") as ledger:
        yield ledger


def place(db, i, *, outcome="home", decimal=2.0, stake=100.0, event="e1",
          book="dk", sport="nfl", market="h2h"):
    return db.record_bet(
        event_id=event, sport=sport, market_type=market, outcome=outcome,
        book=book, decimal_odds=decimal, stake=stake, placed_at=1000.0 + i,
        at_bet=AtBet(fair_prob=0.50, fair_low=0.47, fair_high=0.53,
                     devig=dict(DEVIG)),
    )


def quote(db, outcome, event="e1", market="h2h", book="pinnacle"):
    db.record_quote(event_id=event, sport="nfl", market_type=market,
                    outcome=outcome, book=book, decimal_odds=1.95,
                    seen_at=900.0)


def pos(outcome, decimal, stake, event="e1"):
    return Position(bet_id=1, event_id=event, sport="nfl", market_type="h2h",
                    outcome=outcome, book="dk", decimal=decimal, stake=stake,
                    placed_at=1000.0)


# ------------------------------------------------------------- the scenarios


def test_a_single_position_pays_one_way_and_loses_the_other():
    m = MarketExposure(event_id="e1", sport="nfl", market_type="h2h",
                       positions=[pos("home", 2.0, 100.0)],
                       known=["home", "away"])
    assert m.payout("home") == pytest.approx(100.0)
    assert m.payout("away") == pytest.approx(-100.0)
    assert m.at_risk == pytest.approx(100.0)


def test_both_sides_at_a_profit_is_a_locked_market():
    """Bet both sides and one leg always returns — the worst case is a win."""
    m = MarketExposure(event_id="e1", sport="nfl", market_type="h2h",
                       positions=[pos("home", 2.10, 490.0),
                                  pos("away", 2.05, 500.0)],
                       known=["home", "away"])
    assert m.locked
    assert m.worst[1] > 0


def test_doubling_down_reads_as_doubling_down():
    """The same side twice returns nothing on the other result."""
    m = MarketExposure(event_id="e1", sport="nfl", market_type="h2h",
                       positions=[pos("home", 2.0, 100.0),
                                  pos("home", 2.0, 100.0)],
                       known=["home", "away"])
    assert m.at_risk == pytest.approx(200.0)
    assert m.payout("away") == pytest.approx(-200.0)
    assert not m.locked


def test_scenarios_come_back_worst_first():
    m = MarketExposure(event_id="e1", sport="nfl", market_type="h2h",
                       positions=[pos("home", 3.0, 100.0)],
                       known=["home", "away", "draw"])
    scenarios = m.scenarios()
    assert scenarios[0][1] <= scenarios[-1][1]
    assert m.worst == scenarios[0]
    assert m.best == scenarios[-1]


def test_an_outcome_nobody_bet_still_has_a_payout():
    m = MarketExposure(event_id="e1", sport="soccer", market_type="h2h",
                       positions=[pos("home", 2.5, 100.0)],
                       known=["home", "away", "draw"])
    assert m.payout("draw") == pytest.approx(-100.0)
    assert m.uncovered == ["away", "draw"]


# ------------------------------------------- the outcome you did not bet


def test_inferring_the_outcome_set_from_your_own_bets_is_flagged():
    """A three-way market where you hold two sides looks covered if the
    outcome set comes from your slips. It is not."""
    m = MarketExposure(event_id="e1", sport="soccer", market_type="h2h",
                       positions=[pos("home", 3.0, 100.0),
                                  pos("away", 3.2, 100.0)],
                       known=[])
    assert m.inferred
    assert m.outcomes == ["away", "home"]
    assert "inferred" in m.describe()


def test_an_inferred_market_is_never_reported_as_locked():
    """Every result it can see is one you bet on, which guarantees a
    flattering answer."""
    m = MarketExposure(event_id="e1", sport="soccer", market_type="h2h",
                       positions=[pos("home", 3.0, 100.0),
                                  pos("away", 3.2, 100.0)],
                       known=[])
    assert m.worst[1] > 0
    assert not m.locked


def test_recorded_quotes_reveal_the_outcome_that_hurts(db):
    place(db, 0, outcome="home", decimal=3.0)
    place(db, 1, outcome="away", decimal=3.2)
    for outcome in ("home", "away", "draw"):
        quote(db, outcome)

    market = report(db).markets[0]
    assert not market.inferred
    assert market.uncovered == ["draw"]
    assert market.worst == ("draw", pytest.approx(-200.0))
    assert not market.locked


def test_without_quotes_the_same_position_looks_safe(db):
    """The point of the flag, shown side by side."""
    place(db, 0, outcome="home", decimal=3.0)
    place(db, 1, outcome="away", decimal=3.2)
    market = report(db).markets[0]
    assert market.inferred
    assert market.worst[1] > 0
    # The market-level line says "inferred"; the report says why it matters.
    assert "inferred" in market.describe()
    assert "worst case is optimistic" in report(db).verdict()


# ---------------------------------------------------------------- the report


def test_open_positions_are_the_unpaid_ones(db):
    settled = place(db, 0, event="paid")
    place(db, 1, event="open")
    db.settle(settled, closing_fair_prob=0.5, result="won", profit=100.0)
    rep = report(db)
    assert rep.positions == 1
    assert rep.markets[0].event_id == "open"


def test_a_graded_but_unpaid_bet_is_still_at_risk(db):
    """Grading is not settlement."""
    bet_id = place(db, 0)
    db.settle(bet_id, closing_fair_prob=0.5)
    assert report(db).positions == 1
    assert report(db).at_risk == pytest.approx(100.0)


def test_the_worst_case_sums_the_per_market_worsts(db):
    place(db, 0, event="a", stake=100.0)
    place(db, 1, event="b", stake=50.0)
    for event in ("a", "b"):
        for outcome in ("home", "away"):
            quote(db, outcome, event=event)
    rep = report(db)
    assert rep.at_risk == pytest.approx(150.0)
    assert rep.worst_case == pytest.approx(-150.0)
    assert rep.best_case == pytest.approx(150.0)


def test_markets_are_ordered_by_money_at_risk(db):
    place(db, 0, event="small", stake=25.0)
    place(db, 1, event="big", stake=500.0)
    assert report(db).markets[0].event_id == "big"


def test_exposure_breaks_down_by_book_sport_and_event(db):
    place(db, 0, book="dk", sport="nfl", event="a", stake=100.0)
    place(db, 1, book="fd", sport="nba", event="b", stake=50.0)
    rep = report(db)
    assert rep.by_book == {"dk": 100.0, "fd": 50.0}
    assert rep.by_sport == {"nfl": 100.0, "nba": 50.0}
    assert rep.by_event["a"] == pytest.approx(100.0)


def test_concentration_names_the_event_carrying_the_risk(db):
    """Six positions without mentioning that five ride on one game is hiding
    the only thing that matters about them."""
    for i in range(5):
        place(db, i, event="bigmatch", stake=100.0)
    place(db, 9, event="other", stake=50.0)
    rep = report(db)
    event, share = rep.concentration
    assert event == "bigmatch"
    assert share == pytest.approx(500 / 550)
    assert rep.concentrated
    assert "on bigmatch" in rep.verdict()


def test_spread_exposure_is_not_flagged(db):
    for i in range(5):
        place(db, i, event=f"e{i}", stake=100.0)
    rep = report(db)
    assert rep.concentration[1] == pytest.approx(0.2)
    assert not rep.concentrated


def test_the_concentration_threshold_is_stated():
    assert CONCENTRATION_FLAG == 0.35


def test_filters_narrow_the_view(db):
    place(db, 0, book="dk", sport="nfl", event="a")
    place(db, 1, book="fd", sport="nba", event="b")
    assert report(db, book="dk").positions == 1
    assert report(db, sport="nba").positions == 1


def test_nothing_open_says_so(db):
    rep = report(db)
    assert rep.verdict() == "nothing open"
    assert rep.at_risk == 0.0
    assert rep.concentration == ("", 0.0)


def test_exposure_and_performance_do_not_double_count(db):
    """An open bet is money at risk, not money lost or won."""
    from overlay_engine.performance import from_ledger

    settled = place(db, 0, event="paid")
    place(db, 1, event="open")
    db.settle(settled, closing_fair_prob=0.5, result="won", profit=100.0)

    assert from_ledger(db).overall.n == 1
    assert report(db).positions == 1
