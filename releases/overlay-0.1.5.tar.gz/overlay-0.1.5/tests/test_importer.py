"""Reading a bet history out of a book's CSV export."""

import pytest

from overlay_engine.importer import (
    ImportError_,
    detect_columns,
    import_csv,
    parse_date,
    parse_money,
    parse_result,
)
from overlay_engine.ledger import Ledger, LedgerError
from overlay_engine.performance import from_ledger


@pytest.fixture
def db(tmp_path):
    with Ledger(tmp_path / "imp.db") as ledger:
        yield ledger


def write(tmp_path, text, name="bets.csv"):
    path = tmp_path / name
    path.write_text(text)
    return path


DK_EXPORT = """Date Placed,Sportsbook,Sport,Bet Type,Selection,Odds,Stake,Result,Profit,Bet ID
2026-01-05 13:20:00,DraftKings,NFL,Moneyline,Chiefs ML,-110,100.00,Won,90.91,DK-1
2026-01-05 16:05:00,DraftKings,NFL,Spread,Bills -3.5,+105,50.00,Lost,-50.00,DK-2
2026-01-06 12:00:00,DraftKings,NBA,Total,Over 220.5,-105,75.00,Push,0.00,DK-3
"""


# ------------------------------------------------------------------ parsing


@pytest.mark.parametrize("text,expected", [
    ("100.00", 100.0), ("$1,250.50", 1250.5), ("+90.91", 90.91),
    ("-50", -50.0), ("(50.00)", -50.0), ("£25", 25.0), ("", None), ("n/a", None),
])
def test_money_parsing(text, expected):
    assert parse_money(text) == expected


def test_parentheses_mean_negative():
    """Exported ledgers use it, and reading it as positive flips the sign of
    every losing bet in such a file."""
    assert parse_money("(125.00)") == -125.0


@pytest.mark.parametrize("text", [
    "2026-01-05 13:20:00", "2026-01-05T13:20:00", "01/05/2026 13:20",
    "01/05/2026", "Jan 05, 2026", "2026-01-05",
])
def test_date_formats_books_actually_use(text):
    assert parse_date(text) is not None


def test_epoch_seconds_and_milliseconds():
    assert parse_date("1767225600") == pytest.approx(1767225600.0)
    assert parse_date("1767225600000") == pytest.approx(1767225600.0)


def test_an_unreadable_date_is_none_not_now():
    assert parse_date("last tuesday") is None
    assert parse_date("") is None


@pytest.mark.parametrize("text,expected", [
    ("Won", "won"), ("WIN", "won"), ("w", "won"), ("Cashed", "won"),
    ("Lost", "lost"), ("Loss", "lost"), ("Push", "push"), ("Tie", "push"),
    ("Void", "void"), ("Cancelled", "void"), ("Refunded", "void"),
    ("", None), ("pending", None),
])
def test_result_words(text, expected):
    assert parse_result(text) == expected


# ------------------------------------------------------------ column mapping


def test_columns_are_detected_from_a_real_looking_header():
    mapping = detect_columns(
        ["Date Placed", "Sportsbook", "Sport", "Bet Type", "Selection",
         "Odds", "Stake", "Result", "Profit", "Bet ID"])
    assert mapping["placed_at"] == "Date Placed"
    assert mapping["book"] == "Sportsbook"
    assert mapping["decimal_odds"] == "Odds"
    assert mapping["stake"] == "Stake"
    assert mapping["profit"] == "Profit"
    assert mapping["external_ref"] == "Bet ID"


def test_an_exact_alias_beats_a_substring_one():
    """"odds" is a substring of "odds american"; a contains-first pass would
    bind the wrong column on a file offering both."""
    mapping = detect_columns(["Odds American", "Odds", "Stake", "Date"])
    assert mapping["decimal_odds"] == "Odds"


def test_unknown_headers_are_simply_absent():
    mapping = detect_columns(["foo", "bar"])
    assert "stake" not in mapping


# ------------------------------------------------------------ the import


def test_a_book_export_imports(db, tmp_path):
    report = import_csv(db, write(tmp_path, DK_EXPORT))
    assert report.imported == 3
    assert report.skipped == []
    assert db.stats()["bets"] == 3
    assert db.stats()["imported"] == 3


def test_imported_bets_reach_the_performance_report(db, tmp_path):
    """The reason this exists: the tracker is theoretical until bets can get
    in."""
    import_csv(db, write(tmp_path, DK_EXPORT))
    rep = from_ledger(db)
    assert rep.overall.n == 3
    assert rep.overall.profit == pytest.approx(40.91)
    assert rep.overall.push == 1
    assert rep.overall.win_rate == pytest.approx(0.5)


def test_re_importing_the_same_file_changes_nothing(db, tmp_path):
    path = write(tmp_path, DK_EXPORT)
    assert import_csv(db, path).imported == 3
    second = import_csv(db, path)
    assert second.imported == 0
    assert second.duplicates == 3
    assert db.stats()["bets"] == 3


def test_rows_without_a_book_id_still_deduplicate(db, tmp_path):
    """A second identical bet at the same second is not something anyone does
    by accident, and treating it as a duplicate is the safer error."""
    text = DK_EXPORT.replace(",Bet ID", ",Nothing").replace(
        "DK-1", "").replace("DK-2", "").replace("DK-3", "")
    path = write(tmp_path, text)
    assert import_csv(db, path).imported == 3
    assert import_csv(db, path).duplicates == 3


# --------------------------------------------------- payout is not profit


def test_a_payout_column_is_converted_not_read_as_profit(db, tmp_path):
    """Reading a payout as profit inflates every winning bet by its own stake —
    roughly doubling the reported return, with nothing downstream able to tell."""
    text = """Date,Book,Odds,Stake,Result,Payout
2026-01-05,DK,-110,100.00,Won,190.91
"""
    report = import_csv(db, write(tmp_path, text))
    assert report.profit_source == "payout"
    assert from_ledger(db).overall.profit == pytest.approx(90.91)


def test_a_profit_column_is_used_directly(db, tmp_path):
    text = """Date,Book,Odds,Stake,Result,Profit
2026-01-05,DK,-110,100.00,Won,90.91
"""
    report = import_csv(db, write(tmp_path, text))
    assert report.profit_source == "profit"
    assert from_ledger(db).overall.profit == pytest.approx(90.91)


def test_profit_wins_when_a_file_offers_both(db, tmp_path):
    text = """Date,Book,Odds,Stake,Result,Profit,Payout
2026-01-05,DK,-110,100.00,Won,90.91,190.91
"""
    assert import_csv(db, write(tmp_path, text)).profit_source == "profit"
    assert from_ledger(db).overall.profit == pytest.approx(90.91)


def test_profit_is_derived_when_the_file_gives_neither(db, tmp_path):
    text = """Date,Book,Odds,Stake,Result
2026-01-05,DK,+100,100.00,Won
2026-01-06,DK,+100,100.00,Lost
"""
    import_csv(db, write(tmp_path, text))
    assert from_ledger(db).overall.profit == pytest.approx(0.0)


def test_a_voided_bet_returns_the_stake_not_the_payout(db, tmp_path):
    text = """Date,Book,Odds,Stake,Result,Payout
2026-01-05,DK,-110,100.00,Void,100.00
"""
    import_csv(db, write(tmp_path, text))
    rep = from_ledger(db)
    assert rep.overall.void == 1
    assert rep.overall.turnover == 0.0


# ------------------------------------------------------------- the refusals


def test_a_row_without_a_stake_is_skipped_with_its_reason(db, tmp_path):
    text = """Date,Book,Odds,Stake,Result
2026-01-05,DK,-110,,Won
2026-01-06,DK,-110,100,Won
"""
    report = import_csv(db, write(tmp_path, text))
    assert report.imported == 1
    assert report.reasons() == {"no usable stake": 1}


def test_a_row_with_unreadable_odds_is_skipped(db, tmp_path):
    text = """Date,Book,Odds,Stake,Result
2026-01-05,DK,evens,100,Won
"""
    assert import_csv(db, write(tmp_path, text)).reasons() == {"no usable odds": 1}


def test_a_row_with_an_unreadable_date_is_skipped_not_defaulted(db, tmp_path):
    """A bet imported with a guessed date is worse than one not imported."""
    text = """Date,Book,Odds,Stake,Result
someday,DK,-110,100,Won
"""
    assert import_csv(db, write(tmp_path, text)).reasons() == {"no usable date": 1}


def test_an_unreadable_result_is_skipped_rather_than_guessed(db, tmp_path):
    text = """Date,Book,Odds,Stake,Result
2026-01-05,DK,-110,100,Partially Settled
"""
    report = import_csv(db, write(tmp_path, text))
    assert report.imported == 0
    assert "unreadable result" in report.skipped[0].reason


def test_a_file_missing_a_required_column_names_it(db, tmp_path):
    text = "Book,Result\nDK,Won\n"
    with pytest.raises(ImportError_, match="missing required column"):
        import_csv(db, write(tmp_path, text))


def test_a_missing_file_says_so(db, tmp_path):
    with pytest.raises(ImportError_, match="no file at"):
        import_csv(db, tmp_path / "nope.csv")


def test_an_empty_file_says_so(db, tmp_path):
    with pytest.raises(ImportError_, match="is empty"):
        import_csv(db, write(tmp_path, "   "))


def test_a_header_only_file_imports_nothing_without_erroring(db, tmp_path):
    text = "Date,Book,Odds,Stake,Result\n"
    report = import_csv(db, write(tmp_path, text))
    assert report.rows == 0
    assert report.describe() == "nothing to import"


# ------------------------------------- imported bets track but do not teach


def test_an_imported_bet_carries_no_devig_spread(db, tmp_path):
    """Nobody recorded what `power` said about a market weeks ago at a book,
    and inventing one would poison the calibration it fed."""
    import_csv(db, write(tmp_path, DK_EXPORT))
    bet_id = db.conn.execute("SELECT id FROM bets LIMIT 1").fetchone()["id"]
    assert db.devig_at_bet(bet_id) == {}


def test_imported_bets_are_invisible_to_calibration(db, tmp_path):
    import_csv(db, write(tmp_path, DK_EXPORT))
    for row in db.conn.execute("SELECT id FROM bets"):
        db.settle(row["id"], closing_fair_prob=0.5)
    assert len(db.graded_bets()) == 3
    assert db.method_candidates() == {}
    assert db.stats()["trainable"] == 0


def test_engine_bets_stay_trainable_alongside_imports(db, tmp_path):
    from overlay_engine.ledger import AtBet

    import_csv(db, write(tmp_path, DK_EXPORT))
    bet_id = db.record_bet(
        event_id="own", sport="nfl", market_type="h2h", outcome="home",
        book="dk", decimal_odds=2.0, stake=100.0,
        at_bet=AtBet(fair_prob=0.5, fair_low=0.47, fair_high=0.53,
                     devig={"power": 0.50, "shin": 0.51}),
    )
    # Every bet graded, imports included — which is the case that matters.
    # With only the engine bet settled, `graded_bets` never sees an import and
    # the filter is irrelevant either way; the mixture is what the filter is
    # for, and what a real ledger looks like.
    for row in db.conn.execute("SELECT id FROM bets"):
        db.settle(row["id"], closing_fair_prob=0.5)

    assert len(db.graded_bets()) == 4
    assert db.stats()["trainable"] == 1
    assert set(db.method_candidates()) == {"power", "shin"}


def test_import_bet_still_validates_the_basics(db):
    with pytest.raises(LedgerError, match="decimal odds"):
        db.import_bet(event_id="e", sport="nfl", market_type="h2h",
                      outcome="home", book="dk", decimal_odds=1.0,
                      stake=100.0, placed_at=1000.0)
    with pytest.raises(LedgerError, match="stake"):
        db.import_bet(event_id="e", sport="nfl", market_type="h2h",
                      outcome="home", book="dk", decimal_odds=2.0,
                      stake=0.0, placed_at=1000.0)
    with pytest.raises(LedgerError, match="unknown result"):
        db.import_bet(event_id="e", sport="nfl", market_type="h2h",
                      outcome="home", book="dk", decimal_odds=2.0,
                      stake=100.0, placed_at=1000.0, result="maybe")


def test_a_v6_database_migrates_to_v7(tmp_path):
    from overlay_engine.ledger import SCHEMA_VERSION

    path = tmp_path / "v6.db"
    with Ledger(path) as db:
        db.import_bet(event_id="e", sport="nfl", market_type="h2h",
                      outcome="home", book="dk", decimal_odds=2.0,
                      stake=100.0, placed_at=1000.0, result="won", profit=100.0)
        db.conn.execute("DROP INDEX IF EXISTS idx_bets_ref")
        db.conn.execute("ALTER TABLE bets DROP COLUMN external_ref")
        db.conn.execute("ALTER TABLE bets DROP COLUMN source")
        db.conn.execute("UPDATE meta SET value = '6' WHERE key = 'schema_version'")
        db.conn.commit()

    with Ledger(path) as db:
        assert db._has_column("bets", "source")
        assert db._has_column("bets", "external_ref")
        assert db.stats()["bets"] == 1
        row = db.conn.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        assert int(row["value"]) == SCHEMA_VERSION
