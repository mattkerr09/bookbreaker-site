"""Twelve positions and four bets are the same book described two ways, and
only one of the two descriptions makes people size correctly."""

import math
import random

import pytest

from overlay_engine.correlation import CorrelationEstimate
from overlay_engine.kelly import DEFAULT_CORRELATION, MAX_SINGLE, simultaneous_scale
from overlay_engine.portfolio import (
    UTILISATION_FLAG,
    PortfolioError,
    PortfolioView,
    build,
    effective_bets,
)

DAY = 86_400.0


def _ledger(tmp_path, open_bets=0, settled_groups=0, rho=0.45, stake=100.0):
    from overlay_engine.ledger import Ledger

    db = Ledger(str(tmp_path / "p.db"))
    rng = random.Random(3)
    for g in range(settled_groups):
        shared = rng.gauss(0.0, 1.0)
        for i in range(4):
            r = math.sqrt(rho) * shared + math.sqrt(1 - rho) * rng.gauss(0.0, 1.0)
            db.import_bet(
                event_id=f"past{g}", sport="nfl", market_type="h2h",
                outcome="home", book="dk", decimal_odds=2.0, stake=100.0,
                placed_at=g * DAY, result="won" if r > 0 else "lost",
                profit=r * 100.0, external_ref=f"s{g}-{i}")
    for i in range(open_bets):
        db.import_bet(
            event_id=f"live{i}", sport="nfl", market_type="h2h",
            outcome="home", book="dk", decimal_odds=2.0, stake=stake,
            placed_at=1_800_000_000.0, external_ref=f"o{i}")
    return db


# --------------------------------------------------------- the arithmetic

def test_independent_bets_are_worth_their_own_count():
    assert effective_bets(12, 0.0) == pytest.approx(12.0)


def test_identical_bets_collapse_to_one():
    assert effective_bets(12, 1.0) == pytest.approx(1.0)


def test_effective_bets_is_exactly_n_times_scale_squared():
    """The two must not drift: they are the same algebra written twice."""
    for n in (2, 5, 12, 40):
        for rho in (0.0, 0.15, 0.45, 0.9):
            assert effective_bets(n, rho) == pytest.approx(
                n * simultaneous_scale(n, rho) ** 2)


def test_twelve_positions_at_the_measured_correlation_are_two_bets():
    """The headline. 0.45 is what a real ledger measured, not a round number
    chosen to make the point."""
    assert effective_bets(12, 0.45) == pytest.approx(2.02, abs=0.05)


def test_effective_bets_falls_as_correlation_rises():
    values = [effective_bets(12, r) for r in (0.0, 0.2, 0.5, 0.9)]
    assert values == sorted(values, reverse=True)


def test_no_positions_is_zero_effective_bets_not_a_division_by_zero():
    assert effective_bets(0, 0.4) == 0.0


# ------------------------------------------------------------- the view

def test_a_view_reports_utilisation_against_the_bankroll_given(tmp_path):
    with _ledger(tmp_path, open_bets=4, stake=250.0) as db:
        view = build(db, bankroll=10_000.0)
    assert view.at_risk == pytest.approx(1000.0)
    assert view.utilisation == pytest.approx(0.10)


def test_a_zero_bankroll_is_refused_rather_than_divided_by(tmp_path):
    """Every ratio would come back zero, and zero reads as safety."""
    with _ledger(tmp_path, open_bets=2) as db:
        with pytest.raises(PortfolioError, match="bankroll must be positive"):
            build(db, bankroll=0.0)


def test_a_negative_bankroll_is_refused(tmp_path):
    with _ledger(tmp_path, open_bets=2) as db:
        with pytest.raises(PortfolioError, match="bankroll must be positive"):
            build(db, bankroll=-500.0)


def test_the_next_stake_cap_shrinks_with_what_is_already_open(tmp_path):
    """MAX_SINGLE is the right cap for someone holding nothing and the wrong
    one for someone holding eleven bets on the same game."""
    with _ledger(tmp_path, open_bets=0) as db:
        empty = build(db, bankroll=10_000.0)
    with _ledger(tmp_path, open_bets=12) as db:
        loaded = build(db, bankroll=10_000.0)
    assert empty.max_next_stake == pytest.approx(10_000.0 * MAX_SINGLE)
    assert loaded.max_next_stake < empty.max_next_stake


def test_the_cap_is_the_single_bet_cap_times_the_scale(tmp_path):
    with _ledger(tmp_path, open_bets=6) as db:
        view = build(db, bankroll=8_000.0)
    assert view.max_next_stake == pytest.approx(
        8_000.0 * MAX_SINGLE * view.scale)


def test_a_measured_correlation_reaches_the_view(tmp_path):
    with _ledger(tmp_path, open_bets=4, settled_groups=60) as db:
        view = build(db, bankroll=10_000.0)
    assert view.correlation.measured
    assert view.correlation.rho == pytest.approx(0.45, abs=0.15)


def test_an_empty_record_falls_back_to_the_prior_and_flags_it(tmp_path):
    with _ledger(tmp_path, open_bets=4) as db:
        view = build(db, bankroll=10_000.0)
    assert not view.correlation.measured
    assert view.correlation.rho == DEFAULT_CORRELATION
    assert any("stated prior" in f for f in view.flags)


# --------------------------------------------------------------- flags

def test_high_utilisation_is_flagged(tmp_path):
    with _ledger(tmp_path, open_bets=4, stake=1000.0) as db:
        view = build(db, bankroll=10_000.0)
    assert view.utilisation > UTILISATION_FLAG
    assert any("on the table at once" in f for f in view.flags)


def test_ordinary_utilisation_is_not_flagged(tmp_path):
    with _ledger(tmp_path, open_bets=2, stake=100.0) as db:
        view = build(db, bankroll=10_000.0)
    assert not any("on the table at once" in f for f in view.flags)


def test_a_book_behaving_like_half_its_position_count_is_flagged(tmp_path):
    with _ledger(tmp_path, open_bets=12, settled_groups=60) as db:
        view = build(db, bankroll=100_000.0)
    assert view.effective < view.live / 2
    assert any("less diversified" in f for f in view.flags)


def test_a_single_position_is_never_flagged_for_diversification(tmp_path):
    """One bet is not an undiversified portfolio, it is one bet."""
    with _ledger(tmp_path, open_bets=1, settled_groups=60) as db:
        view = build(db, bankroll=100_000.0)
    assert not any("less diversified" in f for f in view.flags)
    assert view.scale == 1.0


def test_concentration_on_one_event_is_flagged(tmp_path):
    from overlay_engine.ledger import Ledger

    with Ledger(str(tmp_path / "c.db")) as db:
        db.import_bet(event_id="big", sport="nfl", market_type="h2h",
                      outcome="home", book="dk", decimal_odds=2.0,
                      stake=900.0, placed_at=1_800_000_000.0, external_ref="a")
        db.import_bet(event_id="small", sport="nfl", market_type="h2h",
                      outcome="home", book="fd", decimal_odds=2.0,
                      stake=100.0, placed_at=1_800_000_000.0, external_ref="b")
        view = build(db, bankroll=100_000.0)
    assert any("one event" in f for f in view.flags)


# ------------------------------------------------------------ the floor

def test_a_book_bet_on_both_sides_reports_its_floor_as_a_share_of_bankroll(tmp_path):
    from overlay_engine.ledger import Ledger

    with Ledger(str(tmp_path / "w.db")) as db:
        for side, ref in (("home", "a"), ("away", "b")):
            db.import_bet(event_id="g1", sport="nfl", market_type="h2h",
                          outcome=side, book="dk", decimal_odds=1.8,
                          stake=250.0, placed_at=1_800_000_000.0,
                          external_ref=ref)
        view = build(db, bankroll=10_000.0)
    assert view.worst_case < 0
    assert view.worst_case_share == pytest.approx(abs(view.worst_case) / 10_000.0)


def test_one_sided_positions_report_an_optimistic_floor_and_say_so(tmp_path):
    """With no recorded quotes the outcome set comes from your own bets, so
    every result the model can see is one you backed — and the "worst case"
    comes out positive. Flagged rather than trusted."""
    with _ledger(tmp_path, open_bets=4, stake=250.0) as db:
        view = build(db, bankroll=10_000.0)
    assert view.worst_case > 0
    assert view.worst_case_share == 0.0
    assert any("optimistic" in f for f in view.flags)


def test_a_positive_worst_case_is_not_reported_as_a_loss_share(tmp_path):
    """A locked book has no floor to express as a share of bankroll."""
    view = PortfolioView(
        bankroll=1000.0,
        exposure=type("E", (), {"worst_case": 50.0, "positions": 0,
                                "at_risk": 0.0, "markets": [],
                                "concentration": ("", 0.0),
                                "concentrated": False,
                                "inferred_markets": []})(),
        correlation=CorrelationEstimate(rho=0.15, provenance="prior"),
    )
    assert view.worst_case_share == 0.0


def test_describe_states_that_correlation_does_not_move_the_floor(tmp_path):
    """The distinction the whole module turns on, said in the output."""
    with _ledger(tmp_path, open_bets=4) as db:
        shown = build(db, bankroll=10_000.0).describe()
    assert "does not" in shown and "move this floor" in shown
    assert "how often you land" in shown


def test_describe_never_presents_a_prior_correlation_as_measured(tmp_path):
    with _ledger(tmp_path, open_bets=4) as db:
        assert "PRIOR" in build(db, bankroll=10_000.0).describe()


def test_describe_shows_the_effective_count_beside_the_position_count(tmp_path):
    with _ledger(tmp_path, open_bets=12, settled_groups=60) as db:
        shown = build(db, bankroll=100_000.0).describe()
    assert "effective bets" in shown
    assert "independent ones" in shown


def test_an_empty_book_still_describes_without_dividing_by_zero(tmp_path):
    with _ledger(tmp_path, open_bets=0) as db:
        view = build(db, bankroll=5_000.0)
    assert view.live == 0
    assert view.utilisation == 0.0
    assert "bankroll" in view.describe()
