"""The harness rewrites engine source, so its own safety matters more than most.

Two loop iterations fired at once and left three guards in `ledger.py` sitting
as `if False:` — a band check, a migration step, and the double-spend check on
promotions. Nothing failed loudly. The breaks reported themselves stale, three
different ones each run, because the restore captures `original` per case: a run
that starts while another has a file broken records the sabotage as the original
and faithfully puts it back.

The tree was one commit away from shipping an engine with its checks off.
"""

import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
HARNESS = ROOT / "scripts" / "break_test.py"

sys.path.insert(0, str(ROOT / "scripts"))
import break_test  # noqa: E402


@pytest.fixture
def lock(tmp_path, monkeypatch):
    path = tmp_path / ".break_test.lock"
    monkeypatch.setattr(break_test, "LOCK_PATH", path)
    yield path
    path.unlink(missing_ok=True)


def test_a_live_holder_is_refused(lock):
    """Refused, not queued. Waiting would serialise the runs and hide the fact
    that the loop is firing twice, which is the thing worth knowing."""
    lock.write_text(f"{os.getpid()} pretend-holder")
    with pytest.raises(break_test.ConcurrentRun, match="holds this tree"):
        with break_test.exclusive():
            pass


def test_the_refusal_names_the_holding_process(lock):
    lock.write_text(f"{os.getpid()} pretend-holder")
    with pytest.raises(break_test.ConcurrentRun, match=str(os.getpid())):
        with break_test.exclusive():
            pass


def test_a_dead_holder_is_treated_as_stale_and_taken_over(lock):
    """A crashed run must not wedge the harness forever."""
    lock.write_text("999999 dead-holder")
    with break_test.exclusive():
        assert lock.exists()
        assert str(os.getpid()) in lock.read_text()


def test_the_lock_is_released_even_when_the_body_raises(lock):
    with pytest.raises(ValueError):
        with break_test.exclusive():
            raise ValueError("boom")
    assert not lock.exists()


def test_the_lock_is_released_on_a_clean_exit(lock):
    with break_test.exclusive():
        pass
    assert not lock.exists()


def test_a_garbled_lock_file_does_not_wedge_the_harness(lock):
    """An empty or truncated lock has no pid to check; it must not be treated
    as a live holder forever."""
    lock.write_text("")
    with break_test.exclusive():
        assert str(os.getpid()) in lock.read_text()


def test_alive_reports_this_process(lock):
    assert break_test._alive(os.getpid())


def test_alive_reports_a_dead_pid(lock):
    assert not break_test._alive(999_999)


# ------------------------------------------------------- leftover sabotage

def test_a_present_replacement_halts_the_run_and_names_the_line():
    """A missing anchor alone is a stale case. A missing anchor whose
    replacement is present is either leftover sabotage or a refactor that made
    the replacement legitimate — the harness cannot tell those apart by text,
    so it halts, says both, and prints the line to read in context. Continuing
    past a disabled guard is the one outcome worth preventing."""
    target = ROOT / "backend" / "overlay_engine" / "ledger.py"
    original = target.read_text()
    case = next(c for c in break_test.CASES if c[1] == target and c[2] in original)
    target.write_text(original.replace(case[2], case[3], 1))
    try:
        run = subprocess.run(
            [sys.executable, str(HARNESS)],
            capture_output=True, text=True, cwd=ROOT, timeout=600,
        )
    finally:
        target.write_text(original)
        assert target.read_text() == original

    assert run.returncode == 2
    assert "ANCHOR GONE, REPLACEMENT PRESENT" in run.stderr
    assert "only one is an emergency" in run.stderr
    assert case[2].strip() in run.stderr      # tells you what to put back
