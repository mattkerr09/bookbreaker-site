"""Parlays: the compounding margin, and what the maths will not claim."""

import pytest

from overlay_engine.odds import OddsError, american_to_decimal
from overlay_engine.parlay import (
    break_even_legs,
    correlation_note,
    parlay_decimal,
    parlay_fair,
    value,
)

STD = american_to_decimal(-110)


def test_a_parlay_pays_the_product_of_its_legs():
    assert parlay_decimal([2.0, 2.0]) == pytest.approx(4.0)
    assert parlay_decimal([STD, STD]) == pytest.approx(STD * STD)


def test_fair_price_is_one_over_the_joint_probability():
    assert parlay_fair([0.5, 0.5]) == pytest.approx(4.0)
    assert parlay_fair([0.5, 0.5, 0.5, 0.5]) == pytest.approx(16.0)


def test_one_leg_is_not_a_parlay():
    with pytest.raises(OddsError, match="at least two"):
        parlay_decimal([2.0])
    with pytest.raises(OddsError, match="at least two"):
        parlay_fair([0.5])


def test_impossible_inputs_are_refused():
    with pytest.raises(OddsError):
        parlay_decimal([2.0, 1.0])
    with pytest.raises(OddsError):
        parlay_fair([0.5, 1.0])
    with pytest.raises(OddsError):
        parlay_fair([0.5, 0.0])


# ------------------------------------------------------- the compounding


def test_four_standard_legs_pay_far_less_than_fair():
    """The whole subject: pays about 12.3 to 1 where fair is 15 to 1."""
    v = value([STD] * 4)
    assert v.offered - 1 == pytest.approx(12.28, abs=0.02)
    assert v.fair - 1 == pytest.approx(15.0, abs=0.01)


def test_the_hold_compounds_with_legs():
    holds = [value([STD] * n).hold for n in (2, 3, 4, 6)]
    assert holds == sorted(holds)
    assert holds[0] == pytest.approx(0.089, abs=0.005)
    assert holds[2] == pytest.approx(0.170, abs=0.005)


def test_a_four_leg_parlay_costs_several_times_a_single():
    v = value([STD] * 4)
    assert v.leg_hold == pytest.approx(0.0455, abs=0.001)
    assert v.multiple > 3.5


def test_expected_value_is_negative_on_fairly_priced_legs():
    """Nothing about a parlay creates value; it only multiplies the margin."""
    assert value([STD] * 3).ev < 0


def test_genuinely_plus_ev_legs_can_survive_being_parlayed():
    """Not a recommendation — a check that the maths is not rigged to say no.
    Two legs priced at 2.10 whose fair probability is 0.52 each are +EV, and
    the parlay of them still is."""
    v = value([2.10, 2.10], probs=[0.52, 0.52])
    assert v.ev > 0


def test_the_description_names_both_numbers():
    text = value([STD] * 4).describe()
    assert "to 1" in text
    assert "hold" in text
    assert "single" in text


# ------------------------------------------------------------ the limits


def test_how_many_legs_before_it_is_a_lottery_ticket():
    assert break_even_legs(0.0455, 0.25) == 7


def test_break_even_legs_refuses_impossible_inputs():
    for bad in (0.0, 1.0, -0.1):
        with pytest.raises(OddsError):
            break_even_legs(bad, 0.25)
        with pytest.raises(OddsError):
            break_even_legs(0.0455, bad)


def test_same_game_legs_are_flagged_as_an_upper_bound():
    """A team covering the spread makes the over more likely, not less. The
    independent figure is a ceiling, and claiming otherwise would be inventing
    an edge."""
    note = correlation_note(same_game=True)
    assert "upper bound" in note
    assert "not independent" in note


def test_separate_games_are_treated_as_independent():
    assert "independent" in correlation_note(same_game=False)
    assert "upper bound" not in correlation_note(same_game=False)
