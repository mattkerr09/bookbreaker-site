"""Fair value and EV: anchoring, hold-out, and the interval."""

import pytest

from overlay_engine.ev import breakeven_prob, ev_per_unit, evaluate, find_edges
from overlay_engine.fair import fair_value
from overlay_engine.models import Book, BookTier, Market, Outcome, Quote

PIN = Book(key="pinnacle", name="Pinnacle", tier=BookTier.SHARP, limits_winners=False)
DK = Book(key="dk", name="DraftKings", tier=BookTier.RETAIL)
FD = Book(key="fd", name="FanDuel", tier=BookTier.RETAIL)
EX = Book(key="betfair", name="Betfair", tier=BookTier.EXCHANGE, commission=0.02)
MYSTERY = Book(key="mystery", name="Mystery", tier=BookTier.UNKNOWN)
BOOKS = {b.key: b for b in (PIN, DK, FD, EX, MYSTERY)}


def _market(prices, market_type="h2h", seen_at=1000.0, sport="nfl"):
    quotes = [
        Quote(book=b, outcome=Outcome(name=n), decimal=d, seen_at=seen_at)
        for b, n, d in prices
    ]
    return Market(event_id="e1", sport=sport, market_type=market_type, quotes=quotes)


SHARP_ONLY = _market([("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95)])


def test_fair_value_from_a_sharp_two_way():
    fv = fair_value(SHARP_ONLY, BOOKS)
    assert fv["home"].prob == pytest.approx(0.5, abs=1e-9)
    assert fv["home"].anchored


def test_fair_value_carries_an_interval():
    market = _market([("pinnacle", "home", 1.75), ("pinnacle", "away", 2.20)])
    fv = fair_value(market, BOOKS)["home"]
    assert fv.low < fv.prob < fv.high
    assert fv.uncertainty > 0


def test_incomplete_books_cannot_anchor():
    """A fair probability built from one book's over and another's under is
    the arbitrage laundered into a probability."""
    market = _market([("pinnacle", "home", 1.95), ("dk", "away", 2.10)])
    assert fair_value(market, BOOKS) == {}


def test_unknown_tier_books_are_excluded_entirely():
    market = _market([("mystery", "home", 1.95), ("mystery", "away", 1.95)])
    assert fair_value(market, BOOKS) == {}


def test_retail_only_market_is_computed_but_flagged():
    """Better than nothing, and never silently treated as anchored."""
    market = _market(
        [("dk", "home", 1.91), ("dk", "away", 1.91),
         ("fd", "home", 1.93), ("fd", "away", 1.89)]
    )
    fv = fair_value(market, BOOKS)["home"]
    assert 0.0 < fv.prob < 1.0
    assert not fv.anchored


def test_sharp_book_dominates_the_blend():
    """One sharp and one soft book disagreeing must land near the sharp."""
    market = _market(
        [("pinnacle", "home", 2.00), ("pinnacle", "away", 1.90),
         ("dk", "home", 2.60), ("dk", "away", 1.50)]
    )
    fv = fair_value(market, BOOKS)["home"]
    sharp_only = fair_value(
        _market([("pinnacle", "home", 2.00), ("pinnacle", "away", 1.90)]), BOOKS
    )["home"]
    assert abs(fv.prob - sharp_only.prob) < 0.02


def test_book_disagreement_widens_the_band():
    agree = _market(
        [("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95),
         ("betfair", "home", 1.95), ("betfair", "away", 1.95)]
    )
    disagree = _market(
        [("pinnacle", "home", 1.70), ("pinnacle", "away", 2.30),
         ("betfair", "home", 2.30), ("betfair", "away", 1.70)]
    )
    assert (
        fair_value(disagree, BOOKS)["home"].uncertainty
        > fair_value(agree, BOOKS)["home"].uncertainty
    )


def test_exchange_commission_moves_the_fair_value():
    net = Book(key="betfair", name="Betfair", tier=BookTier.EXCHANGE, commission=0.0)
    market = _market([("betfair", "home", 2.50), ("betfair", "away", 1.60)])
    with_comm = fair_value(market, BOOKS)["home"].prob
    without = fair_value(market, {**BOOKS, "betfair": net})["home"].prob
    assert with_comm != pytest.approx(without)


def test_ev_arithmetic():
    assert ev_per_unit(2.0, 0.5) == pytest.approx(0.0)
    assert ev_per_unit(2.0, 0.55) == pytest.approx(0.10)
    assert ev_per_unit(1.91, 0.50) == pytest.approx(-0.045)


def test_breakeven_is_the_rate_you_must_hit():
    assert breakeven_prob(2.0) == pytest.approx(0.5)
    assert breakeven_prob(1.91) == pytest.approx(0.5235602, abs=1e-6)


def test_evaluate_keeps_the_band():
    fv = fair_value(_market([("pinnacle", "home", 1.75), ("pinnacle", "away", 2.20)]), BOOKS)["home"]
    res = evaluate(2.10, fv)
    assert res.ev_low <= res.ev <= res.ev_high


def test_a_book_is_never_priced_against_a_fair_value_it_helped_set():
    """Self-reference shrinks exactly the edge being detected, hardest on the
    markets where the edge is largest."""
    market = _market(
        [("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95),
         ("dk", "home", 2.20), ("dk", "away", 1.70)]
    )
    edges = find_edges(market, BOOKS, now=1000.0)
    dk_home = [e for e in edges if e.book == "dk" and e.outcome == "home"]
    assert dk_home, "the soft overlay should be found"
    assert dk_home[0].fair_prob == pytest.approx(0.5, abs=1e-6)


def test_find_edges_ignores_negative_ev_offers():
    market = _market(
        [("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95),
         ("dk", "home", 1.70), ("dk", "away", 1.70)]
    )
    assert find_edges(market, BOOKS, now=1000.0) == []


def test_robust_filter_rejects_method_dependent_edges():
    """An edge that exists under one devig and vanishes under another is a
    modelling artefact."""
    market = _market(
        [("pinnacle", "home", 1.60), ("pinnacle", "away", 2.45),
         ("dk", "home", 1.66), ("dk", "away", 2.30)]
    )
    strict = find_edges(market, BOOKS, now=1000.0, require_robust=True)
    loose = find_edges(market, BOOKS, now=1000.0, require_robust=False)
    assert len(strict) <= len(loose)
    assert all(e.robust for e in strict)


def test_unanchored_edges_are_excluded_by_default():
    market = _market(
        [("dk", "home", 1.91), ("dk", "away", 1.91),
         ("fd", "home", 2.30), ("fd", "away", 1.70)]
    )
    assert find_edges(market, BOOKS, now=1000.0) == []
    loose = find_edges(market, BOOKS, now=1000.0, require_anchor=False)
    assert any(e.note == "no sharp anchor" for e in loose)


def test_fill_probability_reorders_the_screen():
    """The reorder is the product: a big stale edge must rank below a smaller
    live one."""

    class Model:
        def p_fill(self, book, market, age):
            return 0.1 if book == "dk" else 0.95

    market = _market(
        [("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95),
         ("dk", "home", 2.10), ("dk", "away", 1.80),
         ("fd", "home", 2.05), ("fd", "away", 1.85)]
    )
    raw = find_edges(market, BOOKS, now=1000.0)
    ranked = find_edges(market, BOOKS, now=1000.0, fill_model=Model())
    assert raw[0].book == "dk"
    assert ranked[0].book == "fd"
    assert ranked[0].ev < raw[0].ev
    assert ranked[0].realised_ev > ranked[1].realised_ev


def test_realised_ev_is_the_discounted_number():
    market = _market(
        [("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95),
         ("dk", "home", 2.20), ("dk", "away", 1.70)]
    )
    edge = find_edges(market, BOOKS, now=1000.0)[0]
    assert edge.p_fill == 1.0
    assert edge.realised_ev == pytest.approx(edge.ev)


def test_quote_age_reaches_the_edge():
    market = _market(
        [("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95),
         ("dk", "home", 2.20), ("dk", "away", 1.70)],
        seen_at=1000.0,
    )
    edge = find_edges(market, BOOKS, now=1030.0)[0]
    assert edge.quote_age == pytest.approx(30.0)


def test_market_helpers():
    market = _market(
        [("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95), ("dk", "home", 2.20)]
    )
    assert market.outcomes() == ["home", "away"]
    assert market.complete_books() == ["pinnacle"]
    assert market.best("home").book == "dk"
    assert market.best("nonexistent") is None


def test_outcome_key_includes_the_line():
    """Comparing over 220.5 with under 221.5 as opposite sides is the most
    common way to fabricate an arbitrage."""
    assert Outcome(name="over", line=220.5).key == "over@220.5"
    assert Outcome(name="over", line=221.5).key != Outcome(name="over", line=220.5).key
    assert Outcome(name="home").key == "home"


def test_seconds_to_start():
    market = _market([("pinnacle", "home", 1.95), ("pinnacle", "away", 1.95)])
    market.starts_at = 4600.0
    assert market.seconds_to_start(now=1000.0) == pytest.approx(3600.0)
    market.starts_at = None
    assert market.seconds_to_start(now=1000.0) is None
