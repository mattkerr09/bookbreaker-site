"""Promotions and the venue catalogue."""

import pytest

import datetime

from overlay_engine.catalog import (
    AS_OF,
    AS_OF_EPOCH,
    COVERAGE_GAPS,
    NO_LEGAL_BETTING,
    VENUES,
    books_for_state,
    for_state,
    has_anchor,
    stale_days,
    state_summary,
)
from overlay_engine.models import BookTier
from overlay_engine.odds import american_to_decimal
from overlay_engine.promo import (
    OFFER_SHAPES,
    Offer,
    OfferType,
    best_conversion,
    bet_and_get_value,
    bonus_bet_conversion,
    conversion_rate,
    breakeven_hold,
    deposit_match_value,
    fair_conversion_ceiling,
    optimal_safety_net_odds,
    profit_boost_value,
    safety_net_premium,
    safety_net_value,
    sequence,
)

# ---------------------------------------------------------------- catalogue


def test_every_venue_has_a_tier_and_a_key_that_matches():
    for key, venue in VENUES.items():
        assert venue.key == key
        assert isinstance(venue.tier, BookTier)


def test_a_big_state_returns_many_books():
    assert len(for_state("NJ")) >= 8
    assert len(for_state("CO")) >= 8


def test_florida_is_a_one_book_state():
    """The single hardest market to arb in, and the catalogue must say so
    rather than returning a screen that looks broken."""
    retail = [v for v in for_state("FL") if v.tier is BookTier.RETAIL]
    assert [v.key for v in retail] == ["hardrock"]


def test_a_state_with_no_legal_betting_returns_only_nationwide_venues():
    for venue in for_state("TX"):
        assert venue.nationwide, f"{venue.key} is not nationwide but showed in TX"
    assert "TX" in NO_LEGAL_BETTING


def test_unverified_venues_are_excluded_by_default():
    """An unverified 'legal here' is the one error in this table that can cost
    a user more than a missed bet."""
    assert all(v.verified for v in for_state("NJ"))
    with_unverified = for_state("NJ", include_unverified=True)
    assert len(with_unverified) > len(for_state("NJ"))
    assert any(v.key == "pinnacle" for v in with_unverified)


def test_unknown_jurisdiction_is_not_the_same_as_unavailable():
    """Pinnacle has no state list because we do not know it, not because we
    know it is empty. Those are different answers to give a user."""
    assert VENUES["pinnacle"].jurisdiction_unknown
    assert not VENUES["dk"].jurisdiction_unknown
    assert not VENUES["kalshi"].jurisdiction_unknown


def test_case_is_not_significant():
    assert [v.key for v in for_state("nj")] == [v.key for v in for_state("NJ")]


def test_states_with_a_sharp_book_are_identified():
    assert has_anchor("CO")  # Circa
    assert has_anchor("NV")  # Circa
    assert has_anchor("NJ")  # Sporttrade


def test_kalshi_anchors_every_state():
    """A nationwide exchange that never limits is why even a one-book state
    has something to price against."""
    assert has_anchor("FL")
    assert "kalshi" in books_for_state("FL")
    assert "kalshi" in books_for_state("TX")


def test_books_for_state_returns_engine_ready_books():
    books = books_for_state("NJ")
    assert books["dk"].tier is BookTier.RETAIL
    assert books["dk"].limits_winners
    assert not books["sporttrade"].limits_winners
    assert books["sporttrade"].commission > 0


def test_never_limit_venues_are_surfaced():
    summary = state_summary("CO")
    assert "circa" in summary["never_limit"]
    assert "kalshi" in summary["never_limit"]
    assert "dk" not in summary["never_limit"]


def test_the_lottery_states_are_now_catalogued():
    """NH, OR, DE, RI and MT each license exactly one online book. They sat in
    COVERAGE_GAPS as 'not looked at' until 2026-08-17."""
    for state, book in (("NH", "DraftKings"), ("OR", "DraftKings"),
                        ("DE", "BetRivers"), ("RI", "Sportsbook Rhode Island"),
                        ("MT", "Sports Bet Montana")):
        retail = [v.name for v in for_state(state) if v.tier is BookTier.RETAIL]
        assert retail == [book], f"{state}: {retail}"
        assert state_summary(state)["single_operator"], state


def test_a_one_row_market_says_why_it_is_one_row():
    """Otherwise a single-operator state reads as a thin table rather than as
    a fact about the state."""
    assert "exclusive lottery" in state_summary("NH")["single_operator"]
    assert "authorised" in state_summary("MT")["single_operator"]
    assert state_summary("NJ")["single_operator"] == ""


def test_retail_only_is_not_the_same_as_uncatalogued():
    """A user in Mississippi is not missing data; they are missing an online
    market. Conflating the two told them to go looking for something that does
    not exist."""
    summary = state_summary("MS")
    assert summary["legal"]
    assert not summary["online"]
    assert summary["retail_only"]
    assert summary["covered"], "MS is not a gap in the table"


def test_an_online_state_is_marked_online():
    assert state_summary("NJ")["online"]
    assert state_summary("NH")["online"]
    assert not state_summary("TX")["online"]


def test_a_retail_only_state_lists_no_online_book():
    """The consistency the label claims. `state_summary` reports the flag, but
    only this notices when the venue table contradicts it — and a state marked
    retail-only while listing an online book is a table lying to itself."""
    from overlay_engine.catalog import RETAIL_ONLY

    for state in RETAIL_ONLY:
        online = [v.name for v in for_state(state) if v.tier is BookTier.RETAIL]
        assert online == [], f"{state} is retail-only but lists {online}"


def test_a_state_with_no_legal_betting_lists_no_licensed_venue():
    for state in NO_LEGAL_BETTING:
        licensed = [v.name for v in for_state(state) if not v.nationwide]
        assert licensed == [], f"{state} lists {licensed}"


def test_there_are_no_coverage_gaps_left():
    """Empty is the goal. If a gap reappears, something was added to the map
    without being catalogued."""
    assert COVERAGE_GAPS == {}


def test_a_covered_state_says_so():
    assert state_summary("NJ")["covered"]
    assert state_summary("NJ")["gap_reason"] == ""


def test_the_table_reports_its_own_age():
    """A jurisdiction table shown without its age asserts 'true now', forever."""
    assert AS_OF == "2026-08-17"
    assert stale_days(now=AS_OF_EPOCH + 86400 * 45) == 45
    assert state_summary("NJ")["as_of"] == AS_OF


def test_the_as_of_epoch_matches_the_as_of_string():
    """These were a year apart on first write, which made a table read today
    announce itself as 365 days stale — the exact failure the age display
    exists to prevent, produced by the age display."""
    stamp = datetime.datetime.fromtimestamp(
        AS_OF_EPOCH, datetime.timezone.utc
    ).strftime("%Y-%m-%d")
    assert stamp == AS_OF


def test_a_fresh_table_reads_as_fresh():
    assert stale_days(now=AS_OF_EPOCH + 3600) == 0


def test_stale_days_never_goes_negative():
    assert stale_days(now=1_000_000.0) == 0


# ------------------------------------------------------------ bonus bets


def test_a_bonus_bet_at_even_money_converts_to_half():
    """The headline number is never the value: a $100 bonus bet is worth about
    $50 if bet at even money, because the stake is not returned."""
    plan = bonus_bet_conversion(free_odds=2.0, hedge_odds=2.0, amount=100.0)
    assert plan.guaranteed == pytest.approx(50.0)
    assert plan.conversion == pytest.approx(0.5)


def test_the_hedge_equalises_both_outcomes():
    plan = bonus_bet_conversion(free_odds=4.0, hedge_odds=1.4, amount=100.0)
    if_free_wins = plan.free_leg_stake * (plan.free_leg_odds - 1) - plan.hedge_stake
    if_hedge_wins = plan.hedge_stake * (plan.hedge_odds - 1)
    assert if_free_wins == pytest.approx(if_hedge_wins)
    assert plan.guaranteed == pytest.approx(if_free_wins)


def test_conversion_does_not_depend_on_the_amount():
    """Only the two prices matter, which is why the rate can be quoted before
    the bonus size is known."""
    a = bonus_bet_conversion(3.0, 1.55, 100.0)
    b = bonus_bet_conversion(3.0, 1.55, 2500.0)
    assert a.conversion == pytest.approx(b.conversion)


def test_longshots_convert_better():
    """The reason the standard advice is 'convert on a longshot'."""
    assert conversion_rate(6.0, 1.22) > conversion_rate(2.0, 2.0)


def test_the_zero_vig_ceiling():
    assert fair_conversion_ceiling(2.0) == pytest.approx(0.50)
    assert fair_conversion_ceiling(4.0) == pytest.approx(0.75)
    assert fair_conversion_ceiling(11.0) == pytest.approx(0.909, abs=1e-3)


def test_a_real_plan_never_beats_its_own_ceiling():
    """With vig in the hedge, the achievable rate must sit under the fair
    ceiling. A plan claiming otherwise is an arithmetic error."""
    for free_odds in (2.0, 3.5, 7.0, 15.0):
        fair_hedge = free_odds / (free_odds - 1.0)
        vigged_hedge = fair_hedge * 0.96
        assert conversion_rate(free_odds, vigged_hedge) < fair_conversion_ceiling(free_odds)


def test_best_conversion_picks_the_highest_guaranteed():
    plan = best_conversion(100.0, [(2.0, 2.05), (6.0, 1.22), (3.0, 1.55)])
    assert plan.free_leg_odds == 6.0


def test_a_hedge_you_cannot_place_is_not_a_plan():
    """Converting a large bonus at long odds needs a large hedge at the other
    book, which may be capped well below it."""
    unconstrained = best_conversion(1000.0, [(2.0, 2.05), (13.0, 1.09)])
    assert unconstrained.free_leg_odds == 13.0
    constrained = best_conversion(1000.0, [(2.0, 2.05), (13.0, 1.09)], max_hedge=600.0)
    assert constrained.free_leg_odds == 2.0


def test_no_hedgeable_candidate_returns_none():
    assert best_conversion(100.0, []) is None
    assert best_conversion(100.0, [(6.0, 1.22)], max_hedge=1.0) is None


@pytest.mark.parametrize("free,hedge", [(1.0, 2.0), (2.0, 1.0), (0.5, 2.0)])
def test_impossible_prices_are_refused(free, hedge):
    with pytest.raises(ValueError):
        bonus_bet_conversion(free, hedge, 100.0)


def test_a_zero_bonus_is_refused():
    with pytest.raises(ValueError):
        bonus_bet_conversion(2.0, 2.0, 0.0)


def test_plan_describes_itself_in_american_odds():
    text = bonus_bet_conversion(3.0, 1.55, 100.0).describe()
    assert "+200" in text
    assert "guaranteed" in text


# ------------------------------------------------------------ offer types


def test_bet_and_get_is_nearly_free():
    """The only cost is the hold on a $5 qualifier — cents."""
    value = bet_and_get_value(qualifying_stake=5.0, qualifying_hold=0.045,
                              bonus_amount=200.0, conversion=0.75)
    assert value.cost == pytest.approx(0.225)
    assert value.guaranteed == pytest.approx(149.775)
    assert value.headline_ratio > 0.7


def test_the_headline_ratio_is_the_honest_number():
    """'$1,000 BONUS' becomes what it is actually worth."""
    value = bet_and_get_value(5.0, 0.045, 1000.0, conversion=0.72)
    assert value.headline == 1000.0
    assert 0.70 < value.headline_ratio < 0.72


def test_a_safety_net_is_never_guaranteed():
    """There is no hedge that locks it — you either win, or you hold bonus
    bets that still have to be converted."""
    value = safety_net_value(stake=1000.0, decimal=2.0, win_prob=0.5)
    assert value.guaranteed == 0.0
    assert value.expected > 0


def test_a_safety_net_pays_more_on_a_longshot():
    """The opposite of the instinct, and the opposite of a bet-and-get: losing
    is the event that pays."""
    favourite = safety_net_value(1000.0, 1.25, win_prob=0.80)
    longshot = safety_net_value(1000.0, 5.00, win_prob=0.20)
    assert longshot.expected > favourite.expected


def test_the_safety_net_optimum_accounts_for_real_vig():
    """Theory says 'longest price available'. Real longshots carry the heaviest
    margin, and past a point the extra vig costs more than the extra refund
    frequency earns."""
    candidates = [(1.5, 0.667), (3.0, 0.333), (8.0, 0.115), (21.0, 0.036)]
    best = optimal_safety_net_odds(candidates, stake=1000.0)
    assert best is not None
    assert best[0] < 21.0


def test_a_refund_cap_limits_the_value():
    capped = safety_net_value(1000.0, 3.0, 0.33, refund_cap=250.0)
    uncapped = safety_net_value(1000.0, 3.0, 0.33)
    assert capped.expected < uncapped.expected


def test_safety_net_rejects_an_impossible_probability():
    with pytest.raises(ValueError):
        safety_net_value(100.0, 2.0, win_prob=1.5)


def test_a_deposit_match_can_be_worth_less_than_nothing():
    """Advertised in the same typeface as the good offers. A 10x match goes
    negative as soon as the eligible markets hold more than 5%, which many
    playthrough-eligible markets do."""
    value = deposit_match_value(1000.0, 1000.0, rollover=10.0, hold_per_bet=0.07)
    assert value.expected < 0
    assert "Negative" in value.note


def test_a_10x_match_is_nearly_worthless_even_at_the_best_hold():
    """$20,000 of turnover to net about $100 — a 10% headline ratio."""
    value = deposit_match_value(1000.0, 1000.0, rollover=10.0, hold_per_bet=0.045)
    assert value.expected == pytest.approx(100.0)
    assert value.headline_ratio == 0.0, "a deposit match is never guaranteed"


def test_the_breakeven_hold_is_the_number_to_decide_on():
    """A matched bonus at 10x breaks even at exactly 5% hold — barely above a
    standard -110/-110 market."""
    assert breakeven_hold(1000.0, 1000.0, 10.0) == pytest.approx(0.05)
    assert breakeven_hold(1000.0, 1000.0, 5.0) == pytest.approx(0.10)
    assert breakeven_hold(1000.0, 500.0, 5.0, rollover_includes_deposit=False) == pytest.approx(0.20)


def test_no_rollover_means_no_hold_can_break_it():
    assert breakeven_hold(500.0, 500.0, 0.0) == float("inf")


def test_a_light_rollover_is_worth_taking():
    value = deposit_match_value(deposit=500.0, bonus=250.0, rollover=1.0)
    assert value.expected > 0
    assert "Worth taking" in value.note


def test_rollover_on_bonus_only_is_much_cheaper():
    both = deposit_match_value(1000.0, 500.0, 5.0, rollover_includes_deposit=True)
    bonus_only = deposit_match_value(1000.0, 500.0, 5.0,
                                     rollover_includes_deposit=False)
    assert bonus_only.expected > both.expected
    assert bonus_only.cost < both.cost


def test_playthrough_cost_scales_with_the_hold_you_can_actually_get():
    cheap = deposit_match_value(1000.0, 1000.0, 5.0, hold_per_bet=0.02)
    dear = deposit_match_value(1000.0, 1000.0, 5.0, hold_per_bet=0.09)
    assert cheap.expected > dear.expected


def test_a_zero_rollover_match_costs_nothing():
    value = deposit_match_value(500.0, 500.0, 0.0)
    assert value.cost == 0.0
    assert value.expected == pytest.approx(500.0)


def test_negative_rollover_is_refused():
    with pytest.raises(ValueError):
        deposit_match_value(500.0, 500.0, -1.0)


def test_a_profit_boost_is_worth_more_on_a_longshot():
    """'Save the boost for something safe' gives away most of it."""
    safe = profit_boost_value(100.0, 1.5, win_prob=0.667, boost=0.5)
    long = profit_boost_value(100.0, 6.0, win_prob=0.167, boost=0.5)
    assert long.headline > safe.headline


def test_a_boost_improves_ev_over_the_unboosted_bet():
    boosted = profit_boost_value(100.0, 3.0, win_prob=0.34, boost=0.5)
    assert boosted.expected > 0


def test_a_boost_must_be_a_fraction_not_a_percentage():
    with pytest.raises(ValueError):
        profit_boost_value(100.0, 2.0, 0.5, boost=50.0)


# --------------------------------------------------------------- sequencing


def test_bet_and_get_offers_come_first():
    """Converting a bonus needs a hedge at a second book, so the first account
    is worth little alone — open the cheap ones first."""
    order = sequence(["betparx", "mgm", "dk", "fd"])
    assert [k for k, _ in order[:2]] == ["dk", "fd"]
    assert order[-1][0] == "betparx"


def test_sequencing_ignores_books_with_no_known_offer():
    assert sequence(["dk", "not_a_book"]) == [("dk", OfferType.BET_AND_GET)]


def test_every_offer_shape_maps_to_a_real_venue():
    for key in OFFER_SHAPES:
        assert key in VENUES, f"{key} has an offer shape but is not a venue"


def test_offer_min_odds_gate():
    """Most books require -200 or better on the qualifier, which is what stops
    'just bet the longest price' from working on a bet-and-get."""
    offer = Offer(book="dk", offer_type=OfferType.BET_AND_GET,
                  min_odds=american_to_decimal(-200))
    assert not offer.qualifies(american_to_decimal(-300))
    assert offer.qualifies(american_to_decimal(-150))
    assert offer.qualifies(american_to_decimal(500))


def test_an_offer_without_a_minimum_accepts_anything():
    assert Offer(book="dk", offer_type=OfferType.BET_AND_GET).qualifies(1.01)


def test_the_safety_net_premium_is_the_offer_alone():
    """A $1,000 net at +300 with 80% conversion is worth about $600, which
    reads like an error until you see it is 75% x 1000 x 0.8 and that the bet
    itself contributes nothing at fair odds."""
    assert safety_net_premium(1000.0, win_prob=0.25, conversion=0.8) == pytest.approx(600.0)


def test_the_premium_is_the_whole_value_at_fair_odds():
    """The underlying bet contributes zero when priced fairly, so the offer's
    premium and the total EV must coincide there."""
    total = safety_net_value(1000.0, decimal=4.0, win_prob=0.25, conversion=0.8)
    premium = safety_net_premium(1000.0, win_prob=0.25, conversion=0.8)
    assert total.expected == pytest.approx(premium)


def test_a_bad_underlying_bet_eats_into_the_premium():
    """The offer does not cover a bad price — it rides on top of one."""
    fair = safety_net_value(1000.0, 4.0, win_prob=0.25, conversion=0.8)
    bad = safety_net_value(1000.0, 4.0, win_prob=0.18, conversion=0.8)
    assert bad.expected < fair.expected


def test_the_premium_falls_as_conversion_falls():
    assert safety_net_premium(1000.0, 0.25, 0.5) < safety_net_premium(1000.0, 0.25, 0.8)
