"""Every test here runs without a key, a socket, or a credit.

That is the point of the fetcher seam: the mapping is the part that can be
wrong, and it is the part that costs nothing to exercise.
"""

import pytest

from datetime import datetime, timezone

from overlay_engine.feed import FeedError, stamp
from overlay_engine.restfeed import (
    MARKET_KEYS,
    Quota,
    RestProvider,
    markets_from_payload,
    parse_time,
    read_quota,
)

NOW = 1_800_000_000.0

# Derived from NOW rather than written out. Hand-typed instants put the feed's
# observation time ten hours after our receipt of it, which `feed.stamp`
# correctly refused as clock skew — the fixture was wrong, and it took the
# engine's own guard to say so.
def _iso(epoch: float) -> str:
    return (datetime.fromtimestamp(epoch, timezone.utc)
            .strftime("%Y-%m-%dT%H:%M:%SZ"))


STAMP = _iso(NOW - 6)                   # the feed saw it six seconds ago
START = _iso(NOW + 1800)                # and the game is half an hour out


def _event(book_update=STAMP, market_update=None, market="h2h",
           outcomes=None, book="draftkings", event_id="e1"):
    outcomes = outcomes or [{"name": "Home", "price": 1.91},
                            {"name": "Away", "price": 2.05}]
    block = {"key": market, "outcomes": outcomes}
    if market_update:
        block["last_update"] = market_update
    bookmaker = {"key": book, "title": book, "markets": [block]}
    if book_update:
        bookmaker["last_update"] = book_update
    return {"id": event_id, "sport_key": "americanfootball_nfl",
            "commence_time": START, "bookmakers": [bookmaker]}


def _fetcher(payload, headers=None):
    def _fetch(path, params):
        _fetch.calls.append((path, params))
        return payload, headers or {}
    _fetch.calls = []
    return _fetch


# ------------------------------------------------------------- timestamps

def test_a_trailing_z_parses_on_this_python():
    """fromisoformat rejected `Z` before 3.11 and this is built for 3.9."""
    assert parse_time("2027-01-15T18:30:00Z") == parse_time(
        "2027-01-15T18:30:00+00:00")


def test_a_naive_timestamp_is_read_as_utc():
    """The feed documents UTC; guessing local time would shift every latency
    measurement by the operator's offset."""
    assert parse_time("2027-01-15T18:30:00") == parse_time(
        "2027-01-15T18:30:00Z")


def test_an_unreadable_timestamp_is_refused():
    with pytest.raises(FeedError, match="unreadable timestamp"):
        parse_time("last tuesday")


def test_an_empty_timestamp_is_refused():
    with pytest.raises(FeedError, match="empty timestamp"):
        parse_time("")


# ---------------------------------------------------------- the mapping

def test_quotes_carry_the_feeds_own_observation_time():
    got = markets_from_payload([_event()], "nfl", NOW)
    assert len(got) == 1
    assert all(q.seen_at == parse_time(STAMP) for q in got[0].quotes)


def test_a_market_level_stamp_beats_the_bookmaker_one():
    """The market block is the more specific claim about when it was seen."""
    later = "2027-01-15T18:45:00Z"
    got = markets_from_payload([_event(market_update=later)], "nfl", NOW)
    assert got[0].quotes[0].seen_at == parse_time(later)


def test_an_undated_quote_falls_back_to_receipt_and_reads_as_assumed():
    """The whole degradation. No stamp means no measurable age, and the quote
    must not claim a freshness nobody observed."""
    got = markets_from_payload([_event(book_update=None)], "nfl", NOW)
    quote = got[0].quotes[0]
    assert quote.seen_at == NOW
    stamped = stamp(got, fetched_at=NOW, provider="restfeed")
    assert stamped.markets[0].quotes[0].provenance == "assumed"


def test_a_dated_quote_reads_as_measured_once_stamped():
    got = markets_from_payload([_event()], "nfl", NOW)
    stamped = stamp(got, fetched_at=NOW, provider="restfeed")
    assert stamped.markets[0].quotes[0].provenance == "measured"


def test_the_start_time_comes_from_commence_time():
    got = markets_from_payload([_event()], "nfl", NOW)
    assert got[0].starts_at == parse_time(START)


def test_books_are_grouped_into_one_market_so_it_can_be_devigged():
    """A market holding one book's prices cannot be compared against anything."""
    payload = [_event(book="draftkings"), _event(book="fanduel")]
    got = markets_from_payload(payload, "nfl", NOW)
    assert len(got) == 1
    assert {q.book for q in got[0].quotes} == {"draftkings", "fanduel"}


def test_different_market_types_stay_separate():
    payload = [_event(market="h2h"), _event(market="totals",
                                            outcomes=[{"name": "Over", "price": 1.9,
                                                       "point": 44.5},
                                                      {"name": "Under", "price": 1.9,
                                                       "point": 44.5}])]
    got = markets_from_payload(payload, "nfl", NOW)
    assert {m.market_type for m in got} == {"h2h", "totals"}


def test_a_point_becomes_the_outcome_line():
    """Two prices on `over` are not comparable unless they share a line."""
    payload = [_event(market="totals",
                      outcomes=[{"name": "Over", "price": 1.9, "point": 44.5},
                                {"name": "Under", "price": 1.9, "point": 44.5}])]
    got = markets_from_payload(payload, "nfl", NOW)
    assert got[0].quotes[0].outcome.line == 44.5
    assert "44.5" in got[0].quotes[0].outcome.key


def test_a_missing_point_leaves_the_line_unset():
    got = markets_from_payload([_event()], "nfl", NOW)
    assert got[0].quotes[0].outcome.line is None


def test_an_unknown_market_key_is_skipped_rather_than_guessed():
    """A market whose semantics nobody checked would be priced by the same code
    that prices the ones we understand."""
    payload = [_event(market="player_shots_on_goal_alternate")]
    assert markets_from_payload(payload, "nfl", NOW) == []


def test_every_mapped_key_maps_to_a_market_type_the_engine_uses():
    assert set(MARKET_KEYS.values()) <= {"h2h", "spreads", "totals"}


# ------------------------------------------------------------- refusals

def test_american_prices_are_refused_rather_than_read_as_decimals():
    """-110 would map straight through and be read as a decimal price."""
    payload = [_event(outcomes=[{"name": "Home", "price": -110},
                                {"name": "Away", "price": -110}])]
    with pytest.raises(FeedError, match="oddsFormat=decimal"):
        markets_from_payload(payload, "nfl", NOW)


def test_a_price_of_exactly_one_is_refused():
    payload = [_event(outcomes=[{"name": "Home", "price": 1.0}])]
    with pytest.raises(FeedError, match="not decimal odds"):
        markets_from_payload(payload, "nfl", NOW)


def test_a_payload_that_is_not_a_list_is_refused():
    with pytest.raises(FeedError, match="expected a list"):
        markets_from_payload({"error": "bad key"}, "nfl", NOW)


def test_an_event_with_no_start_time_is_refused_not_partially_mapped():
    bad = _event()
    del bad["commence_time"]
    with pytest.raises(FeedError, match="refusing a partial map"):
        markets_from_payload([bad], "nfl", NOW)


def test_a_bookmaker_with_no_key_is_refused():
    bad = _event()
    bad["bookmakers"][0]["key"] = ""
    with pytest.raises(FeedError, match="no key"):
        markets_from_payload([bad], "nfl", NOW)


def test_an_outcome_with_no_price_is_refused():
    payload = [_event(outcomes=[{"name": "Home"}])]
    with pytest.raises(FeedError, match="bad outcome"):
        markets_from_payload(payload, "nfl", NOW)


def test_an_event_with_no_bookmakers_maps_to_nothing_rather_than_crashing():
    bare = _event()
    bare["bookmakers"] = []
    assert markets_from_payload([bare], "nfl", NOW) == []


# ---------------------------------------------------------------- quota

def test_quota_is_read_off_the_headers():
    got = read_quota({"x-requests-remaining": "412", "x-requests-used": "88"})
    assert (got.remaining, got.used) == (412, 88)
    assert got.known


def test_quota_headers_are_matched_whatever_their_case():
    assert read_quota({"X-Requests-Remaining": "7"}).remaining == 7


def test_missing_quota_headers_are_unknown_rather_than_zero():
    """Zero would read as an exhausted key rather than an unreported one."""
    got = read_quota({})
    assert got.remaining is None
    assert not got.known
    assert "credits unknown" in got.describe()


def test_a_garbled_quota_header_is_unknown_rather_than_guessed():
    assert read_quota({"x-requests-remaining": "lots"}).remaining is None


# ------------------------------------------------------------- provider

def test_the_provider_maps_a_response_end_to_end():
    fetch = _fetcher([_event()], {"x-requests-remaining": "99"})
    provider = RestProvider(fetcher=fetch, api_key="k", sport_keys=("nfl",),
                            received_at=NOW)
    got = provider.fetch("americanfootball_nfl")
    assert len(got) == 1
    assert provider.quota.remaining == 99


def test_the_provider_asks_for_decimal_odds():
    """The refusal above is a backstop; this is the request that avoids it."""
    fetch = _fetcher([_event()])
    RestProvider(fetcher=fetch, sport_keys=("nfl",), received_at=NOW).fetch("nfl")
    assert fetch.calls[0][1]["oddsFormat"] == "decimal"


def test_the_provider_requests_the_sport_it_was_asked_for():
    fetch = _fetcher([_event()])
    RestProvider(fetcher=fetch, sport_keys=("nfl",), received_at=NOW).fetch("nba")
    assert fetch.calls[0][0] == "/v4/sports/nba/odds"


def test_polling_every_sport_a_key_can_reach_is_refused():
    """Each sport costs a credit, so the set is configured rather than
    discovered."""
    with pytest.raises(FeedError, match="no sports configured"):
        RestProvider(fetcher=_fetcher([])).sports()


def test_configured_sports_are_reported():
    provider = RestProvider(fetcher=_fetcher([]), sport_keys=("nfl", "nba"))
    assert provider.sports() == ["nfl", "nba"]


def test_a_provider_with_no_fetcher_refuses_rather_than_opening_a_socket():
    with pytest.raises(FeedError, match="nothing here opens a socket"):
        RestProvider(sport_keys=("nfl",)).fetch("nfl")


def test_the_api_key_is_omitted_when_absent_rather_than_sent_blank():
    fetch = _fetcher([_event()])
    RestProvider(fetcher=fetch, sport_keys=("nfl",), received_at=NOW).fetch("nfl")
    assert "apiKey" not in fetch.calls[0][1]


def test_the_quota_starts_unknown_rather_than_optimistic():
    assert not RestProvider().quota.known
    assert Quota().remaining is None
