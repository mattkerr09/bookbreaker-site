"""Devigging: every method sums to one, disagrees, and fails loudly."""

import pytest

from overlay_engine.devig import (
    METHODS,
    additive,
    devig,
    devig_all,
    multiplicative,
    power,
    shin,
    worst_case,
)
from overlay_engine.odds import OddsError, american_to_decimal

# -145 / +125: a real Pinnacle-shaped NFL moneyline with ~2% margin.
NFL = [american_to_decimal(-145), american_to_decimal(125)]
# -110 / -110: the canonical juiced spread.
SPREAD = [american_to_decimal(-110), american_to_decimal(-110)]
# A three-way soccer market with a wide margin.
SOCCER = [2.20, 3.40, 3.30]
# A long-tail market with a wide margin — a soccer correct-score screen. The
# equal split additive takes from every outcome exceeds the longest shot's
# whole implied probability, which is the case additive has no answer for.
WIDE = [1.30, 5.0, 8.0, 20.0, 60.0, 150.0]


@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("market", [NFL, SPREAD, SOCCER])
def test_every_method_returns_a_probability_vector(method, market):
    probs = devig(market, method)
    assert len(probs) == len(market)
    assert sum(probs) == pytest.approx(1.0, abs=1e-9)
    assert all(0.0 < p < 1.0 for p in probs)


@pytest.mark.parametrize("method", METHODS)
def test_devig_preserves_ordering(method):
    """The favourite stays the favourite under every method."""
    probs = devig(SOCCER, method)
    assert probs[0] > probs[1]
    assert probs[0] > probs[2]


def test_a_fair_market_is_left_alone():
    """Prices already summing to 1 must survive every method untouched."""
    fair = [2.0, 2.0]
    for method in METHODS:
        assert devig(fair, method) == pytest.approx([0.5, 0.5], abs=1e-9)


def test_symmetric_market_splits_evenly():
    for method in METHODS:
        assert devig(SPREAD, method) == pytest.approx([0.5, 0.5], abs=1e-9)


def test_the_methods_actually_disagree():
    """The premise of the whole module. If they agreed, one would do."""
    spread = devig_all(NFL)
    assert spread.spread(0) > 0.001
    assert spread.low(0) < spread.high(0)


def test_additive_is_more_generous_to_the_longshot_than_multiplicative():
    """The favourite-longshot correction has a direction, and this is it."""
    m = multiplicative(SOCCER)
    a = additive(SOCCER)
    longshot = SOCCER.index(max(SOCCER))
    assert a[longshot] < m[longshot]


def test_power_stays_inside_the_unit_interval_where_additive_cannot():
    """A wide market that breaks additive must not break power."""
    wide = WIDE
    with pytest.raises(OddsError):
        additive(wide)
    probs = power(wide)
    assert all(0.0 < p < 1.0 for p in probs)
    assert sum(probs) == pytest.approx(1.0, abs=1e-9)


def test_additive_refuses_rather_than_clamping():
    """A clamped vector stops summing to 1 and poisons every EV built on it."""
    with pytest.raises(OddsError, match="non-positive"):
        additive(WIDE)


def test_shin_needs_a_positive_margin():
    with pytest.raises(OddsError, match="positive margin"):
        shin([2.10, 2.10])


def test_shin_solves_a_wide_three_way():
    probs = shin(SOCCER)
    assert sum(probs) == pytest.approx(1.0, abs=1e-9)
    assert all(0.0 < p < 1.0 for p in probs)


def test_power_solves_a_heavy_favourite():
    heavy = [american_to_decimal(-2000), american_to_decimal(1000)]
    probs = power(heavy)
    assert sum(probs) == pytest.approx(1.0, abs=1e-9)
    assert probs[0] > 0.9


@pytest.mark.parametrize("fn", [multiplicative, additive, power, shin])
def test_one_outcome_is_not_a_market(fn):
    with pytest.raises(OddsError):
        fn([2.0])


def test_unknown_method_names_the_alternatives():
    with pytest.raises(OddsError, match="power"):
        devig(NFL, "vegas_magic")


def test_devig_all_keeps_failures_rather_than_hiding_them():
    """A tighter envelope on the weirdest markets is the opposite of an error
    bar's purpose."""
    spread = devig_all(WIDE)
    assert "additive" in spread.failed
    assert "additive" not in spread.by_method
    assert "power" in spread.by_method


def test_devig_all_raises_only_when_everything_fails():
    with pytest.raises(OddsError):
        devig_all([2.0])


def test_consensus_defaults_to_equal_weights():
    spread = devig_all(NFL)
    manual = sum(v[0] for v in spread.by_method.values()) / len(spread.by_method)
    assert spread.consensus(0) == pytest.approx(manual)


def test_consensus_respects_weights():
    spread = devig_all(NFL)
    only_power = spread.consensus(0, {"power": 1.0})
    assert only_power == pytest.approx(spread.by_method["power"][0])


def test_consensus_ignores_weights_for_methods_that_failed():
    """Weighting a method that has no answer must not produce a NaN."""
    spread = devig_all(WIDE)
    value = spread.consensus(0, {"additive": 1.0})
    assert 0.0 < value < 1.0


def test_worst_case_is_the_least_favourable_answer():
    wc = worst_case(NFL, 0)
    spread = devig_all(NFL)
    assert wc == spread.low(0)
    assert wc <= spread.consensus(0)


def test_worst_case_bounds_do_not_sum_to_one():
    """Deliberate: they are per-outcome bounds, not a distribution."""
    total = sum(worst_case(SOCCER, i) for i in range(3))
    assert total < 1.0
