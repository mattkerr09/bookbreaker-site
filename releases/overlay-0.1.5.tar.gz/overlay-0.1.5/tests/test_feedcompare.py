"""Comparing feeds is easy to do badly, and every way of doing it badly picks
a provider you then pay for."""

import json
import random

import pytest

from overlay_engine.feedcompare import (
    MIN_COVERAGE,
    MIN_STAMPED,
    CompareError,
    Sample,
    compare,
    distinguishable,
    read_snapshot,
)

NOW = 1_800_000_000.0


def _snapshot(tmp_path, name, latencies, unstamped=0, jitter=0.0, seed=1):
    """A recorded trial where each quote is `latency` seconds old on arrival."""
    rng = random.Random(seed)
    quotes = []
    for lat in latencies:
        actual = lat + (rng.gauss(0.0, jitter) if jitter else 0.0)
        quotes.append({"book": "dk", "outcome": "home", "line": None,
                       "decimal": 1.91, "seen_at": NOW - max(0.0, actual)})
    for _ in range(unstamped):
        quotes.append({"book": "dk", "outcome": "home", "line": None,
                       "decimal": 1.91, "seen_at": None})
    path = tmp_path / f"{name}.json"
    path.write_text(json.dumps({
        "fetched_at": NOW, "provider": name,
        "markets": [{"event_id": "e1", "sport": "nfl", "market_type": "h2h",
                     "quotes": quotes}],
    }))
    return path


def _spread(centre, n=200, width=3.0):
    """`n` latencies evenly spanning `width` seconds around `centre`.

    Deterministic on purpose. Two of these tests first used random draws with
    different seeds and the sample means wandered far enough apart to flip the
    verdict — a test that passes on the seed is the thing this repo objects to
    everywhere else.
    """
    return [centre - width / 2 + width * i / (n - 1) for i in range(n)]


def _sample(name, latencies, quotes=None):
    return Sample(provider=name, latencies=list(latencies),
                  quotes=quotes if quotes is not None else len(latencies))


# ------------------------------------------------------------- reading

def test_latency_is_receipt_minus_the_books_own_timestamp(tmp_path):
    got = read_snapshot(_snapshot(tmp_path, "a", [2.0] * 40))
    assert got.mean == pytest.approx(2.0)
    assert got.stamped == 40


def test_a_clock_running_ahead_cannot_make_a_quote_arrive_early(tmp_path):
    """A negative gap would credit a quote with being fresher than live."""
    path = tmp_path / "ahead.json"
    path.write_text(json.dumps({
        "fetched_at": NOW,
        "markets": [{"event_id": "e", "sport": "nfl", "market_type": "h2h",
                     "quotes": [{"book": "dk", "outcome": "home", "line": None,
                                 "decimal": 1.9, "seen_at": NOW + 30.0}]}],
    }))
    assert read_snapshot(path).latencies == [0.0]


def test_unstamped_quotes_are_counted_but_never_averaged_as_zero(tmp_path):
    """Averaging them in would drag a feed's mean toward zero for the crime of
    not saying when it saw the price."""
    got = read_snapshot(_snapshot(tmp_path, "a", [4.0] * 40, unstamped=60))
    assert got.quotes == 100
    assert got.stamped == 40
    assert got.mean == pytest.approx(4.0)
    assert got.stamped_share == pytest.approx(0.4)


def test_a_snapshot_with_no_fetched_at_is_refused(tmp_path):
    path = tmp_path / "undated.json"
    path.write_text(json.dumps({"markets": []}))
    with pytest.raises(CompareError, match="no fetched_at"):
        read_snapshot(path)


def test_an_empty_snapshot_is_refused(tmp_path):
    path = tmp_path / "empty.json"
    path.write_text(json.dumps({"fetched_at": NOW, "markets": []}))
    with pytest.raises(CompareError, match="no quotes"):
        read_snapshot(path)


def test_an_unreadable_file_is_refused(tmp_path):
    with pytest.raises(CompareError, match="cannot read"):
        read_snapshot(tmp_path / "missing.json")


# ------------------------------------------------------ what is measurable

def test_a_thin_sample_cannot_carry_a_latency_claim():
    got = _sample("thin", [2.0] * (MIN_STAMPED - 1))
    assert not got.measurable
    assert "too few" in got.why_not()


def test_thin_coverage_is_refused_even_with_plenty_of_stamps():
    """A feed you can check a tenth of is not a fast feed."""
    got = _sample("sparse", [2.0] * 50, quotes=1000)
    assert got.stamped >= MIN_STAMPED
    assert got.stamped_share < MIN_COVERAGE
    assert not got.measurable
    assert "describes the subset that stamps" in got.why_not()


def test_an_all_zero_feed_is_not_reported_as_the_fastest():
    """The failure this module exists for: no timestamp records as zero, and
    zero is the best possible number."""
    got = _sample("unstamped", [0.0] * 200)
    assert got.looks_unstamped
    assert not got.measurable
    assert "sending no observation time" in got.why_not()


def test_a_genuinely_fast_feed_is_still_measurable():
    got = _sample("quick", [0.05] * 200)
    assert not got.looks_unstamped
    assert got.measurable


def test_a_healthy_sample_has_no_reason_to_be_excluded():
    assert _sample("ok", [1.0 + i * 0.01 for i in range(100)]).why_not() is None


# ------------------------------------------------------------ dispersion

def test_one_observation_has_no_spread_rather_than_zero_spread():
    """Zero would make a single quote look like a perfectly consistent feed."""
    got = _sample("one", [2.0])
    assert got.sd is None
    assert got.stderr is None
    assert got.interval is None


def test_the_interval_never_extends_below_zero():
    got = _sample("noisy", [0.2, 0.1, 0.9, 0.05, 1.4] * 20)
    assert got.interval[0] >= 0.0


def test_an_empty_sample_reports_no_mean_rather_than_zero():
    got = _sample("none", [], quotes=10)
    assert got.mean is None
    assert "no stamped quotes" in got.describe()


# --------------------------------------------------- telling feeds apart

def test_two_feeds_far_apart_are_distinguishable():
    fast = _sample("fast", [1.0 + i * 0.001 for i in range(200)])
    slow = _sample("slow", [5.0 + i * 0.001 for i in range(200)])
    assert distinguishable(fast, slow)


def test_two_feeds_a_hair_apart_are_not():
    """Same spread, means 0.03s apart. The samples cannot separate that."""
    a, b = _sample("a", _spread(2.00)), _sample("b", _spread(2.03))
    assert a.mean == pytest.approx(2.00)
    assert b.mean == pytest.approx(2.03)
    assert not distinguishable(a, b)


def test_an_unmeasurable_feed_is_never_distinguishable_from_anything():
    real = _sample("real", [2.0 + i * 0.001 for i in range(200)])
    blank = _sample("blank", [0.0] * 200)
    assert not distinguishable(real, blank)
    assert not distinguishable(blank, real)


# ------------------------------------------------------------- comparing

def test_a_clear_winner_is_named(tmp_path):
    paths = [_snapshot(tmp_path, "fast", _spread(1.0, width=0.4)),
             _snapshot(tmp_path, "slow", _spread(4.0, width=0.4))]
    got = compare(paths)
    assert got.winner.provider == "fast"
    assert "Fastest: fast" in got.describe()


def test_a_close_pair_is_refused_rather_than_ranked(tmp_path):
    """A ranking here would be a coin toss with a decimal point."""
    paths = [_snapshot(tmp_path, "a", _spread(2.00)),
             _snapshot(tmp_path, "b", _spread(2.03))]
    got = compare(paths)
    assert got.winner is None
    assert "Too close to call" in got.describe()


def test_an_unstamped_feed_never_wins_however_fast_it_looks(tmp_path):
    paths = [_snapshot(tmp_path, "unstamped", [0.0] * 200),
             _snapshot(tmp_path, "honest", _spread(3.0, width=0.4))]
    got = compare(paths)
    assert got.winner.provider == "honest"
    assert "unstamped" not in [s.provider for s in got.ranked]


def test_a_field_of_unmeasurable_feeds_reports_that_as_the_finding(tmp_path):
    paths = [_snapshot(tmp_path, "a", [0.0] * 200),
             _snapshot(tmp_path, "b", [0.0] * 200)]
    got = compare(paths)
    assert got.winner is None
    assert got.ranked == []
    assert "can carry a latency claim" in got.describe()


def test_a_single_feed_is_reported_without_a_comparison(tmp_path):
    got = compare([_snapshot(tmp_path, "only", _spread(2.0, width=0.4))])
    assert got.winner.provider == "only"


def test_comparing_nothing_is_refused():
    with pytest.raises(CompareError, match="nothing to compare"):
        compare([])


def test_unranked_feeds_are_counted_in_the_output(tmp_path):
    paths = [_snapshot(tmp_path, "good", _spread(2.0, width=0.4)),
             _snapshot(tmp_path, "blank", [0.0] * 200)]
    assert "1 feed(s) left unranked" in compare(paths).describe()
