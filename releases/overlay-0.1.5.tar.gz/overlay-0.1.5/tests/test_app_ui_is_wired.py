"""Every control in the window reaches something that exists.

This test exists because of the data plate that drew nothing. Five of its six
CSS classes did not exist, the build went green, and the figure gate could not
tell an invisible plate from a correct one — because geometry lives in a
`style` attribute the gate deliberately strips. Wrong and correct looked
identical in the region the checker was told to ignore.

The window has the same shape of hole. `cargo test` proves the shell spawns the
engine; the Python suite proves the engine's arithmetic. **Nothing checked that
a tab points at a panel that exists, or that the JavaScript reads an input the
HTML actually contains.** A typo in an element id would ship green: the tab
would highlight, the button would run, and the panel would sit empty.

None of this needs a GUI. The wiring is static and so is the check.
"""

from __future__ import annotations

import re
from pathlib import Path

UI = Path(__file__).resolve().parent.parent / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
RUST = (UI / "src-tauri" / "src" / "main.rs").read_text()


def _all(pattern: str, text: str) -> set[str]:
    return set(re.findall(pattern, text))


TABS = _all(r'data-panel="([a-z-]+)"', HTML)
PANELS = _all(r'id="panel-([a-z-]+)"', HTML)
RUNS = _all(r'data-run="([a-z-]+)"', HTML)
ALLOWED = set(re.search(r'const ALLOWED: \[&str; \d+\] = \[([^\]]+)\]',
                        RUST).group(1).replace('"', '').replace(' ', '').split(','))


def test_there_is_at_least_one_of_everything():
    """A wiring test over empty sets passes trivially. That failure mode has
    appeared four times today; it does not get a fifth."""
    assert TABS and PANELS and RUNS and ALLOWED


def test_every_tab_points_at_a_panel_that_exists():
    assert TABS <= PANELS, f"tabs with no panel: {sorted(TABS - PANELS)}"


def test_every_panel_is_reachable_from_a_tab():
    """An unreachable panel is dead weight in the bundle and a half-finished
    feature nobody can find."""
    assert PANELS <= TABS, f"panels with no tab: {sorted(PANELS - TABS)}"


def test_every_run_button_lives_in_a_panel_that_exists():
    assert RUNS <= PANELS, f"buttons with no panel: {sorted(RUNS - PANELS)}"


def test_every_run_button_has_an_argument_builder():
    """The builder turns the panel's inputs into an engine command. Without one
    the button does nothing and the panel stays empty."""
    for kind in sorted(RUNS):
        assert re.search(rf"\b{kind}: \(\) =>", JS), f"no builder for {kind}"


def test_every_run_button_has_a_renderer():
    """`showDevig`, `showArb` and friends. A missing one throws inside the
    click handler, which surfaces as a button that appears to do nothing."""
    shown = {name.lower() for name in re.findall(r"function show([A-Za-z]+)", JS)}
    for kind in sorted(RUNS):
        assert kind in shown, f"no show{kind.title()} renderer"


def test_every_renderer_is_dispatched():
    """A renderer that exists but is not in the dispatch map is the same
    failure wearing a different hat."""
    dispatch = re.search(r"\(\{([^}]*)\}\)\[kind\]", JS, re.S).group(1)
    for kind in sorted(RUNS):
        assert re.search(rf"\b{kind}:", dispatch), f"{kind} not dispatched"


def test_every_command_the_window_runs_is_allowed_by_the_shell():
    """The Rust side refuses anything not on its list, so a panel calling an
    unlisted command fails at the boundary rather than in the window."""
    assert RUNS <= ALLOWED, f"not allowed by the shell: {sorted(RUNS - ALLOWED)}"


def test_the_shell_allows_nothing_the_window_cannot_reach():
    """The allow-list is an attack surface. Anything on it that no panel uses
    is a command a compromised frontend could run for free."""
    assert ALLOWED <= RUNS, f"allowed but unreachable: {sorted(ALLOWED - RUNS)}"


def test_every_element_the_javascript_reads_exists_in_the_html():
    """The typo this whole file is about. `val("f-age")` against an input with
    id `f_age` returns undefined, the engine gets a malformed argument, and the
    panel shows an error nobody can trace back to a hyphen."""
    ids = _all(r'id="([^"]+)"', HTML)
    read = (_all(r'val\("([^"]+)"\)', JS)
            | _all(r'getElementById\("([^"]+)"\)', JS))
    missing = read - ids
    assert not missing, f"JavaScript reads ids the HTML does not define: {sorted(missing)}"


def test_every_input_in_a_panel_is_read_by_something():
    """An input nobody reads is a control that silently does nothing when the
    user changes it."""
    ids = _all(r'<input id="([^"]+)"', HTML)
    read = (_all(r'val\("([^"]+)"\)', JS)
            | _all(r'getElementById\("([^"]+)"\)', JS))
    assert ids <= read, f"inputs nothing reads: {sorted(ids - read)}"


def test_the_window_follows_the_system_theme():
    """It shipped from 0.1.0 to 0.1.2 pinned to `data-theme="light"`.

    The dark palette was written, maintained and restyled across three
    releases and never once applied: the attribute on `<html>` beat the media
    query every time. Anyone running macOS in dark mode opened a blazing white
    window, and nothing in the suite could tell, because every test read the
    CSS rather than the computed result.
    """
    assert 'data-theme=' not in HTML, (
        "the window pins its own theme; let prefers-color-scheme decide")


def test_a_dark_palette_exists_for_it_to_follow():
    """Removing the attribute only helps if there is something to fall back
    to — the paired half of the bug above."""
    css = (UI / "src" / "app.css").read_text()
    assert "prefers-color-scheme:dark" in css.replace(" ", "")
