"""A crash writes a file. Nothing sends it anywhere.

The failure Matthew actually hit was "the app doesn't even work/open", and a
crash at startup is invisible to everyone: no window appears, no output is
kept, and the only evidence is a user who gives up. This closes that.

**It is not telemetry and must never become telemetry.** This module imports
stdlib only and opens no socket. bookbreaker.bet promises the ledger never
leaves your machine, and a crash report is the most sensitive thing the
process holds — it can contain file paths, argument values and stake sizes. A
reporter that phoned home would break the product's central claim to fix a
debugging inconvenience. `tests/test_app_is_offline.py` fails the build if
anyone adds an uploader.

**Installed at process entry, before anything else initialises.** A handler
that only wraps command dispatch cannot see an import-time failure, which is
precisely the class of crash that produces "it doesn't open".

Three hooks, because Python fails in three different ways:

    sys.excepthook          an unhandled exception on the main thread
    threading.excepthook    the same on any other thread, which otherwise
                            dies silently and leaves the process running
    faulthandler            a segfault or abort in native code, where there
                            is no Python exception to catch at all
"""

from __future__ import annotations

import datetime
import json
import re
import os
import platform
import sys
import threading
import traceback
from pathlib import Path

#: Where reports go. Under the user's own directory, never a temp dir that a
#: cleaner empties before anyone reads it.
CRASH_DIR = Path(os.environ.get("OVERLAY_HOME", Path.home() / ".overlay")) / "crashes"

#: Reports kept. A crash loop must not fill a disk, and the newest reports are
#: the ones anybody reads.
KEEP = 20

#: Things that must never reach a file the user is invited to email us.
#: An exception message is attacker-of-convenience data: whatever the process
#: happened to be holding when it died. `overlay capture --api-key sk-...`
#: puts a live credential straight into argv, and a traceback prints the
#: locals of the frame that raised.
_SECRETS = (
    (re.compile(r"sk-ant-[A-Za-z0-9_-]{8,}"), "sk-ant-REDACTED"),
    (re.compile(r"\bAKIA[0-9A-Z]{12,}"), "AKIA-REDACTED"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{16,}"), "gh-REDACTED"),
    (re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{8,}"), "xox-REDACTED"),
    (re.compile(r"(?i)\b(api[_-]?key|apikey|token|secret|password|passwd|"
                r"bearer)\b\s*[=:]?\s*[\"']?([^\s\"'&]{6,})"),
     r"\1=REDACTED"),
    # A long opaque run is a credential more often than it is anything else.
    (re.compile(r"\b[A-Za-z0-9_-]{32,}\b"), "REDACTED-LONG-TOKEN"),
)


def sanitise(text: str) -> str:
    """Strip anything that looks like a credential.

    Applied to EVERY string that reaches the report, including the exception
    message and the traceback. A reporter that sanitises most fields and
    interpolates into one is a reporter that leaks through that one.
    """
    if not isinstance(text, str):
        text = str(text)
    for pattern, replacement in _SECRETS:
        text = pattern.sub(replacement, text)
    return text


#: A crash is the app failing. These are the app WORKING: it was asked for
#: something it will not do and said so. Writing a report for one fills the
#: directory with noise and buries the crash that matters — and the report is
#: only useful if its presence means something went wrong.
_EXPECTED = ("OddsError", "CorrelationError", "FeedError", "CompareError",
             "ImportError_", "LedgerError", "OfferError", "PortfolioError")


def is_expected(exc_type) -> bool:
    """Whether this is the app refusing, rather than the app breaking."""
    if exc_type is None:
        return False
    if issubclass(exc_type, (KeyboardInterrupt, SystemExit, BrokenPipeError)):
        return True
    return any(base.__name__ in _EXPECTED for base in exc_type.__mro__)


_installed = False


def _now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime(
        "%Y-%m-%dT%H-%M-%SZ")


def _prune() -> None:
    reports = sorted(CRASH_DIR.glob("crash-*.json"))
    for stale in reports[:-KEEP]:
        try:
            stale.unlink()
        except OSError:
            pass


def write_report(kind: str, exc_type, exc_value, exc_tb,
                 thread: str | None = None) -> Path | None:
    """Write one post-mortem and return its path. Never raises.

    A crash handler that throws replaces a diagnosable failure with an
    undiagnosable one, so every branch here is defensive.
    """
    try:
        CRASH_DIR.mkdir(parents=True, exist_ok=True)
        # 0600 files inside a 0755 directory still leak the file names,
        # which carry the crash times. Tighten the directory too, and on
        # every write — an existing directory keeps whatever mode it had.
        os.chmod(CRASH_DIR, 0o700)
        path = CRASH_DIR / f"crash-{_now()}-{os.getpid()}.json"
        report = {
            "kind": kind,
            "when": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "version": _version(),
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "thread": thread,
            # The type name is a bare identifier and carries nothing, but
            # everything derived from the VALUE is user data.
            "argv": [sanitise(a) for a in sys.argv],
            "exception": getattr(exc_type, "__name__", str(exc_type)),
            "message": sanitise(str(exc_value)),
            "traceback": [
                sanitise(line)
                for line in traceback.format_exception(exc_type, exc_value, exc_tb)
            ],
        }
        path.write_text(json.dumps(report, indent=2))
        # The report can name file paths, stake sizes and argument values, so
        # it is readable by its owner and nobody else.
        os.chmod(path, 0o600)
        _prune()
        return path
    except Exception:                                    # noqa: BLE001
        return None


def _version() -> str:
    try:
        from overlay_engine import __version__

        return __version__
    except Exception:                                    # noqa: BLE001
        return "unknown"


def _explain(path: Path | None) -> None:
    if path is None:
        return
    print(f"\nA crash report was written to {path}", file=sys.stderr)
    print("It stays on this machine. Nothing was sent anywhere.",
          file=sys.stderr)
    print("`overlay crashes --bundle` packages it if you want to send it.",
          file=sys.stderr)


def install() -> None:
    """Install the hooks. Idempotent, and safe to call before anything else."""
    global _installed
    if _installed:
        return
    _installed = True

    previous = sys.excepthook

    def _hook(exc_type, exc_value, exc_tb):
        if not is_expected(exc_type):
            _explain(write_report("exception", exc_type, exc_value, exc_tb))
        previous(exc_type, exc_value, exc_tb)

    sys.excepthook = _hook

    # A thread dying silently while the process carries on is the hardest of
    # these to notice, because nothing appears to be wrong.
    def _thread_hook(args):
        if is_expected(args.exc_type):
            return
        write_report("thread", args.exc_type, args.exc_value, args.exc_traceback,
                     thread=getattr(args.thread, "name", None))

    threading.excepthook = _thread_hook

    # A native crash has no Python exception, so faulthandler writes the C
    # stack straight to a file that survives the process dying.
    try:
        import faulthandler

        CRASH_DIR.mkdir(parents=True, exist_ok=True)
        # 0600 files inside a 0755 directory still leak the file names,
        # which carry the crash times. Tighten the directory too, and on
        # every write — an existing directory keeps whatever mode it had.
        os.chmod(CRASH_DIR, 0o700)
        native = CRASH_DIR / "native.log"
        handle = native.open("a")
        os.chmod(native, 0o600)
        faulthandler.enable(file=handle)
    except Exception:                                    # noqa: BLE001
        pass


def reports() -> list[Path]:
    """Every report on disk, newest last."""
    if not CRASH_DIR.exists():
        return []
    return sorted(CRASH_DIR.glob("crash-*.json"))


def bundle(target: Path | None = None) -> Path | None:
    """Zip the reports so a user can attach them to an email, by choice.

    This is the only way a report leaves the machine, and a person has to do
    it. There is no uploader and there is not going to be one.
    """
    import zipfile

    found = reports()
    native = CRASH_DIR / "native.log"
    if not found and not native.exists():
        return None
    out = Path(target) if target else CRASH_DIR / f"bookbreaker-crashes-{_now()}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in found:
            zf.write(path, path.name)
        if native.exists():
            zf.write(native, native.name)
    os.chmod(out, 0o600)
    return out
