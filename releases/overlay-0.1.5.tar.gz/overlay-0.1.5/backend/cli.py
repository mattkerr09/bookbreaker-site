#!/usr/bin/env python3
"""Run the Overlay CLI from a checkout, with nothing installed.

The CLI itself lives in `overlay_engine/cli.py`, so that the packaged
distribution and the checkout run the same code rather than two copies that
drift. This file exists only to put `backend/` on the import path first —
without it, `python3 backend/cli.py` cannot see `overlay_engine` at all.

    python3 backend/cli.py demo

Installed from the wheel, the same program is on PATH as `overlay`.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
