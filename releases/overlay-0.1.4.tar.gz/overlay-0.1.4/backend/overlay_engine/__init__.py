"""Overlay — the edge engine.

*Overlay* is the betting term for a price better than the true probability
warrants. It is the thing the product looks for, so it is what the product is
called.

Three claims separate this from every screen in the category, and each one is
a module:

  `devig` + `fair`   An edge is an interval, not a number. Four defensible
                     devig methods disagree by more than most edges are worth,
                     so the disagreement is reported instead of being resolved
                     by the author's preference.

  `staleness`        An edge you cannot get down is worth zero. Fill
                     probability is modelled per book and market and multiplied
                     through, which reorders the screen — and the reorder is
                     the product.

  `heat`             An account that gets limited stops earning, so account
                     lifetime is the denominator of every edge, not a footnote.

  `clv` + `ledger`   All of the above is graded against closing lines and
                     retuned from the record. Nothing here is tuned by opinion,
                     and a bet is stored with the model state that produced it
                     or not at all — because "which devig method was right"
                     cannot be answered later from prices nobody kept.
"""

from .arb import ArbPlan, Leg, arb_margin, find_arbs, stake_arb
from .calibrate import (
    Calibration,
    apply_book_weights,
    book_weights_for,
    calibrate_all,
    calibrate_books,
    calibrate_methods,
    weights_for,
)
from .catalog import Venue, books_for_state, for_state, has_anchor, state_summary
from .clv import CLVReport, GradedBet, report as clv_report
from .devig import DevigSpread, devig, devig_all, worst_case
from .ev import EVResult, ev_per_unit, evaluate, find_edges
from .exposure import ExposureReport, MarketExposure, Position
from .exposure import report as exposure_report
from .fair import FairValue, fair_value
from .feed import (
    CaptureReport,
    FeedError,
    Provider,
    ReplayProvider,
    Snapshot,
    capture,
    stamp,
    write_snapshot,
)
from .grade import GradeReport, Skip, closing_fair_prob, grade_pending
from .heat import AccountHeat, BetRecord, Shaping, shape
from .importer import ImportReport, detect_columns, import_csv
from .kelly import Sizing, kelly_fraction, size_bet
from .ledger import AtBet, Ledger, LedgerError
from .middles import MarginModel, MiddlePlan, find_middles, window_probability
from .models import Book, BookTier, Edge, Market, Outcome, Quote
from .promo import (
    ConversionPlan,
    Holding,
    HoldingsReport,
    holdings,
    report_holdings,
    Offer,
    OfferType,
    OfferValue,
    best_conversion,
    bet_and_get_value,
    bonus_bet_conversion,
    breakeven_hold,
    conversion_rate,
    deposit_match_value,
    fair_conversion_ceiling,
    profit_boost_value,
    safety_net_premium,
    safety_net_value,
    sequence,
)
from .odds import (
    OddsError,
    Price,
    american_to_decimal,
    decimal_to_american,
    hold,
    overround,
    parse_odds,
)
from .performance import Performance, Slice, TagReport, bonferroni_z, family_error_rate, tag_report, to_csv
from .performance import from_ledger as performance_for
from .performance import report as performance_report
from .pricing import PricingContext, context_for, fair_for, price_market
from .staleness import FillModel, LatencyModel, Observation

__version__ = "0.1.4"

__all__ = [
    "AccountHeat",
    "ArbPlan",
    "AtBet",
    "BetRecord",
    "Book",
    "BookTier",
    "CLVReport",
    "Calibration",
    "CaptureReport",
    "ConversionPlan",
    "DevigSpread",
    "EVResult",
    "Edge",
    "ExposureReport",
    "FairValue",
    "FeedError",
    "FillModel",
    "GradeReport",
    "GradedBet",
    "Holding",
    "HoldingsReport",
    "ImportReport",
    "LatencyModel",
    "Ledger",
    "LedgerError",
    "Leg",
    "MarginModel",
    "Market",
    "MarketExposure",
    "MiddlePlan",
    "Observation",
    "OddsError",
    "Offer",
    "OfferType",
    "OfferValue",
    "Outcome",
    "Performance",
    "Position",
    "Price",
    "PricingContext",
    "Provider",
    "Quote",
    "ReplayProvider",
    "Shaping",
    "Sizing",
    "Skip",
    "Slice",
    "Snapshot",
    "TagReport",
    "Venue",
    "__version__",
    "american_to_decimal",
    "apply_book_weights",
    "arb_margin",
    "best_conversion",
    "bet_and_get_value",
    "bonferroni_z",
    "bonus_bet_conversion",
    "book_weights_for",
    "books_for_state",
    "breakeven_hold",
    "calibrate_all",
    "calibrate_books",
    "calibrate_methods",
    "capture",
    "closing_fair_prob",
    "clv_report",
    "context_for",
    "conversion_rate",
    "decimal_to_american",
    "deposit_match_value",
    "detect_columns",
    "devig",
    "devig_all",
    "ev_per_unit",
    "evaluate",
    "exposure_report",
    "fair_conversion_ceiling",
    "fair_for",
    "fair_value",
    "family_error_rate",
    "find_arbs",
    "find_edges",
    "find_middles",
    "for_state",
    "grade_pending",
    "has_anchor",
    "hold",
    "holdings",
    "import_csv",
    "kelly_fraction",
    "overround",
    "parse_odds",
    "performance_for",
    "performance_report",
    "price_market",
    "profit_boost_value",
    "report_holdings",
    "safety_net_premium",
    "safety_net_value",
    "sequence",
    "shape",
    "size_bet",
    "stake_arb",
    "stamp",
    "state_summary",
    "tag_report",
    "to_csv",
    "weights_for",
    "window_probability",
    "worst_case",
    "write_snapshot",
]
