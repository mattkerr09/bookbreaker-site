"""The wallet: what the person says they have at each sportsbook, kept on this Mac only.

Why it exists. A bettor spreads money over several books and loses track of where it is. Saving a bet takes its
stake out of a book; settling it puts something back. Keeping that sum here saves doing it in a head.

**The person types every balance.** Nothing here reaches a book, logs in to one, or reads one. A balance is what
was typed, moved by the bets saved and settled in this app, and it is wrong the moment money moves anywhere
else. The way to fix it is to type it again (`set_balance`).

**A book never set stays unset.** Saving or settling a bet at a book with no balance changes nothing and says
nothing. Only books the person chose to keep are kept.

**A balance cannot go below zero.** A stake larger than the balance means the typed balance was out of date.
The balance is then set to zero and the sentence says to type it again, rather than showing money nobody has.

The balances live in the ledger's settings store under one key, `wallet`, as `{book: amount}`.
"""

from __future__ import annotations

import math

from .catalog import VENUES
from .ledger import Ledger, LedgerError

#: The settings key the balances are kept under.
KEY = "wallet"

#: Said on the wallet, in these words.
TYPED_ONLY = ("These are the amounts you typed, moved by the bets you save and settle here. Bookbreaker never "
              "reads a book, so type a balance again whenever it is off.")

RESULTS = ("won", "lost", "push", "void")


def _money(x: float) -> str:
    return f"${abs(x):,.2f}"


def book_name(book: str) -> str:
    """The book as the person knows it; an unknown key is shown as it is."""
    venue = VENUES.get(book)
    return venue.name if venue is not None else book


def resolve_book(text: str) -> str:
    """The catalog key for what was typed: the key itself (`dk`) or the book's name (`DraftKings`)."""
    typed = str(text or "").strip().lower()
    if typed in VENUES:
        return typed
    for key, venue in VENUES.items():
        if venue.name.lower() == typed:
            return key
    raise LedgerError(f"{str(text).strip()!r} is not a book Bookbreaker knows. Use the short name it shows "
                      "beside the book, like dk or fd.")


def _read(db: Ledger) -> dict:
    raw = db.get_setting(KEY, {})
    if not isinstance(raw, dict):
        return {}
    out = {}
    for book, amount in raw.items():
        if isinstance(amount, (int, float)) and not isinstance(amount, bool) and math.isfinite(amount):
            out[str(book)] = float(amount)
    return out


def _write(db: Ledger, held: dict) -> None:
    db.set_setting(KEY, {book: round(amount, 2) for book, amount in held.items()})


def _amount(value) -> float:
    try:
        amount = float(str(value).replace(",", "").replace("$", "").strip())
    except ValueError:
        raise LedgerError(f"{value!r} is not an amount. Type what is in the account, like 250 or 250.50.") from None
    if not math.isfinite(amount):
        raise LedgerError(f"{value!r} is not an amount. Type what is in the account, like 250 or 250.50.")
    if amount < 0:
        raise LedgerError("A balance cannot be less than zero. Type what is in the account.")
    if amount > 1_000_000_000:
        raise LedgerError("That balance is too large to be right. Type what is in the account.")
    return round(amount, 2)


def _change(book: str, before: float, after: float, text: str) -> dict:
    return {"book": book, "name": book_name(book), "before": round(before, 2), "after": round(after, 2),
            "balance_text": _money(after), "text": text}


def set_balance(db: Ledger, book: str, amount) -> dict:
    """Type what is in one book's account. Refuses a negative amount and a book the catalog does not know."""
    key = resolve_book(book)
    value = _amount(amount)
    held = _read(db)
    before = held.get(key)
    held[key] = value
    _write(db, held)
    name = book_name(key)
    if before is None:
        text = f"{name} balance set to {_money(value)}."
    else:
        text = f"{name} balance changed from {_money(before)} to {_money(value)}."
    return _change(key, value if before is None else before, value, text)


def balances(db: Ledger) -> dict:
    """Every book with a balance, its name, and the total. `unset` lists the books not kept, for a picker."""
    held = _read(db)
    rows = [{"book": book, "name": book_name(book), "balance": round(held[book], 2),
             "balance_text": _money(held[book])}
            for book in sorted(held, key=lambda b: (book_name(b).lower(), b))]
    total = round(sum(r["balance"] for r in rows), 2)
    unset = [{"book": key, "name": venue.name} for key, venue in VENUES.items() if key not in held]
    return {"books": rows, "count": len(rows), "total": total, "total_text": _money(total),
            "empty": not rows, "unset": unset, "note": TYPED_ONLY}


def on_bet(db: Ledger, book: str, stake: float) -> dict | None:
    """A bet was saved: take its stake off the book's balance. None when the book has no balance."""
    held = _read(db)
    if book not in held:
        return None
    before = held[book]
    stake = round(float(stake), 2)
    after = round(before - stake, 2)
    name = book_name(book)
    if after < 0:
        after = 0.0
        text = (f"{_money(stake)} left {name}, more than the {_money(before)} you had typed, so the balance is "
                "now $0.00. Type it again to put it right.")
    else:
        text = f"{_money(stake)} left {name}. It now has {_money(after)}."
    held[book] = after
    _write(db, held)
    return _change(book, before, after, text)


def on_settle(db: Ledger, book: str, stake: float, result: str, profit: float) -> dict | None:
    """A bet was settled. Won returns the stake and the profit; a push or a void returns the stake; a loss
    returns nothing, since the stake already left when the bet was saved. None when the book has no balance."""
    if result not in RESULTS:
        raise LedgerError(f"{result!r} is not a result. Use won, lost, push or void.")
    held = _read(db)
    if book not in held:
        return None
    before = held[book]
    stake = round(float(stake), 2)
    if result == "won":
        back = stake + round(float(profit), 2)
    elif result in ("push", "void"):
        back = stake
    else:
        back = 0.0
    after = round(before + back, 2)
    held[book] = after
    _write(db, held)
    name = book_name(book)
    if result == "won":
        text = (f"{_money(back)} came back to {name}: your {_money(stake)} and {_money(profit)} won. "
                f"It now has {_money(after)}.")
    elif result == "lost":
        text = f"{name} gets nothing back from a lost bet. It still has {_money(after)}."
    else:
        word = "a push" if result == "push" else "void"
        text = f"{_money(back)} came back to {name}, because the bet was {word}. It now has {_money(after)}."
    return _change(book, before, after, text)


def wallet_text(db: Ledger) -> str:
    """The wallet as plain lines."""
    got = balances(db)
    if got["empty"]:
        return ("No balances yet. Type what is in an account with: wallet --set BOOK AMOUNT, like wallet --set dk 250.\n"
                + TYPED_ONLY)
    lines = [f"  {r['name']:<18} {r['balance_text']:>14}" for r in got["books"]]
    lines.append(f"  {'Total':<18} {got['total_text']:>14}")
    return "\n".join(lines) + "\n" + TYPED_ONLY


__all__ = ["KEY", "TYPED_ONLY", "balances", "book_name", "on_bet", "on_settle", "resolve_book", "set_balance",
           "wallet_text"]
