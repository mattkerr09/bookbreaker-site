"""The wallet, the engine's side: the balance a person says they have at each book, kept on this Mac.

What these pin is what the window cannot show:

  * a balance is what the person typed, per book in the catalog, with a total, and a negative one or an unknown
    book is refused and writes nothing;
  * saving a bet takes its stake off that book, and settling it returns what the result says: a win returns the
    stake and the profit, a push and a void return the stake, a loss returns nothing;
  * a book the person never set is never touched, and saving a bet there says nothing about a balance;
  * the track verb's text gains one line about the balance only when the book has one;
  * the `wallet` verb lists, sets and prints the shape the window reads, and says nothing a bettor should not hear.

Nothing here touches the real `~/.overlay`: every ledger is a temporary file.
"""

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from overlay_engine import tracking, wallet
from overlay_engine.ledger import Ledger, LedgerError

ROOT = Path(__file__).resolve().parent.parent
BANNED = ("guaranteed", "risk-free", "risk free", "riskfree", "either way", "free bet", "lock")
NOW = 1_700_000_000.0


@pytest.fixture()
def db(tmp_path):
    with Ledger(tmp_path / "t.db") as ledger:
        yield ledger


def _pick(book="dk", **over):
    pick = {"event_id": "g1", "sport": "basketball_nba", "market_type": "h2h", "outcome": "home", "book": book,
            "book_name": "DraftKings", "selection": "Home"}
    pick.update(over)
    return pick


def _save(db, book="dk", stake="25", price="+110", ref=None):
    return tracking.save(db, _pick(book), price=price, stake=stake, ref=ref, now=NOW)


def _balance(db, book):
    return {r["book"]: r["balance"] for r in wallet.balances(db)["books"]}.get(book)


# ------------------------------------------------------------ set and list

def test_a_balance_that_was_typed_is_listed_with_its_name_and_a_total(db):
    wallet.set_balance(db, "dk", "250")
    wallet.set_balance(db, "fd", "$1,000.50")
    got = wallet.balances(db)
    assert [(r["book"], r["name"], r["balance"]) for r in got["books"]] == [
        ("dk", "DraftKings", 250.0), ("fd", "FanDuel", 1000.5)]
    assert got["total"] == pytest.approx(1250.5) and got["total_text"] == "$1,250.50" and got["count"] == 2
    assert "dk" not in {u["book"] for u in got["unset"]} and "mgm" in {u["book"] for u in got["unset"]}


def test_nothing_set_is_an_empty_wallet_that_says_how_to_start(db):
    got = wallet.balances(db)
    assert got["empty"] and got["books"] == [] and got["total"] == 0.0
    assert "wallet --set" in wallet.wallet_text(db)


def test_typing_a_balance_again_replaces_it_and_the_book_can_be_named_by_its_name(db):
    wallet.set_balance(db, "dk", 100)
    change = wallet.set_balance(db, "DraftKings", 40)
    assert _balance(db, "dk") == 40.0 and change["before"] == 100.0 and change["after"] == 40.0
    assert "changed from $100.00 to $40.00" in change["text"]


def test_a_zero_balance_is_a_balance(db):
    wallet.set_balance(db, "dk", 0)
    assert _balance(db, "dk") == 0.0 and wallet.balances(db)["count"] == 1


# ------------------------------------------------------------ refusals

@pytest.mark.parametrize("amount", ["-5", -0.01, "nan", "inf", "abc", ""])
def test_a_negative_or_unreadable_balance_is_refused_and_writes_nothing(db, amount):
    wallet.set_balance(db, "dk", 100)
    with pytest.raises(LedgerError):
        wallet.set_balance(db, "dk", amount)
    assert _balance(db, "dk") == 100.0


def test_a_book_the_catalog_does_not_know_is_refused_and_writes_nothing(db):
    with pytest.raises(LedgerError) as err:
        wallet.set_balance(db, "notabook", 100)
    assert "not a book Bookbreaker knows" in str(err.value)
    assert wallet.balances(db)["empty"]


# ------------------------------------------------------------ a bet takes the stake off

def test_a_bet_takes_its_stake_off_that_book_and_no_other(db):
    wallet.set_balance(db, "dk", 100)
    wallet.set_balance(db, "fd", 50)
    change = wallet.on_bet(db, "dk", 25)
    assert _balance(db, "dk") == 75.0 and _balance(db, "fd") == 50.0
    assert change["before"] == 100.0 and change["after"] == 75.0 and "$25.00 left DraftKings" in change["text"]


def test_a_stake_bigger_than_the_balance_leaves_zero_not_a_negative_and_says_to_retype(db):
    wallet.set_balance(db, "dk", 10)
    change = wallet.on_bet(db, "dk", 25)
    assert _balance(db, "dk") == 0.0 and "Type it again" in change["text"]


# ------------------------------------------------------------ each result

@pytest.mark.parametrize("result, profit, expected", [
    ("won", 27.5, 100 + 27.5 + 25),
    ("lost", -25.0, 100.0),
    ("push", 0.0, 100 + 25),
    ("void", 0.0, 100 + 25),
])
def test_each_result_returns_what_it_should(db, result, profit, expected):
    wallet.set_balance(db, "dk", 100)
    change = wallet.on_settle(db, "dk", 25, result, profit)
    assert _balance(db, "dk") == pytest.approx(expected) and change["after"] == pytest.approx(expected)


def test_a_result_that_is_not_one_is_refused(db):
    wallet.set_balance(db, "dk", 100)
    with pytest.raises(LedgerError):
        wallet.on_settle(db, "dk", 25, "cancelled", 0.0)
    assert _balance(db, "dk") == 100.0


# ------------------------------------------------------------ a book with no balance

def test_a_book_with_no_balance_is_never_touched(db):
    wallet.set_balance(db, "fd", 50)
    assert wallet.on_bet(db, "dk", 25) is None
    assert wallet.on_settle(db, "dk", 25, "won", 30.0) is None
    assert _balance(db, "dk") is None and _balance(db, "fd") == 50.0
    assert [r["book"] for r in wallet.balances(db)["books"]] == ["fd"]


# ------------------------------------------------------------ saving and settling a tracked bet

def test_saving_a_tracked_bet_takes_the_stake_and_the_text_gives_the_new_balance(db):
    wallet.set_balance(db, "dk", 100)
    out = _save(db, stake="25")
    assert _balance(db, "dk") == 75.0
    assert out["text"].endswith("DraftKings balance: $75.00.") and out["wallet"]["after"] == 75.0


def test_saving_a_tracked_bet_at_a_book_with_no_balance_changes_nothing_and_says_nothing(db):
    out = _save(db, stake="25")
    assert out["wallet"] is None and "balance" not in out["text"] and wallet.balances(db)["empty"]


def test_saving_the_same_bet_twice_takes_the_stake_once(db):
    wallet.set_balance(db, "dk", 100)
    _save(db, ref="once")
    _save(db, ref="once")
    assert _balance(db, "dk") == 75.0


def test_settling_a_tracked_bet_returns_by_its_result_and_the_text_gives_the_new_balance(db):
    wallet.set_balance(db, "dk", 100)
    won = _save(db, stake="25", price="+100")
    lost = _save(db, stake="10", price="+100")
    push = _save(db, stake="5", price="+100")
    assert _balance(db, "dk") == 60.0
    out = tracking.settle(db, won["bet_id"], "won", now=NOW)
    assert _balance(db, "dk") == 110.0 and out["text"].endswith("DraftKings balance: $110.00.")
    tracking.settle(db, lost["bet_id"], "lost", now=NOW)
    assert _balance(db, "dk") == 110.0
    tracking.settle(db, push["bet_id"], "push", now=NOW)
    assert _balance(db, "dk") == 115.0


def test_a_settled_bet_cannot_be_settled_again_to_return_money_twice(db):
    wallet.set_balance(db, "dk", 100)
    bet = _save(db, stake="25", price="+100")
    tracking.settle(db, bet["bet_id"], "won", now=NOW)
    with pytest.raises(LedgerError):
        tracking.settle(db, bet["bet_id"], "won", now=NOW)
    assert _balance(db, "dk") == 125.0


def test_settling_at_a_book_with_no_balance_adds_no_line(db):
    bet = _save(db)
    out = tracking.settle(db, bet["bet_id"], "won", now=NOW)
    assert out["wallet"] is None and "balance" not in out["text"] and wallet.balances(db)["empty"]


def test_a_damaged_wallet_setting_reads_as_empty_not_as_a_crash(db):
    db.set_setting(wallet.KEY, ["not", "a", "dict"])
    assert wallet.balances(db)["empty"]
    db.set_setting(wallet.KEY, {"dk": "lots", "fd": 20})
    assert [r["book"] for r in wallet.balances(db)["books"]] == ["fd"]


# ------------------------------------------------------------ the verb

def _verb(tmp_path, *args):
    run = subprocess.run([sys.executable, str(ROOT / "backend" / "cli.py"), "wallet", *args],
                         capture_output=True, text=True, env={**os.environ, "OVERLAY_HOME": str(tmp_path / "home")})
    return run


def test_the_verb_sets_and_lists_in_the_ledger_it_is_pointed_at(tmp_path):
    path = tmp_path / "t.db"
    run = _verb(tmp_path, "--set", "dk", "250", "--json", "--db", str(path))
    assert run.returncode == 0, run.stderr
    out = json.loads(run.stdout)
    assert out["command"] == "wallet" and out["ledger"] == str(path)
    assert out["changed"]["book"] == "dk" and out["changed"]["after"] == 250.0
    run = _verb(tmp_path, "--json", "--db", str(path))
    out = json.loads(run.stdout)
    assert set(out) >= {"command", "books", "count", "total", "total_text", "empty", "unset", "note", "text",
                        "changed", "ledger"}
    assert out["books"] == [{"book": "dk", "name": "DraftKings", "balance": 250.0, "balance_text": "$250.00"}]
    assert out["total"] == 250.0 and out["total_text"] == "$250.00" and out["changed"] is None and not out["empty"]
    assert not (tmp_path / "home" / "overlay.db").exists()
    with Ledger(path) as db:
        assert _balance(db, "dk") == 250.0


def test_the_verb_in_words_lists_the_books_and_the_total(tmp_path):
    path = tmp_path / "t.db"
    _verb(tmp_path, "--set", "dk", "250", "--db", str(path))
    run = _verb(tmp_path, "--set", "FanDuel", "100", "--db", str(path))
    assert run.returncode == 0, run.stderr
    assert "FanDuel balance set to $100.00." in run.stdout
    assert "DraftKings" in run.stdout and "$350.00" in run.stdout and "Total" in run.stdout


def test_the_verb_refuses_a_negative_balance_and_an_unknown_book_with_a_sentence(tmp_path):
    path = tmp_path / "t.db"
    run = _verb(tmp_path, "--set", "dk", "-5", "--json", "--db", str(path))
    out = json.loads(run.stdout)
    assert run.returncode == 2 and out["command"] == "wallet" and "less than zero" in out["error"]
    run = _verb(tmp_path, "--set", "nowhere", "5", "--json", "--db", str(path))
    out = json.loads(run.stdout)
    assert run.returncode == 2 and "not a book Bookbreaker knows" in out["error"]
    out = json.loads(_verb(tmp_path, "--json", "--db", str(path)).stdout)
    assert out["empty"]


def test_the_verb_and_the_track_verb_share_one_wallet(tmp_path):
    path = tmp_path / "t.db"
    _verb(tmp_path, "--set", "dk", "100", "--db", str(path))
    pick = json.dumps(_pick())
    run = subprocess.run([sys.executable, str(ROOT / "backend" / "cli.py"), "track", f"--pick={pick}",
                          "--price=+100", "--stake=40", "--json", "--db", str(path)],
                         capture_output=True, text=True, env={**os.environ, "OVERLAY_HOME": str(tmp_path / "home")})
    out = json.loads(run.stdout)
    assert run.returncode == 0 and out["wallet"]["after"] == 60.0 and out["text"].endswith("DraftKings balance: $60.00.")
    assert json.loads(_verb(tmp_path, "--json", "--db", str(path)).stdout)["total"] == 60.0


# ------------------------------------------------------------ what it says, and where it goes

def _strings(node):
    if isinstance(node, str):
        yield node
    elif isinstance(node, dict):
        for v in node.values():
            yield from _strings(v)
    elif isinstance(node, list):
        for v in node:
            yield from _strings(v)


def test_everything_it_says_stays_in_plain_words(db):
    said = []
    wallet.set_balance(db, "dk", 10)
    said.append(wallet.set_balance(db, "dk", 5))
    said.append(wallet.on_bet(db, "dk", 25))
    wallet.set_balance(db, "dk", 100)
    for result in wallet.RESULTS:
        said.append(wallet.on_settle(db, "dk", 25, result, 10.0))
    said.append(wallet.balances(db))
    said.append(wallet.wallet_text(db))
    text = " ".join(_strings(said)).lower()
    for word in BANNED:
        assert word not in text, word


def test_the_wallet_never_reaches_a_book_or_a_network():
    source = (ROOT / "backend" / "overlay_engine" / "wallet.py").read_text()
    for needle in ("import requests", "urllib", "http.client", "socket", "subprocess", "urlopen"):
        assert needle not in source, needle
