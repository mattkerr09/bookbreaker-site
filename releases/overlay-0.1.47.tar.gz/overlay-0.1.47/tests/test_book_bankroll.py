"""A bankroll for each book (the AVO bar's item 11, last piece): a +EV play at a book with a balance in Your books is
sized on that balance and says so; any other play keeps the saved bankroll; a board reads the balances without
opening the ledger for writing."""
import json
import os
import re
import subprocess
import sys
from pathlib import Path

from overlay_engine import kelly, wallet
from overlay_engine.ledger import Ledger

ROOT = Path(__file__).resolve().parents[1]


def _ev(book):
    return {"kind": "ev", "legs": [{"book": book, "decimal": 2.2, "fair_prob": 0.5, "ev_low": 0.03}]}


def test_a_book_with_a_balance_is_sized_on_that_balance():
    rows = [_ev("dk"), _ev("fd")]
    kelly.stake_rows(rows, 2000, 0.25, {"dk": 400.0}, {"dk": "DraftKings"})
    dk, fd = rows[0]["sizing"], rows[1]["sizing"]
    assert dk["bankroll"] == 400.0 and dk["from_book"] is True
    assert dk["stake"] == kelly.ev_stake(2.2, 0.5, 0.03, 400.0, 0.25)["stake"]
    assert "your DraftKings balance of $400.00 in Your books" in dk["text"]
    assert fd["bankroll"] == 2000 and fd["from_book"] is False and "your $2,000 bankroll" in fd["text"]


def test_without_a_saved_bankroll_only_books_with_a_balance_get_a_stake():
    rows = [_ev("dk"), _ev("fd")]
    kelly.stake_rows(rows, None, 0.25, {"dk": 400.0}, {"dk": "DraftKings"})
    assert rows[0]["sizing"]["stake"] > 0 and "sizing" not in rows[1]


def test_a_zero_balance_suggests_nothing_and_says_why():
    rows = [_ev("dk")]
    kelly.stake_rows(rows, 2000, 0.25, {"dk": 0.0}, {"dk": "DraftKings"})
    s = rows[0]["sizing"]
    assert s["stake"] == 0 and "DraftKings balance in Your books is $0.00" in s["text"]
    assert not re.search(r"guarantee|risk.free|either way|free bet|\bwin\b|sure thing", s["text"], re.I)


def test_the_board_reads_balances_without_writing(tmp_path):
    db = tmp_path / "overlay.db"
    with Ledger(db) as led:
        wallet.set_balance(led, "dk", 300)
    before = (db.stat().st_mtime_ns, db.read_bytes())
    assert wallet.read_file(db) == {"dk": 300.0}
    assert (db.stat().st_mtime_ns, db.read_bytes()) == before
    assert wallet.read_file(tmp_path / "missing.db") == {}
    assert not (tmp_path / "missing.db").exists()


def _board(home, *extra):
    env = {**os.environ, "OVERLAY_HOME": str(home)}
    out = subprocess.run([sys.executable, "-m", "overlay_engine.cli", "board", "--kind", "ev", *extra, "--json"],
                         cwd=ROOT / "backend", capture_output=True, text=True, check=True, env=env).stdout
    return json.loads(out)


def test_the_board_sizes_a_row_on_its_books_balance(tmp_path):
    rows = _board(tmp_path)["rows"]
    assert rows and all(r["sizing"] is None for r in rows)
    assert not (tmp_path / "overlay.db").exists(), "a board with no wallet must not make a ledger"
    book = rows[0]["legs"][0]["book"]
    with Ledger(tmp_path / "overlay.db") as led:
        wallet.set_balance(led, book, 500)
    sized = [r for r in _board(tmp_path)["rows"] if r["legs"][0]["book"] == book]
    assert sized and all(r["sizing"] and r["sizing"]["from_book"] and r["sizing"]["bankroll"] == 500 for r in sized)
    assert all(wallet.book_name(book) in r["sizing"]["text"] for r in sized)
