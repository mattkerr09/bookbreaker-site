"""Your books in the window (wallet.py's verb): the window may run `wallet`, the build asks the built engine about it
offline, the balance typed is what is sent, and the window draws the engine's figures without arithmetic."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JS = (ROOT / "ui" / "src" / "app.js").read_text()


def test_the_window_may_run_wallet_and_the_build_asks_the_built_engine():
    rust = (ROOT / "ui" / "src-tauri" / "src" / "main.rs").read_text()
    verbs = re.findall(r'"([a-z-]+)"', re.search(r'const ALLOWED: \[&str; \d+\] = \[([^\]]+)\]', rust).group(1))
    assert "wallet" in verbs
    build = (ROOT / "scripts" / "build_app.sh").read_text()
    assert re.search(r'^\s+wallet\)\s+probe=\(wallet --db "\$TMPH/probe\.db"\)', build, re.M)


def test_saving_sends_the_book_and_the_amount_typed():
    assert 'walletset: () => ["wallet", "--set", val("w-book"), val("w-amt").replace(/[$,]/g, "")],' in JS


def test_the_window_draws_the_engines_balances_without_arithmetic():
    body = JS[JS.index("function showWalletlist"):JS.index("function showHedge")]
    assert "balance_text" in body and "total_text" in body
    assert not re.search(r"toFixed|Math\.|\breduce\(", body), "the window adds nothing up"
