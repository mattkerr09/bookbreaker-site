"""The window's half of board filters: it keeps what was chosen, passes it as flags and draws the engine's words.

The engine sorts and narrows (tests/test_board_filters.py). These pin that the window:

  * does no arithmetic and no sorting of its own: it never compares a price, counts a play or orders a list, and when
    a sort was chosen it draws the plays in exactly the order the engine sent;
  * keeps its choices in one storage key on this Mac and sends them on a read the person starts, each value as ONE
    token (a price like -150 is a value, never an option), and only on the two reads that build a board of plays;
  * changing a control reads nothing and starts nothing: it prints the engine's count and says where it is used;
  * reads only fields the engine sends, and its controls offer exactly the choices the engine knows;
  * Clear filters empties these controls and Hide under and leaves Recommended where it was;
  * says so, with a way out, when the filters leave a board empty.
"""

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine import boardfilter, cli  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "ui" / "src" / "index.html").read_text()
JS = (ROOT / "ui" / "src" / "app.js").read_text()
CSS = (ROOT / "ui" / "src" / "app.css").read_text()
NODE = shutil.which("node")

START = "/* ------------------------------------------------------------ Board filters"
SECTION = JS[JS.index(START):JS.index("/* ------------------------------------------------------------ EV formula")]
CODE = SECTION[SECTION.index("*/"):]
BOX = HTML[HTML.index('id="bf-box"'):HTML.index("</details>", HTML.index('id="bf-box"'))]


def _braced(text: str, anchor: str) -> str:
    start = text.index(anchor)
    opened = text.index("{", start)
    depth = 0
    for i in range(opened, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[opened:i + 1]
    raise AssertionError(f"unbalanced braces after {anchor!r}")


# ------------------------------------------------------------ the window works nothing out

def test_the_window_sorts_compares_and_counts_nothing():
    for banned in (".sort(", ".reduce(", "parseFloat", "parseInt", "Number(", "Math.", ".toFixed(", "toLocaleString",
                   "toPrecision", "Date.now", "new Date", ".length >", ".length <", "> 0", "< 0"):
        assert banned not in CODE, banned
    # Two lists are filtered, and neither is a count or a comparison of prices: a stored value that is not text is
    # discarded, and a switched-off name the board does not carry is found by the key the engine gave.
    assert CODE.count(".filter(") == 2
    assert '.filter((x) => typeof x === "string")' in CODE and "off.filter((k) => !here.has(k))" in CODE


def test_a_sort_the_person_chose_is_drawn_in_the_order_the_engine_sent():
    order = _braced(JS, "function boardOrder(")
    assert "if (bf && bf.sorted_by) return plays;" in order
    assert order.index("if (bf && bf.sorted_by) return plays;") < order.index(".sort(")
    for show in ("function showBoard(", "function showOddsboard("):
        assert "boardOrder(out.rows, out.board_filters)" in _braced(JS, show), show


@pytest.mark.skipif(NODE is None, reason="node is not installed")
def test_the_order_function_keeps_the_engines_order_when_a_sort_was_chosen_and_groups_by_kind_when_not():
    start = JS.index("function boardOrder(")
    func = JS[start:JS.index("{", start) + len(_braced(JS, "function boardOrder("))]
    script = (func + "\nconst boardPlay = (r) => r;\n"
              + "const rows = [{kind:'ev'},{kind:'middle'},{kind:'arb'}];\n"
              + "console.log(JSON.stringify([boardOrder(rows, {sorted_by:'edge'}).map(r=>r.kind),"
              + " boardOrder(rows, {sorted_by:null}).map(r=>r.kind), boardOrder(rows, null).map(r=>r.kind)]));")
    done = subprocess.run([NODE, "-e", script], capture_output=True, text=True)
    assert done.returncode == 0, done.stderr[-400:]
    assert json.loads(done.stdout) == [["ev", "middle", "arb"], ["arb", "middle", "ev"], ["arb", "middle", "ev"]]


# ------------------------------------------------------------ what is kept, and what is sent

def test_the_choices_are_kept_under_one_key_through_the_stores_helper_and_nowhere_else():
    assert re.findall(r'store\.set\("([^"]+)"', CODE) == ["bb.boardfilters"]
    assert 'store.get("bb.boardfilters", null)' in CODE
    for sink in ("localStorage", "sessionStorage", "indexedDB", "document.cookie"):
        assert sink not in CODE, sink


def test_a_value_that_is_not_text_is_never_trusted_from_storage():
    restore = _braced(CODE, "(function restoreBoardFilters()")
    assert 'typeof saved[k] === "string"' in restore and 'Array.isArray(saved[k])' in restore


def test_every_value_goes_to_the_engine_as_one_token_and_only_on_the_two_reads_that_build_a_board():
    flags = _braced(CODE, "function boardFilterFlags()")
    for flag in ("--sort=${BF.sort}", "--game-state=${BF.gstate}", "--within=${BF.within}", "--min-price=${BF.pmin}",
                 "--max-price=${BF.pmax}", "--min-window=${BF.win}", "--league-off=${l}", "--bet-type-off=${t}"):
        assert f"`{flag}`" in flags, flag
    body = JS[JS.index("const argv = {"):JS.index("}[kind]();")]
    builders = {part.split(":")[0]: part for part in re.split(r"\n    (?=[a-z]+: \(\) =>)", body)[1:]}
    assert {"board", "oddsboard", "screen", "lowhold", "futuresread", "altread"} <= set(builders)
    users = sorted(k for k, v in builders.items() if "boardFilterFlags()" in v)
    assert users == ["board", "oddsboard"], users
    assert JS.count("boardFilterFlags()") == 3          # the two builders and the function itself


def test_every_flag_the_window_sends_is_one_the_engine_takes():
    flags = _braced(CODE, "function boardFilterFlags()")
    sent = re.findall(r"`(--[a-z-]+)=", flags)
    assert len(sent) == 8
    sample = {"--sort": "edge", "--game-state": "in_play", "--within": "24h", "--min-price": "-150",
              "--max-price": "+200", "--min-window": "2", "--league-off": "NBA", "--bet-type-off": "totals"}
    import contextlib
    import io
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        code = cli.main(["board", "--json", *[f"{f}={sample[f]}" for f in sent]])
    assert code == 0
    block = json.loads(out.getvalue())["board_filters"]
    assert block["enabled"] and block["active"] and block["sorted_by"] == "edge"


def test_the_controls_offer_exactly_the_choices_the_engine_knows():
    def options(ident):
        select = re.search(rf'<select id="{ident}">(.*?)</select>', BOX, re.S).group(1)
        return re.findall(r'<option value="([^"]*)"', select)

    assert options("bf-sort") == ["", *boardfilter.SORTS]
    assert options("bf-gstate") == ["", *boardfilter.STATES]
    assert options("bf-within") == ["", *boardfilter.WITHIN]
    for key, label in {**boardfilter.SORT_LABELS, **boardfilter.STATE_LABELS, **boardfilter.WITHIN_LABELS}.items():
        assert f'value="{key}">{label}</option>' in BOX, key


def test_the_panel_sits_on_the_arbitrage_page_and_every_control_has_its_id_read():
    panel = HTML[HTML.index('id="panel-board"'):HTML.index('id="panel-odds"')]
    assert 'id="bf-box"' in panel
    for ident in ("bf-sort", "bf-gstate", "bf-within", "bf-pmin", "bf-pmax", "bf-win", "bf-counts", "bf-leagues",
                  "bf-types", "bf-clear", "bf-state"):
        assert f'id="{ident}"' in BOX, ident
        assert f'"{ident}"' in CODE, ident
    assert "data-run" not in BOX, "a filter has no button that reads"


# ------------------------------------------------------------ changing a control reads nothing

def test_changing_a_control_starts_no_read_and_asks_the_engine_for_nothing():
    for fn in ("function bfChanged(", "function bfSet(", "function bfToggle(", "function clearBoardFilters(",
               "function drawBoardFilters("):
        body = _braced(CODE, fn)
        for call in ("run(", "invoke(", "fetch(", "await", "async", "setTimeout", "setInterval", "XMLHttpRequest"):
            assert call not in body, (fn, call)
    assert "const bf = bfBoard();" in _braced(CODE, "function bfChanged(")


def test_a_choice_is_answered_with_the_engines_count_and_the_engines_line_about_where_it_is_used():
    changed = _braced(CODE, "function bfChanged(")
    for part in ("bfChip(bf.state.options", "bfChip(bf.within.options", "bfChip(bf.price.min_chips",
                 "bfChip(bf.price.max_chips", "bfChip(bf.window.chips", "bf.sort.options.find", "bf.apply"):
        assert part in changed, part
    toggle = _braced(CODE, "function bfToggle(")
    assert "item.text_rec" in toggle and "item.text_all" in toggle and "bf.apply" in toggle
    chip = _braced(CODE, "function bfChip(")
    assert "c.text_rec" in chip and "c.text_all" in chip and "PRESET.on" in chip


def test_the_counts_follow_recommended_the_way_hide_under_does():
    for fn in ("function bfChips(", "function bfToggles("):
        body = _braced(CODE, fn)
        assert "PRESET.on ? " in body and "left_text_rec" in body and "left_text" in body, fn


def test_a_toggle_that_is_off_for_a_league_the_board_lacks_can_still_be_switched_on():
    toggles = _braced(CODE, "function bfToggles(")
    assert "not on this board" in toggles and "off.filter((k) => !here.has(k))" in toggles


# ------------------------------------------------------------ it reads only what the engine sends

def _engine_block():
    from test_board_filters import _mixed

    _, block = boardfilter.apply(_mixed(), boardfilter.parse(), 1_700_000_000.0)
    return block


def test_every_field_the_window_reads_from_the_block_is_one_the_engine_sends():
    block = _engine_block()
    top = set(re.findall(r"\bbf\.([a-z_]+)", CODE))
    assert top >= {"sorted_by", "sort", "state", "within", "price", "window", "leagues", "bet_types", "apply", "note",
                   "sentence", "empty_text", "undo", "empty_by_filters"} - {"sorted_by", "empty_by_filters"}
    assert top <= set(block), sorted(top - set(block))
    for group in ("state", "within", "price", "window", "sort", "undo"):
        read = set(re.findall(rf"\bbf\.{group}\.([a-z_]+)", CODE))
        assert read <= set(block[group]), (group, sorted(read - set(block[group])))
    assert set(re.findall(r"\bbf\.undo\.([a-z_]+)", CODE)) == {"label"}
    chip = block["state"]["options"][0]
    for name in set(re.findall(r"\bc\.([a-z_]+)", _braced(CODE, "function bfChips(") + _braced(CODE, "function bfChip("))):
        assert name in chip, name
    toggle = block["leagues"][0]
    for name in set(re.findall(r"\bi\.([a-z_]+)", _braced(CODE, "function bfToggles("))):
        assert name in toggle, name
    option = block["sort"]["options"][1]
    assert {"key", "label", "text"} <= set(option)


def test_the_boards_row_fields_the_window_reads_for_a_middles_window_are_sent():
    play = _braced(JS, "function boardPlay(")
    assert "r.window_text" in play
    from overlay_engine import board
    from overlay_engine.cli import DEFAULT_BOOKS, _demo_market

    sent = board.scan([_demo_market()], DEFAULT_BOOKS, now=cli.NOW, kinds=("arb",))[0].as_dict()
    assert "window_text" in sent and "start_epoch" in sent


def test_every_board_the_window_draws_keeps_the_engines_block():
    assert JS.count("bf: out.board_filters") == 3
    for show in ("function showBoard(", "function showOddsboard("):
        assert "board_filters" in _braced(JS, show), show
    assert "drawBoardFilters();" in _braced(JS, "function drawBoard(")


# ------------------------------------------------------------ clearing, and a board the filters emptied

def test_clear_filters_empties_these_controls_and_hide_under_and_leaves_recommended_alone():
    clear = _braced(CODE, "function clearBoardFilters(")
    for part in ('BF[k] = ""', "BF.leagues_off = [];", "BF.types_off = [];", 'document.getElementById("b-min").value = "0";',
                 "keepBF();"):
        assert part in clear, part
    for left_alone in ("PRESET", "setPreset", "askPreset", "b-preset", "hiddenFlags", "HIDDEN"):
        assert left_alone not in clear, left_alone
    assert 'id="bf-clear"' in BOX and "Clear filters" in BOX
    assert "Recommended stays as it is" in BOX


def test_a_board_the_filters_emptied_says_so_names_the_way_out_and_is_checked_before_a_hidden_one():
    empty = _braced(CODE, "function bfEmptyHTML(")
    assert "Board filters are leaving nothing on this board" in empty and "bf.empty_text" in empty
    assert "data-bf-clear" in empty and "bf.undo.label" in empty
    console = _braced(JS, "function consoleHTML(")
    assert console.index("if (bfEmptied()) return bfEmptyHTML();") < console.index("if (allHiddenByYou())")
    assert "All left out by Board filters" in _braced(JS, "function drawBoard(")


# ------------------------------------------------------------ words, and looks

def test_the_page_says_a_filter_reads_nothing_and_never_promises_more_than_a_play_does():
    text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", BOX))
    assert "Changing a filter reads nothing and spends no credit" in text
    assert "Find arbs or Read the odds" in text
    blob = (text + CODE).lower()
    for banned in ("guarantee", "risk-free", "risk free", "free bet", "either way"):
        assert banned not in blob, banned
    assert not re.search(r"\block(s|ed|ing)?\b", blob)


def test_every_class_the_filter_panel_draws_is_styled():
    for cls in ("bf-counts", "bf-toggles", "bf-tog", "fchip", "fc-row", "fc-k", "fchips", "fc-say"):
        assert re.search(rf"\.{cls}\b", CSS), cls
