"""Board filters: sort the board, and narrow it by price, game state, start time, league, bet type and a middle's window.

The engine does all of it (`boardfilter`), through new `board` flags. These pin:

  * each sort orders the way its sentence says, and a middle (which has no single return) comes after the plays that do;
  * a price range holds back +EV bets only, in American odds, and refuses what is not a price;
  * game state and the date range are judged from the start time the data carries, and a play with none is left out
    and counted, never guessed;
  * league and bet type are toggles that match without regard to case, and a toggle's own count ignores itself;
  * a smallest window holds back middles only, and a middle's window is the gap between its two lines;
  * every count the engine prints equals what the board really leaves when that choice is made (the whole point of
    saying how many plays a filter would leave before it is changed);
  * filtering is the last thing done: alerts, the hidden list, warnings, the counts and Recommended speak for every
    play the read found, so a filter can never make an old play look new on a later read;
  * a filter typed wrongly in the window is no filter and a sentence, on the command line a refusal;
  * nothing it says promises more than a play does.
"""

import contextlib
import dataclasses
import io
import json
import re
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

from overlay_engine import board, boardfilter, cli, feed  # noqa: E402
from overlay_engine.boardfilter import FilterError, Spec  # noqa: E402
from overlay_engine.cli import DEFAULT_BOOKS, _demo_market  # noqa: E402
from overlay_engine.models import Market, Outcome, Quote  # noqa: E402

NOW = 1_700_000_000.0


@pytest.fixture(autouse=True)
def throwaway_home(monkeypatch, tmp_path):
    """Never the real ~/.overlay."""
    monkeypatch.setenv("OVERLAY_HOME", str(tmp_path))
    return tmp_path


def play(kind="arb", league="NBA", market="totals", start=NOW + 3600, price=None, window=None, margin=0.02,
         profit=10.0, rec=True, label=None):
    """One play, as the board sends it."""
    row = {"kind": kind, "event": "g", "league": league, "market": market, "margin": margin, "profit": profit,
           "recommended": rec, "start_epoch": start,
           "legs": [{"book": "dk", "american": price if price is not None else -110}]}
    if window is not None:
        row["window_points"] = window
    if label:
        row["market_label"] = label
    return row


def spec(**kw):
    return boardfilter.parse(**kw)


def kept(views, **kw):
    order, _ = boardfilter.apply(views, spec(**kw), NOW)
    return order


# ------------------------------------------------------------ sort

def test_sort_by_return_is_dollars_largest_first_and_a_middle_comes_after_the_plays_that_have_one():
    views = [play("middle", profit=0.0, margin=0.30), play("arb", profit=5.0), play("ev", profit=9.0),
             play("arb", profit=7.0, margin=0.001)]
    assert kept(views, sort="return") == [2, 3, 1, 0]


def test_sort_by_edge_is_the_headline_percentage_and_the_two_sorts_disagree_where_they_should():
    views = [play("arb", profit=100.0, margin=0.01), play("ev", profit=5.0, margin=0.04),
             play("middle", profit=0.0, margin=0.50)]
    assert kept(views, sort="edge") == [1, 0, 2]
    assert kept(views, sort="return") == [0, 1, 2]
    assert kept(views, sort="edge") != kept(views, sort="return")


def test_sort_by_start_is_soonest_first_and_a_play_with_no_start_time_comes_last():
    views = [play(start=NOW + 9000), play(start=None), play(start=NOW + 100), play(start=NOW - 50)]
    assert kept(views, sort="start") == [3, 2, 0, 1]


def test_equal_plays_keep_the_boards_own_order():
    views = [play(profit=3.0), play(profit=3.0), play(profit=3.0)]
    for sort in boardfilter.SORTS:
        assert kept(views, sort=sort) == [0, 1, 2], sort


def test_no_sort_leaves_the_order_alone_and_says_nothing_was_sorted():
    views = [play(profit=1.0), play(profit=9.0)]
    order, block = boardfilter.apply(views, Spec(), NOW)
    assert order == [0, 1] and block["sorted_by"] is None and block["sentence"] == ""


# ------------------------------------------------------------ price range

def test_a_price_range_holds_back_ev_bets_outside_it_and_keeps_the_ends():
    views = [play("ev", price=-200), play("ev", price=-110), play("ev", price=+100), play("ev", price=+250)]
    assert kept(views, min_price="-110", max_price="+100") == [1, 2]
    assert kept(views, min_price="-200") == [0, 1, 2, 3]
    assert kept(views, max_price="249") == [0, 1, 2]


def test_a_price_range_never_holds_back_an_arb_or_a_middle():
    views = [play("arb", price=-500), play("middle", price=+900, window=3.0), play("ev", price=+900)]
    assert kept(views, min_price="-110", max_price="+200") == [0, 1]


def test_what_is_not_an_american_price_is_refused_in_a_sentence():
    for bad in ("-99", "0", "50", "99", "abc", "1.5", "nan", "inf", "-100000000"):
        with pytest.raises(FilterError, match="American price"):
            boardfilter.parse(min_price=bad)
    assert boardfilter.parse(min_price="-100").min_price == -100
    assert boardfilter.parse(min_price="+100").min_price == 100
    assert boardfilter.parse(min_price="  −150 ").min_price == -150
    assert boardfilter.parse(min_price="").min_price is None


def test_a_range_that_leaves_no_price_is_refused():
    with pytest.raises(FilterError, match="above"):
        boardfilter.parse(min_price="+200", max_price="-150")


# ------------------------------------------------------------ game state and date range

def test_game_state_is_the_start_time_against_the_moment_of_the_read():
    views = [play(start=NOW + 60), play(start=NOW - 60), play(start=NOW)]
    assert kept(views, state="not_started") == [0]
    assert kept(views, state="in_play") == [1, 2]


def test_a_play_with_no_start_time_is_in_neither_state_and_the_engine_counts_it():
    views = [play(start=None), play(start=NOW + 60)]
    assert kept(views, state="not_started") == [1]
    assert kept(views, state="in_play") == []
    _, block = boardfilter.apply(views, spec(state="not_started"), NOW)
    assert block["state"]["unknown"] == 1 and "no start time in the data" in block["state"]["sentence"]


def test_the_date_ranges_count_forward_from_the_read_and_a_game_under_way_is_in_none_of_them():
    views = [play(start=NOW - 10), play(start=NOW + 3599), play(start=NOW + 3601), play(start=NOW + 86400 - 1),
             play(start=NOW + 86400 + 1), play(start=NOW + 7 * 86400), play(start=NOW + 7 * 86400 + 1)]
    assert kept(views, within="hour") == [1]
    assert kept(views, within="24h") == [1, 2, 3]
    assert kept(views, within="7d") == [1, 2, 3, 4, 5]
    assert kept([play(start=None)], within="7d") == []


def test_today_runs_midnight_to_midnight_on_this_macs_clock(monkeypatch):
    monkeypatch.setenv("TZ", "America/New_York")
    time.tzset()
    try:
        now = time.mktime((2026, 10, 31, 15, 0, 0, 0, 0, -1))
        midnight = time.mktime((2026, 11, 1, 0, 0, 0, 0, 0, -1))
        views = [play(start=now - 6 * 3600), play(start=midnight - 1), play(start=midnight),
                 play(start=now - 15 * 3600 - 1)]
        order, _ = boardfilter.apply(views, spec(within="today"), now)
        assert order == [0, 1], "this morning's game is today's; midnight itself is tomorrow's"
    finally:
        monkeypatch.undo()
        time.tzset()


# ------------------------------------------------------------ league and bet type

def test_a_league_off_leaves_it_out_without_regard_to_case_and_the_rest_stay():
    views = [play(league="NBA"), play(league="NFL"), play(league="College basketball")]
    assert kept(views, leagues_off=["nba"]) == [1, 2]
    assert kept(views, leagues_off=["NBA", " college BASKETBALL "]) == [1]


def test_a_bet_type_off_matches_the_key_or_the_label():
    views = [play(market="totals"), play(market="h2h"), play(market="player_points", label="Player points")]
    assert kept(views, bet_types_off=["totals"]) == [1, 2]
    assert kept(views, bet_types_off=["Moneyline"]) == [0, 2]
    assert kept(views, bet_types_off=["player points"]) == [0, 1]


def test_a_toggle_counts_the_plays_it_governs_whatever_its_own_state():
    views = [play(league="NBA"), play(league="NBA"), play(league="NFL")]
    _, block = boardfilter.apply(views, spec(leagues_off=["NBA"]), NOW)
    counts = {t["label"]: (t["on"], t["count"]) for t in block["leagues"]}
    assert counts == {"NBA": (False, 2), "NFL": (True, 1)}
    assert block["left"] == 1


def test_a_league_the_board_does_not_carry_is_kept_in_the_spec_and_harms_nothing():
    assert kept([play(league="NBA")], leagues_off=["MLB"]) == [0]


# ------------------------------------------------------------ a middle's window

def test_a_smallest_window_holds_back_small_middles_only():
    views = [play("middle", window=1.0), play("middle", window=2.0), play("middle", window=3.5),
             play("arb"), play("ev", price=+120), play("middle", window=None)]
    assert kept(views, min_window="2") == [1, 2, 3, 4]
    assert kept(views, min_window="3.5") == [2, 3, 4]


def test_a_window_must_be_a_number_of_points_above_nothing():
    for bad in ("0", "-1", "abc", "nan", "inf", "1000"):
        with pytest.raises(FilterError, match="points"):
            boardfilter.parse(min_window=bad)
    assert boardfilter.parse(min_window=" 2 ").min_window == 2.0


def test_a_middles_window_is_the_gap_between_its_two_lines():
    def q(book, name, line):
        return Quote(book=book, outcome=Outcome(name=name, line=line), decimal=1.91, seen_at=NOW - 5)

    market = Market(event_id="nba_2026_bos_lal", sport="basketball_nba", market_type="totals", starts_at=NOW + 3600,
                    quotes=[q("dk", "over", 220.5), q("dk", "under", 220.5), q("fd", "over", 223.5),
                            q("fd", "under", 223.5)])
    rows = board.scan([market], DEFAULT_BOOKS, now=NOW, kinds=("middle",))
    assert [r.window_points for r in rows] == [3.0]
    sent = rows[0].as_dict()
    assert sent["window_points"] == 3.0 and sent["window_text"] == "3-point window"
    assert sent["start_epoch"] == NOW + 3600
    arb = board.scan([_demo_market()], DEFAULT_BOOKS, now=NOW, kinds=("arb",))[0].as_dict()
    assert arb["window_points"] is None and arb["window_text"] == ""


# ------------------------------------------------------------ counts

def _mixed():
    return [
        play("arb", league="NBA", start=NOW + 1800, profit=12.0, margin=0.02),
        play("arb", league="NFL", start=NOW - 600, profit=4.0, margin=0.005, market="h2h"),
        play("ev", league="NBA", start=NOW + 90000, price=-150, profit=3.0, margin=0.04, rec=False),
        play("ev", league="NHL", start=NOW + 5000, price=+180, profit=2.0, margin=0.06),
        play("ev", league="NFL", start=None, price=+240, profit=1.0, margin=0.03, market="spreads"),
        play("middle", league="NBA", start=NOW + 700000, window=1.0, margin=0.08, profit=0.0, rec=False),
        play("middle", league="NHL", start=NOW + 4000, window=4.0, margin=0.11, profit=0.0),
    ]


def _chip_specs(block, base):
    """Every count the engine printed, with the spec that choosing it makes."""
    for chip in block["state"]["options"]:
        yield chip, dataclasses.replace(base, state=chip["key"] or None)
    for chip in block["within"]["options"]:
        yield chip, dataclasses.replace(base, within=chip["key"] or None)
    for chip in block["price"]["min_chips"]:
        yield chip, dataclasses.replace(base, min_price=int(chip["key"]) if chip["key"] else None)
    for chip in block["price"]["max_chips"]:
        yield chip, dataclasses.replace(base, max_price=int(chip["key"]) if chip["key"] else None)
    for chip in block["window"]["chips"]:
        yield chip, dataclasses.replace(base, min_window=float(chip["key"]) if chip["key"] else None)


def test_every_count_the_engine_prints_is_what_the_board_really_leaves():
    views = _mixed()
    for base in (Spec(), spec(state="not_started"), spec(leagues_off=["NFL"], min_price="-200"),
                 spec(within="7d", bet_types_off=["totals"])):
        _, block = boardfilter.apply(views, base, NOW)
        seen = 0
        for chip, chosen in _chip_specs(block, base):
            order, _ = boardfilter.apply(views, chosen, NOW)
            assert chip["all"] == len(order), (base, chip["label"])
            assert chip["rec"] == sum(1 for i in order if views[i]["recommended"]), (base, chip["label"])
            assert chip["left_text"] == f"{chip['all']} left" and chip["left_text_rec"] == f"{chip['rec']} left"
            assert str(chip["all"]) in chip["text_all"] and str(chip["rec"]) in chip["text_rec"]
            seen += 1
        assert seen >= 20, "the chips were not walked"


def test_a_toggles_count_is_the_plays_it_governs_that_pass_every_other_filter():
    views = _mixed()
    base = spec(state="not_started", leagues_off=["NBA"])
    _, block = boardfilter.apply(views, base, NOW)
    for item in block["leagues"]:
        want = [i for i, v in enumerate(views) if v["league"] == item["label"]]
        other = dataclasses.replace(base, leagues_off=frozenset())
        order, _ = boardfilter.apply([views[i] for i in want], other, NOW)
        assert item["count"] == len(order), item["label"]
        assert item["count_rec"] == sum(1 for i in order if views[want[i]]["recommended"])


def test_the_board_says_how_many_it_left_of_how_many_and_when_it_left_nothing():
    views = _mixed()
    order, block = boardfilter.apply(views, spec(state="in_play"), NOW)
    assert block["total"] == 7 and block["left"] == len(order) == 1
    assert block["sentence"] == "Board filters leave 1 of 7 plays."
    assert block["empty_by_filters"] is False
    order, block = boardfilter.apply(views, spec(leagues_off=["NBA", "NFL", "NHL"]), NOW)
    assert order == [] and block["empty_by_filters"] is True
    assert "leave nothing" in block["empty_text"] and "7 plays" in block["empty_text"]
    order, block = boardfilter.apply([], spec(state="in_play"), NOW)
    assert block["empty_by_filters"] is False, "an empty board is not one the filters emptied"


def test_the_apply_line_says_nothing_is_read_and_the_notes_say_who_is_held_to_what():
    _, block = boardfilter.apply(_mixed(), Spec(), NOW)
    assert "Nothing is read until you do" in block["apply"]
    assert "spends no credit" in block["note"]
    assert "Only +EV bets" in block["price"]["note"] and "Only middles" in block["window"]["note"]
    assert "In play finds plays only among Live prices pairs and recorded snapshots" in block["state"]["note"]
    assert block["price"]["applies_to"] == 3 and block["window"]["applies_to"] == 2


def test_nothing_the_engine_says_promises_more_than_a_play_does():
    blob = []
    for sp in (Spec(), spec(sort="edge", state="in_play", within="today", min_price="-150", max_price="+200",
                            leagues_off=["NBA"], bet_types_off=["totals"], min_window="2")):
        _, block = boardfilter.apply(_mixed(), sp, NOW)
        blob.append(json.dumps(block).lower())
    text = " ".join(blob)
    for banned in ("guarantee", "risk-free", "risk free", "free bet", "either way"):
        assert banned not in text, banned
    assert not re.search(r"\block(s|ed|ing)?\b", text), "lock"


def test_a_problem_is_said_and_the_board_is_not_narrowed():
    order, block = boardfilter.apply(_mixed(), Spec(), NOW, problem="--min-price needs an American price like -150.")
    assert order == list(range(7)) and block["enabled"] is False
    assert block["error"] in block["sentence"] and "without board filters" in block["sentence"]


# ------------------------------------------------------------ the command

def _snapshot(path):
    """Three games in three leagues: one under way, one tonight, one in three days; plus a middle with no start."""
    def copy(event, sport, starts):
        base = _demo_market()
        return Market(event_id=event, sport=sport, market_type="totals", starts_at=starts, quotes=base.quotes)

    def q(book, name, line):
        return Quote(book=book, outcome=Outcome(name=name, line=line), decimal=1.91, seen_at=cli.NOW - 6)

    middle = Market(event_id="nhl_2026_bos_nyr", sport="icehockey_nhl", market_type="totals", starts_at=None,
                    quotes=[q("dk", "over", 5.5), q("dk", "under", 5.5), q("fd", "over", 8.5), q("fd", "under", 8.5)])
    feed.write_snapshot(path, [
        copy("nba_2026_bos_lal", "basketball_nba", cli.NOW - 1800),
        copy("nfl_2026_buf_mia", "americanfootball_nfl", cli.NOW + 7200),
        copy("mlb_2026_nyy_bos", "baseball_mlb", cli.NOW + 3 * 86400), middle], fetched_at=cli.NOW)


def _board(tmp_path, *argv, text=False):
    snap = tmp_path / "snap.json"
    if not snap.exists():
        _snapshot(snap)
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        code = cli.main(["board", "--snapshot", str(snap), *argv] + ([] if text else ["--json"]))
    return code, (out.getvalue() if text else json.loads(out.getvalue()))


def test_the_command_narrows_and_sorts_a_recorded_board_and_sends_the_rest_of_the_answer_whole(tmp_path):
    code, whole = _board(tmp_path)
    assert code == 0 and len(whole["rows"]) >= 6
    code, out = _board(tmp_path, "--game-state", "not_started", "--sort", "start", "--league-off", "mlb")
    assert code == 0
    starts = [r["start_epoch"] for r in out["rows"]]
    assert starts and starts == sorted(starts) and all(s > cli.NOW - 7 for s in starts)
    assert {r["league"] if "league" in r else r["sport"] for r in out["rows"]} == {"americanfootball_nfl"}
    assert out["board_filters"]["sorted_by"] == "start"
    assert out["board_filters"]["total"] == len(whole["rows"])
    assert out["board_filters"]["left"] == len(out["rows"])
    # Every other part of the answer speaks for every play the read found.
    for key in ("filters", "warnings", "preset"):
        assert out[key] == whole[key], key
    assert {json.dumps(r, sort_keys=True) for r in out["rows"]} <= {json.dumps(r, sort_keys=True) for r in whole["rows"]}


def test_the_filters_name_leagues_the_way_the_board_does_and_the_demonstration_agrees(tmp_path):
    _, out = _board(tmp_path)
    assert [t["label"] for t in out["board_filters"]["leagues"]] == ["MLB", "NBA", "NFL", "NHL"]
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        cli.main(["board", "--json"])
    assert [t["label"] for t in json.loads(out.getvalue())["board_filters"]["leagues"]] == ["NBA"]


def test_the_board_always_carries_its_filter_block_even_with_no_filter(tmp_path):
    _, out = _board(tmp_path)
    block = out["board_filters"]
    assert block["active"] is False and block["sorted_by"] is None and block["left"] == block["total"]
    assert block["sentence"] == "" and block["enabled"] is True


def test_a_smallest_window_on_the_command_holds_back_only_the_small_middles(tmp_path):
    _, out = _board(tmp_path, "--kind", "middle", "--min-window", "2")
    assert [r["window_points"] for r in out["rows"]] == [3.0]
    _, out = _board(tmp_path, "--kind", "middle", "--min-window", "3.5")
    assert out["rows"] == [] and out["board_filters"]["empty_by_filters"] is True
    _, out = _board(tmp_path, "--min-window", "3.5", "--kind", "arb")
    assert out["rows"], "arbs have no window and are not held to one"


def test_a_filter_typed_wrongly_is_a_sentence_in_the_window_and_a_refusal_on_the_command_line(tmp_path):
    code, whole = _board(tmp_path)
    code, out = _board(tmp_path, "--min-price=-50")
    assert code == 0 and out["rows"] == whole["rows"]
    assert out["board_filters"]["enabled"] is False and "American price" in out["board_filters"]["sentence"]
    err = io.StringIO()
    with contextlib.redirect_stderr(err):
        code, _ = _board(tmp_path, "--min-price=-50", text=True)
    assert code == 2 and "American price" in err.getvalue()


def test_the_filters_cannot_be_combined_with_a_read_that_has_no_board(tmp_path):
    for flags in (["--estimate"], ["--screen"], ["--lowhold"], ["--futures"], ["--alt-stored"]):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = cli.main(["board", "--feed", "oddsapi", "--sort", "edge", *flags, "--json"])
        assert code == 2, flags
        assert "work on the board of plays" in json.loads(out.getvalue())["error"], flags


def test_the_printed_board_says_what_the_filters_left(tmp_path):
    code, text = _board(tmp_path, "--game-state", "in_play", text=True)
    assert code == 0 and "Board filters leave" in text and "of" in text
    code, text = _board(tmp_path, "--league-off", "NBA", "--league-off", "NFL", "--league-off", "MLB",
                        "--league-off", "NHL", text=True)
    assert "Your board filters left nothing" in text and "normal state of a small board" not in text


def test_a_live_pair_is_filtered_by_its_own_start_and_its_league():
    pairs = [{"league": "nfl", "game": "A vs B", "margin": 0.02, "profit": 9.0, "starts_at": NOW - 100,
              "in_play": True, "legs": [{"venue": "kalshi"}], "recommended": True},
             {"league": "nba", "game": "C vs D", "margin": 0.03, "profit": 4.0, "starts_at": NOW + 600,
              "in_play": False, "legs": [{"venue": "kalshi"}], "recommended": True},
             {"league": "nhl", "game": "E vs F", "margin": 0.01, "profit": 2.0, "starts_at": None, "in_play": False,
              "legs": [{"venue": "kalshi"}], "recommended": True}]
    order, block = boardfilter.apply(pairs, spec(state="in_play"), NOW)
    assert order == [0]
    order, _ = boardfilter.apply(pairs, spec(state="not_started", sort="edge"), NOW)
    assert order == [1]
    order, block = boardfilter.apply(pairs, spec(sort="edge"), NOW)
    assert order == [1, 0, 2]
    assert [t["label"] for t in block["leagues"]] == ["NBA", "NFL", "NHL"]
    assert block["state"]["unknown"] == 1


# ------------------------------------------------------------ a read of live sportsbook odds

@pytest.fixture()
def live(monkeypatch):
    """The engine's board on the tests' fake Odds API and fake Keychain, as the window gets it."""
    from types import SimpleNamespace

    import test_keystore as tk
    import test_oddsapi as to
    from overlay_engine import keystore, oddsapi

    monkeypatch.setattr(keystore, "_available", lambda: None)
    monkeypatch.setattr(keystore.subprocess, "run", tk.FakeSecurity())
    monkeypatch.setattr(oddsapi, "odds_api_fetcher", lambda *a, **k: to.FakeApi())
    monkeypatch.setattr(oddsapi, "time", SimpleNamespace(time=to.Clock()))

    def call(*argv, stdin=""):
        out = io.StringIO()
        stream = io.StringIO(stdin)
        stream.isatty = lambda: False
        old, cli.sys.stdin = cli.sys.stdin, stream
        try:
            with contextlib.redirect_stdout(out):
                code = cli.main(list(argv))
        finally:
            cli.sys.stdin = old
        return code, json.loads(out.getvalue())

    call("key", "set", "--json", stdin=to.KEY)
    return lambda *argv: call("board", "--feed", "oddsapi", "--sport", "nfl", *argv, "--json")


def test_a_read_of_sportsbook_odds_is_narrowed_last_and_leaves_every_other_block_whole(live):
    code, whole = live()
    assert code == 0 and whole["rows"], "the fake read has plays on it"
    code, out = live("--sort", "edge", "--within", "7d", "--min-price=-1000")
    assert code == 0
    assert len(out["rows"]) <= len(whole["rows"]) and out["board_filters"]["total"] == len(whole["rows"])
    margins = [r["margin"] for r in out["rows"] if r["kind"] != "middle"]
    assert margins == sorted(margins, reverse=True)
    for key in ("filters", "warnings", "preset"):
        assert out[key] == whole[key], key
    assert all(r["league"] == "NFL" for r in out["rows"])
    # The row still carries the feed's own start text, and the engine's epoch beside it.
    assert all(isinstance(r["starts_at"], str) and isinstance(r["start_epoch"], float) for r in out["rows"])


def test_a_read_of_sportsbook_odds_leaves_games_under_way_off_so_in_play_finds_none_and_says_why(live):
    _, out = live("--game-state", "in_play")
    assert out["rows"] == []
    block = out["board_filters"]
    assert block["empty_by_filters"] is True and "leaves games already under way off the board" in block["state"]["note"]
    _, started = live("--game-state", "not_started")
    _, whole = live()
    assert started["rows"] == whole["rows"]


def test_a_league_or_a_bet_type_switched_off_empties_the_read_and_says_so(live):
    _, out = live("--league-off", "nfl")
    assert out["rows"] == [] and out["board_filters"]["empty_by_filters"] is True
    assert [t["on"] for t in out["board_filters"]["leagues"]] == [False]
    _, whole = live()
    types = sorted({r["market"] for r in whole["rows"]})
    _, out = live(*[a for t in types for a in ("--bet-type-off", t)])
    assert out["rows"] == []


def test_filters_never_change_what_alerts_remember_about_a_read(live):
    """A narrowed read must record every play it found. If it recorded only the plays it drew, the next read would
    announce them all as new."""
    setting = json.dumps({"min_ev": 0.0, "min_arb": 0.0, "kinds": ["arb", "ev", "middle"], "recommended_only": False})
    _, first = live(f"--alerts={setting}")
    assert first["alerts"]["first_read"] is True
    _, narrowed = live(f"--alerts={setting}", "--league-off", "NFL")
    assert narrowed["rows"] == [] and narrowed["alerts"]["first_read"] is False and narrowed["alerts"]["new"] == 0
    _, again = live(f"--alerts={setting}")
    assert again["rows"] and again["alerts"]["new"] == 0 and not again["alerts"]["message"]
    assert not any(r.get("alert") for r in again["rows"])


def test_live_prices_pairs_are_filtered_in_the_answer_and_the_block_rides_beside_cross_venue(monkeypatch):
    from overlay_engine import pubfeed
    from test_xvenue import arb_world

    def run(*argv):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = cli.main(["board", "--live", "--state", "PA", *argv, "--json"])
        return code, json.loads(out.getvalue())

    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _, whole = run()
    [pair] = whole["cross_venue"]["pairs"]
    assert whole["board_filters"]["total"] == 1 and whole["board_filters"]["left"] == 1
    assert [t["label"] for t in whole["board_filters"]["leagues"]] == [pair["league"].upper()]
    monkeypatch.setattr(pubfeed, "urllib_fetcher", arb_world())
    _, narrowed = run("--league-off", pair["league"])
    assert narrowed["cross_venue"]["pairs"] == [] and narrowed["board_filters"]["empty_by_filters"] is True
    # Everything else the read said is as it was.
    for key in ("warnings", "hidden"):
        assert narrowed[key] == whole[key], key
    assert narrowed["cross_venue"]["filters"] == whole["cross_venue"]["filters"]
