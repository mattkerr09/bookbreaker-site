"""Odds for each side on the Low hold tab (the AVO bar's item 4): the lowest and highest price the bet at the credit
book may have, and the same for the other bet (both bets, with no credit book).

What is pinned: a limit picks the cheapest pair INSIDE it (checked against a brute force), it never just drops the
row the unlimited search found; a credit-book limit holds only the leg at that book; the markets a limit leaves out
are counted and said; a limit that cannot work is one sentence and exit 2; and the window passes the flags and
draws the engine's sentence.
"""
import itertools
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

import test_lowhold_view as lv  # noqa: E402
from overlay_engine import cli, lowholdview  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
home = lv.home

#: Decimal prices (home, away). Unlimited, the cheapest pair is FanDuel's home 1.98 with BetMGM's away 1.97.
ML2 = {"draftkings": (1.95, 1.93), "fanduel": (1.98, 1.85), "betmgm": (1.85, 1.97), "caesars": (1.90, 1.96),
       "pinnacle": (2.10, 2.10)}


def read2(ml=ML2):
    lv.read(payload=lv.tp.only(lv.world(ml=ml), "h2h"))


def brute(ml, ok, credit=None):
    """The cheapest cross-book pair whose legs pass ok(book_key, decimal), by plain enumeration."""
    books = [b for b in ml if lv.KEY[b] in lv.BETTABLE]
    best = None
    for h, a in itertools.permutations(books, 2):
        kh, ka = lv.KEY[h], lv.KEY[a]
        if credit and credit not in (kh, ka):
            continue
        if not (ok(kh, ml[h][0]) and ok(ka, ml[a][1])):
            continue
        hold = 1 / ml[h][0] + 1 / ml[a][1] - 1
        if best is None or hold < best[0] - 1e-12:
            best = (hold, kh, ka)
    return best


def limits(credit="", **kw):
    return lowholdview.Limits(credit, kw.get("cmin"), kw.get("cmax"), kw.get("omin"), kw.get("omax"))


def test_without_limits_nothing_changes(home):
    read2()
    plain, empty = lv.view(), lv.view(limits=limits())
    assert plain["rows"] == empty["rows"] and empty["limits_text"] == "" and empty["left_out_by_limits"] == 0


def test_a_limit_picks_the_cheapest_pair_inside_it_not_just_drops_the_cheapest(home):
    read2()
    free = lv.view()["rows"][0]
    assert {l["book"] for l in free["legs"]} == {"fd", "mgm"}
    v = lv.view(limits=limits(omax="-103"))              # 1.9709 or shorter: FanDuel's 1.98 is out
    hold, kh, ka = brute(ML2, lambda b, d: d <= 1.9709 + 1e-9)
    row = v["rows"][0]
    assert row["hold"] == pytest.approx(hold, abs=1e-6)
    assert {l["label"]: l["book"] for l in row["legs"]} == {lv.HOME: kh, lv.AWAY: ka}
    assert all(l["decimal"] <= 1.9709 + 1e-9 for l in row["legs"])


def test_with_no_credit_book_the_other_limit_holds_both_bets(home):
    read2()
    row = lv.view(limits=limits(omin="-104"))["rows"][0]   # 1.9615 or longer, on both bets
    assert all(l["decimal"] >= 1.9615 - 1e-9 for l in row["legs"])


def test_a_credit_book_limit_holds_only_the_bet_at_that_book(home):
    read2()
    v = lv.view(credit_book="dk", amount=500, limits=limits("dk", cmax="-107"))   # 1.9346 or shorter at DraftKings
    hold, kh, ka = brute(ML2, lambda b, d: b != "dk" or d <= 1.9346 + 1e-9, credit="dk")
    row = v["rows"][0]
    assert row["hold"] == pytest.approx(hold, abs=1e-6)
    credit_leg = next(l for l in row["legs"] if l["credit"])
    other = next(l for l in row["legs"] if not l["credit"])
    assert credit_leg["book"] == "dk" and credit_leg["decimal"] == pytest.approx(1.93) and credit_leg["stake"] == 500
    assert other["decimal"] > 1.9346, "the other bet is not held to the credit book's limit"
    assert "the bet at DraftKings is at -107 or shorter" in v["limits_text"]


def test_what_a_limit_leaves_out_is_counted_and_said(home):
    lv.read()                                           # the plain world: only FanDuel's 1.98 makes a cheap pair
    v = lv.view(limits=limits(omax="-105"))
    assert v["shown"] == 0 and v["left_out_by_limits"] == 1
    assert "Your odds limits leave nothing: 1 two-way market" in v["message"]
    assert "each bet is at -105 or shorter" in v["limits_text"] and "left out 1 market" in v["limits_text"]


@pytest.mark.parametrize("credit,kw,words", [
    ("", {"cmin": "-200"}, "need a credit book"),
    ("dk", {"cmin": "+150", "cmax": "-110"}, "above the highest"),
    ("", {"omin": "+200", "omax": "+100"}, "above the highest"),
    ("", {"omax": "lots"}, "is not a price"),
])
def test_a_limit_that_cannot_work_is_refused_in_a_sentence(credit, kw, words):
    with pytest.raises(lowholdview.LowHoldError, match=words):
        limits(credit, **kw)


def test_the_command_takes_the_flags_and_refuses_them_elsewhere(home, capsys):
    read2()
    assert cli.main(["board", "--feed", "oddsapi", "--lowhold", "--other-max=-103", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)["lowhold"]
    assert out["limits"]["other_max"] == "-103" and out["shown"] == 1
    assert cli.main(["board", "--feed", "oddsapi", "--lowhold", "--credit-min=-200", "--json"]) == 2
    assert "need a credit book" in json.loads(capsys.readouterr().out)["error"]
    assert cli.main(["board", "--other-min=-200", "--json"]) == 2
    assert "only work with --lowhold" in capsys.readouterr().out


def test_the_words_never_promise(home):
    read2()
    t = lv.view(credit_book="dk", limits=limits("dk", cmin="-200", omax="+150"))["limits_text"]
    assert t and not any(b in t.lower() for b in lv.BANNED) and not re.search(r"\bwin\b|\block\b", t, re.I)


def test_the_window_passes_the_limits_and_draws_the_engines_sentence():
    js = (ROOT / "ui" / "src" / "app.js").read_text()
    html = (ROOT / "ui" / "src" / "index.html").read_text()
    for fid, flag in (("lh-cmin", "--credit-min"), ("lh-cmax", "--credit-max"), ("lh-omin", "--other-min"),
                      ("lh-omax", "--other-max")):
        assert f'id="{fid}"' in html
        assert f'...(val("{fid}") ? [`{flag}=${{val("{fid}")}}`] : [])' in js, "one token, so a minus price is a value"
    assert "esc(s.limits_text)" in js
