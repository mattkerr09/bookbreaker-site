"""Convert my own promo, in the window: wired, honest, and drawn from what the engine sends.

The engine's arithmetic and its labels are in tests/test_promoconv.py. These pin what the
window may do with them: ask for the right things, draw only fields the engine really sends,
compute nothing of its own, label an average as an average, and keep the verb that reaches
the engine on the shell's list.
"""

import re
from pathlib import Path

import pytest

from overlay_engine import oddsapi, promoconv
from promo_fixtures import NOW, h2h, history

UI = Path(__file__).resolve().parent.parent / "ui"
HTML = (UI / "src" / "index.html").read_text()
JS = (UI / "src" / "app.js").read_text()
CSS = (UI / "src" / "app.css").read_text()
RUST = (UI / "src-tauri" / "src" / "main.rs").read_text()

BLOCK = JS[JS.index("/* ------------------------------------------------------------ convert my own promo"):
           JS.index("/* ------------------------------------------------------------ arbitrage")]
PANEL = HTML[HTML.index('id="panel-convert"'):HTML.index('id="panel-results"')]


def _answers(tmp_path):
    """The engine's answer for each promo type, with a recorded read and without one."""
    hist = history(tmp_path, [h2h("e1", dk=(4.0, 1.25), fd=(3.6, 1.30))])
    for h in (hist, tmp_path / "none"):
        yield promoconv.convert("bonus_bet", "dk", 100.0, history=h, now=NOW)
        yield promoconv.convert("refund", "dk", 100.0, history=h, now=NOW)
        yield promoconv.convert("boost", "dk", 50.0, boost_pct=50.0, history=h, now=NOW)
        yield promoconv.convert("boost", "dk", 50.0, boost_pct=2.0, history=h, now=NOW)
        yield promoconv.convert("deposit_match", "", 500.0, match_pct=100.0, rollover=10.0, history=h, now=NOW)


# ------------------------------------------------------------ where it is, and what it sends

def test_the_page_is_a_second_tab_of_promos_and_promos_still_opens_on_welcome_offers():
    assert re.search(r'<nav class="subnav" data-section="promos"[^>]*>.*?data-panel="convert".*?</nav>', HTML, re.S)
    assert 'id="panel-convert" data-section="promos"' in HTML
    assert re.search(r'<button class="nav[^"]*" data-section="promos" data-panel="welcome"', HTML)
    assert "Convert my own promo" in HTML


def test_pressing_convert_sends_the_promo_verb_with_each_number_as_one_token():
    builder = re.search(r"\n    promo: \(\) => \[(.*?)\],\n  \}\[kind\]\(\);", JS, re.S).group(1)
    assert builder.lstrip().startswith('"promo"')
    for flag in ("--type=", "--book=", "--amount=", "--boost=", "--max-win=", "--match=", "--rollover="):
        assert flag in builder, flag
    assert '"--amount", ' not in builder, "a value that starts with '-' would be read as an option"
    # Only what the chosen type shows is sent.
    assert 'val("pc-type") === "boost"' in builder and 'val("pc-type") === "deposit_match"' in builder
    assert 'val("pc-maxwin") ?' in builder, "an empty max winnings is not sent"


def test_every_promo_field_in_the_form_is_read_and_shown_for_the_right_type():
    fields = re.findall(r'<input id="(pc-[a-z]+)"', PANEL)
    assert set(fields) == {"pc-amount", "pc-boost", "pc-maxwin", "pc-match", "pc-roll"}
    for f in fields:
        assert f'val("{f}")' in JS
    shown = {}
    for types, body in re.findall(r'<label class="fld" data-pc="([a-z_ ]+)">(.*?)</label>', PANEL, re.S):
        for f in re.findall(r'<input id="(pc-[a-z]+)"', body):
            shown[f] = types
    assert shown == {"pc-boost": "boost", "pc-maxwin": "boost", "pc-match": "deposit_match", "pc-roll": "deposit_match"}
    # The book is chosen for every type except a deposit match, which is not hedged at a book.
    assert re.search(r'data-pc="bonus_bet refund boost">Sportsbook<select id="pc-book"', PANEL)


def test_the_type_menu_offers_exactly_the_four_promos_the_engine_prices():
    menu = re.search(r'<select id="pc-type">(.*?)</select>', PANEL, re.S).group(1)
    assert set(re.findall(r'value="([a-z_]+)"', menu)) == set(promoconv.KINDS)


def test_the_book_menu_is_books_the_engine_can_pair_and_each_exactly_once():
    menu = re.search(r'<select id="pc-book">(.*?)</select>', PANEL, re.S).group(1)
    keys = re.findall(r'value="([a-z_]*)"', menu)
    assert keys[0] == "" and len(keys) == len(set(keys))
    assert set(keys[1:]) <= set(oddsapi.BETTABLE)
    # Hard Rock's four state keys are one book in the menu; every other bettable book is there.
    families = {("hardrockbet" if k.startswith("hardrockbet") else k) for k in oddsapi.BETTABLE}
    assert set(keys[1:]) == families
    assert "pc-book" in BLOCK or 'val("pc-book")' in JS


def test_the_page_runs_nothing_until_convert_is_pressed():
    """Other panels read when first shown. This one has nothing to read until the person
    says which promo they hold, and a default promo drawn on arrival would be an answer to a
    question nobody asked."""
    body = JS[JS.index("function prime(kind)"):]
    body = body[:body.index("\n}\n")]
    assert 'button.dataset.run !== "promo"' in body
    assert "convert" not in JS[JS.index("show(\"ask\");"):JS.index("show(\"ask\");") + 20]


def test_the_shell_lets_the_window_run_promo_and_nothing_else_new():
    allowed = re.search(r'const ALLOWED: \[&str; (\d+)\] = \[([^\]]+)\]', RUST)
    verbs = re.findall(r'"([a-z-]+)"', allowed.group(2))
    assert int(allowed.group(1)) == len(verbs) == 22 and "promo" in verbs
    assert "lab" not in verbs and "edges" not in verbs


# ------------------------------------------------------------ it draws; it does not compute

def test_the_window_reads_only_fields_the_engine_sends(tmp_path):
    answers = list(_answers(tmp_path))
    sent_top = set().union(*(a.keys() for a in answers))
    sent_worth = set().union(*(a["worth"].keys() for a in answers))
    sent_outcome = set().union(*(o.keys() for a in answers for o in a["outcomes"]))
    sent_pair = set().union(*(a["pair"].keys() for a in answers if a["pair"]))
    sent_leg = set().union(*(a["pair"][k].keys() for a in answers if a["pair"] for k in ("promo", "hedge") if a["pair"][k]))

    def reads(var, text=BLOCK):
        return set(re.findall(rf"\b{var}\.([a-z_]+)", text))

    show = BLOCK[BLOCK.index("function showPromo"):]
    assert reads("out", show) >= {"worth", "outcomes", "pair", "assumptions", "notes", "book", "book_name", "type_name", "amount"}
    assert reads("out", BLOCK) <= sent_top, f"read but never sent: {sorted(reads('out') - sent_top)}"
    assert reads("w", show) == {"locked", "amount", "caption"} <= sent_worth
    assert reads("o", BLOCK[BLOCK.index("function pcOutcome"):BLOCK.index("function pcPair")]) >= {
        "from_promo", "from_hedge", "from_refund", "kept", "name", "note"}
    assert reads("o", BLOCK) <= sent_outcome
    pair_fn = BLOCK[BLOCK.index("function pcPair"):BLOCK.index("function pcMatch")]
    assert reads("p", pair_fn) <= sent_pair, f"read but never sent: {sorted(reads('p', pair_fn) - sent_pair)}"
    leg_fn = BLOCK[BLOCK.index("function pcLeg"):BLOCK.index("function pcOutcome")]
    assert reads("leg", leg_fn) >= {"book", "stake", "side", "american", "bonus", "book_name"}
    assert reads("leg", leg_fn) <= sent_leg
    match = next(a for a in answers if a["type"] == "deposit_match")
    match_fn = BLOCK[BLOCK.index("function pcMatch"):BLOCK.index("function showPromo")]
    assert reads("out", match_fn) <= set(match), f"read but never sent: {sorted(reads('out', match_fn) - set(match))}"


def test_the_window_computes_nothing_for_a_promo():
    for call in ("Math.round", "Math.max", "Math.min", "Math.floor", "Math.ceil", ".toFixed", ".reduce(", "parseFloat", "Number("):
        assert call not in BLOCK, call
    # No operator touches a number the engine sent. The one sum is a time of day: the start epoch in milliseconds.
    bare = re.sub(r"/\*.*?\*/", "", BLOCK, flags=re.S)
    on_a_field = re.findall(r"\b(?:out|w|o|p|leg)\.[a-z_]+\s*[-+*/]\s*[\w(]+", bare)
    assert on_a_field == ["p.starts * 1000"], on_a_field


def test_an_average_is_drawn_as_an_average_and_a_locked_amount_only_when_the_engine_says_it_is():
    show = BLOCK[BLOCK.index("function showPromo"):]
    assert '<div class="promo-big${w.locked ? "" : " ev"}">' in show
    assert "esc(w.caption)" in show, "the label is the engine's, as the Promos cards' is"
    assert "locked" not in show.replace("w.locked", "")


def test_the_labels_match_the_promos_cards_word_for_word(tmp_path):
    cards = JS[JS.index("function showWelcome"):JS.index("/* ------------------------------------------------------------ convert my own promo")]
    for sentence in ("A boost cannot be hedged to a fixed amount.",
                     "It only pays if your first bet loses, so it cannot be locked in.",
                     "This kind of offer cannot be locked in.",
                     "locked from $${money(o.face)} in bonus if both bets are accepted and stand"):
        assert sentence in cards, sentence
    got = {a["worth"]["caption"] for a in _answers(tmp_path)}
    assert "locked from $100.00 in bonus if both bets are accepted and stand" in got
    assert {"expected on average. A boost cannot be hedged to a fixed amount.",
            "expected on average. It only pays if your first bet loses, so it cannot be locked in.",
            "expected on average. This kind of offer cannot be locked in."} <= got


def test_the_page_never_says_guaranteed_risk_free_free_bets_or_either_way():
    for text in (BLOCK, PANEL):
        low = text.lower()
        for banned in ("guarantee", "risk-free", "risk free", "free bet", "free money", "either way", "sure thing"):
            assert banned not in low, banned
    assert "bonus bet" in PANEL.lower()


def test_the_page_says_it_fetches_nothing_and_the_window_still_makes_no_request():
    assert "fetches nothing" in PANEL and "spends no credits" in PANEL
    assert "fetch(" not in BLOCK and "invoke(" not in BLOCK


def test_every_class_the_converter_draws_is_styled():
    classes = set(re.findall(r"\bpc-[a-z]+\b", BLOCK + PANEL)) - {"pc-type", "pc-book", "pc-amount", "pc-amount-l",
                                                                  "pc-boost", "pc-maxwin", "pc-match", "pc-roll"}
    assert {"pc-head", "pc-outcomes", "pc-oc", "pc-kept", "pc-pair", "pc-game", "pc-legs", "pc-leg", "pc-role",
            "pc-facts", "pc-notes", "pc-help"} <= classes
    for cls in classes - {"pc-form"}:  # pc-form is a hook on the shared .filters bar, which is styled
        assert re.search(rf"(?:^|[}},\s])\.{cls}\b[^{{]*[,{{]", CSS, re.M), f".{cls} has no rule in app.css"
    for cls in ("promo-big", "promo-head", "assume", "block", "tag", "how", "note", "up", "down", "bk"):
        assert re.search(rf"\.{cls}\b", CSS), cls


def test_a_refusal_from_the_engine_is_drawn_as_its_sentence():
    """The shell hands the window {"error": sentence}; the shared dispatcher escapes and draws it."""
    assert "if (out.error) return fail(box, esc(out.error));" in JS
    with pytest.raises(promoconv.PromoError, match="Pick the sportsbook"):
        promoconv.convert("bonus_bet", "", 100.0, history=Path("/nonexistent"), now=NOW)


def test_the_converter_holds_no_lab_code():
    for text in (BLOCK, PANEL):
        assert "edgelab" not in text and not re.search(r"\bH0\d\d\b", text)
    assert "lab" not in set(re.findall(r'^\s*[a-z-]+:\s*\(\)\s*=>\s*\[\s*"([a-z-]+)"', JS, re.M))
